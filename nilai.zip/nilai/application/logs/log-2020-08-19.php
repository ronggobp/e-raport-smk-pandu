<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-19 07:45:10 --> Config Class Initialized
INFO - 2020-08-19 07:45:10 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:10 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:10 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:10 --> URI Class Initialized
INFO - 2020-08-19 07:45:10 --> Router Class Initialized
INFO - 2020-08-19 07:45:10 --> Output Class Initialized
INFO - 2020-08-19 07:45:10 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:10 --> Input Class Initialized
INFO - 2020-08-19 07:45:10 --> Language Class Initialized
INFO - 2020-08-19 07:45:10 --> Language Class Initialized
INFO - 2020-08-19 07:45:10 --> Config Class Initialized
INFO - 2020-08-19 07:45:10 --> Loader Class Initialized
INFO - 2020-08-19 07:45:10 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:10 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:10 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:10 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:10 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:10 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:10 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:10 --> Total execution time: 0.0714
INFO - 2020-08-19 07:45:12 --> Config Class Initialized
INFO - 2020-08-19 07:45:12 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:12 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:12 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:12 --> URI Class Initialized
INFO - 2020-08-19 07:45:12 --> Router Class Initialized
INFO - 2020-08-19 07:45:12 --> Output Class Initialized
INFO - 2020-08-19 07:45:12 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:12 --> Input Class Initialized
INFO - 2020-08-19 07:45:12 --> Language Class Initialized
INFO - 2020-08-19 07:45:12 --> Language Class Initialized
INFO - 2020-08-19 07:45:12 --> Config Class Initialized
INFO - 2020-08-19 07:45:12 --> Loader Class Initialized
INFO - 2020-08-19 07:45:12 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:12 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:12 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:12 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:12 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:12 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:12 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:12 --> Total execution time: 0.0654
INFO - 2020-08-19 07:45:12 --> Config Class Initialized
INFO - 2020-08-19 07:45:12 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:12 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:12 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:12 --> URI Class Initialized
INFO - 2020-08-19 07:45:12 --> Router Class Initialized
INFO - 2020-08-19 07:45:12 --> Output Class Initialized
INFO - 2020-08-19 07:45:12 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:12 --> Input Class Initialized
INFO - 2020-08-19 07:45:12 --> Language Class Initialized
INFO - 2020-08-19 07:45:12 --> Language Class Initialized
INFO - 2020-08-19 07:45:12 --> Config Class Initialized
INFO - 2020-08-19 07:45:12 --> Loader Class Initialized
INFO - 2020-08-19 07:45:12 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:12 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:12 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:12 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:12 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:12 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:12 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:12 --> Total execution time: 0.0608
INFO - 2020-08-19 07:45:12 --> Config Class Initialized
INFO - 2020-08-19 07:45:12 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:13 --> URI Class Initialized
INFO - 2020-08-19 07:45:13 --> Router Class Initialized
INFO - 2020-08-19 07:45:13 --> Output Class Initialized
INFO - 2020-08-19 07:45:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:13 --> Input Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Loader Class Initialized
INFO - 2020-08-19 07:45:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:13 --> Total execution time: 0.0678
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:13 --> URI Class Initialized
INFO - 2020-08-19 07:45:13 --> Router Class Initialized
INFO - 2020-08-19 07:45:13 --> Output Class Initialized
INFO - 2020-08-19 07:45:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:13 --> Input Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Loader Class Initialized
INFO - 2020-08-19 07:45:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:13 --> Total execution time: 0.0636
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:13 --> URI Class Initialized
INFO - 2020-08-19 07:45:13 --> Router Class Initialized
INFO - 2020-08-19 07:45:13 --> Output Class Initialized
INFO - 2020-08-19 07:45:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:13 --> Input Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Loader Class Initialized
INFO - 2020-08-19 07:45:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:13 --> Total execution time: 0.0617
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:13 --> URI Class Initialized
INFO - 2020-08-19 07:45:13 --> Router Class Initialized
INFO - 2020-08-19 07:45:13 --> Output Class Initialized
INFO - 2020-08-19 07:45:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:13 --> Input Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Loader Class Initialized
INFO - 2020-08-19 07:45:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:13 --> Total execution time: 0.0662
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:13 --> URI Class Initialized
INFO - 2020-08-19 07:45:13 --> Router Class Initialized
INFO - 2020-08-19 07:45:13 --> Output Class Initialized
INFO - 2020-08-19 07:45:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:13 --> Input Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Language Class Initialized
INFO - 2020-08-19 07:45:13 --> Config Class Initialized
INFO - 2020-08-19 07:45:13 --> Loader Class Initialized
INFO - 2020-08-19 07:45:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:13 --> Total execution time: 0.0704
INFO - 2020-08-19 07:45:20 --> Config Class Initialized
INFO - 2020-08-19 07:45:20 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:45:20 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:45:20 --> Utf8 Class Initialized
INFO - 2020-08-19 07:45:20 --> URI Class Initialized
INFO - 2020-08-19 07:45:20 --> Router Class Initialized
INFO - 2020-08-19 07:45:20 --> Output Class Initialized
INFO - 2020-08-19 07:45:20 --> Security Class Initialized
DEBUG - 2020-08-19 07:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:45:20 --> Input Class Initialized
INFO - 2020-08-19 07:45:20 --> Language Class Initialized
INFO - 2020-08-19 07:45:20 --> Language Class Initialized
INFO - 2020-08-19 07:45:20 --> Config Class Initialized
INFO - 2020-08-19 07:45:20 --> Loader Class Initialized
INFO - 2020-08-19 07:45:20 --> Helper loaded: url_helper
INFO - 2020-08-19 07:45:20 --> Helper loaded: file_helper
INFO - 2020-08-19 07:45:20 --> Helper loaded: form_helper
INFO - 2020-08-19 07:45:20 --> Helper loaded: my_helper
INFO - 2020-08-19 07:45:20 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:45:20 --> Controller Class Initialized
DEBUG - 2020-08-19 07:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:45:20 --> Final output sent to browser
DEBUG - 2020-08-19 07:45:20 --> Total execution time: 0.0708
INFO - 2020-08-19 07:46:32 --> Config Class Initialized
INFO - 2020-08-19 07:46:32 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:32 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:32 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:32 --> URI Class Initialized
INFO - 2020-08-19 07:46:32 --> Router Class Initialized
INFO - 2020-08-19 07:46:32 --> Output Class Initialized
INFO - 2020-08-19 07:46:32 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:32 --> Input Class Initialized
INFO - 2020-08-19 07:46:32 --> Language Class Initialized
INFO - 2020-08-19 07:46:32 --> Language Class Initialized
INFO - 2020-08-19 07:46:32 --> Config Class Initialized
INFO - 2020-08-19 07:46:32 --> Loader Class Initialized
INFO - 2020-08-19 07:46:32 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:32 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:32 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:32 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:32 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:32 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:46:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:32 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:32 --> Total execution time: 0.0674
INFO - 2020-08-19 07:46:33 --> Config Class Initialized
INFO - 2020-08-19 07:46:33 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:33 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:33 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:33 --> URI Class Initialized
INFO - 2020-08-19 07:46:33 --> Router Class Initialized
INFO - 2020-08-19 07:46:33 --> Output Class Initialized
INFO - 2020-08-19 07:46:33 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:33 --> Input Class Initialized
INFO - 2020-08-19 07:46:33 --> Language Class Initialized
INFO - 2020-08-19 07:46:33 --> Language Class Initialized
INFO - 2020-08-19 07:46:33 --> Config Class Initialized
INFO - 2020-08-19 07:46:33 --> Loader Class Initialized
INFO - 2020-08-19 07:46:33 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:33 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:33 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:33 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:33 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:33 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:46:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:33 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:33 --> Total execution time: 0.0581
INFO - 2020-08-19 07:46:03 --> Config Class Initialized
INFO - 2020-08-19 07:46:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:03 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:03 --> URI Class Initialized
INFO - 2020-08-19 07:46:03 --> Router Class Initialized
INFO - 2020-08-19 07:46:03 --> Output Class Initialized
INFO - 2020-08-19 07:46:03 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:03 --> Input Class Initialized
INFO - 2020-08-19 07:46:03 --> Language Class Initialized
INFO - 2020-08-19 07:46:03 --> Language Class Initialized
INFO - 2020-08-19 07:46:03 --> Config Class Initialized
INFO - 2020-08-19 07:46:03 --> Loader Class Initialized
INFO - 2020-08-19 07:46:03 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:03 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:03 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:03 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:03 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-19 07:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:03 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:03 --> Total execution time: 0.0718
INFO - 2020-08-19 07:46:03 --> Config Class Initialized
INFO - 2020-08-19 07:46:03 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:03 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:03 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:03 --> URI Class Initialized
INFO - 2020-08-19 07:46:03 --> Router Class Initialized
INFO - 2020-08-19 07:46:03 --> Output Class Initialized
INFO - 2020-08-19 07:46:03 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:03 --> Input Class Initialized
INFO - 2020-08-19 07:46:03 --> Language Class Initialized
INFO - 2020-08-19 07:46:03 --> Language Class Initialized
INFO - 2020-08-19 07:46:03 --> Config Class Initialized
INFO - 2020-08-19 07:46:03 --> Loader Class Initialized
INFO - 2020-08-19 07:46:03 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:03 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:03 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:03 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:03 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:03 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-19 07:46:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:03 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:03 --> Total execution time: 0.0574
INFO - 2020-08-19 07:46:04 --> Config Class Initialized
INFO - 2020-08-19 07:46:04 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:04 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:04 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:04 --> URI Class Initialized
INFO - 2020-08-19 07:46:04 --> Router Class Initialized
INFO - 2020-08-19 07:46:04 --> Output Class Initialized
INFO - 2020-08-19 07:46:04 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:04 --> Input Class Initialized
INFO - 2020-08-19 07:46:04 --> Language Class Initialized
INFO - 2020-08-19 07:46:04 --> Language Class Initialized
INFO - 2020-08-19 07:46:04 --> Config Class Initialized
INFO - 2020-08-19 07:46:04 --> Loader Class Initialized
INFO - 2020-08-19 07:46:04 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:04 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:04 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:04 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:04 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:04 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:46:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:04 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:04 --> Total execution time: 0.0595
INFO - 2020-08-19 07:46:28 --> Config Class Initialized
INFO - 2020-08-19 07:46:28 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:28 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:28 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:28 --> URI Class Initialized
INFO - 2020-08-19 07:46:28 --> Router Class Initialized
INFO - 2020-08-19 07:46:28 --> Output Class Initialized
INFO - 2020-08-19 07:46:28 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:28 --> Input Class Initialized
INFO - 2020-08-19 07:46:28 --> Language Class Initialized
INFO - 2020-08-19 07:46:28 --> Language Class Initialized
INFO - 2020-08-19 07:46:28 --> Config Class Initialized
INFO - 2020-08-19 07:46:28 --> Loader Class Initialized
INFO - 2020-08-19 07:46:28 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:28 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:28 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:28 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:28 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:28 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-19 07:46:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:28 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:28 --> Total execution time: 0.0698
INFO - 2020-08-19 07:46:53 --> Config Class Initialized
INFO - 2020-08-19 07:46:53 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:53 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:53 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:53 --> URI Class Initialized
INFO - 2020-08-19 07:46:53 --> Router Class Initialized
INFO - 2020-08-19 07:46:53 --> Output Class Initialized
INFO - 2020-08-19 07:46:53 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:53 --> Input Class Initialized
INFO - 2020-08-19 07:46:53 --> Language Class Initialized
INFO - 2020-08-19 07:46:53 --> Language Class Initialized
INFO - 2020-08-19 07:46:53 --> Config Class Initialized
INFO - 2020-08-19 07:46:53 --> Loader Class Initialized
INFO - 2020-08-19 07:46:53 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:53 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:53 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:53 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:53 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:53 --> Controller Class Initialized
INFO - 2020-08-19 07:46:53 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:46:53 --> Config Class Initialized
INFO - 2020-08-19 07:46:53 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:46:53 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:46:53 --> Utf8 Class Initialized
INFO - 2020-08-19 07:46:53 --> URI Class Initialized
INFO - 2020-08-19 07:46:53 --> Router Class Initialized
INFO - 2020-08-19 07:46:53 --> Output Class Initialized
INFO - 2020-08-19 07:46:53 --> Security Class Initialized
DEBUG - 2020-08-19 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:46:53 --> Input Class Initialized
INFO - 2020-08-19 07:46:53 --> Language Class Initialized
INFO - 2020-08-19 07:46:53 --> Language Class Initialized
INFO - 2020-08-19 07:46:53 --> Config Class Initialized
INFO - 2020-08-19 07:46:53 --> Loader Class Initialized
INFO - 2020-08-19 07:46:53 --> Helper loaded: url_helper
INFO - 2020-08-19 07:46:54 --> Helper loaded: file_helper
INFO - 2020-08-19 07:46:54 --> Helper loaded: form_helper
INFO - 2020-08-19 07:46:54 --> Helper loaded: my_helper
INFO - 2020-08-19 07:46:54 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:46:54 --> Controller Class Initialized
DEBUG - 2020-08-19 07:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:46:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:46:54 --> Final output sent to browser
DEBUG - 2020-08-19 07:46:54 --> Total execution time: 0.0705
INFO - 2020-08-19 07:47:58 --> Config Class Initialized
INFO - 2020-08-19 07:47:58 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:47:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:47:58 --> Utf8 Class Initialized
INFO - 2020-08-19 07:47:58 --> URI Class Initialized
INFO - 2020-08-19 07:47:58 --> Router Class Initialized
INFO - 2020-08-19 07:47:58 --> Output Class Initialized
INFO - 2020-08-19 07:47:58 --> Security Class Initialized
DEBUG - 2020-08-19 07:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:47:58 --> Input Class Initialized
INFO - 2020-08-19 07:47:58 --> Language Class Initialized
INFO - 2020-08-19 07:47:58 --> Language Class Initialized
INFO - 2020-08-19 07:47:58 --> Config Class Initialized
INFO - 2020-08-19 07:47:58 --> Loader Class Initialized
INFO - 2020-08-19 07:47:58 --> Helper loaded: url_helper
INFO - 2020-08-19 07:47:58 --> Helper loaded: file_helper
INFO - 2020-08-19 07:47:58 --> Helper loaded: form_helper
INFO - 2020-08-19 07:47:58 --> Helper loaded: my_helper
INFO - 2020-08-19 07:47:58 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:47:58 --> Controller Class Initialized
DEBUG - 2020-08-19 07:47:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:47:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:47:58 --> Final output sent to browser
DEBUG - 2020-08-19 07:47:58 --> Total execution time: 0.0604
INFO - 2020-08-19 07:48:15 --> Config Class Initialized
INFO - 2020-08-19 07:48:15 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:15 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:15 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:15 --> URI Class Initialized
INFO - 2020-08-19 07:48:15 --> Router Class Initialized
INFO - 2020-08-19 07:48:15 --> Output Class Initialized
INFO - 2020-08-19 07:48:15 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:15 --> Input Class Initialized
INFO - 2020-08-19 07:48:15 --> Language Class Initialized
INFO - 2020-08-19 07:48:15 --> Language Class Initialized
INFO - 2020-08-19 07:48:15 --> Config Class Initialized
INFO - 2020-08-19 07:48:15 --> Loader Class Initialized
INFO - 2020-08-19 07:48:15 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:15 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:15 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:15 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:15 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:15 --> Controller Class Initialized
INFO - 2020-08-19 07:48:15 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:48:15 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:15 --> Total execution time: 0.0554
INFO - 2020-08-19 07:48:15 --> Config Class Initialized
INFO - 2020-08-19 07:48:15 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:15 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:15 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:15 --> URI Class Initialized
INFO - 2020-08-19 07:48:15 --> Router Class Initialized
INFO - 2020-08-19 07:48:15 --> Output Class Initialized
INFO - 2020-08-19 07:48:15 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:15 --> Input Class Initialized
INFO - 2020-08-19 07:48:15 --> Language Class Initialized
INFO - 2020-08-19 07:48:15 --> Language Class Initialized
INFO - 2020-08-19 07:48:15 --> Config Class Initialized
INFO - 2020-08-19 07:48:15 --> Loader Class Initialized
INFO - 2020-08-19 07:48:15 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:15 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:15 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:15 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:15 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:15 --> Controller Class Initialized
DEBUG - 2020-08-19 07:48:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:48:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:16 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:16 --> Total execution time: 0.6986
INFO - 2020-08-19 07:48:17 --> Config Class Initialized
INFO - 2020-08-19 07:48:17 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:17 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:17 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:17 --> URI Class Initialized
INFO - 2020-08-19 07:48:17 --> Router Class Initialized
INFO - 2020-08-19 07:48:17 --> Output Class Initialized
INFO - 2020-08-19 07:48:17 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:17 --> Input Class Initialized
INFO - 2020-08-19 07:48:17 --> Language Class Initialized
INFO - 2020-08-19 07:48:17 --> Language Class Initialized
INFO - 2020-08-19 07:48:17 --> Config Class Initialized
INFO - 2020-08-19 07:48:17 --> Loader Class Initialized
INFO - 2020-08-19 07:48:17 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:17 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:17 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:17 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:17 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:17 --> Controller Class Initialized
DEBUG - 2020-08-19 07:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:17 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:17 --> Total execution time: 0.0456
INFO - 2020-08-19 07:48:17 --> Config Class Initialized
INFO - 2020-08-19 07:48:17 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:17 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:17 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:17 --> URI Class Initialized
INFO - 2020-08-19 07:48:17 --> Router Class Initialized
INFO - 2020-08-19 07:48:17 --> Output Class Initialized
INFO - 2020-08-19 07:48:17 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:17 --> Input Class Initialized
INFO - 2020-08-19 07:48:17 --> Language Class Initialized
INFO - 2020-08-19 07:48:17 --> Language Class Initialized
INFO - 2020-08-19 07:48:17 --> Config Class Initialized
INFO - 2020-08-19 07:48:17 --> Loader Class Initialized
INFO - 2020-08-19 07:48:17 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:17 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:17 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:17 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:17 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:17 --> Controller Class Initialized
INFO - 2020-08-19 07:48:21 --> Config Class Initialized
INFO - 2020-08-19 07:48:21 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:21 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:21 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:21 --> URI Class Initialized
INFO - 2020-08-19 07:48:21 --> Router Class Initialized
INFO - 2020-08-19 07:48:21 --> Output Class Initialized
INFO - 2020-08-19 07:48:21 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:21 --> Input Class Initialized
INFO - 2020-08-19 07:48:21 --> Language Class Initialized
INFO - 2020-08-19 07:48:21 --> Language Class Initialized
INFO - 2020-08-19 07:48:21 --> Config Class Initialized
INFO - 2020-08-19 07:48:21 --> Loader Class Initialized
INFO - 2020-08-19 07:48:21 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:21 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:21 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:21 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:21 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:21 --> Controller Class Initialized
DEBUG - 2020-08-19 07:48:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-19 07:48:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:21 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:21 --> Total execution time: 0.0618
INFO - 2020-08-19 07:48:22 --> Config Class Initialized
INFO - 2020-08-19 07:48:22 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:22 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:22 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:22 --> URI Class Initialized
INFO - 2020-08-19 07:48:22 --> Router Class Initialized
INFO - 2020-08-19 07:48:22 --> Output Class Initialized
INFO - 2020-08-19 07:48:22 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:22 --> Input Class Initialized
INFO - 2020-08-19 07:48:22 --> Language Class Initialized
INFO - 2020-08-19 07:48:22 --> Language Class Initialized
INFO - 2020-08-19 07:48:22 --> Config Class Initialized
INFO - 2020-08-19 07:48:22 --> Loader Class Initialized
INFO - 2020-08-19 07:48:22 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:22 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:22 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:22 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:22 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:22 --> Controller Class Initialized
DEBUG - 2020-08-19 07:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-19 07:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:22 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:22 --> Total execution time: 0.0482
INFO - 2020-08-19 07:48:24 --> Config Class Initialized
INFO - 2020-08-19 07:48:24 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:24 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:24 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:24 --> URI Class Initialized
INFO - 2020-08-19 07:48:24 --> Router Class Initialized
INFO - 2020-08-19 07:48:24 --> Output Class Initialized
INFO - 2020-08-19 07:48:24 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:24 --> Input Class Initialized
INFO - 2020-08-19 07:48:24 --> Language Class Initialized
INFO - 2020-08-19 07:48:24 --> Language Class Initialized
INFO - 2020-08-19 07:48:24 --> Config Class Initialized
INFO - 2020-08-19 07:48:24 --> Loader Class Initialized
INFO - 2020-08-19 07:48:24 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:24 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:24 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:24 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:24 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:25 --> Controller Class Initialized
DEBUG - 2020-08-19 07:48:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:48:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:25 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:25 --> Total execution time: 0.0443
INFO - 2020-08-19 07:48:25 --> Config Class Initialized
INFO - 2020-08-19 07:48:25 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:25 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:25 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:25 --> URI Class Initialized
INFO - 2020-08-19 07:48:25 --> Router Class Initialized
INFO - 2020-08-19 07:48:25 --> Output Class Initialized
INFO - 2020-08-19 07:48:25 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:25 --> Input Class Initialized
INFO - 2020-08-19 07:48:25 --> Language Class Initialized
INFO - 2020-08-19 07:48:25 --> Language Class Initialized
INFO - 2020-08-19 07:48:25 --> Config Class Initialized
INFO - 2020-08-19 07:48:25 --> Loader Class Initialized
INFO - 2020-08-19 07:48:25 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:25 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:25 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:25 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:25 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:25 --> Controller Class Initialized
INFO - 2020-08-19 07:48:41 --> Config Class Initialized
INFO - 2020-08-19 07:48:41 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:41 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:41 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:41 --> URI Class Initialized
INFO - 2020-08-19 07:48:41 --> Router Class Initialized
INFO - 2020-08-19 07:48:41 --> Output Class Initialized
INFO - 2020-08-19 07:48:41 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:41 --> Input Class Initialized
INFO - 2020-08-19 07:48:41 --> Language Class Initialized
INFO - 2020-08-19 07:48:41 --> Language Class Initialized
INFO - 2020-08-19 07:48:41 --> Config Class Initialized
INFO - 2020-08-19 07:48:41 --> Loader Class Initialized
INFO - 2020-08-19 07:48:41 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:41 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:41 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:41 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:41 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:41 --> Controller Class Initialized
INFO - 2020-08-19 07:48:47 --> Config Class Initialized
INFO - 2020-08-19 07:48:47 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:47 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:47 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:47 --> URI Class Initialized
INFO - 2020-08-19 07:48:47 --> Router Class Initialized
INFO - 2020-08-19 07:48:47 --> Output Class Initialized
INFO - 2020-08-19 07:48:47 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:47 --> Input Class Initialized
INFO - 2020-08-19 07:48:47 --> Language Class Initialized
INFO - 2020-08-19 07:48:47 --> Language Class Initialized
INFO - 2020-08-19 07:48:47 --> Config Class Initialized
INFO - 2020-08-19 07:48:47 --> Loader Class Initialized
INFO - 2020-08-19 07:48:47 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:47 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:47 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:47 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:47 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:47 --> Controller Class Initialized
ERROR - 2020-08-19 07:48:47 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:48:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:48:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:47 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:47 --> Total execution time: 0.0494
INFO - 2020-08-19 07:48:59 --> Config Class Initialized
INFO - 2020-08-19 07:48:59 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:59 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:59 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:59 --> URI Class Initialized
INFO - 2020-08-19 07:48:59 --> Router Class Initialized
INFO - 2020-08-19 07:48:59 --> Output Class Initialized
INFO - 2020-08-19 07:48:59 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:59 --> Input Class Initialized
INFO - 2020-08-19 07:48:59 --> Language Class Initialized
INFO - 2020-08-19 07:48:59 --> Language Class Initialized
INFO - 2020-08-19 07:48:59 --> Config Class Initialized
INFO - 2020-08-19 07:48:59 --> Loader Class Initialized
INFO - 2020-08-19 07:48:59 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:59 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:59 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:59 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:59 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:59 --> Controller Class Initialized
DEBUG - 2020-08-19 07:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:48:59 --> Final output sent to browser
DEBUG - 2020-08-19 07:48:59 --> Total execution time: 0.0462
INFO - 2020-08-19 07:48:59 --> Config Class Initialized
INFO - 2020-08-19 07:48:59 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:48:59 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:48:59 --> Utf8 Class Initialized
INFO - 2020-08-19 07:48:59 --> URI Class Initialized
INFO - 2020-08-19 07:48:59 --> Router Class Initialized
INFO - 2020-08-19 07:48:59 --> Output Class Initialized
INFO - 2020-08-19 07:48:59 --> Security Class Initialized
DEBUG - 2020-08-19 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:48:59 --> Input Class Initialized
INFO - 2020-08-19 07:48:59 --> Language Class Initialized
INFO - 2020-08-19 07:48:59 --> Language Class Initialized
INFO - 2020-08-19 07:48:59 --> Config Class Initialized
INFO - 2020-08-19 07:48:59 --> Loader Class Initialized
INFO - 2020-08-19 07:48:59 --> Helper loaded: url_helper
INFO - 2020-08-19 07:48:59 --> Helper loaded: file_helper
INFO - 2020-08-19 07:48:59 --> Helper loaded: form_helper
INFO - 2020-08-19 07:48:59 --> Helper loaded: my_helper
INFO - 2020-08-19 07:48:59 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:48:59 --> Controller Class Initialized
INFO - 2020-08-19 07:49:01 --> Config Class Initialized
INFO - 2020-08-19 07:49:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:01 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:01 --> URI Class Initialized
INFO - 2020-08-19 07:49:01 --> Router Class Initialized
INFO - 2020-08-19 07:49:01 --> Output Class Initialized
INFO - 2020-08-19 07:49:01 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:01 --> Input Class Initialized
INFO - 2020-08-19 07:49:01 --> Language Class Initialized
INFO - 2020-08-19 07:49:01 --> Language Class Initialized
INFO - 2020-08-19 07:49:01 --> Config Class Initialized
INFO - 2020-08-19 07:49:01 --> Loader Class Initialized
INFO - 2020-08-19 07:49:01 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:01 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:01 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:01 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:01 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:01 --> Controller Class Initialized
INFO - 2020-08-19 07:49:02 --> Config Class Initialized
INFO - 2020-08-19 07:49:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:02 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:02 --> URI Class Initialized
INFO - 2020-08-19 07:49:02 --> Router Class Initialized
INFO - 2020-08-19 07:49:02 --> Output Class Initialized
INFO - 2020-08-19 07:49:02 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:02 --> Input Class Initialized
INFO - 2020-08-19 07:49:02 --> Language Class Initialized
INFO - 2020-08-19 07:49:02 --> Language Class Initialized
INFO - 2020-08-19 07:49:02 --> Config Class Initialized
INFO - 2020-08-19 07:49:02 --> Loader Class Initialized
INFO - 2020-08-19 07:49:02 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:02 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:02 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:02 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:02 --> Controller Class Initialized
ERROR - 2020-08-19 07:49:02 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:49:02 --> Final output sent to browser
DEBUG - 2020-08-19 07:49:02 --> Total execution time: 0.0487
INFO - 2020-08-19 07:49:09 --> Config Class Initialized
INFO - 2020-08-19 07:49:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:09 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:09 --> URI Class Initialized
INFO - 2020-08-19 07:49:09 --> Router Class Initialized
INFO - 2020-08-19 07:49:09 --> Output Class Initialized
INFO - 2020-08-19 07:49:09 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:09 --> Input Class Initialized
INFO - 2020-08-19 07:49:09 --> Language Class Initialized
INFO - 2020-08-19 07:49:09 --> Language Class Initialized
INFO - 2020-08-19 07:49:09 --> Config Class Initialized
INFO - 2020-08-19 07:49:09 --> Loader Class Initialized
INFO - 2020-08-19 07:49:09 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:09 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:09 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:09 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:09 --> Controller Class Initialized
DEBUG - 2020-08-19 07:49:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:49:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:49:09 --> Final output sent to browser
DEBUG - 2020-08-19 07:49:09 --> Total execution time: 0.0669
INFO - 2020-08-19 07:49:09 --> Config Class Initialized
INFO - 2020-08-19 07:49:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:09 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:09 --> URI Class Initialized
INFO - 2020-08-19 07:49:09 --> Router Class Initialized
INFO - 2020-08-19 07:49:09 --> Output Class Initialized
INFO - 2020-08-19 07:49:09 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:09 --> Input Class Initialized
INFO - 2020-08-19 07:49:09 --> Language Class Initialized
INFO - 2020-08-19 07:49:09 --> Language Class Initialized
INFO - 2020-08-19 07:49:09 --> Config Class Initialized
INFO - 2020-08-19 07:49:09 --> Loader Class Initialized
INFO - 2020-08-19 07:49:09 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:09 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:09 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:09 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:09 --> Controller Class Initialized
INFO - 2020-08-19 07:49:11 --> Config Class Initialized
INFO - 2020-08-19 07:49:11 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:11 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:11 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:11 --> URI Class Initialized
INFO - 2020-08-19 07:49:11 --> Router Class Initialized
INFO - 2020-08-19 07:49:11 --> Output Class Initialized
INFO - 2020-08-19 07:49:11 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:11 --> Input Class Initialized
INFO - 2020-08-19 07:49:11 --> Language Class Initialized
INFO - 2020-08-19 07:49:11 --> Language Class Initialized
INFO - 2020-08-19 07:49:11 --> Config Class Initialized
INFO - 2020-08-19 07:49:11 --> Loader Class Initialized
INFO - 2020-08-19 07:49:11 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:11 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:11 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:11 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:11 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:11 --> Controller Class Initialized
INFO - 2020-08-19 07:49:12 --> Config Class Initialized
INFO - 2020-08-19 07:49:12 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:12 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:12 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:12 --> URI Class Initialized
INFO - 2020-08-19 07:49:12 --> Router Class Initialized
INFO - 2020-08-19 07:49:12 --> Output Class Initialized
INFO - 2020-08-19 07:49:12 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:12 --> Input Class Initialized
INFO - 2020-08-19 07:49:12 --> Language Class Initialized
INFO - 2020-08-19 07:49:12 --> Language Class Initialized
INFO - 2020-08-19 07:49:12 --> Config Class Initialized
INFO - 2020-08-19 07:49:12 --> Loader Class Initialized
INFO - 2020-08-19 07:49:12 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:12 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:12 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:12 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:12 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:12 --> Controller Class Initialized
ERROR - 2020-08-19 07:49:12 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:49:12 --> Final output sent to browser
DEBUG - 2020-08-19 07:49:12 --> Total execution time: 0.0493
INFO - 2020-08-19 07:49:19 --> Config Class Initialized
INFO - 2020-08-19 07:49:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:19 --> URI Class Initialized
INFO - 2020-08-19 07:49:19 --> Router Class Initialized
INFO - 2020-08-19 07:49:19 --> Output Class Initialized
INFO - 2020-08-19 07:49:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:19 --> Input Class Initialized
INFO - 2020-08-19 07:49:19 --> Language Class Initialized
INFO - 2020-08-19 07:49:19 --> Language Class Initialized
INFO - 2020-08-19 07:49:19 --> Config Class Initialized
INFO - 2020-08-19 07:49:19 --> Loader Class Initialized
INFO - 2020-08-19 07:49:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:19 --> Controller Class Initialized
DEBUG - 2020-08-19 07:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:49:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:49:19 --> Final output sent to browser
DEBUG - 2020-08-19 07:49:19 --> Total execution time: 0.0452
INFO - 2020-08-19 07:49:19 --> Config Class Initialized
INFO - 2020-08-19 07:49:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:19 --> URI Class Initialized
INFO - 2020-08-19 07:49:19 --> Router Class Initialized
INFO - 2020-08-19 07:49:19 --> Output Class Initialized
INFO - 2020-08-19 07:49:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:19 --> Input Class Initialized
INFO - 2020-08-19 07:49:19 --> Language Class Initialized
INFO - 2020-08-19 07:49:19 --> Language Class Initialized
INFO - 2020-08-19 07:49:19 --> Config Class Initialized
INFO - 2020-08-19 07:49:19 --> Loader Class Initialized
INFO - 2020-08-19 07:49:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:19 --> Controller Class Initialized
INFO - 2020-08-19 07:49:23 --> Config Class Initialized
INFO - 2020-08-19 07:49:23 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:49:23 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:49:23 --> Utf8 Class Initialized
INFO - 2020-08-19 07:49:23 --> URI Class Initialized
INFO - 2020-08-19 07:49:23 --> Router Class Initialized
INFO - 2020-08-19 07:49:23 --> Output Class Initialized
INFO - 2020-08-19 07:49:23 --> Security Class Initialized
DEBUG - 2020-08-19 07:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:49:23 --> Input Class Initialized
INFO - 2020-08-19 07:49:23 --> Language Class Initialized
INFO - 2020-08-19 07:49:23 --> Language Class Initialized
INFO - 2020-08-19 07:49:23 --> Config Class Initialized
INFO - 2020-08-19 07:49:23 --> Loader Class Initialized
INFO - 2020-08-19 07:49:23 --> Helper loaded: url_helper
INFO - 2020-08-19 07:49:23 --> Helper loaded: file_helper
INFO - 2020-08-19 07:49:23 --> Helper loaded: form_helper
INFO - 2020-08-19 07:49:23 --> Helper loaded: my_helper
INFO - 2020-08-19 07:49:23 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:49:23 --> Controller Class Initialized
DEBUG - 2020-08-19 07:49:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-19 07:49:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:49:23 --> Final output sent to browser
DEBUG - 2020-08-19 07:49:23 --> Total execution time: 0.0588
INFO - 2020-08-19 07:50:27 --> Config Class Initialized
INFO - 2020-08-19 07:50:27 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:27 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:27 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:27 --> URI Class Initialized
INFO - 2020-08-19 07:50:27 --> Router Class Initialized
INFO - 2020-08-19 07:50:27 --> Output Class Initialized
INFO - 2020-08-19 07:50:27 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:27 --> Input Class Initialized
INFO - 2020-08-19 07:50:27 --> Language Class Initialized
INFO - 2020-08-19 07:50:27 --> Language Class Initialized
INFO - 2020-08-19 07:50:27 --> Config Class Initialized
INFO - 2020-08-19 07:50:27 --> Loader Class Initialized
INFO - 2020-08-19 07:50:27 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:27 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:27 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:27 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:27 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:27 --> Controller Class Initialized
INFO - 2020-08-19 07:50:27 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:50:27 --> Config Class Initialized
INFO - 2020-08-19 07:50:27 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:27 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:27 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:27 --> URI Class Initialized
INFO - 2020-08-19 07:50:27 --> Router Class Initialized
INFO - 2020-08-19 07:50:27 --> Output Class Initialized
INFO - 2020-08-19 07:50:27 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:27 --> Input Class Initialized
INFO - 2020-08-19 07:50:27 --> Language Class Initialized
INFO - 2020-08-19 07:50:27 --> Language Class Initialized
INFO - 2020-08-19 07:50:27 --> Config Class Initialized
INFO - 2020-08-19 07:50:27 --> Loader Class Initialized
INFO - 2020-08-19 07:50:27 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:27 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:27 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:27 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:27 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:27 --> Controller Class Initialized
DEBUG - 2020-08-19 07:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:50:27 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:27 --> Total execution time: 0.0544
INFO - 2020-08-19 07:50:32 --> Config Class Initialized
INFO - 2020-08-19 07:50:32 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:32 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:32 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:32 --> URI Class Initialized
INFO - 2020-08-19 07:50:32 --> Router Class Initialized
INFO - 2020-08-19 07:50:32 --> Output Class Initialized
INFO - 2020-08-19 07:50:32 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:32 --> Input Class Initialized
INFO - 2020-08-19 07:50:32 --> Language Class Initialized
INFO - 2020-08-19 07:50:32 --> Language Class Initialized
INFO - 2020-08-19 07:50:32 --> Config Class Initialized
INFO - 2020-08-19 07:50:32 --> Loader Class Initialized
INFO - 2020-08-19 07:50:32 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:32 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:32 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:32 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:32 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:32 --> Controller Class Initialized
INFO - 2020-08-19 07:50:32 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:50:32 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:32 --> Total execution time: 0.0722
INFO - 2020-08-19 07:50:32 --> Config Class Initialized
INFO - 2020-08-19 07:50:32 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:32 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:32 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:32 --> URI Class Initialized
INFO - 2020-08-19 07:50:32 --> Router Class Initialized
INFO - 2020-08-19 07:50:32 --> Output Class Initialized
INFO - 2020-08-19 07:50:32 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:32 --> Input Class Initialized
INFO - 2020-08-19 07:50:32 --> Language Class Initialized
INFO - 2020-08-19 07:50:32 --> Language Class Initialized
INFO - 2020-08-19 07:50:32 --> Config Class Initialized
INFO - 2020-08-19 07:50:32 --> Loader Class Initialized
INFO - 2020-08-19 07:50:32 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:32 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:32 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:32 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:32 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:32 --> Controller Class Initialized
DEBUG - 2020-08-19 07:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:50:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:50:33 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:33 --> Total execution time: 0.6362
INFO - 2020-08-19 07:50:34 --> Config Class Initialized
INFO - 2020-08-19 07:50:34 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:34 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:34 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:34 --> URI Class Initialized
INFO - 2020-08-19 07:50:34 --> Router Class Initialized
INFO - 2020-08-19 07:50:34 --> Output Class Initialized
INFO - 2020-08-19 07:50:34 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:34 --> Input Class Initialized
INFO - 2020-08-19 07:50:34 --> Language Class Initialized
INFO - 2020-08-19 07:50:34 --> Language Class Initialized
INFO - 2020-08-19 07:50:34 --> Config Class Initialized
INFO - 2020-08-19 07:50:34 --> Loader Class Initialized
INFO - 2020-08-19 07:50:34 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:34 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:34 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:34 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:34 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:34 --> Controller Class Initialized
DEBUG - 2020-08-19 07:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:50:34 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:34 --> Total execution time: 0.0901
INFO - 2020-08-19 07:50:40 --> Config Class Initialized
INFO - 2020-08-19 07:50:40 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:40 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:40 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:40 --> URI Class Initialized
INFO - 2020-08-19 07:50:40 --> Router Class Initialized
INFO - 2020-08-19 07:50:40 --> Output Class Initialized
INFO - 2020-08-19 07:50:40 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:40 --> Input Class Initialized
INFO - 2020-08-19 07:50:40 --> Language Class Initialized
INFO - 2020-08-19 07:50:40 --> Language Class Initialized
INFO - 2020-08-19 07:50:40 --> Config Class Initialized
INFO - 2020-08-19 07:50:40 --> Loader Class Initialized
INFO - 2020-08-19 07:50:40 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:40 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:40 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:40 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:40 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:40 --> Controller Class Initialized
INFO - 2020-08-19 07:50:40 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:50:40 --> Config Class Initialized
INFO - 2020-08-19 07:50:40 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:40 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:40 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:40 --> URI Class Initialized
INFO - 2020-08-19 07:50:40 --> Router Class Initialized
INFO - 2020-08-19 07:50:40 --> Output Class Initialized
INFO - 2020-08-19 07:50:40 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:40 --> Input Class Initialized
INFO - 2020-08-19 07:50:40 --> Language Class Initialized
INFO - 2020-08-19 07:50:40 --> Language Class Initialized
INFO - 2020-08-19 07:50:40 --> Config Class Initialized
INFO - 2020-08-19 07:50:40 --> Loader Class Initialized
INFO - 2020-08-19 07:50:40 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:40 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:40 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:40 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:40 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:40 --> Controller Class Initialized
DEBUG - 2020-08-19 07:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:50:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:50:40 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:40 --> Total execution time: 0.0550
INFO - 2020-08-19 07:50:48 --> Config Class Initialized
INFO - 2020-08-19 07:50:48 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:48 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:48 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:48 --> URI Class Initialized
INFO - 2020-08-19 07:50:48 --> Router Class Initialized
INFO - 2020-08-19 07:50:48 --> Output Class Initialized
INFO - 2020-08-19 07:50:48 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:48 --> Input Class Initialized
INFO - 2020-08-19 07:50:48 --> Language Class Initialized
INFO - 2020-08-19 07:50:48 --> Language Class Initialized
INFO - 2020-08-19 07:50:48 --> Config Class Initialized
INFO - 2020-08-19 07:50:48 --> Loader Class Initialized
INFO - 2020-08-19 07:50:48 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:48 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:48 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:48 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:48 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:48 --> Controller Class Initialized
INFO - 2020-08-19 07:50:48 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:50:48 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:48 --> Total execution time: 0.0664
INFO - 2020-08-19 07:50:48 --> Config Class Initialized
INFO - 2020-08-19 07:50:48 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:48 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:48 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:48 --> URI Class Initialized
INFO - 2020-08-19 07:50:48 --> Router Class Initialized
INFO - 2020-08-19 07:50:48 --> Output Class Initialized
INFO - 2020-08-19 07:50:48 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:48 --> Input Class Initialized
INFO - 2020-08-19 07:50:48 --> Language Class Initialized
INFO - 2020-08-19 07:50:48 --> Language Class Initialized
INFO - 2020-08-19 07:50:48 --> Config Class Initialized
INFO - 2020-08-19 07:50:48 --> Loader Class Initialized
INFO - 2020-08-19 07:50:48 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:48 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:48 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:48 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:48 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:48 --> Controller Class Initialized
DEBUG - 2020-08-19 07:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:50:49 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:49 --> Total execution time: 0.6162
INFO - 2020-08-19 07:50:50 --> Config Class Initialized
INFO - 2020-08-19 07:50:50 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:50:50 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:50:50 --> Utf8 Class Initialized
INFO - 2020-08-19 07:50:50 --> URI Class Initialized
INFO - 2020-08-19 07:50:50 --> Router Class Initialized
INFO - 2020-08-19 07:50:50 --> Output Class Initialized
INFO - 2020-08-19 07:50:50 --> Security Class Initialized
DEBUG - 2020-08-19 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:50:50 --> Input Class Initialized
INFO - 2020-08-19 07:50:50 --> Language Class Initialized
INFO - 2020-08-19 07:50:50 --> Language Class Initialized
INFO - 2020-08-19 07:50:50 --> Config Class Initialized
INFO - 2020-08-19 07:50:50 --> Loader Class Initialized
INFO - 2020-08-19 07:50:50 --> Helper loaded: url_helper
INFO - 2020-08-19 07:50:50 --> Helper loaded: file_helper
INFO - 2020-08-19 07:50:50 --> Helper loaded: form_helper
INFO - 2020-08-19 07:50:50 --> Helper loaded: my_helper
INFO - 2020-08-19 07:50:50 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:50:50 --> Controller Class Initialized
DEBUG - 2020-08-19 07:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:50:50 --> Final output sent to browser
DEBUG - 2020-08-19 07:50:50 --> Total execution time: 0.0647
INFO - 2020-08-19 07:51:01 --> Config Class Initialized
INFO - 2020-08-19 07:51:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:51:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:51:01 --> Utf8 Class Initialized
INFO - 2020-08-19 07:51:01 --> URI Class Initialized
INFO - 2020-08-19 07:51:01 --> Router Class Initialized
INFO - 2020-08-19 07:51:01 --> Output Class Initialized
INFO - 2020-08-19 07:51:01 --> Security Class Initialized
DEBUG - 2020-08-19 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:51:01 --> Input Class Initialized
INFO - 2020-08-19 07:51:01 --> Language Class Initialized
INFO - 2020-08-19 07:51:01 --> Language Class Initialized
INFO - 2020-08-19 07:51:01 --> Config Class Initialized
INFO - 2020-08-19 07:51:01 --> Loader Class Initialized
INFO - 2020-08-19 07:51:01 --> Helper loaded: url_helper
INFO - 2020-08-19 07:51:01 --> Helper loaded: file_helper
INFO - 2020-08-19 07:51:01 --> Helper loaded: form_helper
INFO - 2020-08-19 07:51:01 --> Helper loaded: my_helper
INFO - 2020-08-19 07:51:01 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:51:01 --> Controller Class Initialized
DEBUG - 2020-08-19 07:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-08-19 07:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:51:01 --> Final output sent to browser
DEBUG - 2020-08-19 07:51:01 --> Total execution time: 0.0860
INFO - 2020-08-19 07:51:01 --> Config Class Initialized
INFO - 2020-08-19 07:51:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:51:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:51:01 --> Utf8 Class Initialized
INFO - 2020-08-19 07:51:01 --> URI Class Initialized
INFO - 2020-08-19 07:51:01 --> Router Class Initialized
INFO - 2020-08-19 07:51:01 --> Output Class Initialized
INFO - 2020-08-19 07:51:01 --> Security Class Initialized
DEBUG - 2020-08-19 07:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:51:01 --> Input Class Initialized
INFO - 2020-08-19 07:51:01 --> Language Class Initialized
INFO - 2020-08-19 07:51:01 --> Language Class Initialized
INFO - 2020-08-19 07:51:01 --> Config Class Initialized
INFO - 2020-08-19 07:51:01 --> Loader Class Initialized
INFO - 2020-08-19 07:51:01 --> Helper loaded: url_helper
INFO - 2020-08-19 07:51:01 --> Helper loaded: file_helper
INFO - 2020-08-19 07:51:01 --> Helper loaded: form_helper
INFO - 2020-08-19 07:51:01 --> Helper loaded: my_helper
INFO - 2020-08-19 07:51:01 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:51:01 --> Controller Class Initialized
INFO - 2020-08-19 07:51:02 --> Config Class Initialized
INFO - 2020-08-19 07:51:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:51:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:51:02 --> Utf8 Class Initialized
INFO - 2020-08-19 07:51:02 --> URI Class Initialized
INFO - 2020-08-19 07:51:02 --> Router Class Initialized
INFO - 2020-08-19 07:51:02 --> Output Class Initialized
INFO - 2020-08-19 07:51:02 --> Security Class Initialized
DEBUG - 2020-08-19 07:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:51:02 --> Input Class Initialized
INFO - 2020-08-19 07:51:02 --> Language Class Initialized
INFO - 2020-08-19 07:51:02 --> Language Class Initialized
INFO - 2020-08-19 07:51:02 --> Config Class Initialized
INFO - 2020-08-19 07:51:02 --> Loader Class Initialized
INFO - 2020-08-19 07:51:02 --> Helper loaded: url_helper
INFO - 2020-08-19 07:51:02 --> Helper loaded: file_helper
INFO - 2020-08-19 07:51:02 --> Helper loaded: form_helper
INFO - 2020-08-19 07:51:02 --> Helper loaded: my_helper
INFO - 2020-08-19 07:51:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:51:02 --> Controller Class Initialized
INFO - 2020-08-19 07:51:02 --> Final output sent to browser
DEBUG - 2020-08-19 07:51:02 --> Total execution time: 0.1060
INFO - 2020-08-19 07:51:08 --> Config Class Initialized
INFO - 2020-08-19 07:51:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:51:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:51:08 --> Utf8 Class Initialized
INFO - 2020-08-19 07:51:08 --> URI Class Initialized
INFO - 2020-08-19 07:51:08 --> Router Class Initialized
INFO - 2020-08-19 07:51:08 --> Output Class Initialized
INFO - 2020-08-19 07:51:08 --> Security Class Initialized
DEBUG - 2020-08-19 07:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:51:08 --> Input Class Initialized
INFO - 2020-08-19 07:51:08 --> Language Class Initialized
INFO - 2020-08-19 07:51:08 --> Language Class Initialized
INFO - 2020-08-19 07:51:08 --> Config Class Initialized
INFO - 2020-08-19 07:51:08 --> Loader Class Initialized
INFO - 2020-08-19 07:51:08 --> Helper loaded: url_helper
INFO - 2020-08-19 07:51:08 --> Helper loaded: file_helper
INFO - 2020-08-19 07:51:08 --> Helper loaded: form_helper
INFO - 2020-08-19 07:51:08 --> Helper loaded: my_helper
INFO - 2020-08-19 07:51:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:51:08 --> Controller Class Initialized
DEBUG - 2020-08-19 07:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-08-19 07:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:51:08 --> Final output sent to browser
DEBUG - 2020-08-19 07:51:08 --> Total execution time: 0.0974
INFO - 2020-08-19 07:51:12 --> Config Class Initialized
INFO - 2020-08-19 07:51:12 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:51:12 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:51:12 --> Utf8 Class Initialized
INFO - 2020-08-19 07:51:12 --> URI Class Initialized
INFO - 2020-08-19 07:51:12 --> Router Class Initialized
INFO - 2020-08-19 07:51:12 --> Output Class Initialized
INFO - 2020-08-19 07:51:12 --> Security Class Initialized
DEBUG - 2020-08-19 07:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:51:12 --> Input Class Initialized
INFO - 2020-08-19 07:51:12 --> Language Class Initialized
INFO - 2020-08-19 07:51:12 --> Language Class Initialized
INFO - 2020-08-19 07:51:12 --> Config Class Initialized
INFO - 2020-08-19 07:51:12 --> Loader Class Initialized
INFO - 2020-08-19 07:51:12 --> Helper loaded: url_helper
INFO - 2020-08-19 07:51:12 --> Helper loaded: file_helper
INFO - 2020-08-19 07:51:12 --> Helper loaded: form_helper
INFO - 2020-08-19 07:51:12 --> Helper loaded: my_helper
INFO - 2020-08-19 07:51:12 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:51:12 --> Controller Class Initialized
INFO - 2020-08-19 07:51:12 --> Final output sent to browser
DEBUG - 2020-08-19 07:51:12 --> Total execution time: 0.0921
INFO - 2020-08-19 07:52:49 --> Config Class Initialized
INFO - 2020-08-19 07:52:49 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:52:49 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:52:49 --> Utf8 Class Initialized
INFO - 2020-08-19 07:52:49 --> URI Class Initialized
INFO - 2020-08-19 07:52:49 --> Router Class Initialized
INFO - 2020-08-19 07:52:49 --> Output Class Initialized
INFO - 2020-08-19 07:52:49 --> Security Class Initialized
DEBUG - 2020-08-19 07:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:52:49 --> Input Class Initialized
INFO - 2020-08-19 07:52:49 --> Language Class Initialized
INFO - 2020-08-19 07:52:49 --> Language Class Initialized
INFO - 2020-08-19 07:52:49 --> Config Class Initialized
INFO - 2020-08-19 07:52:49 --> Loader Class Initialized
INFO - 2020-08-19 07:52:49 --> Helper loaded: url_helper
INFO - 2020-08-19 07:52:49 --> Helper loaded: file_helper
INFO - 2020-08-19 07:52:49 --> Helper loaded: form_helper
INFO - 2020-08-19 07:52:49 --> Helper loaded: my_helper
INFO - 2020-08-19 07:52:49 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:52:49 --> Controller Class Initialized
DEBUG - 2020-08-19 07:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-08-19 07:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:52:49 --> Final output sent to browser
DEBUG - 2020-08-19 07:52:49 --> Total execution time: 0.0519
INFO - 2020-08-19 07:52:51 --> Config Class Initialized
INFO - 2020-08-19 07:52:51 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:52:51 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:52:51 --> Utf8 Class Initialized
INFO - 2020-08-19 07:52:51 --> URI Class Initialized
INFO - 2020-08-19 07:52:51 --> Router Class Initialized
INFO - 2020-08-19 07:52:51 --> Output Class Initialized
INFO - 2020-08-19 07:52:51 --> Security Class Initialized
DEBUG - 2020-08-19 07:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:52:51 --> Input Class Initialized
INFO - 2020-08-19 07:52:51 --> Language Class Initialized
INFO - 2020-08-19 07:52:51 --> Language Class Initialized
INFO - 2020-08-19 07:52:51 --> Config Class Initialized
INFO - 2020-08-19 07:52:51 --> Loader Class Initialized
INFO - 2020-08-19 07:52:51 --> Helper loaded: url_helper
INFO - 2020-08-19 07:52:51 --> Helper loaded: file_helper
INFO - 2020-08-19 07:52:51 --> Helper loaded: form_helper
INFO - 2020-08-19 07:52:51 --> Helper loaded: my_helper
INFO - 2020-08-19 07:52:51 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:52:51 --> Controller Class Initialized
INFO - 2020-08-19 07:52:51 --> Final output sent to browser
DEBUG - 2020-08-19 07:52:51 --> Total execution time: 0.0485
INFO - 2020-08-19 07:53:38 --> Config Class Initialized
INFO - 2020-08-19 07:53:38 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:38 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:38 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:38 --> URI Class Initialized
INFO - 2020-08-19 07:53:38 --> Router Class Initialized
INFO - 2020-08-19 07:53:38 --> Output Class Initialized
INFO - 2020-08-19 07:53:38 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:38 --> Input Class Initialized
INFO - 2020-08-19 07:53:38 --> Language Class Initialized
INFO - 2020-08-19 07:53:38 --> Language Class Initialized
INFO - 2020-08-19 07:53:38 --> Config Class Initialized
INFO - 2020-08-19 07:53:38 --> Loader Class Initialized
INFO - 2020-08-19 07:53:38 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:38 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:38 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:38 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:38 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:38 --> Controller Class Initialized
INFO - 2020-08-19 07:53:38 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:53:38 --> Config Class Initialized
INFO - 2020-08-19 07:53:38 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:38 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:38 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:38 --> URI Class Initialized
INFO - 2020-08-19 07:53:38 --> Router Class Initialized
INFO - 2020-08-19 07:53:38 --> Output Class Initialized
INFO - 2020-08-19 07:53:38 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:38 --> Input Class Initialized
INFO - 2020-08-19 07:53:38 --> Language Class Initialized
INFO - 2020-08-19 07:53:38 --> Language Class Initialized
INFO - 2020-08-19 07:53:38 --> Config Class Initialized
INFO - 2020-08-19 07:53:38 --> Loader Class Initialized
INFO - 2020-08-19 07:53:38 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:38 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:38 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:38 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:38 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:38 --> Controller Class Initialized
DEBUG - 2020-08-19 07:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:53:38 --> Final output sent to browser
DEBUG - 2020-08-19 07:53:38 --> Total execution time: 0.0547
INFO - 2020-08-19 07:53:45 --> Config Class Initialized
INFO - 2020-08-19 07:53:45 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:45 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:45 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:45 --> URI Class Initialized
INFO - 2020-08-19 07:53:45 --> Router Class Initialized
INFO - 2020-08-19 07:53:45 --> Output Class Initialized
INFO - 2020-08-19 07:53:45 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:45 --> Input Class Initialized
INFO - 2020-08-19 07:53:45 --> Language Class Initialized
INFO - 2020-08-19 07:53:45 --> Language Class Initialized
INFO - 2020-08-19 07:53:45 --> Config Class Initialized
INFO - 2020-08-19 07:53:45 --> Loader Class Initialized
INFO - 2020-08-19 07:53:45 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:45 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:45 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:45 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:45 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:45 --> Controller Class Initialized
INFO - 2020-08-19 07:53:45 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:53:45 --> Final output sent to browser
DEBUG - 2020-08-19 07:53:45 --> Total execution time: 0.0590
INFO - 2020-08-19 07:53:45 --> Config Class Initialized
INFO - 2020-08-19 07:53:45 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:45 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:45 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:45 --> URI Class Initialized
INFO - 2020-08-19 07:53:45 --> Router Class Initialized
INFO - 2020-08-19 07:53:45 --> Output Class Initialized
INFO - 2020-08-19 07:53:45 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:45 --> Input Class Initialized
INFO - 2020-08-19 07:53:45 --> Language Class Initialized
INFO - 2020-08-19 07:53:45 --> Language Class Initialized
INFO - 2020-08-19 07:53:45 --> Config Class Initialized
INFO - 2020-08-19 07:53:45 --> Loader Class Initialized
INFO - 2020-08-19 07:53:45 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:45 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:45 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:45 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:45 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:45 --> Controller Class Initialized
DEBUG - 2020-08-19 07:53:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:53:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:53:46 --> Final output sent to browser
DEBUG - 2020-08-19 07:53:46 --> Total execution time: 0.7240
INFO - 2020-08-19 07:53:51 --> Config Class Initialized
INFO - 2020-08-19 07:53:51 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:51 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:51 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:51 --> URI Class Initialized
INFO - 2020-08-19 07:53:51 --> Router Class Initialized
INFO - 2020-08-19 07:53:51 --> Output Class Initialized
INFO - 2020-08-19 07:53:51 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:51 --> Input Class Initialized
INFO - 2020-08-19 07:53:51 --> Language Class Initialized
INFO - 2020-08-19 07:53:51 --> Language Class Initialized
INFO - 2020-08-19 07:53:51 --> Config Class Initialized
INFO - 2020-08-19 07:53:51 --> Loader Class Initialized
INFO - 2020-08-19 07:53:51 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:51 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:51 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:51 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:51 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:51 --> Controller Class Initialized
DEBUG - 2020-08-19 07:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:53:51 --> Final output sent to browser
DEBUG - 2020-08-19 07:53:51 --> Total execution time: 0.0697
INFO - 2020-08-19 07:53:51 --> Config Class Initialized
INFO - 2020-08-19 07:53:51 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:51 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:51 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:51 --> URI Class Initialized
INFO - 2020-08-19 07:53:51 --> Router Class Initialized
INFO - 2020-08-19 07:53:51 --> Output Class Initialized
INFO - 2020-08-19 07:53:51 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:51 --> Input Class Initialized
INFO - 2020-08-19 07:53:51 --> Language Class Initialized
INFO - 2020-08-19 07:53:51 --> Language Class Initialized
INFO - 2020-08-19 07:53:51 --> Config Class Initialized
INFO - 2020-08-19 07:53:51 --> Loader Class Initialized
INFO - 2020-08-19 07:53:51 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:51 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:51 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:51 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:51 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:51 --> Controller Class Initialized
INFO - 2020-08-19 07:53:53 --> Config Class Initialized
INFO - 2020-08-19 07:53:53 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:53 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:53 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:53 --> URI Class Initialized
INFO - 2020-08-19 07:53:53 --> Router Class Initialized
INFO - 2020-08-19 07:53:53 --> Output Class Initialized
INFO - 2020-08-19 07:53:53 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:53 --> Input Class Initialized
INFO - 2020-08-19 07:53:53 --> Language Class Initialized
INFO - 2020-08-19 07:53:53 --> Language Class Initialized
INFO - 2020-08-19 07:53:53 --> Config Class Initialized
INFO - 2020-08-19 07:53:53 --> Loader Class Initialized
INFO - 2020-08-19 07:53:53 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:53 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:53 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:53 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:53 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:53 --> Controller Class Initialized
INFO - 2020-08-19 07:53:55 --> Config Class Initialized
INFO - 2020-08-19 07:53:55 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:55 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:55 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:55 --> URI Class Initialized
INFO - 2020-08-19 07:53:55 --> Router Class Initialized
INFO - 2020-08-19 07:53:55 --> Output Class Initialized
INFO - 2020-08-19 07:53:55 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:55 --> Input Class Initialized
INFO - 2020-08-19 07:53:55 --> Language Class Initialized
INFO - 2020-08-19 07:53:55 --> Language Class Initialized
INFO - 2020-08-19 07:53:55 --> Config Class Initialized
INFO - 2020-08-19 07:53:55 --> Loader Class Initialized
INFO - 2020-08-19 07:53:55 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:55 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:55 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:55 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:55 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:55 --> Controller Class Initialized
ERROR - 2020-08-19 07:53:55 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:53:55 --> Final output sent to browser
DEBUG - 2020-08-19 07:53:55 --> Total execution time: 0.0643
INFO - 2020-08-19 07:53:58 --> Config Class Initialized
INFO - 2020-08-19 07:53:58 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:58 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:58 --> URI Class Initialized
INFO - 2020-08-19 07:53:58 --> Router Class Initialized
INFO - 2020-08-19 07:53:58 --> Output Class Initialized
INFO - 2020-08-19 07:53:58 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:58 --> Input Class Initialized
INFO - 2020-08-19 07:53:58 --> Language Class Initialized
INFO - 2020-08-19 07:53:58 --> Language Class Initialized
INFO - 2020-08-19 07:53:58 --> Config Class Initialized
INFO - 2020-08-19 07:53:58 --> Loader Class Initialized
INFO - 2020-08-19 07:53:58 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:58 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:58 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:58 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:58 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:58 --> Controller Class Initialized
DEBUG - 2020-08-19 07:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:53:58 --> Final output sent to browser
DEBUG - 2020-08-19 07:53:58 --> Total execution time: 0.0682
INFO - 2020-08-19 07:53:58 --> Config Class Initialized
INFO - 2020-08-19 07:53:58 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:53:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:53:58 --> Utf8 Class Initialized
INFO - 2020-08-19 07:53:58 --> URI Class Initialized
INFO - 2020-08-19 07:53:58 --> Router Class Initialized
INFO - 2020-08-19 07:53:58 --> Output Class Initialized
INFO - 2020-08-19 07:53:58 --> Security Class Initialized
DEBUG - 2020-08-19 07:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:53:58 --> Input Class Initialized
INFO - 2020-08-19 07:53:58 --> Language Class Initialized
INFO - 2020-08-19 07:53:58 --> Language Class Initialized
INFO - 2020-08-19 07:53:58 --> Config Class Initialized
INFO - 2020-08-19 07:53:58 --> Loader Class Initialized
INFO - 2020-08-19 07:53:58 --> Helper loaded: url_helper
INFO - 2020-08-19 07:53:58 --> Helper loaded: file_helper
INFO - 2020-08-19 07:53:58 --> Helper loaded: form_helper
INFO - 2020-08-19 07:53:58 --> Helper loaded: my_helper
INFO - 2020-08-19 07:53:58 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:53:58 --> Controller Class Initialized
INFO - 2020-08-19 07:54:00 --> Config Class Initialized
INFO - 2020-08-19 07:54:00 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:00 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:00 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:00 --> URI Class Initialized
INFO - 2020-08-19 07:54:01 --> Router Class Initialized
INFO - 2020-08-19 07:54:01 --> Output Class Initialized
INFO - 2020-08-19 07:54:01 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:01 --> Input Class Initialized
INFO - 2020-08-19 07:54:01 --> Language Class Initialized
INFO - 2020-08-19 07:54:01 --> Language Class Initialized
INFO - 2020-08-19 07:54:01 --> Config Class Initialized
INFO - 2020-08-19 07:54:01 --> Loader Class Initialized
INFO - 2020-08-19 07:54:01 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:01 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:01 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:01 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:01 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:01 --> Controller Class Initialized
INFO - 2020-08-19 07:54:02 --> Config Class Initialized
INFO - 2020-08-19 07:54:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:02 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:02 --> URI Class Initialized
INFO - 2020-08-19 07:54:02 --> Router Class Initialized
INFO - 2020-08-19 07:54:02 --> Output Class Initialized
INFO - 2020-08-19 07:54:02 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:02 --> Input Class Initialized
INFO - 2020-08-19 07:54:02 --> Language Class Initialized
INFO - 2020-08-19 07:54:02 --> Language Class Initialized
INFO - 2020-08-19 07:54:02 --> Config Class Initialized
INFO - 2020-08-19 07:54:02 --> Loader Class Initialized
INFO - 2020-08-19 07:54:02 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:02 --> Controller Class Initialized
INFO - 2020-08-19 07:54:02 --> Config Class Initialized
INFO - 2020-08-19 07:54:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:02 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:02 --> URI Class Initialized
INFO - 2020-08-19 07:54:02 --> Router Class Initialized
INFO - 2020-08-19 07:54:02 --> Output Class Initialized
INFO - 2020-08-19 07:54:02 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:02 --> Input Class Initialized
INFO - 2020-08-19 07:54:02 --> Language Class Initialized
INFO - 2020-08-19 07:54:02 --> Language Class Initialized
INFO - 2020-08-19 07:54:02 --> Config Class Initialized
INFO - 2020-08-19 07:54:02 --> Loader Class Initialized
INFO - 2020-08-19 07:54:02 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:02 --> Controller Class Initialized
DEBUG - 2020-08-19 07:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:02 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:02 --> Total execution time: 0.0681
INFO - 2020-08-19 07:54:02 --> Config Class Initialized
INFO - 2020-08-19 07:54:02 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:02 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:02 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:02 --> URI Class Initialized
INFO - 2020-08-19 07:54:02 --> Router Class Initialized
INFO - 2020-08-19 07:54:02 --> Output Class Initialized
INFO - 2020-08-19 07:54:02 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:02 --> Input Class Initialized
INFO - 2020-08-19 07:54:02 --> Language Class Initialized
INFO - 2020-08-19 07:54:02 --> Language Class Initialized
INFO - 2020-08-19 07:54:02 --> Config Class Initialized
INFO - 2020-08-19 07:54:02 --> Loader Class Initialized
INFO - 2020-08-19 07:54:02 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:02 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:02 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:02 --> Controller Class Initialized
INFO - 2020-08-19 07:54:09 --> Config Class Initialized
INFO - 2020-08-19 07:54:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:09 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:09 --> URI Class Initialized
INFO - 2020-08-19 07:54:09 --> Router Class Initialized
INFO - 2020-08-19 07:54:09 --> Output Class Initialized
INFO - 2020-08-19 07:54:09 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:09 --> Input Class Initialized
INFO - 2020-08-19 07:54:09 --> Language Class Initialized
INFO - 2020-08-19 07:54:09 --> Language Class Initialized
INFO - 2020-08-19 07:54:09 --> Config Class Initialized
INFO - 2020-08-19 07:54:09 --> Loader Class Initialized
INFO - 2020-08-19 07:54:09 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:09 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:09 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:09 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:09 --> Controller Class Initialized
INFO - 2020-08-19 07:54:10 --> Config Class Initialized
INFO - 2020-08-19 07:54:10 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:10 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:10 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:10 --> URI Class Initialized
INFO - 2020-08-19 07:54:10 --> Router Class Initialized
INFO - 2020-08-19 07:54:10 --> Output Class Initialized
INFO - 2020-08-19 07:54:10 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:10 --> Input Class Initialized
INFO - 2020-08-19 07:54:10 --> Language Class Initialized
INFO - 2020-08-19 07:54:10 --> Language Class Initialized
INFO - 2020-08-19 07:54:10 --> Config Class Initialized
INFO - 2020-08-19 07:54:10 --> Loader Class Initialized
INFO - 2020-08-19 07:54:10 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:10 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:10 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:10 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:10 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:10 --> Controller Class Initialized
ERROR - 2020-08-19 07:54:10 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:54:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:54:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:10 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:10 --> Total execution time: 0.0720
INFO - 2020-08-19 07:54:19 --> Config Class Initialized
INFO - 2020-08-19 07:54:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:19 --> URI Class Initialized
INFO - 2020-08-19 07:54:19 --> Router Class Initialized
INFO - 2020-08-19 07:54:19 --> Output Class Initialized
INFO - 2020-08-19 07:54:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:19 --> Input Class Initialized
INFO - 2020-08-19 07:54:19 --> Language Class Initialized
INFO - 2020-08-19 07:54:19 --> Language Class Initialized
INFO - 2020-08-19 07:54:19 --> Config Class Initialized
INFO - 2020-08-19 07:54:19 --> Loader Class Initialized
INFO - 2020-08-19 07:54:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:19 --> Controller Class Initialized
DEBUG - 2020-08-19 07:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:19 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:19 --> Total execution time: 0.0638
INFO - 2020-08-19 07:54:20 --> Config Class Initialized
INFO - 2020-08-19 07:54:20 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:20 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:20 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:20 --> URI Class Initialized
INFO - 2020-08-19 07:54:20 --> Router Class Initialized
INFO - 2020-08-19 07:54:20 --> Output Class Initialized
INFO - 2020-08-19 07:54:20 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:20 --> Input Class Initialized
INFO - 2020-08-19 07:54:20 --> Language Class Initialized
INFO - 2020-08-19 07:54:20 --> Language Class Initialized
INFO - 2020-08-19 07:54:20 --> Config Class Initialized
INFO - 2020-08-19 07:54:20 --> Loader Class Initialized
INFO - 2020-08-19 07:54:20 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:20 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:20 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:20 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:20 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:20 --> Controller Class Initialized
INFO - 2020-08-19 07:54:22 --> Config Class Initialized
INFO - 2020-08-19 07:54:22 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:22 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:22 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:22 --> URI Class Initialized
INFO - 2020-08-19 07:54:22 --> Router Class Initialized
INFO - 2020-08-19 07:54:22 --> Output Class Initialized
INFO - 2020-08-19 07:54:22 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:22 --> Input Class Initialized
INFO - 2020-08-19 07:54:22 --> Language Class Initialized
INFO - 2020-08-19 07:54:22 --> Language Class Initialized
INFO - 2020-08-19 07:54:22 --> Config Class Initialized
INFO - 2020-08-19 07:54:22 --> Loader Class Initialized
INFO - 2020-08-19 07:54:22 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:22 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:22 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:22 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:22 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:22 --> Controller Class Initialized
INFO - 2020-08-19 07:54:25 --> Config Class Initialized
INFO - 2020-08-19 07:54:25 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:25 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:25 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:25 --> URI Class Initialized
INFO - 2020-08-19 07:54:25 --> Router Class Initialized
INFO - 2020-08-19 07:54:25 --> Output Class Initialized
INFO - 2020-08-19 07:54:25 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:25 --> Input Class Initialized
INFO - 2020-08-19 07:54:25 --> Language Class Initialized
INFO - 2020-08-19 07:54:25 --> Language Class Initialized
INFO - 2020-08-19 07:54:25 --> Config Class Initialized
INFO - 2020-08-19 07:54:25 --> Loader Class Initialized
INFO - 2020-08-19 07:54:25 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:25 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:25 --> Controller Class Initialized
INFO - 2020-08-19 07:54:25 --> Config Class Initialized
INFO - 2020-08-19 07:54:25 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:25 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:25 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:25 --> URI Class Initialized
INFO - 2020-08-19 07:54:25 --> Router Class Initialized
INFO - 2020-08-19 07:54:25 --> Output Class Initialized
INFO - 2020-08-19 07:54:25 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:25 --> Input Class Initialized
INFO - 2020-08-19 07:54:25 --> Language Class Initialized
INFO - 2020-08-19 07:54:25 --> Language Class Initialized
INFO - 2020-08-19 07:54:25 --> Config Class Initialized
INFO - 2020-08-19 07:54:25 --> Loader Class Initialized
INFO - 2020-08-19 07:54:25 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:25 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:25 --> Controller Class Initialized
DEBUG - 2020-08-19 07:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:25 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:25 --> Total execution time: 0.0586
INFO - 2020-08-19 07:54:25 --> Config Class Initialized
INFO - 2020-08-19 07:54:25 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:25 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:25 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:25 --> URI Class Initialized
INFO - 2020-08-19 07:54:25 --> Router Class Initialized
INFO - 2020-08-19 07:54:25 --> Output Class Initialized
INFO - 2020-08-19 07:54:25 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:25 --> Input Class Initialized
INFO - 2020-08-19 07:54:25 --> Language Class Initialized
INFO - 2020-08-19 07:54:25 --> Language Class Initialized
INFO - 2020-08-19 07:54:25 --> Config Class Initialized
INFO - 2020-08-19 07:54:25 --> Loader Class Initialized
INFO - 2020-08-19 07:54:25 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:25 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:25 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:25 --> Controller Class Initialized
INFO - 2020-08-19 07:54:32 --> Config Class Initialized
INFO - 2020-08-19 07:54:32 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:32 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:32 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:32 --> URI Class Initialized
INFO - 2020-08-19 07:54:32 --> Router Class Initialized
INFO - 2020-08-19 07:54:32 --> Output Class Initialized
INFO - 2020-08-19 07:54:32 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:32 --> Input Class Initialized
INFO - 2020-08-19 07:54:32 --> Language Class Initialized
INFO - 2020-08-19 07:54:32 --> Language Class Initialized
INFO - 2020-08-19 07:54:32 --> Config Class Initialized
INFO - 2020-08-19 07:54:32 --> Loader Class Initialized
INFO - 2020-08-19 07:54:32 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:32 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:32 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:32 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:32 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:32 --> Controller Class Initialized
INFO - 2020-08-19 07:54:34 --> Config Class Initialized
INFO - 2020-08-19 07:54:34 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:34 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:34 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:34 --> URI Class Initialized
INFO - 2020-08-19 07:54:34 --> Router Class Initialized
INFO - 2020-08-19 07:54:34 --> Output Class Initialized
INFO - 2020-08-19 07:54:34 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:34 --> Input Class Initialized
INFO - 2020-08-19 07:54:34 --> Language Class Initialized
INFO - 2020-08-19 07:54:34 --> Language Class Initialized
INFO - 2020-08-19 07:54:34 --> Config Class Initialized
INFO - 2020-08-19 07:54:34 --> Loader Class Initialized
INFO - 2020-08-19 07:54:34 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:34 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:34 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:34 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:34 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:34 --> Controller Class Initialized
ERROR - 2020-08-19 07:54:34 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:34 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:34 --> Total execution time: 0.0735
INFO - 2020-08-19 07:54:39 --> Config Class Initialized
INFO - 2020-08-19 07:54:39 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:39 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:39 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:39 --> URI Class Initialized
INFO - 2020-08-19 07:54:39 --> Router Class Initialized
INFO - 2020-08-19 07:54:39 --> Output Class Initialized
INFO - 2020-08-19 07:54:39 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:39 --> Input Class Initialized
INFO - 2020-08-19 07:54:39 --> Language Class Initialized
INFO - 2020-08-19 07:54:39 --> Language Class Initialized
INFO - 2020-08-19 07:54:39 --> Config Class Initialized
INFO - 2020-08-19 07:54:39 --> Loader Class Initialized
INFO - 2020-08-19 07:54:39 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:39 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:39 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:39 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:39 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:39 --> Controller Class Initialized
DEBUG - 2020-08-19 07:54:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:54:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:39 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:39 --> Total execution time: 0.0605
INFO - 2020-08-19 07:54:39 --> Config Class Initialized
INFO - 2020-08-19 07:54:39 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:39 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:39 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:39 --> URI Class Initialized
INFO - 2020-08-19 07:54:39 --> Router Class Initialized
INFO - 2020-08-19 07:54:39 --> Output Class Initialized
INFO - 2020-08-19 07:54:39 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:39 --> Input Class Initialized
INFO - 2020-08-19 07:54:39 --> Language Class Initialized
INFO - 2020-08-19 07:54:39 --> Language Class Initialized
INFO - 2020-08-19 07:54:39 --> Config Class Initialized
INFO - 2020-08-19 07:54:39 --> Loader Class Initialized
INFO - 2020-08-19 07:54:39 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:39 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:39 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:39 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:39 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:39 --> Controller Class Initialized
INFO - 2020-08-19 07:54:41 --> Config Class Initialized
INFO - 2020-08-19 07:54:41 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:41 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:41 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:41 --> URI Class Initialized
INFO - 2020-08-19 07:54:41 --> Router Class Initialized
INFO - 2020-08-19 07:54:41 --> Output Class Initialized
INFO - 2020-08-19 07:54:41 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:41 --> Input Class Initialized
INFO - 2020-08-19 07:54:41 --> Language Class Initialized
INFO - 2020-08-19 07:54:41 --> Language Class Initialized
INFO - 2020-08-19 07:54:41 --> Config Class Initialized
INFO - 2020-08-19 07:54:41 --> Loader Class Initialized
INFO - 2020-08-19 07:54:41 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:41 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:41 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:41 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:41 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:41 --> Controller Class Initialized
INFO - 2020-08-19 07:54:43 --> Config Class Initialized
INFO - 2020-08-19 07:54:43 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:43 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:43 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:43 --> URI Class Initialized
INFO - 2020-08-19 07:54:43 --> Router Class Initialized
INFO - 2020-08-19 07:54:43 --> Output Class Initialized
INFO - 2020-08-19 07:54:43 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:43 --> Input Class Initialized
INFO - 2020-08-19 07:54:43 --> Language Class Initialized
INFO - 2020-08-19 07:54:43 --> Language Class Initialized
INFO - 2020-08-19 07:54:43 --> Config Class Initialized
INFO - 2020-08-19 07:54:43 --> Loader Class Initialized
INFO - 2020-08-19 07:54:43 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:43 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:43 --> Controller Class Initialized
INFO - 2020-08-19 07:54:43 --> Config Class Initialized
INFO - 2020-08-19 07:54:43 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:43 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:43 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:43 --> URI Class Initialized
INFO - 2020-08-19 07:54:43 --> Router Class Initialized
INFO - 2020-08-19 07:54:43 --> Output Class Initialized
INFO - 2020-08-19 07:54:43 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:43 --> Input Class Initialized
INFO - 2020-08-19 07:54:43 --> Language Class Initialized
INFO - 2020-08-19 07:54:43 --> Language Class Initialized
INFO - 2020-08-19 07:54:43 --> Config Class Initialized
INFO - 2020-08-19 07:54:43 --> Loader Class Initialized
INFO - 2020-08-19 07:54:43 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:43 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:43 --> Controller Class Initialized
DEBUG - 2020-08-19 07:54:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:54:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:43 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:43 --> Total execution time: 0.0531
INFO - 2020-08-19 07:54:43 --> Config Class Initialized
INFO - 2020-08-19 07:54:43 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:43 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:43 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:43 --> URI Class Initialized
INFO - 2020-08-19 07:54:43 --> Router Class Initialized
INFO - 2020-08-19 07:54:43 --> Output Class Initialized
INFO - 2020-08-19 07:54:43 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:43 --> Input Class Initialized
INFO - 2020-08-19 07:54:43 --> Language Class Initialized
INFO - 2020-08-19 07:54:43 --> Language Class Initialized
INFO - 2020-08-19 07:54:43 --> Config Class Initialized
INFO - 2020-08-19 07:54:43 --> Loader Class Initialized
INFO - 2020-08-19 07:54:43 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:43 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:43 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:43 --> Controller Class Initialized
INFO - 2020-08-19 07:54:49 --> Config Class Initialized
INFO - 2020-08-19 07:54:49 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:49 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:49 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:49 --> URI Class Initialized
INFO - 2020-08-19 07:54:49 --> Router Class Initialized
INFO - 2020-08-19 07:54:49 --> Output Class Initialized
INFO - 2020-08-19 07:54:49 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:49 --> Input Class Initialized
INFO - 2020-08-19 07:54:49 --> Language Class Initialized
INFO - 2020-08-19 07:54:49 --> Language Class Initialized
INFO - 2020-08-19 07:54:49 --> Config Class Initialized
INFO - 2020-08-19 07:54:49 --> Loader Class Initialized
INFO - 2020-08-19 07:54:49 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:49 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:49 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:49 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:49 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:49 --> Controller Class Initialized
INFO - 2020-08-19 07:54:52 --> Config Class Initialized
INFO - 2020-08-19 07:54:52 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:52 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:52 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:52 --> URI Class Initialized
INFO - 2020-08-19 07:54:52 --> Router Class Initialized
INFO - 2020-08-19 07:54:52 --> Output Class Initialized
INFO - 2020-08-19 07:54:52 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:52 --> Input Class Initialized
INFO - 2020-08-19 07:54:52 --> Language Class Initialized
INFO - 2020-08-19 07:54:52 --> Language Class Initialized
INFO - 2020-08-19 07:54:52 --> Config Class Initialized
INFO - 2020-08-19 07:54:52 --> Loader Class Initialized
INFO - 2020-08-19 07:54:52 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:52 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:52 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:52 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:52 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:52 --> Controller Class Initialized
INFO - 2020-08-19 07:54:52 --> Config Class Initialized
INFO - 2020-08-19 07:54:52 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:52 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:52 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:52 --> URI Class Initialized
INFO - 2020-08-19 07:54:52 --> Router Class Initialized
INFO - 2020-08-19 07:54:52 --> Output Class Initialized
INFO - 2020-08-19 07:54:52 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:52 --> Input Class Initialized
INFO - 2020-08-19 07:54:52 --> Language Class Initialized
INFO - 2020-08-19 07:54:52 --> Language Class Initialized
INFO - 2020-08-19 07:54:52 --> Config Class Initialized
INFO - 2020-08-19 07:54:52 --> Loader Class Initialized
INFO - 2020-08-19 07:54:52 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:52 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:52 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:52 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:52 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:52 --> Controller Class Initialized
DEBUG - 2020-08-19 07:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:54:52 --> Final output sent to browser
DEBUG - 2020-08-19 07:54:52 --> Total execution time: 0.0688
INFO - 2020-08-19 07:54:53 --> Config Class Initialized
INFO - 2020-08-19 07:54:53 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:53 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:53 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:53 --> URI Class Initialized
INFO - 2020-08-19 07:54:53 --> Router Class Initialized
INFO - 2020-08-19 07:54:53 --> Output Class Initialized
INFO - 2020-08-19 07:54:53 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:53 --> Input Class Initialized
INFO - 2020-08-19 07:54:53 --> Language Class Initialized
INFO - 2020-08-19 07:54:53 --> Language Class Initialized
INFO - 2020-08-19 07:54:53 --> Config Class Initialized
INFO - 2020-08-19 07:54:53 --> Loader Class Initialized
INFO - 2020-08-19 07:54:53 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:53 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:53 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:53 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:53 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:53 --> Controller Class Initialized
INFO - 2020-08-19 07:54:59 --> Config Class Initialized
INFO - 2020-08-19 07:54:59 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:54:59 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:54:59 --> Utf8 Class Initialized
INFO - 2020-08-19 07:54:59 --> URI Class Initialized
INFO - 2020-08-19 07:54:59 --> Router Class Initialized
INFO - 2020-08-19 07:54:59 --> Output Class Initialized
INFO - 2020-08-19 07:54:59 --> Security Class Initialized
DEBUG - 2020-08-19 07:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:54:59 --> Input Class Initialized
INFO - 2020-08-19 07:54:59 --> Language Class Initialized
INFO - 2020-08-19 07:54:59 --> Language Class Initialized
INFO - 2020-08-19 07:54:59 --> Config Class Initialized
INFO - 2020-08-19 07:54:59 --> Loader Class Initialized
INFO - 2020-08-19 07:54:59 --> Helper loaded: url_helper
INFO - 2020-08-19 07:54:59 --> Helper loaded: file_helper
INFO - 2020-08-19 07:54:59 --> Helper loaded: form_helper
INFO - 2020-08-19 07:54:59 --> Helper loaded: my_helper
INFO - 2020-08-19 07:54:59 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:54:59 --> Controller Class Initialized
INFO - 2020-08-19 07:55:01 --> Config Class Initialized
INFO - 2020-08-19 07:55:01 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:01 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:01 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:01 --> URI Class Initialized
INFO - 2020-08-19 07:55:01 --> Router Class Initialized
INFO - 2020-08-19 07:55:01 --> Output Class Initialized
INFO - 2020-08-19 07:55:01 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:01 --> Input Class Initialized
INFO - 2020-08-19 07:55:01 --> Language Class Initialized
INFO - 2020-08-19 07:55:01 --> Language Class Initialized
INFO - 2020-08-19 07:55:01 --> Config Class Initialized
INFO - 2020-08-19 07:55:01 --> Loader Class Initialized
INFO - 2020-08-19 07:55:01 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:01 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:01 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:01 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:01 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:01 --> Controller Class Initialized
ERROR - 2020-08-19 07:55:01 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_c_akademik`, CONSTRAINT `FK_t_c_akademik_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '2340'
INFO - 2020-08-19 07:55:01 --> Language file loaded: language/english/db_lang.php
INFO - 2020-08-19 07:55:05 --> Config Class Initialized
INFO - 2020-08-19 07:55:05 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:05 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:05 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:05 --> URI Class Initialized
INFO - 2020-08-19 07:55:05 --> Router Class Initialized
INFO - 2020-08-19 07:55:05 --> Output Class Initialized
INFO - 2020-08-19 07:55:05 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:05 --> Input Class Initialized
INFO - 2020-08-19 07:55:05 --> Language Class Initialized
INFO - 2020-08-19 07:55:05 --> Language Class Initialized
INFO - 2020-08-19 07:55:05 --> Config Class Initialized
INFO - 2020-08-19 07:55:05 --> Loader Class Initialized
INFO - 2020-08-19 07:55:05 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:05 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:05 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:05 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:05 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:05 --> Controller Class Initialized
ERROR - 2020-08-19 07:55:05 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:55:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:55:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:05 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:05 --> Total execution time: 0.0680
INFO - 2020-08-19 07:55:09 --> Config Class Initialized
INFO - 2020-08-19 07:55:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:09 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:09 --> URI Class Initialized
INFO - 2020-08-19 07:55:09 --> Router Class Initialized
INFO - 2020-08-19 07:55:09 --> Output Class Initialized
INFO - 2020-08-19 07:55:09 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:09 --> Input Class Initialized
INFO - 2020-08-19 07:55:09 --> Language Class Initialized
INFO - 2020-08-19 07:55:09 --> Language Class Initialized
INFO - 2020-08-19 07:55:09 --> Config Class Initialized
INFO - 2020-08-19 07:55:09 --> Loader Class Initialized
INFO - 2020-08-19 07:55:09 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:09 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:09 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:09 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:09 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:09 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:09 --> Total execution time: 0.0665
INFO - 2020-08-19 07:55:09 --> Config Class Initialized
INFO - 2020-08-19 07:55:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:09 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:09 --> URI Class Initialized
INFO - 2020-08-19 07:55:09 --> Router Class Initialized
INFO - 2020-08-19 07:55:09 --> Output Class Initialized
INFO - 2020-08-19 07:55:09 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:09 --> Input Class Initialized
INFO - 2020-08-19 07:55:09 --> Language Class Initialized
INFO - 2020-08-19 07:55:09 --> Language Class Initialized
INFO - 2020-08-19 07:55:09 --> Config Class Initialized
INFO - 2020-08-19 07:55:09 --> Loader Class Initialized
INFO - 2020-08-19 07:55:09 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:09 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:09 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:09 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:09 --> Controller Class Initialized
INFO - 2020-08-19 07:55:11 --> Config Class Initialized
INFO - 2020-08-19 07:55:11 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:11 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:11 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:11 --> URI Class Initialized
INFO - 2020-08-19 07:55:11 --> Router Class Initialized
INFO - 2020-08-19 07:55:11 --> Output Class Initialized
INFO - 2020-08-19 07:55:11 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:11 --> Input Class Initialized
INFO - 2020-08-19 07:55:11 --> Language Class Initialized
INFO - 2020-08-19 07:55:11 --> Language Class Initialized
INFO - 2020-08-19 07:55:11 --> Config Class Initialized
INFO - 2020-08-19 07:55:11 --> Loader Class Initialized
INFO - 2020-08-19 07:55:11 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:11 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:11 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:11 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:11 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:11 --> Controller Class Initialized
INFO - 2020-08-19 07:55:13 --> Config Class Initialized
INFO - 2020-08-19 07:55:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:13 --> URI Class Initialized
INFO - 2020-08-19 07:55:13 --> Router Class Initialized
INFO - 2020-08-19 07:55:13 --> Output Class Initialized
INFO - 2020-08-19 07:55:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:13 --> Input Class Initialized
INFO - 2020-08-19 07:55:13 --> Language Class Initialized
INFO - 2020-08-19 07:55:13 --> Language Class Initialized
INFO - 2020-08-19 07:55:13 --> Config Class Initialized
INFO - 2020-08-19 07:55:13 --> Loader Class Initialized
INFO - 2020-08-19 07:55:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:13 --> Controller Class Initialized
INFO - 2020-08-19 07:55:13 --> Config Class Initialized
INFO - 2020-08-19 07:55:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:13 --> URI Class Initialized
INFO - 2020-08-19 07:55:13 --> Router Class Initialized
INFO - 2020-08-19 07:55:13 --> Output Class Initialized
INFO - 2020-08-19 07:55:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:13 --> Input Class Initialized
INFO - 2020-08-19 07:55:13 --> Language Class Initialized
INFO - 2020-08-19 07:55:13 --> Language Class Initialized
INFO - 2020-08-19 07:55:13 --> Config Class Initialized
INFO - 2020-08-19 07:55:13 --> Loader Class Initialized
INFO - 2020-08-19 07:55:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:55:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:13 --> Total execution time: 0.0681
INFO - 2020-08-19 07:55:13 --> Config Class Initialized
INFO - 2020-08-19 07:55:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:13 --> URI Class Initialized
INFO - 2020-08-19 07:55:13 --> Router Class Initialized
INFO - 2020-08-19 07:55:13 --> Output Class Initialized
INFO - 2020-08-19 07:55:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:13 --> Input Class Initialized
INFO - 2020-08-19 07:55:13 --> Language Class Initialized
INFO - 2020-08-19 07:55:13 --> Language Class Initialized
INFO - 2020-08-19 07:55:13 --> Config Class Initialized
INFO - 2020-08-19 07:55:13 --> Loader Class Initialized
INFO - 2020-08-19 07:55:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:13 --> Controller Class Initialized
INFO - 2020-08-19 07:55:16 --> Config Class Initialized
INFO - 2020-08-19 07:55:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:16 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:16 --> URI Class Initialized
INFO - 2020-08-19 07:55:16 --> Router Class Initialized
INFO - 2020-08-19 07:55:16 --> Output Class Initialized
INFO - 2020-08-19 07:55:16 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:16 --> Input Class Initialized
INFO - 2020-08-19 07:55:16 --> Language Class Initialized
INFO - 2020-08-19 07:55:16 --> Language Class Initialized
INFO - 2020-08-19 07:55:16 --> Config Class Initialized
INFO - 2020-08-19 07:55:16 --> Loader Class Initialized
INFO - 2020-08-19 07:55:16 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:16 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:16 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:16 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:16 --> Controller Class Initialized
INFO - 2020-08-19 07:55:17 --> Config Class Initialized
INFO - 2020-08-19 07:55:17 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:17 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:17 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:17 --> URI Class Initialized
INFO - 2020-08-19 07:55:17 --> Router Class Initialized
INFO - 2020-08-19 07:55:17 --> Output Class Initialized
INFO - 2020-08-19 07:55:17 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:17 --> Input Class Initialized
INFO - 2020-08-19 07:55:17 --> Language Class Initialized
INFO - 2020-08-19 07:55:17 --> Language Class Initialized
INFO - 2020-08-19 07:55:17 --> Config Class Initialized
INFO - 2020-08-19 07:55:17 --> Loader Class Initialized
INFO - 2020-08-19 07:55:17 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:17 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:17 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:17 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:17 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:17 --> Controller Class Initialized
ERROR - 2020-08-19 07:55:17 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2020-08-19 07:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-19 07:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:17 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:17 --> Total execution time: 0.0752
INFO - 2020-08-19 07:55:19 --> Config Class Initialized
INFO - 2020-08-19 07:55:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:19 --> URI Class Initialized
INFO - 2020-08-19 07:55:19 --> Router Class Initialized
INFO - 2020-08-19 07:55:19 --> Output Class Initialized
INFO - 2020-08-19 07:55:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:19 --> Input Class Initialized
INFO - 2020-08-19 07:55:19 --> Language Class Initialized
INFO - 2020-08-19 07:55:19 --> Language Class Initialized
INFO - 2020-08-19 07:55:19 --> Config Class Initialized
INFO - 2020-08-19 07:55:19 --> Loader Class Initialized
INFO - 2020-08-19 07:55:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:19 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:55:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:19 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:19 --> Total execution time: 0.0641
INFO - 2020-08-19 07:55:19 --> Config Class Initialized
INFO - 2020-08-19 07:55:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:19 --> URI Class Initialized
INFO - 2020-08-19 07:55:19 --> Router Class Initialized
INFO - 2020-08-19 07:55:19 --> Output Class Initialized
INFO - 2020-08-19 07:55:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:19 --> Input Class Initialized
INFO - 2020-08-19 07:55:19 --> Language Class Initialized
INFO - 2020-08-19 07:55:19 --> Language Class Initialized
INFO - 2020-08-19 07:55:19 --> Config Class Initialized
INFO - 2020-08-19 07:55:19 --> Loader Class Initialized
INFO - 2020-08-19 07:55:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:19 --> Controller Class Initialized
INFO - 2020-08-19 07:55:25 --> Config Class Initialized
INFO - 2020-08-19 07:55:25 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:25 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:25 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:25 --> URI Class Initialized
INFO - 2020-08-19 07:55:25 --> Router Class Initialized
INFO - 2020-08-19 07:55:25 --> Output Class Initialized
INFO - 2020-08-19 07:55:25 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:25 --> Input Class Initialized
INFO - 2020-08-19 07:55:25 --> Language Class Initialized
INFO - 2020-08-19 07:55:25 --> Language Class Initialized
INFO - 2020-08-19 07:55:25 --> Config Class Initialized
INFO - 2020-08-19 07:55:25 --> Loader Class Initialized
INFO - 2020-08-19 07:55:25 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:25 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:25 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:25 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:25 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:25 --> Controller Class Initialized
INFO - 2020-08-19 07:55:27 --> Config Class Initialized
INFO - 2020-08-19 07:55:27 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:27 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:27 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:27 --> URI Class Initialized
INFO - 2020-08-19 07:55:27 --> Router Class Initialized
INFO - 2020-08-19 07:55:27 --> Output Class Initialized
INFO - 2020-08-19 07:55:27 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:27 --> Input Class Initialized
INFO - 2020-08-19 07:55:27 --> Language Class Initialized
INFO - 2020-08-19 07:55:27 --> Language Class Initialized
INFO - 2020-08-19 07:55:27 --> Config Class Initialized
INFO - 2020-08-19 07:55:27 --> Loader Class Initialized
INFO - 2020-08-19 07:55:27 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:27 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:27 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:27 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:27 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:27 --> Controller Class Initialized
ERROR - 2020-08-19 07:55:27 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_c_akademik`, CONSTRAINT `FK_t_c_akademik_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswa` (`id`)) - Invalid query: DELETE FROM m_siswa WHERE id = '2344'
INFO - 2020-08-19 07:55:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-08-19 07:55:29 --> Config Class Initialized
INFO - 2020-08-19 07:55:29 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:29 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:29 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:29 --> URI Class Initialized
INFO - 2020-08-19 07:55:29 --> Router Class Initialized
INFO - 2020-08-19 07:55:29 --> Output Class Initialized
INFO - 2020-08-19 07:55:29 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:29 --> Input Class Initialized
INFO - 2020-08-19 07:55:29 --> Language Class Initialized
INFO - 2020-08-19 07:55:29 --> Language Class Initialized
INFO - 2020-08-19 07:55:29 --> Config Class Initialized
INFO - 2020-08-19 07:55:29 --> Loader Class Initialized
INFO - 2020-08-19 07:55:29 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:29 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:29 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:29 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:29 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:29 --> Controller Class Initialized
INFO - 2020-08-19 07:55:29 --> Config Class Initialized
INFO - 2020-08-19 07:55:29 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:29 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:29 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:29 --> URI Class Initialized
INFO - 2020-08-19 07:55:29 --> Router Class Initialized
INFO - 2020-08-19 07:55:29 --> Output Class Initialized
INFO - 2020-08-19 07:55:29 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:29 --> Input Class Initialized
INFO - 2020-08-19 07:55:29 --> Language Class Initialized
INFO - 2020-08-19 07:55:29 --> Language Class Initialized
INFO - 2020-08-19 07:55:29 --> Config Class Initialized
INFO - 2020-08-19 07:55:29 --> Loader Class Initialized
INFO - 2020-08-19 07:55:29 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:29 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:29 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:29 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:29 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:29 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-19 07:55:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:29 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:29 --> Total execution time: 0.0670
INFO - 2020-08-19 07:55:30 --> Config Class Initialized
INFO - 2020-08-19 07:55:30 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:30 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:30 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:30 --> URI Class Initialized
INFO - 2020-08-19 07:55:30 --> Router Class Initialized
INFO - 2020-08-19 07:55:30 --> Output Class Initialized
INFO - 2020-08-19 07:55:30 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:30 --> Input Class Initialized
INFO - 2020-08-19 07:55:30 --> Language Class Initialized
INFO - 2020-08-19 07:55:30 --> Language Class Initialized
INFO - 2020-08-19 07:55:30 --> Config Class Initialized
INFO - 2020-08-19 07:55:30 --> Loader Class Initialized
INFO - 2020-08-19 07:55:30 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:30 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:30 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:30 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:30 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:30 --> Controller Class Initialized
INFO - 2020-08-19 07:55:33 --> Config Class Initialized
INFO - 2020-08-19 07:55:33 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:33 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:33 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:33 --> URI Class Initialized
INFO - 2020-08-19 07:55:33 --> Router Class Initialized
INFO - 2020-08-19 07:55:33 --> Output Class Initialized
INFO - 2020-08-19 07:55:33 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:33 --> Input Class Initialized
INFO - 2020-08-19 07:55:33 --> Language Class Initialized
INFO - 2020-08-19 07:55:33 --> Language Class Initialized
INFO - 2020-08-19 07:55:33 --> Config Class Initialized
INFO - 2020-08-19 07:55:33 --> Loader Class Initialized
INFO - 2020-08-19 07:55:33 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:33 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:33 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:33 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:33 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:33 --> Controller Class Initialized
INFO - 2020-08-19 07:55:33 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:55:33 --> Config Class Initialized
INFO - 2020-08-19 07:55:33 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:33 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:33 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:33 --> URI Class Initialized
INFO - 2020-08-19 07:55:33 --> Router Class Initialized
INFO - 2020-08-19 07:55:33 --> Output Class Initialized
INFO - 2020-08-19 07:55:33 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:33 --> Input Class Initialized
INFO - 2020-08-19 07:55:33 --> Language Class Initialized
INFO - 2020-08-19 07:55:33 --> Language Class Initialized
INFO - 2020-08-19 07:55:33 --> Config Class Initialized
INFO - 2020-08-19 07:55:33 --> Loader Class Initialized
INFO - 2020-08-19 07:55:33 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:33 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:33 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:33 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:33 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:33 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:55:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:33 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:33 --> Total execution time: 0.0547
INFO - 2020-08-19 07:55:42 --> Config Class Initialized
INFO - 2020-08-19 07:55:42 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:42 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:42 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:42 --> URI Class Initialized
INFO - 2020-08-19 07:55:42 --> Router Class Initialized
INFO - 2020-08-19 07:55:42 --> Output Class Initialized
INFO - 2020-08-19 07:55:42 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:42 --> Input Class Initialized
INFO - 2020-08-19 07:55:42 --> Language Class Initialized
INFO - 2020-08-19 07:55:42 --> Language Class Initialized
INFO - 2020-08-19 07:55:42 --> Config Class Initialized
INFO - 2020-08-19 07:55:42 --> Loader Class Initialized
INFO - 2020-08-19 07:55:42 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:42 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:42 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:42 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:42 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:42 --> Controller Class Initialized
INFO - 2020-08-19 07:55:42 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:55:42 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:42 --> Total execution time: 0.0708
INFO - 2020-08-19 07:55:42 --> Config Class Initialized
INFO - 2020-08-19 07:55:42 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:42 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:42 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:42 --> URI Class Initialized
INFO - 2020-08-19 07:55:42 --> Router Class Initialized
INFO - 2020-08-19 07:55:42 --> Output Class Initialized
INFO - 2020-08-19 07:55:42 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:42 --> Input Class Initialized
INFO - 2020-08-19 07:55:42 --> Language Class Initialized
INFO - 2020-08-19 07:55:42 --> Language Class Initialized
INFO - 2020-08-19 07:55:42 --> Config Class Initialized
INFO - 2020-08-19 07:55:42 --> Loader Class Initialized
INFO - 2020-08-19 07:55:42 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:42 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:42 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:42 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:42 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:42 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:43 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:43 --> Total execution time: 0.6499
INFO - 2020-08-19 07:55:44 --> Config Class Initialized
INFO - 2020-08-19 07:55:44 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:44 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:44 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:44 --> URI Class Initialized
INFO - 2020-08-19 07:55:44 --> Router Class Initialized
INFO - 2020-08-19 07:55:44 --> Output Class Initialized
INFO - 2020-08-19 07:55:44 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:44 --> Input Class Initialized
INFO - 2020-08-19 07:55:44 --> Language Class Initialized
INFO - 2020-08-19 07:55:44 --> Language Class Initialized
INFO - 2020-08-19 07:55:44 --> Config Class Initialized
INFO - 2020-08-19 07:55:44 --> Loader Class Initialized
INFO - 2020-08-19 07:55:44 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:44 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:44 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:44 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:44 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:44 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:44 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:44 --> Total execution time: 0.0727
INFO - 2020-08-19 07:55:56 --> Config Class Initialized
INFO - 2020-08-19 07:55:56 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:56 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:56 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:56 --> URI Class Initialized
INFO - 2020-08-19 07:55:56 --> Router Class Initialized
INFO - 2020-08-19 07:55:56 --> Output Class Initialized
INFO - 2020-08-19 07:55:56 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:56 --> Input Class Initialized
INFO - 2020-08-19 07:55:56 --> Language Class Initialized
INFO - 2020-08-19 07:55:56 --> Language Class Initialized
INFO - 2020-08-19 07:55:56 --> Config Class Initialized
INFO - 2020-08-19 07:55:56 --> Loader Class Initialized
INFO - 2020-08-19 07:55:56 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:56 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:56 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:56 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:56 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:56 --> Controller Class Initialized
DEBUG - 2020-08-19 07:55:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-08-19 07:55:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:55:56 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:56 --> Total execution time: 0.0511
INFO - 2020-08-19 07:55:56 --> Config Class Initialized
INFO - 2020-08-19 07:55:56 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:56 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:56 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:56 --> URI Class Initialized
INFO - 2020-08-19 07:55:56 --> Router Class Initialized
INFO - 2020-08-19 07:55:56 --> Output Class Initialized
INFO - 2020-08-19 07:55:56 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:56 --> Input Class Initialized
INFO - 2020-08-19 07:55:56 --> Language Class Initialized
INFO - 2020-08-19 07:55:56 --> Language Class Initialized
INFO - 2020-08-19 07:55:56 --> Config Class Initialized
INFO - 2020-08-19 07:55:56 --> Loader Class Initialized
INFO - 2020-08-19 07:55:56 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:56 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:56 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:56 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:56 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:56 --> Controller Class Initialized
INFO - 2020-08-19 07:55:58 --> Config Class Initialized
INFO - 2020-08-19 07:55:58 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:55:58 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:55:58 --> Utf8 Class Initialized
INFO - 2020-08-19 07:55:58 --> URI Class Initialized
INFO - 2020-08-19 07:55:58 --> Router Class Initialized
INFO - 2020-08-19 07:55:58 --> Output Class Initialized
INFO - 2020-08-19 07:55:58 --> Security Class Initialized
DEBUG - 2020-08-19 07:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:55:58 --> Input Class Initialized
INFO - 2020-08-19 07:55:58 --> Language Class Initialized
INFO - 2020-08-19 07:55:58 --> Language Class Initialized
INFO - 2020-08-19 07:55:58 --> Config Class Initialized
INFO - 2020-08-19 07:55:58 --> Loader Class Initialized
INFO - 2020-08-19 07:55:58 --> Helper loaded: url_helper
INFO - 2020-08-19 07:55:58 --> Helper loaded: file_helper
INFO - 2020-08-19 07:55:58 --> Helper loaded: form_helper
INFO - 2020-08-19 07:55:58 --> Helper loaded: my_helper
INFO - 2020-08-19 07:55:58 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:55:58 --> Controller Class Initialized
INFO - 2020-08-19 07:55:58 --> Final output sent to browser
DEBUG - 2020-08-19 07:55:58 --> Total execution time: 0.0838
INFO - 2020-08-19 07:56:06 --> Config Class Initialized
INFO - 2020-08-19 07:56:06 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:06 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:06 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:06 --> URI Class Initialized
INFO - 2020-08-19 07:56:06 --> Router Class Initialized
INFO - 2020-08-19 07:56:06 --> Output Class Initialized
INFO - 2020-08-19 07:56:06 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:06 --> Input Class Initialized
INFO - 2020-08-19 07:56:06 --> Language Class Initialized
INFO - 2020-08-19 07:56:06 --> Language Class Initialized
INFO - 2020-08-19 07:56:06 --> Config Class Initialized
INFO - 2020-08-19 07:56:06 --> Loader Class Initialized
INFO - 2020-08-19 07:56:06 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:06 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:06 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:06 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:06 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:06 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:06 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:06 --> Total execution time: 0.0638
INFO - 2020-08-19 07:56:07 --> Config Class Initialized
INFO - 2020-08-19 07:56:07 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:07 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:07 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:07 --> URI Class Initialized
INFO - 2020-08-19 07:56:07 --> Router Class Initialized
INFO - 2020-08-19 07:56:07 --> Output Class Initialized
INFO - 2020-08-19 07:56:07 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:07 --> Input Class Initialized
INFO - 2020-08-19 07:56:07 --> Language Class Initialized
INFO - 2020-08-19 07:56:07 --> Language Class Initialized
INFO - 2020-08-19 07:56:07 --> Config Class Initialized
INFO - 2020-08-19 07:56:07 --> Loader Class Initialized
INFO - 2020-08-19 07:56:07 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:07 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:07 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:07 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:07 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:07 --> Controller Class Initialized
INFO - 2020-08-19 07:56:07 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:56:07 --> Config Class Initialized
INFO - 2020-08-19 07:56:07 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:07 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:07 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:07 --> URI Class Initialized
INFO - 2020-08-19 07:56:07 --> Router Class Initialized
INFO - 2020-08-19 07:56:07 --> Output Class Initialized
INFO - 2020-08-19 07:56:07 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:07 --> Input Class Initialized
INFO - 2020-08-19 07:56:07 --> Language Class Initialized
INFO - 2020-08-19 07:56:07 --> Language Class Initialized
INFO - 2020-08-19 07:56:07 --> Config Class Initialized
INFO - 2020-08-19 07:56:07 --> Loader Class Initialized
INFO - 2020-08-19 07:56:07 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:07 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:07 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:07 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:07 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:07 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:07 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:07 --> Total execution time: 0.0683
INFO - 2020-08-19 07:56:10 --> Config Class Initialized
INFO - 2020-08-19 07:56:10 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:10 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:10 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:10 --> URI Class Initialized
INFO - 2020-08-19 07:56:10 --> Router Class Initialized
INFO - 2020-08-19 07:56:10 --> Output Class Initialized
INFO - 2020-08-19 07:56:10 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:10 --> Input Class Initialized
INFO - 2020-08-19 07:56:10 --> Language Class Initialized
INFO - 2020-08-19 07:56:10 --> Language Class Initialized
INFO - 2020-08-19 07:56:10 --> Config Class Initialized
INFO - 2020-08-19 07:56:10 --> Loader Class Initialized
INFO - 2020-08-19 07:56:10 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:10 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:10 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:10 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:10 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:10 --> Controller Class Initialized
INFO - 2020-08-19 07:56:10 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:56:10 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:10 --> Total execution time: 0.0764
INFO - 2020-08-19 07:56:10 --> Config Class Initialized
INFO - 2020-08-19 07:56:10 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:10 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:10 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:10 --> URI Class Initialized
INFO - 2020-08-19 07:56:10 --> Router Class Initialized
INFO - 2020-08-19 07:56:10 --> Output Class Initialized
INFO - 2020-08-19 07:56:10 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:10 --> Input Class Initialized
INFO - 2020-08-19 07:56:10 --> Language Class Initialized
INFO - 2020-08-19 07:56:10 --> Language Class Initialized
INFO - 2020-08-19 07:56:10 --> Config Class Initialized
INFO - 2020-08-19 07:56:10 --> Loader Class Initialized
INFO - 2020-08-19 07:56:10 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:10 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:10 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:10 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:10 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:10 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:56:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:11 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:11 --> Total execution time: 0.6542
INFO - 2020-08-19 07:56:13 --> Config Class Initialized
INFO - 2020-08-19 07:56:13 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:13 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:13 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:13 --> URI Class Initialized
INFO - 2020-08-19 07:56:13 --> Router Class Initialized
INFO - 2020-08-19 07:56:13 --> Output Class Initialized
INFO - 2020-08-19 07:56:13 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:13 --> Input Class Initialized
INFO - 2020-08-19 07:56:13 --> Language Class Initialized
INFO - 2020-08-19 07:56:13 --> Language Class Initialized
INFO - 2020-08-19 07:56:13 --> Config Class Initialized
INFO - 2020-08-19 07:56:13 --> Loader Class Initialized
INFO - 2020-08-19 07:56:13 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:13 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:13 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:13 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:13 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:13 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:56:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:13 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:13 --> Total execution time: 0.0692
INFO - 2020-08-19 07:56:14 --> Config Class Initialized
INFO - 2020-08-19 07:56:14 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:14 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:14 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:14 --> URI Class Initialized
INFO - 2020-08-19 07:56:14 --> Router Class Initialized
INFO - 2020-08-19 07:56:14 --> Output Class Initialized
INFO - 2020-08-19 07:56:14 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:14 --> Input Class Initialized
INFO - 2020-08-19 07:56:14 --> Language Class Initialized
INFO - 2020-08-19 07:56:14 --> Language Class Initialized
INFO - 2020-08-19 07:56:14 --> Config Class Initialized
INFO - 2020-08-19 07:56:14 --> Loader Class Initialized
INFO - 2020-08-19 07:56:14 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:14 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:14 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:14 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:14 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:14 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-08-19 07:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:14 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:14 --> Total execution time: 0.0687
INFO - 2020-08-19 07:56:14 --> Config Class Initialized
INFO - 2020-08-19 07:56:14 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:14 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:14 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:14 --> URI Class Initialized
INFO - 2020-08-19 07:56:14 --> Router Class Initialized
INFO - 2020-08-19 07:56:14 --> Output Class Initialized
INFO - 2020-08-19 07:56:14 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:14 --> Input Class Initialized
INFO - 2020-08-19 07:56:14 --> Language Class Initialized
INFO - 2020-08-19 07:56:14 --> Language Class Initialized
INFO - 2020-08-19 07:56:14 --> Config Class Initialized
INFO - 2020-08-19 07:56:14 --> Loader Class Initialized
INFO - 2020-08-19 07:56:14 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:14 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:14 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:14 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:14 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:14 --> Controller Class Initialized
INFO - 2020-08-19 07:56:16 --> Config Class Initialized
INFO - 2020-08-19 07:56:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:16 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:16 --> URI Class Initialized
INFO - 2020-08-19 07:56:16 --> Router Class Initialized
INFO - 2020-08-19 07:56:16 --> Output Class Initialized
INFO - 2020-08-19 07:56:16 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:16 --> Input Class Initialized
INFO - 2020-08-19 07:56:16 --> Language Class Initialized
INFO - 2020-08-19 07:56:16 --> Language Class Initialized
INFO - 2020-08-19 07:56:16 --> Config Class Initialized
INFO - 2020-08-19 07:56:16 --> Loader Class Initialized
INFO - 2020-08-19 07:56:16 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:16 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:16 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:16 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:16 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:16 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:16 --> Total execution time: 0.0727
INFO - 2020-08-19 07:56:17 --> Config Class Initialized
INFO - 2020-08-19 07:56:17 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:17 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:17 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:17 --> URI Class Initialized
INFO - 2020-08-19 07:56:17 --> Router Class Initialized
INFO - 2020-08-19 07:56:17 --> Output Class Initialized
INFO - 2020-08-19 07:56:17 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:17 --> Input Class Initialized
INFO - 2020-08-19 07:56:17 --> Language Class Initialized
INFO - 2020-08-19 07:56:17 --> Language Class Initialized
INFO - 2020-08-19 07:56:17 --> Config Class Initialized
INFO - 2020-08-19 07:56:17 --> Loader Class Initialized
INFO - 2020-08-19 07:56:17 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:17 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:17 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:17 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:17 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:17 --> Controller Class Initialized
DEBUG - 2020-08-19 07:56:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-08-19 07:56:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:56:17 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:17 --> Total execution time: 0.0473
INFO - 2020-08-19 07:56:19 --> Config Class Initialized
INFO - 2020-08-19 07:56:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:56:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:56:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:56:19 --> URI Class Initialized
INFO - 2020-08-19 07:56:19 --> Router Class Initialized
INFO - 2020-08-19 07:56:19 --> Output Class Initialized
INFO - 2020-08-19 07:56:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:56:19 --> Input Class Initialized
INFO - 2020-08-19 07:56:19 --> Language Class Initialized
INFO - 2020-08-19 07:56:19 --> Language Class Initialized
INFO - 2020-08-19 07:56:19 --> Config Class Initialized
INFO - 2020-08-19 07:56:19 --> Loader Class Initialized
INFO - 2020-08-19 07:56:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:56:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:56:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:56:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:56:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:56:19 --> Controller Class Initialized
INFO - 2020-08-19 07:56:19 --> Final output sent to browser
DEBUG - 2020-08-19 07:56:19 --> Total execution time: 0.0930
INFO - 2020-08-19 07:57:05 --> Config Class Initialized
INFO - 2020-08-19 07:57:05 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:05 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:05 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:05 --> URI Class Initialized
INFO - 2020-08-19 07:57:05 --> Router Class Initialized
INFO - 2020-08-19 07:57:05 --> Output Class Initialized
INFO - 2020-08-19 07:57:05 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:05 --> Input Class Initialized
INFO - 2020-08-19 07:57:05 --> Language Class Initialized
INFO - 2020-08-19 07:57:05 --> Language Class Initialized
INFO - 2020-08-19 07:57:05 --> Config Class Initialized
INFO - 2020-08-19 07:57:05 --> Loader Class Initialized
INFO - 2020-08-19 07:57:05 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:05 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:05 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:05 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:05 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:05 --> Controller Class Initialized
INFO - 2020-08-19 07:57:05 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:57:05 --> Config Class Initialized
INFO - 2020-08-19 07:57:05 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:05 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:05 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:05 --> URI Class Initialized
INFO - 2020-08-19 07:57:05 --> Router Class Initialized
INFO - 2020-08-19 07:57:05 --> Output Class Initialized
INFO - 2020-08-19 07:57:05 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:05 --> Input Class Initialized
INFO - 2020-08-19 07:57:05 --> Language Class Initialized
INFO - 2020-08-19 07:57:05 --> Language Class Initialized
INFO - 2020-08-19 07:57:05 --> Config Class Initialized
INFO - 2020-08-19 07:57:05 --> Loader Class Initialized
INFO - 2020-08-19 07:57:05 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:05 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:05 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:05 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:05 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:05 --> Controller Class Initialized
DEBUG - 2020-08-19 07:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:57:05 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:05 --> Total execution time: 0.0547
INFO - 2020-08-19 07:57:08 --> Config Class Initialized
INFO - 2020-08-19 07:57:08 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:08 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:08 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:08 --> URI Class Initialized
INFO - 2020-08-19 07:57:08 --> Router Class Initialized
INFO - 2020-08-19 07:57:08 --> Output Class Initialized
INFO - 2020-08-19 07:57:08 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:08 --> Input Class Initialized
INFO - 2020-08-19 07:57:08 --> Language Class Initialized
INFO - 2020-08-19 07:57:08 --> Language Class Initialized
INFO - 2020-08-19 07:57:08 --> Config Class Initialized
INFO - 2020-08-19 07:57:08 --> Loader Class Initialized
INFO - 2020-08-19 07:57:08 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:08 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:08 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:08 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:08 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:08 --> Controller Class Initialized
INFO - 2020-08-19 07:57:08 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:57:08 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:08 --> Total execution time: 0.0673
INFO - 2020-08-19 07:57:09 --> Config Class Initialized
INFO - 2020-08-19 07:57:09 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:09 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:09 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:09 --> URI Class Initialized
INFO - 2020-08-19 07:57:09 --> Router Class Initialized
INFO - 2020-08-19 07:57:09 --> Output Class Initialized
INFO - 2020-08-19 07:57:09 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:09 --> Input Class Initialized
INFO - 2020-08-19 07:57:09 --> Language Class Initialized
INFO - 2020-08-19 07:57:09 --> Language Class Initialized
INFO - 2020-08-19 07:57:09 --> Config Class Initialized
INFO - 2020-08-19 07:57:09 --> Loader Class Initialized
INFO - 2020-08-19 07:57:09 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:09 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:09 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:09 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:09 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:09 --> Controller Class Initialized
DEBUG - 2020-08-19 07:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-19 07:57:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:57:09 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:09 --> Total execution time: 0.6858
INFO - 2020-08-19 07:57:10 --> Config Class Initialized
INFO - 2020-08-19 07:57:10 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:10 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:10 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:10 --> URI Class Initialized
INFO - 2020-08-19 07:57:10 --> Router Class Initialized
INFO - 2020-08-19 07:57:10 --> Output Class Initialized
INFO - 2020-08-19 07:57:10 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:10 --> Input Class Initialized
INFO - 2020-08-19 07:57:10 --> Language Class Initialized
INFO - 2020-08-19 07:57:10 --> Language Class Initialized
INFO - 2020-08-19 07:57:10 --> Config Class Initialized
INFO - 2020-08-19 07:57:10 --> Loader Class Initialized
INFO - 2020-08-19 07:57:10 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:10 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:10 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:10 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:10 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:10 --> Controller Class Initialized
DEBUG - 2020-08-19 07:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-19 07:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:57:11 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:11 --> Total execution time: 0.0716
INFO - 2020-08-19 07:57:16 --> Config Class Initialized
INFO - 2020-08-19 07:57:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:16 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:16 --> URI Class Initialized
INFO - 2020-08-19 07:57:16 --> Router Class Initialized
INFO - 2020-08-19 07:57:16 --> Output Class Initialized
INFO - 2020-08-19 07:57:16 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:16 --> Input Class Initialized
INFO - 2020-08-19 07:57:16 --> Language Class Initialized
INFO - 2020-08-19 07:57:16 --> Language Class Initialized
INFO - 2020-08-19 07:57:16 --> Config Class Initialized
INFO - 2020-08-19 07:57:16 --> Loader Class Initialized
INFO - 2020-08-19 07:57:16 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:16 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:16 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:16 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:16 --> Controller Class Initialized
DEBUG - 2020-08-19 07:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-08-19 07:57:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:57:16 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:16 --> Total execution time: 0.0529
INFO - 2020-08-19 07:57:16 --> Config Class Initialized
INFO - 2020-08-19 07:57:16 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:16 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:16 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:16 --> URI Class Initialized
INFO - 2020-08-19 07:57:16 --> Router Class Initialized
INFO - 2020-08-19 07:57:16 --> Output Class Initialized
INFO - 2020-08-19 07:57:16 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:16 --> Input Class Initialized
INFO - 2020-08-19 07:57:16 --> Language Class Initialized
INFO - 2020-08-19 07:57:16 --> Language Class Initialized
INFO - 2020-08-19 07:57:16 --> Config Class Initialized
INFO - 2020-08-19 07:57:16 --> Loader Class Initialized
INFO - 2020-08-19 07:57:16 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:16 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:16 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:16 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:16 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:16 --> Controller Class Initialized
INFO - 2020-08-19 07:57:19 --> Config Class Initialized
INFO - 2020-08-19 07:57:19 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:19 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:19 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:19 --> URI Class Initialized
INFO - 2020-08-19 07:57:19 --> Router Class Initialized
INFO - 2020-08-19 07:57:19 --> Output Class Initialized
INFO - 2020-08-19 07:57:19 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:19 --> Input Class Initialized
INFO - 2020-08-19 07:57:19 --> Language Class Initialized
INFO - 2020-08-19 07:57:19 --> Language Class Initialized
INFO - 2020-08-19 07:57:19 --> Config Class Initialized
INFO - 2020-08-19 07:57:19 --> Loader Class Initialized
INFO - 2020-08-19 07:57:19 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:19 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:19 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:19 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:19 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:19 --> Controller Class Initialized
INFO - 2020-08-19 07:57:19 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:19 --> Total execution time: 0.0869
INFO - 2020-08-19 07:57:45 --> Config Class Initialized
INFO - 2020-08-19 07:57:45 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:45 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:45 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:45 --> URI Class Initialized
INFO - 2020-08-19 07:57:45 --> Router Class Initialized
INFO - 2020-08-19 07:57:45 --> Output Class Initialized
INFO - 2020-08-19 07:57:45 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:45 --> Input Class Initialized
INFO - 2020-08-19 07:57:45 --> Language Class Initialized
INFO - 2020-08-19 07:57:45 --> Language Class Initialized
INFO - 2020-08-19 07:57:45 --> Config Class Initialized
INFO - 2020-08-19 07:57:45 --> Loader Class Initialized
INFO - 2020-08-19 07:57:45 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:45 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:45 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:45 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:45 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:45 --> Controller Class Initialized
INFO - 2020-08-19 07:57:45 --> Helper loaded: cookie_helper
INFO - 2020-08-19 07:57:45 --> Config Class Initialized
INFO - 2020-08-19 07:57:45 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:57:45 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:57:45 --> Utf8 Class Initialized
INFO - 2020-08-19 07:57:45 --> URI Class Initialized
INFO - 2020-08-19 07:57:45 --> Router Class Initialized
INFO - 2020-08-19 07:57:45 --> Output Class Initialized
INFO - 2020-08-19 07:57:45 --> Security Class Initialized
DEBUG - 2020-08-19 07:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:57:45 --> Input Class Initialized
INFO - 2020-08-19 07:57:45 --> Language Class Initialized
INFO - 2020-08-19 07:57:45 --> Language Class Initialized
INFO - 2020-08-19 07:57:46 --> Config Class Initialized
INFO - 2020-08-19 07:57:46 --> Loader Class Initialized
INFO - 2020-08-19 07:57:46 --> Helper loaded: url_helper
INFO - 2020-08-19 07:57:46 --> Helper loaded: file_helper
INFO - 2020-08-19 07:57:46 --> Helper loaded: form_helper
INFO - 2020-08-19 07:57:46 --> Helper loaded: my_helper
INFO - 2020-08-19 07:57:46 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:57:46 --> Controller Class Initialized
DEBUG - 2020-08-19 07:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-19 07:57:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:57:46 --> Final output sent to browser
DEBUG - 2020-08-19 07:57:46 --> Total execution time: 0.0691
INFO - 2020-08-19 07:59:42 --> Config Class Initialized
INFO - 2020-08-19 07:59:42 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:59:42 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:59:42 --> Utf8 Class Initialized
INFO - 2020-08-19 07:59:42 --> URI Class Initialized
INFO - 2020-08-19 07:59:42 --> Router Class Initialized
INFO - 2020-08-19 07:59:42 --> Output Class Initialized
INFO - 2020-08-19 07:59:42 --> Security Class Initialized
DEBUG - 2020-08-19 07:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:59:42 --> Input Class Initialized
INFO - 2020-08-19 07:59:42 --> Language Class Initialized
INFO - 2020-08-19 07:59:42 --> Language Class Initialized
INFO - 2020-08-19 07:59:42 --> Config Class Initialized
INFO - 2020-08-19 07:59:42 --> Loader Class Initialized
INFO - 2020-08-19 07:59:42 --> Helper loaded: url_helper
INFO - 2020-08-19 07:59:42 --> Helper loaded: file_helper
INFO - 2020-08-19 07:59:42 --> Helper loaded: form_helper
INFO - 2020-08-19 07:59:42 --> Helper loaded: my_helper
INFO - 2020-08-19 07:59:42 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:59:42 --> Controller Class Initialized
DEBUG - 2020-08-19 07:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-08-19 07:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-19 07:59:42 --> Final output sent to browser
DEBUG - 2020-08-19 07:59:42 --> Total execution time: 0.0512
INFO - 2020-08-19 07:59:46 --> Config Class Initialized
INFO - 2020-08-19 07:59:46 --> Hooks Class Initialized
DEBUG - 2020-08-19 07:59:46 --> UTF-8 Support Enabled
INFO - 2020-08-19 07:59:46 --> Utf8 Class Initialized
INFO - 2020-08-19 07:59:46 --> URI Class Initialized
INFO - 2020-08-19 07:59:46 --> Router Class Initialized
INFO - 2020-08-19 07:59:46 --> Output Class Initialized
INFO - 2020-08-19 07:59:46 --> Security Class Initialized
DEBUG - 2020-08-19 07:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 07:59:46 --> Input Class Initialized
INFO - 2020-08-19 07:59:46 --> Language Class Initialized
INFO - 2020-08-19 07:59:46 --> Language Class Initialized
INFO - 2020-08-19 07:59:46 --> Config Class Initialized
INFO - 2020-08-19 07:59:46 --> Loader Class Initialized
INFO - 2020-08-19 07:59:46 --> Helper loaded: url_helper
INFO - 2020-08-19 07:59:46 --> Helper loaded: file_helper
INFO - 2020-08-19 07:59:46 --> Helper loaded: form_helper
INFO - 2020-08-19 07:59:46 --> Helper loaded: my_helper
INFO - 2020-08-19 07:59:46 --> Database Driver Class Initialized
DEBUG - 2020-08-19 07:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 07:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 07:59:46 --> Controller Class Initialized
INFO - 2020-08-19 08:00:27 --> Config Class Initialized
INFO - 2020-08-19 08:00:27 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:00:27 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:00:27 --> Utf8 Class Initialized
INFO - 2020-08-19 08:00:27 --> URI Class Initialized
INFO - 2020-08-19 08:00:27 --> Router Class Initialized
INFO - 2020-08-19 08:00:27 --> Output Class Initialized
INFO - 2020-08-19 08:00:27 --> Security Class Initialized
DEBUG - 2020-08-19 08:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:00:27 --> Input Class Initialized
INFO - 2020-08-19 08:00:27 --> Language Class Initialized
INFO - 2020-08-19 08:00:27 --> Language Class Initialized
INFO - 2020-08-19 08:00:27 --> Config Class Initialized
INFO - 2020-08-19 08:00:27 --> Loader Class Initialized
INFO - 2020-08-19 08:00:27 --> Helper loaded: url_helper
INFO - 2020-08-19 08:00:27 --> Helper loaded: file_helper
INFO - 2020-08-19 08:00:27 --> Helper loaded: form_helper
INFO - 2020-08-19 08:00:27 --> Helper loaded: my_helper
INFO - 2020-08-19 08:00:27 --> Database Driver Class Initialized
DEBUG - 2020-08-19 08:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 08:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:00:27 --> Controller Class Initialized
INFO - 2020-08-19 08:00:27 --> Final output sent to browser
DEBUG - 2020-08-19 08:00:27 --> Total execution time: 0.0675
INFO - 2020-08-19 08:00:33 --> Config Class Initialized
INFO - 2020-08-19 08:00:33 --> Hooks Class Initialized
DEBUG - 2020-08-19 08:00:33 --> UTF-8 Support Enabled
INFO - 2020-08-19 08:00:33 --> Utf8 Class Initialized
INFO - 2020-08-19 08:00:33 --> URI Class Initialized
INFO - 2020-08-19 08:00:33 --> Router Class Initialized
INFO - 2020-08-19 08:00:33 --> Output Class Initialized
INFO - 2020-08-19 08:00:33 --> Security Class Initialized
DEBUG - 2020-08-19 08:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-19 08:00:33 --> Input Class Initialized
INFO - 2020-08-19 08:00:33 --> Language Class Initialized
INFO - 2020-08-19 08:00:33 --> Language Class Initialized
INFO - 2020-08-19 08:00:33 --> Config Class Initialized
INFO - 2020-08-19 08:00:33 --> Loader Class Initialized
INFO - 2020-08-19 08:00:33 --> Helper loaded: url_helper
INFO - 2020-08-19 08:00:33 --> Helper loaded: file_helper
INFO - 2020-08-19 08:00:33 --> Helper loaded: form_helper
INFO - 2020-08-19 08:00:33 --> Helper loaded: my_helper
INFO - 2020-08-19 08:00:33 --> Database Driver Class Initialized
DEBUG - 2020-08-19 08:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-19 08:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-19 08:00:33 --> Controller Class Initialized
