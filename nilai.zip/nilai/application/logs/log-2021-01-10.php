<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-10 03:52:27 --> Config Class Initialized
INFO - 2021-01-10 03:52:27 --> Hooks Class Initialized
DEBUG - 2021-01-10 03:52:27 --> UTF-8 Support Enabled
INFO - 2021-01-10 03:52:27 --> Utf8 Class Initialized
INFO - 2021-01-10 03:52:27 --> URI Class Initialized
DEBUG - 2021-01-10 03:52:27 --> No URI present. Default controller set.
INFO - 2021-01-10 03:52:27 --> Router Class Initialized
INFO - 2021-01-10 03:52:27 --> Output Class Initialized
INFO - 2021-01-10 03:52:27 --> Security Class Initialized
DEBUG - 2021-01-10 03:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 03:52:27 --> Input Class Initialized
INFO - 2021-01-10 03:52:27 --> Language Class Initialized
INFO - 2021-01-10 03:52:27 --> Language Class Initialized
INFO - 2021-01-10 03:52:27 --> Config Class Initialized
INFO - 2021-01-10 03:52:27 --> Loader Class Initialized
INFO - 2021-01-10 03:52:27 --> Helper loaded: url_helper
INFO - 2021-01-10 03:52:27 --> Helper loaded: file_helper
INFO - 2021-01-10 03:52:27 --> Helper loaded: form_helper
INFO - 2021-01-10 03:52:27 --> Helper loaded: my_helper
INFO - 2021-01-10 03:52:27 --> Database Driver Class Initialized
DEBUG - 2021-01-10 03:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 03:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 03:52:27 --> Controller Class Initialized
INFO - 2021-01-10 03:52:27 --> Config Class Initialized
INFO - 2021-01-10 03:52:27 --> Hooks Class Initialized
DEBUG - 2021-01-10 03:52:27 --> UTF-8 Support Enabled
INFO - 2021-01-10 03:52:27 --> Utf8 Class Initialized
INFO - 2021-01-10 03:52:27 --> URI Class Initialized
INFO - 2021-01-10 03:52:27 --> Router Class Initialized
INFO - 2021-01-10 03:52:27 --> Output Class Initialized
INFO - 2021-01-10 03:52:27 --> Security Class Initialized
DEBUG - 2021-01-10 03:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 03:52:27 --> Input Class Initialized
INFO - 2021-01-10 03:52:27 --> Language Class Initialized
INFO - 2021-01-10 03:52:27 --> Language Class Initialized
INFO - 2021-01-10 03:52:27 --> Config Class Initialized
INFO - 2021-01-10 03:52:27 --> Loader Class Initialized
INFO - 2021-01-10 03:52:27 --> Helper loaded: url_helper
INFO - 2021-01-10 03:52:27 --> Helper loaded: file_helper
INFO - 2021-01-10 03:52:27 --> Helper loaded: form_helper
INFO - 2021-01-10 03:52:27 --> Helper loaded: my_helper
INFO - 2021-01-10 03:52:27 --> Database Driver Class Initialized
DEBUG - 2021-01-10 03:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 03:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 03:52:27 --> Controller Class Initialized
DEBUG - 2021-01-10 03:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 03:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 03:52:27 --> Final output sent to browser
DEBUG - 2021-01-10 03:52:27 --> Total execution time: 0.2126
INFO - 2021-01-10 04:03:46 --> Config Class Initialized
INFO - 2021-01-10 04:03:46 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:03:46 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:03:46 --> Utf8 Class Initialized
INFO - 2021-01-10 04:03:46 --> URI Class Initialized
INFO - 2021-01-10 04:03:46 --> Router Class Initialized
INFO - 2021-01-10 04:03:46 --> Output Class Initialized
INFO - 2021-01-10 04:03:46 --> Security Class Initialized
DEBUG - 2021-01-10 04:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:03:46 --> Input Class Initialized
INFO - 2021-01-10 04:03:46 --> Language Class Initialized
INFO - 2021-01-10 04:03:46 --> Language Class Initialized
INFO - 2021-01-10 04:03:46 --> Config Class Initialized
INFO - 2021-01-10 04:03:46 --> Loader Class Initialized
INFO - 2021-01-10 04:03:46 --> Helper loaded: url_helper
INFO - 2021-01-10 04:03:46 --> Helper loaded: file_helper
INFO - 2021-01-10 04:03:46 --> Helper loaded: form_helper
ERROR - 2021-01-10 04:03:46 --> Severity: Parsing Error --> syntax error, unexpected '$b_max' (T_VARIABLE) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 30
INFO - 2021-01-10 04:03:47 --> Config Class Initialized
INFO - 2021-01-10 04:03:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:03:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:03:47 --> Utf8 Class Initialized
INFO - 2021-01-10 04:03:47 --> URI Class Initialized
INFO - 2021-01-10 04:03:47 --> Router Class Initialized
INFO - 2021-01-10 04:03:47 --> Output Class Initialized
INFO - 2021-01-10 04:03:47 --> Security Class Initialized
DEBUG - 2021-01-10 04:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:03:47 --> Input Class Initialized
INFO - 2021-01-10 04:03:47 --> Language Class Initialized
INFO - 2021-01-10 04:03:47 --> Language Class Initialized
INFO - 2021-01-10 04:03:47 --> Config Class Initialized
INFO - 2021-01-10 04:03:47 --> Loader Class Initialized
INFO - 2021-01-10 04:03:47 --> Helper loaded: url_helper
INFO - 2021-01-10 04:03:47 --> Helper loaded: file_helper
INFO - 2021-01-10 04:03:47 --> Helper loaded: form_helper
ERROR - 2021-01-10 04:03:47 --> Severity: Parsing Error --> syntax error, unexpected '$b_max' (T_VARIABLE) C:\xampp\htdocs\nilai\application\helpers\my_helper.php 30
INFO - 2021-01-10 04:04:41 --> Config Class Initialized
INFO - 2021-01-10 04:04:41 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:04:41 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:04:41 --> Utf8 Class Initialized
INFO - 2021-01-10 04:04:41 --> URI Class Initialized
INFO - 2021-01-10 04:04:41 --> Router Class Initialized
INFO - 2021-01-10 04:04:41 --> Output Class Initialized
INFO - 2021-01-10 04:04:41 --> Security Class Initialized
DEBUG - 2021-01-10 04:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:04:41 --> Input Class Initialized
INFO - 2021-01-10 04:04:41 --> Language Class Initialized
INFO - 2021-01-10 04:04:41 --> Language Class Initialized
INFO - 2021-01-10 04:04:41 --> Config Class Initialized
INFO - 2021-01-10 04:04:41 --> Loader Class Initialized
INFO - 2021-01-10 04:04:41 --> Helper loaded: url_helper
INFO - 2021-01-10 04:04:41 --> Helper loaded: file_helper
INFO - 2021-01-10 04:04:41 --> Helper loaded: form_helper
INFO - 2021-01-10 04:04:41 --> Helper loaded: my_helper
INFO - 2021-01-10 04:04:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:04:42 --> Controller Class Initialized
INFO - 2021-01-10 04:04:42 --> Config Class Initialized
INFO - 2021-01-10 04:04:42 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:04:42 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:04:42 --> Utf8 Class Initialized
INFO - 2021-01-10 04:04:42 --> URI Class Initialized
INFO - 2021-01-10 04:04:42 --> Router Class Initialized
INFO - 2021-01-10 04:04:42 --> Output Class Initialized
INFO - 2021-01-10 04:04:42 --> Security Class Initialized
DEBUG - 2021-01-10 04:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:04:42 --> Input Class Initialized
INFO - 2021-01-10 04:04:42 --> Language Class Initialized
INFO - 2021-01-10 04:04:42 --> Language Class Initialized
INFO - 2021-01-10 04:04:42 --> Config Class Initialized
INFO - 2021-01-10 04:04:42 --> Loader Class Initialized
INFO - 2021-01-10 04:04:42 --> Helper loaded: url_helper
INFO - 2021-01-10 04:04:42 --> Helper loaded: file_helper
INFO - 2021-01-10 04:04:42 --> Helper loaded: form_helper
INFO - 2021-01-10 04:04:42 --> Helper loaded: my_helper
INFO - 2021-01-10 04:04:42 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:04:42 --> Controller Class Initialized
DEBUG - 2021-01-10 04:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 04:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:04:42 --> Final output sent to browser
DEBUG - 2021-01-10 04:04:42 --> Total execution time: 0.5966
INFO - 2021-01-10 04:04:49 --> Config Class Initialized
INFO - 2021-01-10 04:04:49 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:04:49 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:04:49 --> Utf8 Class Initialized
INFO - 2021-01-10 04:04:49 --> URI Class Initialized
INFO - 2021-01-10 04:04:49 --> Router Class Initialized
INFO - 2021-01-10 04:04:49 --> Output Class Initialized
INFO - 2021-01-10 04:04:49 --> Security Class Initialized
DEBUG - 2021-01-10 04:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:04:49 --> Input Class Initialized
INFO - 2021-01-10 04:04:49 --> Language Class Initialized
INFO - 2021-01-10 04:04:49 --> Language Class Initialized
INFO - 2021-01-10 04:04:49 --> Config Class Initialized
INFO - 2021-01-10 04:04:49 --> Loader Class Initialized
INFO - 2021-01-10 04:04:49 --> Helper loaded: url_helper
INFO - 2021-01-10 04:04:49 --> Helper loaded: file_helper
INFO - 2021-01-10 04:04:49 --> Helper loaded: form_helper
INFO - 2021-01-10 04:04:49 --> Helper loaded: my_helper
INFO - 2021-01-10 04:04:49 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:04:49 --> Controller Class Initialized
INFO - 2021-01-10 04:04:50 --> Helper loaded: cookie_helper
INFO - 2021-01-10 04:04:50 --> Final output sent to browser
DEBUG - 2021-01-10 04:04:50 --> Total execution time: 0.7361
INFO - 2021-01-10 04:04:50 --> Config Class Initialized
INFO - 2021-01-10 04:04:50 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:04:50 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:04:50 --> Utf8 Class Initialized
INFO - 2021-01-10 04:04:50 --> URI Class Initialized
INFO - 2021-01-10 04:04:50 --> Router Class Initialized
INFO - 2021-01-10 04:04:50 --> Output Class Initialized
INFO - 2021-01-10 04:04:50 --> Security Class Initialized
DEBUG - 2021-01-10 04:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:04:50 --> Input Class Initialized
INFO - 2021-01-10 04:04:50 --> Language Class Initialized
INFO - 2021-01-10 04:04:50 --> Language Class Initialized
INFO - 2021-01-10 04:04:50 --> Config Class Initialized
INFO - 2021-01-10 04:04:50 --> Loader Class Initialized
INFO - 2021-01-10 04:04:50 --> Helper loaded: url_helper
INFO - 2021-01-10 04:04:50 --> Helper loaded: file_helper
INFO - 2021-01-10 04:04:50 --> Helper loaded: form_helper
INFO - 2021-01-10 04:04:50 --> Helper loaded: my_helper
INFO - 2021-01-10 04:04:50 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:04:51 --> Controller Class Initialized
DEBUG - 2021-01-10 04:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 04:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:04:51 --> Final output sent to browser
DEBUG - 2021-01-10 04:04:51 --> Total execution time: 0.5777
INFO - 2021-01-10 04:04:54 --> Config Class Initialized
INFO - 2021-01-10 04:04:54 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:04:54 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:04:54 --> Utf8 Class Initialized
INFO - 2021-01-10 04:04:54 --> URI Class Initialized
INFO - 2021-01-10 04:04:54 --> Router Class Initialized
INFO - 2021-01-10 04:04:54 --> Output Class Initialized
INFO - 2021-01-10 04:04:54 --> Security Class Initialized
DEBUG - 2021-01-10 04:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:04:54 --> Input Class Initialized
INFO - 2021-01-10 04:04:54 --> Language Class Initialized
INFO - 2021-01-10 04:04:54 --> Language Class Initialized
INFO - 2021-01-10 04:04:54 --> Config Class Initialized
INFO - 2021-01-10 04:04:54 --> Loader Class Initialized
INFO - 2021-01-10 04:04:54 --> Helper loaded: url_helper
INFO - 2021-01-10 04:04:54 --> Helper loaded: file_helper
INFO - 2021-01-10 04:04:54 --> Helper loaded: form_helper
INFO - 2021-01-10 04:04:54 --> Helper loaded: my_helper
INFO - 2021-01-10 04:04:54 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:04:54 --> Controller Class Initialized
DEBUG - 2021-01-10 04:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 04:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:04:54 --> Final output sent to browser
DEBUG - 2021-01-10 04:04:54 --> Total execution time: 0.6223
INFO - 2021-01-10 04:04:55 --> Config Class Initialized
INFO - 2021-01-10 04:04:55 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:04:55 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:04:55 --> Utf8 Class Initialized
INFO - 2021-01-10 04:04:55 --> URI Class Initialized
INFO - 2021-01-10 04:04:55 --> Router Class Initialized
INFO - 2021-01-10 04:04:56 --> Output Class Initialized
INFO - 2021-01-10 04:04:56 --> Security Class Initialized
DEBUG - 2021-01-10 04:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:04:56 --> Input Class Initialized
INFO - 2021-01-10 04:04:56 --> Language Class Initialized
INFO - 2021-01-10 04:04:56 --> Language Class Initialized
INFO - 2021-01-10 04:04:56 --> Config Class Initialized
INFO - 2021-01-10 04:04:56 --> Loader Class Initialized
INFO - 2021-01-10 04:04:56 --> Helper loaded: url_helper
INFO - 2021-01-10 04:04:56 --> Helper loaded: file_helper
INFO - 2021-01-10 04:04:56 --> Helper loaded: form_helper
INFO - 2021-01-10 04:04:56 --> Helper loaded: my_helper
INFO - 2021-01-10 04:04:56 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:04:56 --> Controller Class Initialized
DEBUG - 2021-01-10 04:04:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 04:04:56 --> Final output sent to browser
DEBUG - 2021-01-10 04:04:56 --> Total execution time: 0.6863
INFO - 2021-01-10 04:05:09 --> Config Class Initialized
INFO - 2021-01-10 04:05:09 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:09 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:09 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:09 --> URI Class Initialized
INFO - 2021-01-10 04:05:09 --> Router Class Initialized
INFO - 2021-01-10 04:05:09 --> Output Class Initialized
INFO - 2021-01-10 04:05:09 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:09 --> Input Class Initialized
INFO - 2021-01-10 04:05:09 --> Language Class Initialized
INFO - 2021-01-10 04:05:09 --> Language Class Initialized
INFO - 2021-01-10 04:05:09 --> Config Class Initialized
INFO - 2021-01-10 04:05:09 --> Loader Class Initialized
INFO - 2021-01-10 04:05:09 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:09 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:09 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:09 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:09 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:09 --> Controller Class Initialized
INFO - 2021-01-10 04:05:09 --> Helper loaded: cookie_helper
INFO - 2021-01-10 04:05:09 --> Config Class Initialized
INFO - 2021-01-10 04:05:09 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:09 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:09 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:09 --> URI Class Initialized
INFO - 2021-01-10 04:05:09 --> Router Class Initialized
INFO - 2021-01-10 04:05:09 --> Output Class Initialized
INFO - 2021-01-10 04:05:10 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:10 --> Input Class Initialized
INFO - 2021-01-10 04:05:10 --> Language Class Initialized
INFO - 2021-01-10 04:05:10 --> Language Class Initialized
INFO - 2021-01-10 04:05:10 --> Config Class Initialized
INFO - 2021-01-10 04:05:10 --> Loader Class Initialized
INFO - 2021-01-10 04:05:10 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:10 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:10 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:10 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:10 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:10 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 04:05:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:05:10 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:10 --> Total execution time: 0.7843
INFO - 2021-01-10 04:05:16 --> Config Class Initialized
INFO - 2021-01-10 04:05:16 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:16 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:16 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:16 --> URI Class Initialized
INFO - 2021-01-10 04:05:16 --> Router Class Initialized
INFO - 2021-01-10 04:05:16 --> Output Class Initialized
INFO - 2021-01-10 04:05:16 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:16 --> Input Class Initialized
INFO - 2021-01-10 04:05:16 --> Language Class Initialized
INFO - 2021-01-10 04:05:16 --> Language Class Initialized
INFO - 2021-01-10 04:05:16 --> Config Class Initialized
INFO - 2021-01-10 04:05:16 --> Loader Class Initialized
INFO - 2021-01-10 04:05:16 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:16 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:16 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:16 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:16 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:16 --> Controller Class Initialized
INFO - 2021-01-10 04:05:16 --> Helper loaded: cookie_helper
INFO - 2021-01-10 04:05:16 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:16 --> Total execution time: 0.8715
INFO - 2021-01-10 04:05:17 --> Config Class Initialized
INFO - 2021-01-10 04:05:17 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:17 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:17 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:17 --> URI Class Initialized
INFO - 2021-01-10 04:05:17 --> Router Class Initialized
INFO - 2021-01-10 04:05:17 --> Output Class Initialized
INFO - 2021-01-10 04:05:17 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:17 --> Input Class Initialized
INFO - 2021-01-10 04:05:17 --> Language Class Initialized
INFO - 2021-01-10 04:05:17 --> Language Class Initialized
INFO - 2021-01-10 04:05:17 --> Config Class Initialized
INFO - 2021-01-10 04:05:17 --> Loader Class Initialized
INFO - 2021-01-10 04:05:17 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:17 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:17 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:17 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:17 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:17 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 04:05:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:05:18 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:18 --> Total execution time: 0.6585
INFO - 2021-01-10 04:05:19 --> Config Class Initialized
INFO - 2021-01-10 04:05:19 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:19 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:19 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:19 --> URI Class Initialized
INFO - 2021-01-10 04:05:19 --> Router Class Initialized
INFO - 2021-01-10 04:05:19 --> Output Class Initialized
INFO - 2021-01-10 04:05:19 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:19 --> Input Class Initialized
INFO - 2021-01-10 04:05:19 --> Language Class Initialized
INFO - 2021-01-10 04:05:19 --> Language Class Initialized
INFO - 2021-01-10 04:05:19 --> Config Class Initialized
INFO - 2021-01-10 04:05:19 --> Loader Class Initialized
INFO - 2021-01-10 04:05:19 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:19 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:19 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:20 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:20 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:20 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 04:05:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:05:20 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:20 --> Total execution time: 0.5982
INFO - 2021-01-10 04:05:21 --> Config Class Initialized
INFO - 2021-01-10 04:05:21 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:21 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:21 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:21 --> URI Class Initialized
INFO - 2021-01-10 04:05:21 --> Router Class Initialized
INFO - 2021-01-10 04:05:21 --> Output Class Initialized
INFO - 2021-01-10 04:05:21 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:22 --> Input Class Initialized
INFO - 2021-01-10 04:05:22 --> Language Class Initialized
INFO - 2021-01-10 04:05:22 --> Language Class Initialized
INFO - 2021-01-10 04:05:22 --> Config Class Initialized
INFO - 2021-01-10 04:05:22 --> Loader Class Initialized
INFO - 2021-01-10 04:05:22 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:22 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:22 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:22 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:22 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:22 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-10 04:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:05:22 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:22 --> Total execution time: 0.6656
INFO - 2021-01-10 04:05:22 --> Config Class Initialized
INFO - 2021-01-10 04:05:22 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:22 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:22 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:22 --> URI Class Initialized
INFO - 2021-01-10 04:05:22 --> Router Class Initialized
INFO - 2021-01-10 04:05:22 --> Output Class Initialized
INFO - 2021-01-10 04:05:22 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:22 --> Input Class Initialized
INFO - 2021-01-10 04:05:22 --> Language Class Initialized
INFO - 2021-01-10 04:05:22 --> Language Class Initialized
INFO - 2021-01-10 04:05:22 --> Config Class Initialized
INFO - 2021-01-10 04:05:23 --> Loader Class Initialized
INFO - 2021-01-10 04:05:23 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:23 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:23 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:23 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:23 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:23 --> Controller Class Initialized
INFO - 2021-01-10 04:05:23 --> Config Class Initialized
INFO - 2021-01-10 04:05:23 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:23 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:23 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:23 --> URI Class Initialized
INFO - 2021-01-10 04:05:23 --> Router Class Initialized
INFO - 2021-01-10 04:05:23 --> Output Class Initialized
INFO - 2021-01-10 04:05:23 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:23 --> Input Class Initialized
INFO - 2021-01-10 04:05:24 --> Language Class Initialized
INFO - 2021-01-10 04:05:24 --> Language Class Initialized
INFO - 2021-01-10 04:05:24 --> Config Class Initialized
INFO - 2021-01-10 04:05:24 --> Loader Class Initialized
INFO - 2021-01-10 04:05:24 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:24 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:24 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:24 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:24 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:24 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-10 04:05:24 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:24 --> Total execution time: 0.5224
INFO - 2021-01-10 04:05:25 --> Config Class Initialized
INFO - 2021-01-10 04:05:25 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:25 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:25 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:25 --> URI Class Initialized
INFO - 2021-01-10 04:05:25 --> Router Class Initialized
INFO - 2021-01-10 04:05:25 --> Output Class Initialized
INFO - 2021-01-10 04:05:25 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:25 --> Input Class Initialized
INFO - 2021-01-10 04:05:25 --> Language Class Initialized
INFO - 2021-01-10 04:05:25 --> Language Class Initialized
INFO - 2021-01-10 04:05:25 --> Config Class Initialized
INFO - 2021-01-10 04:05:25 --> Loader Class Initialized
INFO - 2021-01-10 04:05:25 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:25 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:25 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:25 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:25 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:25 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 04:05:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:05:25 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:25 --> Total execution time: 0.6904
INFO - 2021-01-10 04:05:26 --> Config Class Initialized
INFO - 2021-01-10 04:05:26 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:26 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:26 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:26 --> URI Class Initialized
INFO - 2021-01-10 04:05:26 --> Router Class Initialized
INFO - 2021-01-10 04:05:26 --> Output Class Initialized
INFO - 2021-01-10 04:05:26 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:27 --> Input Class Initialized
INFO - 2021-01-10 04:05:27 --> Language Class Initialized
INFO - 2021-01-10 04:05:27 --> Language Class Initialized
INFO - 2021-01-10 04:05:27 --> Config Class Initialized
INFO - 2021-01-10 04:05:27 --> Loader Class Initialized
INFO - 2021-01-10 04:05:27 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:27 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:27 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:27 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:27 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:27 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-10 04:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 04:05:27 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:27 --> Total execution time: 0.7165
INFO - 2021-01-10 04:05:28 --> Config Class Initialized
INFO - 2021-01-10 04:05:28 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:05:28 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:05:28 --> Utf8 Class Initialized
INFO - 2021-01-10 04:05:28 --> URI Class Initialized
INFO - 2021-01-10 04:05:28 --> Router Class Initialized
INFO - 2021-01-10 04:05:28 --> Output Class Initialized
INFO - 2021-01-10 04:05:28 --> Security Class Initialized
DEBUG - 2021-01-10 04:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:05:28 --> Input Class Initialized
INFO - 2021-01-10 04:05:28 --> Language Class Initialized
INFO - 2021-01-10 04:05:28 --> Language Class Initialized
INFO - 2021-01-10 04:05:28 --> Config Class Initialized
INFO - 2021-01-10 04:05:28 --> Loader Class Initialized
INFO - 2021-01-10 04:05:28 --> Helper loaded: url_helper
INFO - 2021-01-10 04:05:28 --> Helper loaded: file_helper
INFO - 2021-01-10 04:05:28 --> Helper loaded: form_helper
INFO - 2021-01-10 04:05:28 --> Helper loaded: my_helper
INFO - 2021-01-10 04:05:28 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:05:28 --> Controller Class Initialized
DEBUG - 2021-01-10 04:05:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-10 04:05:29 --> Final output sent to browser
DEBUG - 2021-01-10 04:05:29 --> Total execution time: 0.5619
INFO - 2021-01-10 04:28:00 --> Config Class Initialized
INFO - 2021-01-10 04:28:00 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:28:00 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:28:00 --> Utf8 Class Initialized
INFO - 2021-01-10 04:28:00 --> URI Class Initialized
INFO - 2021-01-10 04:28:00 --> Router Class Initialized
INFO - 2021-01-10 04:28:00 --> Output Class Initialized
INFO - 2021-01-10 04:28:00 --> Security Class Initialized
DEBUG - 2021-01-10 04:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:28:00 --> Input Class Initialized
INFO - 2021-01-10 04:28:00 --> Language Class Initialized
INFO - 2021-01-10 04:28:00 --> Language Class Initialized
INFO - 2021-01-10 04:28:00 --> Config Class Initialized
INFO - 2021-01-10 04:28:01 --> Loader Class Initialized
INFO - 2021-01-10 04:28:01 --> Helper loaded: url_helper
INFO - 2021-01-10 04:28:01 --> Helper loaded: file_helper
INFO - 2021-01-10 04:28:01 --> Helper loaded: form_helper
INFO - 2021-01-10 04:28:01 --> Helper loaded: my_helper
INFO - 2021-01-10 04:28:01 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:28:01 --> Controller Class Initialized
DEBUG - 2021-01-10 04:28:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 04:28:01 --> Final output sent to browser
DEBUG - 2021-01-10 04:28:01 --> Total execution time: 0.8528
INFO - 2021-01-10 04:28:40 --> Config Class Initialized
INFO - 2021-01-10 04:28:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 04:28:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 04:28:40 --> Utf8 Class Initialized
INFO - 2021-01-10 04:28:40 --> URI Class Initialized
INFO - 2021-01-10 04:28:40 --> Router Class Initialized
INFO - 2021-01-10 04:28:40 --> Output Class Initialized
INFO - 2021-01-10 04:28:40 --> Security Class Initialized
DEBUG - 2021-01-10 04:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 04:28:40 --> Input Class Initialized
INFO - 2021-01-10 04:28:40 --> Language Class Initialized
INFO - 2021-01-10 04:28:40 --> Language Class Initialized
INFO - 2021-01-10 04:28:40 --> Config Class Initialized
INFO - 2021-01-10 04:28:40 --> Loader Class Initialized
INFO - 2021-01-10 04:28:40 --> Helper loaded: url_helper
INFO - 2021-01-10 04:28:40 --> Helper loaded: file_helper
INFO - 2021-01-10 04:28:41 --> Helper loaded: form_helper
INFO - 2021-01-10 04:28:41 --> Helper loaded: my_helper
INFO - 2021-01-10 04:28:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 04:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 04:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 04:28:41 --> Controller Class Initialized
DEBUG - 2021-01-10 04:28:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 04:28:41 --> Final output sent to browser
DEBUG - 2021-01-10 04:28:41 --> Total execution time: 0.9122
INFO - 2021-01-10 12:07:53 --> Config Class Initialized
INFO - 2021-01-10 12:07:53 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:07:53 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:07:53 --> Utf8 Class Initialized
INFO - 2021-01-10 12:07:53 --> URI Class Initialized
DEBUG - 2021-01-10 12:07:53 --> No URI present. Default controller set.
INFO - 2021-01-10 12:07:53 --> Router Class Initialized
INFO - 2021-01-10 12:07:53 --> Output Class Initialized
INFO - 2021-01-10 12:07:53 --> Security Class Initialized
DEBUG - 2021-01-10 12:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:07:53 --> Input Class Initialized
INFO - 2021-01-10 12:07:53 --> Language Class Initialized
INFO - 2021-01-10 12:07:53 --> Language Class Initialized
INFO - 2021-01-10 12:07:53 --> Config Class Initialized
INFO - 2021-01-10 12:07:53 --> Loader Class Initialized
INFO - 2021-01-10 12:07:53 --> Helper loaded: url_helper
INFO - 2021-01-10 12:07:53 --> Helper loaded: file_helper
INFO - 2021-01-10 12:07:53 --> Helper loaded: form_helper
INFO - 2021-01-10 12:07:53 --> Helper loaded: my_helper
INFO - 2021-01-10 12:07:53 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:07:53 --> Controller Class Initialized
INFO - 2021-01-10 12:07:53 --> Config Class Initialized
INFO - 2021-01-10 12:07:53 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:07:53 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:07:53 --> Utf8 Class Initialized
INFO - 2021-01-10 12:07:53 --> URI Class Initialized
INFO - 2021-01-10 12:07:53 --> Router Class Initialized
INFO - 2021-01-10 12:07:53 --> Output Class Initialized
INFO - 2021-01-10 12:07:53 --> Security Class Initialized
DEBUG - 2021-01-10 12:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:07:53 --> Input Class Initialized
INFO - 2021-01-10 12:07:53 --> Language Class Initialized
INFO - 2021-01-10 12:07:53 --> Language Class Initialized
INFO - 2021-01-10 12:07:53 --> Config Class Initialized
INFO - 2021-01-10 12:07:53 --> Loader Class Initialized
INFO - 2021-01-10 12:07:53 --> Helper loaded: url_helper
INFO - 2021-01-10 12:07:53 --> Helper loaded: file_helper
INFO - 2021-01-10 12:07:53 --> Helper loaded: form_helper
INFO - 2021-01-10 12:07:53 --> Helper loaded: my_helper
INFO - 2021-01-10 12:07:53 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:07:53 --> Controller Class Initialized
DEBUG - 2021-01-10 12:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 12:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:07:53 --> Final output sent to browser
DEBUG - 2021-01-10 12:07:53 --> Total execution time: 0.2508
INFO - 2021-01-10 12:08:59 --> Config Class Initialized
INFO - 2021-01-10 12:08:59 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:08:59 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:08:59 --> Utf8 Class Initialized
INFO - 2021-01-10 12:08:59 --> URI Class Initialized
INFO - 2021-01-10 12:08:59 --> Router Class Initialized
INFO - 2021-01-10 12:08:59 --> Output Class Initialized
INFO - 2021-01-10 12:08:59 --> Security Class Initialized
DEBUG - 2021-01-10 12:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:08:59 --> Input Class Initialized
INFO - 2021-01-10 12:08:59 --> Language Class Initialized
INFO - 2021-01-10 12:08:59 --> Language Class Initialized
INFO - 2021-01-10 12:08:59 --> Config Class Initialized
INFO - 2021-01-10 12:08:59 --> Loader Class Initialized
INFO - 2021-01-10 12:08:59 --> Helper loaded: url_helper
INFO - 2021-01-10 12:08:59 --> Helper loaded: file_helper
INFO - 2021-01-10 12:08:59 --> Helper loaded: form_helper
INFO - 2021-01-10 12:08:59 --> Helper loaded: my_helper
INFO - 2021-01-10 12:08:59 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:08:59 --> Controller Class Initialized
INFO - 2021-01-10 12:08:59 --> Helper loaded: cookie_helper
INFO - 2021-01-10 12:08:59 --> Final output sent to browser
DEBUG - 2021-01-10 12:08:59 --> Total execution time: 0.7248
INFO - 2021-01-10 12:09:00 --> Config Class Initialized
INFO - 2021-01-10 12:09:00 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:00 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:00 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:00 --> URI Class Initialized
INFO - 2021-01-10 12:09:00 --> Router Class Initialized
INFO - 2021-01-10 12:09:00 --> Output Class Initialized
INFO - 2021-01-10 12:09:00 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:00 --> Input Class Initialized
INFO - 2021-01-10 12:09:00 --> Language Class Initialized
INFO - 2021-01-10 12:09:00 --> Language Class Initialized
INFO - 2021-01-10 12:09:00 --> Config Class Initialized
INFO - 2021-01-10 12:09:00 --> Loader Class Initialized
INFO - 2021-01-10 12:09:00 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:00 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:00 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:00 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:00 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:00 --> Controller Class Initialized
DEBUG - 2021-01-10 12:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 12:09:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:09:01 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:01 --> Total execution time: 0.8492
INFO - 2021-01-10 12:09:03 --> Config Class Initialized
INFO - 2021-01-10 12:09:03 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:03 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:03 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:03 --> URI Class Initialized
INFO - 2021-01-10 12:09:03 --> Router Class Initialized
INFO - 2021-01-10 12:09:03 --> Output Class Initialized
INFO - 2021-01-10 12:09:03 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:03 --> Input Class Initialized
INFO - 2021-01-10 12:09:03 --> Language Class Initialized
INFO - 2021-01-10 12:09:03 --> Language Class Initialized
INFO - 2021-01-10 12:09:03 --> Config Class Initialized
INFO - 2021-01-10 12:09:03 --> Loader Class Initialized
INFO - 2021-01-10 12:09:03 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:03 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:03 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:03 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:03 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:03 --> Controller Class Initialized
DEBUG - 2021-01-10 12:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 12:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:09:03 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:04 --> Total execution time: 0.9341
INFO - 2021-01-10 12:09:05 --> Config Class Initialized
INFO - 2021-01-10 12:09:05 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:05 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:05 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:05 --> URI Class Initialized
INFO - 2021-01-10 12:09:05 --> Router Class Initialized
INFO - 2021-01-10 12:09:05 --> Output Class Initialized
INFO - 2021-01-10 12:09:05 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:05 --> Input Class Initialized
INFO - 2021-01-10 12:09:05 --> Language Class Initialized
INFO - 2021-01-10 12:09:05 --> Language Class Initialized
INFO - 2021-01-10 12:09:05 --> Config Class Initialized
INFO - 2021-01-10 12:09:06 --> Loader Class Initialized
INFO - 2021-01-10 12:09:06 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:06 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:06 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:06 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:06 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:06 --> Controller Class Initialized
DEBUG - 2021-01-10 12:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 12:09:06 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:06 --> Total execution time: 0.7499
INFO - 2021-01-10 12:09:19 --> Config Class Initialized
INFO - 2021-01-10 12:09:19 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:19 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:19 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:19 --> URI Class Initialized
INFO - 2021-01-10 12:09:19 --> Router Class Initialized
INFO - 2021-01-10 12:09:19 --> Output Class Initialized
INFO - 2021-01-10 12:09:19 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:19 --> Input Class Initialized
INFO - 2021-01-10 12:09:20 --> Language Class Initialized
INFO - 2021-01-10 12:09:20 --> Language Class Initialized
INFO - 2021-01-10 12:09:20 --> Config Class Initialized
INFO - 2021-01-10 12:09:20 --> Loader Class Initialized
INFO - 2021-01-10 12:09:20 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:20 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:20 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:20 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:20 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:20 --> Controller Class Initialized
INFO - 2021-01-10 12:09:20 --> Helper loaded: cookie_helper
INFO - 2021-01-10 12:09:20 --> Config Class Initialized
INFO - 2021-01-10 12:09:20 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:20 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:20 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:20 --> URI Class Initialized
INFO - 2021-01-10 12:09:20 --> Router Class Initialized
INFO - 2021-01-10 12:09:20 --> Output Class Initialized
INFO - 2021-01-10 12:09:20 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:20 --> Input Class Initialized
INFO - 2021-01-10 12:09:20 --> Language Class Initialized
INFO - 2021-01-10 12:09:20 --> Language Class Initialized
INFO - 2021-01-10 12:09:20 --> Config Class Initialized
INFO - 2021-01-10 12:09:20 --> Loader Class Initialized
INFO - 2021-01-10 12:09:20 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:20 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:20 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:20 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:20 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:21 --> Controller Class Initialized
DEBUG - 2021-01-10 12:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 12:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:09:21 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:21 --> Total execution time: 0.6872
INFO - 2021-01-10 12:09:39 --> Config Class Initialized
INFO - 2021-01-10 12:09:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:39 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:39 --> URI Class Initialized
INFO - 2021-01-10 12:09:39 --> Router Class Initialized
INFO - 2021-01-10 12:09:39 --> Output Class Initialized
INFO - 2021-01-10 12:09:39 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:39 --> Input Class Initialized
INFO - 2021-01-10 12:09:39 --> Language Class Initialized
INFO - 2021-01-10 12:09:39 --> Language Class Initialized
INFO - 2021-01-10 12:09:39 --> Config Class Initialized
INFO - 2021-01-10 12:09:39 --> Loader Class Initialized
INFO - 2021-01-10 12:09:39 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:39 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:39 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:39 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:39 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:39 --> Controller Class Initialized
INFO - 2021-01-10 12:09:39 --> Helper loaded: cookie_helper
INFO - 2021-01-10 12:09:39 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:40 --> Total execution time: 0.8055
INFO - 2021-01-10 12:09:40 --> Config Class Initialized
INFO - 2021-01-10 12:09:41 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:41 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:41 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:41 --> URI Class Initialized
INFO - 2021-01-10 12:09:41 --> Router Class Initialized
INFO - 2021-01-10 12:09:41 --> Output Class Initialized
INFO - 2021-01-10 12:09:41 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:41 --> Input Class Initialized
INFO - 2021-01-10 12:09:41 --> Language Class Initialized
INFO - 2021-01-10 12:09:41 --> Language Class Initialized
INFO - 2021-01-10 12:09:41 --> Config Class Initialized
INFO - 2021-01-10 12:09:41 --> Loader Class Initialized
INFO - 2021-01-10 12:09:41 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:41 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:41 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:41 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:41 --> Controller Class Initialized
DEBUG - 2021-01-10 12:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 12:09:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:09:41 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:41 --> Total execution time: 0.7813
INFO - 2021-01-10 12:09:51 --> Config Class Initialized
INFO - 2021-01-10 12:09:51 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:51 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:51 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:51 --> URI Class Initialized
INFO - 2021-01-10 12:09:51 --> Router Class Initialized
INFO - 2021-01-10 12:09:51 --> Output Class Initialized
INFO - 2021-01-10 12:09:52 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:52 --> Input Class Initialized
INFO - 2021-01-10 12:09:52 --> Language Class Initialized
INFO - 2021-01-10 12:09:52 --> Language Class Initialized
INFO - 2021-01-10 12:09:52 --> Config Class Initialized
INFO - 2021-01-10 12:09:52 --> Loader Class Initialized
INFO - 2021-01-10 12:09:52 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:52 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:52 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:52 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:52 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:52 --> Controller Class Initialized
DEBUG - 2021-01-10 12:09:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-01-10 12:09:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:09:52 --> Final output sent to browser
DEBUG - 2021-01-10 12:09:52 --> Total execution time: 0.9529
INFO - 2021-01-10 12:09:53 --> Config Class Initialized
INFO - 2021-01-10 12:09:53 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:09:53 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:09:53 --> Utf8 Class Initialized
INFO - 2021-01-10 12:09:53 --> URI Class Initialized
INFO - 2021-01-10 12:09:53 --> Router Class Initialized
INFO - 2021-01-10 12:09:53 --> Output Class Initialized
INFO - 2021-01-10 12:09:53 --> Security Class Initialized
DEBUG - 2021-01-10 12:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:09:53 --> Input Class Initialized
INFO - 2021-01-10 12:09:53 --> Language Class Initialized
INFO - 2021-01-10 12:09:53 --> Language Class Initialized
INFO - 2021-01-10 12:09:53 --> Config Class Initialized
INFO - 2021-01-10 12:09:53 --> Loader Class Initialized
INFO - 2021-01-10 12:09:53 --> Helper loaded: url_helper
INFO - 2021-01-10 12:09:53 --> Helper loaded: file_helper
INFO - 2021-01-10 12:09:53 --> Helper loaded: form_helper
INFO - 2021-01-10 12:09:53 --> Helper loaded: my_helper
INFO - 2021-01-10 12:09:53 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:09:53 --> Controller Class Initialized
INFO - 2021-01-10 12:13:13 --> Config Class Initialized
INFO - 2021-01-10 12:13:13 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:13:13 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:13:13 --> Utf8 Class Initialized
INFO - 2021-01-10 12:13:13 --> URI Class Initialized
INFO - 2021-01-10 12:13:13 --> Router Class Initialized
INFO - 2021-01-10 12:13:13 --> Output Class Initialized
INFO - 2021-01-10 12:13:13 --> Security Class Initialized
DEBUG - 2021-01-10 12:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:13:13 --> Input Class Initialized
INFO - 2021-01-10 12:13:13 --> Language Class Initialized
INFO - 2021-01-10 12:13:14 --> Language Class Initialized
INFO - 2021-01-10 12:13:14 --> Config Class Initialized
INFO - 2021-01-10 12:13:14 --> Loader Class Initialized
INFO - 2021-01-10 12:13:14 --> Helper loaded: url_helper
INFO - 2021-01-10 12:13:14 --> Helper loaded: file_helper
INFO - 2021-01-10 12:13:14 --> Helper loaded: form_helper
INFO - 2021-01-10 12:13:14 --> Helper loaded: my_helper
INFO - 2021-01-10 12:13:14 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:13:14 --> Controller Class Initialized
DEBUG - 2021-01-10 12:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-01-10 12:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:13:14 --> Final output sent to browser
DEBUG - 2021-01-10 12:13:14 --> Total execution time: 0.6116
INFO - 2021-01-10 12:13:14 --> Config Class Initialized
INFO - 2021-01-10 12:13:14 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:13:14 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:13:14 --> Utf8 Class Initialized
INFO - 2021-01-10 12:13:14 --> URI Class Initialized
INFO - 2021-01-10 12:13:14 --> Router Class Initialized
INFO - 2021-01-10 12:13:14 --> Output Class Initialized
INFO - 2021-01-10 12:13:14 --> Security Class Initialized
DEBUG - 2021-01-10 12:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:13:14 --> Input Class Initialized
INFO - 2021-01-10 12:13:14 --> Language Class Initialized
INFO - 2021-01-10 12:13:14 --> Language Class Initialized
INFO - 2021-01-10 12:13:14 --> Config Class Initialized
INFO - 2021-01-10 12:13:14 --> Loader Class Initialized
INFO - 2021-01-10 12:13:14 --> Helper loaded: url_helper
INFO - 2021-01-10 12:13:14 --> Helper loaded: file_helper
INFO - 2021-01-10 12:13:14 --> Helper loaded: form_helper
INFO - 2021-01-10 12:13:14 --> Helper loaded: my_helper
INFO - 2021-01-10 12:13:15 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:13:15 --> Controller Class Initialized
INFO - 2021-01-10 12:13:16 --> Config Class Initialized
INFO - 2021-01-10 12:13:16 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:13:16 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:13:16 --> Utf8 Class Initialized
INFO - 2021-01-10 12:13:16 --> URI Class Initialized
INFO - 2021-01-10 12:13:16 --> Router Class Initialized
INFO - 2021-01-10 12:13:16 --> Output Class Initialized
INFO - 2021-01-10 12:13:16 --> Security Class Initialized
DEBUG - 2021-01-10 12:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:13:16 --> Input Class Initialized
INFO - 2021-01-10 12:13:16 --> Language Class Initialized
INFO - 2021-01-10 12:13:16 --> Language Class Initialized
INFO - 2021-01-10 12:13:16 --> Config Class Initialized
INFO - 2021-01-10 12:13:16 --> Loader Class Initialized
INFO - 2021-01-10 12:13:16 --> Helper loaded: url_helper
INFO - 2021-01-10 12:13:16 --> Helper loaded: file_helper
INFO - 2021-01-10 12:13:16 --> Helper loaded: form_helper
INFO - 2021-01-10 12:13:16 --> Helper loaded: my_helper
INFO - 2021-01-10 12:13:16 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:13:16 --> Controller Class Initialized
INFO - 2021-01-10 12:13:16 --> Final output sent to browser
DEBUG - 2021-01-10 12:13:16 --> Total execution time: 0.4773
INFO - 2021-01-10 12:13:35 --> Config Class Initialized
INFO - 2021-01-10 12:13:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:13:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:13:35 --> Utf8 Class Initialized
INFO - 2021-01-10 12:13:35 --> URI Class Initialized
INFO - 2021-01-10 12:13:35 --> Router Class Initialized
INFO - 2021-01-10 12:13:35 --> Output Class Initialized
INFO - 2021-01-10 12:13:35 --> Security Class Initialized
DEBUG - 2021-01-10 12:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:13:35 --> Input Class Initialized
INFO - 2021-01-10 12:13:35 --> Language Class Initialized
INFO - 2021-01-10 12:13:35 --> Language Class Initialized
INFO - 2021-01-10 12:13:35 --> Config Class Initialized
INFO - 2021-01-10 12:13:35 --> Loader Class Initialized
INFO - 2021-01-10 12:13:35 --> Helper loaded: url_helper
INFO - 2021-01-10 12:13:35 --> Helper loaded: file_helper
INFO - 2021-01-10 12:13:35 --> Helper loaded: form_helper
INFO - 2021-01-10 12:13:35 --> Helper loaded: my_helper
INFO - 2021-01-10 12:13:36 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:13:36 --> Controller Class Initialized
INFO - 2021-01-10 12:13:36 --> Final output sent to browser
DEBUG - 2021-01-10 12:13:36 --> Total execution time: 0.6800
INFO - 2021-01-10 12:30:34 --> Config Class Initialized
INFO - 2021-01-10 12:30:34 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:30:34 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:30:34 --> Utf8 Class Initialized
INFO - 2021-01-10 12:30:34 --> URI Class Initialized
INFO - 2021-01-10 12:30:34 --> Router Class Initialized
INFO - 2021-01-10 12:30:34 --> Output Class Initialized
INFO - 2021-01-10 12:30:34 --> Security Class Initialized
DEBUG - 2021-01-10 12:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:30:34 --> Input Class Initialized
INFO - 2021-01-10 12:30:34 --> Language Class Initialized
INFO - 2021-01-10 12:30:34 --> Language Class Initialized
INFO - 2021-01-10 12:30:35 --> Config Class Initialized
INFO - 2021-01-10 12:30:35 --> Loader Class Initialized
INFO - 2021-01-10 12:30:35 --> Helper loaded: url_helper
INFO - 2021-01-10 12:30:35 --> Helper loaded: file_helper
INFO - 2021-01-10 12:30:35 --> Helper loaded: form_helper
INFO - 2021-01-10 12:30:35 --> Helper loaded: my_helper
INFO - 2021-01-10 12:30:35 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:30:35 --> Controller Class Initialized
DEBUG - 2021-01-10 12:30:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-01-10 12:30:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:30:35 --> Final output sent to browser
DEBUG - 2021-01-10 12:30:35 --> Total execution time: 0.5825
INFO - 2021-01-10 12:30:35 --> Config Class Initialized
INFO - 2021-01-10 12:30:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:30:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:30:35 --> Utf8 Class Initialized
INFO - 2021-01-10 12:30:35 --> URI Class Initialized
INFO - 2021-01-10 12:30:35 --> Router Class Initialized
INFO - 2021-01-10 12:30:35 --> Output Class Initialized
INFO - 2021-01-10 12:30:35 --> Security Class Initialized
DEBUG - 2021-01-10 12:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:30:35 --> Input Class Initialized
INFO - 2021-01-10 12:30:35 --> Language Class Initialized
INFO - 2021-01-10 12:30:35 --> Language Class Initialized
INFO - 2021-01-10 12:30:35 --> Config Class Initialized
INFO - 2021-01-10 12:30:35 --> Loader Class Initialized
INFO - 2021-01-10 12:30:35 --> Helper loaded: url_helper
INFO - 2021-01-10 12:30:35 --> Helper loaded: file_helper
INFO - 2021-01-10 12:30:35 --> Helper loaded: form_helper
INFO - 2021-01-10 12:30:35 --> Helper loaded: my_helper
INFO - 2021-01-10 12:30:36 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:30:36 --> Controller Class Initialized
INFO - 2021-01-10 12:30:39 --> Config Class Initialized
INFO - 2021-01-10 12:30:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:30:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:30:39 --> Utf8 Class Initialized
INFO - 2021-01-10 12:30:39 --> URI Class Initialized
INFO - 2021-01-10 12:30:39 --> Router Class Initialized
INFO - 2021-01-10 12:30:39 --> Output Class Initialized
INFO - 2021-01-10 12:30:39 --> Security Class Initialized
DEBUG - 2021-01-10 12:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:30:39 --> Input Class Initialized
INFO - 2021-01-10 12:30:39 --> Language Class Initialized
INFO - 2021-01-10 12:30:39 --> Language Class Initialized
INFO - 2021-01-10 12:30:39 --> Config Class Initialized
INFO - 2021-01-10 12:30:39 --> Loader Class Initialized
INFO - 2021-01-10 12:30:39 --> Helper loaded: url_helper
INFO - 2021-01-10 12:30:39 --> Helper loaded: file_helper
INFO - 2021-01-10 12:30:39 --> Helper loaded: form_helper
INFO - 2021-01-10 12:30:39 --> Helper loaded: my_helper
INFO - 2021-01-10 12:30:39 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:30:39 --> Controller Class Initialized
INFO - 2021-01-10 12:30:39 --> Final output sent to browser
DEBUG - 2021-01-10 12:30:39 --> Total execution time: 0.4836
INFO - 2021-01-10 12:31:39 --> Config Class Initialized
INFO - 2021-01-10 12:31:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:31:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:31:39 --> Utf8 Class Initialized
INFO - 2021-01-10 12:31:39 --> URI Class Initialized
INFO - 2021-01-10 12:31:39 --> Router Class Initialized
INFO - 2021-01-10 12:31:39 --> Output Class Initialized
INFO - 2021-01-10 12:31:39 --> Security Class Initialized
DEBUG - 2021-01-10 12:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:31:39 --> Input Class Initialized
INFO - 2021-01-10 12:31:39 --> Language Class Initialized
INFO - 2021-01-10 12:31:39 --> Language Class Initialized
INFO - 2021-01-10 12:31:40 --> Config Class Initialized
INFO - 2021-01-10 12:31:40 --> Loader Class Initialized
INFO - 2021-01-10 12:31:40 --> Helper loaded: url_helper
INFO - 2021-01-10 12:31:40 --> Helper loaded: file_helper
INFO - 2021-01-10 12:31:40 --> Helper loaded: form_helper
INFO - 2021-01-10 12:31:40 --> Helper loaded: my_helper
INFO - 2021-01-10 12:31:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:31:40 --> Controller Class Initialized
INFO - 2021-01-10 12:31:40 --> Final output sent to browser
DEBUG - 2021-01-10 12:31:40 --> Total execution time: 0.7147
INFO - 2021-01-10 12:32:12 --> Config Class Initialized
INFO - 2021-01-10 12:32:12 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:32:12 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:32:12 --> Utf8 Class Initialized
INFO - 2021-01-10 12:32:12 --> URI Class Initialized
INFO - 2021-01-10 12:32:12 --> Router Class Initialized
INFO - 2021-01-10 12:32:12 --> Output Class Initialized
INFO - 2021-01-10 12:32:12 --> Security Class Initialized
DEBUG - 2021-01-10 12:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:32:12 --> Input Class Initialized
INFO - 2021-01-10 12:32:12 --> Language Class Initialized
INFO - 2021-01-10 12:32:12 --> Language Class Initialized
INFO - 2021-01-10 12:32:12 --> Config Class Initialized
INFO - 2021-01-10 12:32:12 --> Loader Class Initialized
INFO - 2021-01-10 12:32:13 --> Helper loaded: url_helper
INFO - 2021-01-10 12:32:13 --> Helper loaded: file_helper
INFO - 2021-01-10 12:32:13 --> Helper loaded: form_helper
INFO - 2021-01-10 12:32:13 --> Helper loaded: my_helper
INFO - 2021-01-10 12:32:13 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:32:13 --> Controller Class Initialized
DEBUG - 2021-01-10 12:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-10 12:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:32:13 --> Final output sent to browser
DEBUG - 2021-01-10 12:32:13 --> Total execution time: 1.0449
INFO - 2021-01-10 12:32:13 --> Config Class Initialized
INFO - 2021-01-10 12:32:13 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:32:14 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:32:14 --> Utf8 Class Initialized
INFO - 2021-01-10 12:32:14 --> URI Class Initialized
INFO - 2021-01-10 12:32:14 --> Router Class Initialized
INFO - 2021-01-10 12:32:14 --> Output Class Initialized
INFO - 2021-01-10 12:32:14 --> Security Class Initialized
DEBUG - 2021-01-10 12:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:32:14 --> Input Class Initialized
INFO - 2021-01-10 12:32:14 --> Language Class Initialized
INFO - 2021-01-10 12:32:14 --> Language Class Initialized
INFO - 2021-01-10 12:32:14 --> Config Class Initialized
INFO - 2021-01-10 12:32:14 --> Loader Class Initialized
INFO - 2021-01-10 12:32:14 --> Helper loaded: url_helper
INFO - 2021-01-10 12:32:14 --> Helper loaded: file_helper
INFO - 2021-01-10 12:32:14 --> Helper loaded: form_helper
INFO - 2021-01-10 12:32:14 --> Helper loaded: my_helper
INFO - 2021-01-10 12:32:14 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:32:14 --> Controller Class Initialized
INFO - 2021-01-10 12:32:15 --> Config Class Initialized
INFO - 2021-01-10 12:32:15 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:32:15 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:32:15 --> Utf8 Class Initialized
INFO - 2021-01-10 12:32:15 --> URI Class Initialized
INFO - 2021-01-10 12:32:15 --> Router Class Initialized
INFO - 2021-01-10 12:32:15 --> Output Class Initialized
INFO - 2021-01-10 12:32:15 --> Security Class Initialized
DEBUG - 2021-01-10 12:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:32:15 --> Input Class Initialized
INFO - 2021-01-10 12:32:15 --> Language Class Initialized
INFO - 2021-01-10 12:32:15 --> Language Class Initialized
INFO - 2021-01-10 12:32:15 --> Config Class Initialized
INFO - 2021-01-10 12:32:15 --> Loader Class Initialized
INFO - 2021-01-10 12:32:15 --> Helper loaded: url_helper
INFO - 2021-01-10 12:32:15 --> Helper loaded: file_helper
INFO - 2021-01-10 12:32:15 --> Helper loaded: form_helper
INFO - 2021-01-10 12:32:15 --> Helper loaded: my_helper
INFO - 2021-01-10 12:32:15 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:32:15 --> Controller Class Initialized
DEBUG - 2021-01-10 12:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-10 12:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:32:15 --> Final output sent to browser
DEBUG - 2021-01-10 12:32:15 --> Total execution time: 0.7970
INFO - 2021-01-10 12:34:33 --> Config Class Initialized
INFO - 2021-01-10 12:34:33 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:34:33 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:34:33 --> Utf8 Class Initialized
INFO - 2021-01-10 12:34:33 --> URI Class Initialized
INFO - 2021-01-10 12:34:33 --> Router Class Initialized
INFO - 2021-01-10 12:34:33 --> Output Class Initialized
INFO - 2021-01-10 12:34:33 --> Security Class Initialized
DEBUG - 2021-01-10 12:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:34:33 --> Input Class Initialized
INFO - 2021-01-10 12:34:33 --> Language Class Initialized
INFO - 2021-01-10 12:34:33 --> Language Class Initialized
INFO - 2021-01-10 12:34:33 --> Config Class Initialized
INFO - 2021-01-10 12:34:34 --> Loader Class Initialized
INFO - 2021-01-10 12:34:34 --> Helper loaded: url_helper
INFO - 2021-01-10 12:34:34 --> Helper loaded: file_helper
INFO - 2021-01-10 12:34:34 --> Helper loaded: form_helper
INFO - 2021-01-10 12:34:34 --> Helper loaded: my_helper
INFO - 2021-01-10 12:34:34 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:34:34 --> Controller Class Initialized
DEBUG - 2021-01-10 12:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-01-10 12:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 12:34:34 --> Final output sent to browser
DEBUG - 2021-01-10 12:34:34 --> Total execution time: 0.9924
INFO - 2021-01-10 12:34:34 --> Config Class Initialized
INFO - 2021-01-10 12:34:34 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:34:34 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:34:34 --> Utf8 Class Initialized
INFO - 2021-01-10 12:34:34 --> URI Class Initialized
INFO - 2021-01-10 12:34:34 --> Router Class Initialized
INFO - 2021-01-10 12:34:35 --> Output Class Initialized
INFO - 2021-01-10 12:34:35 --> Security Class Initialized
DEBUG - 2021-01-10 12:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:34:35 --> Input Class Initialized
INFO - 2021-01-10 12:34:35 --> Language Class Initialized
INFO - 2021-01-10 12:34:35 --> Language Class Initialized
INFO - 2021-01-10 12:34:35 --> Config Class Initialized
INFO - 2021-01-10 12:34:35 --> Loader Class Initialized
INFO - 2021-01-10 12:34:35 --> Helper loaded: url_helper
INFO - 2021-01-10 12:34:35 --> Helper loaded: file_helper
INFO - 2021-01-10 12:34:35 --> Helper loaded: form_helper
INFO - 2021-01-10 12:34:35 --> Helper loaded: my_helper
INFO - 2021-01-10 12:34:35 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:34:35 --> Controller Class Initialized
INFO - 2021-01-10 12:45:54 --> Config Class Initialized
INFO - 2021-01-10 12:45:54 --> Hooks Class Initialized
DEBUG - 2021-01-10 12:45:54 --> UTF-8 Support Enabled
INFO - 2021-01-10 12:45:54 --> Utf8 Class Initialized
INFO - 2021-01-10 12:45:54 --> URI Class Initialized
INFO - 2021-01-10 12:45:54 --> Router Class Initialized
INFO - 2021-01-10 12:45:54 --> Output Class Initialized
INFO - 2021-01-10 12:45:54 --> Security Class Initialized
DEBUG - 2021-01-10 12:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 12:45:54 --> Input Class Initialized
INFO - 2021-01-10 12:45:54 --> Language Class Initialized
INFO - 2021-01-10 12:45:54 --> Language Class Initialized
INFO - 2021-01-10 12:45:54 --> Config Class Initialized
INFO - 2021-01-10 12:45:54 --> Loader Class Initialized
INFO - 2021-01-10 12:45:54 --> Helper loaded: url_helper
INFO - 2021-01-10 12:45:54 --> Helper loaded: file_helper
INFO - 2021-01-10 12:45:54 --> Helper loaded: form_helper
INFO - 2021-01-10 12:45:54 --> Helper loaded: my_helper
INFO - 2021-01-10 12:45:54 --> Database Driver Class Initialized
DEBUG - 2021-01-10 12:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 12:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 12:45:54 --> Controller Class Initialized
DEBUG - 2021-01-10 12:45:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 12:45:55 --> Final output sent to browser
DEBUG - 2021-01-10 12:45:55 --> Total execution time: 0.8671
INFO - 2021-01-10 13:33:42 --> Config Class Initialized
INFO - 2021-01-10 13:33:42 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:33:42 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:33:42 --> Utf8 Class Initialized
INFO - 2021-01-10 13:33:42 --> URI Class Initialized
INFO - 2021-01-10 13:33:42 --> Router Class Initialized
INFO - 2021-01-10 13:33:42 --> Output Class Initialized
INFO - 2021-01-10 13:33:42 --> Security Class Initialized
DEBUG - 2021-01-10 13:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:33:42 --> Input Class Initialized
INFO - 2021-01-10 13:33:42 --> Language Class Initialized
INFO - 2021-01-10 13:33:42 --> Language Class Initialized
INFO - 2021-01-10 13:33:42 --> Config Class Initialized
INFO - 2021-01-10 13:33:42 --> Loader Class Initialized
INFO - 2021-01-10 13:33:42 --> Helper loaded: url_helper
INFO - 2021-01-10 13:33:42 --> Helper loaded: file_helper
INFO - 2021-01-10 13:33:42 --> Helper loaded: form_helper
INFO - 2021-01-10 13:33:42 --> Helper loaded: my_helper
INFO - 2021-01-10 13:33:42 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:33:42 --> Controller Class Initialized
DEBUG - 2021-01-10 13:33:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:33:43 --> Final output sent to browser
DEBUG - 2021-01-10 13:33:43 --> Total execution time: 0.2946
INFO - 2021-01-10 13:33:59 --> Config Class Initialized
INFO - 2021-01-10 13:33:59 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:33:59 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:33:59 --> Utf8 Class Initialized
INFO - 2021-01-10 13:33:59 --> URI Class Initialized
INFO - 2021-01-10 13:33:59 --> Router Class Initialized
INFO - 2021-01-10 13:33:59 --> Output Class Initialized
INFO - 2021-01-10 13:33:59 --> Security Class Initialized
DEBUG - 2021-01-10 13:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:33:59 --> Input Class Initialized
INFO - 2021-01-10 13:33:59 --> Language Class Initialized
INFO - 2021-01-10 13:33:59 --> Language Class Initialized
INFO - 2021-01-10 13:33:59 --> Config Class Initialized
INFO - 2021-01-10 13:33:59 --> Loader Class Initialized
INFO - 2021-01-10 13:33:59 --> Helper loaded: url_helper
INFO - 2021-01-10 13:33:59 --> Helper loaded: file_helper
INFO - 2021-01-10 13:33:59 --> Helper loaded: form_helper
INFO - 2021-01-10 13:33:59 --> Helper loaded: my_helper
INFO - 2021-01-10 13:33:59 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:33:59 --> Controller Class Initialized
DEBUG - 2021-01-10 13:33:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:33:59 --> Final output sent to browser
DEBUG - 2021-01-10 13:33:59 --> Total execution time: 0.3160
INFO - 2021-01-10 13:35:40 --> Config Class Initialized
INFO - 2021-01-10 13:35:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:35:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:35:40 --> Utf8 Class Initialized
INFO - 2021-01-10 13:35:40 --> URI Class Initialized
INFO - 2021-01-10 13:35:40 --> Router Class Initialized
INFO - 2021-01-10 13:35:40 --> Output Class Initialized
INFO - 2021-01-10 13:35:40 --> Security Class Initialized
DEBUG - 2021-01-10 13:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:35:40 --> Input Class Initialized
INFO - 2021-01-10 13:35:40 --> Language Class Initialized
INFO - 2021-01-10 13:35:40 --> Language Class Initialized
INFO - 2021-01-10 13:35:40 --> Config Class Initialized
INFO - 2021-01-10 13:35:40 --> Loader Class Initialized
INFO - 2021-01-10 13:35:40 --> Helper loaded: url_helper
INFO - 2021-01-10 13:35:40 --> Helper loaded: file_helper
INFO - 2021-01-10 13:35:40 --> Helper loaded: form_helper
INFO - 2021-01-10 13:35:40 --> Helper loaded: my_helper
INFO - 2021-01-10 13:35:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:35:40 --> Controller Class Initialized
DEBUG - 2021-01-10 13:35:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:35:40 --> Final output sent to browser
DEBUG - 2021-01-10 13:35:40 --> Total execution time: 0.3229
INFO - 2021-01-10 13:36:02 --> Config Class Initialized
INFO - 2021-01-10 13:36:02 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:36:02 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:36:02 --> Utf8 Class Initialized
INFO - 2021-01-10 13:36:02 --> URI Class Initialized
INFO - 2021-01-10 13:36:02 --> Router Class Initialized
INFO - 2021-01-10 13:36:02 --> Output Class Initialized
INFO - 2021-01-10 13:36:02 --> Security Class Initialized
DEBUG - 2021-01-10 13:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:36:02 --> Input Class Initialized
INFO - 2021-01-10 13:36:02 --> Language Class Initialized
INFO - 2021-01-10 13:36:02 --> Language Class Initialized
INFO - 2021-01-10 13:36:02 --> Config Class Initialized
INFO - 2021-01-10 13:36:02 --> Loader Class Initialized
INFO - 2021-01-10 13:36:02 --> Helper loaded: url_helper
INFO - 2021-01-10 13:36:02 --> Helper loaded: file_helper
INFO - 2021-01-10 13:36:02 --> Helper loaded: form_helper
INFO - 2021-01-10 13:36:02 --> Helper loaded: my_helper
INFO - 2021-01-10 13:36:02 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:36:02 --> Controller Class Initialized
DEBUG - 2021-01-10 13:36:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:36:02 --> Final output sent to browser
DEBUG - 2021-01-10 13:36:02 --> Total execution time: 0.2582
INFO - 2021-01-10 13:36:29 --> Config Class Initialized
INFO - 2021-01-10 13:36:29 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:36:29 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:36:29 --> Utf8 Class Initialized
INFO - 2021-01-10 13:36:29 --> URI Class Initialized
INFO - 2021-01-10 13:36:29 --> Router Class Initialized
INFO - 2021-01-10 13:36:29 --> Output Class Initialized
INFO - 2021-01-10 13:36:29 --> Security Class Initialized
DEBUG - 2021-01-10 13:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:36:29 --> Input Class Initialized
INFO - 2021-01-10 13:36:29 --> Language Class Initialized
INFO - 2021-01-10 13:36:29 --> Language Class Initialized
INFO - 2021-01-10 13:36:29 --> Config Class Initialized
INFO - 2021-01-10 13:36:29 --> Loader Class Initialized
INFO - 2021-01-10 13:36:29 --> Helper loaded: url_helper
INFO - 2021-01-10 13:36:29 --> Helper loaded: file_helper
INFO - 2021-01-10 13:36:29 --> Helper loaded: form_helper
INFO - 2021-01-10 13:36:29 --> Helper loaded: my_helper
INFO - 2021-01-10 13:36:29 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:36:29 --> Controller Class Initialized
DEBUG - 2021-01-10 13:36:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:36:30 --> Final output sent to browser
DEBUG - 2021-01-10 13:36:30 --> Total execution time: 0.3788
INFO - 2021-01-10 13:37:02 --> Config Class Initialized
INFO - 2021-01-10 13:37:02 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:37:02 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:37:02 --> Utf8 Class Initialized
INFO - 2021-01-10 13:37:02 --> URI Class Initialized
INFO - 2021-01-10 13:37:02 --> Router Class Initialized
INFO - 2021-01-10 13:37:02 --> Output Class Initialized
INFO - 2021-01-10 13:37:02 --> Security Class Initialized
DEBUG - 2021-01-10 13:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:37:02 --> Input Class Initialized
INFO - 2021-01-10 13:37:02 --> Language Class Initialized
INFO - 2021-01-10 13:37:02 --> Language Class Initialized
INFO - 2021-01-10 13:37:02 --> Config Class Initialized
INFO - 2021-01-10 13:37:02 --> Loader Class Initialized
INFO - 2021-01-10 13:37:02 --> Helper loaded: url_helper
INFO - 2021-01-10 13:37:02 --> Helper loaded: file_helper
INFO - 2021-01-10 13:37:02 --> Helper loaded: form_helper
INFO - 2021-01-10 13:37:02 --> Helper loaded: my_helper
INFO - 2021-01-10 13:37:02 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:37:02 --> Controller Class Initialized
DEBUG - 2021-01-10 13:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:37:02 --> Final output sent to browser
DEBUG - 2021-01-10 13:37:02 --> Total execution time: 0.2280
INFO - 2021-01-10 13:38:28 --> Config Class Initialized
INFO - 2021-01-10 13:38:28 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:38:28 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:38:28 --> Utf8 Class Initialized
INFO - 2021-01-10 13:38:28 --> URI Class Initialized
INFO - 2021-01-10 13:38:28 --> Router Class Initialized
INFO - 2021-01-10 13:38:28 --> Output Class Initialized
INFO - 2021-01-10 13:38:28 --> Security Class Initialized
DEBUG - 2021-01-10 13:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:38:28 --> Input Class Initialized
INFO - 2021-01-10 13:38:28 --> Language Class Initialized
INFO - 2021-01-10 13:38:28 --> Language Class Initialized
INFO - 2021-01-10 13:38:28 --> Config Class Initialized
INFO - 2021-01-10 13:38:28 --> Loader Class Initialized
INFO - 2021-01-10 13:38:28 --> Helper loaded: url_helper
INFO - 2021-01-10 13:38:28 --> Helper loaded: file_helper
INFO - 2021-01-10 13:38:28 --> Helper loaded: form_helper
INFO - 2021-01-10 13:38:28 --> Helper loaded: my_helper
INFO - 2021-01-10 13:38:28 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:38:28 --> Controller Class Initialized
DEBUG - 2021-01-10 13:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:38:28 --> Final output sent to browser
DEBUG - 2021-01-10 13:38:28 --> Total execution time: 0.3328
INFO - 2021-01-10 13:38:48 --> Config Class Initialized
INFO - 2021-01-10 13:38:48 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:38:48 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:38:48 --> Utf8 Class Initialized
INFO - 2021-01-10 13:38:48 --> URI Class Initialized
INFO - 2021-01-10 13:38:48 --> Router Class Initialized
INFO - 2021-01-10 13:38:48 --> Output Class Initialized
INFO - 2021-01-10 13:38:48 --> Security Class Initialized
DEBUG - 2021-01-10 13:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:38:48 --> Input Class Initialized
INFO - 2021-01-10 13:38:48 --> Language Class Initialized
INFO - 2021-01-10 13:38:48 --> Language Class Initialized
INFO - 2021-01-10 13:38:48 --> Config Class Initialized
INFO - 2021-01-10 13:38:48 --> Loader Class Initialized
INFO - 2021-01-10 13:38:48 --> Helper loaded: url_helper
INFO - 2021-01-10 13:38:48 --> Helper loaded: file_helper
INFO - 2021-01-10 13:38:48 --> Helper loaded: form_helper
INFO - 2021-01-10 13:38:48 --> Helper loaded: my_helper
INFO - 2021-01-10 13:38:48 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:38:48 --> Controller Class Initialized
DEBUG - 2021-01-10 13:38:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:38:48 --> Final output sent to browser
DEBUG - 2021-01-10 13:38:48 --> Total execution time: 0.2911
INFO - 2021-01-10 13:41:52 --> Config Class Initialized
INFO - 2021-01-10 13:41:52 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:41:52 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:41:52 --> Utf8 Class Initialized
INFO - 2021-01-10 13:41:52 --> URI Class Initialized
INFO - 2021-01-10 13:41:52 --> Router Class Initialized
INFO - 2021-01-10 13:41:52 --> Output Class Initialized
INFO - 2021-01-10 13:41:52 --> Security Class Initialized
DEBUG - 2021-01-10 13:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:41:52 --> Input Class Initialized
INFO - 2021-01-10 13:41:52 --> Language Class Initialized
INFO - 2021-01-10 13:41:52 --> Language Class Initialized
INFO - 2021-01-10 13:41:52 --> Config Class Initialized
INFO - 2021-01-10 13:41:52 --> Loader Class Initialized
INFO - 2021-01-10 13:41:52 --> Helper loaded: url_helper
INFO - 2021-01-10 13:41:52 --> Helper loaded: file_helper
INFO - 2021-01-10 13:41:52 --> Helper loaded: form_helper
INFO - 2021-01-10 13:41:52 --> Helper loaded: my_helper
INFO - 2021-01-10 13:41:52 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:41:52 --> Controller Class Initialized
DEBUG - 2021-01-10 13:41:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:41:52 --> Final output sent to browser
DEBUG - 2021-01-10 13:41:52 --> Total execution time: 0.3057
INFO - 2021-01-10 13:43:18 --> Config Class Initialized
INFO - 2021-01-10 13:43:18 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:18 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:18 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:18 --> URI Class Initialized
INFO - 2021-01-10 13:43:18 --> Router Class Initialized
INFO - 2021-01-10 13:43:18 --> Output Class Initialized
INFO - 2021-01-10 13:43:18 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:18 --> Input Class Initialized
INFO - 2021-01-10 13:43:18 --> Language Class Initialized
INFO - 2021-01-10 13:43:18 --> Language Class Initialized
INFO - 2021-01-10 13:43:18 --> Config Class Initialized
INFO - 2021-01-10 13:43:18 --> Loader Class Initialized
INFO - 2021-01-10 13:43:18 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:18 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:18 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:18 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:18 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:18 --> Controller Class Initialized
DEBUG - 2021-01-10 13:43:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:43:18 --> Final output sent to browser
DEBUG - 2021-01-10 13:43:18 --> Total execution time: 0.2973
INFO - 2021-01-10 13:43:39 --> Config Class Initialized
INFO - 2021-01-10 13:43:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:39 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:40 --> URI Class Initialized
INFO - 2021-01-10 13:43:40 --> Router Class Initialized
INFO - 2021-01-10 13:43:40 --> Output Class Initialized
INFO - 2021-01-10 13:43:40 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:40 --> Input Class Initialized
INFO - 2021-01-10 13:43:40 --> Language Class Initialized
INFO - 2021-01-10 13:43:40 --> Language Class Initialized
INFO - 2021-01-10 13:43:40 --> Config Class Initialized
INFO - 2021-01-10 13:43:40 --> Loader Class Initialized
INFO - 2021-01-10 13:43:40 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:40 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:40 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:40 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:40 --> Controller Class Initialized
INFO - 2021-01-10 13:43:40 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:43:40 --> Config Class Initialized
INFO - 2021-01-10 13:43:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:40 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:40 --> URI Class Initialized
INFO - 2021-01-10 13:43:40 --> Router Class Initialized
INFO - 2021-01-10 13:43:40 --> Output Class Initialized
INFO - 2021-01-10 13:43:40 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:40 --> Input Class Initialized
INFO - 2021-01-10 13:43:40 --> Language Class Initialized
INFO - 2021-01-10 13:43:40 --> Language Class Initialized
INFO - 2021-01-10 13:43:40 --> Config Class Initialized
INFO - 2021-01-10 13:43:40 --> Loader Class Initialized
INFO - 2021-01-10 13:43:40 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:40 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:40 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:40 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:40 --> Controller Class Initialized
DEBUG - 2021-01-10 13:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 13:43:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:43:40 --> Final output sent to browser
DEBUG - 2021-01-10 13:43:40 --> Total execution time: 0.3163
INFO - 2021-01-10 13:43:46 --> Config Class Initialized
INFO - 2021-01-10 13:43:46 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:46 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:46 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:46 --> URI Class Initialized
INFO - 2021-01-10 13:43:46 --> Router Class Initialized
INFO - 2021-01-10 13:43:46 --> Output Class Initialized
INFO - 2021-01-10 13:43:46 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:46 --> Input Class Initialized
INFO - 2021-01-10 13:43:46 --> Language Class Initialized
INFO - 2021-01-10 13:43:46 --> Language Class Initialized
INFO - 2021-01-10 13:43:46 --> Config Class Initialized
INFO - 2021-01-10 13:43:46 --> Loader Class Initialized
INFO - 2021-01-10 13:43:46 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:46 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:46 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:46 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:46 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:46 --> Controller Class Initialized
INFO - 2021-01-10 13:43:46 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:43:46 --> Final output sent to browser
DEBUG - 2021-01-10 13:43:46 --> Total execution time: 0.3156
INFO - 2021-01-10 13:43:46 --> Config Class Initialized
INFO - 2021-01-10 13:43:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:47 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:47 --> URI Class Initialized
INFO - 2021-01-10 13:43:47 --> Router Class Initialized
INFO - 2021-01-10 13:43:47 --> Output Class Initialized
INFO - 2021-01-10 13:43:47 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:47 --> Input Class Initialized
INFO - 2021-01-10 13:43:47 --> Language Class Initialized
INFO - 2021-01-10 13:43:47 --> Language Class Initialized
INFO - 2021-01-10 13:43:47 --> Config Class Initialized
INFO - 2021-01-10 13:43:47 --> Loader Class Initialized
INFO - 2021-01-10 13:43:47 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:47 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:47 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:47 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:47 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:47 --> Controller Class Initialized
DEBUG - 2021-01-10 13:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 13:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:43:47 --> Final output sent to browser
DEBUG - 2021-01-10 13:43:47 --> Total execution time: 0.3458
INFO - 2021-01-10 13:43:48 --> Config Class Initialized
INFO - 2021-01-10 13:43:48 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:48 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:48 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:48 --> URI Class Initialized
INFO - 2021-01-10 13:43:48 --> Router Class Initialized
INFO - 2021-01-10 13:43:48 --> Output Class Initialized
INFO - 2021-01-10 13:43:48 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:48 --> Input Class Initialized
INFO - 2021-01-10 13:43:48 --> Language Class Initialized
INFO - 2021-01-10 13:43:48 --> Language Class Initialized
INFO - 2021-01-10 13:43:48 --> Config Class Initialized
INFO - 2021-01-10 13:43:48 --> Loader Class Initialized
INFO - 2021-01-10 13:43:48 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:48 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:48 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:48 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:48 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:49 --> Controller Class Initialized
DEBUG - 2021-01-10 13:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 13:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:43:49 --> Final output sent to browser
DEBUG - 2021-01-10 13:43:49 --> Total execution time: 0.3231
INFO - 2021-01-10 13:43:50 --> Config Class Initialized
INFO - 2021-01-10 13:43:50 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:43:50 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:43:50 --> Utf8 Class Initialized
INFO - 2021-01-10 13:43:50 --> URI Class Initialized
INFO - 2021-01-10 13:43:50 --> Router Class Initialized
INFO - 2021-01-10 13:43:50 --> Output Class Initialized
INFO - 2021-01-10 13:43:50 --> Security Class Initialized
DEBUG - 2021-01-10 13:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:43:50 --> Input Class Initialized
INFO - 2021-01-10 13:43:50 --> Language Class Initialized
INFO - 2021-01-10 13:43:50 --> Language Class Initialized
INFO - 2021-01-10 13:43:50 --> Config Class Initialized
INFO - 2021-01-10 13:43:50 --> Loader Class Initialized
INFO - 2021-01-10 13:43:50 --> Helper loaded: url_helper
INFO - 2021-01-10 13:43:50 --> Helper loaded: file_helper
INFO - 2021-01-10 13:43:50 --> Helper loaded: form_helper
INFO - 2021-01-10 13:43:50 --> Helper loaded: my_helper
INFO - 2021-01-10 13:43:50 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:43:50 --> Controller Class Initialized
DEBUG - 2021-01-10 13:43:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:43:50 --> Final output sent to browser
DEBUG - 2021-01-10 13:43:50 --> Total execution time: 0.2747
INFO - 2021-01-10 13:44:43 --> Config Class Initialized
INFO - 2021-01-10 13:44:43 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:44:43 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:44:43 --> Utf8 Class Initialized
INFO - 2021-01-10 13:44:43 --> URI Class Initialized
INFO - 2021-01-10 13:44:43 --> Router Class Initialized
INFO - 2021-01-10 13:44:43 --> Output Class Initialized
INFO - 2021-01-10 13:44:43 --> Security Class Initialized
DEBUG - 2021-01-10 13:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:44:43 --> Input Class Initialized
INFO - 2021-01-10 13:44:43 --> Language Class Initialized
INFO - 2021-01-10 13:44:43 --> Language Class Initialized
INFO - 2021-01-10 13:44:43 --> Config Class Initialized
INFO - 2021-01-10 13:44:43 --> Loader Class Initialized
INFO - 2021-01-10 13:44:43 --> Helper loaded: url_helper
INFO - 2021-01-10 13:44:43 --> Helper loaded: file_helper
INFO - 2021-01-10 13:44:43 --> Helper loaded: form_helper
INFO - 2021-01-10 13:44:43 --> Helper loaded: my_helper
INFO - 2021-01-10 13:44:43 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:44:43 --> Controller Class Initialized
DEBUG - 2021-01-10 13:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:44:43 --> Final output sent to browser
DEBUG - 2021-01-10 13:44:43 --> Total execution time: 0.3013
INFO - 2021-01-10 13:45:16 --> Config Class Initialized
INFO - 2021-01-10 13:45:16 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:45:16 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:45:16 --> Utf8 Class Initialized
INFO - 2021-01-10 13:45:16 --> URI Class Initialized
INFO - 2021-01-10 13:45:16 --> Router Class Initialized
INFO - 2021-01-10 13:45:16 --> Output Class Initialized
INFO - 2021-01-10 13:45:16 --> Security Class Initialized
DEBUG - 2021-01-10 13:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:45:16 --> Input Class Initialized
INFO - 2021-01-10 13:45:16 --> Language Class Initialized
INFO - 2021-01-10 13:45:16 --> Language Class Initialized
INFO - 2021-01-10 13:45:16 --> Config Class Initialized
INFO - 2021-01-10 13:45:16 --> Loader Class Initialized
INFO - 2021-01-10 13:45:16 --> Helper loaded: url_helper
INFO - 2021-01-10 13:45:16 --> Helper loaded: file_helper
INFO - 2021-01-10 13:45:16 --> Helper loaded: form_helper
INFO - 2021-01-10 13:45:16 --> Helper loaded: my_helper
INFO - 2021-01-10 13:45:16 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:45:16 --> Controller Class Initialized
DEBUG - 2021-01-10 13:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:45:16 --> Final output sent to browser
DEBUG - 2021-01-10 13:45:16 --> Total execution time: 0.3306
INFO - 2021-01-10 13:45:47 --> Config Class Initialized
INFO - 2021-01-10 13:45:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:45:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:45:47 --> Utf8 Class Initialized
INFO - 2021-01-10 13:45:47 --> URI Class Initialized
INFO - 2021-01-10 13:45:47 --> Router Class Initialized
INFO - 2021-01-10 13:45:47 --> Output Class Initialized
INFO - 2021-01-10 13:45:47 --> Security Class Initialized
DEBUG - 2021-01-10 13:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:45:47 --> Input Class Initialized
INFO - 2021-01-10 13:45:47 --> Language Class Initialized
INFO - 2021-01-10 13:45:47 --> Language Class Initialized
INFO - 2021-01-10 13:45:47 --> Config Class Initialized
INFO - 2021-01-10 13:45:47 --> Loader Class Initialized
INFO - 2021-01-10 13:45:47 --> Helper loaded: url_helper
INFO - 2021-01-10 13:45:47 --> Helper loaded: file_helper
INFO - 2021-01-10 13:45:47 --> Helper loaded: form_helper
INFO - 2021-01-10 13:45:47 --> Helper loaded: my_helper
INFO - 2021-01-10 13:45:47 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:45:47 --> Controller Class Initialized
DEBUG - 2021-01-10 13:45:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:45:47 --> Final output sent to browser
DEBUG - 2021-01-10 13:45:47 --> Total execution time: 0.3217
INFO - 2021-01-10 13:45:53 --> Config Class Initialized
INFO - 2021-01-10 13:45:53 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:45:53 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:45:53 --> Utf8 Class Initialized
INFO - 2021-01-10 13:45:53 --> URI Class Initialized
INFO - 2021-01-10 13:45:53 --> Router Class Initialized
INFO - 2021-01-10 13:45:53 --> Output Class Initialized
INFO - 2021-01-10 13:45:53 --> Security Class Initialized
DEBUG - 2021-01-10 13:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:45:53 --> Input Class Initialized
INFO - 2021-01-10 13:45:53 --> Language Class Initialized
INFO - 2021-01-10 13:45:53 --> Language Class Initialized
INFO - 2021-01-10 13:45:53 --> Config Class Initialized
INFO - 2021-01-10 13:45:53 --> Loader Class Initialized
INFO - 2021-01-10 13:45:53 --> Helper loaded: url_helper
INFO - 2021-01-10 13:45:53 --> Helper loaded: file_helper
INFO - 2021-01-10 13:45:53 --> Helper loaded: form_helper
INFO - 2021-01-10 13:45:53 --> Helper loaded: my_helper
INFO - 2021-01-10 13:45:53 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:45:53 --> Controller Class Initialized
DEBUG - 2021-01-10 13:45:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:45:53 --> Final output sent to browser
DEBUG - 2021-01-10 13:45:53 --> Total execution time: 0.2307
INFO - 2021-01-10 13:46:56 --> Config Class Initialized
INFO - 2021-01-10 13:46:56 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:46:56 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:46:56 --> Utf8 Class Initialized
INFO - 2021-01-10 13:46:56 --> URI Class Initialized
INFO - 2021-01-10 13:46:56 --> Router Class Initialized
INFO - 2021-01-10 13:46:56 --> Output Class Initialized
INFO - 2021-01-10 13:46:56 --> Security Class Initialized
DEBUG - 2021-01-10 13:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:46:56 --> Input Class Initialized
INFO - 2021-01-10 13:46:56 --> Language Class Initialized
INFO - 2021-01-10 13:46:56 --> Language Class Initialized
INFO - 2021-01-10 13:46:56 --> Config Class Initialized
INFO - 2021-01-10 13:46:56 --> Loader Class Initialized
INFO - 2021-01-10 13:46:56 --> Helper loaded: url_helper
INFO - 2021-01-10 13:46:56 --> Helper loaded: file_helper
INFO - 2021-01-10 13:46:56 --> Helper loaded: form_helper
INFO - 2021-01-10 13:46:56 --> Helper loaded: my_helper
INFO - 2021-01-10 13:46:56 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:46:56 --> Controller Class Initialized
DEBUG - 2021-01-10 13:46:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:46:56 --> Final output sent to browser
DEBUG - 2021-01-10 13:46:56 --> Total execution time: 0.3195
INFO - 2021-01-10 13:47:16 --> Config Class Initialized
INFO - 2021-01-10 13:47:17 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:47:17 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:47:17 --> Utf8 Class Initialized
INFO - 2021-01-10 13:47:17 --> URI Class Initialized
INFO - 2021-01-10 13:47:17 --> Router Class Initialized
INFO - 2021-01-10 13:47:17 --> Output Class Initialized
INFO - 2021-01-10 13:47:17 --> Security Class Initialized
DEBUG - 2021-01-10 13:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:47:17 --> Input Class Initialized
INFO - 2021-01-10 13:47:17 --> Language Class Initialized
INFO - 2021-01-10 13:47:17 --> Language Class Initialized
INFO - 2021-01-10 13:47:17 --> Config Class Initialized
INFO - 2021-01-10 13:47:17 --> Loader Class Initialized
INFO - 2021-01-10 13:47:17 --> Helper loaded: url_helper
INFO - 2021-01-10 13:47:17 --> Helper loaded: file_helper
INFO - 2021-01-10 13:47:17 --> Helper loaded: form_helper
INFO - 2021-01-10 13:47:17 --> Helper loaded: my_helper
INFO - 2021-01-10 13:47:17 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:47:17 --> Controller Class Initialized
DEBUG - 2021-01-10 13:47:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:47:17 --> Final output sent to browser
DEBUG - 2021-01-10 13:47:17 --> Total execution time: 0.3230
INFO - 2021-01-10 13:47:21 --> Config Class Initialized
INFO - 2021-01-10 13:47:21 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:47:21 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:47:21 --> Utf8 Class Initialized
INFO - 2021-01-10 13:47:21 --> URI Class Initialized
INFO - 2021-01-10 13:47:21 --> Router Class Initialized
INFO - 2021-01-10 13:47:21 --> Output Class Initialized
INFO - 2021-01-10 13:47:21 --> Security Class Initialized
DEBUG - 2021-01-10 13:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:47:21 --> Input Class Initialized
INFO - 2021-01-10 13:47:21 --> Language Class Initialized
INFO - 2021-01-10 13:47:21 --> Language Class Initialized
INFO - 2021-01-10 13:47:21 --> Config Class Initialized
INFO - 2021-01-10 13:47:21 --> Loader Class Initialized
INFO - 2021-01-10 13:47:21 --> Helper loaded: url_helper
INFO - 2021-01-10 13:47:21 --> Helper loaded: file_helper
INFO - 2021-01-10 13:47:21 --> Helper loaded: form_helper
INFO - 2021-01-10 13:47:21 --> Helper loaded: my_helper
INFO - 2021-01-10 13:47:21 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:47:21 --> Controller Class Initialized
DEBUG - 2021-01-10 13:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:47:21 --> Final output sent to browser
DEBUG - 2021-01-10 13:47:21 --> Total execution time: 0.2449
INFO - 2021-01-10 13:47:47 --> Config Class Initialized
INFO - 2021-01-10 13:47:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:47:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:47:47 --> Utf8 Class Initialized
INFO - 2021-01-10 13:47:47 --> URI Class Initialized
INFO - 2021-01-10 13:47:47 --> Router Class Initialized
INFO - 2021-01-10 13:47:47 --> Output Class Initialized
INFO - 2021-01-10 13:47:47 --> Security Class Initialized
DEBUG - 2021-01-10 13:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:47:47 --> Input Class Initialized
INFO - 2021-01-10 13:47:47 --> Language Class Initialized
INFO - 2021-01-10 13:47:47 --> Language Class Initialized
INFO - 2021-01-10 13:47:47 --> Config Class Initialized
INFO - 2021-01-10 13:47:47 --> Loader Class Initialized
INFO - 2021-01-10 13:47:47 --> Helper loaded: url_helper
INFO - 2021-01-10 13:47:47 --> Helper loaded: file_helper
INFO - 2021-01-10 13:47:47 --> Helper loaded: form_helper
INFO - 2021-01-10 13:47:47 --> Helper loaded: my_helper
INFO - 2021-01-10 13:47:47 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:47:47 --> Controller Class Initialized
INFO - 2021-01-10 13:47:47 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:47:47 --> Config Class Initialized
INFO - 2021-01-10 13:47:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:47:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:47:47 --> Utf8 Class Initialized
INFO - 2021-01-10 13:47:47 --> URI Class Initialized
INFO - 2021-01-10 13:47:47 --> Router Class Initialized
INFO - 2021-01-10 13:47:47 --> Output Class Initialized
INFO - 2021-01-10 13:47:47 --> Security Class Initialized
DEBUG - 2021-01-10 13:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:47:47 --> Input Class Initialized
INFO - 2021-01-10 13:47:47 --> Language Class Initialized
INFO - 2021-01-10 13:47:47 --> Language Class Initialized
INFO - 2021-01-10 13:47:47 --> Config Class Initialized
INFO - 2021-01-10 13:47:47 --> Loader Class Initialized
INFO - 2021-01-10 13:47:47 --> Helper loaded: url_helper
INFO - 2021-01-10 13:47:47 --> Helper loaded: file_helper
INFO - 2021-01-10 13:47:47 --> Helper loaded: form_helper
INFO - 2021-01-10 13:47:47 --> Helper loaded: my_helper
INFO - 2021-01-10 13:47:47 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:47:47 --> Controller Class Initialized
DEBUG - 2021-01-10 13:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 13:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:47:48 --> Final output sent to browser
DEBUG - 2021-01-10 13:47:48 --> Total execution time: 0.2337
INFO - 2021-01-10 13:47:59 --> Config Class Initialized
INFO - 2021-01-10 13:47:59 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:47:59 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:47:59 --> Utf8 Class Initialized
INFO - 2021-01-10 13:47:59 --> URI Class Initialized
INFO - 2021-01-10 13:47:59 --> Router Class Initialized
INFO - 2021-01-10 13:47:59 --> Output Class Initialized
INFO - 2021-01-10 13:47:59 --> Security Class Initialized
DEBUG - 2021-01-10 13:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:47:59 --> Input Class Initialized
INFO - 2021-01-10 13:47:59 --> Language Class Initialized
INFO - 2021-01-10 13:47:59 --> Language Class Initialized
INFO - 2021-01-10 13:47:59 --> Config Class Initialized
INFO - 2021-01-10 13:47:59 --> Loader Class Initialized
INFO - 2021-01-10 13:47:59 --> Helper loaded: url_helper
INFO - 2021-01-10 13:47:59 --> Helper loaded: file_helper
INFO - 2021-01-10 13:47:59 --> Helper loaded: form_helper
INFO - 2021-01-10 13:47:59 --> Helper loaded: my_helper
INFO - 2021-01-10 13:47:59 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:47:59 --> Controller Class Initialized
INFO - 2021-01-10 13:47:59 --> Final output sent to browser
DEBUG - 2021-01-10 13:47:59 --> Total execution time: 0.3232
INFO - 2021-01-10 13:48:04 --> Config Class Initialized
INFO - 2021-01-10 13:48:04 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:04 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:04 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:04 --> URI Class Initialized
INFO - 2021-01-10 13:48:04 --> Router Class Initialized
INFO - 2021-01-10 13:48:04 --> Output Class Initialized
INFO - 2021-01-10 13:48:04 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:04 --> Input Class Initialized
INFO - 2021-01-10 13:48:04 --> Language Class Initialized
INFO - 2021-01-10 13:48:04 --> Language Class Initialized
INFO - 2021-01-10 13:48:04 --> Config Class Initialized
INFO - 2021-01-10 13:48:04 --> Loader Class Initialized
INFO - 2021-01-10 13:48:04 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:04 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:04 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:04 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:04 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:04 --> Controller Class Initialized
INFO - 2021-01-10 13:48:04 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:48:04 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:04 --> Total execution time: 0.3325
INFO - 2021-01-10 13:48:04 --> Config Class Initialized
INFO - 2021-01-10 13:48:05 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:05 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:05 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:05 --> URI Class Initialized
INFO - 2021-01-10 13:48:05 --> Router Class Initialized
INFO - 2021-01-10 13:48:05 --> Output Class Initialized
INFO - 2021-01-10 13:48:05 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:05 --> Input Class Initialized
INFO - 2021-01-10 13:48:05 --> Language Class Initialized
INFO - 2021-01-10 13:48:05 --> Language Class Initialized
INFO - 2021-01-10 13:48:05 --> Config Class Initialized
INFO - 2021-01-10 13:48:05 --> Loader Class Initialized
INFO - 2021-01-10 13:48:05 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:05 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:05 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:05 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:05 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:05 --> Controller Class Initialized
DEBUG - 2021-01-10 13:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 13:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:48:05 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:05 --> Total execution time: 0.3741
INFO - 2021-01-10 13:48:07 --> Config Class Initialized
INFO - 2021-01-10 13:48:07 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:07 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:07 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:07 --> URI Class Initialized
INFO - 2021-01-10 13:48:07 --> Router Class Initialized
INFO - 2021-01-10 13:48:07 --> Output Class Initialized
INFO - 2021-01-10 13:48:07 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:07 --> Input Class Initialized
INFO - 2021-01-10 13:48:07 --> Language Class Initialized
INFO - 2021-01-10 13:48:07 --> Language Class Initialized
INFO - 2021-01-10 13:48:07 --> Config Class Initialized
INFO - 2021-01-10 13:48:07 --> Loader Class Initialized
INFO - 2021-01-10 13:48:07 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:07 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:07 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:07 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:07 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:07 --> Controller Class Initialized
DEBUG - 2021-01-10 13:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-01-10 13:48:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:48:07 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:07 --> Total execution time: 0.3089
INFO - 2021-01-10 13:48:07 --> Config Class Initialized
INFO - 2021-01-10 13:48:07 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:07 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:07 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:07 --> URI Class Initialized
INFO - 2021-01-10 13:48:07 --> Router Class Initialized
INFO - 2021-01-10 13:48:07 --> Output Class Initialized
INFO - 2021-01-10 13:48:07 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:07 --> Input Class Initialized
INFO - 2021-01-10 13:48:07 --> Language Class Initialized
INFO - 2021-01-10 13:48:07 --> Language Class Initialized
INFO - 2021-01-10 13:48:07 --> Config Class Initialized
INFO - 2021-01-10 13:48:07 --> Loader Class Initialized
INFO - 2021-01-10 13:48:07 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:07 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:07 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:07 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:07 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:07 --> Controller Class Initialized
INFO - 2021-01-10 13:48:09 --> Config Class Initialized
INFO - 2021-01-10 13:48:09 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:09 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:09 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:09 --> URI Class Initialized
INFO - 2021-01-10 13:48:09 --> Router Class Initialized
INFO - 2021-01-10 13:48:09 --> Output Class Initialized
INFO - 2021-01-10 13:48:09 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:09 --> Input Class Initialized
INFO - 2021-01-10 13:48:09 --> Language Class Initialized
INFO - 2021-01-10 13:48:09 --> Language Class Initialized
INFO - 2021-01-10 13:48:10 --> Config Class Initialized
INFO - 2021-01-10 13:48:10 --> Loader Class Initialized
INFO - 2021-01-10 13:48:10 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:10 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:10 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:10 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:10 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:10 --> Controller Class Initialized
DEBUG - 2021-01-10 13:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-10 13:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:48:10 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:10 --> Total execution time: 0.3350
INFO - 2021-01-10 13:48:10 --> Config Class Initialized
INFO - 2021-01-10 13:48:10 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:10 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:10 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:10 --> URI Class Initialized
INFO - 2021-01-10 13:48:10 --> Router Class Initialized
INFO - 2021-01-10 13:48:10 --> Output Class Initialized
INFO - 2021-01-10 13:48:10 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:10 --> Input Class Initialized
INFO - 2021-01-10 13:48:10 --> Language Class Initialized
INFO - 2021-01-10 13:48:10 --> Language Class Initialized
INFO - 2021-01-10 13:48:10 --> Config Class Initialized
INFO - 2021-01-10 13:48:10 --> Loader Class Initialized
INFO - 2021-01-10 13:48:10 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:10 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:10 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:10 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:10 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:10 --> Controller Class Initialized
INFO - 2021-01-10 13:48:11 --> Config Class Initialized
INFO - 2021-01-10 13:48:11 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:11 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:11 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:11 --> URI Class Initialized
INFO - 2021-01-10 13:48:11 --> Router Class Initialized
INFO - 2021-01-10 13:48:11 --> Output Class Initialized
INFO - 2021-01-10 13:48:11 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:11 --> Input Class Initialized
INFO - 2021-01-10 13:48:11 --> Language Class Initialized
INFO - 2021-01-10 13:48:11 --> Language Class Initialized
INFO - 2021-01-10 13:48:11 --> Config Class Initialized
INFO - 2021-01-10 13:48:11 --> Loader Class Initialized
INFO - 2021-01-10 13:48:11 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:11 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:11 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:11 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:11 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:11 --> Controller Class Initialized
INFO - 2021-01-10 13:48:11 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:11 --> Total execution time: 0.2464
INFO - 2021-01-10 13:48:35 --> Config Class Initialized
INFO - 2021-01-10 13:48:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:35 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:35 --> URI Class Initialized
INFO - 2021-01-10 13:48:35 --> Router Class Initialized
INFO - 2021-01-10 13:48:35 --> Output Class Initialized
INFO - 2021-01-10 13:48:35 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:35 --> Input Class Initialized
INFO - 2021-01-10 13:48:35 --> Language Class Initialized
INFO - 2021-01-10 13:48:35 --> Language Class Initialized
INFO - 2021-01-10 13:48:35 --> Config Class Initialized
INFO - 2021-01-10 13:48:35 --> Loader Class Initialized
INFO - 2021-01-10 13:48:35 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:35 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:35 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:35 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:35 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:35 --> Controller Class Initialized
DEBUG - 2021-01-10 13:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-10 13:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:48:35 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:35 --> Total execution time: 0.3052
INFO - 2021-01-10 13:48:44 --> Config Class Initialized
INFO - 2021-01-10 13:48:44 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:44 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:44 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:44 --> URI Class Initialized
INFO - 2021-01-10 13:48:44 --> Router Class Initialized
INFO - 2021-01-10 13:48:44 --> Output Class Initialized
INFO - 2021-01-10 13:48:44 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:44 --> Input Class Initialized
INFO - 2021-01-10 13:48:44 --> Language Class Initialized
INFO - 2021-01-10 13:48:44 --> Language Class Initialized
INFO - 2021-01-10 13:48:44 --> Config Class Initialized
INFO - 2021-01-10 13:48:44 --> Loader Class Initialized
INFO - 2021-01-10 13:48:44 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:44 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:44 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:44 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:44 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:44 --> Controller Class Initialized
DEBUG - 2021-01-10 13:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-10 13:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:48:44 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:44 --> Total execution time: 0.2520
INFO - 2021-01-10 13:48:45 --> Config Class Initialized
INFO - 2021-01-10 13:48:45 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:45 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:45 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:45 --> URI Class Initialized
INFO - 2021-01-10 13:48:45 --> Router Class Initialized
INFO - 2021-01-10 13:48:45 --> Output Class Initialized
INFO - 2021-01-10 13:48:45 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:45 --> Input Class Initialized
INFO - 2021-01-10 13:48:45 --> Language Class Initialized
INFO - 2021-01-10 13:48:45 --> Language Class Initialized
INFO - 2021-01-10 13:48:45 --> Config Class Initialized
INFO - 2021-01-10 13:48:45 --> Loader Class Initialized
INFO - 2021-01-10 13:48:45 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:45 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:45 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:45 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:45 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:45 --> Controller Class Initialized
INFO - 2021-01-10 13:48:46 --> Config Class Initialized
INFO - 2021-01-10 13:48:46 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:46 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:46 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:46 --> URI Class Initialized
INFO - 2021-01-10 13:48:46 --> Router Class Initialized
INFO - 2021-01-10 13:48:46 --> Output Class Initialized
INFO - 2021-01-10 13:48:46 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:46 --> Input Class Initialized
INFO - 2021-01-10 13:48:46 --> Language Class Initialized
INFO - 2021-01-10 13:48:46 --> Language Class Initialized
INFO - 2021-01-10 13:48:46 --> Config Class Initialized
INFO - 2021-01-10 13:48:46 --> Loader Class Initialized
INFO - 2021-01-10 13:48:46 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:46 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:46 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:46 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:46 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:46 --> Controller Class Initialized
INFO - 2021-01-10 13:48:46 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:46 --> Total execution time: 0.2688
INFO - 2021-01-10 13:48:57 --> Config Class Initialized
INFO - 2021-01-10 13:48:57 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:57 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:57 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:57 --> URI Class Initialized
INFO - 2021-01-10 13:48:57 --> Router Class Initialized
INFO - 2021-01-10 13:48:57 --> Output Class Initialized
INFO - 2021-01-10 13:48:57 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:57 --> Input Class Initialized
INFO - 2021-01-10 13:48:57 --> Language Class Initialized
INFO - 2021-01-10 13:48:57 --> Language Class Initialized
INFO - 2021-01-10 13:48:57 --> Config Class Initialized
INFO - 2021-01-10 13:48:57 --> Loader Class Initialized
INFO - 2021-01-10 13:48:57 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:57 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:57 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:57 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:57 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:57 --> Controller Class Initialized
INFO - 2021-01-10 13:48:57 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:57 --> Total execution time: 0.2801
INFO - 2021-01-10 13:48:57 --> Config Class Initialized
INFO - 2021-01-10 13:48:57 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:57 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:57 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:57 --> URI Class Initialized
INFO - 2021-01-10 13:48:57 --> Router Class Initialized
INFO - 2021-01-10 13:48:57 --> Output Class Initialized
INFO - 2021-01-10 13:48:57 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:57 --> Input Class Initialized
INFO - 2021-01-10 13:48:57 --> Language Class Initialized
INFO - 2021-01-10 13:48:57 --> Language Class Initialized
INFO - 2021-01-10 13:48:57 --> Config Class Initialized
INFO - 2021-01-10 13:48:57 --> Loader Class Initialized
INFO - 2021-01-10 13:48:57 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:57 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:57 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:57 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:57 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:57 --> Controller Class Initialized
INFO - 2021-01-10 13:48:58 --> Config Class Initialized
INFO - 2021-01-10 13:48:58 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:58 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:58 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:58 --> URI Class Initialized
INFO - 2021-01-10 13:48:58 --> Router Class Initialized
INFO - 2021-01-10 13:48:58 --> Output Class Initialized
INFO - 2021-01-10 13:48:58 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:58 --> Input Class Initialized
INFO - 2021-01-10 13:48:58 --> Language Class Initialized
INFO - 2021-01-10 13:48:58 --> Language Class Initialized
INFO - 2021-01-10 13:48:58 --> Config Class Initialized
INFO - 2021-01-10 13:48:58 --> Loader Class Initialized
INFO - 2021-01-10 13:48:59 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:59 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:59 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:59 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:59 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:59 --> Controller Class Initialized
DEBUG - 2021-01-10 13:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-01-10 13:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:48:59 --> Final output sent to browser
DEBUG - 2021-01-10 13:48:59 --> Total execution time: 0.3378
INFO - 2021-01-10 13:48:59 --> Config Class Initialized
INFO - 2021-01-10 13:48:59 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:48:59 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:48:59 --> Utf8 Class Initialized
INFO - 2021-01-10 13:48:59 --> URI Class Initialized
INFO - 2021-01-10 13:48:59 --> Router Class Initialized
INFO - 2021-01-10 13:48:59 --> Output Class Initialized
INFO - 2021-01-10 13:48:59 --> Security Class Initialized
DEBUG - 2021-01-10 13:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:48:59 --> Input Class Initialized
INFO - 2021-01-10 13:48:59 --> Language Class Initialized
INFO - 2021-01-10 13:48:59 --> Language Class Initialized
INFO - 2021-01-10 13:48:59 --> Config Class Initialized
INFO - 2021-01-10 13:48:59 --> Loader Class Initialized
INFO - 2021-01-10 13:48:59 --> Helper loaded: url_helper
INFO - 2021-01-10 13:48:59 --> Helper loaded: file_helper
INFO - 2021-01-10 13:48:59 --> Helper loaded: form_helper
INFO - 2021-01-10 13:48:59 --> Helper loaded: my_helper
INFO - 2021-01-10 13:48:59 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:48:59 --> Controller Class Initialized
INFO - 2021-01-10 13:49:07 --> Config Class Initialized
INFO - 2021-01-10 13:49:07 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:07 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:07 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:07 --> URI Class Initialized
INFO - 2021-01-10 13:49:08 --> Router Class Initialized
INFO - 2021-01-10 13:49:08 --> Output Class Initialized
INFO - 2021-01-10 13:49:08 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:08 --> Input Class Initialized
INFO - 2021-01-10 13:49:08 --> Language Class Initialized
INFO - 2021-01-10 13:49:08 --> Language Class Initialized
INFO - 2021-01-10 13:49:08 --> Config Class Initialized
INFO - 2021-01-10 13:49:08 --> Loader Class Initialized
INFO - 2021-01-10 13:49:08 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:08 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:08 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:08 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:08 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:08 --> Controller Class Initialized
INFO - 2021-01-10 13:49:08 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:49:08 --> Config Class Initialized
INFO - 2021-01-10 13:49:08 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:08 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:08 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:08 --> URI Class Initialized
INFO - 2021-01-10 13:49:08 --> Router Class Initialized
INFO - 2021-01-10 13:49:08 --> Output Class Initialized
INFO - 2021-01-10 13:49:08 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:08 --> Input Class Initialized
INFO - 2021-01-10 13:49:08 --> Language Class Initialized
INFO - 2021-01-10 13:49:08 --> Language Class Initialized
INFO - 2021-01-10 13:49:08 --> Config Class Initialized
INFO - 2021-01-10 13:49:08 --> Loader Class Initialized
INFO - 2021-01-10 13:49:08 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:08 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:08 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:08 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:08 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:08 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 13:49:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:08 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:08 --> Total execution time: 0.2639
INFO - 2021-01-10 13:49:13 --> Config Class Initialized
INFO - 2021-01-10 13:49:13 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:13 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:13 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:13 --> URI Class Initialized
INFO - 2021-01-10 13:49:13 --> Router Class Initialized
INFO - 2021-01-10 13:49:13 --> Output Class Initialized
INFO - 2021-01-10 13:49:13 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:13 --> Input Class Initialized
INFO - 2021-01-10 13:49:13 --> Language Class Initialized
INFO - 2021-01-10 13:49:13 --> Language Class Initialized
INFO - 2021-01-10 13:49:13 --> Config Class Initialized
INFO - 2021-01-10 13:49:13 --> Loader Class Initialized
INFO - 2021-01-10 13:49:13 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:13 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:13 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:13 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:13 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:14 --> Controller Class Initialized
INFO - 2021-01-10 13:49:14 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:49:14 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:14 --> Total execution time: 0.3614
INFO - 2021-01-10 13:49:14 --> Config Class Initialized
INFO - 2021-01-10 13:49:14 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:14 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:14 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:14 --> URI Class Initialized
INFO - 2021-01-10 13:49:14 --> Router Class Initialized
INFO - 2021-01-10 13:49:14 --> Output Class Initialized
INFO - 2021-01-10 13:49:14 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:14 --> Input Class Initialized
INFO - 2021-01-10 13:49:14 --> Language Class Initialized
INFO - 2021-01-10 13:49:14 --> Language Class Initialized
INFO - 2021-01-10 13:49:14 --> Config Class Initialized
INFO - 2021-01-10 13:49:14 --> Loader Class Initialized
INFO - 2021-01-10 13:49:14 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:14 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:14 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:14 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:14 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:14 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 13:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:14 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:14 --> Total execution time: 0.3598
INFO - 2021-01-10 13:49:16 --> Config Class Initialized
INFO - 2021-01-10 13:49:16 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:16 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:16 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:16 --> URI Class Initialized
INFO - 2021-01-10 13:49:16 --> Router Class Initialized
INFO - 2021-01-10 13:49:16 --> Output Class Initialized
INFO - 2021-01-10 13:49:16 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:16 --> Input Class Initialized
INFO - 2021-01-10 13:49:16 --> Language Class Initialized
INFO - 2021-01-10 13:49:16 --> Language Class Initialized
INFO - 2021-01-10 13:49:16 --> Config Class Initialized
INFO - 2021-01-10 13:49:16 --> Loader Class Initialized
INFO - 2021-01-10 13:49:16 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:16 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:16 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:16 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:16 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:17 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 13:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:17 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:17 --> Total execution time: 0.3050
INFO - 2021-01-10 13:49:18 --> Config Class Initialized
INFO - 2021-01-10 13:49:18 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:18 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:18 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:18 --> URI Class Initialized
INFO - 2021-01-10 13:49:18 --> Router Class Initialized
INFO - 2021-01-10 13:49:18 --> Output Class Initialized
INFO - 2021-01-10 13:49:18 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:18 --> Input Class Initialized
INFO - 2021-01-10 13:49:18 --> Language Class Initialized
INFO - 2021-01-10 13:49:18 --> Language Class Initialized
INFO - 2021-01-10 13:49:18 --> Config Class Initialized
INFO - 2021-01-10 13:49:18 --> Loader Class Initialized
INFO - 2021-01-10 13:49:18 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:18 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:18 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:18 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:18 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:18 --> Controller Class Initialized
ERROR - 2021-01-10 13:49:18 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 13:49:18 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 13:49:18 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 13:49:18 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 13:49:18 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 13:49:18 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 13:49:18 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-10 13:49:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:49:18 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:18 --> Total execution time: 0.3450
INFO - 2021-01-10 13:49:35 --> Config Class Initialized
INFO - 2021-01-10 13:49:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:35 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:35 --> URI Class Initialized
INFO - 2021-01-10 13:49:35 --> Router Class Initialized
INFO - 2021-01-10 13:49:35 --> Output Class Initialized
INFO - 2021-01-10 13:49:35 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:35 --> Input Class Initialized
INFO - 2021-01-10 13:49:35 --> Language Class Initialized
INFO - 2021-01-10 13:49:35 --> Language Class Initialized
INFO - 2021-01-10 13:49:35 --> Config Class Initialized
INFO - 2021-01-10 13:49:35 --> Loader Class Initialized
INFO - 2021-01-10 13:49:35 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:35 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:35 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:35 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:35 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:35 --> Controller Class Initialized
INFO - 2021-01-10 13:49:35 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:49:35 --> Config Class Initialized
INFO - 2021-01-10 13:49:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:35 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:35 --> URI Class Initialized
INFO - 2021-01-10 13:49:35 --> Router Class Initialized
INFO - 2021-01-10 13:49:35 --> Output Class Initialized
INFO - 2021-01-10 13:49:35 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:35 --> Input Class Initialized
INFO - 2021-01-10 13:49:35 --> Language Class Initialized
INFO - 2021-01-10 13:49:35 --> Language Class Initialized
INFO - 2021-01-10 13:49:35 --> Config Class Initialized
INFO - 2021-01-10 13:49:35 --> Loader Class Initialized
INFO - 2021-01-10 13:49:35 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:35 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:35 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:35 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:35 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:35 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-10 13:49:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:35 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:35 --> Total execution time: 0.3307
INFO - 2021-01-10 13:49:40 --> Config Class Initialized
INFO - 2021-01-10 13:49:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:40 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:40 --> URI Class Initialized
INFO - 2021-01-10 13:49:40 --> Router Class Initialized
INFO - 2021-01-10 13:49:40 --> Output Class Initialized
INFO - 2021-01-10 13:49:40 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:40 --> Input Class Initialized
INFO - 2021-01-10 13:49:40 --> Language Class Initialized
INFO - 2021-01-10 13:49:40 --> Language Class Initialized
INFO - 2021-01-10 13:49:40 --> Config Class Initialized
INFO - 2021-01-10 13:49:40 --> Loader Class Initialized
INFO - 2021-01-10 13:49:40 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:40 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:40 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:40 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:40 --> Controller Class Initialized
INFO - 2021-01-10 13:49:40 --> Helper loaded: cookie_helper
INFO - 2021-01-10 13:49:40 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:40 --> Total execution time: 0.3580
INFO - 2021-01-10 13:49:40 --> Config Class Initialized
INFO - 2021-01-10 13:49:41 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:41 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:41 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:41 --> URI Class Initialized
INFO - 2021-01-10 13:49:41 --> Router Class Initialized
INFO - 2021-01-10 13:49:41 --> Output Class Initialized
INFO - 2021-01-10 13:49:41 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:41 --> Input Class Initialized
INFO - 2021-01-10 13:49:41 --> Language Class Initialized
INFO - 2021-01-10 13:49:41 --> Language Class Initialized
INFO - 2021-01-10 13:49:41 --> Config Class Initialized
INFO - 2021-01-10 13:49:41 --> Loader Class Initialized
INFO - 2021-01-10 13:49:41 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:41 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:41 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:41 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:41 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-10 13:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:41 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:41 --> Total execution time: 0.4215
INFO - 2021-01-10 13:49:44 --> Config Class Initialized
INFO - 2021-01-10 13:49:44 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:44 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:44 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:44 --> URI Class Initialized
INFO - 2021-01-10 13:49:44 --> Router Class Initialized
INFO - 2021-01-10 13:49:44 --> Output Class Initialized
INFO - 2021-01-10 13:49:44 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:44 --> Input Class Initialized
INFO - 2021-01-10 13:49:44 --> Language Class Initialized
INFO - 2021-01-10 13:49:44 --> Language Class Initialized
INFO - 2021-01-10 13:49:44 --> Config Class Initialized
INFO - 2021-01-10 13:49:44 --> Loader Class Initialized
INFO - 2021-01-10 13:49:44 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:44 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:44 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:44 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:44 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:44 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 13:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:44 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:44 --> Total execution time: 0.3215
INFO - 2021-01-10 13:49:47 --> Config Class Initialized
INFO - 2021-01-10 13:49:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:48 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:48 --> URI Class Initialized
INFO - 2021-01-10 13:49:48 --> Router Class Initialized
INFO - 2021-01-10 13:49:48 --> Output Class Initialized
INFO - 2021-01-10 13:49:48 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:48 --> Input Class Initialized
INFO - 2021-01-10 13:49:48 --> Language Class Initialized
INFO - 2021-01-10 13:49:48 --> Language Class Initialized
INFO - 2021-01-10 13:49:48 --> Config Class Initialized
INFO - 2021-01-10 13:49:48 --> Loader Class Initialized
INFO - 2021-01-10 13:49:48 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:48 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:48 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:48 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:48 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:48 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-10 13:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:48 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:48 --> Total execution time: 0.2599
INFO - 2021-01-10 13:49:48 --> Config Class Initialized
INFO - 2021-01-10 13:49:48 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:48 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:48 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:48 --> URI Class Initialized
INFO - 2021-01-10 13:49:48 --> Router Class Initialized
INFO - 2021-01-10 13:49:48 --> Output Class Initialized
INFO - 2021-01-10 13:49:48 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:48 --> Input Class Initialized
INFO - 2021-01-10 13:49:48 --> Language Class Initialized
INFO - 2021-01-10 13:49:48 --> Language Class Initialized
INFO - 2021-01-10 13:49:48 --> Config Class Initialized
INFO - 2021-01-10 13:49:48 --> Loader Class Initialized
INFO - 2021-01-10 13:49:48 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:48 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:48 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:48 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:48 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:48 --> Controller Class Initialized
INFO - 2021-01-10 13:49:54 --> Config Class Initialized
INFO - 2021-01-10 13:49:54 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:54 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:54 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:54 --> URI Class Initialized
INFO - 2021-01-10 13:49:54 --> Router Class Initialized
INFO - 2021-01-10 13:49:54 --> Output Class Initialized
INFO - 2021-01-10 13:49:54 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:54 --> Input Class Initialized
INFO - 2021-01-10 13:49:54 --> Language Class Initialized
INFO - 2021-01-10 13:49:54 --> Language Class Initialized
INFO - 2021-01-10 13:49:54 --> Config Class Initialized
INFO - 2021-01-10 13:49:54 --> Loader Class Initialized
INFO - 2021-01-10 13:49:54 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:54 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:54 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:54 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:54 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:54 --> Controller Class Initialized
INFO - 2021-01-10 13:49:54 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:54 --> Total execution time: 0.2459
INFO - 2021-01-10 13:49:58 --> Config Class Initialized
INFO - 2021-01-10 13:49:58 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:49:58 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:49:58 --> Utf8 Class Initialized
INFO - 2021-01-10 13:49:58 --> URI Class Initialized
INFO - 2021-01-10 13:49:58 --> Router Class Initialized
INFO - 2021-01-10 13:49:58 --> Output Class Initialized
INFO - 2021-01-10 13:49:58 --> Security Class Initialized
DEBUG - 2021-01-10 13:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:49:58 --> Input Class Initialized
INFO - 2021-01-10 13:49:58 --> Language Class Initialized
INFO - 2021-01-10 13:49:58 --> Language Class Initialized
INFO - 2021-01-10 13:49:58 --> Config Class Initialized
INFO - 2021-01-10 13:49:58 --> Loader Class Initialized
INFO - 2021-01-10 13:49:58 --> Helper loaded: url_helper
INFO - 2021-01-10 13:49:58 --> Helper loaded: file_helper
INFO - 2021-01-10 13:49:58 --> Helper loaded: form_helper
INFO - 2021-01-10 13:49:58 --> Helper loaded: my_helper
INFO - 2021-01-10 13:49:58 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:49:58 --> Controller Class Initialized
DEBUG - 2021-01-10 13:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 13:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:49:59 --> Final output sent to browser
DEBUG - 2021-01-10 13:49:59 --> Total execution time: 0.3349
INFO - 2021-01-10 13:50:02 --> Config Class Initialized
INFO - 2021-01-10 13:50:02 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:02 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:02 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:02 --> URI Class Initialized
INFO - 2021-01-10 13:50:02 --> Router Class Initialized
INFO - 2021-01-10 13:50:02 --> Output Class Initialized
INFO - 2021-01-10 13:50:02 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:02 --> Input Class Initialized
INFO - 2021-01-10 13:50:02 --> Language Class Initialized
INFO - 2021-01-10 13:50:02 --> Language Class Initialized
INFO - 2021-01-10 13:50:02 --> Config Class Initialized
INFO - 2021-01-10 13:50:02 --> Loader Class Initialized
INFO - 2021-01-10 13:50:02 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:02 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:02 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:02 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:02 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:02 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-10 13:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:02 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:02 --> Total execution time: 0.2785
INFO - 2021-01-10 13:50:02 --> Config Class Initialized
INFO - 2021-01-10 13:50:02 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:02 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:02 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:02 --> URI Class Initialized
INFO - 2021-01-10 13:50:02 --> Router Class Initialized
INFO - 2021-01-10 13:50:02 --> Output Class Initialized
INFO - 2021-01-10 13:50:02 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:02 --> Input Class Initialized
INFO - 2021-01-10 13:50:02 --> Language Class Initialized
INFO - 2021-01-10 13:50:02 --> Language Class Initialized
INFO - 2021-01-10 13:50:02 --> Config Class Initialized
INFO - 2021-01-10 13:50:02 --> Loader Class Initialized
INFO - 2021-01-10 13:50:02 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:02 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:02 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:02 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:03 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:03 --> Controller Class Initialized
INFO - 2021-01-10 13:50:04 --> Config Class Initialized
INFO - 2021-01-10 13:50:04 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:04 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:04 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:04 --> URI Class Initialized
INFO - 2021-01-10 13:50:04 --> Router Class Initialized
INFO - 2021-01-10 13:50:04 --> Output Class Initialized
INFO - 2021-01-10 13:50:04 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:04 --> Input Class Initialized
INFO - 2021-01-10 13:50:04 --> Language Class Initialized
INFO - 2021-01-10 13:50:04 --> Language Class Initialized
INFO - 2021-01-10 13:50:04 --> Config Class Initialized
INFO - 2021-01-10 13:50:04 --> Loader Class Initialized
INFO - 2021-01-10 13:50:04 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:04 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:04 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:04 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:04 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:04 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 13:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:04 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:04 --> Total execution time: 0.2907
INFO - 2021-01-10 13:50:05 --> Config Class Initialized
INFO - 2021-01-10 13:50:05 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:05 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:05 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:05 --> URI Class Initialized
INFO - 2021-01-10 13:50:05 --> Router Class Initialized
INFO - 2021-01-10 13:50:05 --> Output Class Initialized
INFO - 2021-01-10 13:50:05 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:05 --> Input Class Initialized
INFO - 2021-01-10 13:50:05 --> Language Class Initialized
INFO - 2021-01-10 13:50:05 --> Language Class Initialized
INFO - 2021-01-10 13:50:05 --> Config Class Initialized
INFO - 2021-01-10 13:50:05 --> Loader Class Initialized
INFO - 2021-01-10 13:50:05 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:05 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:05 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:05 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:05 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:05 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-10 13:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:06 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:06 --> Total execution time: 0.2781
INFO - 2021-01-10 13:50:06 --> Config Class Initialized
INFO - 2021-01-10 13:50:06 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:06 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:06 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:06 --> URI Class Initialized
INFO - 2021-01-10 13:50:06 --> Router Class Initialized
INFO - 2021-01-10 13:50:06 --> Output Class Initialized
INFO - 2021-01-10 13:50:06 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:06 --> Input Class Initialized
INFO - 2021-01-10 13:50:06 --> Language Class Initialized
INFO - 2021-01-10 13:50:06 --> Language Class Initialized
INFO - 2021-01-10 13:50:06 --> Config Class Initialized
INFO - 2021-01-10 13:50:06 --> Loader Class Initialized
INFO - 2021-01-10 13:50:06 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:06 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:06 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:06 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:06 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:06 --> Controller Class Initialized
INFO - 2021-01-10 13:50:07 --> Config Class Initialized
INFO - 2021-01-10 13:50:07 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:07 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:07 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:07 --> URI Class Initialized
INFO - 2021-01-10 13:50:07 --> Router Class Initialized
INFO - 2021-01-10 13:50:07 --> Output Class Initialized
INFO - 2021-01-10 13:50:07 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:07 --> Input Class Initialized
INFO - 2021-01-10 13:50:07 --> Language Class Initialized
INFO - 2021-01-10 13:50:07 --> Language Class Initialized
INFO - 2021-01-10 13:50:07 --> Config Class Initialized
INFO - 2021-01-10 13:50:07 --> Loader Class Initialized
INFO - 2021-01-10 13:50:07 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:07 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:07 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:07 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:07 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:07 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 13:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:07 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:07 --> Total execution time: 0.3094
INFO - 2021-01-10 13:50:09 --> Config Class Initialized
INFO - 2021-01-10 13:50:09 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:09 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:09 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:09 --> URI Class Initialized
INFO - 2021-01-10 13:50:09 --> Router Class Initialized
INFO - 2021-01-10 13:50:09 --> Output Class Initialized
INFO - 2021-01-10 13:50:09 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:09 --> Input Class Initialized
INFO - 2021-01-10 13:50:09 --> Language Class Initialized
INFO - 2021-01-10 13:50:09 --> Language Class Initialized
INFO - 2021-01-10 13:50:09 --> Config Class Initialized
INFO - 2021-01-10 13:50:09 --> Loader Class Initialized
INFO - 2021-01-10 13:50:09 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:09 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:09 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:09 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:09 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:10 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-10 13:50:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:10 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:10 --> Total execution time: 0.2883
INFO - 2021-01-10 13:50:10 --> Config Class Initialized
INFO - 2021-01-10 13:50:10 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:10 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:10 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:10 --> URI Class Initialized
INFO - 2021-01-10 13:50:10 --> Router Class Initialized
INFO - 2021-01-10 13:50:10 --> Output Class Initialized
INFO - 2021-01-10 13:50:10 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:10 --> Input Class Initialized
INFO - 2021-01-10 13:50:10 --> Language Class Initialized
INFO - 2021-01-10 13:50:10 --> Language Class Initialized
INFO - 2021-01-10 13:50:10 --> Config Class Initialized
INFO - 2021-01-10 13:50:10 --> Loader Class Initialized
INFO - 2021-01-10 13:50:10 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:10 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:10 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:10 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:10 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:10 --> Controller Class Initialized
INFO - 2021-01-10 13:50:11 --> Config Class Initialized
INFO - 2021-01-10 13:50:11 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:11 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:11 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:11 --> URI Class Initialized
INFO - 2021-01-10 13:50:11 --> Router Class Initialized
INFO - 2021-01-10 13:50:11 --> Output Class Initialized
INFO - 2021-01-10 13:50:11 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:11 --> Input Class Initialized
INFO - 2021-01-10 13:50:11 --> Language Class Initialized
INFO - 2021-01-10 13:50:11 --> Language Class Initialized
INFO - 2021-01-10 13:50:11 --> Config Class Initialized
INFO - 2021-01-10 13:50:11 --> Loader Class Initialized
INFO - 2021-01-10 13:50:11 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:11 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:11 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:11 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:11 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:11 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 13:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:12 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:12 --> Total execution time: 0.3316
INFO - 2021-01-10 13:50:15 --> Config Class Initialized
INFO - 2021-01-10 13:50:15 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:15 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:15 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:15 --> URI Class Initialized
INFO - 2021-01-10 13:50:15 --> Router Class Initialized
INFO - 2021-01-10 13:50:15 --> Output Class Initialized
INFO - 2021-01-10 13:50:15 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:15 --> Input Class Initialized
INFO - 2021-01-10 13:50:15 --> Language Class Initialized
INFO - 2021-01-10 13:50:15 --> Language Class Initialized
INFO - 2021-01-10 13:50:15 --> Config Class Initialized
INFO - 2021-01-10 13:50:15 --> Loader Class Initialized
INFO - 2021-01-10 13:50:15 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:15 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:15 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:15 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:15 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:15 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-10 13:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:15 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:16 --> Total execution time: 0.2673
INFO - 2021-01-10 13:50:16 --> Config Class Initialized
INFO - 2021-01-10 13:50:16 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:16 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:16 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:16 --> URI Class Initialized
INFO - 2021-01-10 13:50:16 --> Router Class Initialized
INFO - 2021-01-10 13:50:16 --> Output Class Initialized
INFO - 2021-01-10 13:50:16 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:16 --> Input Class Initialized
INFO - 2021-01-10 13:50:16 --> Language Class Initialized
INFO - 2021-01-10 13:50:16 --> Language Class Initialized
INFO - 2021-01-10 13:50:16 --> Config Class Initialized
INFO - 2021-01-10 13:50:16 --> Loader Class Initialized
INFO - 2021-01-10 13:50:16 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:16 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:16 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:16 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:16 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:16 --> Controller Class Initialized
INFO - 2021-01-10 13:50:17 --> Config Class Initialized
INFO - 2021-01-10 13:50:17 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:17 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:17 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:17 --> URI Class Initialized
INFO - 2021-01-10 13:50:17 --> Router Class Initialized
INFO - 2021-01-10 13:50:17 --> Output Class Initialized
INFO - 2021-01-10 13:50:17 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:17 --> Input Class Initialized
INFO - 2021-01-10 13:50:17 --> Language Class Initialized
INFO - 2021-01-10 13:50:17 --> Language Class Initialized
INFO - 2021-01-10 13:50:17 --> Config Class Initialized
INFO - 2021-01-10 13:50:17 --> Loader Class Initialized
INFO - 2021-01-10 13:50:17 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:17 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:17 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:17 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:17 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:17 --> Controller Class Initialized
INFO - 2021-01-10 13:50:17 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:17 --> Total execution time: 0.2655
INFO - 2021-01-10 13:50:25 --> Config Class Initialized
INFO - 2021-01-10 13:50:25 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:25 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:25 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:25 --> URI Class Initialized
INFO - 2021-01-10 13:50:25 --> Router Class Initialized
INFO - 2021-01-10 13:50:25 --> Output Class Initialized
INFO - 2021-01-10 13:50:25 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:25 --> Input Class Initialized
INFO - 2021-01-10 13:50:25 --> Language Class Initialized
INFO - 2021-01-10 13:50:25 --> Language Class Initialized
INFO - 2021-01-10 13:50:25 --> Config Class Initialized
INFO - 2021-01-10 13:50:25 --> Loader Class Initialized
INFO - 2021-01-10 13:50:25 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:25 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:25 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:25 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:25 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:25 --> Controller Class Initialized
INFO - 2021-01-10 13:50:25 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:25 --> Total execution time: 0.3806
INFO - 2021-01-10 13:50:27 --> Config Class Initialized
INFO - 2021-01-10 13:50:27 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:27 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:27 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:27 --> URI Class Initialized
INFO - 2021-01-10 13:50:27 --> Router Class Initialized
INFO - 2021-01-10 13:50:27 --> Output Class Initialized
INFO - 2021-01-10 13:50:27 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:27 --> Input Class Initialized
INFO - 2021-01-10 13:50:27 --> Language Class Initialized
INFO - 2021-01-10 13:50:27 --> Language Class Initialized
INFO - 2021-01-10 13:50:27 --> Config Class Initialized
INFO - 2021-01-10 13:50:27 --> Loader Class Initialized
INFO - 2021-01-10 13:50:27 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:27 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:27 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:27 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:27 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:27 --> Controller Class Initialized
INFO - 2021-01-10 13:50:27 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:27 --> Total execution time: 0.2478
INFO - 2021-01-10 13:50:31 --> Config Class Initialized
INFO - 2021-01-10 13:50:31 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:31 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:31 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:31 --> URI Class Initialized
INFO - 2021-01-10 13:50:31 --> Router Class Initialized
INFO - 2021-01-10 13:50:31 --> Output Class Initialized
INFO - 2021-01-10 13:50:31 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:31 --> Input Class Initialized
INFO - 2021-01-10 13:50:31 --> Language Class Initialized
INFO - 2021-01-10 13:50:31 --> Language Class Initialized
INFO - 2021-01-10 13:50:31 --> Config Class Initialized
INFO - 2021-01-10 13:50:31 --> Loader Class Initialized
INFO - 2021-01-10 13:50:31 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:31 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:31 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:31 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:31 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:31 --> Controller Class Initialized
INFO - 2021-01-10 13:50:31 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:31 --> Total execution time: 0.4402
INFO - 2021-01-10 13:50:33 --> Config Class Initialized
INFO - 2021-01-10 13:50:33 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:33 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:33 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:33 --> URI Class Initialized
INFO - 2021-01-10 13:50:33 --> Router Class Initialized
INFO - 2021-01-10 13:50:33 --> Output Class Initialized
INFO - 2021-01-10 13:50:33 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:33 --> Input Class Initialized
INFO - 2021-01-10 13:50:33 --> Language Class Initialized
INFO - 2021-01-10 13:50:33 --> Language Class Initialized
INFO - 2021-01-10 13:50:33 --> Config Class Initialized
INFO - 2021-01-10 13:50:33 --> Loader Class Initialized
INFO - 2021-01-10 13:50:33 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:33 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:33 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:33 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:33 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:33 --> Controller Class Initialized
INFO - 2021-01-10 13:50:33 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:33 --> Total execution time: 0.3126
INFO - 2021-01-10 13:50:38 --> Config Class Initialized
INFO - 2021-01-10 13:50:38 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:38 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:38 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:38 --> URI Class Initialized
INFO - 2021-01-10 13:50:38 --> Router Class Initialized
INFO - 2021-01-10 13:50:38 --> Output Class Initialized
INFO - 2021-01-10 13:50:38 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:38 --> Input Class Initialized
INFO - 2021-01-10 13:50:38 --> Language Class Initialized
INFO - 2021-01-10 13:50:38 --> Language Class Initialized
INFO - 2021-01-10 13:50:38 --> Config Class Initialized
INFO - 2021-01-10 13:50:38 --> Loader Class Initialized
INFO - 2021-01-10 13:50:38 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:38 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:38 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:38 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:38 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:38 --> Controller Class Initialized
INFO - 2021-01-10 13:50:38 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:38 --> Total execution time: 0.4563
INFO - 2021-01-10 13:50:40 --> Config Class Initialized
INFO - 2021-01-10 13:50:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:40 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:40 --> URI Class Initialized
INFO - 2021-01-10 13:50:40 --> Router Class Initialized
INFO - 2021-01-10 13:50:40 --> Output Class Initialized
INFO - 2021-01-10 13:50:40 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:40 --> Input Class Initialized
INFO - 2021-01-10 13:50:40 --> Language Class Initialized
INFO - 2021-01-10 13:50:40 --> Language Class Initialized
INFO - 2021-01-10 13:50:40 --> Config Class Initialized
INFO - 2021-01-10 13:50:40 --> Loader Class Initialized
INFO - 2021-01-10 13:50:40 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:40 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:40 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:40 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:40 --> Controller Class Initialized
INFO - 2021-01-10 13:50:40 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:40 --> Total execution time: 0.2829
INFO - 2021-01-10 13:50:44 --> Config Class Initialized
INFO - 2021-01-10 13:50:44 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:44 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:44 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:44 --> URI Class Initialized
INFO - 2021-01-10 13:50:44 --> Router Class Initialized
INFO - 2021-01-10 13:50:44 --> Output Class Initialized
INFO - 2021-01-10 13:50:44 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:44 --> Input Class Initialized
INFO - 2021-01-10 13:50:44 --> Language Class Initialized
INFO - 2021-01-10 13:50:44 --> Language Class Initialized
INFO - 2021-01-10 13:50:44 --> Config Class Initialized
INFO - 2021-01-10 13:50:44 --> Loader Class Initialized
INFO - 2021-01-10 13:50:44 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:44 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:44 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:44 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:44 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:44 --> Controller Class Initialized
INFO - 2021-01-10 13:50:44 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:44 --> Total execution time: 0.4254
INFO - 2021-01-10 13:50:47 --> Config Class Initialized
INFO - 2021-01-10 13:50:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:47 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:47 --> URI Class Initialized
INFO - 2021-01-10 13:50:47 --> Router Class Initialized
INFO - 2021-01-10 13:50:47 --> Output Class Initialized
INFO - 2021-01-10 13:50:47 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:47 --> Input Class Initialized
INFO - 2021-01-10 13:50:47 --> Language Class Initialized
INFO - 2021-01-10 13:50:47 --> Language Class Initialized
INFO - 2021-01-10 13:50:47 --> Config Class Initialized
INFO - 2021-01-10 13:50:47 --> Loader Class Initialized
INFO - 2021-01-10 13:50:47 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:47 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:47 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:47 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:47 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:47 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-10 13:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:47 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:47 --> Total execution time: 0.3238
INFO - 2021-01-10 13:50:50 --> Config Class Initialized
INFO - 2021-01-10 13:50:50 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:50 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:50 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:50 --> URI Class Initialized
INFO - 2021-01-10 13:50:50 --> Router Class Initialized
INFO - 2021-01-10 13:50:50 --> Output Class Initialized
INFO - 2021-01-10 13:50:50 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:50 --> Input Class Initialized
INFO - 2021-01-10 13:50:50 --> Language Class Initialized
INFO - 2021-01-10 13:50:50 --> Language Class Initialized
INFO - 2021-01-10 13:50:50 --> Config Class Initialized
INFO - 2021-01-10 13:50:50 --> Loader Class Initialized
INFO - 2021-01-10 13:50:50 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:50 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:50 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:50 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:50 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:50 --> Controller Class Initialized
DEBUG - 2021-01-10 13:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-10 13:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 13:50:50 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:50 --> Total execution time: 0.2874
INFO - 2021-01-10 13:50:55 --> Config Class Initialized
INFO - 2021-01-10 13:50:55 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:50:55 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:50:55 --> Utf8 Class Initialized
INFO - 2021-01-10 13:50:55 --> URI Class Initialized
INFO - 2021-01-10 13:50:55 --> Router Class Initialized
INFO - 2021-01-10 13:50:55 --> Output Class Initialized
INFO - 2021-01-10 13:50:55 --> Security Class Initialized
DEBUG - 2021-01-10 13:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:50:55 --> Input Class Initialized
INFO - 2021-01-10 13:50:55 --> Language Class Initialized
INFO - 2021-01-10 13:50:55 --> Language Class Initialized
INFO - 2021-01-10 13:50:55 --> Config Class Initialized
INFO - 2021-01-10 13:50:55 --> Loader Class Initialized
INFO - 2021-01-10 13:50:55 --> Helper loaded: url_helper
INFO - 2021-01-10 13:50:55 --> Helper loaded: file_helper
INFO - 2021-01-10 13:50:55 --> Helper loaded: form_helper
INFO - 2021-01-10 13:50:55 --> Helper loaded: my_helper
INFO - 2021-01-10 13:50:55 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:50:55 --> Controller Class Initialized
INFO - 2021-01-10 13:50:55 --> Final output sent to browser
DEBUG - 2021-01-10 13:50:55 --> Total execution time: 0.2245
INFO - 2021-01-10 13:51:00 --> Config Class Initialized
INFO - 2021-01-10 13:51:00 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:51:00 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:51:00 --> Utf8 Class Initialized
INFO - 2021-01-10 13:51:00 --> URI Class Initialized
INFO - 2021-01-10 13:51:00 --> Router Class Initialized
INFO - 2021-01-10 13:51:00 --> Output Class Initialized
INFO - 2021-01-10 13:51:00 --> Security Class Initialized
DEBUG - 2021-01-10 13:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:51:00 --> Input Class Initialized
INFO - 2021-01-10 13:51:00 --> Language Class Initialized
INFO - 2021-01-10 13:51:00 --> Language Class Initialized
INFO - 2021-01-10 13:51:00 --> Config Class Initialized
INFO - 2021-01-10 13:51:00 --> Loader Class Initialized
INFO - 2021-01-10 13:51:00 --> Helper loaded: url_helper
INFO - 2021-01-10 13:51:00 --> Helper loaded: file_helper
INFO - 2021-01-10 13:51:00 --> Helper loaded: form_helper
INFO - 2021-01-10 13:51:00 --> Helper loaded: my_helper
INFO - 2021-01-10 13:51:00 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:51:00 --> Controller Class Initialized
INFO - 2021-01-10 13:51:00 --> Final output sent to browser
DEBUG - 2021-01-10 13:51:00 --> Total execution time: 0.3717
INFO - 2021-01-10 13:51:02 --> Config Class Initialized
INFO - 2021-01-10 13:51:02 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:51:02 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:51:02 --> Utf8 Class Initialized
INFO - 2021-01-10 13:51:02 --> URI Class Initialized
INFO - 2021-01-10 13:51:02 --> Router Class Initialized
INFO - 2021-01-10 13:51:02 --> Output Class Initialized
INFO - 2021-01-10 13:51:02 --> Security Class Initialized
DEBUG - 2021-01-10 13:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:51:02 --> Input Class Initialized
INFO - 2021-01-10 13:51:02 --> Language Class Initialized
INFO - 2021-01-10 13:51:02 --> Language Class Initialized
INFO - 2021-01-10 13:51:02 --> Config Class Initialized
INFO - 2021-01-10 13:51:02 --> Loader Class Initialized
INFO - 2021-01-10 13:51:02 --> Helper loaded: url_helper
INFO - 2021-01-10 13:51:02 --> Helper loaded: file_helper
INFO - 2021-01-10 13:51:02 --> Helper loaded: form_helper
INFO - 2021-01-10 13:51:02 --> Helper loaded: my_helper
INFO - 2021-01-10 13:51:02 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:51:02 --> Controller Class Initialized
INFO - 2021-01-10 13:51:02 --> Final output sent to browser
DEBUG - 2021-01-10 13:51:02 --> Total execution time: 0.2493
INFO - 2021-01-10 13:51:06 --> Config Class Initialized
INFO - 2021-01-10 13:51:06 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:51:06 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:51:06 --> Utf8 Class Initialized
INFO - 2021-01-10 13:51:06 --> URI Class Initialized
INFO - 2021-01-10 13:51:06 --> Router Class Initialized
INFO - 2021-01-10 13:51:06 --> Output Class Initialized
INFO - 2021-01-10 13:51:06 --> Security Class Initialized
DEBUG - 2021-01-10 13:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:51:06 --> Input Class Initialized
INFO - 2021-01-10 13:51:06 --> Language Class Initialized
INFO - 2021-01-10 13:51:06 --> Language Class Initialized
INFO - 2021-01-10 13:51:06 --> Config Class Initialized
INFO - 2021-01-10 13:51:06 --> Loader Class Initialized
INFO - 2021-01-10 13:51:06 --> Helper loaded: url_helper
INFO - 2021-01-10 13:51:06 --> Helper loaded: file_helper
INFO - 2021-01-10 13:51:06 --> Helper loaded: form_helper
INFO - 2021-01-10 13:51:06 --> Helper loaded: my_helper
INFO - 2021-01-10 13:51:06 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:51:06 --> Controller Class Initialized
INFO - 2021-01-10 13:51:06 --> Final output sent to browser
DEBUG - 2021-01-10 13:51:06 --> Total execution time: 0.3829
INFO - 2021-01-10 13:51:12 --> Config Class Initialized
INFO - 2021-01-10 13:51:12 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:51:12 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:51:12 --> Utf8 Class Initialized
INFO - 2021-01-10 13:51:12 --> URI Class Initialized
INFO - 2021-01-10 13:51:12 --> Router Class Initialized
INFO - 2021-01-10 13:51:12 --> Output Class Initialized
INFO - 2021-01-10 13:51:12 --> Security Class Initialized
DEBUG - 2021-01-10 13:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:51:12 --> Input Class Initialized
INFO - 2021-01-10 13:51:12 --> Language Class Initialized
INFO - 2021-01-10 13:51:12 --> Language Class Initialized
INFO - 2021-01-10 13:51:12 --> Config Class Initialized
INFO - 2021-01-10 13:51:12 --> Loader Class Initialized
INFO - 2021-01-10 13:51:12 --> Helper loaded: url_helper
INFO - 2021-01-10 13:51:12 --> Helper loaded: file_helper
INFO - 2021-01-10 13:51:12 --> Helper loaded: form_helper
INFO - 2021-01-10 13:51:12 --> Helper loaded: my_helper
INFO - 2021-01-10 13:51:12 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:51:13 --> Controller Class Initialized
DEBUG - 2021-01-10 13:51:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:51:13 --> Final output sent to browser
DEBUG - 2021-01-10 13:51:13 --> Total execution time: 0.2836
INFO - 2021-01-10 13:53:24 --> Config Class Initialized
INFO - 2021-01-10 13:53:24 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:53:25 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:53:25 --> Utf8 Class Initialized
INFO - 2021-01-10 13:53:25 --> URI Class Initialized
INFO - 2021-01-10 13:53:25 --> Router Class Initialized
INFO - 2021-01-10 13:53:25 --> Output Class Initialized
INFO - 2021-01-10 13:53:25 --> Security Class Initialized
DEBUG - 2021-01-10 13:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:53:25 --> Input Class Initialized
INFO - 2021-01-10 13:53:25 --> Language Class Initialized
INFO - 2021-01-10 13:53:25 --> Language Class Initialized
INFO - 2021-01-10 13:53:25 --> Config Class Initialized
INFO - 2021-01-10 13:53:25 --> Loader Class Initialized
INFO - 2021-01-10 13:53:25 --> Helper loaded: url_helper
INFO - 2021-01-10 13:53:25 --> Helper loaded: file_helper
INFO - 2021-01-10 13:53:25 --> Helper loaded: form_helper
INFO - 2021-01-10 13:53:25 --> Helper loaded: my_helper
INFO - 2021-01-10 13:53:25 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:53:25 --> Controller Class Initialized
DEBUG - 2021-01-10 13:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:53:25 --> Final output sent to browser
DEBUG - 2021-01-10 13:53:25 --> Total execution time: 0.3439
INFO - 2021-01-10 13:53:44 --> Config Class Initialized
INFO - 2021-01-10 13:53:44 --> Hooks Class Initialized
DEBUG - 2021-01-10 13:53:44 --> UTF-8 Support Enabled
INFO - 2021-01-10 13:53:44 --> Utf8 Class Initialized
INFO - 2021-01-10 13:53:44 --> URI Class Initialized
INFO - 2021-01-10 13:53:44 --> Router Class Initialized
INFO - 2021-01-10 13:53:44 --> Output Class Initialized
INFO - 2021-01-10 13:53:44 --> Security Class Initialized
DEBUG - 2021-01-10 13:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 13:53:44 --> Input Class Initialized
INFO - 2021-01-10 13:53:44 --> Language Class Initialized
INFO - 2021-01-10 13:53:44 --> Language Class Initialized
INFO - 2021-01-10 13:53:44 --> Config Class Initialized
INFO - 2021-01-10 13:53:44 --> Loader Class Initialized
INFO - 2021-01-10 13:53:44 --> Helper loaded: url_helper
INFO - 2021-01-10 13:53:44 --> Helper loaded: file_helper
INFO - 2021-01-10 13:53:44 --> Helper loaded: form_helper
INFO - 2021-01-10 13:53:44 --> Helper loaded: my_helper
INFO - 2021-01-10 13:53:44 --> Database Driver Class Initialized
DEBUG - 2021-01-10 13:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 13:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 13:53:44 --> Controller Class Initialized
DEBUG - 2021-01-10 13:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 13:53:44 --> Final output sent to browser
DEBUG - 2021-01-10 13:53:44 --> Total execution time: 0.3208
INFO - 2021-01-10 14:37:55 --> Config Class Initialized
INFO - 2021-01-10 14:37:55 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:37:55 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:37:55 --> Utf8 Class Initialized
INFO - 2021-01-10 14:37:55 --> URI Class Initialized
INFO - 2021-01-10 14:37:55 --> Router Class Initialized
INFO - 2021-01-10 14:37:55 --> Output Class Initialized
INFO - 2021-01-10 14:37:55 --> Security Class Initialized
DEBUG - 2021-01-10 14:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:37:55 --> Input Class Initialized
INFO - 2021-01-10 14:37:55 --> Language Class Initialized
INFO - 2021-01-10 14:37:55 --> Language Class Initialized
INFO - 2021-01-10 14:37:55 --> Config Class Initialized
INFO - 2021-01-10 14:37:55 --> Loader Class Initialized
INFO - 2021-01-10 14:37:55 --> Helper loaded: url_helper
INFO - 2021-01-10 14:37:55 --> Helper loaded: file_helper
INFO - 2021-01-10 14:37:55 --> Helper loaded: form_helper
INFO - 2021-01-10 14:37:55 --> Helper loaded: my_helper
INFO - 2021-01-10 14:37:55 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:37:55 --> Controller Class Initialized
DEBUG - 2021-01-10 14:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 14:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 14:37:55 --> Final output sent to browser
DEBUG - 2021-01-10 14:37:55 --> Total execution time: 0.8351
INFO - 2021-01-10 14:37:57 --> Config Class Initialized
INFO - 2021-01-10 14:37:57 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:37:57 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:37:57 --> Utf8 Class Initialized
INFO - 2021-01-10 14:37:57 --> URI Class Initialized
INFO - 2021-01-10 14:37:57 --> Router Class Initialized
INFO - 2021-01-10 14:37:57 --> Output Class Initialized
INFO - 2021-01-10 14:37:57 --> Security Class Initialized
DEBUG - 2021-01-10 14:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:37:57 --> Input Class Initialized
INFO - 2021-01-10 14:37:57 --> Language Class Initialized
ERROR - 2021-01-10 14:37:57 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/2571
INFO - 2021-01-10 14:38:16 --> Config Class Initialized
INFO - 2021-01-10 14:38:16 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:38:16 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:38:16 --> Utf8 Class Initialized
INFO - 2021-01-10 14:38:16 --> URI Class Initialized
INFO - 2021-01-10 14:38:16 --> Router Class Initialized
INFO - 2021-01-10 14:38:16 --> Output Class Initialized
INFO - 2021-01-10 14:38:16 --> Security Class Initialized
DEBUG - 2021-01-10 14:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:38:16 --> Input Class Initialized
INFO - 2021-01-10 14:38:16 --> Language Class Initialized
INFO - 2021-01-10 14:38:16 --> Language Class Initialized
INFO - 2021-01-10 14:38:16 --> Config Class Initialized
INFO - 2021-01-10 14:38:16 --> Loader Class Initialized
INFO - 2021-01-10 14:38:16 --> Helper loaded: url_helper
INFO - 2021-01-10 14:38:16 --> Helper loaded: file_helper
INFO - 2021-01-10 14:38:16 --> Helper loaded: form_helper
INFO - 2021-01-10 14:38:16 --> Helper loaded: my_helper
INFO - 2021-01-10 14:38:16 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:38:16 --> Controller Class Initialized
DEBUG - 2021-01-10 14:38:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 14:38:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 14:38:16 --> Final output sent to browser
DEBUG - 2021-01-10 14:38:16 --> Total execution time: 0.7755
INFO - 2021-01-10 14:38:18 --> Config Class Initialized
INFO - 2021-01-10 14:38:18 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:38:18 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:38:18 --> Utf8 Class Initialized
INFO - 2021-01-10 14:38:18 --> URI Class Initialized
INFO - 2021-01-10 14:38:18 --> Router Class Initialized
INFO - 2021-01-10 14:38:18 --> Output Class Initialized
INFO - 2021-01-10 14:38:18 --> Security Class Initialized
DEBUG - 2021-01-10 14:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:38:18 --> Input Class Initialized
INFO - 2021-01-10 14:38:18 --> Language Class Initialized
INFO - 2021-01-10 14:38:18 --> Language Class Initialized
INFO - 2021-01-10 14:38:18 --> Config Class Initialized
INFO - 2021-01-10 14:38:18 --> Loader Class Initialized
INFO - 2021-01-10 14:38:18 --> Helper loaded: url_helper
INFO - 2021-01-10 14:38:18 --> Helper loaded: file_helper
INFO - 2021-01-10 14:38:18 --> Helper loaded: form_helper
INFO - 2021-01-10 14:38:18 --> Helper loaded: my_helper
INFO - 2021-01-10 14:38:18 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:38:18 --> Controller Class Initialized
ERROR - 2021-01-10 14:38:18 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:38:18 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:38:18 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 14:38:18 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 14:38:18 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:38:19 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:38:19 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-10 14:38:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:38:19 --> Final output sent to browser
DEBUG - 2021-01-10 14:38:19 --> Total execution time: 0.9477
INFO - 2021-01-10 14:39:09 --> Config Class Initialized
INFO - 2021-01-10 14:39:09 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:39:09 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:39:09 --> Utf8 Class Initialized
INFO - 2021-01-10 14:39:09 --> URI Class Initialized
INFO - 2021-01-10 14:39:09 --> Router Class Initialized
INFO - 2021-01-10 14:39:09 --> Output Class Initialized
INFO - 2021-01-10 14:39:09 --> Security Class Initialized
DEBUG - 2021-01-10 14:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:39:09 --> Input Class Initialized
INFO - 2021-01-10 14:39:09 --> Language Class Initialized
INFO - 2021-01-10 14:39:09 --> Language Class Initialized
INFO - 2021-01-10 14:39:09 --> Config Class Initialized
INFO - 2021-01-10 14:39:09 --> Loader Class Initialized
INFO - 2021-01-10 14:39:09 --> Helper loaded: url_helper
INFO - 2021-01-10 14:39:09 --> Helper loaded: file_helper
INFO - 2021-01-10 14:39:09 --> Helper loaded: form_helper
INFO - 2021-01-10 14:39:09 --> Helper loaded: my_helper
INFO - 2021-01-10 14:39:10 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:39:10 --> Controller Class Initialized
ERROR - 2021-01-10 14:39:10 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:39:10 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:39:10 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 14:39:10 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 14:39:10 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:39:10 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:39:10 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-10 14:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:39:10 --> Final output sent to browser
DEBUG - 2021-01-10 14:39:10 --> Total execution time: 0.9070
INFO - 2021-01-10 14:39:34 --> Config Class Initialized
INFO - 2021-01-10 14:39:34 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:39:34 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:39:34 --> Utf8 Class Initialized
INFO - 2021-01-10 14:39:34 --> URI Class Initialized
INFO - 2021-01-10 14:39:34 --> Router Class Initialized
INFO - 2021-01-10 14:39:34 --> Output Class Initialized
INFO - 2021-01-10 14:39:34 --> Security Class Initialized
DEBUG - 2021-01-10 14:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:39:34 --> Input Class Initialized
INFO - 2021-01-10 14:39:34 --> Language Class Initialized
INFO - 2021-01-10 14:39:34 --> Language Class Initialized
INFO - 2021-01-10 14:39:34 --> Config Class Initialized
INFO - 2021-01-10 14:39:34 --> Loader Class Initialized
INFO - 2021-01-10 14:39:34 --> Helper loaded: url_helper
INFO - 2021-01-10 14:39:34 --> Helper loaded: file_helper
INFO - 2021-01-10 14:39:34 --> Helper loaded: form_helper
INFO - 2021-01-10 14:39:34 --> Helper loaded: my_helper
INFO - 2021-01-10 14:39:34 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:39:34 --> Controller Class Initialized
DEBUG - 2021-01-10 14:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 14:39:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 14:39:35 --> Final output sent to browser
DEBUG - 2021-01-10 14:39:35 --> Total execution time: 1.0685
INFO - 2021-01-10 14:39:36 --> Config Class Initialized
INFO - 2021-01-10 14:39:36 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:39:36 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:39:36 --> Utf8 Class Initialized
INFO - 2021-01-10 14:39:36 --> URI Class Initialized
INFO - 2021-01-10 14:39:36 --> Router Class Initialized
INFO - 2021-01-10 14:39:36 --> Output Class Initialized
INFO - 2021-01-10 14:39:36 --> Security Class Initialized
DEBUG - 2021-01-10 14:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:39:36 --> Input Class Initialized
INFO - 2021-01-10 14:39:36 --> Language Class Initialized
ERROR - 2021-01-10 14:39:36 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/2571
INFO - 2021-01-10 14:44:29 --> Config Class Initialized
INFO - 2021-01-10 14:44:29 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:44:29 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:44:29 --> Utf8 Class Initialized
INFO - 2021-01-10 14:44:29 --> URI Class Initialized
INFO - 2021-01-10 14:44:29 --> Router Class Initialized
INFO - 2021-01-10 14:44:29 --> Output Class Initialized
INFO - 2021-01-10 14:44:29 --> Security Class Initialized
DEBUG - 2021-01-10 14:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:44:29 --> Input Class Initialized
INFO - 2021-01-10 14:44:29 --> Language Class Initialized
INFO - 2021-01-10 14:44:29 --> Language Class Initialized
INFO - 2021-01-10 14:44:29 --> Config Class Initialized
INFO - 2021-01-10 14:44:29 --> Loader Class Initialized
INFO - 2021-01-10 14:44:29 --> Helper loaded: url_helper
INFO - 2021-01-10 14:44:29 --> Helper loaded: file_helper
INFO - 2021-01-10 14:44:29 --> Helper loaded: form_helper
INFO - 2021-01-10 14:44:29 --> Helper loaded: my_helper
INFO - 2021-01-10 14:44:30 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:44:30 --> Controller Class Initialized
DEBUG - 2021-01-10 14:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:44:30 --> Final output sent to browser
DEBUG - 2021-01-10 14:44:30 --> Total execution time: 0.9354
INFO - 2021-01-10 14:44:41 --> Config Class Initialized
INFO - 2021-01-10 14:44:41 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:44:41 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:44:41 --> Utf8 Class Initialized
INFO - 2021-01-10 14:44:41 --> URI Class Initialized
INFO - 2021-01-10 14:44:41 --> Router Class Initialized
INFO - 2021-01-10 14:44:41 --> Output Class Initialized
INFO - 2021-01-10 14:44:41 --> Security Class Initialized
DEBUG - 2021-01-10 14:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:44:41 --> Input Class Initialized
INFO - 2021-01-10 14:44:41 --> Language Class Initialized
INFO - 2021-01-10 14:44:41 --> Language Class Initialized
INFO - 2021-01-10 14:44:41 --> Config Class Initialized
INFO - 2021-01-10 14:44:41 --> Loader Class Initialized
INFO - 2021-01-10 14:44:41 --> Helper loaded: url_helper
INFO - 2021-01-10 14:44:41 --> Helper loaded: file_helper
INFO - 2021-01-10 14:44:41 --> Helper loaded: form_helper
INFO - 2021-01-10 14:44:41 --> Helper loaded: my_helper
INFO - 2021-01-10 14:44:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:44:41 --> Controller Class Initialized
DEBUG - 2021-01-10 14:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:44:42 --> Final output sent to browser
DEBUG - 2021-01-10 14:44:42 --> Total execution time: 1.1459
INFO - 2021-01-10 14:45:04 --> Config Class Initialized
INFO - 2021-01-10 14:45:04 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:04 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:04 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:04 --> URI Class Initialized
INFO - 2021-01-10 14:45:04 --> Router Class Initialized
INFO - 2021-01-10 14:45:05 --> Output Class Initialized
INFO - 2021-01-10 14:45:05 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:05 --> Input Class Initialized
INFO - 2021-01-10 14:45:05 --> Language Class Initialized
ERROR - 2021-01-10 14:45:05 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/2571
INFO - 2021-01-10 14:45:07 --> Config Class Initialized
INFO - 2021-01-10 14:45:07 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:07 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:07 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:07 --> URI Class Initialized
INFO - 2021-01-10 14:45:07 --> Router Class Initialized
INFO - 2021-01-10 14:45:07 --> Output Class Initialized
INFO - 2021-01-10 14:45:07 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:07 --> Input Class Initialized
INFO - 2021-01-10 14:45:07 --> Language Class Initialized
INFO - 2021-01-10 14:45:07 --> Language Class Initialized
INFO - 2021-01-10 14:45:07 --> Config Class Initialized
INFO - 2021-01-10 14:45:07 --> Loader Class Initialized
INFO - 2021-01-10 14:45:07 --> Helper loaded: url_helper
INFO - 2021-01-10 14:45:07 --> Helper loaded: file_helper
INFO - 2021-01-10 14:45:07 --> Helper loaded: form_helper
INFO - 2021-01-10 14:45:07 --> Helper loaded: my_helper
INFO - 2021-01-10 14:45:07 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:45:07 --> Controller Class Initialized
ERROR - 2021-01-10 14:45:08 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:45:08 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:45:08 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 14:45:08 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 14:45:08 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:45:08 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:45:08 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-10 14:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:45:08 --> Final output sent to browser
DEBUG - 2021-01-10 14:45:08 --> Total execution time: 1.3644
INFO - 2021-01-10 14:45:10 --> Config Class Initialized
INFO - 2021-01-10 14:45:10 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:10 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:10 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:10 --> URI Class Initialized
INFO - 2021-01-10 14:45:10 --> Router Class Initialized
INFO - 2021-01-10 14:45:10 --> Output Class Initialized
INFO - 2021-01-10 14:45:11 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:11 --> Input Class Initialized
INFO - 2021-01-10 14:45:11 --> Language Class Initialized
INFO - 2021-01-10 14:45:11 --> Language Class Initialized
INFO - 2021-01-10 14:45:11 --> Config Class Initialized
INFO - 2021-01-10 14:45:11 --> Loader Class Initialized
INFO - 2021-01-10 14:45:11 --> Helper loaded: url_helper
INFO - 2021-01-10 14:45:11 --> Helper loaded: file_helper
INFO - 2021-01-10 14:45:11 --> Helper loaded: form_helper
INFO - 2021-01-10 14:45:11 --> Helper loaded: my_helper
INFO - 2021-01-10 14:45:11 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:45:11 --> Controller Class Initialized
DEBUG - 2021-01-10 14:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:45:11 --> Final output sent to browser
DEBUG - 2021-01-10 14:45:11 --> Total execution time: 0.8866
INFO - 2021-01-10 14:45:26 --> Config Class Initialized
INFO - 2021-01-10 14:45:26 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:26 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:26 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:26 --> URI Class Initialized
INFO - 2021-01-10 14:45:26 --> Router Class Initialized
INFO - 2021-01-10 14:45:26 --> Output Class Initialized
INFO - 2021-01-10 14:45:26 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:26 --> Input Class Initialized
INFO - 2021-01-10 14:45:26 --> Language Class Initialized
INFO - 2021-01-10 14:45:26 --> Language Class Initialized
INFO - 2021-01-10 14:45:26 --> Config Class Initialized
INFO - 2021-01-10 14:45:26 --> Loader Class Initialized
INFO - 2021-01-10 14:45:26 --> Helper loaded: url_helper
INFO - 2021-01-10 14:45:26 --> Helper loaded: file_helper
INFO - 2021-01-10 14:45:26 --> Helper loaded: form_helper
INFO - 2021-01-10 14:45:26 --> Helper loaded: my_helper
INFO - 2021-01-10 14:45:26 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:45:27 --> Controller Class Initialized
DEBUG - 2021-01-10 14:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 14:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 14:45:27 --> Final output sent to browser
DEBUG - 2021-01-10 14:45:27 --> Total execution time: 0.9499
INFO - 2021-01-10 14:45:28 --> Config Class Initialized
INFO - 2021-01-10 14:45:28 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:28 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:28 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:28 --> URI Class Initialized
INFO - 2021-01-10 14:45:28 --> Router Class Initialized
INFO - 2021-01-10 14:45:28 --> Output Class Initialized
INFO - 2021-01-10 14:45:28 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:28 --> Input Class Initialized
INFO - 2021-01-10 14:45:28 --> Language Class Initialized
ERROR - 2021-01-10 14:45:28 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/2571
INFO - 2021-01-10 14:45:41 --> Config Class Initialized
INFO - 2021-01-10 14:45:41 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:41 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:41 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:41 --> URI Class Initialized
INFO - 2021-01-10 14:45:41 --> Router Class Initialized
INFO - 2021-01-10 14:45:41 --> Output Class Initialized
INFO - 2021-01-10 14:45:41 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:41 --> Input Class Initialized
INFO - 2021-01-10 14:45:41 --> Language Class Initialized
INFO - 2021-01-10 14:45:41 --> Language Class Initialized
INFO - 2021-01-10 14:45:41 --> Config Class Initialized
INFO - 2021-01-10 14:45:41 --> Loader Class Initialized
INFO - 2021-01-10 14:45:41 --> Helper loaded: url_helper
INFO - 2021-01-10 14:45:42 --> Helper loaded: file_helper
INFO - 2021-01-10 14:45:42 --> Helper loaded: form_helper
INFO - 2021-01-10 14:45:42 --> Helper loaded: my_helper
INFO - 2021-01-10 14:45:42 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:45:42 --> Controller Class Initialized
DEBUG - 2021-01-10 14:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 14:45:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 14:45:42 --> Final output sent to browser
DEBUG - 2021-01-10 14:45:42 --> Total execution time: 1.2621
INFO - 2021-01-10 14:45:43 --> Config Class Initialized
INFO - 2021-01-10 14:45:43 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:45:43 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:45:43 --> Utf8 Class Initialized
INFO - 2021-01-10 14:45:43 --> URI Class Initialized
INFO - 2021-01-10 14:45:43 --> Router Class Initialized
INFO - 2021-01-10 14:45:43 --> Output Class Initialized
INFO - 2021-01-10 14:45:43 --> Security Class Initialized
DEBUG - 2021-01-10 14:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:45:43 --> Input Class Initialized
INFO - 2021-01-10 14:45:43 --> Language Class Initialized
INFO - 2021-01-10 14:45:43 --> Language Class Initialized
INFO - 2021-01-10 14:45:43 --> Config Class Initialized
INFO - 2021-01-10 14:45:43 --> Loader Class Initialized
INFO - 2021-01-10 14:45:43 --> Helper loaded: url_helper
INFO - 2021-01-10 14:45:43 --> Helper loaded: file_helper
INFO - 2021-01-10 14:45:43 --> Helper loaded: form_helper
INFO - 2021-01-10 14:45:43 --> Helper loaded: my_helper
INFO - 2021-01-10 14:45:43 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:45:43 --> Controller Class Initialized
ERROR - 2021-01-10 14:45:44 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:45:44 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 14:45:44 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 14:45:44 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 14:45:44 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:45:44 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 14:45:44 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-10 14:45:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:45:44 --> Final output sent to browser
DEBUG - 2021-01-10 14:45:44 --> Total execution time: 1.0442
INFO - 2021-01-10 14:53:50 --> Config Class Initialized
INFO - 2021-01-10 14:53:50 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:53:50 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:53:50 --> Utf8 Class Initialized
INFO - 2021-01-10 14:53:50 --> URI Class Initialized
INFO - 2021-01-10 14:53:50 --> Router Class Initialized
INFO - 2021-01-10 14:53:50 --> Output Class Initialized
INFO - 2021-01-10 14:53:50 --> Security Class Initialized
DEBUG - 2021-01-10 14:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:53:50 --> Input Class Initialized
INFO - 2021-01-10 14:53:50 --> Language Class Initialized
INFO - 2021-01-10 14:53:50 --> Language Class Initialized
INFO - 2021-01-10 14:53:50 --> Config Class Initialized
INFO - 2021-01-10 14:53:50 --> Loader Class Initialized
INFO - 2021-01-10 14:53:50 --> Helper loaded: url_helper
INFO - 2021-01-10 14:53:51 --> Helper loaded: file_helper
INFO - 2021-01-10 14:53:51 --> Helper loaded: form_helper
INFO - 2021-01-10 14:53:51 --> Helper loaded: my_helper
INFO - 2021-01-10 14:53:51 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:53:51 --> Controller Class Initialized
DEBUG - 2021-01-10 14:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:53:51 --> Final output sent to browser
DEBUG - 2021-01-10 14:53:51 --> Total execution time: 0.9783
INFO - 2021-01-10 14:54:54 --> Config Class Initialized
INFO - 2021-01-10 14:54:54 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:54:54 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:54:54 --> Utf8 Class Initialized
INFO - 2021-01-10 14:54:54 --> URI Class Initialized
INFO - 2021-01-10 14:54:54 --> Router Class Initialized
INFO - 2021-01-10 14:54:55 --> Output Class Initialized
INFO - 2021-01-10 14:54:55 --> Security Class Initialized
DEBUG - 2021-01-10 14:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:54:55 --> Input Class Initialized
INFO - 2021-01-10 14:54:55 --> Language Class Initialized
INFO - 2021-01-10 14:54:55 --> Language Class Initialized
INFO - 2021-01-10 14:54:55 --> Config Class Initialized
INFO - 2021-01-10 14:54:55 --> Loader Class Initialized
INFO - 2021-01-10 14:54:55 --> Helper loaded: url_helper
INFO - 2021-01-10 14:54:55 --> Helper loaded: file_helper
INFO - 2021-01-10 14:54:55 --> Helper loaded: form_helper
INFO - 2021-01-10 14:54:55 --> Helper loaded: my_helper
INFO - 2021-01-10 14:54:55 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:54:55 --> Controller Class Initialized
DEBUG - 2021-01-10 14:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:54:55 --> Final output sent to browser
DEBUG - 2021-01-10 14:54:55 --> Total execution time: 0.7566
INFO - 2021-01-10 14:55:51 --> Config Class Initialized
INFO - 2021-01-10 14:55:51 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:55:51 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:55:51 --> Utf8 Class Initialized
INFO - 2021-01-10 14:55:51 --> URI Class Initialized
INFO - 2021-01-10 14:55:52 --> Router Class Initialized
INFO - 2021-01-10 14:55:52 --> Output Class Initialized
INFO - 2021-01-10 14:55:52 --> Security Class Initialized
DEBUG - 2021-01-10 14:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:55:52 --> Input Class Initialized
INFO - 2021-01-10 14:55:52 --> Language Class Initialized
INFO - 2021-01-10 14:55:52 --> Language Class Initialized
INFO - 2021-01-10 14:55:52 --> Config Class Initialized
INFO - 2021-01-10 14:55:52 --> Loader Class Initialized
INFO - 2021-01-10 14:55:52 --> Helper loaded: url_helper
INFO - 2021-01-10 14:55:52 --> Helper loaded: file_helper
INFO - 2021-01-10 14:55:52 --> Helper loaded: form_helper
INFO - 2021-01-10 14:55:52 --> Helper loaded: my_helper
INFO - 2021-01-10 14:55:52 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:55:52 --> Controller Class Initialized
ERROR - 2021-01-10 14:55:52 --> Severity: Notice --> Undefined index: nilai_utama_10 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 453
DEBUG - 2021-01-10 14:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:55:52 --> Final output sent to browser
DEBUG - 2021-01-10 14:55:52 --> Total execution time: 0.9173
INFO - 2021-01-10 14:56:39 --> Config Class Initialized
INFO - 2021-01-10 14:56:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:56:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:56:39 --> Utf8 Class Initialized
INFO - 2021-01-10 14:56:39 --> URI Class Initialized
INFO - 2021-01-10 14:56:39 --> Router Class Initialized
INFO - 2021-01-10 14:56:39 --> Output Class Initialized
INFO - 2021-01-10 14:56:40 --> Security Class Initialized
DEBUG - 2021-01-10 14:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:56:40 --> Input Class Initialized
INFO - 2021-01-10 14:56:40 --> Language Class Initialized
INFO - 2021-01-10 14:56:40 --> Language Class Initialized
INFO - 2021-01-10 14:56:40 --> Config Class Initialized
INFO - 2021-01-10 14:56:40 --> Loader Class Initialized
INFO - 2021-01-10 14:56:40 --> Helper loaded: url_helper
INFO - 2021-01-10 14:56:40 --> Helper loaded: file_helper
INFO - 2021-01-10 14:56:40 --> Helper loaded: form_helper
INFO - 2021-01-10 14:56:40 --> Helper loaded: my_helper
INFO - 2021-01-10 14:56:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:56:40 --> Controller Class Initialized
ERROR - 2021-01-10 14:56:40 --> Severity: Notice --> Undefined index: nilai_utama_10 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 453
DEBUG - 2021-01-10 14:56:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:56:40 --> Final output sent to browser
DEBUG - 2021-01-10 14:56:40 --> Total execution time: 0.9847
INFO - 2021-01-10 14:57:41 --> Config Class Initialized
INFO - 2021-01-10 14:57:41 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:57:41 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:57:41 --> Utf8 Class Initialized
INFO - 2021-01-10 14:57:41 --> URI Class Initialized
INFO - 2021-01-10 14:57:41 --> Router Class Initialized
INFO - 2021-01-10 14:57:41 --> Output Class Initialized
INFO - 2021-01-10 14:57:41 --> Security Class Initialized
DEBUG - 2021-01-10 14:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:57:41 --> Input Class Initialized
INFO - 2021-01-10 14:57:41 --> Language Class Initialized
INFO - 2021-01-10 14:57:42 --> Language Class Initialized
INFO - 2021-01-10 14:57:42 --> Config Class Initialized
INFO - 2021-01-10 14:57:42 --> Loader Class Initialized
INFO - 2021-01-10 14:57:42 --> Helper loaded: url_helper
INFO - 2021-01-10 14:57:42 --> Helper loaded: file_helper
INFO - 2021-01-10 14:57:42 --> Helper loaded: form_helper
INFO - 2021-01-10 14:57:42 --> Helper loaded: my_helper
INFO - 2021-01-10 14:57:42 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:57:42 --> Controller Class Initialized
ERROR - 2021-01-10 14:57:42 --> Severity: Notice --> Undefined index: nilai_utama_10 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 453
DEBUG - 2021-01-10 14:57:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:57:42 --> Final output sent to browser
DEBUG - 2021-01-10 14:57:42 --> Total execution time: 0.9745
INFO - 2021-01-10 14:57:53 --> Config Class Initialized
INFO - 2021-01-10 14:57:53 --> Hooks Class Initialized
DEBUG - 2021-01-10 14:57:53 --> UTF-8 Support Enabled
INFO - 2021-01-10 14:57:53 --> Utf8 Class Initialized
INFO - 2021-01-10 14:57:53 --> URI Class Initialized
INFO - 2021-01-10 14:57:53 --> Router Class Initialized
INFO - 2021-01-10 14:57:53 --> Output Class Initialized
INFO - 2021-01-10 14:57:53 --> Security Class Initialized
DEBUG - 2021-01-10 14:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 14:57:53 --> Input Class Initialized
INFO - 2021-01-10 14:57:53 --> Language Class Initialized
INFO - 2021-01-10 14:57:54 --> Language Class Initialized
INFO - 2021-01-10 14:57:54 --> Config Class Initialized
INFO - 2021-01-10 14:57:54 --> Loader Class Initialized
INFO - 2021-01-10 14:57:54 --> Helper loaded: url_helper
INFO - 2021-01-10 14:57:54 --> Helper loaded: file_helper
INFO - 2021-01-10 14:57:54 --> Helper loaded: form_helper
INFO - 2021-01-10 14:57:54 --> Helper loaded: my_helper
INFO - 2021-01-10 14:57:54 --> Database Driver Class Initialized
DEBUG - 2021-01-10 14:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 14:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 14:57:54 --> Controller Class Initialized
ERROR - 2021-01-10 14:57:54 --> Severity: Notice --> Undefined index: nilai_utama_10 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 453
DEBUG - 2021-01-10 14:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 14:57:54 --> Final output sent to browser
DEBUG - 2021-01-10 14:57:54 --> Total execution time: 1.0229
INFO - 2021-01-10 15:42:01 --> Config Class Initialized
INFO - 2021-01-10 15:42:01 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:42:01 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:42:01 --> Utf8 Class Initialized
INFO - 2021-01-10 15:42:01 --> URI Class Initialized
INFO - 2021-01-10 15:42:01 --> Router Class Initialized
INFO - 2021-01-10 15:42:01 --> Output Class Initialized
INFO - 2021-01-10 15:42:01 --> Security Class Initialized
DEBUG - 2021-01-10 15:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:42:01 --> Input Class Initialized
INFO - 2021-01-10 15:42:01 --> Language Class Initialized
INFO - 2021-01-10 15:42:01 --> Language Class Initialized
INFO - 2021-01-10 15:42:01 --> Config Class Initialized
INFO - 2021-01-10 15:42:01 --> Loader Class Initialized
INFO - 2021-01-10 15:42:01 --> Helper loaded: url_helper
INFO - 2021-01-10 15:42:01 --> Helper loaded: file_helper
INFO - 2021-01-10 15:42:01 --> Helper loaded: form_helper
INFO - 2021-01-10 15:42:02 --> Helper loaded: my_helper
INFO - 2021-01-10 15:42:02 --> Database Driver Class Initialized
DEBUG - 2021-01-10 15:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 15:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 15:42:02 --> Controller Class Initialized
DEBUG - 2021-01-10 15:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 15:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 15:42:02 --> Final output sent to browser
DEBUG - 2021-01-10 15:42:02 --> Total execution time: 1.2652
INFO - 2021-01-10 15:42:04 --> Config Class Initialized
INFO - 2021-01-10 15:42:04 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:42:04 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:42:04 --> Utf8 Class Initialized
INFO - 2021-01-10 15:42:04 --> URI Class Initialized
INFO - 2021-01-10 15:42:04 --> Router Class Initialized
INFO - 2021-01-10 15:42:04 --> Output Class Initialized
INFO - 2021-01-10 15:42:04 --> Security Class Initialized
DEBUG - 2021-01-10 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:42:04 --> Input Class Initialized
INFO - 2021-01-10 15:42:04 --> Language Class Initialized
ERROR - 2021-01-10 15:42:04 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak-Copy
INFO - 2021-01-10 15:42:36 --> Config Class Initialized
INFO - 2021-01-10 15:42:36 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:42:36 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:42:36 --> Utf8 Class Initialized
INFO - 2021-01-10 15:42:37 --> URI Class Initialized
INFO - 2021-01-10 15:42:37 --> Router Class Initialized
INFO - 2021-01-10 15:42:37 --> Output Class Initialized
INFO - 2021-01-10 15:42:37 --> Security Class Initialized
DEBUG - 2021-01-10 15:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:42:37 --> Input Class Initialized
INFO - 2021-01-10 15:42:37 --> Language Class Initialized
ERROR - 2021-01-10 15:42:37 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak-Copy
INFO - 2021-01-10 15:42:39 --> Config Class Initialized
INFO - 2021-01-10 15:42:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:42:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:42:39 --> Utf8 Class Initialized
INFO - 2021-01-10 15:42:39 --> URI Class Initialized
INFO - 2021-01-10 15:42:39 --> Router Class Initialized
INFO - 2021-01-10 15:42:40 --> Output Class Initialized
INFO - 2021-01-10 15:42:40 --> Security Class Initialized
DEBUG - 2021-01-10 15:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:42:40 --> Input Class Initialized
INFO - 2021-01-10 15:42:40 --> Language Class Initialized
INFO - 2021-01-10 15:42:40 --> Language Class Initialized
INFO - 2021-01-10 15:42:40 --> Config Class Initialized
INFO - 2021-01-10 15:42:40 --> Loader Class Initialized
INFO - 2021-01-10 15:42:40 --> Helper loaded: url_helper
INFO - 2021-01-10 15:42:40 --> Helper loaded: file_helper
INFO - 2021-01-10 15:42:40 --> Helper loaded: form_helper
INFO - 2021-01-10 15:42:40 --> Helper loaded: my_helper
INFO - 2021-01-10 15:42:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 15:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 15:42:40 --> Controller Class Initialized
DEBUG - 2021-01-10 15:42:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 15:42:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 15:42:40 --> Final output sent to browser
DEBUG - 2021-01-10 15:42:40 --> Total execution time: 0.8999
INFO - 2021-01-10 15:42:42 --> Config Class Initialized
INFO - 2021-01-10 15:42:42 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:42:42 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:42:42 --> Utf8 Class Initialized
INFO - 2021-01-10 15:42:42 --> URI Class Initialized
INFO - 2021-01-10 15:42:42 --> Router Class Initialized
INFO - 2021-01-10 15:42:42 --> Output Class Initialized
INFO - 2021-01-10 15:42:42 --> Security Class Initialized
DEBUG - 2021-01-10 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:42:43 --> Input Class Initialized
INFO - 2021-01-10 15:42:43 --> Language Class Initialized
ERROR - 2021-01-10 15:42:43 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak-Copy
INFO - 2021-01-10 15:45:32 --> Config Class Initialized
INFO - 2021-01-10 15:45:32 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:45:32 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:45:32 --> Utf8 Class Initialized
INFO - 2021-01-10 15:45:32 --> URI Class Initialized
INFO - 2021-01-10 15:45:32 --> Router Class Initialized
INFO - 2021-01-10 15:45:32 --> Output Class Initialized
INFO - 2021-01-10 15:45:32 --> Security Class Initialized
DEBUG - 2021-01-10 15:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:45:32 --> Input Class Initialized
INFO - 2021-01-10 15:45:32 --> Language Class Initialized
INFO - 2021-01-10 15:45:32 --> Language Class Initialized
INFO - 2021-01-10 15:45:32 --> Config Class Initialized
INFO - 2021-01-10 15:45:32 --> Loader Class Initialized
INFO - 2021-01-10 15:45:32 --> Helper loaded: url_helper
INFO - 2021-01-10 15:45:32 --> Helper loaded: file_helper
INFO - 2021-01-10 15:45:32 --> Helper loaded: form_helper
INFO - 2021-01-10 15:45:32 --> Helper loaded: my_helper
INFO - 2021-01-10 15:45:32 --> Database Driver Class Initialized
DEBUG - 2021-01-10 15:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 15:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 15:45:33 --> Controller Class Initialized
DEBUG - 2021-01-10 15:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 15:45:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 15:45:33 --> Final output sent to browser
DEBUG - 2021-01-10 15:45:33 --> Total execution time: 0.9255
INFO - 2021-01-10 15:45:35 --> Config Class Initialized
INFO - 2021-01-10 15:45:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:45:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:45:35 --> Utf8 Class Initialized
INFO - 2021-01-10 15:45:35 --> URI Class Initialized
INFO - 2021-01-10 15:45:35 --> Router Class Initialized
INFO - 2021-01-10 15:45:35 --> Output Class Initialized
INFO - 2021-01-10 15:45:35 --> Security Class Initialized
DEBUG - 2021-01-10 15:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:45:35 --> Input Class Initialized
INFO - 2021-01-10 15:45:35 --> Language Class Initialized
ERROR - 2021-01-10 15:45:35 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak_to
INFO - 2021-01-10 15:45:49 --> Config Class Initialized
INFO - 2021-01-10 15:45:49 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:45:49 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:45:49 --> Utf8 Class Initialized
INFO - 2021-01-10 15:45:50 --> URI Class Initialized
INFO - 2021-01-10 15:45:50 --> Router Class Initialized
INFO - 2021-01-10 15:45:50 --> Output Class Initialized
INFO - 2021-01-10 15:45:50 --> Security Class Initialized
DEBUG - 2021-01-10 15:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:45:50 --> Input Class Initialized
INFO - 2021-01-10 15:45:50 --> Language Class Initialized
INFO - 2021-01-10 15:45:50 --> Language Class Initialized
INFO - 2021-01-10 15:45:50 --> Config Class Initialized
INFO - 2021-01-10 15:45:50 --> Loader Class Initialized
INFO - 2021-01-10 15:45:50 --> Helper loaded: url_helper
INFO - 2021-01-10 15:45:50 --> Helper loaded: file_helper
INFO - 2021-01-10 15:45:50 --> Helper loaded: form_helper
INFO - 2021-01-10 15:45:50 --> Helper loaded: my_helper
INFO - 2021-01-10 15:45:50 --> Database Driver Class Initialized
DEBUG - 2021-01-10 15:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 15:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 15:45:50 --> Controller Class Initialized
ERROR - 2021-01-10 15:45:50 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 15:45:50 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 15:45:50 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 15:45:50 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 15:45:50 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 15:45:51 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_10 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 453
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_all C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 514
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_tbsm_all C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 552
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_tbsm_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 588
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_otr_xi C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 601
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_otr_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 626
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_tki C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 651
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_tkj_xi C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 676
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_tkj_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 712
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_tkj_xii_b C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 725
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_mm_xi C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 750
ERROR - 2021-01-10 15:45:51 --> Severity: Notice --> Undefined index: nilai_utama_mm_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 775
DEBUG - 2021-01-10 15:45:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 15:45:51 --> Final output sent to browser
DEBUG - 2021-01-10 15:45:51 --> Total execution time: 1.6879
INFO - 2021-01-10 15:59:29 --> Config Class Initialized
INFO - 2021-01-10 15:59:29 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:59:29 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:59:29 --> Utf8 Class Initialized
INFO - 2021-01-10 15:59:29 --> URI Class Initialized
INFO - 2021-01-10 15:59:29 --> Router Class Initialized
INFO - 2021-01-10 15:59:29 --> Output Class Initialized
INFO - 2021-01-10 15:59:29 --> Security Class Initialized
DEBUG - 2021-01-10 15:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:59:29 --> Input Class Initialized
INFO - 2021-01-10 15:59:30 --> Language Class Initialized
INFO - 2021-01-10 15:59:30 --> Language Class Initialized
INFO - 2021-01-10 15:59:30 --> Config Class Initialized
INFO - 2021-01-10 15:59:30 --> Loader Class Initialized
INFO - 2021-01-10 15:59:30 --> Helper loaded: url_helper
INFO - 2021-01-10 15:59:30 --> Helper loaded: file_helper
INFO - 2021-01-10 15:59:30 --> Helper loaded: form_helper
INFO - 2021-01-10 15:59:30 --> Helper loaded: my_helper
INFO - 2021-01-10 15:59:30 --> Database Driver Class Initialized
DEBUG - 2021-01-10 15:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 15:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 15:59:30 --> Controller Class Initialized
DEBUG - 2021-01-10 15:59:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 15:59:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 15:59:30 --> Final output sent to browser
DEBUG - 2021-01-10 15:59:30 --> Total execution time: 0.7828
INFO - 2021-01-10 15:59:32 --> Config Class Initialized
INFO - 2021-01-10 15:59:32 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:59:32 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:59:32 --> Utf8 Class Initialized
INFO - 2021-01-10 15:59:32 --> URI Class Initialized
INFO - 2021-01-10 15:59:32 --> Router Class Initialized
INFO - 2021-01-10 15:59:32 --> Output Class Initialized
INFO - 2021-01-10 15:59:32 --> Security Class Initialized
DEBUG - 2021-01-10 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:59:32 --> Input Class Initialized
INFO - 2021-01-10 15:59:32 --> Language Class Initialized
ERROR - 2021-01-10 15:59:32 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak_to
INFO - 2021-01-10 15:59:52 --> Config Class Initialized
INFO - 2021-01-10 15:59:52 --> Hooks Class Initialized
DEBUG - 2021-01-10 15:59:52 --> UTF-8 Support Enabled
INFO - 2021-01-10 15:59:52 --> Utf8 Class Initialized
INFO - 2021-01-10 15:59:52 --> URI Class Initialized
INFO - 2021-01-10 15:59:52 --> Router Class Initialized
INFO - 2021-01-10 15:59:52 --> Output Class Initialized
INFO - 2021-01-10 15:59:52 --> Security Class Initialized
DEBUG - 2021-01-10 15:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 15:59:52 --> Input Class Initialized
INFO - 2021-01-10 15:59:52 --> Language Class Initialized
INFO - 2021-01-10 15:59:52 --> Language Class Initialized
INFO - 2021-01-10 15:59:52 --> Config Class Initialized
INFO - 2021-01-10 15:59:52 --> Loader Class Initialized
INFO - 2021-01-10 15:59:52 --> Helper loaded: url_helper
INFO - 2021-01-10 15:59:52 --> Helper loaded: file_helper
INFO - 2021-01-10 15:59:52 --> Helper loaded: form_helper
INFO - 2021-01-10 15:59:52 --> Helper loaded: my_helper
INFO - 2021-01-10 15:59:52 --> Database Driver Class Initialized
DEBUG - 2021-01-10 15:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 15:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 15:59:52 --> Controller Class Initialized
DEBUG - 2021-01-10 15:59:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 15:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 15:59:53 --> Final output sent to browser
DEBUG - 2021-01-10 15:59:53 --> Total execution time: 0.8942
INFO - 2021-01-10 16:00:19 --> Config Class Initialized
INFO - 2021-01-10 16:00:19 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:00:19 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:00:19 --> Utf8 Class Initialized
INFO - 2021-01-10 16:00:19 --> URI Class Initialized
INFO - 2021-01-10 16:00:20 --> Router Class Initialized
INFO - 2021-01-10 16:00:20 --> Output Class Initialized
INFO - 2021-01-10 16:00:20 --> Security Class Initialized
DEBUG - 2021-01-10 16:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:00:20 --> Input Class Initialized
INFO - 2021-01-10 16:00:20 --> Language Class Initialized
INFO - 2021-01-10 16:00:20 --> Language Class Initialized
INFO - 2021-01-10 16:00:20 --> Config Class Initialized
INFO - 2021-01-10 16:00:20 --> Loader Class Initialized
INFO - 2021-01-10 16:00:20 --> Helper loaded: url_helper
INFO - 2021-01-10 16:00:20 --> Helper loaded: file_helper
INFO - 2021-01-10 16:00:20 --> Helper loaded: form_helper
INFO - 2021-01-10 16:00:20 --> Helper loaded: my_helper
INFO - 2021-01-10 16:00:20 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:00:20 --> Controller Class Initialized
DEBUG - 2021-01-10 16:00:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:00:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:00:20 --> Final output sent to browser
DEBUG - 2021-01-10 16:00:20 --> Total execution time: 0.7453
INFO - 2021-01-10 16:00:40 --> Config Class Initialized
INFO - 2021-01-10 16:00:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:00:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:00:40 --> Utf8 Class Initialized
INFO - 2021-01-10 16:00:40 --> URI Class Initialized
INFO - 2021-01-10 16:00:40 --> Router Class Initialized
INFO - 2021-01-10 16:00:41 --> Output Class Initialized
INFO - 2021-01-10 16:00:41 --> Security Class Initialized
DEBUG - 2021-01-10 16:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:00:41 --> Input Class Initialized
INFO - 2021-01-10 16:00:41 --> Language Class Initialized
INFO - 2021-01-10 16:00:41 --> Language Class Initialized
INFO - 2021-01-10 16:00:41 --> Config Class Initialized
INFO - 2021-01-10 16:00:41 --> Loader Class Initialized
INFO - 2021-01-10 16:00:41 --> Helper loaded: url_helper
INFO - 2021-01-10 16:00:41 --> Helper loaded: file_helper
INFO - 2021-01-10 16:00:41 --> Helper loaded: form_helper
INFO - 2021-01-10 16:00:41 --> Helper loaded: my_helper
INFO - 2021-01-10 16:00:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:00:41 --> Controller Class Initialized
DEBUG - 2021-01-10 16:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:00:41 --> Final output sent to browser
DEBUG - 2021-01-10 16:00:41 --> Total execution time: 1.0100
INFO - 2021-01-10 16:00:52 --> Config Class Initialized
INFO - 2021-01-10 16:00:52 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:00:52 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:00:53 --> Utf8 Class Initialized
INFO - 2021-01-10 16:00:53 --> URI Class Initialized
INFO - 2021-01-10 16:00:53 --> Router Class Initialized
INFO - 2021-01-10 16:00:53 --> Output Class Initialized
INFO - 2021-01-10 16:00:53 --> Security Class Initialized
DEBUG - 2021-01-10 16:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:00:53 --> Input Class Initialized
INFO - 2021-01-10 16:00:53 --> Language Class Initialized
INFO - 2021-01-10 16:00:53 --> Language Class Initialized
INFO - 2021-01-10 16:00:53 --> Config Class Initialized
INFO - 2021-01-10 16:00:53 --> Loader Class Initialized
INFO - 2021-01-10 16:00:53 --> Helper loaded: url_helper
INFO - 2021-01-10 16:00:53 --> Helper loaded: file_helper
INFO - 2021-01-10 16:00:53 --> Helper loaded: form_helper
INFO - 2021-01-10 16:00:53 --> Helper loaded: my_helper
INFO - 2021-01-10 16:00:53 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:00:53 --> Controller Class Initialized
DEBUG - 2021-01-10 16:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:00:53 --> Final output sent to browser
DEBUG - 2021-01-10 16:00:53 --> Total execution time: 0.7499
INFO - 2021-01-10 16:02:39 --> Config Class Initialized
INFO - 2021-01-10 16:02:39 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:02:39 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:02:39 --> Utf8 Class Initialized
INFO - 2021-01-10 16:02:39 --> URI Class Initialized
INFO - 2021-01-10 16:02:39 --> Router Class Initialized
INFO - 2021-01-10 16:02:39 --> Output Class Initialized
INFO - 2021-01-10 16:02:39 --> Security Class Initialized
DEBUG - 2021-01-10 16:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:02:39 --> Input Class Initialized
INFO - 2021-01-10 16:02:39 --> Language Class Initialized
INFO - 2021-01-10 16:02:40 --> Language Class Initialized
INFO - 2021-01-10 16:02:40 --> Config Class Initialized
INFO - 2021-01-10 16:02:40 --> Loader Class Initialized
INFO - 2021-01-10 16:02:40 --> Helper loaded: url_helper
INFO - 2021-01-10 16:02:40 --> Helper loaded: file_helper
INFO - 2021-01-10 16:02:40 --> Helper loaded: form_helper
INFO - 2021-01-10 16:02:40 --> Helper loaded: my_helper
INFO - 2021-01-10 16:02:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:02:40 --> Controller Class Initialized
DEBUG - 2021-01-10 16:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:02:40 --> Final output sent to browser
DEBUG - 2021-01-10 16:02:40 --> Total execution time: 1.0356
INFO - 2021-01-10 16:02:42 --> Config Class Initialized
INFO - 2021-01-10 16:02:42 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:02:42 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:02:42 --> Utf8 Class Initialized
INFO - 2021-01-10 16:02:42 --> URI Class Initialized
INFO - 2021-01-10 16:02:42 --> Router Class Initialized
INFO - 2021-01-10 16:02:42 --> Output Class Initialized
INFO - 2021-01-10 16:02:42 --> Security Class Initialized
DEBUG - 2021-01-10 16:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:02:42 --> Input Class Initialized
INFO - 2021-01-10 16:02:42 --> Language Class Initialized
ERROR - 2021-01-10 16:02:42 --> 404 Page Not Found: /index
INFO - 2021-01-10 16:04:22 --> Config Class Initialized
INFO - 2021-01-10 16:04:22 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:04:22 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:04:22 --> Utf8 Class Initialized
INFO - 2021-01-10 16:04:22 --> URI Class Initialized
INFO - 2021-01-10 16:04:22 --> Router Class Initialized
INFO - 2021-01-10 16:04:22 --> Output Class Initialized
INFO - 2021-01-10 16:04:22 --> Security Class Initialized
DEBUG - 2021-01-10 16:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:04:22 --> Input Class Initialized
INFO - 2021-01-10 16:04:22 --> Language Class Initialized
INFO - 2021-01-10 16:04:23 --> Language Class Initialized
INFO - 2021-01-10 16:04:23 --> Config Class Initialized
INFO - 2021-01-10 16:04:23 --> Loader Class Initialized
INFO - 2021-01-10 16:04:23 --> Helper loaded: url_helper
INFO - 2021-01-10 16:04:23 --> Helper loaded: file_helper
INFO - 2021-01-10 16:04:23 --> Helper loaded: form_helper
INFO - 2021-01-10 16:04:23 --> Helper loaded: my_helper
INFO - 2021-01-10 16:04:23 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:04:23 --> Controller Class Initialized
DEBUG - 2021-01-10 16:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:04:23 --> Final output sent to browser
DEBUG - 2021-01-10 16:04:23 --> Total execution time: 1.3043
INFO - 2021-01-10 16:04:25 --> Config Class Initialized
INFO - 2021-01-10 16:04:25 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:04:25 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:04:25 --> Utf8 Class Initialized
INFO - 2021-01-10 16:04:25 --> URI Class Initialized
INFO - 2021-01-10 16:04:25 --> Router Class Initialized
INFO - 2021-01-10 16:04:25 --> Output Class Initialized
INFO - 2021-01-10 16:04:25 --> Security Class Initialized
DEBUG - 2021-01-10 16:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:04:25 --> Input Class Initialized
INFO - 2021-01-10 16:04:25 --> Language Class Initialized
ERROR - 2021-01-10 16:04:25 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak_to
INFO - 2021-01-10 16:04:38 --> Config Class Initialized
INFO - 2021-01-10 16:04:38 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:04:38 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:04:38 --> Utf8 Class Initialized
INFO - 2021-01-10 16:04:38 --> URI Class Initialized
INFO - 2021-01-10 16:04:38 --> Router Class Initialized
INFO - 2021-01-10 16:04:38 --> Output Class Initialized
INFO - 2021-01-10 16:04:38 --> Security Class Initialized
DEBUG - 2021-01-10 16:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:04:39 --> Input Class Initialized
INFO - 2021-01-10 16:04:39 --> Language Class Initialized
INFO - 2021-01-10 16:04:39 --> Language Class Initialized
INFO - 2021-01-10 16:04:39 --> Config Class Initialized
INFO - 2021-01-10 16:04:39 --> Loader Class Initialized
INFO - 2021-01-10 16:04:39 --> Helper loaded: url_helper
INFO - 2021-01-10 16:04:39 --> Helper loaded: file_helper
INFO - 2021-01-10 16:04:39 --> Helper loaded: form_helper
INFO - 2021-01-10 16:04:39 --> Helper loaded: my_helper
INFO - 2021-01-10 16:04:39 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:04:39 --> Controller Class Initialized
DEBUG - 2021-01-10 16:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:04:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:04:39 --> Final output sent to browser
DEBUG - 2021-01-10 16:04:39 --> Total execution time: 0.8558
INFO - 2021-01-10 16:04:40 --> Config Class Initialized
INFO - 2021-01-10 16:04:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:04:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:04:40 --> Utf8 Class Initialized
INFO - 2021-01-10 16:04:40 --> URI Class Initialized
INFO - 2021-01-10 16:04:40 --> Router Class Initialized
INFO - 2021-01-10 16:04:40 --> Output Class Initialized
INFO - 2021-01-10 16:04:40 --> Security Class Initialized
DEBUG - 2021-01-10 16:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:04:40 --> Input Class Initialized
INFO - 2021-01-10 16:04:40 --> Language Class Initialized
INFO - 2021-01-10 16:04:40 --> Language Class Initialized
INFO - 2021-01-10 16:04:40 --> Config Class Initialized
INFO - 2021-01-10 16:04:40 --> Loader Class Initialized
INFO - 2021-01-10 16:04:40 --> Helper loaded: url_helper
INFO - 2021-01-10 16:04:40 --> Helper loaded: file_helper
INFO - 2021-01-10 16:04:40 --> Helper loaded: form_helper
INFO - 2021-01-10 16:04:40 --> Helper loaded: my_helper
INFO - 2021-01-10 16:04:40 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:04:41 --> Controller Class Initialized
ERROR - 2021-01-10 16:04:41 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\nilai\application\helpers\my_helper.php 150
DEBUG - 2021-01-10 16:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-01-10 16:04:41 --> Final output sent to browser
DEBUG - 2021-01-10 16:04:41 --> Total execution time: 0.9406
INFO - 2021-01-10 16:06:27 --> Config Class Initialized
INFO - 2021-01-10 16:06:27 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:06:27 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:06:27 --> Utf8 Class Initialized
INFO - 2021-01-10 16:06:28 --> URI Class Initialized
INFO - 2021-01-10 16:06:28 --> Router Class Initialized
INFO - 2021-01-10 16:06:28 --> Output Class Initialized
INFO - 2021-01-10 16:06:28 --> Security Class Initialized
DEBUG - 2021-01-10 16:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:06:28 --> Input Class Initialized
INFO - 2021-01-10 16:06:28 --> Language Class Initialized
INFO - 2021-01-10 16:06:28 --> Language Class Initialized
INFO - 2021-01-10 16:06:28 --> Config Class Initialized
INFO - 2021-01-10 16:06:28 --> Loader Class Initialized
INFO - 2021-01-10 16:06:28 --> Helper loaded: url_helper
INFO - 2021-01-10 16:06:28 --> Helper loaded: file_helper
INFO - 2021-01-10 16:06:28 --> Helper loaded: form_helper
INFO - 2021-01-10 16:06:28 --> Helper loaded: my_helper
INFO - 2021-01-10 16:06:28 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:06:28 --> Controller Class Initialized
DEBUG - 2021-01-10 16:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:06:28 --> Final output sent to browser
DEBUG - 2021-01-10 16:06:28 --> Total execution time: 0.6315
INFO - 2021-01-10 16:06:29 --> Config Class Initialized
INFO - 2021-01-10 16:06:29 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:06:29 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:06:29 --> Utf8 Class Initialized
INFO - 2021-01-10 16:06:29 --> URI Class Initialized
INFO - 2021-01-10 16:06:30 --> Router Class Initialized
INFO - 2021-01-10 16:06:30 --> Output Class Initialized
INFO - 2021-01-10 16:06:30 --> Security Class Initialized
DEBUG - 2021-01-10 16:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:06:30 --> Input Class Initialized
INFO - 2021-01-10 16:06:30 --> Language Class Initialized
INFO - 2021-01-10 16:06:30 --> Language Class Initialized
INFO - 2021-01-10 16:06:30 --> Config Class Initialized
INFO - 2021-01-10 16:06:30 --> Loader Class Initialized
INFO - 2021-01-10 16:06:30 --> Helper loaded: url_helper
INFO - 2021-01-10 16:06:30 --> Helper loaded: file_helper
INFO - 2021-01-10 16:06:30 --> Helper loaded: form_helper
INFO - 2021-01-10 16:06:30 --> Helper loaded: my_helper
INFO - 2021-01-10 16:06:30 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:06:30 --> Controller Class Initialized
DEBUG - 2021-01-10 16:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-01-10 16:06:30 --> Final output sent to browser
DEBUG - 2021-01-10 16:06:30 --> Total execution time: 0.8429
INFO - 2021-01-10 16:06:48 --> Config Class Initialized
INFO - 2021-01-10 16:06:48 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:06:48 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:06:48 --> Utf8 Class Initialized
INFO - 2021-01-10 16:06:48 --> URI Class Initialized
INFO - 2021-01-10 16:06:48 --> Router Class Initialized
INFO - 2021-01-10 16:06:48 --> Output Class Initialized
INFO - 2021-01-10 16:06:48 --> Security Class Initialized
DEBUG - 2021-01-10 16:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:06:48 --> Input Class Initialized
INFO - 2021-01-10 16:06:48 --> Language Class Initialized
INFO - 2021-01-10 16:06:48 --> Language Class Initialized
INFO - 2021-01-10 16:06:48 --> Config Class Initialized
INFO - 2021-01-10 16:06:48 --> Loader Class Initialized
INFO - 2021-01-10 16:06:49 --> Helper loaded: url_helper
INFO - 2021-01-10 16:06:49 --> Helper loaded: file_helper
INFO - 2021-01-10 16:06:49 --> Helper loaded: form_helper
INFO - 2021-01-10 16:06:49 --> Helper loaded: my_helper
INFO - 2021-01-10 16:06:49 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:06:49 --> Controller Class Initialized
DEBUG - 2021-01-10 16:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:06:49 --> Final output sent to browser
DEBUG - 2021-01-10 16:06:49 --> Total execution time: 1.0976
INFO - 2021-01-10 16:06:51 --> Config Class Initialized
INFO - 2021-01-10 16:06:51 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:06:51 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:06:51 --> Utf8 Class Initialized
INFO - 2021-01-10 16:06:51 --> URI Class Initialized
INFO - 2021-01-10 16:06:51 --> Router Class Initialized
INFO - 2021-01-10 16:06:51 --> Output Class Initialized
INFO - 2021-01-10 16:06:51 --> Security Class Initialized
DEBUG - 2021-01-10 16:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:06:51 --> Input Class Initialized
INFO - 2021-01-10 16:06:51 --> Language Class Initialized
INFO - 2021-01-10 16:06:51 --> Language Class Initialized
INFO - 2021-01-10 16:06:51 --> Config Class Initialized
INFO - 2021-01-10 16:06:51 --> Loader Class Initialized
INFO - 2021-01-10 16:06:51 --> Helper loaded: url_helper
INFO - 2021-01-10 16:06:51 --> Helper loaded: file_helper
INFO - 2021-01-10 16:06:51 --> Helper loaded: form_helper
INFO - 2021-01-10 16:06:51 --> Helper loaded: my_helper
INFO - 2021-01-10 16:06:51 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:06:51 --> Controller Class Initialized
DEBUG - 2021-01-10 16:06:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-01-10 16:06:52 --> Final output sent to browser
DEBUG - 2021-01-10 16:06:52 --> Total execution time: 0.7622
INFO - 2021-01-10 16:08:06 --> Config Class Initialized
INFO - 2021-01-10 16:08:06 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:08:06 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:08:06 --> Utf8 Class Initialized
INFO - 2021-01-10 16:08:06 --> URI Class Initialized
INFO - 2021-01-10 16:08:06 --> Router Class Initialized
INFO - 2021-01-10 16:08:06 --> Output Class Initialized
INFO - 2021-01-10 16:08:06 --> Security Class Initialized
DEBUG - 2021-01-10 16:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:08:06 --> Input Class Initialized
INFO - 2021-01-10 16:08:06 --> Language Class Initialized
INFO - 2021-01-10 16:08:07 --> Language Class Initialized
INFO - 2021-01-10 16:08:07 --> Config Class Initialized
INFO - 2021-01-10 16:08:07 --> Loader Class Initialized
INFO - 2021-01-10 16:08:07 --> Helper loaded: url_helper
INFO - 2021-01-10 16:08:07 --> Helper loaded: file_helper
INFO - 2021-01-10 16:08:07 --> Helper loaded: form_helper
INFO - 2021-01-10 16:08:07 --> Helper loaded: my_helper
INFO - 2021-01-10 16:08:07 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:08:07 --> Controller Class Initialized
DEBUG - 2021-01-10 16:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:08:07 --> Final output sent to browser
DEBUG - 2021-01-10 16:08:07 --> Total execution time: 0.6175
INFO - 2021-01-10 16:08:08 --> Config Class Initialized
INFO - 2021-01-10 16:08:08 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:08:08 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:08:08 --> Utf8 Class Initialized
INFO - 2021-01-10 16:08:08 --> URI Class Initialized
INFO - 2021-01-10 16:08:08 --> Router Class Initialized
INFO - 2021-01-10 16:08:08 --> Output Class Initialized
INFO - 2021-01-10 16:08:08 --> Security Class Initialized
DEBUG - 2021-01-10 16:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:08:08 --> Input Class Initialized
INFO - 2021-01-10 16:08:08 --> Language Class Initialized
ERROR - 2021-01-10 16:08:08 --> 404 Page Not Found: ../modules/cetak_raport/controllers/Cetak_raport/cetak_to
INFO - 2021-01-10 16:08:12 --> Config Class Initialized
INFO - 2021-01-10 16:08:12 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:08:12 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:08:12 --> Utf8 Class Initialized
INFO - 2021-01-10 16:08:12 --> URI Class Initialized
INFO - 2021-01-10 16:08:12 --> Router Class Initialized
INFO - 2021-01-10 16:08:12 --> Output Class Initialized
INFO - 2021-01-10 16:08:12 --> Security Class Initialized
DEBUG - 2021-01-10 16:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:08:13 --> Input Class Initialized
INFO - 2021-01-10 16:08:13 --> Language Class Initialized
INFO - 2021-01-10 16:08:13 --> Language Class Initialized
INFO - 2021-01-10 16:08:13 --> Config Class Initialized
INFO - 2021-01-10 16:08:13 --> Loader Class Initialized
INFO - 2021-01-10 16:08:13 --> Helper loaded: url_helper
INFO - 2021-01-10 16:08:13 --> Helper loaded: file_helper
INFO - 2021-01-10 16:08:13 --> Helper loaded: form_helper
INFO - 2021-01-10 16:08:13 --> Helper loaded: my_helper
INFO - 2021-01-10 16:08:13 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:08:13 --> Controller Class Initialized
ERROR - 2021-01-10 16:08:13 --> Severity: Notice --> Undefined offset: -1 C:\xampp\htdocs\nilai\application\helpers\my_helper.php 150
DEBUG - 2021-01-10 16:08:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2021-01-10 16:08:13 --> Final output sent to browser
DEBUG - 2021-01-10 16:08:13 --> Total execution time: 0.8665
INFO - 2021-01-10 16:08:29 --> Config Class Initialized
INFO - 2021-01-10 16:08:29 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:08:29 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:08:29 --> Utf8 Class Initialized
INFO - 2021-01-10 16:08:29 --> URI Class Initialized
INFO - 2021-01-10 16:08:29 --> Router Class Initialized
INFO - 2021-01-10 16:08:29 --> Output Class Initialized
INFO - 2021-01-10 16:08:29 --> Security Class Initialized
DEBUG - 2021-01-10 16:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:08:29 --> Input Class Initialized
INFO - 2021-01-10 16:08:29 --> Language Class Initialized
INFO - 2021-01-10 16:08:29 --> Language Class Initialized
INFO - 2021-01-10 16:08:29 --> Config Class Initialized
INFO - 2021-01-10 16:08:29 --> Loader Class Initialized
INFO - 2021-01-10 16:08:29 --> Helper loaded: url_helper
INFO - 2021-01-10 16:08:29 --> Helper loaded: file_helper
INFO - 2021-01-10 16:08:29 --> Helper loaded: form_helper
INFO - 2021-01-10 16:08:29 --> Helper loaded: my_helper
INFO - 2021-01-10 16:08:29 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:08:29 --> Controller Class Initialized
DEBUG - 2021-01-10 16:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2021-01-10 16:08:29 --> Final output sent to browser
DEBUG - 2021-01-10 16:08:29 --> Total execution time: 0.8852
INFO - 2021-01-10 16:08:35 --> Config Class Initialized
INFO - 2021-01-10 16:08:35 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:08:35 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:08:35 --> Utf8 Class Initialized
INFO - 2021-01-10 16:08:35 --> URI Class Initialized
INFO - 2021-01-10 16:08:35 --> Router Class Initialized
INFO - 2021-01-10 16:08:35 --> Output Class Initialized
INFO - 2021-01-10 16:08:35 --> Security Class Initialized
DEBUG - 2021-01-10 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:08:35 --> Input Class Initialized
INFO - 2021-01-10 16:08:35 --> Language Class Initialized
INFO - 2021-01-10 16:08:35 --> Language Class Initialized
INFO - 2021-01-10 16:08:35 --> Config Class Initialized
INFO - 2021-01-10 16:08:35 --> Loader Class Initialized
INFO - 2021-01-10 16:08:35 --> Helper loaded: url_helper
INFO - 2021-01-10 16:08:35 --> Helper loaded: file_helper
INFO - 2021-01-10 16:08:36 --> Helper loaded: form_helper
INFO - 2021-01-10 16:08:36 --> Helper loaded: my_helper
INFO - 2021-01-10 16:08:36 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:08:36 --> Controller Class Initialized
DEBUG - 2021-01-10 16:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2021-01-10 16:08:36 --> Final output sent to browser
DEBUG - 2021-01-10 16:08:36 --> Total execution time: 0.8327
INFO - 2021-01-10 16:08:40 --> Config Class Initialized
INFO - 2021-01-10 16:08:40 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:08:40 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:08:40 --> Utf8 Class Initialized
INFO - 2021-01-10 16:08:40 --> URI Class Initialized
INFO - 2021-01-10 16:08:40 --> Router Class Initialized
INFO - 2021-01-10 16:08:40 --> Output Class Initialized
INFO - 2021-01-10 16:08:40 --> Security Class Initialized
DEBUG - 2021-01-10 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:08:40 --> Input Class Initialized
INFO - 2021-01-10 16:08:40 --> Language Class Initialized
INFO - 2021-01-10 16:08:41 --> Language Class Initialized
INFO - 2021-01-10 16:08:41 --> Config Class Initialized
INFO - 2021-01-10 16:08:41 --> Loader Class Initialized
INFO - 2021-01-10 16:08:41 --> Helper loaded: url_helper
INFO - 2021-01-10 16:08:41 --> Helper loaded: file_helper
INFO - 2021-01-10 16:08:41 --> Helper loaded: form_helper
INFO - 2021-01-10 16:08:41 --> Helper loaded: my_helper
INFO - 2021-01-10 16:08:41 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:08:41 --> Controller Class Initialized
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 16:08:41 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_10 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 453
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_all C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 514
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_tbsm_all C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 552
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_tbsm_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 588
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_otr_xi C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 601
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_otr_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 626
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_tki C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 651
ERROR - 2021-01-10 16:08:41 --> Severity: Notice --> Undefined index: nilai_utama_tkj_xi C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 676
ERROR - 2021-01-10 16:08:42 --> Severity: Notice --> Undefined index: nilai_utama_tkj_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 712
ERROR - 2021-01-10 16:08:42 --> Severity: Notice --> Undefined index: nilai_utama_tkj_xii_b C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 725
ERROR - 2021-01-10 16:08:42 --> Severity: Notice --> Undefined index: nilai_utama_mm_xi C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 750
ERROR - 2021-01-10 16:08:42 --> Severity: Notice --> Undefined index: nilai_utama_mm_xii C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 775
DEBUG - 2021-01-10 16:08:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 16:08:42 --> Final output sent to browser
DEBUG - 2021-01-10 16:08:42 --> Total execution time: 1.5941
INFO - 2021-01-10 16:14:47 --> Config Class Initialized
INFO - 2021-01-10 16:14:47 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:14:47 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:14:47 --> Utf8 Class Initialized
INFO - 2021-01-10 16:14:47 --> URI Class Initialized
INFO - 2021-01-10 16:14:47 --> Router Class Initialized
INFO - 2021-01-10 16:14:47 --> Output Class Initialized
INFO - 2021-01-10 16:14:47 --> Security Class Initialized
DEBUG - 2021-01-10 16:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:14:47 --> Input Class Initialized
INFO - 2021-01-10 16:14:47 --> Language Class Initialized
INFO - 2021-01-10 16:14:47 --> Language Class Initialized
INFO - 2021-01-10 16:14:47 --> Config Class Initialized
INFO - 2021-01-10 16:14:47 --> Loader Class Initialized
INFO - 2021-01-10 16:14:47 --> Helper loaded: url_helper
INFO - 2021-01-10 16:14:47 --> Helper loaded: file_helper
INFO - 2021-01-10 16:14:47 --> Helper loaded: form_helper
INFO - 2021-01-10 16:14:47 --> Helper loaded: my_helper
INFO - 2021-01-10 16:14:48 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:14:48 --> Controller Class Initialized
DEBUG - 2021-01-10 16:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-10 16:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-10 16:14:48 --> Final output sent to browser
DEBUG - 2021-01-10 16:14:48 --> Total execution time: 0.9678
INFO - 2021-01-10 16:14:49 --> Config Class Initialized
INFO - 2021-01-10 16:14:49 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:14:49 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:14:49 --> Utf8 Class Initialized
INFO - 2021-01-10 16:14:49 --> URI Class Initialized
INFO - 2021-01-10 16:14:49 --> Router Class Initialized
INFO - 2021-01-10 16:14:49 --> Output Class Initialized
INFO - 2021-01-10 16:14:49 --> Security Class Initialized
DEBUG - 2021-01-10 16:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:14:49 --> Input Class Initialized
INFO - 2021-01-10 16:14:49 --> Language Class Initialized
INFO - 2021-01-10 16:14:49 --> Language Class Initialized
INFO - 2021-01-10 16:14:49 --> Config Class Initialized
INFO - 2021-01-10 16:14:49 --> Loader Class Initialized
INFO - 2021-01-10 16:14:49 --> Helper loaded: url_helper
INFO - 2021-01-10 16:14:49 --> Helper loaded: file_helper
INFO - 2021-01-10 16:14:50 --> Helper loaded: form_helper
INFO - 2021-01-10 16:14:50 --> Helper loaded: my_helper
INFO - 2021-01-10 16:14:50 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:14:50 --> Controller Class Initialized
ERROR - 2021-01-10 16:14:50 --> Severity: Notice --> Undefined variable: _np C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 16:14:50 --> Severity: Notice --> Undefined variable: _nilai_keterampilan C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 261
ERROR - 2021-01-10 16:14:50 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
ERROR - 2021-01-10 16:14:50 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 264
ERROR - 2021-01-10 16:14:50 --> Severity: Notice --> Undefined variable: txt_desk C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 16:14:50 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
ERROR - 2021-01-10 16:14:50 --> Severity: Notice --> Undefined variable: k C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 265
DEBUG - 2021-01-10 16:14:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-10 16:14:50 --> Final output sent to browser
DEBUG - 2021-01-10 16:14:50 --> Total execution time: 1.2346
INFO - 2021-01-10 16:22:48 --> Config Class Initialized
INFO - 2021-01-10 16:22:48 --> Hooks Class Initialized
DEBUG - 2021-01-10 16:22:48 --> UTF-8 Support Enabled
INFO - 2021-01-10 16:22:48 --> Utf8 Class Initialized
INFO - 2021-01-10 16:22:49 --> URI Class Initialized
INFO - 2021-01-10 16:22:49 --> Router Class Initialized
INFO - 2021-01-10 16:22:49 --> Output Class Initialized
INFO - 2021-01-10 16:22:49 --> Security Class Initialized
DEBUG - 2021-01-10 16:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-10 16:22:49 --> Input Class Initialized
INFO - 2021-01-10 16:22:49 --> Language Class Initialized
INFO - 2021-01-10 16:22:49 --> Language Class Initialized
INFO - 2021-01-10 16:22:49 --> Config Class Initialized
INFO - 2021-01-10 16:22:49 --> Loader Class Initialized
INFO - 2021-01-10 16:22:49 --> Helper loaded: url_helper
INFO - 2021-01-10 16:22:49 --> Helper loaded: file_helper
INFO - 2021-01-10 16:22:49 --> Helper loaded: form_helper
INFO - 2021-01-10 16:22:49 --> Helper loaded: my_helper
INFO - 2021-01-10 16:22:49 --> Database Driver Class Initialized
DEBUG - 2021-01-10 16:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-10 16:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-10 16:22:49 --> Controller Class Initialized
DEBUG - 2021-01-10 16:22:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2021-01-10 16:22:49 --> Final output sent to browser
DEBUG - 2021-01-10 16:22:49 --> Total execution time: 0.8514
