<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-16 01:32:52 --> Config Class Initialized
INFO - 2020-11-16 01:32:52 --> Hooks Class Initialized
DEBUG - 2020-11-16 01:32:52 --> UTF-8 Support Enabled
INFO - 2020-11-16 01:32:52 --> Utf8 Class Initialized
INFO - 2020-11-16 01:32:52 --> URI Class Initialized
DEBUG - 2020-11-16 01:32:52 --> No URI present. Default controller set.
INFO - 2020-11-16 01:32:52 --> Router Class Initialized
INFO - 2020-11-16 01:32:52 --> Output Class Initialized
INFO - 2020-11-16 01:32:52 --> Security Class Initialized
DEBUG - 2020-11-16 01:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 01:32:52 --> Input Class Initialized
INFO - 2020-11-16 01:32:52 --> Language Class Initialized
INFO - 2020-11-16 01:32:52 --> Language Class Initialized
INFO - 2020-11-16 01:32:52 --> Config Class Initialized
INFO - 2020-11-16 01:32:52 --> Loader Class Initialized
INFO - 2020-11-16 01:32:52 --> Helper loaded: url_helper
INFO - 2020-11-16 01:32:52 --> Helper loaded: file_helper
INFO - 2020-11-16 01:32:52 --> Helper loaded: form_helper
INFO - 2020-11-16 01:32:52 --> Helper loaded: my_helper
INFO - 2020-11-16 01:32:52 --> Database Driver Class Initialized
DEBUG - 2020-11-16 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 01:32:53 --> Controller Class Initialized
INFO - 2020-11-16 01:32:53 --> Config Class Initialized
INFO - 2020-11-16 01:32:53 --> Hooks Class Initialized
DEBUG - 2020-11-16 01:32:53 --> UTF-8 Support Enabled
INFO - 2020-11-16 01:32:53 --> Utf8 Class Initialized
INFO - 2020-11-16 01:32:53 --> URI Class Initialized
INFO - 2020-11-16 01:32:53 --> Router Class Initialized
INFO - 2020-11-16 01:32:53 --> Output Class Initialized
INFO - 2020-11-16 01:32:53 --> Security Class Initialized
DEBUG - 2020-11-16 01:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 01:32:53 --> Input Class Initialized
INFO - 2020-11-16 01:32:53 --> Language Class Initialized
INFO - 2020-11-16 01:32:53 --> Language Class Initialized
INFO - 2020-11-16 01:32:53 --> Config Class Initialized
INFO - 2020-11-16 01:32:53 --> Loader Class Initialized
INFO - 2020-11-16 01:32:53 --> Helper loaded: url_helper
INFO - 2020-11-16 01:32:53 --> Helper loaded: file_helper
INFO - 2020-11-16 01:32:53 --> Helper loaded: form_helper
INFO - 2020-11-16 01:32:53 --> Helper loaded: my_helper
INFO - 2020-11-16 01:32:53 --> Database Driver Class Initialized
DEBUG - 2020-11-16 01:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 01:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 01:32:53 --> Controller Class Initialized
DEBUG - 2020-11-16 01:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-16 01:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 01:32:53 --> Final output sent to browser
DEBUG - 2020-11-16 01:32:53 --> Total execution time: 0.2164
INFO - 2020-11-16 08:22:31 --> Config Class Initialized
INFO - 2020-11-16 08:22:31 --> Hooks Class Initialized
DEBUG - 2020-11-16 08:22:31 --> UTF-8 Support Enabled
INFO - 2020-11-16 08:22:31 --> Utf8 Class Initialized
INFO - 2020-11-16 08:22:31 --> URI Class Initialized
DEBUG - 2020-11-16 08:22:31 --> No URI present. Default controller set.
INFO - 2020-11-16 08:22:31 --> Router Class Initialized
INFO - 2020-11-16 08:22:31 --> Output Class Initialized
INFO - 2020-11-16 08:22:31 --> Security Class Initialized
DEBUG - 2020-11-16 08:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 08:22:31 --> Input Class Initialized
INFO - 2020-11-16 08:22:31 --> Language Class Initialized
INFO - 2020-11-16 08:22:31 --> Language Class Initialized
INFO - 2020-11-16 08:22:31 --> Config Class Initialized
INFO - 2020-11-16 08:22:31 --> Loader Class Initialized
INFO - 2020-11-16 08:22:31 --> Helper loaded: url_helper
INFO - 2020-11-16 08:22:31 --> Helper loaded: file_helper
INFO - 2020-11-16 08:22:31 --> Helper loaded: form_helper
INFO - 2020-11-16 08:22:31 --> Helper loaded: my_helper
INFO - 2020-11-16 08:22:31 --> Database Driver Class Initialized
DEBUG - 2020-11-16 08:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 08:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 08:22:31 --> Controller Class Initialized
INFO - 2020-11-16 08:22:31 --> Config Class Initialized
INFO - 2020-11-16 08:22:31 --> Hooks Class Initialized
DEBUG - 2020-11-16 08:22:31 --> UTF-8 Support Enabled
INFO - 2020-11-16 08:22:31 --> Utf8 Class Initialized
INFO - 2020-11-16 08:22:31 --> URI Class Initialized
INFO - 2020-11-16 08:22:31 --> Router Class Initialized
INFO - 2020-11-16 08:22:31 --> Output Class Initialized
INFO - 2020-11-16 08:22:31 --> Security Class Initialized
DEBUG - 2020-11-16 08:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 08:22:31 --> Input Class Initialized
INFO - 2020-11-16 08:22:31 --> Language Class Initialized
INFO - 2020-11-16 08:22:31 --> Language Class Initialized
INFO - 2020-11-16 08:22:31 --> Config Class Initialized
INFO - 2020-11-16 08:22:31 --> Loader Class Initialized
INFO - 2020-11-16 08:22:31 --> Helper loaded: url_helper
INFO - 2020-11-16 08:22:31 --> Helper loaded: file_helper
INFO - 2020-11-16 08:22:31 --> Helper loaded: form_helper
INFO - 2020-11-16 08:22:31 --> Helper loaded: my_helper
INFO - 2020-11-16 08:22:31 --> Database Driver Class Initialized
DEBUG - 2020-11-16 08:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 08:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 08:22:31 --> Controller Class Initialized
DEBUG - 2020-11-16 08:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-16 08:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 08:22:31 --> Final output sent to browser
DEBUG - 2020-11-16 08:22:31 --> Total execution time: 0.2701
INFO - 2020-11-16 09:14:50 --> Config Class Initialized
INFO - 2020-11-16 09:14:50 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:14:50 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:14:50 --> Utf8 Class Initialized
INFO - 2020-11-16 09:14:50 --> URI Class Initialized
INFO - 2020-11-16 09:14:50 --> Router Class Initialized
INFO - 2020-11-16 09:14:50 --> Output Class Initialized
INFO - 2020-11-16 09:14:50 --> Security Class Initialized
DEBUG - 2020-11-16 09:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:14:50 --> Input Class Initialized
INFO - 2020-11-16 09:14:50 --> Language Class Initialized
INFO - 2020-11-16 09:14:50 --> Language Class Initialized
INFO - 2020-11-16 09:14:50 --> Config Class Initialized
INFO - 2020-11-16 09:14:50 --> Loader Class Initialized
INFO - 2020-11-16 09:14:50 --> Helper loaded: url_helper
INFO - 2020-11-16 09:14:50 --> Helper loaded: file_helper
INFO - 2020-11-16 09:14:50 --> Helper loaded: form_helper
INFO - 2020-11-16 09:14:50 --> Helper loaded: my_helper
INFO - 2020-11-16 09:14:50 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:14:50 --> Controller Class Initialized
INFO - 2020-11-16 09:14:50 --> Helper loaded: cookie_helper
INFO - 2020-11-16 09:14:50 --> Final output sent to browser
DEBUG - 2020-11-16 09:14:50 --> Total execution time: 0.2910
INFO - 2020-11-16 09:14:52 --> Config Class Initialized
INFO - 2020-11-16 09:14:52 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:14:52 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:14:52 --> Utf8 Class Initialized
INFO - 2020-11-16 09:14:52 --> URI Class Initialized
INFO - 2020-11-16 09:14:52 --> Router Class Initialized
INFO - 2020-11-16 09:14:52 --> Output Class Initialized
INFO - 2020-11-16 09:14:52 --> Security Class Initialized
DEBUG - 2020-11-16 09:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:14:52 --> Input Class Initialized
INFO - 2020-11-16 09:14:52 --> Language Class Initialized
INFO - 2020-11-16 09:14:52 --> Language Class Initialized
INFO - 2020-11-16 09:14:52 --> Config Class Initialized
INFO - 2020-11-16 09:14:52 --> Loader Class Initialized
INFO - 2020-11-16 09:14:52 --> Helper loaded: url_helper
INFO - 2020-11-16 09:14:52 --> Helper loaded: file_helper
INFO - 2020-11-16 09:14:52 --> Helper loaded: form_helper
INFO - 2020-11-16 09:14:52 --> Helper loaded: my_helper
INFO - 2020-11-16 09:14:52 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:14:52 --> Controller Class Initialized
DEBUG - 2020-11-16 09:14:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-16 09:14:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:14:52 --> Final output sent to browser
DEBUG - 2020-11-16 09:14:52 --> Total execution time: 0.3702
INFO - 2020-11-16 09:14:54 --> Config Class Initialized
INFO - 2020-11-16 09:14:54 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:14:54 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:14:54 --> Utf8 Class Initialized
INFO - 2020-11-16 09:14:54 --> URI Class Initialized
INFO - 2020-11-16 09:14:54 --> Router Class Initialized
INFO - 2020-11-16 09:14:54 --> Output Class Initialized
INFO - 2020-11-16 09:14:54 --> Security Class Initialized
DEBUG - 2020-11-16 09:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:14:54 --> Input Class Initialized
INFO - 2020-11-16 09:14:54 --> Language Class Initialized
INFO - 2020-11-16 09:14:54 --> Language Class Initialized
INFO - 2020-11-16 09:14:54 --> Config Class Initialized
INFO - 2020-11-16 09:14:54 --> Loader Class Initialized
INFO - 2020-11-16 09:14:54 --> Helper loaded: url_helper
INFO - 2020-11-16 09:14:55 --> Helper loaded: file_helper
INFO - 2020-11-16 09:14:55 --> Helper loaded: form_helper
INFO - 2020-11-16 09:14:55 --> Helper loaded: my_helper
INFO - 2020-11-16 09:14:55 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:14:55 --> Controller Class Initialized
DEBUG - 2020-11-16 09:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-16 09:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:14:55 --> Final output sent to browser
DEBUG - 2020-11-16 09:14:55 --> Total execution time: 0.3003
INFO - 2020-11-16 09:40:12 --> Config Class Initialized
INFO - 2020-11-16 09:40:12 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:40:12 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:40:12 --> Utf8 Class Initialized
INFO - 2020-11-16 09:40:12 --> URI Class Initialized
INFO - 2020-11-16 09:40:12 --> Router Class Initialized
INFO - 2020-11-16 09:40:12 --> Output Class Initialized
INFO - 2020-11-16 09:40:12 --> Security Class Initialized
DEBUG - 2020-11-16 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:40:12 --> Input Class Initialized
INFO - 2020-11-16 09:40:12 --> Language Class Initialized
INFO - 2020-11-16 09:40:12 --> Language Class Initialized
INFO - 2020-11-16 09:40:12 --> Config Class Initialized
INFO - 2020-11-16 09:40:12 --> Loader Class Initialized
INFO - 2020-11-16 09:40:12 --> Helper loaded: url_helper
INFO - 2020-11-16 09:40:12 --> Helper loaded: file_helper
INFO - 2020-11-16 09:40:12 --> Helper loaded: form_helper
INFO - 2020-11-16 09:40:12 --> Helper loaded: my_helper
INFO - 2020-11-16 09:40:12 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:40:12 --> Controller Class Initialized
DEBUG - 2020-11-16 09:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-16 09:40:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:40:12 --> Final output sent to browser
DEBUG - 2020-11-16 09:40:12 --> Total execution time: 0.2952
INFO - 2020-11-16 09:40:14 --> Config Class Initialized
INFO - 2020-11-16 09:40:14 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:40:14 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:40:14 --> Utf8 Class Initialized
INFO - 2020-11-16 09:40:14 --> URI Class Initialized
INFO - 2020-11-16 09:40:14 --> Router Class Initialized
INFO - 2020-11-16 09:40:14 --> Output Class Initialized
INFO - 2020-11-16 09:40:14 --> Security Class Initialized
DEBUG - 2020-11-16 09:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:40:14 --> Input Class Initialized
INFO - 2020-11-16 09:40:14 --> Language Class Initialized
INFO - 2020-11-16 09:40:14 --> Language Class Initialized
INFO - 2020-11-16 09:40:14 --> Config Class Initialized
INFO - 2020-11-16 09:40:14 --> Loader Class Initialized
INFO - 2020-11-16 09:40:14 --> Helper loaded: url_helper
INFO - 2020-11-16 09:40:14 --> Helper loaded: file_helper
INFO - 2020-11-16 09:40:14 --> Helper loaded: form_helper
INFO - 2020-11-16 09:40:14 --> Helper loaded: my_helper
INFO - 2020-11-16 09:40:14 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:40:14 --> Controller Class Initialized
INFO - 2020-11-16 09:40:14 --> Final output sent to browser
DEBUG - 2020-11-16 09:40:14 --> Total execution time: 0.1801
INFO - 2020-11-16 09:40:50 --> Config Class Initialized
INFO - 2020-11-16 09:40:50 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:40:50 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:40:50 --> Utf8 Class Initialized
INFO - 2020-11-16 09:40:50 --> URI Class Initialized
INFO - 2020-11-16 09:40:50 --> Router Class Initialized
INFO - 2020-11-16 09:40:50 --> Output Class Initialized
INFO - 2020-11-16 09:40:50 --> Security Class Initialized
DEBUG - 2020-11-16 09:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:40:50 --> Input Class Initialized
INFO - 2020-11-16 09:40:50 --> Language Class Initialized
INFO - 2020-11-16 09:40:50 --> Language Class Initialized
INFO - 2020-11-16 09:40:50 --> Config Class Initialized
INFO - 2020-11-16 09:40:50 --> Loader Class Initialized
INFO - 2020-11-16 09:40:50 --> Helper loaded: url_helper
INFO - 2020-11-16 09:40:50 --> Helper loaded: file_helper
INFO - 2020-11-16 09:40:50 --> Helper loaded: form_helper
INFO - 2020-11-16 09:40:50 --> Helper loaded: my_helper
INFO - 2020-11-16 09:40:50 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:40:50 --> Controller Class Initialized
DEBUG - 2020-11-16 09:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-16 09:40:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:40:50 --> Final output sent to browser
DEBUG - 2020-11-16 09:40:50 --> Total execution time: 0.2649
INFO - 2020-11-16 09:40:55 --> Config Class Initialized
INFO - 2020-11-16 09:40:55 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:40:55 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:40:55 --> Utf8 Class Initialized
INFO - 2020-11-16 09:40:55 --> URI Class Initialized
INFO - 2020-11-16 09:40:55 --> Router Class Initialized
INFO - 2020-11-16 09:40:55 --> Output Class Initialized
INFO - 2020-11-16 09:40:55 --> Security Class Initialized
DEBUG - 2020-11-16 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:40:55 --> Input Class Initialized
INFO - 2020-11-16 09:40:55 --> Language Class Initialized
INFO - 2020-11-16 09:40:55 --> Language Class Initialized
INFO - 2020-11-16 09:40:55 --> Config Class Initialized
INFO - 2020-11-16 09:40:55 --> Loader Class Initialized
INFO - 2020-11-16 09:40:55 --> Helper loaded: url_helper
INFO - 2020-11-16 09:40:55 --> Helper loaded: file_helper
INFO - 2020-11-16 09:40:55 --> Helper loaded: form_helper
INFO - 2020-11-16 09:40:55 --> Helper loaded: my_helper
INFO - 2020-11-16 09:40:55 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:40:55 --> Controller Class Initialized
DEBUG - 2020-11-16 09:40:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-11-16 09:40:55 --> Final output sent to browser
DEBUG - 2020-11-16 09:40:55 --> Total execution time: 0.2547
INFO - 2020-11-16 09:41:16 --> Config Class Initialized
INFO - 2020-11-16 09:41:16 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:41:16 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:41:16 --> Utf8 Class Initialized
INFO - 2020-11-16 09:41:16 --> URI Class Initialized
INFO - 2020-11-16 09:41:16 --> Router Class Initialized
INFO - 2020-11-16 09:41:16 --> Output Class Initialized
INFO - 2020-11-16 09:41:16 --> Security Class Initialized
DEBUG - 2020-11-16 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:41:16 --> Input Class Initialized
INFO - 2020-11-16 09:41:16 --> Language Class Initialized
INFO - 2020-11-16 09:41:16 --> Language Class Initialized
INFO - 2020-11-16 09:41:16 --> Config Class Initialized
INFO - 2020-11-16 09:41:16 --> Loader Class Initialized
INFO - 2020-11-16 09:41:16 --> Helper loaded: url_helper
INFO - 2020-11-16 09:41:16 --> Helper loaded: file_helper
INFO - 2020-11-16 09:41:16 --> Helper loaded: form_helper
INFO - 2020-11-16 09:41:16 --> Helper loaded: my_helper
INFO - 2020-11-16 09:41:16 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:41:16 --> Controller Class Initialized
DEBUG - 2020-11-16 09:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-16 09:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:41:16 --> Final output sent to browser
DEBUG - 2020-11-16 09:41:16 --> Total execution time: 0.2599
INFO - 2020-11-16 09:41:29 --> Config Class Initialized
INFO - 2020-11-16 09:41:29 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:41:29 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:41:29 --> Utf8 Class Initialized
INFO - 2020-11-16 09:41:29 --> URI Class Initialized
INFO - 2020-11-16 09:41:29 --> Router Class Initialized
INFO - 2020-11-16 09:41:29 --> Output Class Initialized
INFO - 2020-11-16 09:41:29 --> Security Class Initialized
DEBUG - 2020-11-16 09:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:41:29 --> Input Class Initialized
INFO - 2020-11-16 09:41:29 --> Language Class Initialized
INFO - 2020-11-16 09:41:29 --> Language Class Initialized
INFO - 2020-11-16 09:41:29 --> Config Class Initialized
INFO - 2020-11-16 09:41:29 --> Loader Class Initialized
INFO - 2020-11-16 09:41:29 --> Helper loaded: url_helper
INFO - 2020-11-16 09:41:29 --> Helper loaded: file_helper
INFO - 2020-11-16 09:41:29 --> Helper loaded: form_helper
INFO - 2020-11-16 09:41:29 --> Helper loaded: my_helper
INFO - 2020-11-16 09:41:29 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:41:29 --> Controller Class Initialized
DEBUG - 2020-11-16 09:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-16 09:41:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:41:29 --> Final output sent to browser
DEBUG - 2020-11-16 09:41:29 --> Total execution time: 0.2679
INFO - 2020-11-16 09:41:31 --> Config Class Initialized
INFO - 2020-11-16 09:41:31 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:41:31 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:41:31 --> Utf8 Class Initialized
INFO - 2020-11-16 09:41:31 --> URI Class Initialized
INFO - 2020-11-16 09:41:31 --> Router Class Initialized
INFO - 2020-11-16 09:41:31 --> Output Class Initialized
INFO - 2020-11-16 09:41:31 --> Security Class Initialized
DEBUG - 2020-11-16 09:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:41:31 --> Input Class Initialized
INFO - 2020-11-16 09:41:31 --> Language Class Initialized
INFO - 2020-11-16 09:41:31 --> Language Class Initialized
INFO - 2020-11-16 09:41:31 --> Config Class Initialized
INFO - 2020-11-16 09:41:31 --> Loader Class Initialized
INFO - 2020-11-16 09:41:31 --> Helper loaded: url_helper
INFO - 2020-11-16 09:41:31 --> Helper loaded: file_helper
INFO - 2020-11-16 09:41:31 --> Helper loaded: form_helper
INFO - 2020-11-16 09:41:31 --> Helper loaded: my_helper
INFO - 2020-11-16 09:41:31 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:41:31 --> Controller Class Initialized
DEBUG - 2020-11-16 09:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-16 09:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:41:31 --> Final output sent to browser
DEBUG - 2020-11-16 09:41:31 --> Total execution time: 0.2157
INFO - 2020-11-16 09:41:35 --> Config Class Initialized
INFO - 2020-11-16 09:41:35 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:41:35 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:41:35 --> Utf8 Class Initialized
INFO - 2020-11-16 09:41:35 --> URI Class Initialized
INFO - 2020-11-16 09:41:35 --> Router Class Initialized
INFO - 2020-11-16 09:41:35 --> Output Class Initialized
INFO - 2020-11-16 09:41:35 --> Security Class Initialized
DEBUG - 2020-11-16 09:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:41:35 --> Input Class Initialized
INFO - 2020-11-16 09:41:35 --> Language Class Initialized
INFO - 2020-11-16 09:41:35 --> Language Class Initialized
INFO - 2020-11-16 09:41:35 --> Config Class Initialized
INFO - 2020-11-16 09:41:35 --> Loader Class Initialized
INFO - 2020-11-16 09:41:35 --> Helper loaded: url_helper
INFO - 2020-11-16 09:41:35 --> Helper loaded: file_helper
INFO - 2020-11-16 09:41:35 --> Helper loaded: form_helper
INFO - 2020-11-16 09:41:35 --> Helper loaded: my_helper
INFO - 2020-11-16 09:41:35 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:41:35 --> Controller Class Initialized
DEBUG - 2020-11-16 09:41:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/cetak.php
INFO - 2020-11-16 09:41:35 --> Final output sent to browser
DEBUG - 2020-11-16 09:41:35 --> Total execution time: 0.2469
INFO - 2020-11-16 09:43:26 --> Config Class Initialized
INFO - 2020-11-16 09:43:26 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:43:26 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:43:26 --> Utf8 Class Initialized
INFO - 2020-11-16 09:43:26 --> URI Class Initialized
INFO - 2020-11-16 09:43:26 --> Router Class Initialized
INFO - 2020-11-16 09:43:26 --> Output Class Initialized
INFO - 2020-11-16 09:43:27 --> Security Class Initialized
DEBUG - 2020-11-16 09:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:43:27 --> Input Class Initialized
INFO - 2020-11-16 09:43:27 --> Language Class Initialized
INFO - 2020-11-16 09:43:27 --> Language Class Initialized
INFO - 2020-11-16 09:43:27 --> Config Class Initialized
INFO - 2020-11-16 09:43:27 --> Loader Class Initialized
INFO - 2020-11-16 09:43:27 --> Helper loaded: url_helper
INFO - 2020-11-16 09:43:27 --> Helper loaded: file_helper
INFO - 2020-11-16 09:43:27 --> Helper loaded: form_helper
INFO - 2020-11-16 09:43:27 --> Helper loaded: my_helper
INFO - 2020-11-16 09:43:27 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:43:27 --> Controller Class Initialized
DEBUG - 2020-11-16 09:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-16 09:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:43:27 --> Final output sent to browser
DEBUG - 2020-11-16 09:43:27 --> Total execution time: 0.2220
INFO - 2020-11-16 09:43:28 --> Config Class Initialized
INFO - 2020-11-16 09:43:28 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:43:28 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:43:28 --> Utf8 Class Initialized
INFO - 2020-11-16 09:43:28 --> URI Class Initialized
INFO - 2020-11-16 09:43:28 --> Router Class Initialized
INFO - 2020-11-16 09:43:28 --> Output Class Initialized
INFO - 2020-11-16 09:43:28 --> Security Class Initialized
DEBUG - 2020-11-16 09:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:43:28 --> Input Class Initialized
INFO - 2020-11-16 09:43:28 --> Language Class Initialized
INFO - 2020-11-16 09:43:28 --> Language Class Initialized
INFO - 2020-11-16 09:43:28 --> Config Class Initialized
INFO - 2020-11-16 09:43:28 --> Loader Class Initialized
INFO - 2020-11-16 09:43:28 --> Helper loaded: url_helper
INFO - 2020-11-16 09:43:28 --> Helper loaded: file_helper
INFO - 2020-11-16 09:43:28 --> Helper loaded: form_helper
INFO - 2020-11-16 09:43:28 --> Helper loaded: my_helper
INFO - 2020-11-16 09:43:28 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:43:28 --> Controller Class Initialized
DEBUG - 2020-11-16 09:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-16 09:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:43:28 --> Final output sent to browser
DEBUG - 2020-11-16 09:43:28 --> Total execution time: 0.2633
INFO - 2020-11-16 09:43:29 --> Config Class Initialized
INFO - 2020-11-16 09:43:29 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:43:29 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:43:29 --> Utf8 Class Initialized
INFO - 2020-11-16 09:43:29 --> URI Class Initialized
INFO - 2020-11-16 09:43:29 --> Router Class Initialized
INFO - 2020-11-16 09:43:29 --> Output Class Initialized
INFO - 2020-11-16 09:43:29 --> Security Class Initialized
DEBUG - 2020-11-16 09:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:43:29 --> Input Class Initialized
INFO - 2020-11-16 09:43:29 --> Language Class Initialized
INFO - 2020-11-16 09:43:29 --> Language Class Initialized
INFO - 2020-11-16 09:43:29 --> Config Class Initialized
INFO - 2020-11-16 09:43:29 --> Loader Class Initialized
INFO - 2020-11-16 09:43:29 --> Helper loaded: url_helper
INFO - 2020-11-16 09:43:29 --> Helper loaded: file_helper
INFO - 2020-11-16 09:43:29 --> Helper loaded: form_helper
INFO - 2020-11-16 09:43:29 --> Helper loaded: my_helper
INFO - 2020-11-16 09:43:29 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:43:29 --> Controller Class Initialized
DEBUG - 2020-11-16 09:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-16 09:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:43:29 --> Final output sent to browser
DEBUG - 2020-11-16 09:43:29 --> Total execution time: 0.2347
INFO - 2020-11-16 09:43:34 --> Config Class Initialized
INFO - 2020-11-16 09:43:34 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:43:34 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:43:34 --> Utf8 Class Initialized
INFO - 2020-11-16 09:43:34 --> URI Class Initialized
INFO - 2020-11-16 09:43:34 --> Router Class Initialized
INFO - 2020-11-16 09:43:34 --> Output Class Initialized
INFO - 2020-11-16 09:43:34 --> Security Class Initialized
DEBUG - 2020-11-16 09:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:43:34 --> Input Class Initialized
INFO - 2020-11-16 09:43:34 --> Language Class Initialized
INFO - 2020-11-16 09:43:34 --> Language Class Initialized
INFO - 2020-11-16 09:43:34 --> Config Class Initialized
INFO - 2020-11-16 09:43:34 --> Loader Class Initialized
INFO - 2020-11-16 09:43:34 --> Helper loaded: url_helper
INFO - 2020-11-16 09:43:34 --> Helper loaded: file_helper
INFO - 2020-11-16 09:43:34 --> Helper loaded: form_helper
INFO - 2020-11-16 09:43:34 --> Helper loaded: my_helper
INFO - 2020-11-16 09:43:34 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:43:34 --> Controller Class Initialized
DEBUG - 2020-11-16 09:43:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-16 09:43:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:43:34 --> Final output sent to browser
DEBUG - 2020-11-16 09:43:34 --> Total execution time: 0.2107
INFO - 2020-11-16 09:43:37 --> Config Class Initialized
INFO - 2020-11-16 09:43:37 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:43:37 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:43:37 --> Utf8 Class Initialized
INFO - 2020-11-16 09:43:37 --> URI Class Initialized
INFO - 2020-11-16 09:43:37 --> Router Class Initialized
INFO - 2020-11-16 09:43:37 --> Output Class Initialized
INFO - 2020-11-16 09:43:37 --> Security Class Initialized
DEBUG - 2020-11-16 09:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:43:37 --> Input Class Initialized
INFO - 2020-11-16 09:43:37 --> Language Class Initialized
INFO - 2020-11-16 09:43:37 --> Language Class Initialized
INFO - 2020-11-16 09:43:37 --> Config Class Initialized
INFO - 2020-11-16 09:43:37 --> Loader Class Initialized
INFO - 2020-11-16 09:43:37 --> Helper loaded: url_helper
INFO - 2020-11-16 09:43:37 --> Helper loaded: file_helper
INFO - 2020-11-16 09:43:37 --> Helper loaded: form_helper
INFO - 2020-11-16 09:43:37 --> Helper loaded: my_helper
INFO - 2020-11-16 09:43:37 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:43:37 --> Controller Class Initialized
DEBUG - 2020-11-16 09:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-16 09:43:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:43:37 --> Final output sent to browser
DEBUG - 2020-11-16 09:43:37 --> Total execution time: 0.2154
INFO - 2020-11-16 09:43:39 --> Config Class Initialized
INFO - 2020-11-16 09:43:39 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:43:39 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:43:39 --> Utf8 Class Initialized
INFO - 2020-11-16 09:43:39 --> URI Class Initialized
INFO - 2020-11-16 09:43:39 --> Router Class Initialized
INFO - 2020-11-16 09:43:39 --> Output Class Initialized
INFO - 2020-11-16 09:43:39 --> Security Class Initialized
DEBUG - 2020-11-16 09:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:43:39 --> Input Class Initialized
INFO - 2020-11-16 09:43:39 --> Language Class Initialized
INFO - 2020-11-16 09:43:39 --> Language Class Initialized
INFO - 2020-11-16 09:43:39 --> Config Class Initialized
INFO - 2020-11-16 09:43:39 --> Loader Class Initialized
INFO - 2020-11-16 09:43:39 --> Helper loaded: url_helper
INFO - 2020-11-16 09:43:39 --> Helper loaded: file_helper
INFO - 2020-11-16 09:43:39 --> Helper loaded: form_helper
INFO - 2020-11-16 09:43:39 --> Helper loaded: my_helper
INFO - 2020-11-16 09:43:39 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:43:39 --> Controller Class Initialized
DEBUG - 2020-11-16 09:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-16 09:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:43:39 --> Final output sent to browser
DEBUG - 2020-11-16 09:43:39 --> Total execution time: 0.2164
INFO - 2020-11-16 09:44:36 --> Config Class Initialized
INFO - 2020-11-16 09:44:36 --> Hooks Class Initialized
DEBUG - 2020-11-16 09:44:36 --> UTF-8 Support Enabled
INFO - 2020-11-16 09:44:36 --> Utf8 Class Initialized
INFO - 2020-11-16 09:44:36 --> URI Class Initialized
INFO - 2020-11-16 09:44:36 --> Router Class Initialized
INFO - 2020-11-16 09:44:36 --> Output Class Initialized
INFO - 2020-11-16 09:44:36 --> Security Class Initialized
DEBUG - 2020-11-16 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-16 09:44:36 --> Input Class Initialized
INFO - 2020-11-16 09:44:36 --> Language Class Initialized
INFO - 2020-11-16 09:44:36 --> Language Class Initialized
INFO - 2020-11-16 09:44:36 --> Config Class Initialized
INFO - 2020-11-16 09:44:36 --> Loader Class Initialized
INFO - 2020-11-16 09:44:36 --> Helper loaded: url_helper
INFO - 2020-11-16 09:44:36 --> Helper loaded: file_helper
INFO - 2020-11-16 09:44:36 --> Helper loaded: form_helper
INFO - 2020-11-16 09:44:36 --> Helper loaded: my_helper
INFO - 2020-11-16 09:44:36 --> Database Driver Class Initialized
DEBUG - 2020-11-16 09:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-16 09:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-16 09:44:36 --> Controller Class Initialized
DEBUG - 2020-11-16 09:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-16 09:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-16 09:44:36 --> Final output sent to browser
DEBUG - 2020-11-16 09:44:36 --> Total execution time: 0.2180
