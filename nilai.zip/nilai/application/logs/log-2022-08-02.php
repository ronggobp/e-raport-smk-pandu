<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-08-02 03:48:57 --> Config Class Initialized
INFO - 2022-08-02 03:48:57 --> Hooks Class Initialized
DEBUG - 2022-08-02 03:48:57 --> UTF-8 Support Enabled
INFO - 2022-08-02 03:48:57 --> Utf8 Class Initialized
INFO - 2022-08-02 03:48:57 --> URI Class Initialized
INFO - 2022-08-02 03:48:57 --> Router Class Initialized
INFO - 2022-08-02 03:48:57 --> Output Class Initialized
INFO - 2022-08-02 03:48:57 --> Security Class Initialized
DEBUG - 2022-08-02 03:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 03:48:57 --> Input Class Initialized
INFO - 2022-08-02 03:48:57 --> Language Class Initialized
INFO - 2022-08-02 03:48:57 --> Language Class Initialized
INFO - 2022-08-02 03:48:57 --> Config Class Initialized
INFO - 2022-08-02 03:48:57 --> Loader Class Initialized
INFO - 2022-08-02 03:48:57 --> Helper loaded: url_helper
INFO - 2022-08-02 03:48:57 --> Helper loaded: file_helper
INFO - 2022-08-02 03:48:57 --> Helper loaded: form_helper
INFO - 2022-08-02 03:48:57 --> Helper loaded: my_helper
INFO - 2022-08-02 03:48:57 --> Database Driver Class Initialized
DEBUG - 2022-08-02 03:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 03:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 03:48:57 --> Controller Class Initialized
DEBUG - 2022-08-02 03:48:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-08-02 03:48:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 03:48:57 --> Final output sent to browser
DEBUG - 2022-08-02 03:48:57 --> Total execution time: 0.0906
INFO - 2022-08-02 03:59:56 --> Config Class Initialized
INFO - 2022-08-02 03:59:56 --> Hooks Class Initialized
DEBUG - 2022-08-02 03:59:56 --> UTF-8 Support Enabled
INFO - 2022-08-02 03:59:56 --> Utf8 Class Initialized
INFO - 2022-08-02 03:59:56 --> URI Class Initialized
INFO - 2022-08-02 03:59:56 --> Router Class Initialized
INFO - 2022-08-02 03:59:56 --> Output Class Initialized
INFO - 2022-08-02 03:59:56 --> Security Class Initialized
DEBUG - 2022-08-02 03:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 03:59:56 --> Input Class Initialized
INFO - 2022-08-02 03:59:56 --> Language Class Initialized
INFO - 2022-08-02 03:59:56 --> Language Class Initialized
INFO - 2022-08-02 03:59:56 --> Config Class Initialized
INFO - 2022-08-02 03:59:56 --> Loader Class Initialized
INFO - 2022-08-02 03:59:56 --> Helper loaded: url_helper
INFO - 2022-08-02 03:59:56 --> Helper loaded: file_helper
INFO - 2022-08-02 03:59:56 --> Helper loaded: form_helper
INFO - 2022-08-02 03:59:56 --> Helper loaded: my_helper
INFO - 2022-08-02 03:59:56 --> Database Driver Class Initialized
DEBUG - 2022-08-02 03:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 03:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 03:59:56 --> Controller Class Initialized
INFO - 2022-08-02 03:59:56 --> Helper loaded: cookie_helper
INFO - 2022-08-02 03:59:56 --> Final output sent to browser
DEBUG - 2022-08-02 03:59:56 --> Total execution time: 0.6088
INFO - 2022-08-02 03:59:57 --> Config Class Initialized
INFO - 2022-08-02 03:59:57 --> Hooks Class Initialized
DEBUG - 2022-08-02 03:59:57 --> UTF-8 Support Enabled
INFO - 2022-08-02 03:59:57 --> Utf8 Class Initialized
INFO - 2022-08-02 03:59:57 --> URI Class Initialized
INFO - 2022-08-02 03:59:57 --> Router Class Initialized
INFO - 2022-08-02 03:59:57 --> Output Class Initialized
INFO - 2022-08-02 03:59:57 --> Security Class Initialized
DEBUG - 2022-08-02 03:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 03:59:57 --> Input Class Initialized
INFO - 2022-08-02 03:59:57 --> Language Class Initialized
INFO - 2022-08-02 03:59:57 --> Language Class Initialized
INFO - 2022-08-02 03:59:57 --> Config Class Initialized
INFO - 2022-08-02 03:59:57 --> Loader Class Initialized
INFO - 2022-08-02 03:59:57 --> Helper loaded: url_helper
INFO - 2022-08-02 03:59:57 --> Helper loaded: file_helper
INFO - 2022-08-02 03:59:57 --> Helper loaded: form_helper
INFO - 2022-08-02 03:59:57 --> Helper loaded: my_helper
INFO - 2022-08-02 03:59:57 --> Database Driver Class Initialized
DEBUG - 2022-08-02 03:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 03:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 03:59:57 --> Controller Class Initialized
DEBUG - 2022-08-02 03:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-08-02 03:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 03:59:57 --> Final output sent to browser
DEBUG - 2022-08-02 03:59:57 --> Total execution time: 0.2309
INFO - 2022-08-02 04:02:28 --> Config Class Initialized
INFO - 2022-08-02 04:02:28 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:28 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:28 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:28 --> URI Class Initialized
INFO - 2022-08-02 04:02:28 --> Router Class Initialized
INFO - 2022-08-02 04:02:28 --> Output Class Initialized
INFO - 2022-08-02 04:02:28 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:28 --> Input Class Initialized
INFO - 2022-08-02 04:02:28 --> Language Class Initialized
INFO - 2022-08-02 04:02:28 --> Language Class Initialized
INFO - 2022-08-02 04:02:28 --> Config Class Initialized
INFO - 2022-08-02 04:02:28 --> Loader Class Initialized
INFO - 2022-08-02 04:02:28 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:28 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:28 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:28 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:28 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:28 --> Controller Class Initialized
DEBUG - 2022-08-02 04:02:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-08-02 04:02:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:02:28 --> Final output sent to browser
DEBUG - 2022-08-02 04:02:28 --> Total execution time: 0.0939
INFO - 2022-08-02 04:02:28 --> Config Class Initialized
INFO - 2022-08-02 04:02:28 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:28 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:28 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:28 --> URI Class Initialized
INFO - 2022-08-02 04:02:28 --> Router Class Initialized
INFO - 2022-08-02 04:02:28 --> Output Class Initialized
INFO - 2022-08-02 04:02:28 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:28 --> Input Class Initialized
INFO - 2022-08-02 04:02:28 --> Language Class Initialized
INFO - 2022-08-02 04:02:28 --> Language Class Initialized
INFO - 2022-08-02 04:02:28 --> Config Class Initialized
INFO - 2022-08-02 04:02:28 --> Loader Class Initialized
INFO - 2022-08-02 04:02:28 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:28 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:28 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:28 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:28 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:28 --> Controller Class Initialized
INFO - 2022-08-02 04:02:31 --> Config Class Initialized
INFO - 2022-08-02 04:02:31 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:31 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:31 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:31 --> URI Class Initialized
INFO - 2022-08-02 04:02:31 --> Router Class Initialized
INFO - 2022-08-02 04:02:31 --> Output Class Initialized
INFO - 2022-08-02 04:02:31 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:31 --> Input Class Initialized
INFO - 2022-08-02 04:02:31 --> Language Class Initialized
INFO - 2022-08-02 04:02:31 --> Language Class Initialized
INFO - 2022-08-02 04:02:31 --> Config Class Initialized
INFO - 2022-08-02 04:02:31 --> Loader Class Initialized
INFO - 2022-08-02 04:02:31 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:31 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:31 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:31 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:31 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:31 --> Controller Class Initialized
INFO - 2022-08-02 04:02:31 --> Config Class Initialized
INFO - 2022-08-02 04:02:31 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:31 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:31 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:31 --> URI Class Initialized
INFO - 2022-08-02 04:02:31 --> Router Class Initialized
INFO - 2022-08-02 04:02:31 --> Output Class Initialized
INFO - 2022-08-02 04:02:31 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:31 --> Input Class Initialized
INFO - 2022-08-02 04:02:31 --> Language Class Initialized
INFO - 2022-08-02 04:02:31 --> Language Class Initialized
INFO - 2022-08-02 04:02:31 --> Config Class Initialized
INFO - 2022-08-02 04:02:31 --> Loader Class Initialized
INFO - 2022-08-02 04:02:31 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:31 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:31 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:31 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:31 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:31 --> Controller Class Initialized
INFO - 2022-08-02 04:02:32 --> Config Class Initialized
INFO - 2022-08-02 04:02:32 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:32 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:32 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:32 --> URI Class Initialized
INFO - 2022-08-02 04:02:32 --> Router Class Initialized
INFO - 2022-08-02 04:02:32 --> Output Class Initialized
INFO - 2022-08-02 04:02:32 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:32 --> Input Class Initialized
INFO - 2022-08-02 04:02:32 --> Language Class Initialized
INFO - 2022-08-02 04:02:32 --> Language Class Initialized
INFO - 2022-08-02 04:02:32 --> Config Class Initialized
INFO - 2022-08-02 04:02:32 --> Loader Class Initialized
INFO - 2022-08-02 04:02:32 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:32 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:32 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:32 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:32 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:32 --> Controller Class Initialized
INFO - 2022-08-02 04:02:32 --> Config Class Initialized
INFO - 2022-08-02 04:02:32 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:32 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:32 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:32 --> URI Class Initialized
INFO - 2022-08-02 04:02:32 --> Router Class Initialized
INFO - 2022-08-02 04:02:32 --> Output Class Initialized
INFO - 2022-08-02 04:02:32 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:32 --> Input Class Initialized
INFO - 2022-08-02 04:02:32 --> Language Class Initialized
INFO - 2022-08-02 04:02:32 --> Language Class Initialized
INFO - 2022-08-02 04:02:32 --> Config Class Initialized
INFO - 2022-08-02 04:02:32 --> Loader Class Initialized
INFO - 2022-08-02 04:02:32 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:32 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:32 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:32 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:32 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:32 --> Controller Class Initialized
INFO - 2022-08-02 04:02:33 --> Config Class Initialized
INFO - 2022-08-02 04:02:33 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:33 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:33 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:33 --> URI Class Initialized
INFO - 2022-08-02 04:02:33 --> Router Class Initialized
INFO - 2022-08-02 04:02:33 --> Output Class Initialized
INFO - 2022-08-02 04:02:33 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:33 --> Input Class Initialized
INFO - 2022-08-02 04:02:33 --> Language Class Initialized
INFO - 2022-08-02 04:02:33 --> Language Class Initialized
INFO - 2022-08-02 04:02:33 --> Config Class Initialized
INFO - 2022-08-02 04:02:33 --> Loader Class Initialized
INFO - 2022-08-02 04:02:33 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:33 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:33 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:33 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:33 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:33 --> Controller Class Initialized
INFO - 2022-08-02 04:02:34 --> Config Class Initialized
INFO - 2022-08-02 04:02:34 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:34 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:34 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:34 --> URI Class Initialized
INFO - 2022-08-02 04:02:34 --> Router Class Initialized
INFO - 2022-08-02 04:02:34 --> Output Class Initialized
INFO - 2022-08-02 04:02:34 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:34 --> Input Class Initialized
INFO - 2022-08-02 04:02:34 --> Language Class Initialized
INFO - 2022-08-02 04:02:34 --> Language Class Initialized
INFO - 2022-08-02 04:02:34 --> Config Class Initialized
INFO - 2022-08-02 04:02:34 --> Loader Class Initialized
INFO - 2022-08-02 04:02:34 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:34 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:34 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:34 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:34 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:34 --> Controller Class Initialized
INFO - 2022-08-02 04:02:35 --> Config Class Initialized
INFO - 2022-08-02 04:02:35 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:35 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:35 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:35 --> URI Class Initialized
INFO - 2022-08-02 04:02:35 --> Router Class Initialized
INFO - 2022-08-02 04:02:35 --> Output Class Initialized
INFO - 2022-08-02 04:02:35 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:35 --> Input Class Initialized
INFO - 2022-08-02 04:02:35 --> Language Class Initialized
INFO - 2022-08-02 04:02:35 --> Language Class Initialized
INFO - 2022-08-02 04:02:35 --> Config Class Initialized
INFO - 2022-08-02 04:02:35 --> Loader Class Initialized
INFO - 2022-08-02 04:02:35 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:35 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:35 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:35 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:35 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:35 --> Controller Class Initialized
INFO - 2022-08-02 04:02:36 --> Config Class Initialized
INFO - 2022-08-02 04:02:36 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:02:36 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:02:36 --> Utf8 Class Initialized
INFO - 2022-08-02 04:02:36 --> URI Class Initialized
INFO - 2022-08-02 04:02:36 --> Router Class Initialized
INFO - 2022-08-02 04:02:36 --> Output Class Initialized
INFO - 2022-08-02 04:02:36 --> Security Class Initialized
DEBUG - 2022-08-02 04:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:02:36 --> Input Class Initialized
INFO - 2022-08-02 04:02:36 --> Language Class Initialized
INFO - 2022-08-02 04:02:36 --> Language Class Initialized
INFO - 2022-08-02 04:02:36 --> Config Class Initialized
INFO - 2022-08-02 04:02:36 --> Loader Class Initialized
INFO - 2022-08-02 04:02:36 --> Helper loaded: url_helper
INFO - 2022-08-02 04:02:36 --> Helper loaded: file_helper
INFO - 2022-08-02 04:02:36 --> Helper loaded: form_helper
INFO - 2022-08-02 04:02:36 --> Helper loaded: my_helper
INFO - 2022-08-02 04:02:36 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:02:36 --> Controller Class Initialized
ERROR - 2022-08-02 04:02:36 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-08-02 04:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-08-02 04:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:02:36 --> Final output sent to browser
DEBUG - 2022-08-02 04:02:36 --> Total execution time: 0.1235
INFO - 2022-08-02 04:04:18 --> Config Class Initialized
INFO - 2022-08-02 04:04:18 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:18 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:18 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:18 --> URI Class Initialized
INFO - 2022-08-02 04:04:18 --> Router Class Initialized
INFO - 2022-08-02 04:04:18 --> Output Class Initialized
INFO - 2022-08-02 04:04:18 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:18 --> Input Class Initialized
INFO - 2022-08-02 04:04:18 --> Language Class Initialized
INFO - 2022-08-02 04:04:18 --> Language Class Initialized
INFO - 2022-08-02 04:04:18 --> Config Class Initialized
INFO - 2022-08-02 04:04:18 --> Loader Class Initialized
INFO - 2022-08-02 04:04:18 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:18 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:18 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:18 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:18 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:18 --> Controller Class Initialized
INFO - 2022-08-02 04:04:18 --> Upload Class Initialized
INFO - 2022-08-02 04:04:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-08-02 04:04:18 --> The upload path does not appear to be valid.
INFO - 2022-08-02 04:04:19 --> Config Class Initialized
INFO - 2022-08-02 04:04:19 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:19 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:19 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:19 --> URI Class Initialized
INFO - 2022-08-02 04:04:19 --> Router Class Initialized
INFO - 2022-08-02 04:04:19 --> Output Class Initialized
INFO - 2022-08-02 04:04:19 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:19 --> Input Class Initialized
INFO - 2022-08-02 04:04:19 --> Language Class Initialized
INFO - 2022-08-02 04:04:19 --> Language Class Initialized
INFO - 2022-08-02 04:04:19 --> Config Class Initialized
INFO - 2022-08-02 04:04:19 --> Loader Class Initialized
INFO - 2022-08-02 04:04:19 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:19 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:19 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:19 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:19 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:19 --> Controller Class Initialized
DEBUG - 2022-08-02 04:04:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-08-02 04:04:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:04:19 --> Final output sent to browser
DEBUG - 2022-08-02 04:04:19 --> Total execution time: 0.0646
INFO - 2022-08-02 04:04:19 --> Config Class Initialized
INFO - 2022-08-02 04:04:19 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:19 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:19 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:19 --> URI Class Initialized
INFO - 2022-08-02 04:04:19 --> Router Class Initialized
INFO - 2022-08-02 04:04:19 --> Output Class Initialized
INFO - 2022-08-02 04:04:19 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:19 --> Input Class Initialized
INFO - 2022-08-02 04:04:19 --> Language Class Initialized
INFO - 2022-08-02 04:04:19 --> Language Class Initialized
INFO - 2022-08-02 04:04:19 --> Config Class Initialized
INFO - 2022-08-02 04:04:19 --> Loader Class Initialized
INFO - 2022-08-02 04:04:19 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:19 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:19 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:19 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:19 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:19 --> Controller Class Initialized
INFO - 2022-08-02 04:04:20 --> Config Class Initialized
INFO - 2022-08-02 04:04:20 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:20 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:20 --> URI Class Initialized
INFO - 2022-08-02 04:04:20 --> Router Class Initialized
INFO - 2022-08-02 04:04:20 --> Output Class Initialized
INFO - 2022-08-02 04:04:20 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:20 --> Input Class Initialized
INFO - 2022-08-02 04:04:20 --> Language Class Initialized
INFO - 2022-08-02 04:04:20 --> Language Class Initialized
INFO - 2022-08-02 04:04:20 --> Config Class Initialized
INFO - 2022-08-02 04:04:20 --> Loader Class Initialized
INFO - 2022-08-02 04:04:20 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:20 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:20 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:20 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:20 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:20 --> Controller Class Initialized
INFO - 2022-08-02 04:04:20 --> Helper loaded: cookie_helper
INFO - 2022-08-02 04:04:20 --> Config Class Initialized
INFO - 2022-08-02 04:04:20 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:20 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:20 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:20 --> URI Class Initialized
INFO - 2022-08-02 04:04:20 --> Router Class Initialized
INFO - 2022-08-02 04:04:20 --> Output Class Initialized
INFO - 2022-08-02 04:04:20 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:20 --> Input Class Initialized
INFO - 2022-08-02 04:04:20 --> Language Class Initialized
INFO - 2022-08-02 04:04:20 --> Language Class Initialized
INFO - 2022-08-02 04:04:20 --> Config Class Initialized
INFO - 2022-08-02 04:04:20 --> Loader Class Initialized
INFO - 2022-08-02 04:04:20 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:20 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:20 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:20 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:20 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:20 --> Controller Class Initialized
DEBUG - 2022-08-02 04:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-08-02 04:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:04:20 --> Final output sent to browser
DEBUG - 2022-08-02 04:04:20 --> Total execution time: 0.0657
INFO - 2022-08-02 04:04:28 --> Config Class Initialized
INFO - 2022-08-02 04:04:28 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:28 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:28 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:28 --> URI Class Initialized
INFO - 2022-08-02 04:04:28 --> Router Class Initialized
INFO - 2022-08-02 04:04:28 --> Output Class Initialized
INFO - 2022-08-02 04:04:28 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:28 --> Input Class Initialized
INFO - 2022-08-02 04:04:28 --> Language Class Initialized
INFO - 2022-08-02 04:04:28 --> Language Class Initialized
INFO - 2022-08-02 04:04:28 --> Config Class Initialized
INFO - 2022-08-02 04:04:28 --> Loader Class Initialized
INFO - 2022-08-02 04:04:28 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:28 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:28 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:28 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:28 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:28 --> Controller Class Initialized
INFO - 2022-08-02 04:04:28 --> Helper loaded: cookie_helper
INFO - 2022-08-02 04:04:28 --> Final output sent to browser
DEBUG - 2022-08-02 04:04:28 --> Total execution time: 0.0511
INFO - 2022-08-02 04:04:28 --> Config Class Initialized
INFO - 2022-08-02 04:04:28 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:28 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:28 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:28 --> URI Class Initialized
INFO - 2022-08-02 04:04:28 --> Router Class Initialized
INFO - 2022-08-02 04:04:28 --> Output Class Initialized
INFO - 2022-08-02 04:04:28 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:28 --> Input Class Initialized
INFO - 2022-08-02 04:04:28 --> Language Class Initialized
INFO - 2022-08-02 04:04:28 --> Language Class Initialized
INFO - 2022-08-02 04:04:28 --> Config Class Initialized
INFO - 2022-08-02 04:04:28 --> Loader Class Initialized
INFO - 2022-08-02 04:04:28 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:28 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:28 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:28 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:28 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:28 --> Controller Class Initialized
DEBUG - 2022-08-02 04:04:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-08-02 04:04:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:04:28 --> Final output sent to browser
DEBUG - 2022-08-02 04:04:28 --> Total execution time: 0.0957
INFO - 2022-08-02 04:04:53 --> Config Class Initialized
INFO - 2022-08-02 04:04:53 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:53 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:53 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:53 --> URI Class Initialized
INFO - 2022-08-02 04:04:53 --> Router Class Initialized
INFO - 2022-08-02 04:04:53 --> Output Class Initialized
INFO - 2022-08-02 04:04:53 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:53 --> Input Class Initialized
INFO - 2022-08-02 04:04:53 --> Language Class Initialized
INFO - 2022-08-02 04:04:53 --> Language Class Initialized
INFO - 2022-08-02 04:04:53 --> Config Class Initialized
INFO - 2022-08-02 04:04:53 --> Loader Class Initialized
INFO - 2022-08-02 04:04:53 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:53 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:53 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:53 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:53 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:53 --> Controller Class Initialized
DEBUG - 2022-08-02 04:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-08-02 04:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:04:53 --> Final output sent to browser
DEBUG - 2022-08-02 04:04:53 --> Total execution time: 0.0939
INFO - 2022-08-02 04:04:54 --> Config Class Initialized
INFO - 2022-08-02 04:04:54 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:04:54 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:04:54 --> Utf8 Class Initialized
INFO - 2022-08-02 04:04:54 --> URI Class Initialized
INFO - 2022-08-02 04:04:54 --> Router Class Initialized
INFO - 2022-08-02 04:04:54 --> Output Class Initialized
INFO - 2022-08-02 04:04:54 --> Security Class Initialized
DEBUG - 2022-08-02 04:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:04:54 --> Input Class Initialized
INFO - 2022-08-02 04:04:54 --> Language Class Initialized
INFO - 2022-08-02 04:04:54 --> Language Class Initialized
INFO - 2022-08-02 04:04:54 --> Config Class Initialized
INFO - 2022-08-02 04:04:54 --> Loader Class Initialized
INFO - 2022-08-02 04:04:54 --> Helper loaded: url_helper
INFO - 2022-08-02 04:04:54 --> Helper loaded: file_helper
INFO - 2022-08-02 04:04:54 --> Helper loaded: form_helper
INFO - 2022-08-02 04:04:54 --> Helper loaded: my_helper
INFO - 2022-08-02 04:04:54 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:04:54 --> Controller Class Initialized
DEBUG - 2022-08-02 04:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-08-02 04:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-08-02 04:04:54 --> Final output sent to browser
DEBUG - 2022-08-02 04:04:54 --> Total execution time: 0.1128
INFO - 2022-08-02 04:05:00 --> Config Class Initialized
INFO - 2022-08-02 04:05:00 --> Hooks Class Initialized
DEBUG - 2022-08-02 04:05:00 --> UTF-8 Support Enabled
INFO - 2022-08-02 04:05:00 --> Utf8 Class Initialized
INFO - 2022-08-02 04:05:00 --> URI Class Initialized
INFO - 2022-08-02 04:05:00 --> Router Class Initialized
INFO - 2022-08-02 04:05:00 --> Output Class Initialized
INFO - 2022-08-02 04:05:00 --> Security Class Initialized
DEBUG - 2022-08-02 04:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-08-02 04:05:00 --> Input Class Initialized
INFO - 2022-08-02 04:05:00 --> Language Class Initialized
INFO - 2022-08-02 04:05:00 --> Language Class Initialized
INFO - 2022-08-02 04:05:00 --> Config Class Initialized
INFO - 2022-08-02 04:05:00 --> Loader Class Initialized
INFO - 2022-08-02 04:05:00 --> Helper loaded: url_helper
INFO - 2022-08-02 04:05:00 --> Helper loaded: file_helper
INFO - 2022-08-02 04:05:00 --> Helper loaded: form_helper
INFO - 2022-08-02 04:05:00 --> Helper loaded: my_helper
INFO - 2022-08-02 04:05:00 --> Database Driver Class Initialized
DEBUG - 2022-08-02 04:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-08-02 04:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-08-02 04:05:00 --> Controller Class Initialized
DEBUG - 2022-08-02 04:05:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-08-02 04:05:00 --> Final output sent to browser
DEBUG - 2022-08-02 04:05:00 --> Total execution time: 0.0683
