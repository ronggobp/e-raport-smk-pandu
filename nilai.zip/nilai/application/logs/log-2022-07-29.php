<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-07-29 02:30:54 --> Config Class Initialized
INFO - 2022-07-29 02:30:54 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:30:54 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:30:54 --> Utf8 Class Initialized
INFO - 2022-07-29 02:30:54 --> URI Class Initialized
DEBUG - 2022-07-29 02:30:54 --> No URI present. Default controller set.
INFO - 2022-07-29 02:30:54 --> Router Class Initialized
INFO - 2022-07-29 02:30:54 --> Output Class Initialized
INFO - 2022-07-29 02:30:54 --> Security Class Initialized
DEBUG - 2022-07-29 02:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:30:54 --> Input Class Initialized
INFO - 2022-07-29 02:30:54 --> Language Class Initialized
INFO - 2022-07-29 02:30:55 --> Language Class Initialized
INFO - 2022-07-29 02:30:55 --> Config Class Initialized
INFO - 2022-07-29 02:30:55 --> Loader Class Initialized
INFO - 2022-07-29 02:30:55 --> Helper loaded: url_helper
INFO - 2022-07-29 02:30:55 --> Helper loaded: file_helper
INFO - 2022-07-29 02:30:55 --> Helper loaded: form_helper
INFO - 2022-07-29 02:30:55 --> Helper loaded: my_helper
INFO - 2022-07-29 02:30:55 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:30:55 --> Controller Class Initialized
INFO - 2022-07-29 02:30:55 --> Config Class Initialized
INFO - 2022-07-29 02:30:55 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:30:55 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:30:55 --> Utf8 Class Initialized
INFO - 2022-07-29 02:30:55 --> URI Class Initialized
INFO - 2022-07-29 02:30:55 --> Router Class Initialized
INFO - 2022-07-29 02:30:55 --> Output Class Initialized
INFO - 2022-07-29 02:30:55 --> Security Class Initialized
DEBUG - 2022-07-29 02:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:30:55 --> Input Class Initialized
INFO - 2022-07-29 02:30:55 --> Language Class Initialized
INFO - 2022-07-29 02:30:55 --> Language Class Initialized
INFO - 2022-07-29 02:30:55 --> Config Class Initialized
INFO - 2022-07-29 02:30:55 --> Loader Class Initialized
INFO - 2022-07-29 02:30:55 --> Helper loaded: url_helper
INFO - 2022-07-29 02:30:55 --> Helper loaded: file_helper
INFO - 2022-07-29 02:30:55 --> Helper loaded: form_helper
INFO - 2022-07-29 02:30:55 --> Helper loaded: my_helper
INFO - 2022-07-29 02:30:55 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:30:55 --> Controller Class Initialized
DEBUG - 2022-07-29 02:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-29 02:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 02:30:55 --> Final output sent to browser
DEBUG - 2022-07-29 02:30:55 --> Total execution time: 0.1005
INFO - 2022-07-29 02:31:01 --> Config Class Initialized
INFO - 2022-07-29 02:31:01 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:31:01 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:31:01 --> Utf8 Class Initialized
INFO - 2022-07-29 02:31:01 --> URI Class Initialized
INFO - 2022-07-29 02:31:01 --> Router Class Initialized
INFO - 2022-07-29 02:31:01 --> Output Class Initialized
INFO - 2022-07-29 02:31:01 --> Security Class Initialized
DEBUG - 2022-07-29 02:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:31:01 --> Input Class Initialized
INFO - 2022-07-29 02:31:01 --> Language Class Initialized
INFO - 2022-07-29 02:31:01 --> Language Class Initialized
INFO - 2022-07-29 02:31:01 --> Config Class Initialized
INFO - 2022-07-29 02:31:01 --> Loader Class Initialized
INFO - 2022-07-29 02:31:01 --> Helper loaded: url_helper
INFO - 2022-07-29 02:31:01 --> Helper loaded: file_helper
INFO - 2022-07-29 02:31:01 --> Helper loaded: form_helper
INFO - 2022-07-29 02:31:01 --> Helper loaded: my_helper
INFO - 2022-07-29 02:31:01 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:31:01 --> Controller Class Initialized
INFO - 2022-07-29 02:31:01 --> Final output sent to browser
DEBUG - 2022-07-29 02:31:01 --> Total execution time: 0.0516
INFO - 2022-07-29 02:31:04 --> Config Class Initialized
INFO - 2022-07-29 02:31:04 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:31:04 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:31:04 --> Utf8 Class Initialized
INFO - 2022-07-29 02:31:04 --> URI Class Initialized
INFO - 2022-07-29 02:31:04 --> Router Class Initialized
INFO - 2022-07-29 02:31:04 --> Output Class Initialized
INFO - 2022-07-29 02:31:04 --> Security Class Initialized
DEBUG - 2022-07-29 02:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:31:04 --> Input Class Initialized
INFO - 2022-07-29 02:31:04 --> Language Class Initialized
INFO - 2022-07-29 02:31:04 --> Language Class Initialized
INFO - 2022-07-29 02:31:04 --> Config Class Initialized
INFO - 2022-07-29 02:31:04 --> Loader Class Initialized
INFO - 2022-07-29 02:31:04 --> Helper loaded: url_helper
INFO - 2022-07-29 02:31:04 --> Helper loaded: file_helper
INFO - 2022-07-29 02:31:04 --> Helper loaded: form_helper
INFO - 2022-07-29 02:31:04 --> Helper loaded: my_helper
INFO - 2022-07-29 02:31:04 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:31:04 --> Controller Class Initialized
INFO - 2022-07-29 02:31:04 --> Helper loaded: cookie_helper
INFO - 2022-07-29 02:31:04 --> Final output sent to browser
DEBUG - 2022-07-29 02:31:04 --> Total execution time: 0.2648
INFO - 2022-07-29 02:31:05 --> Config Class Initialized
INFO - 2022-07-29 02:31:05 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:31:05 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:31:05 --> Utf8 Class Initialized
INFO - 2022-07-29 02:31:05 --> URI Class Initialized
INFO - 2022-07-29 02:31:05 --> Router Class Initialized
INFO - 2022-07-29 02:31:05 --> Output Class Initialized
INFO - 2022-07-29 02:31:05 --> Security Class Initialized
DEBUG - 2022-07-29 02:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:31:05 --> Input Class Initialized
INFO - 2022-07-29 02:31:05 --> Language Class Initialized
INFO - 2022-07-29 02:31:05 --> Language Class Initialized
INFO - 2022-07-29 02:31:05 --> Config Class Initialized
INFO - 2022-07-29 02:31:05 --> Loader Class Initialized
INFO - 2022-07-29 02:31:05 --> Helper loaded: url_helper
INFO - 2022-07-29 02:31:05 --> Helper loaded: file_helper
INFO - 2022-07-29 02:31:05 --> Helper loaded: form_helper
INFO - 2022-07-29 02:31:05 --> Helper loaded: my_helper
INFO - 2022-07-29 02:31:05 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:31:05 --> Controller Class Initialized
DEBUG - 2022-07-29 02:31:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-29 02:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 02:31:06 --> Final output sent to browser
DEBUG - 2022-07-29 02:31:06 --> Total execution time: 0.6722
INFO - 2022-07-29 02:31:07 --> Config Class Initialized
INFO - 2022-07-29 02:31:07 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:31:07 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:31:07 --> Utf8 Class Initialized
INFO - 2022-07-29 02:31:07 --> URI Class Initialized
INFO - 2022-07-29 02:31:07 --> Router Class Initialized
INFO - 2022-07-29 02:31:07 --> Output Class Initialized
INFO - 2022-07-29 02:31:07 --> Security Class Initialized
DEBUG - 2022-07-29 02:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:31:07 --> Input Class Initialized
INFO - 2022-07-29 02:31:07 --> Language Class Initialized
INFO - 2022-07-29 02:31:07 --> Language Class Initialized
INFO - 2022-07-29 02:31:07 --> Config Class Initialized
INFO - 2022-07-29 02:31:07 --> Loader Class Initialized
INFO - 2022-07-29 02:31:07 --> Helper loaded: url_helper
INFO - 2022-07-29 02:31:07 --> Helper loaded: file_helper
INFO - 2022-07-29 02:31:07 --> Helper loaded: form_helper
INFO - 2022-07-29 02:31:07 --> Helper loaded: my_helper
INFO - 2022-07-29 02:31:07 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:31:07 --> Controller Class Initialized
DEBUG - 2022-07-29 02:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-29 02:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 02:31:07 --> Final output sent to browser
DEBUG - 2022-07-29 02:31:07 --> Total execution time: 0.1601
INFO - 2022-07-29 02:31:17 --> Config Class Initialized
INFO - 2022-07-29 02:31:17 --> Hooks Class Initialized
DEBUG - 2022-07-29 02:31:17 --> UTF-8 Support Enabled
INFO - 2022-07-29 02:31:17 --> Utf8 Class Initialized
INFO - 2022-07-29 02:31:17 --> URI Class Initialized
INFO - 2022-07-29 02:31:17 --> Router Class Initialized
INFO - 2022-07-29 02:31:17 --> Output Class Initialized
INFO - 2022-07-29 02:31:17 --> Security Class Initialized
DEBUG - 2022-07-29 02:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 02:31:17 --> Input Class Initialized
INFO - 2022-07-29 02:31:17 --> Language Class Initialized
INFO - 2022-07-29 02:31:17 --> Language Class Initialized
INFO - 2022-07-29 02:31:17 --> Config Class Initialized
INFO - 2022-07-29 02:31:17 --> Loader Class Initialized
INFO - 2022-07-29 02:31:17 --> Helper loaded: url_helper
INFO - 2022-07-29 02:31:17 --> Helper loaded: file_helper
INFO - 2022-07-29 02:31:17 --> Helper loaded: form_helper
INFO - 2022-07-29 02:31:17 --> Helper loaded: my_helper
INFO - 2022-07-29 02:31:17 --> Database Driver Class Initialized
DEBUG - 2022-07-29 02:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 02:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 02:31:17 --> Controller Class Initialized
DEBUG - 2022-07-29 02:31:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-07-29 02:31:18 --> Final output sent to browser
DEBUG - 2022-07-29 02:31:18 --> Total execution time: 1.2286
INFO - 2022-07-29 03:55:50 --> Config Class Initialized
INFO - 2022-07-29 03:55:50 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:55:50 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:55:50 --> Utf8 Class Initialized
INFO - 2022-07-29 03:55:50 --> URI Class Initialized
DEBUG - 2022-07-29 03:55:50 --> No URI present. Default controller set.
INFO - 2022-07-29 03:55:50 --> Router Class Initialized
INFO - 2022-07-29 03:55:50 --> Output Class Initialized
INFO - 2022-07-29 03:55:50 --> Security Class Initialized
DEBUG - 2022-07-29 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:55:50 --> Input Class Initialized
INFO - 2022-07-29 03:55:50 --> Language Class Initialized
INFO - 2022-07-29 03:55:50 --> Language Class Initialized
INFO - 2022-07-29 03:55:50 --> Config Class Initialized
INFO - 2022-07-29 03:55:50 --> Loader Class Initialized
INFO - 2022-07-29 03:55:50 --> Helper loaded: url_helper
INFO - 2022-07-29 03:55:50 --> Helper loaded: file_helper
INFO - 2022-07-29 03:55:50 --> Helper loaded: form_helper
INFO - 2022-07-29 03:55:50 --> Helper loaded: my_helper
INFO - 2022-07-29 03:55:50 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:55:50 --> Controller Class Initialized
INFO - 2022-07-29 03:55:50 --> Config Class Initialized
INFO - 2022-07-29 03:55:50 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:55:50 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:55:50 --> Utf8 Class Initialized
INFO - 2022-07-29 03:55:50 --> URI Class Initialized
INFO - 2022-07-29 03:55:50 --> Router Class Initialized
INFO - 2022-07-29 03:55:50 --> Output Class Initialized
INFO - 2022-07-29 03:55:50 --> Security Class Initialized
DEBUG - 2022-07-29 03:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:55:50 --> Input Class Initialized
INFO - 2022-07-29 03:55:50 --> Language Class Initialized
INFO - 2022-07-29 03:55:50 --> Language Class Initialized
INFO - 2022-07-29 03:55:50 --> Config Class Initialized
INFO - 2022-07-29 03:55:50 --> Loader Class Initialized
INFO - 2022-07-29 03:55:50 --> Helper loaded: url_helper
INFO - 2022-07-29 03:55:50 --> Helper loaded: file_helper
INFO - 2022-07-29 03:55:50 --> Helper loaded: form_helper
INFO - 2022-07-29 03:55:50 --> Helper loaded: my_helper
INFO - 2022-07-29 03:55:50 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:55:50 --> Controller Class Initialized
DEBUG - 2022-07-29 03:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-29 03:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 03:55:50 --> Final output sent to browser
DEBUG - 2022-07-29 03:55:50 --> Total execution time: 0.0435
INFO - 2022-07-29 03:55:54 --> Config Class Initialized
INFO - 2022-07-29 03:55:54 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:55:54 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:55:54 --> Utf8 Class Initialized
INFO - 2022-07-29 03:55:54 --> URI Class Initialized
INFO - 2022-07-29 03:55:54 --> Router Class Initialized
INFO - 2022-07-29 03:55:54 --> Output Class Initialized
INFO - 2022-07-29 03:55:54 --> Security Class Initialized
DEBUG - 2022-07-29 03:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:55:54 --> Input Class Initialized
INFO - 2022-07-29 03:55:54 --> Language Class Initialized
INFO - 2022-07-29 03:55:54 --> Language Class Initialized
INFO - 2022-07-29 03:55:54 --> Config Class Initialized
INFO - 2022-07-29 03:55:54 --> Loader Class Initialized
INFO - 2022-07-29 03:55:54 --> Helper loaded: url_helper
INFO - 2022-07-29 03:55:54 --> Helper loaded: file_helper
INFO - 2022-07-29 03:55:54 --> Helper loaded: form_helper
INFO - 2022-07-29 03:55:54 --> Helper loaded: my_helper
INFO - 2022-07-29 03:55:54 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:55:54 --> Controller Class Initialized
INFO - 2022-07-29 03:55:54 --> Helper loaded: cookie_helper
INFO - 2022-07-29 03:55:54 --> Final output sent to browser
DEBUG - 2022-07-29 03:55:54 --> Total execution time: 0.0517
INFO - 2022-07-29 03:55:55 --> Config Class Initialized
INFO - 2022-07-29 03:55:55 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:55:55 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:55:55 --> Utf8 Class Initialized
INFO - 2022-07-29 03:55:55 --> URI Class Initialized
INFO - 2022-07-29 03:55:55 --> Router Class Initialized
INFO - 2022-07-29 03:55:55 --> Output Class Initialized
INFO - 2022-07-29 03:55:55 --> Security Class Initialized
DEBUG - 2022-07-29 03:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:55:55 --> Input Class Initialized
INFO - 2022-07-29 03:55:55 --> Language Class Initialized
INFO - 2022-07-29 03:55:55 --> Language Class Initialized
INFO - 2022-07-29 03:55:55 --> Config Class Initialized
INFO - 2022-07-29 03:55:55 --> Loader Class Initialized
INFO - 2022-07-29 03:55:55 --> Helper loaded: url_helper
INFO - 2022-07-29 03:55:55 --> Helper loaded: file_helper
INFO - 2022-07-29 03:55:55 --> Helper loaded: form_helper
INFO - 2022-07-29 03:55:55 --> Helper loaded: my_helper
INFO - 2022-07-29 03:55:55 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:55:55 --> Controller Class Initialized
DEBUG - 2022-07-29 03:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-29 03:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 03:55:55 --> Final output sent to browser
DEBUG - 2022-07-29 03:55:55 --> Total execution time: 0.1336
INFO - 2022-07-29 03:55:58 --> Config Class Initialized
INFO - 2022-07-29 03:55:58 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:55:58 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:55:58 --> Utf8 Class Initialized
INFO - 2022-07-29 03:55:58 --> URI Class Initialized
INFO - 2022-07-29 03:55:58 --> Router Class Initialized
INFO - 2022-07-29 03:55:58 --> Output Class Initialized
INFO - 2022-07-29 03:55:58 --> Security Class Initialized
DEBUG - 2022-07-29 03:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:55:58 --> Input Class Initialized
INFO - 2022-07-29 03:55:58 --> Language Class Initialized
INFO - 2022-07-29 03:55:58 --> Language Class Initialized
INFO - 2022-07-29 03:55:58 --> Config Class Initialized
INFO - 2022-07-29 03:55:58 --> Loader Class Initialized
INFO - 2022-07-29 03:55:58 --> Helper loaded: url_helper
INFO - 2022-07-29 03:55:58 --> Helper loaded: file_helper
INFO - 2022-07-29 03:55:58 --> Helper loaded: form_helper
INFO - 2022-07-29 03:55:58 --> Helper loaded: my_helper
INFO - 2022-07-29 03:55:58 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:55:59 --> Controller Class Initialized
DEBUG - 2022-07-29 03:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-29 03:55:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 03:55:59 --> Final output sent to browser
DEBUG - 2022-07-29 03:55:59 --> Total execution time: 0.0824
INFO - 2022-07-29 03:56:05 --> Config Class Initialized
INFO - 2022-07-29 03:56:05 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:56:05 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:56:05 --> Utf8 Class Initialized
INFO - 2022-07-29 03:56:05 --> URI Class Initialized
INFO - 2022-07-29 03:56:05 --> Router Class Initialized
INFO - 2022-07-29 03:56:05 --> Output Class Initialized
INFO - 2022-07-29 03:56:05 --> Security Class Initialized
DEBUG - 2022-07-29 03:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:56:05 --> Input Class Initialized
INFO - 2022-07-29 03:56:05 --> Language Class Initialized
INFO - 2022-07-29 03:56:05 --> Language Class Initialized
INFO - 2022-07-29 03:56:05 --> Config Class Initialized
INFO - 2022-07-29 03:56:05 --> Loader Class Initialized
INFO - 2022-07-29 03:56:05 --> Helper loaded: url_helper
INFO - 2022-07-29 03:56:05 --> Helper loaded: file_helper
INFO - 2022-07-29 03:56:05 --> Helper loaded: form_helper
INFO - 2022-07-29 03:56:05 --> Helper loaded: my_helper
INFO - 2022-07-29 03:56:05 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:56:05 --> Controller Class Initialized
DEBUG - 2022-07-29 03:56:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2022-07-29 03:56:05 --> Final output sent to browser
DEBUG - 2022-07-29 03:56:05 --> Total execution time: 0.0523
INFO - 2022-07-29 03:56:07 --> Config Class Initialized
INFO - 2022-07-29 03:56:07 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:56:07 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:56:07 --> Utf8 Class Initialized
INFO - 2022-07-29 03:56:07 --> URI Class Initialized
INFO - 2022-07-29 03:56:07 --> Router Class Initialized
INFO - 2022-07-29 03:56:07 --> Output Class Initialized
INFO - 2022-07-29 03:56:07 --> Security Class Initialized
DEBUG - 2022-07-29 03:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:56:07 --> Input Class Initialized
INFO - 2022-07-29 03:56:07 --> Language Class Initialized
INFO - 2022-07-29 03:56:07 --> Language Class Initialized
INFO - 2022-07-29 03:56:07 --> Config Class Initialized
INFO - 2022-07-29 03:56:07 --> Loader Class Initialized
INFO - 2022-07-29 03:56:07 --> Helper loaded: url_helper
INFO - 2022-07-29 03:56:07 --> Helper loaded: file_helper
INFO - 2022-07-29 03:56:07 --> Helper loaded: form_helper
INFO - 2022-07-29 03:56:07 --> Helper loaded: my_helper
INFO - 2022-07-29 03:56:07 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:56:07 --> Controller Class Initialized
DEBUG - 2022-07-29 03:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 03:56:07 --> Final output sent to browser
DEBUG - 2022-07-29 03:56:07 --> Total execution time: 0.0517
INFO - 2022-07-29 03:57:01 --> Config Class Initialized
INFO - 2022-07-29 03:57:01 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:57:01 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:57:01 --> Utf8 Class Initialized
INFO - 2022-07-29 03:57:01 --> URI Class Initialized
INFO - 2022-07-29 03:57:01 --> Router Class Initialized
INFO - 2022-07-29 03:57:01 --> Output Class Initialized
INFO - 2022-07-29 03:57:01 --> Security Class Initialized
DEBUG - 2022-07-29 03:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:57:01 --> Input Class Initialized
INFO - 2022-07-29 03:57:01 --> Language Class Initialized
INFO - 2022-07-29 03:57:01 --> Language Class Initialized
INFO - 2022-07-29 03:57:01 --> Config Class Initialized
INFO - 2022-07-29 03:57:01 --> Loader Class Initialized
INFO - 2022-07-29 03:57:01 --> Helper loaded: url_helper
INFO - 2022-07-29 03:57:01 --> Helper loaded: file_helper
INFO - 2022-07-29 03:57:01 --> Helper loaded: form_helper
INFO - 2022-07-29 03:57:01 --> Helper loaded: my_helper
INFO - 2022-07-29 03:57:01 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:57:01 --> Controller Class Initialized
DEBUG - 2022-07-29 03:57:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 03:57:01 --> Final output sent to browser
DEBUG - 2022-07-29 03:57:01 --> Total execution time: 0.0685
INFO - 2022-07-29 03:57:47 --> Config Class Initialized
INFO - 2022-07-29 03:57:47 --> Hooks Class Initialized
DEBUG - 2022-07-29 03:57:47 --> UTF-8 Support Enabled
INFO - 2022-07-29 03:57:47 --> Utf8 Class Initialized
INFO - 2022-07-29 03:57:47 --> URI Class Initialized
INFO - 2022-07-29 03:57:47 --> Router Class Initialized
INFO - 2022-07-29 03:57:47 --> Output Class Initialized
INFO - 2022-07-29 03:57:47 --> Security Class Initialized
DEBUG - 2022-07-29 03:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 03:57:47 --> Input Class Initialized
INFO - 2022-07-29 03:57:47 --> Language Class Initialized
INFO - 2022-07-29 03:57:47 --> Language Class Initialized
INFO - 2022-07-29 03:57:47 --> Config Class Initialized
INFO - 2022-07-29 03:57:47 --> Loader Class Initialized
INFO - 2022-07-29 03:57:47 --> Helper loaded: url_helper
INFO - 2022-07-29 03:57:47 --> Helper loaded: file_helper
INFO - 2022-07-29 03:57:47 --> Helper loaded: form_helper
INFO - 2022-07-29 03:57:47 --> Helper loaded: my_helper
INFO - 2022-07-29 03:57:47 --> Database Driver Class Initialized
DEBUG - 2022-07-29 03:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 03:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 03:57:47 --> Controller Class Initialized
DEBUG - 2022-07-29 03:57:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 03:57:47 --> Final output sent to browser
DEBUG - 2022-07-29 03:57:47 --> Total execution time: 0.0780
INFO - 2022-07-29 09:47:22 --> Config Class Initialized
INFO - 2022-07-29 09:47:22 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:23 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:23 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:23 --> URI Class Initialized
DEBUG - 2022-07-29 09:47:23 --> No URI present. Default controller set.
INFO - 2022-07-29 09:47:23 --> Router Class Initialized
INFO - 2022-07-29 09:47:23 --> Output Class Initialized
INFO - 2022-07-29 09:47:23 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:23 --> Input Class Initialized
INFO - 2022-07-29 09:47:23 --> Language Class Initialized
INFO - 2022-07-29 09:47:23 --> Language Class Initialized
INFO - 2022-07-29 09:47:23 --> Config Class Initialized
INFO - 2022-07-29 09:47:23 --> Loader Class Initialized
INFO - 2022-07-29 09:47:23 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:23 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:23 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:23 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:23 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:23 --> Controller Class Initialized
INFO - 2022-07-29 09:47:23 --> Config Class Initialized
INFO - 2022-07-29 09:47:23 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:23 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:23 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:23 --> URI Class Initialized
INFO - 2022-07-29 09:47:23 --> Router Class Initialized
INFO - 2022-07-29 09:47:23 --> Output Class Initialized
INFO - 2022-07-29 09:47:23 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:23 --> Input Class Initialized
INFO - 2022-07-29 09:47:23 --> Language Class Initialized
INFO - 2022-07-29 09:47:23 --> Language Class Initialized
INFO - 2022-07-29 09:47:23 --> Config Class Initialized
INFO - 2022-07-29 09:47:23 --> Loader Class Initialized
INFO - 2022-07-29 09:47:23 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:23 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:23 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:23 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:23 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:23 --> Controller Class Initialized
DEBUG - 2022-07-29 09:47:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-29 09:47:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:47:23 --> Final output sent to browser
DEBUG - 2022-07-29 09:47:23 --> Total execution time: 0.1046
INFO - 2022-07-29 09:47:30 --> Config Class Initialized
INFO - 2022-07-29 09:47:30 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:30 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:30 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:30 --> URI Class Initialized
INFO - 2022-07-29 09:47:30 --> Router Class Initialized
INFO - 2022-07-29 09:47:30 --> Output Class Initialized
INFO - 2022-07-29 09:47:30 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:30 --> Input Class Initialized
INFO - 2022-07-29 09:47:30 --> Language Class Initialized
INFO - 2022-07-29 09:47:30 --> Language Class Initialized
INFO - 2022-07-29 09:47:30 --> Config Class Initialized
INFO - 2022-07-29 09:47:30 --> Loader Class Initialized
INFO - 2022-07-29 09:47:30 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:30 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:30 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:30 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:30 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:30 --> Controller Class Initialized
INFO - 2022-07-29 09:47:30 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:47:30 --> Final output sent to browser
DEBUG - 2022-07-29 09:47:30 --> Total execution time: 0.0867
INFO - 2022-07-29 09:47:30 --> Config Class Initialized
INFO - 2022-07-29 09:47:30 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:30 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:30 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:30 --> URI Class Initialized
INFO - 2022-07-29 09:47:30 --> Router Class Initialized
INFO - 2022-07-29 09:47:30 --> Output Class Initialized
INFO - 2022-07-29 09:47:30 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:30 --> Input Class Initialized
INFO - 2022-07-29 09:47:30 --> Language Class Initialized
INFO - 2022-07-29 09:47:30 --> Language Class Initialized
INFO - 2022-07-29 09:47:30 --> Config Class Initialized
INFO - 2022-07-29 09:47:30 --> Loader Class Initialized
INFO - 2022-07-29 09:47:30 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:30 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:30 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:30 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:30 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:30 --> Controller Class Initialized
DEBUG - 2022-07-29 09:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-29 09:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:47:30 --> Final output sent to browser
DEBUG - 2022-07-29 09:47:30 --> Total execution time: 0.1939
INFO - 2022-07-29 09:47:32 --> Config Class Initialized
INFO - 2022-07-29 09:47:32 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:32 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:32 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:32 --> URI Class Initialized
INFO - 2022-07-29 09:47:32 --> Router Class Initialized
INFO - 2022-07-29 09:47:32 --> Output Class Initialized
INFO - 2022-07-29 09:47:32 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:32 --> Input Class Initialized
INFO - 2022-07-29 09:47:32 --> Language Class Initialized
INFO - 2022-07-29 09:47:32 --> Language Class Initialized
INFO - 2022-07-29 09:47:32 --> Config Class Initialized
INFO - 2022-07-29 09:47:32 --> Loader Class Initialized
INFO - 2022-07-29 09:47:32 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:32 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:32 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:32 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:32 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:32 --> Controller Class Initialized
DEBUG - 2022-07-29 09:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-07-29 09:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:47:32 --> Final output sent to browser
DEBUG - 2022-07-29 09:47:32 --> Total execution time: 0.1401
INFO - 2022-07-29 09:47:36 --> Config Class Initialized
INFO - 2022-07-29 09:47:36 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:36 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:36 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:36 --> URI Class Initialized
INFO - 2022-07-29 09:47:36 --> Router Class Initialized
INFO - 2022-07-29 09:47:36 --> Output Class Initialized
INFO - 2022-07-29 09:47:36 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:36 --> Input Class Initialized
INFO - 2022-07-29 09:47:36 --> Language Class Initialized
INFO - 2022-07-29 09:47:36 --> Language Class Initialized
INFO - 2022-07-29 09:47:36 --> Config Class Initialized
INFO - 2022-07-29 09:47:36 --> Loader Class Initialized
INFO - 2022-07-29 09:47:36 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:36 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:36 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:36 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:36 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:36 --> Controller Class Initialized
DEBUG - 2022-07-29 09:47:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2022-07-29 09:47:36 --> Final output sent to browser
DEBUG - 2022-07-29 09:47:36 --> Total execution time: 0.0597
INFO - 2022-07-29 09:47:37 --> Config Class Initialized
INFO - 2022-07-29 09:47:37 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:47:37 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:47:37 --> Utf8 Class Initialized
INFO - 2022-07-29 09:47:37 --> URI Class Initialized
INFO - 2022-07-29 09:47:37 --> Router Class Initialized
INFO - 2022-07-29 09:47:37 --> Output Class Initialized
INFO - 2022-07-29 09:47:37 --> Security Class Initialized
DEBUG - 2022-07-29 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:47:37 --> Input Class Initialized
INFO - 2022-07-29 09:47:37 --> Language Class Initialized
INFO - 2022-07-29 09:47:37 --> Language Class Initialized
INFO - 2022-07-29 09:47:37 --> Config Class Initialized
INFO - 2022-07-29 09:47:37 --> Loader Class Initialized
INFO - 2022-07-29 09:47:37 --> Helper loaded: url_helper
INFO - 2022-07-29 09:47:37 --> Helper loaded: file_helper
INFO - 2022-07-29 09:47:37 --> Helper loaded: form_helper
INFO - 2022-07-29 09:47:37 --> Helper loaded: my_helper
INFO - 2022-07-29 09:47:37 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:47:37 --> Controller Class Initialized
DEBUG - 2022-07-29 09:47:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:47:37 --> Final output sent to browser
DEBUG - 2022-07-29 09:47:37 --> Total execution time: 0.0700
INFO - 2022-07-29 09:48:03 --> Config Class Initialized
INFO - 2022-07-29 09:48:03 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:03 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:03 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:03 --> URI Class Initialized
INFO - 2022-07-29 09:48:03 --> Router Class Initialized
INFO - 2022-07-29 09:48:03 --> Output Class Initialized
INFO - 2022-07-29 09:48:03 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:03 --> Input Class Initialized
INFO - 2022-07-29 09:48:03 --> Language Class Initialized
INFO - 2022-07-29 09:48:03 --> Language Class Initialized
INFO - 2022-07-29 09:48:03 --> Config Class Initialized
INFO - 2022-07-29 09:48:03 --> Loader Class Initialized
INFO - 2022-07-29 09:48:03 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:03 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:04 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:04 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:04 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:04 --> Controller Class Initialized
INFO - 2022-07-29 09:48:04 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:48:04 --> Config Class Initialized
INFO - 2022-07-29 09:48:04 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:04 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:04 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:04 --> URI Class Initialized
INFO - 2022-07-29 09:48:04 --> Router Class Initialized
INFO - 2022-07-29 09:48:04 --> Output Class Initialized
INFO - 2022-07-29 09:48:04 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:04 --> Input Class Initialized
INFO - 2022-07-29 09:48:04 --> Language Class Initialized
INFO - 2022-07-29 09:48:04 --> Language Class Initialized
INFO - 2022-07-29 09:48:04 --> Config Class Initialized
INFO - 2022-07-29 09:48:04 --> Loader Class Initialized
INFO - 2022-07-29 09:48:04 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:04 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:04 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:04 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:04 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:04 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-29 09:48:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:04 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:04 --> Total execution time: 0.0524
INFO - 2022-07-29 09:48:07 --> Config Class Initialized
INFO - 2022-07-29 09:48:07 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:07 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:07 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:07 --> URI Class Initialized
INFO - 2022-07-29 09:48:07 --> Router Class Initialized
INFO - 2022-07-29 09:48:07 --> Output Class Initialized
INFO - 2022-07-29 09:48:07 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:07 --> Input Class Initialized
INFO - 2022-07-29 09:48:07 --> Language Class Initialized
INFO - 2022-07-29 09:48:07 --> Language Class Initialized
INFO - 2022-07-29 09:48:07 --> Config Class Initialized
INFO - 2022-07-29 09:48:07 --> Loader Class Initialized
INFO - 2022-07-29 09:48:07 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:07 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:07 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:07 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:07 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:07 --> Controller Class Initialized
INFO - 2022-07-29 09:48:08 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:48:08 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:08 --> Total execution time: 0.0427
INFO - 2022-07-29 09:48:08 --> Config Class Initialized
INFO - 2022-07-29 09:48:08 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:08 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:08 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:08 --> URI Class Initialized
INFO - 2022-07-29 09:48:08 --> Router Class Initialized
INFO - 2022-07-29 09:48:08 --> Output Class Initialized
INFO - 2022-07-29 09:48:08 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:08 --> Input Class Initialized
INFO - 2022-07-29 09:48:08 --> Language Class Initialized
INFO - 2022-07-29 09:48:08 --> Language Class Initialized
INFO - 2022-07-29 09:48:08 --> Config Class Initialized
INFO - 2022-07-29 09:48:08 --> Loader Class Initialized
INFO - 2022-07-29 09:48:08 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:08 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:08 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:08 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:08 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:08 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-29 09:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:08 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:08 --> Total execution time: 0.0831
INFO - 2022-07-29 09:48:10 --> Config Class Initialized
INFO - 2022-07-29 09:48:10 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:10 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:10 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:10 --> URI Class Initialized
INFO - 2022-07-29 09:48:10 --> Router Class Initialized
INFO - 2022-07-29 09:48:10 --> Output Class Initialized
INFO - 2022-07-29 09:48:10 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:10 --> Input Class Initialized
INFO - 2022-07-29 09:48:10 --> Language Class Initialized
INFO - 2022-07-29 09:48:10 --> Language Class Initialized
INFO - 2022-07-29 09:48:10 --> Config Class Initialized
INFO - 2022-07-29 09:48:10 --> Loader Class Initialized
INFO - 2022-07-29 09:48:10 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:10 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:10 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:10 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:10 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:10 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-29 09:48:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:10 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:10 --> Total execution time: 0.0888
INFO - 2022-07-29 09:48:10 --> Config Class Initialized
INFO - 2022-07-29 09:48:10 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:10 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:10 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:10 --> URI Class Initialized
INFO - 2022-07-29 09:48:10 --> Router Class Initialized
INFO - 2022-07-29 09:48:10 --> Output Class Initialized
INFO - 2022-07-29 09:48:10 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:10 --> Input Class Initialized
INFO - 2022-07-29 09:48:10 --> Language Class Initialized
INFO - 2022-07-29 09:48:10 --> Language Class Initialized
INFO - 2022-07-29 09:48:10 --> Config Class Initialized
INFO - 2022-07-29 09:48:10 --> Loader Class Initialized
INFO - 2022-07-29 09:48:10 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:10 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:10 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:10 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:10 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:10 --> Controller Class Initialized
INFO - 2022-07-29 09:48:12 --> Config Class Initialized
INFO - 2022-07-29 09:48:12 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:12 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:12 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:12 --> URI Class Initialized
INFO - 2022-07-29 09:48:12 --> Router Class Initialized
INFO - 2022-07-29 09:48:12 --> Output Class Initialized
INFO - 2022-07-29 09:48:12 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:12 --> Input Class Initialized
INFO - 2022-07-29 09:48:12 --> Language Class Initialized
INFO - 2022-07-29 09:48:12 --> Language Class Initialized
INFO - 2022-07-29 09:48:12 --> Config Class Initialized
INFO - 2022-07-29 09:48:12 --> Loader Class Initialized
INFO - 2022-07-29 09:48:12 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:12 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:12 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:12 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:12 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:12 --> Controller Class Initialized
INFO - 2022-07-29 09:48:12 --> Config Class Initialized
INFO - 2022-07-29 09:48:12 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:12 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:12 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:12 --> URI Class Initialized
INFO - 2022-07-29 09:48:12 --> Router Class Initialized
INFO - 2022-07-29 09:48:12 --> Output Class Initialized
INFO - 2022-07-29 09:48:12 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:12 --> Input Class Initialized
INFO - 2022-07-29 09:48:12 --> Language Class Initialized
INFO - 2022-07-29 09:48:12 --> Language Class Initialized
INFO - 2022-07-29 09:48:12 --> Config Class Initialized
INFO - 2022-07-29 09:48:12 --> Loader Class Initialized
INFO - 2022-07-29 09:48:12 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:12 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:12 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:12 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:12 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:12 --> Controller Class Initialized
INFO - 2022-07-29 09:48:13 --> Config Class Initialized
INFO - 2022-07-29 09:48:13 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:13 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:13 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:13 --> URI Class Initialized
INFO - 2022-07-29 09:48:13 --> Router Class Initialized
INFO - 2022-07-29 09:48:13 --> Output Class Initialized
INFO - 2022-07-29 09:48:13 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:13 --> Input Class Initialized
INFO - 2022-07-29 09:48:13 --> Language Class Initialized
INFO - 2022-07-29 09:48:13 --> Language Class Initialized
INFO - 2022-07-29 09:48:13 --> Config Class Initialized
INFO - 2022-07-29 09:48:13 --> Loader Class Initialized
INFO - 2022-07-29 09:48:13 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:13 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:13 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:13 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:13 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:13 --> Controller Class Initialized
INFO - 2022-07-29 09:48:14 --> Config Class Initialized
INFO - 2022-07-29 09:48:14 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:14 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:14 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:14 --> URI Class Initialized
INFO - 2022-07-29 09:48:14 --> Router Class Initialized
INFO - 2022-07-29 09:48:14 --> Output Class Initialized
INFO - 2022-07-29 09:48:14 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:14 --> Input Class Initialized
INFO - 2022-07-29 09:48:14 --> Language Class Initialized
INFO - 2022-07-29 09:48:14 --> Language Class Initialized
INFO - 2022-07-29 09:48:14 --> Config Class Initialized
INFO - 2022-07-29 09:48:14 --> Loader Class Initialized
INFO - 2022-07-29 09:48:14 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:14 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:14 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:14 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:14 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:14 --> Controller Class Initialized
ERROR - 2022-07-29 09:48:14 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-29 09:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-29 09:48:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:14 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:14 --> Total execution time: 0.1195
INFO - 2022-07-29 09:48:22 --> Config Class Initialized
INFO - 2022-07-29 09:48:22 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:22 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:22 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:22 --> URI Class Initialized
INFO - 2022-07-29 09:48:22 --> Router Class Initialized
INFO - 2022-07-29 09:48:22 --> Output Class Initialized
INFO - 2022-07-29 09:48:22 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:22 --> Input Class Initialized
INFO - 2022-07-29 09:48:22 --> Language Class Initialized
INFO - 2022-07-29 09:48:22 --> Language Class Initialized
INFO - 2022-07-29 09:48:22 --> Config Class Initialized
INFO - 2022-07-29 09:48:22 --> Loader Class Initialized
INFO - 2022-07-29 09:48:22 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:22 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:22 --> Controller Class Initialized
INFO - 2022-07-29 09:48:22 --> Upload Class Initialized
INFO - 2022-07-29 09:48:22 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-29 09:48:22 --> The upload path does not appear to be valid.
INFO - 2022-07-29 09:48:22 --> Config Class Initialized
INFO - 2022-07-29 09:48:22 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:22 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:22 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:22 --> URI Class Initialized
INFO - 2022-07-29 09:48:22 --> Router Class Initialized
INFO - 2022-07-29 09:48:22 --> Output Class Initialized
INFO - 2022-07-29 09:48:22 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:22 --> Input Class Initialized
INFO - 2022-07-29 09:48:22 --> Language Class Initialized
INFO - 2022-07-29 09:48:22 --> Language Class Initialized
INFO - 2022-07-29 09:48:22 --> Config Class Initialized
INFO - 2022-07-29 09:48:22 --> Loader Class Initialized
INFO - 2022-07-29 09:48:22 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:22 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:22 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-29 09:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:22 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:22 --> Total execution time: 0.0536
INFO - 2022-07-29 09:48:22 --> Config Class Initialized
INFO - 2022-07-29 09:48:22 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:22 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:22 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:22 --> URI Class Initialized
INFO - 2022-07-29 09:48:22 --> Router Class Initialized
INFO - 2022-07-29 09:48:22 --> Output Class Initialized
INFO - 2022-07-29 09:48:22 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:22 --> Input Class Initialized
INFO - 2022-07-29 09:48:22 --> Language Class Initialized
INFO - 2022-07-29 09:48:22 --> Language Class Initialized
INFO - 2022-07-29 09:48:22 --> Config Class Initialized
INFO - 2022-07-29 09:48:22 --> Loader Class Initialized
INFO - 2022-07-29 09:48:22 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:22 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:22 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:22 --> Controller Class Initialized
INFO - 2022-07-29 09:48:24 --> Config Class Initialized
INFO - 2022-07-29 09:48:24 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:24 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:24 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:24 --> URI Class Initialized
INFO - 2022-07-29 09:48:24 --> Router Class Initialized
INFO - 2022-07-29 09:48:24 --> Output Class Initialized
INFO - 2022-07-29 09:48:24 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:24 --> Input Class Initialized
INFO - 2022-07-29 09:48:24 --> Language Class Initialized
INFO - 2022-07-29 09:48:24 --> Language Class Initialized
INFO - 2022-07-29 09:48:24 --> Config Class Initialized
INFO - 2022-07-29 09:48:24 --> Loader Class Initialized
INFO - 2022-07-29 09:48:24 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:24 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:24 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:24 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:24 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:24 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:48:24 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:24 --> Total execution time: 0.0472
INFO - 2022-07-29 09:48:29 --> Config Class Initialized
INFO - 2022-07-29 09:48:29 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:29 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:29 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:29 --> URI Class Initialized
INFO - 2022-07-29 09:48:29 --> Router Class Initialized
INFO - 2022-07-29 09:48:29 --> Output Class Initialized
INFO - 2022-07-29 09:48:29 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:29 --> Input Class Initialized
INFO - 2022-07-29 09:48:29 --> Language Class Initialized
INFO - 2022-07-29 09:48:29 --> Language Class Initialized
INFO - 2022-07-29 09:48:29 --> Config Class Initialized
INFO - 2022-07-29 09:48:29 --> Loader Class Initialized
INFO - 2022-07-29 09:48:29 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:29 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:29 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:29 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:29 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:29 --> Controller Class Initialized
INFO - 2022-07-29 09:48:29 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:48:29 --> Config Class Initialized
INFO - 2022-07-29 09:48:29 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:29 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:29 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:29 --> URI Class Initialized
INFO - 2022-07-29 09:48:29 --> Router Class Initialized
INFO - 2022-07-29 09:48:29 --> Output Class Initialized
INFO - 2022-07-29 09:48:29 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:29 --> Input Class Initialized
INFO - 2022-07-29 09:48:29 --> Language Class Initialized
INFO - 2022-07-29 09:48:29 --> Language Class Initialized
INFO - 2022-07-29 09:48:29 --> Config Class Initialized
INFO - 2022-07-29 09:48:29 --> Loader Class Initialized
INFO - 2022-07-29 09:48:29 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:29 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:29 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:29 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:29 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:29 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-29 09:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:29 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:29 --> Total execution time: 0.0548
INFO - 2022-07-29 09:48:33 --> Config Class Initialized
INFO - 2022-07-29 09:48:33 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:33 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:33 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:33 --> URI Class Initialized
INFO - 2022-07-29 09:48:33 --> Router Class Initialized
INFO - 2022-07-29 09:48:33 --> Output Class Initialized
INFO - 2022-07-29 09:48:33 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:33 --> Input Class Initialized
INFO - 2022-07-29 09:48:33 --> Language Class Initialized
INFO - 2022-07-29 09:48:33 --> Language Class Initialized
INFO - 2022-07-29 09:48:33 --> Config Class Initialized
INFO - 2022-07-29 09:48:33 --> Loader Class Initialized
INFO - 2022-07-29 09:48:33 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:33 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:33 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:33 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:33 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:33 --> Controller Class Initialized
INFO - 2022-07-29 09:48:33 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:48:33 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:33 --> Total execution time: 0.0571
INFO - 2022-07-29 09:48:33 --> Config Class Initialized
INFO - 2022-07-29 09:48:33 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:33 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:33 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:33 --> URI Class Initialized
INFO - 2022-07-29 09:48:33 --> Router Class Initialized
INFO - 2022-07-29 09:48:33 --> Output Class Initialized
INFO - 2022-07-29 09:48:33 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:33 --> Input Class Initialized
INFO - 2022-07-29 09:48:33 --> Language Class Initialized
INFO - 2022-07-29 09:48:33 --> Language Class Initialized
INFO - 2022-07-29 09:48:33 --> Config Class Initialized
INFO - 2022-07-29 09:48:33 --> Loader Class Initialized
INFO - 2022-07-29 09:48:33 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:33 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:33 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:33 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:33 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:33 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-29 09:48:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:33 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:33 --> Total execution time: 0.0803
INFO - 2022-07-29 09:48:35 --> Config Class Initialized
INFO - 2022-07-29 09:48:35 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:35 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:35 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:35 --> URI Class Initialized
INFO - 2022-07-29 09:48:35 --> Router Class Initialized
INFO - 2022-07-29 09:48:35 --> Output Class Initialized
INFO - 2022-07-29 09:48:35 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:35 --> Input Class Initialized
INFO - 2022-07-29 09:48:35 --> Language Class Initialized
INFO - 2022-07-29 09:48:35 --> Language Class Initialized
INFO - 2022-07-29 09:48:35 --> Config Class Initialized
INFO - 2022-07-29 09:48:35 --> Loader Class Initialized
INFO - 2022-07-29 09:48:35 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:35 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:35 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:35 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:35 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:35 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:48:35 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:35 --> Total execution time: 0.0666
INFO - 2022-07-29 09:48:40 --> Config Class Initialized
INFO - 2022-07-29 09:48:40 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:40 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:40 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:40 --> URI Class Initialized
INFO - 2022-07-29 09:48:40 --> Router Class Initialized
INFO - 2022-07-29 09:48:40 --> Output Class Initialized
INFO - 2022-07-29 09:48:40 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:40 --> Input Class Initialized
INFO - 2022-07-29 09:48:40 --> Language Class Initialized
INFO - 2022-07-29 09:48:40 --> Language Class Initialized
INFO - 2022-07-29 09:48:40 --> Config Class Initialized
INFO - 2022-07-29 09:48:40 --> Loader Class Initialized
INFO - 2022-07-29 09:48:40 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:40 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:40 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:40 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:40 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:40 --> Controller Class Initialized
INFO - 2022-07-29 09:48:40 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:48:40 --> Config Class Initialized
INFO - 2022-07-29 09:48:40 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:40 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:40 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:40 --> URI Class Initialized
INFO - 2022-07-29 09:48:40 --> Router Class Initialized
INFO - 2022-07-29 09:48:40 --> Output Class Initialized
INFO - 2022-07-29 09:48:40 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:40 --> Input Class Initialized
INFO - 2022-07-29 09:48:40 --> Language Class Initialized
INFO - 2022-07-29 09:48:40 --> Language Class Initialized
INFO - 2022-07-29 09:48:40 --> Config Class Initialized
INFO - 2022-07-29 09:48:40 --> Loader Class Initialized
INFO - 2022-07-29 09:48:40 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:40 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:40 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:40 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:40 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:40 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-07-29 09:48:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:40 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:40 --> Total execution time: 0.0412
INFO - 2022-07-29 09:48:45 --> Config Class Initialized
INFO - 2022-07-29 09:48:45 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:45 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:45 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:45 --> URI Class Initialized
INFO - 2022-07-29 09:48:45 --> Router Class Initialized
INFO - 2022-07-29 09:48:45 --> Output Class Initialized
INFO - 2022-07-29 09:48:45 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:45 --> Input Class Initialized
INFO - 2022-07-29 09:48:45 --> Language Class Initialized
INFO - 2022-07-29 09:48:45 --> Language Class Initialized
INFO - 2022-07-29 09:48:45 --> Config Class Initialized
INFO - 2022-07-29 09:48:45 --> Loader Class Initialized
INFO - 2022-07-29 09:48:45 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:45 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:45 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:45 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:45 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:45 --> Controller Class Initialized
INFO - 2022-07-29 09:48:45 --> Helper loaded: cookie_helper
INFO - 2022-07-29 09:48:45 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:45 --> Total execution time: 0.0572
INFO - 2022-07-29 09:48:45 --> Config Class Initialized
INFO - 2022-07-29 09:48:45 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:45 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:45 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:45 --> URI Class Initialized
INFO - 2022-07-29 09:48:45 --> Router Class Initialized
INFO - 2022-07-29 09:48:45 --> Output Class Initialized
INFO - 2022-07-29 09:48:45 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:45 --> Input Class Initialized
INFO - 2022-07-29 09:48:45 --> Language Class Initialized
INFO - 2022-07-29 09:48:46 --> Language Class Initialized
INFO - 2022-07-29 09:48:46 --> Config Class Initialized
INFO - 2022-07-29 09:48:46 --> Loader Class Initialized
INFO - 2022-07-29 09:48:46 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:46 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:46 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:46 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:46 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:46 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-07-29 09:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:46 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:46 --> Total execution time: 0.0992
INFO - 2022-07-29 09:48:47 --> Config Class Initialized
INFO - 2022-07-29 09:48:47 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:47 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:47 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:47 --> URI Class Initialized
INFO - 2022-07-29 09:48:47 --> Router Class Initialized
INFO - 2022-07-29 09:48:47 --> Output Class Initialized
INFO - 2022-07-29 09:48:47 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:48 --> Input Class Initialized
INFO - 2022-07-29 09:48:48 --> Language Class Initialized
INFO - 2022-07-29 09:48:48 --> Language Class Initialized
INFO - 2022-07-29 09:48:48 --> Config Class Initialized
INFO - 2022-07-29 09:48:48 --> Loader Class Initialized
INFO - 2022-07-29 09:48:48 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:48 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:48 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:48 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:48 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:48 --> Controller Class Initialized
DEBUG - 2022-07-29 09:48:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-29 09:48:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:48 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:48 --> Total execution time: 0.0537
INFO - 2022-07-29 09:48:48 --> Config Class Initialized
INFO - 2022-07-29 09:48:48 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:48 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:48 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:48 --> URI Class Initialized
INFO - 2022-07-29 09:48:48 --> Router Class Initialized
INFO - 2022-07-29 09:48:48 --> Output Class Initialized
INFO - 2022-07-29 09:48:48 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:48 --> Input Class Initialized
INFO - 2022-07-29 09:48:48 --> Language Class Initialized
INFO - 2022-07-29 09:48:48 --> Language Class Initialized
INFO - 2022-07-29 09:48:48 --> Config Class Initialized
INFO - 2022-07-29 09:48:48 --> Loader Class Initialized
INFO - 2022-07-29 09:48:48 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:48 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:48 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:48 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:48 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:48 --> Controller Class Initialized
INFO - 2022-07-29 09:48:49 --> Config Class Initialized
INFO - 2022-07-29 09:48:49 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:49 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:49 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:49 --> URI Class Initialized
INFO - 2022-07-29 09:48:49 --> Router Class Initialized
INFO - 2022-07-29 09:48:49 --> Output Class Initialized
INFO - 2022-07-29 09:48:49 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:49 --> Input Class Initialized
INFO - 2022-07-29 09:48:49 --> Language Class Initialized
INFO - 2022-07-29 09:48:49 --> Language Class Initialized
INFO - 2022-07-29 09:48:49 --> Config Class Initialized
INFO - 2022-07-29 09:48:49 --> Loader Class Initialized
INFO - 2022-07-29 09:48:49 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:49 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:49 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:49 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:49 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:49 --> Controller Class Initialized
INFO - 2022-07-29 09:48:49 --> Config Class Initialized
INFO - 2022-07-29 09:48:49 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:49 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:49 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:49 --> URI Class Initialized
INFO - 2022-07-29 09:48:49 --> Router Class Initialized
INFO - 2022-07-29 09:48:49 --> Output Class Initialized
INFO - 2022-07-29 09:48:49 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:49 --> Input Class Initialized
INFO - 2022-07-29 09:48:49 --> Language Class Initialized
INFO - 2022-07-29 09:48:49 --> Language Class Initialized
INFO - 2022-07-29 09:48:49 --> Config Class Initialized
INFO - 2022-07-29 09:48:49 --> Loader Class Initialized
INFO - 2022-07-29 09:48:49 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:49 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:49 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:49 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:49 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:49 --> Controller Class Initialized
INFO - 2022-07-29 09:48:50 --> Config Class Initialized
INFO - 2022-07-29 09:48:50 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:50 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:50 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:50 --> URI Class Initialized
INFO - 2022-07-29 09:48:50 --> Router Class Initialized
INFO - 2022-07-29 09:48:50 --> Output Class Initialized
INFO - 2022-07-29 09:48:50 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:50 --> Input Class Initialized
INFO - 2022-07-29 09:48:50 --> Language Class Initialized
INFO - 2022-07-29 09:48:50 --> Language Class Initialized
INFO - 2022-07-29 09:48:50 --> Config Class Initialized
INFO - 2022-07-29 09:48:50 --> Loader Class Initialized
INFO - 2022-07-29 09:48:50 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:50 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:50 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:50 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:50 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:50 --> Controller Class Initialized
INFO - 2022-07-29 09:48:51 --> Config Class Initialized
INFO - 2022-07-29 09:48:51 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:48:51 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:48:51 --> Utf8 Class Initialized
INFO - 2022-07-29 09:48:51 --> URI Class Initialized
INFO - 2022-07-29 09:48:51 --> Router Class Initialized
INFO - 2022-07-29 09:48:51 --> Output Class Initialized
INFO - 2022-07-29 09:48:51 --> Security Class Initialized
DEBUG - 2022-07-29 09:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:48:51 --> Input Class Initialized
INFO - 2022-07-29 09:48:51 --> Language Class Initialized
INFO - 2022-07-29 09:48:51 --> Language Class Initialized
INFO - 2022-07-29 09:48:51 --> Config Class Initialized
INFO - 2022-07-29 09:48:51 --> Loader Class Initialized
INFO - 2022-07-29 09:48:51 --> Helper loaded: url_helper
INFO - 2022-07-29 09:48:51 --> Helper loaded: file_helper
INFO - 2022-07-29 09:48:51 --> Helper loaded: form_helper
INFO - 2022-07-29 09:48:51 --> Helper loaded: my_helper
INFO - 2022-07-29 09:48:51 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:48:51 --> Controller Class Initialized
ERROR - 2022-07-29 09:48:51 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-29 09:48:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-29 09:48:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:48:51 --> Final output sent to browser
DEBUG - 2022-07-29 09:48:51 --> Total execution time: 0.0699
INFO - 2022-07-29 09:49:05 --> Config Class Initialized
INFO - 2022-07-29 09:49:05 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:05 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:05 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:05 --> URI Class Initialized
INFO - 2022-07-29 09:49:05 --> Router Class Initialized
INFO - 2022-07-29 09:49:05 --> Output Class Initialized
INFO - 2022-07-29 09:49:05 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:05 --> Input Class Initialized
INFO - 2022-07-29 09:49:05 --> Language Class Initialized
INFO - 2022-07-29 09:49:05 --> Language Class Initialized
INFO - 2022-07-29 09:49:05 --> Config Class Initialized
INFO - 2022-07-29 09:49:05 --> Loader Class Initialized
INFO - 2022-07-29 09:49:05 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:05 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:05 --> Controller Class Initialized
INFO - 2022-07-29 09:49:05 --> Upload Class Initialized
INFO - 2022-07-29 09:49:05 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-29 09:49:05 --> The upload path does not appear to be valid.
INFO - 2022-07-29 09:49:05 --> Config Class Initialized
INFO - 2022-07-29 09:49:05 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:05 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:05 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:05 --> URI Class Initialized
INFO - 2022-07-29 09:49:05 --> Router Class Initialized
INFO - 2022-07-29 09:49:05 --> Output Class Initialized
INFO - 2022-07-29 09:49:05 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:05 --> Input Class Initialized
INFO - 2022-07-29 09:49:05 --> Language Class Initialized
INFO - 2022-07-29 09:49:05 --> Language Class Initialized
INFO - 2022-07-29 09:49:05 --> Config Class Initialized
INFO - 2022-07-29 09:49:05 --> Loader Class Initialized
INFO - 2022-07-29 09:49:05 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:05 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:05 --> Controller Class Initialized
DEBUG - 2022-07-29 09:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-29 09:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:49:05 --> Final output sent to browser
DEBUG - 2022-07-29 09:49:05 --> Total execution time: 0.0421
INFO - 2022-07-29 09:49:05 --> Config Class Initialized
INFO - 2022-07-29 09:49:05 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:05 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:05 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:05 --> URI Class Initialized
INFO - 2022-07-29 09:49:05 --> Router Class Initialized
INFO - 2022-07-29 09:49:05 --> Output Class Initialized
INFO - 2022-07-29 09:49:05 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:05 --> Input Class Initialized
INFO - 2022-07-29 09:49:05 --> Language Class Initialized
INFO - 2022-07-29 09:49:05 --> Language Class Initialized
INFO - 2022-07-29 09:49:05 --> Config Class Initialized
INFO - 2022-07-29 09:49:05 --> Loader Class Initialized
INFO - 2022-07-29 09:49:05 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:05 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:05 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:05 --> Controller Class Initialized
INFO - 2022-07-29 09:49:07 --> Config Class Initialized
INFO - 2022-07-29 09:49:07 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:07 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:07 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:07 --> URI Class Initialized
INFO - 2022-07-29 09:49:07 --> Router Class Initialized
INFO - 2022-07-29 09:49:07 --> Output Class Initialized
INFO - 2022-07-29 09:49:07 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:07 --> Input Class Initialized
INFO - 2022-07-29 09:49:07 --> Language Class Initialized
INFO - 2022-07-29 09:49:07 --> Language Class Initialized
INFO - 2022-07-29 09:49:07 --> Config Class Initialized
INFO - 2022-07-29 09:49:07 --> Loader Class Initialized
INFO - 2022-07-29 09:49:07 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:07 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:07 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:07 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:07 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:07 --> Controller Class Initialized
DEBUG - 2022-07-29 09:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:49:07 --> Final output sent to browser
DEBUG - 2022-07-29 09:49:07 --> Total execution time: 0.0572
INFO - 2022-07-29 09:49:53 --> Config Class Initialized
INFO - 2022-07-29 09:49:53 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:53 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:53 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:53 --> URI Class Initialized
INFO - 2022-07-29 09:49:53 --> Router Class Initialized
INFO - 2022-07-29 09:49:53 --> Output Class Initialized
INFO - 2022-07-29 09:49:53 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:53 --> Input Class Initialized
INFO - 2022-07-29 09:49:53 --> Language Class Initialized
INFO - 2022-07-29 09:49:53 --> Language Class Initialized
INFO - 2022-07-29 09:49:53 --> Config Class Initialized
INFO - 2022-07-29 09:49:53 --> Loader Class Initialized
INFO - 2022-07-29 09:49:53 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:53 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:53 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:53 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:53 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:53 --> Controller Class Initialized
INFO - 2022-07-29 09:49:54 --> Config Class Initialized
INFO - 2022-07-29 09:49:54 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:54 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:54 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:54 --> URI Class Initialized
INFO - 2022-07-29 09:49:54 --> Router Class Initialized
INFO - 2022-07-29 09:49:54 --> Output Class Initialized
INFO - 2022-07-29 09:49:54 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:54 --> Input Class Initialized
INFO - 2022-07-29 09:49:54 --> Language Class Initialized
INFO - 2022-07-29 09:49:54 --> Language Class Initialized
INFO - 2022-07-29 09:49:54 --> Config Class Initialized
INFO - 2022-07-29 09:49:54 --> Loader Class Initialized
INFO - 2022-07-29 09:49:54 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:54 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:54 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:54 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:54 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:54 --> Controller Class Initialized
INFO - 2022-07-29 09:49:56 --> Config Class Initialized
INFO - 2022-07-29 09:49:56 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:49:56 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:49:56 --> Utf8 Class Initialized
INFO - 2022-07-29 09:49:56 --> URI Class Initialized
INFO - 2022-07-29 09:49:56 --> Router Class Initialized
INFO - 2022-07-29 09:49:56 --> Output Class Initialized
INFO - 2022-07-29 09:49:56 --> Security Class Initialized
DEBUG - 2022-07-29 09:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:49:56 --> Input Class Initialized
INFO - 2022-07-29 09:49:56 --> Language Class Initialized
INFO - 2022-07-29 09:49:56 --> Language Class Initialized
INFO - 2022-07-29 09:49:56 --> Config Class Initialized
INFO - 2022-07-29 09:49:56 --> Loader Class Initialized
INFO - 2022-07-29 09:49:56 --> Helper loaded: url_helper
INFO - 2022-07-29 09:49:56 --> Helper loaded: file_helper
INFO - 2022-07-29 09:49:56 --> Helper loaded: form_helper
INFO - 2022-07-29 09:49:56 --> Helper loaded: my_helper
INFO - 2022-07-29 09:49:56 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:49:56 --> Controller Class Initialized
ERROR - 2022-07-29 09:49:56 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-07-29 09:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-07-29 09:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:49:56 --> Final output sent to browser
DEBUG - 2022-07-29 09:49:56 --> Total execution time: 0.0665
INFO - 2022-07-29 09:50:00 --> Config Class Initialized
INFO - 2022-07-29 09:50:00 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:50:00 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:50:00 --> Utf8 Class Initialized
INFO - 2022-07-29 09:50:00 --> URI Class Initialized
INFO - 2022-07-29 09:50:00 --> Router Class Initialized
INFO - 2022-07-29 09:50:00 --> Output Class Initialized
INFO - 2022-07-29 09:50:00 --> Security Class Initialized
DEBUG - 2022-07-29 09:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:50:00 --> Input Class Initialized
INFO - 2022-07-29 09:50:00 --> Language Class Initialized
INFO - 2022-07-29 09:50:00 --> Language Class Initialized
INFO - 2022-07-29 09:50:00 --> Config Class Initialized
INFO - 2022-07-29 09:50:00 --> Loader Class Initialized
INFO - 2022-07-29 09:50:00 --> Helper loaded: url_helper
INFO - 2022-07-29 09:50:00 --> Helper loaded: file_helper
INFO - 2022-07-29 09:50:00 --> Helper loaded: form_helper
INFO - 2022-07-29 09:50:00 --> Helper loaded: my_helper
INFO - 2022-07-29 09:50:00 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:50:00 --> Controller Class Initialized
INFO - 2022-07-29 09:50:00 --> Upload Class Initialized
INFO - 2022-07-29 09:50:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-07-29 09:50:00 --> The upload path does not appear to be valid.
INFO - 2022-07-29 09:50:00 --> Config Class Initialized
INFO - 2022-07-29 09:50:00 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:50:00 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:50:00 --> Utf8 Class Initialized
INFO - 2022-07-29 09:50:00 --> URI Class Initialized
INFO - 2022-07-29 09:50:00 --> Router Class Initialized
INFO - 2022-07-29 09:50:00 --> Output Class Initialized
INFO - 2022-07-29 09:50:00 --> Security Class Initialized
DEBUG - 2022-07-29 09:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:50:01 --> Input Class Initialized
INFO - 2022-07-29 09:50:01 --> Language Class Initialized
INFO - 2022-07-29 09:50:01 --> Language Class Initialized
INFO - 2022-07-29 09:50:01 --> Config Class Initialized
INFO - 2022-07-29 09:50:01 --> Loader Class Initialized
INFO - 2022-07-29 09:50:01 --> Helper loaded: url_helper
INFO - 2022-07-29 09:50:01 --> Helper loaded: file_helper
INFO - 2022-07-29 09:50:01 --> Helper loaded: form_helper
INFO - 2022-07-29 09:50:01 --> Helper loaded: my_helper
INFO - 2022-07-29 09:50:01 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:50:01 --> Controller Class Initialized
DEBUG - 2022-07-29 09:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-07-29 09:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-07-29 09:50:01 --> Final output sent to browser
DEBUG - 2022-07-29 09:50:01 --> Total execution time: 0.0420
INFO - 2022-07-29 09:50:01 --> Config Class Initialized
INFO - 2022-07-29 09:50:01 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:50:01 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:50:01 --> Utf8 Class Initialized
INFO - 2022-07-29 09:50:01 --> URI Class Initialized
INFO - 2022-07-29 09:50:01 --> Router Class Initialized
INFO - 2022-07-29 09:50:01 --> Output Class Initialized
INFO - 2022-07-29 09:50:01 --> Security Class Initialized
DEBUG - 2022-07-29 09:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:50:01 --> Input Class Initialized
INFO - 2022-07-29 09:50:01 --> Language Class Initialized
INFO - 2022-07-29 09:50:01 --> Language Class Initialized
INFO - 2022-07-29 09:50:01 --> Config Class Initialized
INFO - 2022-07-29 09:50:01 --> Loader Class Initialized
INFO - 2022-07-29 09:50:01 --> Helper loaded: url_helper
INFO - 2022-07-29 09:50:01 --> Helper loaded: file_helper
INFO - 2022-07-29 09:50:01 --> Helper loaded: form_helper
INFO - 2022-07-29 09:50:01 --> Helper loaded: my_helper
INFO - 2022-07-29 09:50:01 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:50:01 --> Controller Class Initialized
INFO - 2022-07-29 09:50:03 --> Config Class Initialized
INFO - 2022-07-29 09:50:03 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:50:03 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:50:03 --> Utf8 Class Initialized
INFO - 2022-07-29 09:50:03 --> URI Class Initialized
INFO - 2022-07-29 09:50:03 --> Router Class Initialized
INFO - 2022-07-29 09:50:03 --> Output Class Initialized
INFO - 2022-07-29 09:50:03 --> Security Class Initialized
DEBUG - 2022-07-29 09:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:50:03 --> Input Class Initialized
INFO - 2022-07-29 09:50:03 --> Language Class Initialized
INFO - 2022-07-29 09:50:03 --> Language Class Initialized
INFO - 2022-07-29 09:50:03 --> Config Class Initialized
INFO - 2022-07-29 09:50:03 --> Loader Class Initialized
INFO - 2022-07-29 09:50:03 --> Helper loaded: url_helper
INFO - 2022-07-29 09:50:03 --> Helper loaded: file_helper
INFO - 2022-07-29 09:50:03 --> Helper loaded: form_helper
INFO - 2022-07-29 09:50:03 --> Helper loaded: my_helper
INFO - 2022-07-29 09:50:03 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:50:03 --> Controller Class Initialized
DEBUG - 2022-07-29 09:50:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:50:03 --> Final output sent to browser
DEBUG - 2022-07-29 09:50:03 --> Total execution time: 0.0697
INFO - 2022-07-29 09:55:38 --> Config Class Initialized
INFO - 2022-07-29 09:55:38 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:55:38 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:55:38 --> Utf8 Class Initialized
INFO - 2022-07-29 09:55:38 --> URI Class Initialized
INFO - 2022-07-29 09:55:38 --> Router Class Initialized
INFO - 2022-07-29 09:55:38 --> Output Class Initialized
INFO - 2022-07-29 09:55:38 --> Security Class Initialized
DEBUG - 2022-07-29 09:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:55:38 --> Input Class Initialized
INFO - 2022-07-29 09:55:38 --> Language Class Initialized
INFO - 2022-07-29 09:55:38 --> Language Class Initialized
INFO - 2022-07-29 09:55:38 --> Config Class Initialized
INFO - 2022-07-29 09:55:38 --> Loader Class Initialized
INFO - 2022-07-29 09:55:38 --> Helper loaded: url_helper
INFO - 2022-07-29 09:55:38 --> Helper loaded: file_helper
INFO - 2022-07-29 09:55:38 --> Helper loaded: form_helper
INFO - 2022-07-29 09:55:38 --> Helper loaded: my_helper
INFO - 2022-07-29 09:55:38 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:55:38 --> Controller Class Initialized
DEBUG - 2022-07-29 09:55:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:55:38 --> Final output sent to browser
DEBUG - 2022-07-29 09:55:38 --> Total execution time: 0.0503
INFO - 2022-07-29 09:55:55 --> Config Class Initialized
INFO - 2022-07-29 09:55:55 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:55:55 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:55:55 --> Utf8 Class Initialized
INFO - 2022-07-29 09:55:55 --> URI Class Initialized
INFO - 2022-07-29 09:55:55 --> Router Class Initialized
INFO - 2022-07-29 09:55:55 --> Output Class Initialized
INFO - 2022-07-29 09:55:55 --> Security Class Initialized
DEBUG - 2022-07-29 09:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:55:55 --> Input Class Initialized
INFO - 2022-07-29 09:55:55 --> Language Class Initialized
INFO - 2022-07-29 09:55:55 --> Language Class Initialized
INFO - 2022-07-29 09:55:55 --> Config Class Initialized
INFO - 2022-07-29 09:55:55 --> Loader Class Initialized
INFO - 2022-07-29 09:55:55 --> Helper loaded: url_helper
INFO - 2022-07-29 09:55:55 --> Helper loaded: file_helper
INFO - 2022-07-29 09:55:55 --> Helper loaded: form_helper
INFO - 2022-07-29 09:55:55 --> Helper loaded: my_helper
INFO - 2022-07-29 09:55:55 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:55:55 --> Controller Class Initialized
DEBUG - 2022-07-29 09:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:55:55 --> Final output sent to browser
DEBUG - 2022-07-29 09:55:55 --> Total execution time: 0.0472
INFO - 2022-07-29 09:56:18 --> Config Class Initialized
INFO - 2022-07-29 09:56:18 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:56:18 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:56:18 --> Utf8 Class Initialized
INFO - 2022-07-29 09:56:18 --> URI Class Initialized
INFO - 2022-07-29 09:56:18 --> Router Class Initialized
INFO - 2022-07-29 09:56:18 --> Output Class Initialized
INFO - 2022-07-29 09:56:18 --> Security Class Initialized
DEBUG - 2022-07-29 09:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:56:18 --> Input Class Initialized
INFO - 2022-07-29 09:56:18 --> Language Class Initialized
INFO - 2022-07-29 09:56:18 --> Language Class Initialized
INFO - 2022-07-29 09:56:18 --> Config Class Initialized
INFO - 2022-07-29 09:56:18 --> Loader Class Initialized
INFO - 2022-07-29 09:56:18 --> Helper loaded: url_helper
INFO - 2022-07-29 09:56:18 --> Helper loaded: file_helper
INFO - 2022-07-29 09:56:18 --> Helper loaded: form_helper
INFO - 2022-07-29 09:56:18 --> Helper loaded: my_helper
INFO - 2022-07-29 09:56:18 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:56:18 --> Controller Class Initialized
DEBUG - 2022-07-29 09:56:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:56:18 --> Final output sent to browser
DEBUG - 2022-07-29 09:56:18 --> Total execution time: 0.0702
INFO - 2022-07-29 09:56:30 --> Config Class Initialized
INFO - 2022-07-29 09:56:30 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:56:30 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:56:30 --> Utf8 Class Initialized
INFO - 2022-07-29 09:56:30 --> URI Class Initialized
INFO - 2022-07-29 09:56:30 --> Router Class Initialized
INFO - 2022-07-29 09:56:30 --> Output Class Initialized
INFO - 2022-07-29 09:56:30 --> Security Class Initialized
DEBUG - 2022-07-29 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:56:30 --> Input Class Initialized
INFO - 2022-07-29 09:56:30 --> Language Class Initialized
INFO - 2022-07-29 09:56:30 --> Language Class Initialized
INFO - 2022-07-29 09:56:30 --> Config Class Initialized
INFO - 2022-07-29 09:56:30 --> Loader Class Initialized
INFO - 2022-07-29 09:56:30 --> Helper loaded: url_helper
INFO - 2022-07-29 09:56:30 --> Helper loaded: file_helper
INFO - 2022-07-29 09:56:30 --> Helper loaded: form_helper
INFO - 2022-07-29 09:56:30 --> Helper loaded: my_helper
INFO - 2022-07-29 09:56:30 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:56:30 --> Controller Class Initialized
DEBUG - 2022-07-29 09:56:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:56:30 --> Final output sent to browser
DEBUG - 2022-07-29 09:56:30 --> Total execution time: 0.0714
INFO - 2022-07-29 09:56:50 --> Config Class Initialized
INFO - 2022-07-29 09:56:50 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:56:50 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:56:50 --> Utf8 Class Initialized
INFO - 2022-07-29 09:56:50 --> URI Class Initialized
INFO - 2022-07-29 09:56:50 --> Router Class Initialized
INFO - 2022-07-29 09:56:50 --> Output Class Initialized
INFO - 2022-07-29 09:56:50 --> Security Class Initialized
DEBUG - 2022-07-29 09:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:56:50 --> Input Class Initialized
INFO - 2022-07-29 09:56:50 --> Language Class Initialized
INFO - 2022-07-29 09:56:50 --> Language Class Initialized
INFO - 2022-07-29 09:56:50 --> Config Class Initialized
INFO - 2022-07-29 09:56:50 --> Loader Class Initialized
INFO - 2022-07-29 09:56:50 --> Helper loaded: url_helper
INFO - 2022-07-29 09:56:50 --> Helper loaded: file_helper
INFO - 2022-07-29 09:56:50 --> Helper loaded: form_helper
INFO - 2022-07-29 09:56:50 --> Helper loaded: my_helper
INFO - 2022-07-29 09:56:50 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:56:50 --> Controller Class Initialized
DEBUG - 2022-07-29 09:56:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:56:50 --> Final output sent to browser
DEBUG - 2022-07-29 09:56:50 --> Total execution time: 0.0590
INFO - 2022-07-29 09:57:07 --> Config Class Initialized
INFO - 2022-07-29 09:57:07 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:57:07 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:57:07 --> Utf8 Class Initialized
INFO - 2022-07-29 09:57:07 --> URI Class Initialized
INFO - 2022-07-29 09:57:07 --> Router Class Initialized
INFO - 2022-07-29 09:57:07 --> Output Class Initialized
INFO - 2022-07-29 09:57:07 --> Security Class Initialized
DEBUG - 2022-07-29 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:57:07 --> Input Class Initialized
INFO - 2022-07-29 09:57:07 --> Language Class Initialized
INFO - 2022-07-29 09:57:07 --> Language Class Initialized
INFO - 2022-07-29 09:57:07 --> Config Class Initialized
INFO - 2022-07-29 09:57:07 --> Loader Class Initialized
INFO - 2022-07-29 09:57:07 --> Helper loaded: url_helper
INFO - 2022-07-29 09:57:07 --> Helper loaded: file_helper
INFO - 2022-07-29 09:57:07 --> Helper loaded: form_helper
INFO - 2022-07-29 09:57:07 --> Helper loaded: my_helper
INFO - 2022-07-29 09:57:07 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:57:07 --> Controller Class Initialized
DEBUG - 2022-07-29 09:57:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:57:07 --> Final output sent to browser
DEBUG - 2022-07-29 09:57:07 --> Total execution time: 0.0471
INFO - 2022-07-29 09:57:26 --> Config Class Initialized
INFO - 2022-07-29 09:57:26 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:57:26 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:57:26 --> Utf8 Class Initialized
INFO - 2022-07-29 09:57:26 --> URI Class Initialized
INFO - 2022-07-29 09:57:26 --> Router Class Initialized
INFO - 2022-07-29 09:57:26 --> Output Class Initialized
INFO - 2022-07-29 09:57:26 --> Security Class Initialized
DEBUG - 2022-07-29 09:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:57:26 --> Input Class Initialized
INFO - 2022-07-29 09:57:26 --> Language Class Initialized
INFO - 2022-07-29 09:57:26 --> Language Class Initialized
INFO - 2022-07-29 09:57:26 --> Config Class Initialized
INFO - 2022-07-29 09:57:26 --> Loader Class Initialized
INFO - 2022-07-29 09:57:26 --> Helper loaded: url_helper
INFO - 2022-07-29 09:57:26 --> Helper loaded: file_helper
INFO - 2022-07-29 09:57:26 --> Helper loaded: form_helper
INFO - 2022-07-29 09:57:26 --> Helper loaded: my_helper
INFO - 2022-07-29 09:57:26 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:57:26 --> Controller Class Initialized
DEBUG - 2022-07-29 09:57:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:57:26 --> Final output sent to browser
DEBUG - 2022-07-29 09:57:26 --> Total execution time: 0.0499
INFO - 2022-07-29 09:57:54 --> Config Class Initialized
INFO - 2022-07-29 09:57:54 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:57:54 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:57:54 --> Utf8 Class Initialized
INFO - 2022-07-29 09:57:54 --> URI Class Initialized
INFO - 2022-07-29 09:57:54 --> Router Class Initialized
INFO - 2022-07-29 09:57:54 --> Output Class Initialized
INFO - 2022-07-29 09:57:54 --> Security Class Initialized
DEBUG - 2022-07-29 09:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:57:54 --> Input Class Initialized
INFO - 2022-07-29 09:57:54 --> Language Class Initialized
INFO - 2022-07-29 09:57:54 --> Language Class Initialized
INFO - 2022-07-29 09:57:54 --> Config Class Initialized
INFO - 2022-07-29 09:57:54 --> Loader Class Initialized
INFO - 2022-07-29 09:57:54 --> Helper loaded: url_helper
INFO - 2022-07-29 09:57:54 --> Helper loaded: file_helper
INFO - 2022-07-29 09:57:54 --> Helper loaded: form_helper
INFO - 2022-07-29 09:57:54 --> Helper loaded: my_helper
INFO - 2022-07-29 09:57:54 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:57:54 --> Controller Class Initialized
DEBUG - 2022-07-29 09:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:57:54 --> Final output sent to browser
DEBUG - 2022-07-29 09:57:54 --> Total execution time: 0.0646
INFO - 2022-07-29 09:58:08 --> Config Class Initialized
INFO - 2022-07-29 09:58:08 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:58:08 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:58:08 --> Utf8 Class Initialized
INFO - 2022-07-29 09:58:08 --> URI Class Initialized
INFO - 2022-07-29 09:58:08 --> Router Class Initialized
INFO - 2022-07-29 09:58:08 --> Output Class Initialized
INFO - 2022-07-29 09:58:08 --> Security Class Initialized
DEBUG - 2022-07-29 09:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:58:08 --> Input Class Initialized
INFO - 2022-07-29 09:58:08 --> Language Class Initialized
INFO - 2022-07-29 09:58:08 --> Language Class Initialized
INFO - 2022-07-29 09:58:08 --> Config Class Initialized
INFO - 2022-07-29 09:58:08 --> Loader Class Initialized
INFO - 2022-07-29 09:58:08 --> Helper loaded: url_helper
INFO - 2022-07-29 09:58:08 --> Helper loaded: file_helper
INFO - 2022-07-29 09:58:08 --> Helper loaded: form_helper
INFO - 2022-07-29 09:58:08 --> Helper loaded: my_helper
INFO - 2022-07-29 09:58:08 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:58:08 --> Controller Class Initialized
DEBUG - 2022-07-29 09:58:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:58:08 --> Final output sent to browser
DEBUG - 2022-07-29 09:58:08 --> Total execution time: 0.0597
INFO - 2022-07-29 09:58:24 --> Config Class Initialized
INFO - 2022-07-29 09:58:24 --> Hooks Class Initialized
DEBUG - 2022-07-29 09:58:24 --> UTF-8 Support Enabled
INFO - 2022-07-29 09:58:24 --> Utf8 Class Initialized
INFO - 2022-07-29 09:58:24 --> URI Class Initialized
INFO - 2022-07-29 09:58:24 --> Router Class Initialized
INFO - 2022-07-29 09:58:24 --> Output Class Initialized
INFO - 2022-07-29 09:58:24 --> Security Class Initialized
DEBUG - 2022-07-29 09:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-07-29 09:58:24 --> Input Class Initialized
INFO - 2022-07-29 09:58:24 --> Language Class Initialized
INFO - 2022-07-29 09:58:24 --> Language Class Initialized
INFO - 2022-07-29 09:58:24 --> Config Class Initialized
INFO - 2022-07-29 09:58:24 --> Loader Class Initialized
INFO - 2022-07-29 09:58:24 --> Helper loaded: url_helper
INFO - 2022-07-29 09:58:24 --> Helper loaded: file_helper
INFO - 2022-07-29 09:58:24 --> Helper loaded: form_helper
INFO - 2022-07-29 09:58:24 --> Helper loaded: my_helper
INFO - 2022-07-29 09:58:24 --> Database Driver Class Initialized
DEBUG - 2022-07-29 09:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-07-29 09:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-07-29 09:58:24 --> Controller Class Initialized
DEBUG - 2022-07-29 09:58:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2022-07-29 09:58:24 --> Final output sent to browser
DEBUG - 2022-07-29 09:58:24 --> Total execution time: 0.0655
