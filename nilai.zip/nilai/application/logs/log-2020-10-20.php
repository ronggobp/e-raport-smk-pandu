<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-20 09:07:00 --> Config Class Initialized
INFO - 2020-10-20 09:07:00 --> Hooks Class Initialized
DEBUG - 2020-10-20 09:07:00 --> UTF-8 Support Enabled
INFO - 2020-10-20 09:07:00 --> Utf8 Class Initialized
INFO - 2020-10-20 09:07:00 --> URI Class Initialized
DEBUG - 2020-10-20 09:07:00 --> No URI present. Default controller set.
INFO - 2020-10-20 09:07:00 --> Router Class Initialized
INFO - 2020-10-20 09:07:00 --> Output Class Initialized
INFO - 2020-10-20 09:07:01 --> Security Class Initialized
DEBUG - 2020-10-20 09:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 09:07:01 --> Input Class Initialized
INFO - 2020-10-20 09:07:01 --> Language Class Initialized
INFO - 2020-10-20 09:07:01 --> Language Class Initialized
INFO - 2020-10-20 09:07:01 --> Config Class Initialized
INFO - 2020-10-20 09:07:01 --> Loader Class Initialized
INFO - 2020-10-20 09:07:01 --> Helper loaded: url_helper
INFO - 2020-10-20 09:07:01 --> Helper loaded: file_helper
INFO - 2020-10-20 09:07:01 --> Helper loaded: form_helper
INFO - 2020-10-20 09:07:01 --> Helper loaded: my_helper
INFO - 2020-10-20 09:07:01 --> Database Driver Class Initialized
DEBUG - 2020-10-20 09:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-20 09:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 09:07:01 --> Controller Class Initialized
INFO - 2020-10-20 09:07:01 --> Config Class Initialized
INFO - 2020-10-20 09:07:01 --> Hooks Class Initialized
DEBUG - 2020-10-20 09:07:01 --> UTF-8 Support Enabled
INFO - 2020-10-20 09:07:01 --> Utf8 Class Initialized
INFO - 2020-10-20 09:07:01 --> URI Class Initialized
INFO - 2020-10-20 09:07:01 --> Router Class Initialized
INFO - 2020-10-20 09:07:01 --> Output Class Initialized
INFO - 2020-10-20 09:07:01 --> Security Class Initialized
DEBUG - 2020-10-20 09:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 09:07:01 --> Input Class Initialized
INFO - 2020-10-20 09:07:01 --> Language Class Initialized
INFO - 2020-10-20 09:07:01 --> Language Class Initialized
INFO - 2020-10-20 09:07:01 --> Config Class Initialized
INFO - 2020-10-20 09:07:01 --> Loader Class Initialized
INFO - 2020-10-20 09:07:01 --> Helper loaded: url_helper
INFO - 2020-10-20 09:07:01 --> Helper loaded: file_helper
INFO - 2020-10-20 09:07:01 --> Helper loaded: form_helper
INFO - 2020-10-20 09:07:01 --> Helper loaded: my_helper
INFO - 2020-10-20 09:07:01 --> Database Driver Class Initialized
DEBUG - 2020-10-20 09:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-20 09:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 09:07:01 --> Controller Class Initialized
DEBUG - 2020-10-20 09:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-20 09:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-20 09:07:01 --> Final output sent to browser
DEBUG - 2020-10-20 09:07:01 --> Total execution time: 0.2451
INFO - 2020-10-20 09:07:09 --> Config Class Initialized
INFO - 2020-10-20 09:07:09 --> Hooks Class Initialized
DEBUG - 2020-10-20 09:07:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 09:07:09 --> Utf8 Class Initialized
INFO - 2020-10-20 09:07:09 --> URI Class Initialized
INFO - 2020-10-20 09:07:09 --> Router Class Initialized
INFO - 2020-10-20 09:07:09 --> Output Class Initialized
INFO - 2020-10-20 09:07:09 --> Security Class Initialized
DEBUG - 2020-10-20 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 09:07:09 --> Input Class Initialized
INFO - 2020-10-20 09:07:09 --> Language Class Initialized
INFO - 2020-10-20 09:07:09 --> Language Class Initialized
INFO - 2020-10-20 09:07:09 --> Config Class Initialized
INFO - 2020-10-20 09:07:09 --> Loader Class Initialized
INFO - 2020-10-20 09:07:09 --> Helper loaded: url_helper
INFO - 2020-10-20 09:07:09 --> Helper loaded: file_helper
INFO - 2020-10-20 09:07:09 --> Helper loaded: form_helper
INFO - 2020-10-20 09:07:09 --> Helper loaded: my_helper
INFO - 2020-10-20 09:07:09 --> Database Driver Class Initialized
DEBUG - 2020-10-20 09:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-20 09:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 09:07:09 --> Controller Class Initialized
INFO - 2020-10-20 09:07:09 --> Helper loaded: cookie_helper
INFO - 2020-10-20 09:07:09 --> Final output sent to browser
DEBUG - 2020-10-20 09:07:09 --> Total execution time: 0.2828
INFO - 2020-10-20 09:07:11 --> Config Class Initialized
INFO - 2020-10-20 09:07:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 09:07:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 09:07:11 --> Utf8 Class Initialized
INFO - 2020-10-20 09:07:11 --> URI Class Initialized
INFO - 2020-10-20 09:07:11 --> Router Class Initialized
INFO - 2020-10-20 09:07:11 --> Output Class Initialized
INFO - 2020-10-20 09:07:11 --> Security Class Initialized
DEBUG - 2020-10-20 09:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 09:07:11 --> Input Class Initialized
INFO - 2020-10-20 09:07:11 --> Language Class Initialized
INFO - 2020-10-20 09:07:11 --> Language Class Initialized
INFO - 2020-10-20 09:07:11 --> Config Class Initialized
INFO - 2020-10-20 09:07:11 --> Loader Class Initialized
INFO - 2020-10-20 09:07:11 --> Helper loaded: url_helper
INFO - 2020-10-20 09:07:11 --> Helper loaded: file_helper
INFO - 2020-10-20 09:07:11 --> Helper loaded: form_helper
INFO - 2020-10-20 09:07:11 --> Helper loaded: my_helper
INFO - 2020-10-20 09:07:11 --> Database Driver Class Initialized
DEBUG - 2020-10-20 09:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-20 09:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 09:07:11 --> Controller Class Initialized
DEBUG - 2020-10-20 09:07:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-20 09:07:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-20 09:07:11 --> Final output sent to browser
DEBUG - 2020-10-20 09:07:11 --> Total execution time: 0.3757
