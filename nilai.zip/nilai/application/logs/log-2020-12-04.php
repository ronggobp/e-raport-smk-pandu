<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-04 01:56:02 --> Config Class Initialized
INFO - 2020-12-04 01:56:02 --> Hooks Class Initialized
DEBUG - 2020-12-04 01:56:02 --> UTF-8 Support Enabled
INFO - 2020-12-04 01:56:02 --> Utf8 Class Initialized
INFO - 2020-12-04 01:56:02 --> URI Class Initialized
DEBUG - 2020-12-04 01:56:02 --> No URI present. Default controller set.
INFO - 2020-12-04 01:56:02 --> Router Class Initialized
INFO - 2020-12-04 01:56:02 --> Output Class Initialized
INFO - 2020-12-04 01:56:02 --> Security Class Initialized
DEBUG - 2020-12-04 01:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 01:56:02 --> Input Class Initialized
INFO - 2020-12-04 01:56:02 --> Language Class Initialized
INFO - 2020-12-04 01:56:03 --> Language Class Initialized
INFO - 2020-12-04 01:56:03 --> Config Class Initialized
INFO - 2020-12-04 01:56:03 --> Loader Class Initialized
INFO - 2020-12-04 01:56:03 --> Helper loaded: url_helper
INFO - 2020-12-04 01:56:03 --> Helper loaded: file_helper
INFO - 2020-12-04 01:56:03 --> Helper loaded: form_helper
INFO - 2020-12-04 01:56:03 --> Helper loaded: my_helper
INFO - 2020-12-04 01:56:03 --> Database Driver Class Initialized
DEBUG - 2020-12-04 01:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 01:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 01:56:03 --> Controller Class Initialized
INFO - 2020-12-04 01:56:03 --> Config Class Initialized
INFO - 2020-12-04 01:56:03 --> Hooks Class Initialized
DEBUG - 2020-12-04 01:56:03 --> UTF-8 Support Enabled
INFO - 2020-12-04 01:56:03 --> Utf8 Class Initialized
INFO - 2020-12-04 01:56:03 --> URI Class Initialized
INFO - 2020-12-04 01:56:03 --> Router Class Initialized
INFO - 2020-12-04 01:56:03 --> Output Class Initialized
INFO - 2020-12-04 01:56:03 --> Security Class Initialized
DEBUG - 2020-12-04 01:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 01:56:03 --> Input Class Initialized
INFO - 2020-12-04 01:56:03 --> Language Class Initialized
INFO - 2020-12-04 01:56:03 --> Language Class Initialized
INFO - 2020-12-04 01:56:03 --> Config Class Initialized
INFO - 2020-12-04 01:56:03 --> Loader Class Initialized
INFO - 2020-12-04 01:56:03 --> Helper loaded: url_helper
INFO - 2020-12-04 01:56:03 --> Helper loaded: file_helper
INFO - 2020-12-04 01:56:03 --> Helper loaded: form_helper
INFO - 2020-12-04 01:56:03 --> Helper loaded: my_helper
INFO - 2020-12-04 01:56:03 --> Database Driver Class Initialized
DEBUG - 2020-12-04 01:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 01:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 01:56:03 --> Controller Class Initialized
DEBUG - 2020-12-04 01:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-04 01:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 01:56:03 --> Final output sent to browser
DEBUG - 2020-12-04 01:56:03 --> Total execution time: 0.2909
INFO - 2020-12-04 03:22:44 --> Config Class Initialized
INFO - 2020-12-04 03:22:44 --> Hooks Class Initialized
DEBUG - 2020-12-04 03:22:44 --> UTF-8 Support Enabled
INFO - 2020-12-04 03:22:44 --> Utf8 Class Initialized
INFO - 2020-12-04 03:22:44 --> URI Class Initialized
INFO - 2020-12-04 03:22:44 --> Router Class Initialized
INFO - 2020-12-04 03:22:44 --> Output Class Initialized
INFO - 2020-12-04 03:22:44 --> Security Class Initialized
DEBUG - 2020-12-04 03:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 03:22:44 --> Input Class Initialized
INFO - 2020-12-04 03:22:44 --> Language Class Initialized
INFO - 2020-12-04 03:22:44 --> Language Class Initialized
INFO - 2020-12-04 03:22:44 --> Config Class Initialized
INFO - 2020-12-04 03:22:44 --> Loader Class Initialized
INFO - 2020-12-04 03:22:44 --> Helper loaded: url_helper
INFO - 2020-12-04 03:22:44 --> Helper loaded: file_helper
INFO - 2020-12-04 03:22:44 --> Helper loaded: form_helper
INFO - 2020-12-04 03:22:44 --> Helper loaded: my_helper
INFO - 2020-12-04 03:22:44 --> Database Driver Class Initialized
DEBUG - 2020-12-04 03:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 03:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 03:22:44 --> Controller Class Initialized
INFO - 2020-12-04 03:22:45 --> Helper loaded: cookie_helper
INFO - 2020-12-04 03:22:45 --> Final output sent to browser
DEBUG - 2020-12-04 03:22:45 --> Total execution time: 0.5982
INFO - 2020-12-04 03:22:45 --> Config Class Initialized
INFO - 2020-12-04 03:22:45 --> Hooks Class Initialized
DEBUG - 2020-12-04 03:22:45 --> UTF-8 Support Enabled
INFO - 2020-12-04 03:22:45 --> Utf8 Class Initialized
INFO - 2020-12-04 03:22:45 --> URI Class Initialized
INFO - 2020-12-04 03:22:45 --> Router Class Initialized
INFO - 2020-12-04 03:22:45 --> Output Class Initialized
INFO - 2020-12-04 03:22:45 --> Security Class Initialized
DEBUG - 2020-12-04 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 03:22:45 --> Input Class Initialized
INFO - 2020-12-04 03:22:45 --> Language Class Initialized
INFO - 2020-12-04 03:22:45 --> Language Class Initialized
INFO - 2020-12-04 03:22:45 --> Config Class Initialized
INFO - 2020-12-04 03:22:45 --> Loader Class Initialized
INFO - 2020-12-04 03:22:45 --> Helper loaded: url_helper
INFO - 2020-12-04 03:22:45 --> Helper loaded: file_helper
INFO - 2020-12-04 03:22:45 --> Helper loaded: form_helper
INFO - 2020-12-04 03:22:45 --> Helper loaded: my_helper
INFO - 2020-12-04 03:22:45 --> Database Driver Class Initialized
DEBUG - 2020-12-04 03:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 03:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 03:22:45 --> Controller Class Initialized
DEBUG - 2020-12-04 03:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-04 03:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 03:22:45 --> Final output sent to browser
DEBUG - 2020-12-04 03:22:45 --> Total execution time: 0.2777
INFO - 2020-12-04 03:22:50 --> Config Class Initialized
INFO - 2020-12-04 03:22:50 --> Hooks Class Initialized
DEBUG - 2020-12-04 03:22:50 --> UTF-8 Support Enabled
INFO - 2020-12-04 03:22:50 --> Utf8 Class Initialized
INFO - 2020-12-04 03:22:50 --> URI Class Initialized
INFO - 2020-12-04 03:22:50 --> Router Class Initialized
INFO - 2020-12-04 03:22:50 --> Output Class Initialized
INFO - 2020-12-04 03:22:50 --> Security Class Initialized
DEBUG - 2020-12-04 03:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 03:22:50 --> Input Class Initialized
INFO - 2020-12-04 03:22:50 --> Language Class Initialized
INFO - 2020-12-04 03:22:50 --> Language Class Initialized
INFO - 2020-12-04 03:22:50 --> Config Class Initialized
INFO - 2020-12-04 03:22:50 --> Loader Class Initialized
INFO - 2020-12-04 03:22:50 --> Helper loaded: url_helper
INFO - 2020-12-04 03:22:50 --> Helper loaded: file_helper
INFO - 2020-12-04 03:22:50 --> Helper loaded: form_helper
INFO - 2020-12-04 03:22:50 --> Helper loaded: my_helper
INFO - 2020-12-04 03:22:50 --> Database Driver Class Initialized
DEBUG - 2020-12-04 03:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 03:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 03:22:50 --> Controller Class Initialized
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 97
ERROR - 2020-12-04 03:22:50 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 113
DEBUG - 2020-12-04 03:22:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 03:22:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 03:22:50 --> Final output sent to browser
DEBUG - 2020-12-04 03:22:50 --> Total execution time: 0.5560
INFO - 2020-12-04 05:35:46 --> Config Class Initialized
INFO - 2020-12-04 05:35:46 --> Hooks Class Initialized
DEBUG - 2020-12-04 05:35:46 --> UTF-8 Support Enabled
INFO - 2020-12-04 05:35:46 --> Utf8 Class Initialized
INFO - 2020-12-04 05:35:46 --> URI Class Initialized
INFO - 2020-12-04 05:35:46 --> Router Class Initialized
INFO - 2020-12-04 05:35:46 --> Output Class Initialized
INFO - 2020-12-04 05:35:46 --> Security Class Initialized
DEBUG - 2020-12-04 05:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 05:35:46 --> Input Class Initialized
INFO - 2020-12-04 05:35:46 --> Language Class Initialized
INFO - 2020-12-04 05:35:46 --> Language Class Initialized
INFO - 2020-12-04 05:35:46 --> Config Class Initialized
INFO - 2020-12-04 05:35:46 --> Loader Class Initialized
INFO - 2020-12-04 05:35:46 --> Helper loaded: url_helper
INFO - 2020-12-04 05:35:46 --> Helper loaded: file_helper
INFO - 2020-12-04 05:35:46 --> Helper loaded: form_helper
INFO - 2020-12-04 05:35:46 --> Helper loaded: my_helper
INFO - 2020-12-04 05:35:46 --> Database Driver Class Initialized
DEBUG - 2020-12-04 05:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 05:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 05:35:46 --> Controller Class Initialized
ERROR - 2020-12-04 05:35:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:47 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:48 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:35:49 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
DEBUG - 2020-12-04 05:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 05:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 05:35:49 --> Final output sent to browser
DEBUG - 2020-12-04 05:35:49 --> Total execution time: 2.8272
INFO - 2020-12-04 05:36:50 --> Config Class Initialized
INFO - 2020-12-04 05:36:50 --> Hooks Class Initialized
DEBUG - 2020-12-04 05:36:50 --> UTF-8 Support Enabled
INFO - 2020-12-04 05:36:50 --> Utf8 Class Initialized
INFO - 2020-12-04 05:36:50 --> URI Class Initialized
INFO - 2020-12-04 05:36:50 --> Router Class Initialized
INFO - 2020-12-04 05:36:50 --> Output Class Initialized
INFO - 2020-12-04 05:36:50 --> Security Class Initialized
DEBUG - 2020-12-04 05:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 05:36:50 --> Input Class Initialized
INFO - 2020-12-04 05:36:50 --> Language Class Initialized
INFO - 2020-12-04 05:36:50 --> Language Class Initialized
INFO - 2020-12-04 05:36:50 --> Config Class Initialized
INFO - 2020-12-04 05:36:50 --> Loader Class Initialized
INFO - 2020-12-04 05:36:50 --> Helper loaded: url_helper
INFO - 2020-12-04 05:36:50 --> Helper loaded: file_helper
INFO - 2020-12-04 05:36:50 --> Helper loaded: form_helper
INFO - 2020-12-04 05:36:50 --> Helper loaded: my_helper
INFO - 2020-12-04 05:36:50 --> Database Driver Class Initialized
DEBUG - 2020-12-04 05:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 05:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 05:36:50 --> Controller Class Initialized
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:50 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
ERROR - 2020-12-04 05:36:53 --> Severity: Notice --> Use of undefined constant A - assumed 'A' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 56
DEBUG - 2020-12-04 05:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 05:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 05:36:53 --> Final output sent to browser
DEBUG - 2020-12-04 05:36:53 --> Total execution time: 3.1679
INFO - 2020-12-04 05:37:47 --> Config Class Initialized
INFO - 2020-12-04 05:37:47 --> Hooks Class Initialized
DEBUG - 2020-12-04 05:37:47 --> UTF-8 Support Enabled
INFO - 2020-12-04 05:37:47 --> Utf8 Class Initialized
INFO - 2020-12-04 05:37:47 --> URI Class Initialized
INFO - 2020-12-04 05:37:47 --> Router Class Initialized
INFO - 2020-12-04 05:37:47 --> Output Class Initialized
INFO - 2020-12-04 05:37:47 --> Security Class Initialized
DEBUG - 2020-12-04 05:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 05:37:47 --> Input Class Initialized
INFO - 2020-12-04 05:37:47 --> Language Class Initialized
INFO - 2020-12-04 05:37:47 --> Language Class Initialized
INFO - 2020-12-04 05:37:47 --> Config Class Initialized
INFO - 2020-12-04 05:37:47 --> Loader Class Initialized
INFO - 2020-12-04 05:37:47 --> Helper loaded: url_helper
INFO - 2020-12-04 05:37:47 --> Helper loaded: file_helper
INFO - 2020-12-04 05:37:47 --> Helper loaded: form_helper
INFO - 2020-12-04 05:37:47 --> Helper loaded: my_helper
INFO - 2020-12-04 05:37:47 --> Database Driver Class Initialized
DEBUG - 2020-12-04 05:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 05:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 05:37:47 --> Controller Class Initialized
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:37:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-04 05:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 05:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 05:37:48 --> Final output sent to browser
DEBUG - 2020-12-04 05:37:48 --> Total execution time: 1.9101
INFO - 2020-12-04 05:39:50 --> Config Class Initialized
INFO - 2020-12-04 05:39:50 --> Hooks Class Initialized
DEBUG - 2020-12-04 05:39:50 --> UTF-8 Support Enabled
INFO - 2020-12-04 05:39:50 --> Utf8 Class Initialized
INFO - 2020-12-04 05:39:50 --> URI Class Initialized
INFO - 2020-12-04 05:39:50 --> Router Class Initialized
INFO - 2020-12-04 05:39:50 --> Output Class Initialized
INFO - 2020-12-04 05:39:50 --> Security Class Initialized
DEBUG - 2020-12-04 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 05:39:50 --> Input Class Initialized
INFO - 2020-12-04 05:39:50 --> Language Class Initialized
INFO - 2020-12-04 05:39:50 --> Language Class Initialized
INFO - 2020-12-04 05:39:50 --> Config Class Initialized
INFO - 2020-12-04 05:39:50 --> Loader Class Initialized
INFO - 2020-12-04 05:39:50 --> Helper loaded: url_helper
INFO - 2020-12-04 05:39:50 --> Helper loaded: file_helper
INFO - 2020-12-04 05:39:50 --> Helper loaded: form_helper
INFO - 2020-12-04 05:39:50 --> Helper loaded: my_helper
INFO - 2020-12-04 05:39:50 --> Database Driver Class Initialized
DEBUG - 2020-12-04 05:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 05:39:50 --> Controller Class Initialized
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 05:39:51 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-04 05:39:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 05:39:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 05:39:51 --> Final output sent to browser
DEBUG - 2020-12-04 05:39:51 --> Total execution time: 1.8704
INFO - 2020-12-04 09:25:52 --> Config Class Initialized
INFO - 2020-12-04 09:25:52 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:25:52 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:25:52 --> Utf8 Class Initialized
INFO - 2020-12-04 09:25:52 --> URI Class Initialized
INFO - 2020-12-04 09:25:52 --> Router Class Initialized
INFO - 2020-12-04 09:25:52 --> Output Class Initialized
INFO - 2020-12-04 09:25:52 --> Security Class Initialized
DEBUG - 2020-12-04 09:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:25:52 --> Input Class Initialized
INFO - 2020-12-04 09:25:52 --> Language Class Initialized
INFO - 2020-12-04 09:25:52 --> Language Class Initialized
INFO - 2020-12-04 09:25:52 --> Config Class Initialized
INFO - 2020-12-04 09:25:52 --> Loader Class Initialized
INFO - 2020-12-04 09:25:52 --> Helper loaded: url_helper
INFO - 2020-12-04 09:25:52 --> Helper loaded: file_helper
INFO - 2020-12-04 09:25:52 --> Helper loaded: form_helper
INFO - 2020-12-04 09:25:52 --> Helper loaded: my_helper
INFO - 2020-12-04 09:25:52 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:25:52 --> Controller Class Initialized
ERROR - 2020-12-04 09:25:52 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 38
INFO - 2020-12-04 09:26:17 --> Config Class Initialized
INFO - 2020-12-04 09:26:17 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:26:17 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:26:17 --> Utf8 Class Initialized
INFO - 2020-12-04 09:26:17 --> URI Class Initialized
INFO - 2020-12-04 09:26:17 --> Router Class Initialized
INFO - 2020-12-04 09:26:17 --> Output Class Initialized
INFO - 2020-12-04 09:26:17 --> Security Class Initialized
DEBUG - 2020-12-04 09:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:26:17 --> Input Class Initialized
INFO - 2020-12-04 09:26:17 --> Language Class Initialized
INFO - 2020-12-04 09:26:17 --> Language Class Initialized
INFO - 2020-12-04 09:26:17 --> Config Class Initialized
INFO - 2020-12-04 09:26:17 --> Loader Class Initialized
INFO - 2020-12-04 09:26:17 --> Helper loaded: url_helper
INFO - 2020-12-04 09:26:17 --> Helper loaded: file_helper
INFO - 2020-12-04 09:26:17 --> Helper loaded: form_helper
INFO - 2020-12-04 09:26:17 --> Helper loaded: my_helper
INFO - 2020-12-04 09:26:17 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:26:17 --> Controller Class Initialized
ERROR - 2020-12-04 09:26:17 --> Severity: Parsing Error --> syntax error, unexpected 'as' (T_AS) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 38
INFO - 2020-12-04 09:26:46 --> Config Class Initialized
INFO - 2020-12-04 09:26:46 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:26:46 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:26:46 --> Utf8 Class Initialized
INFO - 2020-12-04 09:26:46 --> URI Class Initialized
INFO - 2020-12-04 09:26:46 --> Router Class Initialized
INFO - 2020-12-04 09:26:46 --> Output Class Initialized
INFO - 2020-12-04 09:26:46 --> Security Class Initialized
DEBUG - 2020-12-04 09:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:26:46 --> Input Class Initialized
INFO - 2020-12-04 09:26:46 --> Language Class Initialized
INFO - 2020-12-04 09:26:46 --> Language Class Initialized
INFO - 2020-12-04 09:26:46 --> Config Class Initialized
INFO - 2020-12-04 09:26:46 --> Loader Class Initialized
INFO - 2020-12-04 09:26:46 --> Helper loaded: url_helper
INFO - 2020-12-04 09:26:46 --> Helper loaded: file_helper
INFO - 2020-12-04 09:26:47 --> Helper loaded: form_helper
INFO - 2020-12-04 09:26:47 --> Helper loaded: my_helper
INFO - 2020-12-04 09:26:47 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:26:47 --> Controller Class Initialized
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 39
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 148
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 154
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 165
ERROR - 2020-12-04 09:26:47 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 181
DEBUG - 2020-12-04 09:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:26:47 --> Final output sent to browser
DEBUG - 2020-12-04 09:26:47 --> Total execution time: 1.0059
INFO - 2020-12-04 09:27:56 --> Config Class Initialized
INFO - 2020-12-04 09:27:56 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:27:56 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:27:56 --> Utf8 Class Initialized
INFO - 2020-12-04 09:27:56 --> URI Class Initialized
INFO - 2020-12-04 09:27:56 --> Router Class Initialized
INFO - 2020-12-04 09:27:56 --> Output Class Initialized
INFO - 2020-12-04 09:27:56 --> Security Class Initialized
DEBUG - 2020-12-04 09:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:27:56 --> Input Class Initialized
INFO - 2020-12-04 09:27:56 --> Language Class Initialized
INFO - 2020-12-04 09:27:56 --> Language Class Initialized
INFO - 2020-12-04 09:27:56 --> Config Class Initialized
INFO - 2020-12-04 09:27:56 --> Loader Class Initialized
INFO - 2020-12-04 09:27:56 --> Helper loaded: url_helper
INFO - 2020-12-04 09:27:56 --> Helper loaded: file_helper
INFO - 2020-12-04 09:27:56 --> Helper loaded: form_helper
INFO - 2020-12-04 09:27:56 --> Helper loaded: my_helper
INFO - 2020-12-04 09:27:56 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:27:56 --> Controller Class Initialized
ERROR - 2020-12-04 09:27:57 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting ')' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 38
INFO - 2020-12-04 09:29:57 --> Config Class Initialized
INFO - 2020-12-04 09:29:57 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:29:57 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:29:57 --> Utf8 Class Initialized
INFO - 2020-12-04 09:29:57 --> URI Class Initialized
INFO - 2020-12-04 09:29:57 --> Router Class Initialized
INFO - 2020-12-04 09:29:57 --> Output Class Initialized
INFO - 2020-12-04 09:29:57 --> Security Class Initialized
DEBUG - 2020-12-04 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:29:57 --> Input Class Initialized
INFO - 2020-12-04 09:29:57 --> Language Class Initialized
INFO - 2020-12-04 09:29:57 --> Language Class Initialized
INFO - 2020-12-04 09:29:57 --> Config Class Initialized
INFO - 2020-12-04 09:29:57 --> Loader Class Initialized
INFO - 2020-12-04 09:29:57 --> Helper loaded: url_helper
INFO - 2020-12-04 09:29:57 --> Helper loaded: file_helper
INFO - 2020-12-04 09:29:57 --> Helper loaded: form_helper
INFO - 2020-12-04 09:29:58 --> Helper loaded: my_helper
INFO - 2020-12-04 09:29:58 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:29:58 --> Controller Class Initialized
ERROR - 2020-12-04 09:29:58 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 130
INFO - 2020-12-04 09:30:09 --> Config Class Initialized
INFO - 2020-12-04 09:30:09 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:30:09 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:30:09 --> Utf8 Class Initialized
INFO - 2020-12-04 09:30:09 --> URI Class Initialized
INFO - 2020-12-04 09:30:09 --> Router Class Initialized
INFO - 2020-12-04 09:30:09 --> Output Class Initialized
INFO - 2020-12-04 09:30:09 --> Security Class Initialized
DEBUG - 2020-12-04 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:30:09 --> Input Class Initialized
INFO - 2020-12-04 09:30:09 --> Language Class Initialized
INFO - 2020-12-04 09:30:09 --> Language Class Initialized
INFO - 2020-12-04 09:30:09 --> Config Class Initialized
INFO - 2020-12-04 09:30:09 --> Loader Class Initialized
INFO - 2020-12-04 09:30:09 --> Helper loaded: url_helper
INFO - 2020-12-04 09:30:09 --> Helper loaded: file_helper
INFO - 2020-12-04 09:30:09 --> Helper loaded: form_helper
INFO - 2020-12-04 09:30:09 --> Helper loaded: my_helper
INFO - 2020-12-04 09:30:09 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:30:09 --> Controller Class Initialized
ERROR - 2020-12-04 09:30:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 151
ERROR - 2020-12-04 09:30:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 157
ERROR - 2020-12-04 09:30:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 168
ERROR - 2020-12-04 09:30:09 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 184
DEBUG - 2020-12-04 09:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:30:09 --> Final output sent to browser
DEBUG - 2020-12-04 09:30:09 --> Total execution time: 0.3343
INFO - 2020-12-04 09:30:49 --> Config Class Initialized
INFO - 2020-12-04 09:30:49 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:30:49 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:30:49 --> Utf8 Class Initialized
INFO - 2020-12-04 09:30:49 --> URI Class Initialized
INFO - 2020-12-04 09:30:49 --> Router Class Initialized
INFO - 2020-12-04 09:30:49 --> Output Class Initialized
INFO - 2020-12-04 09:30:49 --> Security Class Initialized
DEBUG - 2020-12-04 09:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:30:49 --> Input Class Initialized
INFO - 2020-12-04 09:30:49 --> Language Class Initialized
INFO - 2020-12-04 09:30:49 --> Language Class Initialized
INFO - 2020-12-04 09:30:49 --> Config Class Initialized
INFO - 2020-12-04 09:30:49 --> Loader Class Initialized
INFO - 2020-12-04 09:30:49 --> Helper loaded: url_helper
INFO - 2020-12-04 09:30:49 --> Helper loaded: file_helper
INFO - 2020-12-04 09:30:49 --> Helper loaded: form_helper
INFO - 2020-12-04 09:30:49 --> Helper loaded: my_helper
INFO - 2020-12-04 09:30:49 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:30:49 --> Controller Class Initialized
ERROR - 2020-12-04 09:30:49 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 123
INFO - 2020-12-04 09:31:24 --> Config Class Initialized
INFO - 2020-12-04 09:31:24 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:31:24 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:31:24 --> Utf8 Class Initialized
INFO - 2020-12-04 09:31:24 --> URI Class Initialized
INFO - 2020-12-04 09:31:24 --> Router Class Initialized
INFO - 2020-12-04 09:31:24 --> Output Class Initialized
INFO - 2020-12-04 09:31:24 --> Security Class Initialized
DEBUG - 2020-12-04 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:31:24 --> Input Class Initialized
INFO - 2020-12-04 09:31:24 --> Language Class Initialized
INFO - 2020-12-04 09:31:24 --> Language Class Initialized
INFO - 2020-12-04 09:31:24 --> Config Class Initialized
INFO - 2020-12-04 09:31:24 --> Loader Class Initialized
INFO - 2020-12-04 09:31:24 --> Helper loaded: url_helper
INFO - 2020-12-04 09:31:24 --> Helper loaded: file_helper
INFO - 2020-12-04 09:31:24 --> Helper loaded: form_helper
INFO - 2020-12-04 09:31:24 --> Helper loaded: my_helper
INFO - 2020-12-04 09:31:24 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:31:24 --> Controller Class Initialized
ERROR - 2020-12-04 09:31:24 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 123
INFO - 2020-12-04 09:31:27 --> Config Class Initialized
INFO - 2020-12-04 09:31:27 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:31:27 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:31:27 --> Utf8 Class Initialized
INFO - 2020-12-04 09:31:27 --> URI Class Initialized
INFO - 2020-12-04 09:31:27 --> Router Class Initialized
INFO - 2020-12-04 09:31:27 --> Output Class Initialized
INFO - 2020-12-04 09:31:27 --> Security Class Initialized
DEBUG - 2020-12-04 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:31:27 --> Input Class Initialized
INFO - 2020-12-04 09:31:27 --> Language Class Initialized
INFO - 2020-12-04 09:31:27 --> Language Class Initialized
INFO - 2020-12-04 09:31:27 --> Config Class Initialized
INFO - 2020-12-04 09:31:27 --> Loader Class Initialized
INFO - 2020-12-04 09:31:27 --> Helper loaded: url_helper
INFO - 2020-12-04 09:31:27 --> Helper loaded: file_helper
INFO - 2020-12-04 09:31:27 --> Helper loaded: form_helper
INFO - 2020-12-04 09:31:27 --> Helper loaded: my_helper
INFO - 2020-12-04 09:31:27 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:31:27 --> Controller Class Initialized
ERROR - 2020-12-04 09:31:27 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 123
INFO - 2020-12-04 09:32:01 --> Config Class Initialized
INFO - 2020-12-04 09:32:01 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:32:02 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:32:02 --> Utf8 Class Initialized
INFO - 2020-12-04 09:32:02 --> URI Class Initialized
INFO - 2020-12-04 09:32:02 --> Router Class Initialized
INFO - 2020-12-04 09:32:02 --> Output Class Initialized
INFO - 2020-12-04 09:32:02 --> Security Class Initialized
DEBUG - 2020-12-04 09:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:32:02 --> Input Class Initialized
INFO - 2020-12-04 09:32:02 --> Language Class Initialized
INFO - 2020-12-04 09:32:02 --> Language Class Initialized
INFO - 2020-12-04 09:32:02 --> Config Class Initialized
INFO - 2020-12-04 09:32:02 --> Loader Class Initialized
INFO - 2020-12-04 09:32:02 --> Helper loaded: url_helper
INFO - 2020-12-04 09:32:02 --> Helper loaded: file_helper
INFO - 2020-12-04 09:32:02 --> Helper loaded: form_helper
INFO - 2020-12-04 09:32:02 --> Helper loaded: my_helper
INFO - 2020-12-04 09:32:02 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:32:02 --> Controller Class Initialized
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:32:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-04 09:32:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:32:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:32:04 --> Final output sent to browser
DEBUG - 2020-12-04 09:32:04 --> Total execution time: 2.0372
INFO - 2020-12-04 09:34:08 --> Config Class Initialized
INFO - 2020-12-04 09:34:08 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:34:08 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:34:08 --> Utf8 Class Initialized
INFO - 2020-12-04 09:34:08 --> URI Class Initialized
INFO - 2020-12-04 09:34:08 --> Router Class Initialized
INFO - 2020-12-04 09:34:08 --> Output Class Initialized
INFO - 2020-12-04 09:34:08 --> Security Class Initialized
DEBUG - 2020-12-04 09:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:34:08 --> Input Class Initialized
INFO - 2020-12-04 09:34:08 --> Language Class Initialized
INFO - 2020-12-04 09:34:08 --> Language Class Initialized
INFO - 2020-12-04 09:34:08 --> Config Class Initialized
INFO - 2020-12-04 09:34:08 --> Loader Class Initialized
INFO - 2020-12-04 09:34:08 --> Helper loaded: url_helper
INFO - 2020-12-04 09:34:08 --> Helper loaded: file_helper
INFO - 2020-12-04 09:34:08 --> Helper loaded: form_helper
INFO - 2020-12-04 09:34:08 --> Helper loaded: my_helper
INFO - 2020-12-04 09:34:08 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:34:08 --> Controller Class Initialized
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 18
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:09 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-04 09:34:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-04 09:34:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:34:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:34:10 --> Final output sent to browser
DEBUG - 2020-12-04 09:34:10 --> Total execution time: 2.1271
INFO - 2020-12-04 09:37:26 --> Config Class Initialized
INFO - 2020-12-04 09:37:26 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:37:26 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:37:26 --> Utf8 Class Initialized
INFO - 2020-12-04 09:37:26 --> URI Class Initialized
INFO - 2020-12-04 09:37:26 --> Router Class Initialized
INFO - 2020-12-04 09:37:26 --> Output Class Initialized
INFO - 2020-12-04 09:37:26 --> Security Class Initialized
DEBUG - 2020-12-04 09:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:37:26 --> Input Class Initialized
INFO - 2020-12-04 09:37:26 --> Language Class Initialized
INFO - 2020-12-04 09:37:26 --> Language Class Initialized
INFO - 2020-12-04 09:37:26 --> Config Class Initialized
INFO - 2020-12-04 09:37:26 --> Loader Class Initialized
INFO - 2020-12-04 09:37:26 --> Helper loaded: url_helper
INFO - 2020-12-04 09:37:26 --> Helper loaded: file_helper
INFO - 2020-12-04 09:37:26 --> Helper loaded: form_helper
INFO - 2020-12-04 09:37:26 --> Helper loaded: my_helper
INFO - 2020-12-04 09:37:26 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:37:26 --> Controller Class Initialized
ERROR - 2020-12-04 09:37:26 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 18
DEBUG - 2020-12-04 09:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:37:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:37:26 --> Final output sent to browser
DEBUG - 2020-12-04 09:37:26 --> Total execution time: 0.3290
INFO - 2020-12-04 09:37:44 --> Config Class Initialized
INFO - 2020-12-04 09:37:44 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:37:44 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:37:44 --> Utf8 Class Initialized
INFO - 2020-12-04 09:37:44 --> URI Class Initialized
INFO - 2020-12-04 09:37:44 --> Router Class Initialized
INFO - 2020-12-04 09:37:44 --> Output Class Initialized
INFO - 2020-12-04 09:37:44 --> Security Class Initialized
DEBUG - 2020-12-04 09:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:37:44 --> Input Class Initialized
INFO - 2020-12-04 09:37:44 --> Language Class Initialized
INFO - 2020-12-04 09:37:44 --> Language Class Initialized
INFO - 2020-12-04 09:37:44 --> Config Class Initialized
INFO - 2020-12-04 09:37:44 --> Loader Class Initialized
INFO - 2020-12-04 09:37:44 --> Helper loaded: url_helper
INFO - 2020-12-04 09:37:44 --> Helper loaded: file_helper
INFO - 2020-12-04 09:37:44 --> Helper loaded: form_helper
INFO - 2020-12-04 09:37:44 --> Helper loaded: my_helper
INFO - 2020-12-04 09:37:44 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:37:44 --> Controller Class Initialized
DEBUG - 2020-12-04 09:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:37:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:37:44 --> Final output sent to browser
DEBUG - 2020-12-04 09:37:44 --> Total execution time: 0.2808
INFO - 2020-12-04 09:51:02 --> Config Class Initialized
INFO - 2020-12-04 09:51:02 --> Hooks Class Initialized
DEBUG - 2020-12-04 09:51:02 --> UTF-8 Support Enabled
INFO - 2020-12-04 09:51:02 --> Utf8 Class Initialized
INFO - 2020-12-04 09:51:02 --> URI Class Initialized
INFO - 2020-12-04 09:51:02 --> Router Class Initialized
INFO - 2020-12-04 09:51:02 --> Output Class Initialized
INFO - 2020-12-04 09:51:02 --> Security Class Initialized
DEBUG - 2020-12-04 09:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-04 09:51:02 --> Input Class Initialized
INFO - 2020-12-04 09:51:02 --> Language Class Initialized
INFO - 2020-12-04 09:51:02 --> Language Class Initialized
INFO - 2020-12-04 09:51:02 --> Config Class Initialized
INFO - 2020-12-04 09:51:02 --> Loader Class Initialized
INFO - 2020-12-04 09:51:02 --> Helper loaded: url_helper
INFO - 2020-12-04 09:51:02 --> Helper loaded: file_helper
INFO - 2020-12-04 09:51:02 --> Helper loaded: form_helper
INFO - 2020-12-04 09:51:02 --> Helper loaded: my_helper
INFO - 2020-12-04 09:51:02 --> Database Driver Class Initialized
DEBUG - 2020-12-04 09:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-04 09:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-04 09:51:02 --> Controller Class Initialized
DEBUG - 2020-12-04 09:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-04 09:51:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-04 09:51:02 --> Final output sent to browser
DEBUG - 2020-12-04 09:51:02 --> Total execution time: 0.2766
