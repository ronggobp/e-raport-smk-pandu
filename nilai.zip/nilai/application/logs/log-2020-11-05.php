<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-05 01:53:18 --> Config Class Initialized
INFO - 2020-11-05 01:53:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 01:53:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 01:53:18 --> Utf8 Class Initialized
INFO - 2020-11-05 01:53:18 --> URI Class Initialized
DEBUG - 2020-11-05 01:53:18 --> No URI present. Default controller set.
INFO - 2020-11-05 01:53:18 --> Router Class Initialized
INFO - 2020-11-05 01:53:18 --> Output Class Initialized
INFO - 2020-11-05 01:53:18 --> Security Class Initialized
DEBUG - 2020-11-05 01:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 01:53:18 --> Input Class Initialized
INFO - 2020-11-05 01:53:18 --> Language Class Initialized
INFO - 2020-11-05 01:53:18 --> Language Class Initialized
INFO - 2020-11-05 01:53:18 --> Config Class Initialized
INFO - 2020-11-05 01:53:18 --> Loader Class Initialized
INFO - 2020-11-05 01:53:18 --> Helper loaded: url_helper
INFO - 2020-11-05 01:53:18 --> Helper loaded: file_helper
INFO - 2020-11-05 01:53:18 --> Helper loaded: form_helper
INFO - 2020-11-05 01:53:18 --> Helper loaded: my_helper
INFO - 2020-11-05 01:53:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 01:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 01:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 01:53:18 --> Controller Class Initialized
INFO - 2020-11-05 01:53:18 --> Config Class Initialized
INFO - 2020-11-05 01:53:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 01:53:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 01:53:19 --> Utf8 Class Initialized
INFO - 2020-11-05 01:53:19 --> URI Class Initialized
INFO - 2020-11-05 01:53:19 --> Router Class Initialized
INFO - 2020-11-05 01:53:19 --> Output Class Initialized
INFO - 2020-11-05 01:53:19 --> Security Class Initialized
DEBUG - 2020-11-05 01:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 01:53:19 --> Input Class Initialized
INFO - 2020-11-05 01:53:19 --> Language Class Initialized
INFO - 2020-11-05 01:53:19 --> Language Class Initialized
INFO - 2020-11-05 01:53:19 --> Config Class Initialized
INFO - 2020-11-05 01:53:19 --> Loader Class Initialized
INFO - 2020-11-05 01:53:19 --> Helper loaded: url_helper
INFO - 2020-11-05 01:53:19 --> Helper loaded: file_helper
INFO - 2020-11-05 01:53:19 --> Helper loaded: form_helper
INFO - 2020-11-05 01:53:19 --> Helper loaded: my_helper
INFO - 2020-11-05 01:53:19 --> Database Driver Class Initialized
DEBUG - 2020-11-05 01:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 01:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 01:53:19 --> Controller Class Initialized
DEBUG - 2020-11-05 01:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-05 01:53:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 01:53:19 --> Final output sent to browser
DEBUG - 2020-11-05 01:53:19 --> Total execution time: 0.6378
INFO - 2020-11-05 02:03:56 --> Config Class Initialized
INFO - 2020-11-05 02:03:56 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:03:56 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:03:56 --> Utf8 Class Initialized
INFO - 2020-11-05 02:03:56 --> URI Class Initialized
INFO - 2020-11-05 02:03:56 --> Router Class Initialized
INFO - 2020-11-05 02:03:56 --> Output Class Initialized
INFO - 2020-11-05 02:03:57 --> Security Class Initialized
DEBUG - 2020-11-05 02:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:03:57 --> Input Class Initialized
INFO - 2020-11-05 02:03:57 --> Language Class Initialized
INFO - 2020-11-05 02:03:57 --> Language Class Initialized
INFO - 2020-11-05 02:03:57 --> Config Class Initialized
INFO - 2020-11-05 02:03:57 --> Loader Class Initialized
INFO - 2020-11-05 02:03:57 --> Helper loaded: url_helper
INFO - 2020-11-05 02:03:57 --> Helper loaded: file_helper
INFO - 2020-11-05 02:03:57 --> Helper loaded: form_helper
INFO - 2020-11-05 02:03:57 --> Helper loaded: my_helper
INFO - 2020-11-05 02:03:57 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:03:57 --> Controller Class Initialized
INFO - 2020-11-05 02:03:57 --> Helper loaded: cookie_helper
INFO - 2020-11-05 02:03:57 --> Final output sent to browser
DEBUG - 2020-11-05 02:03:57 --> Total execution time: 0.3829
INFO - 2020-11-05 02:04:02 --> Config Class Initialized
INFO - 2020-11-05 02:04:02 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:04:02 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:04:02 --> Utf8 Class Initialized
INFO - 2020-11-05 02:04:02 --> URI Class Initialized
INFO - 2020-11-05 02:04:02 --> Router Class Initialized
INFO - 2020-11-05 02:04:02 --> Output Class Initialized
INFO - 2020-11-05 02:04:02 --> Security Class Initialized
DEBUG - 2020-11-05 02:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:04:02 --> Input Class Initialized
INFO - 2020-11-05 02:04:02 --> Language Class Initialized
INFO - 2020-11-05 02:04:02 --> Language Class Initialized
INFO - 2020-11-05 02:04:02 --> Config Class Initialized
INFO - 2020-11-05 02:04:02 --> Loader Class Initialized
INFO - 2020-11-05 02:04:02 --> Helper loaded: url_helper
INFO - 2020-11-05 02:04:02 --> Helper loaded: file_helper
INFO - 2020-11-05 02:04:02 --> Helper loaded: form_helper
INFO - 2020-11-05 02:04:02 --> Helper loaded: my_helper
INFO - 2020-11-05 02:04:02 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:04:02 --> Controller Class Initialized
DEBUG - 2020-11-05 02:04:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-05 02:04:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:04:02 --> Final output sent to browser
DEBUG - 2020-11-05 02:04:02 --> Total execution time: 0.3536
INFO - 2020-11-05 02:07:39 --> Config Class Initialized
INFO - 2020-11-05 02:07:39 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:07:39 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:07:39 --> Utf8 Class Initialized
INFO - 2020-11-05 02:07:39 --> URI Class Initialized
INFO - 2020-11-05 02:07:39 --> Router Class Initialized
INFO - 2020-11-05 02:07:39 --> Output Class Initialized
INFO - 2020-11-05 02:07:39 --> Security Class Initialized
DEBUG - 2020-11-05 02:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:07:39 --> Input Class Initialized
INFO - 2020-11-05 02:07:39 --> Language Class Initialized
INFO - 2020-11-05 02:07:39 --> Language Class Initialized
INFO - 2020-11-05 02:07:39 --> Config Class Initialized
INFO - 2020-11-05 02:07:39 --> Loader Class Initialized
INFO - 2020-11-05 02:07:39 --> Helper loaded: url_helper
INFO - 2020-11-05 02:07:39 --> Helper loaded: file_helper
INFO - 2020-11-05 02:07:39 --> Helper loaded: form_helper
INFO - 2020-11-05 02:07:39 --> Helper loaded: my_helper
INFO - 2020-11-05 02:07:39 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:07:39 --> Controller Class Initialized
DEBUG - 2020-11-05 02:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:07:39 --> Final output sent to browser
DEBUG - 2020-11-05 02:07:39 --> Total execution time: 0.3057
INFO - 2020-11-05 02:13:08 --> Config Class Initialized
INFO - 2020-11-05 02:13:08 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:13:08 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:13:08 --> Utf8 Class Initialized
INFO - 2020-11-05 02:13:08 --> URI Class Initialized
INFO - 2020-11-05 02:13:08 --> Router Class Initialized
INFO - 2020-11-05 02:13:08 --> Output Class Initialized
INFO - 2020-11-05 02:13:08 --> Security Class Initialized
DEBUG - 2020-11-05 02:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:13:08 --> Input Class Initialized
INFO - 2020-11-05 02:13:08 --> Language Class Initialized
INFO - 2020-11-05 02:13:08 --> Language Class Initialized
INFO - 2020-11-05 02:13:08 --> Config Class Initialized
INFO - 2020-11-05 02:13:08 --> Loader Class Initialized
INFO - 2020-11-05 02:13:08 --> Helper loaded: url_helper
INFO - 2020-11-05 02:13:08 --> Helper loaded: file_helper
INFO - 2020-11-05 02:13:08 --> Helper loaded: form_helper
INFO - 2020-11-05 02:13:08 --> Helper loaded: my_helper
INFO - 2020-11-05 02:13:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:13:08 --> Controller Class Initialized
DEBUG - 2020-11-05 02:13:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:13:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:13:08 --> Final output sent to browser
DEBUG - 2020-11-05 02:13:08 --> Total execution time: 0.3496
INFO - 2020-11-05 02:13:09 --> Config Class Initialized
INFO - 2020-11-05 02:13:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:13:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:13:09 --> Utf8 Class Initialized
INFO - 2020-11-05 02:13:09 --> URI Class Initialized
INFO - 2020-11-05 02:13:09 --> Router Class Initialized
INFO - 2020-11-05 02:13:09 --> Output Class Initialized
INFO - 2020-11-05 02:13:09 --> Security Class Initialized
DEBUG - 2020-11-05 02:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:13:09 --> Input Class Initialized
INFO - 2020-11-05 02:13:09 --> Language Class Initialized
INFO - 2020-11-05 02:13:09 --> Language Class Initialized
INFO - 2020-11-05 02:13:09 --> Config Class Initialized
INFO - 2020-11-05 02:13:09 --> Loader Class Initialized
INFO - 2020-11-05 02:13:09 --> Helper loaded: url_helper
INFO - 2020-11-05 02:13:09 --> Helper loaded: file_helper
INFO - 2020-11-05 02:13:09 --> Helper loaded: form_helper
INFO - 2020-11-05 02:13:09 --> Helper loaded: my_helper
INFO - 2020-11-05 02:13:09 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:13:09 --> Controller Class Initialized
INFO - 2020-11-05 02:14:05 --> Config Class Initialized
INFO - 2020-11-05 02:14:05 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:05 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:05 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:05 --> URI Class Initialized
INFO - 2020-11-05 02:14:05 --> Router Class Initialized
INFO - 2020-11-05 02:14:05 --> Output Class Initialized
INFO - 2020-11-05 02:14:05 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:05 --> Input Class Initialized
INFO - 2020-11-05 02:14:05 --> Language Class Initialized
INFO - 2020-11-05 02:14:05 --> Language Class Initialized
INFO - 2020-11-05 02:14:05 --> Config Class Initialized
INFO - 2020-11-05 02:14:05 --> Loader Class Initialized
INFO - 2020-11-05 02:14:05 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:05 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:05 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:05 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:05 --> Controller Class Initialized
INFO - 2020-11-05 02:14:07 --> Config Class Initialized
INFO - 2020-11-05 02:14:07 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:07 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:07 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:07 --> URI Class Initialized
INFO - 2020-11-05 02:14:07 --> Router Class Initialized
INFO - 2020-11-05 02:14:07 --> Output Class Initialized
INFO - 2020-11-05 02:14:07 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:07 --> Input Class Initialized
INFO - 2020-11-05 02:14:07 --> Language Class Initialized
INFO - 2020-11-05 02:14:07 --> Language Class Initialized
INFO - 2020-11-05 02:14:07 --> Config Class Initialized
INFO - 2020-11-05 02:14:07 --> Loader Class Initialized
INFO - 2020-11-05 02:14:07 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:07 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:07 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:08 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:08 --> Controller Class Initialized
ERROR - 2020-11-05 02:14:08 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-11-05 02:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-11-05 02:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:14:08 --> Final output sent to browser
DEBUG - 2020-11-05 02:14:08 --> Total execution time: 0.3288
INFO - 2020-11-05 02:14:17 --> Config Class Initialized
INFO - 2020-11-05 02:14:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:17 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:17 --> URI Class Initialized
INFO - 2020-11-05 02:14:17 --> Router Class Initialized
INFO - 2020-11-05 02:14:17 --> Output Class Initialized
INFO - 2020-11-05 02:14:17 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:17 --> Input Class Initialized
INFO - 2020-11-05 02:14:17 --> Language Class Initialized
INFO - 2020-11-05 02:14:17 --> Language Class Initialized
INFO - 2020-11-05 02:14:17 --> Config Class Initialized
INFO - 2020-11-05 02:14:17 --> Loader Class Initialized
INFO - 2020-11-05 02:14:17 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:17 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:17 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:17 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:17 --> Controller Class Initialized
INFO - 2020-11-05 02:14:17 --> Upload Class Initialized
INFO - 2020-11-05 02:14:17 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-11-05 02:14:17 --> The upload path does not appear to be valid.
INFO - 2020-11-05 02:14:17 --> Config Class Initialized
INFO - 2020-11-05 02:14:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:18 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:18 --> URI Class Initialized
INFO - 2020-11-05 02:14:18 --> Router Class Initialized
INFO - 2020-11-05 02:14:18 --> Output Class Initialized
INFO - 2020-11-05 02:14:18 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:18 --> Input Class Initialized
INFO - 2020-11-05 02:14:18 --> Language Class Initialized
INFO - 2020-11-05 02:14:18 --> Language Class Initialized
INFO - 2020-11-05 02:14:18 --> Config Class Initialized
INFO - 2020-11-05 02:14:18 --> Loader Class Initialized
INFO - 2020-11-05 02:14:18 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:18 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:18 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:18 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:18 --> Controller Class Initialized
DEBUG - 2020-11-05 02:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:14:18 --> Final output sent to browser
DEBUG - 2020-11-05 02:14:18 --> Total execution time: 0.2627
INFO - 2020-11-05 02:14:18 --> Config Class Initialized
INFO - 2020-11-05 02:14:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:18 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:18 --> URI Class Initialized
INFO - 2020-11-05 02:14:18 --> Router Class Initialized
INFO - 2020-11-05 02:14:18 --> Output Class Initialized
INFO - 2020-11-05 02:14:18 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:18 --> Input Class Initialized
INFO - 2020-11-05 02:14:18 --> Language Class Initialized
INFO - 2020-11-05 02:14:18 --> Language Class Initialized
INFO - 2020-11-05 02:14:18 --> Config Class Initialized
INFO - 2020-11-05 02:14:18 --> Loader Class Initialized
INFO - 2020-11-05 02:14:18 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:18 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:18 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:18 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:18 --> Controller Class Initialized
INFO - 2020-11-05 02:14:20 --> Config Class Initialized
INFO - 2020-11-05 02:14:20 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:20 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:20 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:20 --> URI Class Initialized
INFO - 2020-11-05 02:14:20 --> Router Class Initialized
INFO - 2020-11-05 02:14:20 --> Output Class Initialized
INFO - 2020-11-05 02:14:20 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:20 --> Input Class Initialized
INFO - 2020-11-05 02:14:20 --> Language Class Initialized
INFO - 2020-11-05 02:14:20 --> Language Class Initialized
INFO - 2020-11-05 02:14:20 --> Config Class Initialized
INFO - 2020-11-05 02:14:20 --> Loader Class Initialized
INFO - 2020-11-05 02:14:20 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:21 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:21 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:21 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:21 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:21 --> Controller Class Initialized
DEBUG - 2020-11-05 02:14:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:14:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:14:21 --> Final output sent to browser
DEBUG - 2020-11-05 02:14:21 --> Total execution time: 0.3583
INFO - 2020-11-05 02:14:22 --> Config Class Initialized
INFO - 2020-11-05 02:14:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:14:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:14:22 --> Utf8 Class Initialized
INFO - 2020-11-05 02:14:22 --> URI Class Initialized
INFO - 2020-11-05 02:14:22 --> Router Class Initialized
INFO - 2020-11-05 02:14:22 --> Output Class Initialized
INFO - 2020-11-05 02:14:22 --> Security Class Initialized
DEBUG - 2020-11-05 02:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:14:22 --> Input Class Initialized
INFO - 2020-11-05 02:14:22 --> Language Class Initialized
INFO - 2020-11-05 02:14:22 --> Language Class Initialized
INFO - 2020-11-05 02:14:22 --> Config Class Initialized
INFO - 2020-11-05 02:14:22 --> Loader Class Initialized
INFO - 2020-11-05 02:14:22 --> Helper loaded: url_helper
INFO - 2020-11-05 02:14:22 --> Helper loaded: file_helper
INFO - 2020-11-05 02:14:22 --> Helper loaded: form_helper
INFO - 2020-11-05 02:14:22 --> Helper loaded: my_helper
INFO - 2020-11-05 02:14:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:14:22 --> Controller Class Initialized
DEBUG - 2020-11-05 02:14:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 02:14:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:14:22 --> Final output sent to browser
DEBUG - 2020-11-05 02:14:22 --> Total execution time: 0.2904
INFO - 2020-11-05 02:19:38 --> Config Class Initialized
INFO - 2020-11-05 02:19:38 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:19:38 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:19:38 --> Utf8 Class Initialized
INFO - 2020-11-05 02:19:38 --> URI Class Initialized
INFO - 2020-11-05 02:19:38 --> Router Class Initialized
INFO - 2020-11-05 02:19:38 --> Output Class Initialized
INFO - 2020-11-05 02:19:38 --> Security Class Initialized
DEBUG - 2020-11-05 02:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:19:38 --> Input Class Initialized
INFO - 2020-11-05 02:19:38 --> Language Class Initialized
INFO - 2020-11-05 02:19:38 --> Language Class Initialized
INFO - 2020-11-05 02:19:38 --> Config Class Initialized
INFO - 2020-11-05 02:19:38 --> Loader Class Initialized
INFO - 2020-11-05 02:19:38 --> Helper loaded: url_helper
INFO - 2020-11-05 02:19:38 --> Helper loaded: file_helper
INFO - 2020-11-05 02:19:38 --> Helper loaded: form_helper
INFO - 2020-11-05 02:19:38 --> Helper loaded: my_helper
INFO - 2020-11-05 02:19:38 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:19:38 --> Controller Class Initialized
DEBUG - 2020-11-05 02:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:19:38 --> Final output sent to browser
DEBUG - 2020-11-05 02:19:38 --> Total execution time: 0.2643
INFO - 2020-11-05 02:20:21 --> Config Class Initialized
INFO - 2020-11-05 02:20:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:20:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:20:21 --> Utf8 Class Initialized
INFO - 2020-11-05 02:20:21 --> URI Class Initialized
DEBUG - 2020-11-05 02:20:21 --> No URI present. Default controller set.
INFO - 2020-11-05 02:20:21 --> Router Class Initialized
INFO - 2020-11-05 02:20:21 --> Output Class Initialized
INFO - 2020-11-05 02:20:21 --> Security Class Initialized
DEBUG - 2020-11-05 02:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:20:21 --> Input Class Initialized
INFO - 2020-11-05 02:20:21 --> Language Class Initialized
INFO - 2020-11-05 02:20:21 --> Language Class Initialized
INFO - 2020-11-05 02:20:21 --> Config Class Initialized
INFO - 2020-11-05 02:20:21 --> Loader Class Initialized
INFO - 2020-11-05 02:20:21 --> Helper loaded: url_helper
INFO - 2020-11-05 02:20:21 --> Helper loaded: file_helper
INFO - 2020-11-05 02:20:22 --> Helper loaded: form_helper
INFO - 2020-11-05 02:20:22 --> Helper loaded: my_helper
INFO - 2020-11-05 02:20:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:20:22 --> Controller Class Initialized
DEBUG - 2020-11-05 02:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-05 02:20:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:20:22 --> Final output sent to browser
DEBUG - 2020-11-05 02:20:22 --> Total execution time: 0.3338
INFO - 2020-11-05 02:21:40 --> Config Class Initialized
INFO - 2020-11-05 02:21:40 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:21:40 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:21:40 --> Utf8 Class Initialized
INFO - 2020-11-05 02:21:40 --> URI Class Initialized
INFO - 2020-11-05 02:21:40 --> Router Class Initialized
INFO - 2020-11-05 02:21:40 --> Output Class Initialized
INFO - 2020-11-05 02:21:40 --> Security Class Initialized
DEBUG - 2020-11-05 02:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:21:40 --> Input Class Initialized
INFO - 2020-11-05 02:21:40 --> Language Class Initialized
INFO - 2020-11-05 02:21:40 --> Language Class Initialized
INFO - 2020-11-05 02:21:40 --> Config Class Initialized
INFO - 2020-11-05 02:21:40 --> Loader Class Initialized
INFO - 2020-11-05 02:21:40 --> Helper loaded: url_helper
INFO - 2020-11-05 02:21:40 --> Helper loaded: file_helper
INFO - 2020-11-05 02:21:40 --> Helper loaded: form_helper
INFO - 2020-11-05 02:21:40 --> Helper loaded: my_helper
INFO - 2020-11-05 02:21:40 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:21:40 --> Controller Class Initialized
DEBUG - 2020-11-05 02:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:21:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:21:40 --> Final output sent to browser
DEBUG - 2020-11-05 02:21:40 --> Total execution time: 0.3425
INFO - 2020-11-05 02:45:08 --> Config Class Initialized
INFO - 2020-11-05 02:45:08 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:45:08 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:45:08 --> Utf8 Class Initialized
INFO - 2020-11-05 02:45:08 --> URI Class Initialized
INFO - 2020-11-05 02:45:08 --> Router Class Initialized
INFO - 2020-11-05 02:45:08 --> Output Class Initialized
INFO - 2020-11-05 02:45:08 --> Security Class Initialized
DEBUG - 2020-11-05 02:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:45:08 --> Input Class Initialized
INFO - 2020-11-05 02:45:08 --> Language Class Initialized
INFO - 2020-11-05 02:45:08 --> Language Class Initialized
INFO - 2020-11-05 02:45:08 --> Config Class Initialized
INFO - 2020-11-05 02:45:08 --> Loader Class Initialized
INFO - 2020-11-05 02:45:08 --> Helper loaded: url_helper
INFO - 2020-11-05 02:45:08 --> Helper loaded: file_helper
INFO - 2020-11-05 02:45:08 --> Helper loaded: form_helper
INFO - 2020-11-05 02:45:08 --> Helper loaded: my_helper
INFO - 2020-11-05 02:45:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:45:08 --> Controller Class Initialized
DEBUG - 2020-11-05 02:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:45:08 --> Final output sent to browser
DEBUG - 2020-11-05 02:45:08 --> Total execution time: 0.3351
INFO - 2020-11-05 02:45:09 --> Config Class Initialized
INFO - 2020-11-05 02:45:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:45:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:45:09 --> Utf8 Class Initialized
INFO - 2020-11-05 02:45:09 --> URI Class Initialized
INFO - 2020-11-05 02:45:09 --> Router Class Initialized
INFO - 2020-11-05 02:45:09 --> Output Class Initialized
INFO - 2020-11-05 02:45:09 --> Security Class Initialized
DEBUG - 2020-11-05 02:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:45:09 --> Input Class Initialized
INFO - 2020-11-05 02:45:09 --> Language Class Initialized
INFO - 2020-11-05 02:45:09 --> Language Class Initialized
INFO - 2020-11-05 02:45:09 --> Config Class Initialized
INFO - 2020-11-05 02:45:09 --> Loader Class Initialized
INFO - 2020-11-05 02:45:09 --> Helper loaded: url_helper
INFO - 2020-11-05 02:45:09 --> Helper loaded: file_helper
INFO - 2020-11-05 02:45:09 --> Helper loaded: form_helper
INFO - 2020-11-05 02:45:09 --> Helper loaded: my_helper
INFO - 2020-11-05 02:45:09 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:45:09 --> Controller Class Initialized
INFO - 2020-11-05 02:47:40 --> Config Class Initialized
INFO - 2020-11-05 02:47:40 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:47:40 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:47:40 --> Utf8 Class Initialized
INFO - 2020-11-05 02:47:41 --> URI Class Initialized
INFO - 2020-11-05 02:47:41 --> Router Class Initialized
INFO - 2020-11-05 02:47:41 --> Output Class Initialized
INFO - 2020-11-05 02:47:41 --> Security Class Initialized
DEBUG - 2020-11-05 02:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:47:41 --> Input Class Initialized
INFO - 2020-11-05 02:47:41 --> Language Class Initialized
INFO - 2020-11-05 02:47:41 --> Language Class Initialized
INFO - 2020-11-05 02:47:41 --> Config Class Initialized
INFO - 2020-11-05 02:47:41 --> Loader Class Initialized
INFO - 2020-11-05 02:47:41 --> Helper loaded: url_helper
INFO - 2020-11-05 02:47:41 --> Helper loaded: file_helper
INFO - 2020-11-05 02:47:41 --> Helper loaded: form_helper
INFO - 2020-11-05 02:47:41 --> Helper loaded: my_helper
INFO - 2020-11-05 02:47:41 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:47:41 --> Controller Class Initialized
DEBUG - 2020-11-05 02:47:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-11-05 02:47:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:47:41 --> Final output sent to browser
DEBUG - 2020-11-05 02:47:41 --> Total execution time: 0.3155
INFO - 2020-11-05 02:47:49 --> Config Class Initialized
INFO - 2020-11-05 02:47:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:47:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:47:49 --> Utf8 Class Initialized
INFO - 2020-11-05 02:47:49 --> URI Class Initialized
INFO - 2020-11-05 02:47:49 --> Router Class Initialized
INFO - 2020-11-05 02:47:49 --> Output Class Initialized
INFO - 2020-11-05 02:47:49 --> Security Class Initialized
DEBUG - 2020-11-05 02:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:47:49 --> Input Class Initialized
INFO - 2020-11-05 02:47:49 --> Language Class Initialized
INFO - 2020-11-05 02:47:49 --> Language Class Initialized
INFO - 2020-11-05 02:47:49 --> Config Class Initialized
INFO - 2020-11-05 02:47:49 --> Loader Class Initialized
INFO - 2020-11-05 02:47:49 --> Helper loaded: url_helper
INFO - 2020-11-05 02:47:49 --> Helper loaded: file_helper
INFO - 2020-11-05 02:47:49 --> Helper loaded: form_helper
INFO - 2020-11-05 02:47:49 --> Helper loaded: my_helper
INFO - 2020-11-05 02:47:49 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:47:49 --> Controller Class Initialized
INFO - 2020-11-05 02:47:52 --> Config Class Initialized
INFO - 2020-11-05 02:47:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:47:53 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:47:53 --> Utf8 Class Initialized
INFO - 2020-11-05 02:47:53 --> URI Class Initialized
INFO - 2020-11-05 02:47:53 --> Router Class Initialized
INFO - 2020-11-05 02:47:53 --> Output Class Initialized
INFO - 2020-11-05 02:47:53 --> Security Class Initialized
DEBUG - 2020-11-05 02:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:47:53 --> Input Class Initialized
INFO - 2020-11-05 02:47:53 --> Language Class Initialized
INFO - 2020-11-05 02:47:53 --> Language Class Initialized
INFO - 2020-11-05 02:47:53 --> Config Class Initialized
INFO - 2020-11-05 02:47:53 --> Loader Class Initialized
INFO - 2020-11-05 02:47:53 --> Helper loaded: url_helper
INFO - 2020-11-05 02:47:53 --> Helper loaded: file_helper
INFO - 2020-11-05 02:47:53 --> Helper loaded: form_helper
INFO - 2020-11-05 02:47:53 --> Helper loaded: my_helper
INFO - 2020-11-05 02:47:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:47:53 --> Controller Class Initialized
DEBUG - 2020-11-05 02:47:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-11-05 02:47:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:47:53 --> Final output sent to browser
DEBUG - 2020-11-05 02:47:53 --> Total execution time: 0.2580
INFO - 2020-11-05 02:47:55 --> Config Class Initialized
INFO - 2020-11-05 02:47:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:47:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:47:55 --> Utf8 Class Initialized
INFO - 2020-11-05 02:47:55 --> URI Class Initialized
INFO - 2020-11-05 02:47:55 --> Router Class Initialized
INFO - 2020-11-05 02:47:55 --> Output Class Initialized
INFO - 2020-11-05 02:47:55 --> Security Class Initialized
DEBUG - 2020-11-05 02:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:47:55 --> Input Class Initialized
INFO - 2020-11-05 02:47:55 --> Language Class Initialized
INFO - 2020-11-05 02:47:55 --> Language Class Initialized
INFO - 2020-11-05 02:47:55 --> Config Class Initialized
INFO - 2020-11-05 02:47:55 --> Loader Class Initialized
INFO - 2020-11-05 02:47:55 --> Helper loaded: url_helper
INFO - 2020-11-05 02:47:55 --> Helper loaded: file_helper
INFO - 2020-11-05 02:47:55 --> Helper loaded: form_helper
INFO - 2020-11-05 02:47:55 --> Helper loaded: my_helper
INFO - 2020-11-05 02:47:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:47:55 --> Controller Class Initialized
DEBUG - 2020-11-05 02:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:47:55 --> Final output sent to browser
DEBUG - 2020-11-05 02:47:55 --> Total execution time: 0.3331
INFO - 2020-11-05 02:47:55 --> Config Class Initialized
INFO - 2020-11-05 02:47:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:47:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:47:55 --> Utf8 Class Initialized
INFO - 2020-11-05 02:47:55 --> URI Class Initialized
INFO - 2020-11-05 02:47:55 --> Router Class Initialized
INFO - 2020-11-05 02:47:55 --> Output Class Initialized
INFO - 2020-11-05 02:47:55 --> Security Class Initialized
DEBUG - 2020-11-05 02:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:47:55 --> Input Class Initialized
INFO - 2020-11-05 02:47:55 --> Language Class Initialized
INFO - 2020-11-05 02:47:55 --> Language Class Initialized
INFO - 2020-11-05 02:47:55 --> Config Class Initialized
INFO - 2020-11-05 02:47:55 --> Loader Class Initialized
INFO - 2020-11-05 02:47:55 --> Helper loaded: url_helper
INFO - 2020-11-05 02:47:55 --> Helper loaded: file_helper
INFO - 2020-11-05 02:47:55 --> Helper loaded: form_helper
INFO - 2020-11-05 02:47:55 --> Helper loaded: my_helper
INFO - 2020-11-05 02:47:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:47:55 --> Controller Class Initialized
INFO - 2020-11-05 02:48:00 --> Config Class Initialized
INFO - 2020-11-05 02:48:00 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:48:00 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:48:00 --> Utf8 Class Initialized
INFO - 2020-11-05 02:48:00 --> URI Class Initialized
INFO - 2020-11-05 02:48:00 --> Router Class Initialized
INFO - 2020-11-05 02:48:00 --> Output Class Initialized
INFO - 2020-11-05 02:48:00 --> Security Class Initialized
DEBUG - 2020-11-05 02:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:48:00 --> Input Class Initialized
INFO - 2020-11-05 02:48:00 --> Language Class Initialized
INFO - 2020-11-05 02:48:01 --> Language Class Initialized
INFO - 2020-11-05 02:48:01 --> Config Class Initialized
INFO - 2020-11-05 02:48:01 --> Loader Class Initialized
INFO - 2020-11-05 02:48:01 --> Helper loaded: url_helper
INFO - 2020-11-05 02:48:01 --> Helper loaded: file_helper
INFO - 2020-11-05 02:48:01 --> Helper loaded: form_helper
INFO - 2020-11-05 02:48:01 --> Helper loaded: my_helper
INFO - 2020-11-05 02:48:01 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:48:01 --> Controller Class Initialized
ERROR - 2020-11-05 02:48:01 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-11-05 02:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-11-05 02:48:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:48:01 --> Final output sent to browser
DEBUG - 2020-11-05 02:48:01 --> Total execution time: 0.3203
INFO - 2020-11-05 02:54:12 --> Config Class Initialized
INFO - 2020-11-05 02:54:12 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:12 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:12 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:12 --> URI Class Initialized
INFO - 2020-11-05 02:54:12 --> Router Class Initialized
INFO - 2020-11-05 02:54:12 --> Output Class Initialized
INFO - 2020-11-05 02:54:12 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:12 --> Input Class Initialized
INFO - 2020-11-05 02:54:12 --> Language Class Initialized
INFO - 2020-11-05 02:54:12 --> Language Class Initialized
INFO - 2020-11-05 02:54:12 --> Config Class Initialized
INFO - 2020-11-05 02:54:12 --> Loader Class Initialized
INFO - 2020-11-05 02:54:12 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:12 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:12 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:12 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:12 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:12 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:12 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:12 --> Total execution time: 0.2877
INFO - 2020-11-05 02:54:12 --> Config Class Initialized
INFO - 2020-11-05 02:54:12 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:12 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:12 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:12 --> URI Class Initialized
INFO - 2020-11-05 02:54:12 --> Router Class Initialized
INFO - 2020-11-05 02:54:12 --> Output Class Initialized
INFO - 2020-11-05 02:54:12 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:12 --> Input Class Initialized
INFO - 2020-11-05 02:54:12 --> Language Class Initialized
INFO - 2020-11-05 02:54:12 --> Language Class Initialized
INFO - 2020-11-05 02:54:12 --> Config Class Initialized
INFO - 2020-11-05 02:54:12 --> Loader Class Initialized
INFO - 2020-11-05 02:54:12 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:12 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:12 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:12 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:12 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:12 --> Controller Class Initialized
INFO - 2020-11-05 02:54:18 --> Config Class Initialized
INFO - 2020-11-05 02:54:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:18 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:18 --> URI Class Initialized
INFO - 2020-11-05 02:54:18 --> Router Class Initialized
INFO - 2020-11-05 02:54:18 --> Output Class Initialized
INFO - 2020-11-05 02:54:18 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:18 --> Input Class Initialized
INFO - 2020-11-05 02:54:18 --> Language Class Initialized
INFO - 2020-11-05 02:54:18 --> Language Class Initialized
INFO - 2020-11-05 02:54:18 --> Config Class Initialized
INFO - 2020-11-05 02:54:18 --> Loader Class Initialized
INFO - 2020-11-05 02:54:18 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:18 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:18 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:18 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:18 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:54:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:18 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:18 --> Total execution time: 0.3388
INFO - 2020-11-05 02:54:19 --> Config Class Initialized
INFO - 2020-11-05 02:54:19 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:19 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:19 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:19 --> URI Class Initialized
INFO - 2020-11-05 02:54:19 --> Router Class Initialized
INFO - 2020-11-05 02:54:19 --> Output Class Initialized
INFO - 2020-11-05 02:54:19 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:19 --> Input Class Initialized
INFO - 2020-11-05 02:54:20 --> Language Class Initialized
INFO - 2020-11-05 02:54:20 --> Language Class Initialized
INFO - 2020-11-05 02:54:20 --> Config Class Initialized
INFO - 2020-11-05 02:54:20 --> Loader Class Initialized
INFO - 2020-11-05 02:54:20 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:20 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:20 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:20 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:20 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:20 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 02:54:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:20 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:20 --> Total execution time: 0.2929
INFO - 2020-11-05 02:54:22 --> Config Class Initialized
INFO - 2020-11-05 02:54:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:22 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:22 --> URI Class Initialized
INFO - 2020-11-05 02:54:22 --> Router Class Initialized
INFO - 2020-11-05 02:54:22 --> Output Class Initialized
INFO - 2020-11-05 02:54:22 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:22 --> Input Class Initialized
INFO - 2020-11-05 02:54:22 --> Language Class Initialized
INFO - 2020-11-05 02:54:22 --> Language Class Initialized
INFO - 2020-11-05 02:54:22 --> Config Class Initialized
INFO - 2020-11-05 02:54:22 --> Loader Class Initialized
INFO - 2020-11-05 02:54:22 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:22 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:22 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:22 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:22 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:54:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:22 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:22 --> Total execution time: 0.2751
INFO - 2020-11-05 02:54:22 --> Config Class Initialized
INFO - 2020-11-05 02:54:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:22 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:22 --> URI Class Initialized
INFO - 2020-11-05 02:54:22 --> Router Class Initialized
INFO - 2020-11-05 02:54:22 --> Output Class Initialized
INFO - 2020-11-05 02:54:22 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:22 --> Input Class Initialized
INFO - 2020-11-05 02:54:22 --> Language Class Initialized
INFO - 2020-11-05 02:54:22 --> Language Class Initialized
INFO - 2020-11-05 02:54:22 --> Config Class Initialized
INFO - 2020-11-05 02:54:22 --> Loader Class Initialized
INFO - 2020-11-05 02:54:22 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:22 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:22 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:22 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:22 --> Controller Class Initialized
INFO - 2020-11-05 02:54:26 --> Config Class Initialized
INFO - 2020-11-05 02:54:26 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:26 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:26 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:26 --> URI Class Initialized
INFO - 2020-11-05 02:54:26 --> Router Class Initialized
INFO - 2020-11-05 02:54:26 --> Output Class Initialized
INFO - 2020-11-05 02:54:26 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:26 --> Input Class Initialized
INFO - 2020-11-05 02:54:26 --> Language Class Initialized
INFO - 2020-11-05 02:54:26 --> Language Class Initialized
INFO - 2020-11-05 02:54:26 --> Config Class Initialized
INFO - 2020-11-05 02:54:26 --> Loader Class Initialized
INFO - 2020-11-05 02:54:26 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:26 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:26 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:26 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:26 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:26 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-11-05 02:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:26 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:26 --> Total execution time: 0.3188
INFO - 2020-11-05 02:54:31 --> Config Class Initialized
INFO - 2020-11-05 02:54:31 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:31 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:31 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:31 --> URI Class Initialized
INFO - 2020-11-05 02:54:31 --> Router Class Initialized
INFO - 2020-11-05 02:54:31 --> Output Class Initialized
INFO - 2020-11-05 02:54:31 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:31 --> Input Class Initialized
INFO - 2020-11-05 02:54:31 --> Language Class Initialized
INFO - 2020-11-05 02:54:31 --> Language Class Initialized
INFO - 2020-11-05 02:54:31 --> Config Class Initialized
INFO - 2020-11-05 02:54:31 --> Loader Class Initialized
INFO - 2020-11-05 02:54:31 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:31 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:31 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:31 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:31 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:31 --> Controller Class Initialized
INFO - 2020-11-05 02:54:34 --> Config Class Initialized
INFO - 2020-11-05 02:54:34 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:34 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:34 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:34 --> URI Class Initialized
INFO - 2020-11-05 02:54:34 --> Router Class Initialized
INFO - 2020-11-05 02:54:34 --> Output Class Initialized
INFO - 2020-11-05 02:54:34 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:34 --> Input Class Initialized
INFO - 2020-11-05 02:54:34 --> Language Class Initialized
INFO - 2020-11-05 02:54:34 --> Language Class Initialized
INFO - 2020-11-05 02:54:34 --> Config Class Initialized
INFO - 2020-11-05 02:54:34 --> Loader Class Initialized
INFO - 2020-11-05 02:54:34 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:34 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:34 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:34 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:34 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:34 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-11-05 02:54:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:34 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:34 --> Total execution time: 0.2445
INFO - 2020-11-05 02:54:36 --> Config Class Initialized
INFO - 2020-11-05 02:54:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:36 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:36 --> URI Class Initialized
INFO - 2020-11-05 02:54:36 --> Router Class Initialized
INFO - 2020-11-05 02:54:36 --> Output Class Initialized
INFO - 2020-11-05 02:54:36 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:36 --> Input Class Initialized
INFO - 2020-11-05 02:54:36 --> Language Class Initialized
INFO - 2020-11-05 02:54:36 --> Language Class Initialized
INFO - 2020-11-05 02:54:36 --> Config Class Initialized
INFO - 2020-11-05 02:54:36 --> Loader Class Initialized
INFO - 2020-11-05 02:54:36 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:36 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:36 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:36 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:36 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:36 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:36 --> Total execution time: 0.3088
INFO - 2020-11-05 02:54:36 --> Config Class Initialized
INFO - 2020-11-05 02:54:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:36 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:36 --> URI Class Initialized
INFO - 2020-11-05 02:54:36 --> Router Class Initialized
INFO - 2020-11-05 02:54:36 --> Output Class Initialized
INFO - 2020-11-05 02:54:36 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:36 --> Input Class Initialized
INFO - 2020-11-05 02:54:36 --> Language Class Initialized
INFO - 2020-11-05 02:54:36 --> Language Class Initialized
INFO - 2020-11-05 02:54:36 --> Config Class Initialized
INFO - 2020-11-05 02:54:36 --> Loader Class Initialized
INFO - 2020-11-05 02:54:36 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:36 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:36 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:36 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:36 --> Controller Class Initialized
INFO - 2020-11-05 02:54:46 --> Config Class Initialized
INFO - 2020-11-05 02:54:46 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:46 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:46 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:46 --> URI Class Initialized
INFO - 2020-11-05 02:54:46 --> Router Class Initialized
INFO - 2020-11-05 02:54:46 --> Output Class Initialized
INFO - 2020-11-05 02:54:46 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:46 --> Input Class Initialized
INFO - 2020-11-05 02:54:46 --> Language Class Initialized
INFO - 2020-11-05 02:54:46 --> Language Class Initialized
INFO - 2020-11-05 02:54:46 --> Config Class Initialized
INFO - 2020-11-05 02:54:46 --> Loader Class Initialized
INFO - 2020-11-05 02:54:46 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:46 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:46 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:46 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:46 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:46 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:54:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:46 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:46 --> Total execution time: 0.3061
INFO - 2020-11-05 02:54:47 --> Config Class Initialized
INFO - 2020-11-05 02:54:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:54:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:54:47 --> Utf8 Class Initialized
INFO - 2020-11-05 02:54:47 --> URI Class Initialized
INFO - 2020-11-05 02:54:47 --> Router Class Initialized
INFO - 2020-11-05 02:54:47 --> Output Class Initialized
INFO - 2020-11-05 02:54:47 --> Security Class Initialized
DEBUG - 2020-11-05 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:54:47 --> Input Class Initialized
INFO - 2020-11-05 02:54:48 --> Language Class Initialized
INFO - 2020-11-05 02:54:48 --> Language Class Initialized
INFO - 2020-11-05 02:54:48 --> Config Class Initialized
INFO - 2020-11-05 02:54:48 --> Loader Class Initialized
INFO - 2020-11-05 02:54:48 --> Helper loaded: url_helper
INFO - 2020-11-05 02:54:48 --> Helper loaded: file_helper
INFO - 2020-11-05 02:54:48 --> Helper loaded: form_helper
INFO - 2020-11-05 02:54:48 --> Helper loaded: my_helper
INFO - 2020-11-05 02:54:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:54:48 --> Controller Class Initialized
DEBUG - 2020-11-05 02:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 02:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:54:48 --> Final output sent to browser
DEBUG - 2020-11-05 02:54:48 --> Total execution time: 0.2931
INFO - 2020-11-05 02:56:48 --> Config Class Initialized
INFO - 2020-11-05 02:56:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:56:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:56:48 --> Utf8 Class Initialized
INFO - 2020-11-05 02:56:48 --> URI Class Initialized
INFO - 2020-11-05 02:56:48 --> Router Class Initialized
INFO - 2020-11-05 02:56:48 --> Output Class Initialized
INFO - 2020-11-05 02:56:48 --> Security Class Initialized
DEBUG - 2020-11-05 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:56:48 --> Input Class Initialized
INFO - 2020-11-05 02:56:48 --> Language Class Initialized
INFO - 2020-11-05 02:56:48 --> Language Class Initialized
INFO - 2020-11-05 02:56:48 --> Config Class Initialized
INFO - 2020-11-05 02:56:48 --> Loader Class Initialized
INFO - 2020-11-05 02:56:48 --> Helper loaded: url_helper
INFO - 2020-11-05 02:56:48 --> Helper loaded: file_helper
INFO - 2020-11-05 02:56:48 --> Helper loaded: form_helper
INFO - 2020-11-05 02:56:48 --> Helper loaded: my_helper
INFO - 2020-11-05 02:56:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:56:48 --> Controller Class Initialized
INFO - 2020-11-05 02:56:48 --> Config Class Initialized
INFO - 2020-11-05 02:56:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:56:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:56:48 --> Utf8 Class Initialized
INFO - 2020-11-05 02:56:48 --> URI Class Initialized
INFO - 2020-11-05 02:56:48 --> Router Class Initialized
INFO - 2020-11-05 02:56:48 --> Output Class Initialized
INFO - 2020-11-05 02:56:48 --> Security Class Initialized
DEBUG - 2020-11-05 02:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:56:48 --> Input Class Initialized
INFO - 2020-11-05 02:56:48 --> Language Class Initialized
INFO - 2020-11-05 02:56:48 --> Language Class Initialized
INFO - 2020-11-05 02:56:48 --> Config Class Initialized
INFO - 2020-11-05 02:56:48 --> Loader Class Initialized
INFO - 2020-11-05 02:56:48 --> Helper loaded: url_helper
INFO - 2020-11-05 02:56:48 --> Helper loaded: file_helper
INFO - 2020-11-05 02:56:48 --> Helper loaded: form_helper
INFO - 2020-11-05 02:56:48 --> Helper loaded: my_helper
INFO - 2020-11-05 02:56:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:56:48 --> Controller Class Initialized
DEBUG - 2020-11-05 02:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:56:48 --> Final output sent to browser
DEBUG - 2020-11-05 02:56:48 --> Total execution time: 0.2840
INFO - 2020-11-05 02:56:54 --> Config Class Initialized
INFO - 2020-11-05 02:56:54 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:56:54 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:56:54 --> Utf8 Class Initialized
INFO - 2020-11-05 02:56:54 --> URI Class Initialized
INFO - 2020-11-05 02:56:54 --> Router Class Initialized
INFO - 2020-11-05 02:56:54 --> Output Class Initialized
INFO - 2020-11-05 02:56:54 --> Security Class Initialized
DEBUG - 2020-11-05 02:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:56:54 --> Input Class Initialized
INFO - 2020-11-05 02:56:54 --> Language Class Initialized
INFO - 2020-11-05 02:56:54 --> Language Class Initialized
INFO - 2020-11-05 02:56:54 --> Config Class Initialized
INFO - 2020-11-05 02:56:54 --> Loader Class Initialized
INFO - 2020-11-05 02:56:54 --> Helper loaded: url_helper
INFO - 2020-11-05 02:56:54 --> Helper loaded: file_helper
INFO - 2020-11-05 02:56:54 --> Helper loaded: form_helper
INFO - 2020-11-05 02:56:54 --> Helper loaded: my_helper
INFO - 2020-11-05 02:56:54 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:56:54 --> Controller Class Initialized
DEBUG - 2020-11-05 02:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 02:56:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:56:54 --> Final output sent to browser
DEBUG - 2020-11-05 02:56:54 --> Total execution time: 0.2782
INFO - 2020-11-05 02:57:36 --> Config Class Initialized
INFO - 2020-11-05 02:57:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:57:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:57:36 --> Utf8 Class Initialized
INFO - 2020-11-05 02:57:36 --> URI Class Initialized
INFO - 2020-11-05 02:57:36 --> Router Class Initialized
INFO - 2020-11-05 02:57:36 --> Output Class Initialized
INFO - 2020-11-05 02:57:36 --> Security Class Initialized
DEBUG - 2020-11-05 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:57:36 --> Input Class Initialized
INFO - 2020-11-05 02:57:36 --> Language Class Initialized
INFO - 2020-11-05 02:57:36 --> Language Class Initialized
INFO - 2020-11-05 02:57:36 --> Config Class Initialized
INFO - 2020-11-05 02:57:36 --> Loader Class Initialized
INFO - 2020-11-05 02:57:36 --> Helper loaded: url_helper
INFO - 2020-11-05 02:57:36 --> Helper loaded: file_helper
INFO - 2020-11-05 02:57:36 --> Helper loaded: form_helper
INFO - 2020-11-05 02:57:36 --> Helper loaded: my_helper
INFO - 2020-11-05 02:57:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:57:36 --> Controller Class Initialized
INFO - 2020-11-05 02:57:36 --> Config Class Initialized
INFO - 2020-11-05 02:57:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 02:57:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 02:57:36 --> Utf8 Class Initialized
INFO - 2020-11-05 02:57:36 --> URI Class Initialized
INFO - 2020-11-05 02:57:36 --> Router Class Initialized
INFO - 2020-11-05 02:57:36 --> Output Class Initialized
INFO - 2020-11-05 02:57:36 --> Security Class Initialized
DEBUG - 2020-11-05 02:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 02:57:36 --> Input Class Initialized
INFO - 2020-11-05 02:57:36 --> Language Class Initialized
INFO - 2020-11-05 02:57:36 --> Language Class Initialized
INFO - 2020-11-05 02:57:36 --> Config Class Initialized
INFO - 2020-11-05 02:57:36 --> Loader Class Initialized
INFO - 2020-11-05 02:57:36 --> Helper loaded: url_helper
INFO - 2020-11-05 02:57:36 --> Helper loaded: file_helper
INFO - 2020-11-05 02:57:36 --> Helper loaded: form_helper
INFO - 2020-11-05 02:57:36 --> Helper loaded: my_helper
INFO - 2020-11-05 02:57:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 02:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 02:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 02:57:36 --> Controller Class Initialized
DEBUG - 2020-11-05 02:57:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 02:57:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 02:57:36 --> Final output sent to browser
DEBUG - 2020-11-05 02:57:36 --> Total execution time: 0.2411
INFO - 2020-11-05 03:01:17 --> Config Class Initialized
INFO - 2020-11-05 03:01:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:01:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:01:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:01:17 --> URI Class Initialized
INFO - 2020-11-05 03:01:17 --> Router Class Initialized
INFO - 2020-11-05 03:01:17 --> Output Class Initialized
INFO - 2020-11-05 03:01:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:01:18 --> Input Class Initialized
INFO - 2020-11-05 03:01:18 --> Language Class Initialized
INFO - 2020-11-05 03:01:18 --> Language Class Initialized
INFO - 2020-11-05 03:01:18 --> Config Class Initialized
INFO - 2020-11-05 03:01:18 --> Loader Class Initialized
INFO - 2020-11-05 03:01:18 --> Helper loaded: url_helper
INFO - 2020-11-05 03:01:18 --> Helper loaded: file_helper
INFO - 2020-11-05 03:01:18 --> Helper loaded: form_helper
INFO - 2020-11-05 03:01:18 --> Helper loaded: my_helper
INFO - 2020-11-05 03:01:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:01:18 --> Controller Class Initialized
DEBUG - 2020-11-05 03:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:01:18 --> Final output sent to browser
DEBUG - 2020-11-05 03:01:18 --> Total execution time: 0.2605
INFO - 2020-11-05 03:01:41 --> Config Class Initialized
INFO - 2020-11-05 03:01:41 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:01:41 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:01:41 --> Utf8 Class Initialized
INFO - 2020-11-05 03:01:41 --> URI Class Initialized
INFO - 2020-11-05 03:01:41 --> Router Class Initialized
INFO - 2020-11-05 03:01:41 --> Output Class Initialized
INFO - 2020-11-05 03:01:41 --> Security Class Initialized
DEBUG - 2020-11-05 03:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:01:41 --> Input Class Initialized
INFO - 2020-11-05 03:01:41 --> Language Class Initialized
INFO - 2020-11-05 03:01:41 --> Language Class Initialized
INFO - 2020-11-05 03:01:41 --> Config Class Initialized
INFO - 2020-11-05 03:01:41 --> Loader Class Initialized
INFO - 2020-11-05 03:01:41 --> Helper loaded: url_helper
INFO - 2020-11-05 03:01:41 --> Helper loaded: file_helper
INFO - 2020-11-05 03:01:41 --> Helper loaded: form_helper
INFO - 2020-11-05 03:01:41 --> Helper loaded: my_helper
INFO - 2020-11-05 03:01:41 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:01:42 --> Controller Class Initialized
DEBUG - 2020-11-05 03:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:01:42 --> Final output sent to browser
DEBUG - 2020-11-05 03:01:42 --> Total execution time: 0.3144
INFO - 2020-11-05 03:02:22 --> Config Class Initialized
INFO - 2020-11-05 03:02:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:02:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:02:22 --> Utf8 Class Initialized
INFO - 2020-11-05 03:02:22 --> URI Class Initialized
INFO - 2020-11-05 03:02:22 --> Router Class Initialized
INFO - 2020-11-05 03:02:22 --> Output Class Initialized
INFO - 2020-11-05 03:02:22 --> Security Class Initialized
DEBUG - 2020-11-05 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:02:22 --> Input Class Initialized
INFO - 2020-11-05 03:02:22 --> Language Class Initialized
INFO - 2020-11-05 03:02:22 --> Language Class Initialized
INFO - 2020-11-05 03:02:22 --> Config Class Initialized
INFO - 2020-11-05 03:02:22 --> Loader Class Initialized
INFO - 2020-11-05 03:02:22 --> Helper loaded: url_helper
INFO - 2020-11-05 03:02:22 --> Helper loaded: file_helper
INFO - 2020-11-05 03:02:22 --> Helper loaded: form_helper
INFO - 2020-11-05 03:02:22 --> Helper loaded: my_helper
INFO - 2020-11-05 03:02:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:02:22 --> Controller Class Initialized
INFO - 2020-11-05 03:02:22 --> Config Class Initialized
INFO - 2020-11-05 03:02:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:02:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:02:22 --> Utf8 Class Initialized
INFO - 2020-11-05 03:02:22 --> URI Class Initialized
INFO - 2020-11-05 03:02:22 --> Router Class Initialized
INFO - 2020-11-05 03:02:22 --> Output Class Initialized
INFO - 2020-11-05 03:02:22 --> Security Class Initialized
DEBUG - 2020-11-05 03:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:02:23 --> Input Class Initialized
INFO - 2020-11-05 03:02:23 --> Language Class Initialized
INFO - 2020-11-05 03:02:23 --> Language Class Initialized
INFO - 2020-11-05 03:02:23 --> Config Class Initialized
INFO - 2020-11-05 03:02:23 --> Loader Class Initialized
INFO - 2020-11-05 03:02:23 --> Helper loaded: url_helper
INFO - 2020-11-05 03:02:23 --> Helper loaded: file_helper
INFO - 2020-11-05 03:02:23 --> Helper loaded: form_helper
INFO - 2020-11-05 03:02:23 --> Helper loaded: my_helper
INFO - 2020-11-05 03:02:23 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:02:23 --> Controller Class Initialized
DEBUG - 2020-11-05 03:02:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:02:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:02:23 --> Final output sent to browser
DEBUG - 2020-11-05 03:02:23 --> Total execution time: 0.2729
INFO - 2020-11-05 03:02:31 --> Config Class Initialized
INFO - 2020-11-05 03:02:31 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:02:31 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:02:31 --> Utf8 Class Initialized
INFO - 2020-11-05 03:02:31 --> URI Class Initialized
INFO - 2020-11-05 03:02:31 --> Router Class Initialized
INFO - 2020-11-05 03:02:31 --> Output Class Initialized
INFO - 2020-11-05 03:02:31 --> Security Class Initialized
DEBUG - 2020-11-05 03:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:02:31 --> Input Class Initialized
INFO - 2020-11-05 03:02:31 --> Language Class Initialized
INFO - 2020-11-05 03:02:31 --> Language Class Initialized
INFO - 2020-11-05 03:02:31 --> Config Class Initialized
INFO - 2020-11-05 03:02:31 --> Loader Class Initialized
INFO - 2020-11-05 03:02:31 --> Helper loaded: url_helper
INFO - 2020-11-05 03:02:31 --> Helper loaded: file_helper
INFO - 2020-11-05 03:02:31 --> Helper loaded: form_helper
INFO - 2020-11-05 03:02:31 --> Helper loaded: my_helper
INFO - 2020-11-05 03:02:32 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:02:32 --> Controller Class Initialized
DEBUG - 2020-11-05 03:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:02:32 --> Final output sent to browser
DEBUG - 2020-11-05 03:02:32 --> Total execution time: 0.2922
INFO - 2020-11-05 03:03:00 --> Config Class Initialized
INFO - 2020-11-05 03:03:00 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:03:00 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:03:00 --> Utf8 Class Initialized
INFO - 2020-11-05 03:03:00 --> URI Class Initialized
INFO - 2020-11-05 03:03:00 --> Router Class Initialized
INFO - 2020-11-05 03:03:00 --> Output Class Initialized
INFO - 2020-11-05 03:03:00 --> Security Class Initialized
DEBUG - 2020-11-05 03:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:03:00 --> Input Class Initialized
INFO - 2020-11-05 03:03:00 --> Language Class Initialized
INFO - 2020-11-05 03:03:00 --> Language Class Initialized
INFO - 2020-11-05 03:03:00 --> Config Class Initialized
INFO - 2020-11-05 03:03:00 --> Loader Class Initialized
INFO - 2020-11-05 03:03:00 --> Helper loaded: url_helper
INFO - 2020-11-05 03:03:00 --> Helper loaded: file_helper
INFO - 2020-11-05 03:03:00 --> Helper loaded: form_helper
INFO - 2020-11-05 03:03:00 --> Helper loaded: my_helper
INFO - 2020-11-05 03:03:00 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:03:00 --> Controller Class Initialized
INFO - 2020-11-05 03:03:00 --> Config Class Initialized
INFO - 2020-11-05 03:03:00 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:03:00 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:03:00 --> Utf8 Class Initialized
INFO - 2020-11-05 03:03:00 --> URI Class Initialized
INFO - 2020-11-05 03:03:00 --> Router Class Initialized
INFO - 2020-11-05 03:03:00 --> Output Class Initialized
INFO - 2020-11-05 03:03:00 --> Security Class Initialized
DEBUG - 2020-11-05 03:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:03:00 --> Input Class Initialized
INFO - 2020-11-05 03:03:00 --> Language Class Initialized
INFO - 2020-11-05 03:03:00 --> Language Class Initialized
INFO - 2020-11-05 03:03:00 --> Config Class Initialized
INFO - 2020-11-05 03:03:00 --> Loader Class Initialized
INFO - 2020-11-05 03:03:00 --> Helper loaded: url_helper
INFO - 2020-11-05 03:03:00 --> Helper loaded: file_helper
INFO - 2020-11-05 03:03:00 --> Helper loaded: form_helper
INFO - 2020-11-05 03:03:00 --> Helper loaded: my_helper
INFO - 2020-11-05 03:03:00 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:03:00 --> Controller Class Initialized
DEBUG - 2020-11-05 03:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:03:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:03:00 --> Final output sent to browser
DEBUG - 2020-11-05 03:03:00 --> Total execution time: 0.2466
INFO - 2020-11-05 03:03:06 --> Config Class Initialized
INFO - 2020-11-05 03:03:06 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:03:06 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:03:06 --> Utf8 Class Initialized
INFO - 2020-11-05 03:03:06 --> URI Class Initialized
INFO - 2020-11-05 03:03:06 --> Router Class Initialized
INFO - 2020-11-05 03:03:06 --> Output Class Initialized
INFO - 2020-11-05 03:03:06 --> Security Class Initialized
DEBUG - 2020-11-05 03:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:03:06 --> Input Class Initialized
INFO - 2020-11-05 03:03:06 --> Language Class Initialized
INFO - 2020-11-05 03:03:06 --> Language Class Initialized
INFO - 2020-11-05 03:03:06 --> Config Class Initialized
INFO - 2020-11-05 03:03:06 --> Loader Class Initialized
INFO - 2020-11-05 03:03:06 --> Helper loaded: url_helper
INFO - 2020-11-05 03:03:06 --> Helper loaded: file_helper
INFO - 2020-11-05 03:03:07 --> Helper loaded: form_helper
INFO - 2020-11-05 03:03:07 --> Helper loaded: my_helper
INFO - 2020-11-05 03:03:07 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:03:07 --> Controller Class Initialized
DEBUG - 2020-11-05 03:03:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:03:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:03:07 --> Final output sent to browser
DEBUG - 2020-11-05 03:03:07 --> Total execution time: 0.2715
INFO - 2020-11-05 03:03:32 --> Config Class Initialized
INFO - 2020-11-05 03:03:32 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:03:32 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:03:32 --> Utf8 Class Initialized
INFO - 2020-11-05 03:03:32 --> URI Class Initialized
INFO - 2020-11-05 03:03:32 --> Router Class Initialized
INFO - 2020-11-05 03:03:32 --> Output Class Initialized
INFO - 2020-11-05 03:03:32 --> Security Class Initialized
DEBUG - 2020-11-05 03:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:03:32 --> Input Class Initialized
INFO - 2020-11-05 03:03:32 --> Language Class Initialized
INFO - 2020-11-05 03:03:32 --> Language Class Initialized
INFO - 2020-11-05 03:03:32 --> Config Class Initialized
INFO - 2020-11-05 03:03:32 --> Loader Class Initialized
INFO - 2020-11-05 03:03:32 --> Helper loaded: url_helper
INFO - 2020-11-05 03:03:32 --> Helper loaded: file_helper
INFO - 2020-11-05 03:03:32 --> Helper loaded: form_helper
INFO - 2020-11-05 03:03:32 --> Helper loaded: my_helper
INFO - 2020-11-05 03:03:32 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:03:32 --> Controller Class Initialized
INFO - 2020-11-05 03:03:32 --> Config Class Initialized
INFO - 2020-11-05 03:03:32 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:03:32 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:03:32 --> Utf8 Class Initialized
INFO - 2020-11-05 03:03:32 --> URI Class Initialized
INFO - 2020-11-05 03:03:32 --> Router Class Initialized
INFO - 2020-11-05 03:03:32 --> Output Class Initialized
INFO - 2020-11-05 03:03:32 --> Security Class Initialized
DEBUG - 2020-11-05 03:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:03:32 --> Input Class Initialized
INFO - 2020-11-05 03:03:32 --> Language Class Initialized
INFO - 2020-11-05 03:03:32 --> Language Class Initialized
INFO - 2020-11-05 03:03:32 --> Config Class Initialized
INFO - 2020-11-05 03:03:32 --> Loader Class Initialized
INFO - 2020-11-05 03:03:32 --> Helper loaded: url_helper
INFO - 2020-11-05 03:03:32 --> Helper loaded: file_helper
INFO - 2020-11-05 03:03:32 --> Helper loaded: form_helper
INFO - 2020-11-05 03:03:32 --> Helper loaded: my_helper
INFO - 2020-11-05 03:03:32 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:03:32 --> Controller Class Initialized
DEBUG - 2020-11-05 03:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:03:33 --> Final output sent to browser
DEBUG - 2020-11-05 03:03:33 --> Total execution time: 0.2672
INFO - 2020-11-05 03:03:35 --> Config Class Initialized
INFO - 2020-11-05 03:03:35 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:03:35 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:03:35 --> Utf8 Class Initialized
INFO - 2020-11-05 03:03:35 --> URI Class Initialized
INFO - 2020-11-05 03:03:35 --> Router Class Initialized
INFO - 2020-11-05 03:03:35 --> Output Class Initialized
INFO - 2020-11-05 03:03:35 --> Security Class Initialized
DEBUG - 2020-11-05 03:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:03:35 --> Input Class Initialized
INFO - 2020-11-05 03:03:35 --> Language Class Initialized
INFO - 2020-11-05 03:03:35 --> Language Class Initialized
INFO - 2020-11-05 03:03:35 --> Config Class Initialized
INFO - 2020-11-05 03:03:35 --> Loader Class Initialized
INFO - 2020-11-05 03:03:35 --> Helper loaded: url_helper
INFO - 2020-11-05 03:03:35 --> Helper loaded: file_helper
INFO - 2020-11-05 03:03:35 --> Helper loaded: form_helper
INFO - 2020-11-05 03:03:35 --> Helper loaded: my_helper
INFO - 2020-11-05 03:03:35 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:03:35 --> Controller Class Initialized
DEBUG - 2020-11-05 03:03:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:03:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:03:35 --> Final output sent to browser
DEBUG - 2020-11-05 03:03:35 --> Total execution time: 0.3336
INFO - 2020-11-05 03:04:14 --> Config Class Initialized
INFO - 2020-11-05 03:04:14 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:04:14 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:04:14 --> Utf8 Class Initialized
INFO - 2020-11-05 03:04:14 --> URI Class Initialized
INFO - 2020-11-05 03:04:14 --> Router Class Initialized
INFO - 2020-11-05 03:04:14 --> Output Class Initialized
INFO - 2020-11-05 03:04:14 --> Security Class Initialized
DEBUG - 2020-11-05 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:04:14 --> Input Class Initialized
INFO - 2020-11-05 03:04:14 --> Language Class Initialized
INFO - 2020-11-05 03:04:14 --> Language Class Initialized
INFO - 2020-11-05 03:04:14 --> Config Class Initialized
INFO - 2020-11-05 03:04:14 --> Loader Class Initialized
INFO - 2020-11-05 03:04:14 --> Helper loaded: url_helper
INFO - 2020-11-05 03:04:14 --> Helper loaded: file_helper
INFO - 2020-11-05 03:04:14 --> Helper loaded: form_helper
INFO - 2020-11-05 03:04:14 --> Helper loaded: my_helper
INFO - 2020-11-05 03:04:14 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:04:14 --> Controller Class Initialized
INFO - 2020-11-05 03:04:14 --> Config Class Initialized
INFO - 2020-11-05 03:04:14 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:04:14 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:04:14 --> Utf8 Class Initialized
INFO - 2020-11-05 03:04:14 --> URI Class Initialized
INFO - 2020-11-05 03:04:14 --> Router Class Initialized
INFO - 2020-11-05 03:04:15 --> Output Class Initialized
INFO - 2020-11-05 03:04:15 --> Security Class Initialized
DEBUG - 2020-11-05 03:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:04:15 --> Input Class Initialized
INFO - 2020-11-05 03:04:15 --> Language Class Initialized
INFO - 2020-11-05 03:04:15 --> Language Class Initialized
INFO - 2020-11-05 03:04:15 --> Config Class Initialized
INFO - 2020-11-05 03:04:15 --> Loader Class Initialized
INFO - 2020-11-05 03:04:15 --> Helper loaded: url_helper
INFO - 2020-11-05 03:04:15 --> Helper loaded: file_helper
INFO - 2020-11-05 03:04:15 --> Helper loaded: form_helper
INFO - 2020-11-05 03:04:15 --> Helper loaded: my_helper
INFO - 2020-11-05 03:04:15 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:04:15 --> Controller Class Initialized
DEBUG - 2020-11-05 03:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:04:15 --> Final output sent to browser
DEBUG - 2020-11-05 03:04:15 --> Total execution time: 0.2941
INFO - 2020-11-05 03:04:17 --> Config Class Initialized
INFO - 2020-11-05 03:04:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:04:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:04:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:04:17 --> URI Class Initialized
INFO - 2020-11-05 03:04:17 --> Router Class Initialized
INFO - 2020-11-05 03:04:17 --> Output Class Initialized
INFO - 2020-11-05 03:04:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:04:17 --> Input Class Initialized
INFO - 2020-11-05 03:04:17 --> Language Class Initialized
INFO - 2020-11-05 03:04:17 --> Language Class Initialized
INFO - 2020-11-05 03:04:17 --> Config Class Initialized
INFO - 2020-11-05 03:04:17 --> Loader Class Initialized
INFO - 2020-11-05 03:04:17 --> Helper loaded: url_helper
INFO - 2020-11-05 03:04:17 --> Helper loaded: file_helper
INFO - 2020-11-05 03:04:17 --> Helper loaded: form_helper
INFO - 2020-11-05 03:04:17 --> Helper loaded: my_helper
INFO - 2020-11-05 03:04:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:04:17 --> Controller Class Initialized
DEBUG - 2020-11-05 03:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:04:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:04:18 --> Final output sent to browser
DEBUG - 2020-11-05 03:04:18 --> Total execution time: 0.2869
INFO - 2020-11-05 03:05:14 --> Config Class Initialized
INFO - 2020-11-05 03:05:14 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:05:14 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:05:14 --> Utf8 Class Initialized
INFO - 2020-11-05 03:05:14 --> URI Class Initialized
INFO - 2020-11-05 03:05:14 --> Router Class Initialized
INFO - 2020-11-05 03:05:14 --> Output Class Initialized
INFO - 2020-11-05 03:05:14 --> Security Class Initialized
DEBUG - 2020-11-05 03:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:05:14 --> Input Class Initialized
INFO - 2020-11-05 03:05:14 --> Language Class Initialized
INFO - 2020-11-05 03:05:14 --> Language Class Initialized
INFO - 2020-11-05 03:05:14 --> Config Class Initialized
INFO - 2020-11-05 03:05:14 --> Loader Class Initialized
INFO - 2020-11-05 03:05:14 --> Helper loaded: url_helper
INFO - 2020-11-05 03:05:14 --> Helper loaded: file_helper
INFO - 2020-11-05 03:05:14 --> Helper loaded: form_helper
INFO - 2020-11-05 03:05:14 --> Helper loaded: my_helper
INFO - 2020-11-05 03:05:14 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:05:14 --> Controller Class Initialized
INFO - 2020-11-05 03:05:14 --> Config Class Initialized
INFO - 2020-11-05 03:05:14 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:05:14 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:05:14 --> Utf8 Class Initialized
INFO - 2020-11-05 03:05:14 --> URI Class Initialized
INFO - 2020-11-05 03:05:14 --> Router Class Initialized
INFO - 2020-11-05 03:05:14 --> Output Class Initialized
INFO - 2020-11-05 03:05:15 --> Security Class Initialized
DEBUG - 2020-11-05 03:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:05:15 --> Input Class Initialized
INFO - 2020-11-05 03:05:15 --> Language Class Initialized
INFO - 2020-11-05 03:05:15 --> Language Class Initialized
INFO - 2020-11-05 03:05:15 --> Config Class Initialized
INFO - 2020-11-05 03:05:15 --> Loader Class Initialized
INFO - 2020-11-05 03:05:15 --> Helper loaded: url_helper
INFO - 2020-11-05 03:05:15 --> Helper loaded: file_helper
INFO - 2020-11-05 03:05:15 --> Helper loaded: form_helper
INFO - 2020-11-05 03:05:15 --> Helper loaded: my_helper
INFO - 2020-11-05 03:05:15 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:05:15 --> Controller Class Initialized
DEBUG - 2020-11-05 03:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:05:15 --> Final output sent to browser
DEBUG - 2020-11-05 03:05:15 --> Total execution time: 0.2498
INFO - 2020-11-05 03:05:19 --> Config Class Initialized
INFO - 2020-11-05 03:05:19 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:05:19 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:05:19 --> Utf8 Class Initialized
INFO - 2020-11-05 03:05:19 --> URI Class Initialized
INFO - 2020-11-05 03:05:19 --> Router Class Initialized
INFO - 2020-11-05 03:05:19 --> Output Class Initialized
INFO - 2020-11-05 03:05:19 --> Security Class Initialized
DEBUG - 2020-11-05 03:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:05:19 --> Input Class Initialized
INFO - 2020-11-05 03:05:19 --> Language Class Initialized
INFO - 2020-11-05 03:05:19 --> Language Class Initialized
INFO - 2020-11-05 03:05:19 --> Config Class Initialized
INFO - 2020-11-05 03:05:19 --> Loader Class Initialized
INFO - 2020-11-05 03:05:19 --> Helper loaded: url_helper
INFO - 2020-11-05 03:05:19 --> Helper loaded: file_helper
INFO - 2020-11-05 03:05:19 --> Helper loaded: form_helper
INFO - 2020-11-05 03:05:19 --> Helper loaded: my_helper
INFO - 2020-11-05 03:05:19 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:05:19 --> Controller Class Initialized
DEBUG - 2020-11-05 03:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:05:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:05:19 --> Final output sent to browser
DEBUG - 2020-11-05 03:05:19 --> Total execution time: 0.3067
INFO - 2020-11-05 03:05:55 --> Config Class Initialized
INFO - 2020-11-05 03:05:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:05:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:05:55 --> Utf8 Class Initialized
INFO - 2020-11-05 03:05:55 --> URI Class Initialized
INFO - 2020-11-05 03:05:55 --> Router Class Initialized
INFO - 2020-11-05 03:05:55 --> Output Class Initialized
INFO - 2020-11-05 03:05:55 --> Security Class Initialized
DEBUG - 2020-11-05 03:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:05:55 --> Input Class Initialized
INFO - 2020-11-05 03:05:55 --> Language Class Initialized
INFO - 2020-11-05 03:05:55 --> Language Class Initialized
INFO - 2020-11-05 03:05:55 --> Config Class Initialized
INFO - 2020-11-05 03:05:55 --> Loader Class Initialized
INFO - 2020-11-05 03:05:55 --> Helper loaded: url_helper
INFO - 2020-11-05 03:05:55 --> Helper loaded: file_helper
INFO - 2020-11-05 03:05:55 --> Helper loaded: form_helper
INFO - 2020-11-05 03:05:55 --> Helper loaded: my_helper
INFO - 2020-11-05 03:05:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:05:55 --> Controller Class Initialized
INFO - 2020-11-05 03:05:55 --> Config Class Initialized
INFO - 2020-11-05 03:05:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:05:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:05:55 --> Utf8 Class Initialized
INFO - 2020-11-05 03:05:55 --> URI Class Initialized
INFO - 2020-11-05 03:05:55 --> Router Class Initialized
INFO - 2020-11-05 03:05:55 --> Output Class Initialized
INFO - 2020-11-05 03:05:55 --> Security Class Initialized
DEBUG - 2020-11-05 03:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:05:55 --> Input Class Initialized
INFO - 2020-11-05 03:05:55 --> Language Class Initialized
INFO - 2020-11-05 03:05:55 --> Language Class Initialized
INFO - 2020-11-05 03:05:55 --> Config Class Initialized
INFO - 2020-11-05 03:05:55 --> Loader Class Initialized
INFO - 2020-11-05 03:05:55 --> Helper loaded: url_helper
INFO - 2020-11-05 03:05:55 --> Helper loaded: file_helper
INFO - 2020-11-05 03:05:55 --> Helper loaded: form_helper
INFO - 2020-11-05 03:05:55 --> Helper loaded: my_helper
INFO - 2020-11-05 03:05:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:05:56 --> Controller Class Initialized
DEBUG - 2020-11-05 03:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:05:56 --> Final output sent to browser
DEBUG - 2020-11-05 03:05:56 --> Total execution time: 0.2911
INFO - 2020-11-05 03:06:01 --> Config Class Initialized
INFO - 2020-11-05 03:06:01 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:06:01 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:06:01 --> Utf8 Class Initialized
INFO - 2020-11-05 03:06:01 --> URI Class Initialized
INFO - 2020-11-05 03:06:01 --> Router Class Initialized
INFO - 2020-11-05 03:06:01 --> Output Class Initialized
INFO - 2020-11-05 03:06:01 --> Security Class Initialized
DEBUG - 2020-11-05 03:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:06:01 --> Input Class Initialized
INFO - 2020-11-05 03:06:01 --> Language Class Initialized
INFO - 2020-11-05 03:06:01 --> Language Class Initialized
INFO - 2020-11-05 03:06:01 --> Config Class Initialized
INFO - 2020-11-05 03:06:01 --> Loader Class Initialized
INFO - 2020-11-05 03:06:01 --> Helper loaded: url_helper
INFO - 2020-11-05 03:06:01 --> Helper loaded: file_helper
INFO - 2020-11-05 03:06:01 --> Helper loaded: form_helper
INFO - 2020-11-05 03:06:01 --> Helper loaded: my_helper
INFO - 2020-11-05 03:06:01 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:06:01 --> Controller Class Initialized
DEBUG - 2020-11-05 03:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:06:01 --> Final output sent to browser
DEBUG - 2020-11-05 03:06:01 --> Total execution time: 0.3025
INFO - 2020-11-05 03:06:26 --> Config Class Initialized
INFO - 2020-11-05 03:06:26 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:06:26 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:06:26 --> Utf8 Class Initialized
INFO - 2020-11-05 03:06:26 --> URI Class Initialized
INFO - 2020-11-05 03:06:26 --> Router Class Initialized
INFO - 2020-11-05 03:06:26 --> Output Class Initialized
INFO - 2020-11-05 03:06:26 --> Security Class Initialized
DEBUG - 2020-11-05 03:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:06:26 --> Input Class Initialized
INFO - 2020-11-05 03:06:26 --> Language Class Initialized
INFO - 2020-11-05 03:06:26 --> Language Class Initialized
INFO - 2020-11-05 03:06:26 --> Config Class Initialized
INFO - 2020-11-05 03:06:26 --> Loader Class Initialized
INFO - 2020-11-05 03:06:26 --> Helper loaded: url_helper
INFO - 2020-11-05 03:06:26 --> Helper loaded: file_helper
INFO - 2020-11-05 03:06:26 --> Helper loaded: form_helper
INFO - 2020-11-05 03:06:26 --> Helper loaded: my_helper
INFO - 2020-11-05 03:06:26 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:06:26 --> Controller Class Initialized
INFO - 2020-11-05 03:06:26 --> Config Class Initialized
INFO - 2020-11-05 03:06:26 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:06:26 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:06:26 --> Utf8 Class Initialized
INFO - 2020-11-05 03:06:26 --> URI Class Initialized
INFO - 2020-11-05 03:06:26 --> Router Class Initialized
INFO - 2020-11-05 03:06:26 --> Output Class Initialized
INFO - 2020-11-05 03:06:26 --> Security Class Initialized
DEBUG - 2020-11-05 03:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:06:26 --> Input Class Initialized
INFO - 2020-11-05 03:06:26 --> Language Class Initialized
INFO - 2020-11-05 03:06:26 --> Language Class Initialized
INFO - 2020-11-05 03:06:26 --> Config Class Initialized
INFO - 2020-11-05 03:06:26 --> Loader Class Initialized
INFO - 2020-11-05 03:06:26 --> Helper loaded: url_helper
INFO - 2020-11-05 03:06:26 --> Helper loaded: file_helper
INFO - 2020-11-05 03:06:26 --> Helper loaded: form_helper
INFO - 2020-11-05 03:06:26 --> Helper loaded: my_helper
INFO - 2020-11-05 03:06:26 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:06:27 --> Controller Class Initialized
DEBUG - 2020-11-05 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:06:27 --> Final output sent to browser
DEBUG - 2020-11-05 03:06:27 --> Total execution time: 0.2913
INFO - 2020-11-05 03:06:32 --> Config Class Initialized
INFO - 2020-11-05 03:06:32 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:06:32 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:06:32 --> Utf8 Class Initialized
INFO - 2020-11-05 03:06:32 --> URI Class Initialized
INFO - 2020-11-05 03:06:32 --> Router Class Initialized
INFO - 2020-11-05 03:06:32 --> Output Class Initialized
INFO - 2020-11-05 03:06:32 --> Security Class Initialized
DEBUG - 2020-11-05 03:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:06:32 --> Input Class Initialized
INFO - 2020-11-05 03:06:32 --> Language Class Initialized
INFO - 2020-11-05 03:06:32 --> Language Class Initialized
INFO - 2020-11-05 03:06:32 --> Config Class Initialized
INFO - 2020-11-05 03:06:32 --> Loader Class Initialized
INFO - 2020-11-05 03:06:32 --> Helper loaded: url_helper
INFO - 2020-11-05 03:06:32 --> Helper loaded: file_helper
INFO - 2020-11-05 03:06:32 --> Helper loaded: form_helper
INFO - 2020-11-05 03:06:32 --> Helper loaded: my_helper
INFO - 2020-11-05 03:06:32 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:06:32 --> Controller Class Initialized
DEBUG - 2020-11-05 03:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:06:32 --> Final output sent to browser
DEBUG - 2020-11-05 03:06:32 --> Total execution time: 0.3301
INFO - 2020-11-05 03:07:21 --> Config Class Initialized
INFO - 2020-11-05 03:07:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:07:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:07:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:07:21 --> URI Class Initialized
INFO - 2020-11-05 03:07:21 --> Router Class Initialized
INFO - 2020-11-05 03:07:21 --> Output Class Initialized
INFO - 2020-11-05 03:07:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:07:21 --> Input Class Initialized
INFO - 2020-11-05 03:07:21 --> Language Class Initialized
INFO - 2020-11-05 03:07:21 --> Language Class Initialized
INFO - 2020-11-05 03:07:21 --> Config Class Initialized
INFO - 2020-11-05 03:07:21 --> Loader Class Initialized
INFO - 2020-11-05 03:07:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:07:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:07:22 --> Helper loaded: form_helper
INFO - 2020-11-05 03:07:22 --> Helper loaded: my_helper
INFO - 2020-11-05 03:07:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:07:22 --> Controller Class Initialized
INFO - 2020-11-05 03:07:22 --> Config Class Initialized
INFO - 2020-11-05 03:07:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:07:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:07:22 --> Utf8 Class Initialized
INFO - 2020-11-05 03:07:22 --> URI Class Initialized
INFO - 2020-11-05 03:07:22 --> Router Class Initialized
INFO - 2020-11-05 03:07:22 --> Output Class Initialized
INFO - 2020-11-05 03:07:22 --> Security Class Initialized
DEBUG - 2020-11-05 03:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:07:22 --> Input Class Initialized
INFO - 2020-11-05 03:07:22 --> Language Class Initialized
INFO - 2020-11-05 03:07:22 --> Language Class Initialized
INFO - 2020-11-05 03:07:22 --> Config Class Initialized
INFO - 2020-11-05 03:07:22 --> Loader Class Initialized
INFO - 2020-11-05 03:07:22 --> Helper loaded: url_helper
INFO - 2020-11-05 03:07:22 --> Helper loaded: file_helper
INFO - 2020-11-05 03:07:22 --> Helper loaded: form_helper
INFO - 2020-11-05 03:07:22 --> Helper loaded: my_helper
INFO - 2020-11-05 03:07:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:07:22 --> Controller Class Initialized
DEBUG - 2020-11-05 03:07:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:07:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:07:22 --> Final output sent to browser
DEBUG - 2020-11-05 03:07:22 --> Total execution time: 0.2565
INFO - 2020-11-05 03:07:30 --> Config Class Initialized
INFO - 2020-11-05 03:07:30 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:07:30 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:07:30 --> Utf8 Class Initialized
INFO - 2020-11-05 03:07:30 --> URI Class Initialized
INFO - 2020-11-05 03:07:30 --> Router Class Initialized
INFO - 2020-11-05 03:07:30 --> Output Class Initialized
INFO - 2020-11-05 03:07:30 --> Security Class Initialized
DEBUG - 2020-11-05 03:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:07:30 --> Input Class Initialized
INFO - 2020-11-05 03:07:30 --> Language Class Initialized
INFO - 2020-11-05 03:07:30 --> Language Class Initialized
INFO - 2020-11-05 03:07:30 --> Config Class Initialized
INFO - 2020-11-05 03:07:30 --> Loader Class Initialized
INFO - 2020-11-05 03:07:30 --> Helper loaded: url_helper
INFO - 2020-11-05 03:07:30 --> Helper loaded: file_helper
INFO - 2020-11-05 03:07:30 --> Helper loaded: form_helper
INFO - 2020-11-05 03:07:30 --> Helper loaded: my_helper
INFO - 2020-11-05 03:07:30 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:07:30 --> Controller Class Initialized
DEBUG - 2020-11-05 03:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:07:30 --> Final output sent to browser
DEBUG - 2020-11-05 03:07:30 --> Total execution time: 0.2965
INFO - 2020-11-05 03:07:48 --> Config Class Initialized
INFO - 2020-11-05 03:07:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:07:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:07:48 --> Utf8 Class Initialized
INFO - 2020-11-05 03:07:48 --> URI Class Initialized
INFO - 2020-11-05 03:07:48 --> Router Class Initialized
INFO - 2020-11-05 03:07:48 --> Output Class Initialized
INFO - 2020-11-05 03:07:48 --> Security Class Initialized
DEBUG - 2020-11-05 03:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:07:48 --> Input Class Initialized
INFO - 2020-11-05 03:07:48 --> Language Class Initialized
INFO - 2020-11-05 03:07:48 --> Language Class Initialized
INFO - 2020-11-05 03:07:48 --> Config Class Initialized
INFO - 2020-11-05 03:07:48 --> Loader Class Initialized
INFO - 2020-11-05 03:07:48 --> Helper loaded: url_helper
INFO - 2020-11-05 03:07:48 --> Helper loaded: file_helper
INFO - 2020-11-05 03:07:48 --> Helper loaded: form_helper
INFO - 2020-11-05 03:07:48 --> Helper loaded: my_helper
INFO - 2020-11-05 03:07:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:07:48 --> Controller Class Initialized
INFO - 2020-11-05 03:07:48 --> Config Class Initialized
INFO - 2020-11-05 03:07:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:07:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:07:48 --> Utf8 Class Initialized
INFO - 2020-11-05 03:07:48 --> URI Class Initialized
INFO - 2020-11-05 03:07:48 --> Router Class Initialized
INFO - 2020-11-05 03:07:48 --> Output Class Initialized
INFO - 2020-11-05 03:07:48 --> Security Class Initialized
DEBUG - 2020-11-05 03:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:07:48 --> Input Class Initialized
INFO - 2020-11-05 03:07:48 --> Language Class Initialized
INFO - 2020-11-05 03:07:48 --> Language Class Initialized
INFO - 2020-11-05 03:07:48 --> Config Class Initialized
INFO - 2020-11-05 03:07:48 --> Loader Class Initialized
INFO - 2020-11-05 03:07:48 --> Helper loaded: url_helper
INFO - 2020-11-05 03:07:48 --> Helper loaded: file_helper
INFO - 2020-11-05 03:07:48 --> Helper loaded: form_helper
INFO - 2020-11-05 03:07:48 --> Helper loaded: my_helper
INFO - 2020-11-05 03:07:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:07:48 --> Controller Class Initialized
DEBUG - 2020-11-05 03:07:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:07:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:07:48 --> Final output sent to browser
DEBUG - 2020-11-05 03:07:48 --> Total execution time: 0.3103
INFO - 2020-11-05 03:07:53 --> Config Class Initialized
INFO - 2020-11-05 03:07:53 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:07:53 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:07:53 --> Utf8 Class Initialized
INFO - 2020-11-05 03:07:53 --> URI Class Initialized
INFO - 2020-11-05 03:07:53 --> Router Class Initialized
INFO - 2020-11-05 03:07:53 --> Output Class Initialized
INFO - 2020-11-05 03:07:53 --> Security Class Initialized
DEBUG - 2020-11-05 03:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:07:53 --> Input Class Initialized
INFO - 2020-11-05 03:07:53 --> Language Class Initialized
INFO - 2020-11-05 03:07:53 --> Language Class Initialized
INFO - 2020-11-05 03:07:53 --> Config Class Initialized
INFO - 2020-11-05 03:07:53 --> Loader Class Initialized
INFO - 2020-11-05 03:07:53 --> Helper loaded: url_helper
INFO - 2020-11-05 03:07:53 --> Helper loaded: file_helper
INFO - 2020-11-05 03:07:53 --> Helper loaded: form_helper
INFO - 2020-11-05 03:07:53 --> Helper loaded: my_helper
INFO - 2020-11-05 03:07:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:07:53 --> Controller Class Initialized
DEBUG - 2020-11-05 03:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:07:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:07:53 --> Final output sent to browser
DEBUG - 2020-11-05 03:07:53 --> Total execution time: 0.3033
INFO - 2020-11-05 03:08:27 --> Config Class Initialized
INFO - 2020-11-05 03:08:27 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:08:27 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:08:27 --> Utf8 Class Initialized
INFO - 2020-11-05 03:08:27 --> URI Class Initialized
INFO - 2020-11-05 03:08:27 --> Router Class Initialized
INFO - 2020-11-05 03:08:27 --> Output Class Initialized
INFO - 2020-11-05 03:08:27 --> Security Class Initialized
DEBUG - 2020-11-05 03:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:08:27 --> Input Class Initialized
INFO - 2020-11-05 03:08:27 --> Language Class Initialized
INFO - 2020-11-05 03:08:27 --> Language Class Initialized
INFO - 2020-11-05 03:08:27 --> Config Class Initialized
INFO - 2020-11-05 03:08:27 --> Loader Class Initialized
INFO - 2020-11-05 03:08:27 --> Helper loaded: url_helper
INFO - 2020-11-05 03:08:28 --> Helper loaded: file_helper
INFO - 2020-11-05 03:08:28 --> Helper loaded: form_helper
INFO - 2020-11-05 03:08:28 --> Helper loaded: my_helper
INFO - 2020-11-05 03:08:28 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:08:28 --> Controller Class Initialized
INFO - 2020-11-05 03:08:28 --> Config Class Initialized
INFO - 2020-11-05 03:08:28 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:08:28 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:08:28 --> Utf8 Class Initialized
INFO - 2020-11-05 03:08:28 --> URI Class Initialized
INFO - 2020-11-05 03:08:28 --> Router Class Initialized
INFO - 2020-11-05 03:08:28 --> Output Class Initialized
INFO - 2020-11-05 03:08:28 --> Security Class Initialized
DEBUG - 2020-11-05 03:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:08:28 --> Input Class Initialized
INFO - 2020-11-05 03:08:28 --> Language Class Initialized
INFO - 2020-11-05 03:08:28 --> Language Class Initialized
INFO - 2020-11-05 03:08:28 --> Config Class Initialized
INFO - 2020-11-05 03:08:28 --> Loader Class Initialized
INFO - 2020-11-05 03:08:28 --> Helper loaded: url_helper
INFO - 2020-11-05 03:08:28 --> Helper loaded: file_helper
INFO - 2020-11-05 03:08:28 --> Helper loaded: form_helper
INFO - 2020-11-05 03:08:28 --> Helper loaded: my_helper
INFO - 2020-11-05 03:08:28 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:08:28 --> Controller Class Initialized
DEBUG - 2020-11-05 03:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:08:28 --> Final output sent to browser
DEBUG - 2020-11-05 03:08:28 --> Total execution time: 0.2786
INFO - 2020-11-05 03:08:44 --> Config Class Initialized
INFO - 2020-11-05 03:08:44 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:08:44 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:08:44 --> Utf8 Class Initialized
INFO - 2020-11-05 03:08:44 --> URI Class Initialized
INFO - 2020-11-05 03:08:44 --> Router Class Initialized
INFO - 2020-11-05 03:08:44 --> Output Class Initialized
INFO - 2020-11-05 03:08:44 --> Security Class Initialized
DEBUG - 2020-11-05 03:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:08:44 --> Input Class Initialized
INFO - 2020-11-05 03:08:44 --> Language Class Initialized
INFO - 2020-11-05 03:08:44 --> Language Class Initialized
INFO - 2020-11-05 03:08:44 --> Config Class Initialized
INFO - 2020-11-05 03:08:44 --> Loader Class Initialized
INFO - 2020-11-05 03:08:44 --> Helper loaded: url_helper
INFO - 2020-11-05 03:08:44 --> Helper loaded: file_helper
INFO - 2020-11-05 03:08:44 --> Helper loaded: form_helper
INFO - 2020-11-05 03:08:44 --> Helper loaded: my_helper
INFO - 2020-11-05 03:08:44 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:08:44 --> Controller Class Initialized
DEBUG - 2020-11-05 03:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:08:44 --> Final output sent to browser
DEBUG - 2020-11-05 03:08:44 --> Total execution time: 0.3525
INFO - 2020-11-05 03:09:27 --> Config Class Initialized
INFO - 2020-11-05 03:09:27 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:09:27 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:09:27 --> Utf8 Class Initialized
INFO - 2020-11-05 03:09:27 --> URI Class Initialized
INFO - 2020-11-05 03:09:27 --> Router Class Initialized
INFO - 2020-11-05 03:09:27 --> Output Class Initialized
INFO - 2020-11-05 03:09:27 --> Security Class Initialized
DEBUG - 2020-11-05 03:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:09:27 --> Input Class Initialized
INFO - 2020-11-05 03:09:27 --> Language Class Initialized
INFO - 2020-11-05 03:09:27 --> Language Class Initialized
INFO - 2020-11-05 03:09:27 --> Config Class Initialized
INFO - 2020-11-05 03:09:27 --> Loader Class Initialized
INFO - 2020-11-05 03:09:27 --> Helper loaded: url_helper
INFO - 2020-11-05 03:09:27 --> Helper loaded: file_helper
INFO - 2020-11-05 03:09:27 --> Helper loaded: form_helper
INFO - 2020-11-05 03:09:27 --> Helper loaded: my_helper
INFO - 2020-11-05 03:09:27 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:09:27 --> Controller Class Initialized
INFO - 2020-11-05 03:09:27 --> Config Class Initialized
INFO - 2020-11-05 03:09:27 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:09:27 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:09:27 --> Utf8 Class Initialized
INFO - 2020-11-05 03:09:27 --> URI Class Initialized
INFO - 2020-11-05 03:09:27 --> Router Class Initialized
INFO - 2020-11-05 03:09:27 --> Output Class Initialized
INFO - 2020-11-05 03:09:27 --> Security Class Initialized
DEBUG - 2020-11-05 03:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:09:27 --> Input Class Initialized
INFO - 2020-11-05 03:09:27 --> Language Class Initialized
INFO - 2020-11-05 03:09:27 --> Language Class Initialized
INFO - 2020-11-05 03:09:27 --> Config Class Initialized
INFO - 2020-11-05 03:09:27 --> Loader Class Initialized
INFO - 2020-11-05 03:09:27 --> Helper loaded: url_helper
INFO - 2020-11-05 03:09:27 --> Helper loaded: file_helper
INFO - 2020-11-05 03:09:27 --> Helper loaded: form_helper
INFO - 2020-11-05 03:09:27 --> Helper loaded: my_helper
INFO - 2020-11-05 03:09:27 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:09:27 --> Controller Class Initialized
DEBUG - 2020-11-05 03:09:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:09:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:09:27 --> Final output sent to browser
DEBUG - 2020-11-05 03:09:27 --> Total execution time: 0.3021
INFO - 2020-11-05 03:09:29 --> Config Class Initialized
INFO - 2020-11-05 03:09:29 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:09:29 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:09:29 --> Utf8 Class Initialized
INFO - 2020-11-05 03:09:29 --> URI Class Initialized
INFO - 2020-11-05 03:09:29 --> Router Class Initialized
INFO - 2020-11-05 03:09:29 --> Output Class Initialized
INFO - 2020-11-05 03:09:29 --> Security Class Initialized
DEBUG - 2020-11-05 03:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:09:29 --> Input Class Initialized
INFO - 2020-11-05 03:09:29 --> Language Class Initialized
INFO - 2020-11-05 03:09:29 --> Language Class Initialized
INFO - 2020-11-05 03:09:29 --> Config Class Initialized
INFO - 2020-11-05 03:09:29 --> Loader Class Initialized
INFO - 2020-11-05 03:09:29 --> Helper loaded: url_helper
INFO - 2020-11-05 03:09:29 --> Helper loaded: file_helper
INFO - 2020-11-05 03:09:29 --> Helper loaded: form_helper
INFO - 2020-11-05 03:09:29 --> Helper loaded: my_helper
INFO - 2020-11-05 03:09:29 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:09:29 --> Controller Class Initialized
DEBUG - 2020-11-05 03:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:09:29 --> Final output sent to browser
DEBUG - 2020-11-05 03:09:29 --> Total execution time: 0.3189
INFO - 2020-11-05 03:10:03 --> Config Class Initialized
INFO - 2020-11-05 03:10:03 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:03 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:03 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:03 --> URI Class Initialized
INFO - 2020-11-05 03:10:03 --> Router Class Initialized
INFO - 2020-11-05 03:10:03 --> Output Class Initialized
INFO - 2020-11-05 03:10:03 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:03 --> Input Class Initialized
INFO - 2020-11-05 03:10:03 --> Language Class Initialized
INFO - 2020-11-05 03:10:03 --> Language Class Initialized
INFO - 2020-11-05 03:10:03 --> Config Class Initialized
INFO - 2020-11-05 03:10:03 --> Loader Class Initialized
INFO - 2020-11-05 03:10:03 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:03 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:03 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:03 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:03 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:03 --> Controller Class Initialized
INFO - 2020-11-05 03:10:03 --> Config Class Initialized
INFO - 2020-11-05 03:10:03 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:03 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:03 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:03 --> URI Class Initialized
INFO - 2020-11-05 03:10:03 --> Router Class Initialized
INFO - 2020-11-05 03:10:03 --> Output Class Initialized
INFO - 2020-11-05 03:10:03 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:03 --> Input Class Initialized
INFO - 2020-11-05 03:10:03 --> Language Class Initialized
INFO - 2020-11-05 03:10:03 --> Language Class Initialized
INFO - 2020-11-05 03:10:03 --> Config Class Initialized
INFO - 2020-11-05 03:10:03 --> Loader Class Initialized
INFO - 2020-11-05 03:10:03 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:04 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:04 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:04 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:04 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:04 --> Controller Class Initialized
DEBUG - 2020-11-05 03:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:10:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:10:04 --> Final output sent to browser
DEBUG - 2020-11-05 03:10:04 --> Total execution time: 0.2749
INFO - 2020-11-05 03:10:05 --> Config Class Initialized
INFO - 2020-11-05 03:10:05 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:05 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:05 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:05 --> URI Class Initialized
INFO - 2020-11-05 03:10:05 --> Router Class Initialized
INFO - 2020-11-05 03:10:05 --> Output Class Initialized
INFO - 2020-11-05 03:10:05 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:05 --> Input Class Initialized
INFO - 2020-11-05 03:10:05 --> Language Class Initialized
INFO - 2020-11-05 03:10:05 --> Language Class Initialized
INFO - 2020-11-05 03:10:05 --> Config Class Initialized
INFO - 2020-11-05 03:10:05 --> Loader Class Initialized
INFO - 2020-11-05 03:10:05 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:05 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:05 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:05 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:05 --> Controller Class Initialized
DEBUG - 2020-11-05 03:10:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:10:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:10:05 --> Final output sent to browser
DEBUG - 2020-11-05 03:10:05 --> Total execution time: 0.3004
INFO - 2020-11-05 03:10:31 --> Config Class Initialized
INFO - 2020-11-05 03:10:31 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:31 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:31 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:31 --> URI Class Initialized
INFO - 2020-11-05 03:10:31 --> Router Class Initialized
INFO - 2020-11-05 03:10:31 --> Output Class Initialized
INFO - 2020-11-05 03:10:31 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:31 --> Input Class Initialized
INFO - 2020-11-05 03:10:31 --> Language Class Initialized
INFO - 2020-11-05 03:10:31 --> Language Class Initialized
INFO - 2020-11-05 03:10:31 --> Config Class Initialized
INFO - 2020-11-05 03:10:31 --> Loader Class Initialized
INFO - 2020-11-05 03:10:31 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:31 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:31 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:31 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:31 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:31 --> Controller Class Initialized
INFO - 2020-11-05 03:10:31 --> Config Class Initialized
INFO - 2020-11-05 03:10:31 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:31 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:31 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:31 --> URI Class Initialized
INFO - 2020-11-05 03:10:31 --> Router Class Initialized
INFO - 2020-11-05 03:10:31 --> Output Class Initialized
INFO - 2020-11-05 03:10:31 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:31 --> Input Class Initialized
INFO - 2020-11-05 03:10:31 --> Language Class Initialized
INFO - 2020-11-05 03:10:31 --> Language Class Initialized
INFO - 2020-11-05 03:10:31 --> Config Class Initialized
INFO - 2020-11-05 03:10:31 --> Loader Class Initialized
INFO - 2020-11-05 03:10:31 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:31 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:31 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:31 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:31 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:31 --> Controller Class Initialized
DEBUG - 2020-11-05 03:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:10:31 --> Final output sent to browser
DEBUG - 2020-11-05 03:10:31 --> Total execution time: 0.2553
INFO - 2020-11-05 03:10:38 --> Config Class Initialized
INFO - 2020-11-05 03:10:38 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:38 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:38 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:38 --> URI Class Initialized
INFO - 2020-11-05 03:10:38 --> Router Class Initialized
INFO - 2020-11-05 03:10:38 --> Output Class Initialized
INFO - 2020-11-05 03:10:38 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:38 --> Input Class Initialized
INFO - 2020-11-05 03:10:38 --> Language Class Initialized
INFO - 2020-11-05 03:10:38 --> Language Class Initialized
INFO - 2020-11-05 03:10:38 --> Config Class Initialized
INFO - 2020-11-05 03:10:38 --> Loader Class Initialized
INFO - 2020-11-05 03:10:38 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:38 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:38 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:38 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:38 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:38 --> Controller Class Initialized
DEBUG - 2020-11-05 03:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:10:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:10:38 --> Final output sent to browser
DEBUG - 2020-11-05 03:10:38 --> Total execution time: 0.2982
INFO - 2020-11-05 03:10:49 --> Config Class Initialized
INFO - 2020-11-05 03:10:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:49 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:49 --> URI Class Initialized
INFO - 2020-11-05 03:10:49 --> Router Class Initialized
INFO - 2020-11-05 03:10:49 --> Output Class Initialized
INFO - 2020-11-05 03:10:49 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:50 --> Input Class Initialized
INFO - 2020-11-05 03:10:50 --> Language Class Initialized
INFO - 2020-11-05 03:10:50 --> Language Class Initialized
INFO - 2020-11-05 03:10:50 --> Config Class Initialized
INFO - 2020-11-05 03:10:50 --> Loader Class Initialized
INFO - 2020-11-05 03:10:50 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:50 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:50 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:50 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:50 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:50 --> Controller Class Initialized
DEBUG - 2020-11-05 03:10:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:10:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:10:50 --> Final output sent to browser
DEBUG - 2020-11-05 03:10:50 --> Total execution time: 0.3504
INFO - 2020-11-05 03:10:55 --> Config Class Initialized
INFO - 2020-11-05 03:10:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:10:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:10:55 --> Utf8 Class Initialized
INFO - 2020-11-05 03:10:55 --> URI Class Initialized
INFO - 2020-11-05 03:10:55 --> Router Class Initialized
INFO - 2020-11-05 03:10:55 --> Output Class Initialized
INFO - 2020-11-05 03:10:55 --> Security Class Initialized
DEBUG - 2020-11-05 03:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:10:55 --> Input Class Initialized
INFO - 2020-11-05 03:10:55 --> Language Class Initialized
INFO - 2020-11-05 03:10:55 --> Language Class Initialized
INFO - 2020-11-05 03:10:55 --> Config Class Initialized
INFO - 2020-11-05 03:10:55 --> Loader Class Initialized
INFO - 2020-11-05 03:10:55 --> Helper loaded: url_helper
INFO - 2020-11-05 03:10:55 --> Helper loaded: file_helper
INFO - 2020-11-05 03:10:55 --> Helper loaded: form_helper
INFO - 2020-11-05 03:10:55 --> Helper loaded: my_helper
INFO - 2020-11-05 03:10:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:10:55 --> Controller Class Initialized
DEBUG - 2020-11-05 03:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:10:55 --> Final output sent to browser
DEBUG - 2020-11-05 03:10:55 --> Total execution time: 0.2858
INFO - 2020-11-05 03:11:21 --> Config Class Initialized
INFO - 2020-11-05 03:11:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:11:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:11:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:11:21 --> URI Class Initialized
INFO - 2020-11-05 03:11:21 --> Router Class Initialized
INFO - 2020-11-05 03:11:21 --> Output Class Initialized
INFO - 2020-11-05 03:11:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:11:21 --> Input Class Initialized
INFO - 2020-11-05 03:11:21 --> Language Class Initialized
INFO - 2020-11-05 03:11:21 --> Language Class Initialized
INFO - 2020-11-05 03:11:21 --> Config Class Initialized
INFO - 2020-11-05 03:11:21 --> Loader Class Initialized
INFO - 2020-11-05 03:11:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:11:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:11:21 --> Helper loaded: form_helper
INFO - 2020-11-05 03:11:21 --> Helper loaded: my_helper
INFO - 2020-11-05 03:11:21 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:11:21 --> Controller Class Initialized
INFO - 2020-11-05 03:11:21 --> Config Class Initialized
INFO - 2020-11-05 03:11:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:11:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:11:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:11:21 --> URI Class Initialized
INFO - 2020-11-05 03:11:21 --> Router Class Initialized
INFO - 2020-11-05 03:11:21 --> Output Class Initialized
INFO - 2020-11-05 03:11:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:11:21 --> Input Class Initialized
INFO - 2020-11-05 03:11:21 --> Language Class Initialized
INFO - 2020-11-05 03:11:21 --> Language Class Initialized
INFO - 2020-11-05 03:11:21 --> Config Class Initialized
INFO - 2020-11-05 03:11:21 --> Loader Class Initialized
INFO - 2020-11-05 03:11:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:11:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:11:21 --> Helper loaded: form_helper
INFO - 2020-11-05 03:11:21 --> Helper loaded: my_helper
INFO - 2020-11-05 03:11:21 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:11:21 --> Controller Class Initialized
DEBUG - 2020-11-05 03:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:11:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:11:21 --> Final output sent to browser
DEBUG - 2020-11-05 03:11:21 --> Total execution time: 0.2788
INFO - 2020-11-05 03:11:23 --> Config Class Initialized
INFO - 2020-11-05 03:11:23 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:11:23 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:11:23 --> Utf8 Class Initialized
INFO - 2020-11-05 03:11:23 --> URI Class Initialized
INFO - 2020-11-05 03:11:23 --> Router Class Initialized
INFO - 2020-11-05 03:11:23 --> Output Class Initialized
INFO - 2020-11-05 03:11:23 --> Security Class Initialized
DEBUG - 2020-11-05 03:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:11:23 --> Input Class Initialized
INFO - 2020-11-05 03:11:23 --> Language Class Initialized
INFO - 2020-11-05 03:11:23 --> Language Class Initialized
INFO - 2020-11-05 03:11:23 --> Config Class Initialized
INFO - 2020-11-05 03:11:23 --> Loader Class Initialized
INFO - 2020-11-05 03:11:23 --> Helper loaded: url_helper
INFO - 2020-11-05 03:11:23 --> Helper loaded: file_helper
INFO - 2020-11-05 03:11:23 --> Helper loaded: form_helper
INFO - 2020-11-05 03:11:23 --> Helper loaded: my_helper
INFO - 2020-11-05 03:11:23 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:11:23 --> Controller Class Initialized
DEBUG - 2020-11-05 03:11:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:11:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:11:23 --> Final output sent to browser
DEBUG - 2020-11-05 03:11:23 --> Total execution time: 0.3199
INFO - 2020-11-05 03:11:49 --> Config Class Initialized
INFO - 2020-11-05 03:11:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:11:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:11:49 --> Utf8 Class Initialized
INFO - 2020-11-05 03:11:49 --> URI Class Initialized
INFO - 2020-11-05 03:11:49 --> Router Class Initialized
INFO - 2020-11-05 03:11:49 --> Output Class Initialized
INFO - 2020-11-05 03:11:49 --> Security Class Initialized
DEBUG - 2020-11-05 03:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:11:49 --> Input Class Initialized
INFO - 2020-11-05 03:11:49 --> Language Class Initialized
INFO - 2020-11-05 03:11:49 --> Language Class Initialized
INFO - 2020-11-05 03:11:49 --> Config Class Initialized
INFO - 2020-11-05 03:11:49 --> Loader Class Initialized
INFO - 2020-11-05 03:11:49 --> Helper loaded: url_helper
INFO - 2020-11-05 03:11:49 --> Helper loaded: file_helper
INFO - 2020-11-05 03:11:49 --> Helper loaded: form_helper
INFO - 2020-11-05 03:11:49 --> Helper loaded: my_helper
INFO - 2020-11-05 03:11:49 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:11:49 --> Controller Class Initialized
INFO - 2020-11-05 03:11:49 --> Config Class Initialized
INFO - 2020-11-05 03:11:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:11:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:11:49 --> Utf8 Class Initialized
INFO - 2020-11-05 03:11:49 --> URI Class Initialized
INFO - 2020-11-05 03:11:49 --> Router Class Initialized
INFO - 2020-11-05 03:11:49 --> Output Class Initialized
INFO - 2020-11-05 03:11:49 --> Security Class Initialized
DEBUG - 2020-11-05 03:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:11:49 --> Input Class Initialized
INFO - 2020-11-05 03:11:49 --> Language Class Initialized
INFO - 2020-11-05 03:11:49 --> Language Class Initialized
INFO - 2020-11-05 03:11:49 --> Config Class Initialized
INFO - 2020-11-05 03:11:49 --> Loader Class Initialized
INFO - 2020-11-05 03:11:49 --> Helper loaded: url_helper
INFO - 2020-11-05 03:11:49 --> Helper loaded: file_helper
INFO - 2020-11-05 03:11:49 --> Helper loaded: form_helper
INFO - 2020-11-05 03:11:49 --> Helper loaded: my_helper
INFO - 2020-11-05 03:11:49 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:11:49 --> Controller Class Initialized
DEBUG - 2020-11-05 03:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:11:49 --> Final output sent to browser
DEBUG - 2020-11-05 03:11:50 --> Total execution time: 0.2779
INFO - 2020-11-05 03:11:51 --> Config Class Initialized
INFO - 2020-11-05 03:11:51 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:11:51 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:11:51 --> Utf8 Class Initialized
INFO - 2020-11-05 03:11:51 --> URI Class Initialized
INFO - 2020-11-05 03:11:51 --> Router Class Initialized
INFO - 2020-11-05 03:11:51 --> Output Class Initialized
INFO - 2020-11-05 03:11:51 --> Security Class Initialized
DEBUG - 2020-11-05 03:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:11:51 --> Input Class Initialized
INFO - 2020-11-05 03:11:51 --> Language Class Initialized
INFO - 2020-11-05 03:11:51 --> Language Class Initialized
INFO - 2020-11-05 03:11:51 --> Config Class Initialized
INFO - 2020-11-05 03:11:51 --> Loader Class Initialized
INFO - 2020-11-05 03:11:51 --> Helper loaded: url_helper
INFO - 2020-11-05 03:11:51 --> Helper loaded: file_helper
INFO - 2020-11-05 03:11:51 --> Helper loaded: form_helper
INFO - 2020-11-05 03:11:51 --> Helper loaded: my_helper
INFO - 2020-11-05 03:11:51 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:11:51 --> Controller Class Initialized
DEBUG - 2020-11-05 03:11:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:11:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:11:51 --> Final output sent to browser
DEBUG - 2020-11-05 03:11:51 --> Total execution time: 0.3384
INFO - 2020-11-05 03:12:19 --> Config Class Initialized
INFO - 2020-11-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:12:19 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:12:19 --> Utf8 Class Initialized
INFO - 2020-11-05 03:12:19 --> URI Class Initialized
INFO - 2020-11-05 03:12:19 --> Router Class Initialized
INFO - 2020-11-05 03:12:19 --> Output Class Initialized
INFO - 2020-11-05 03:12:19 --> Security Class Initialized
DEBUG - 2020-11-05 03:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:12:19 --> Input Class Initialized
INFO - 2020-11-05 03:12:19 --> Language Class Initialized
INFO - 2020-11-05 03:12:19 --> Language Class Initialized
INFO - 2020-11-05 03:12:19 --> Config Class Initialized
INFO - 2020-11-05 03:12:19 --> Loader Class Initialized
INFO - 2020-11-05 03:12:19 --> Helper loaded: url_helper
INFO - 2020-11-05 03:12:19 --> Helper loaded: file_helper
INFO - 2020-11-05 03:12:19 --> Helper loaded: form_helper
INFO - 2020-11-05 03:12:19 --> Helper loaded: my_helper
INFO - 2020-11-05 03:12:19 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:12:19 --> Controller Class Initialized
INFO - 2020-11-05 03:12:19 --> Config Class Initialized
INFO - 2020-11-05 03:12:19 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:12:19 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:12:19 --> Utf8 Class Initialized
INFO - 2020-11-05 03:12:19 --> URI Class Initialized
INFO - 2020-11-05 03:12:19 --> Router Class Initialized
INFO - 2020-11-05 03:12:19 --> Output Class Initialized
INFO - 2020-11-05 03:12:19 --> Security Class Initialized
DEBUG - 2020-11-05 03:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:12:20 --> Input Class Initialized
INFO - 2020-11-05 03:12:20 --> Language Class Initialized
INFO - 2020-11-05 03:12:20 --> Language Class Initialized
INFO - 2020-11-05 03:12:20 --> Config Class Initialized
INFO - 2020-11-05 03:12:20 --> Loader Class Initialized
INFO - 2020-11-05 03:12:20 --> Helper loaded: url_helper
INFO - 2020-11-05 03:12:20 --> Helper loaded: file_helper
INFO - 2020-11-05 03:12:20 --> Helper loaded: form_helper
INFO - 2020-11-05 03:12:20 --> Helper loaded: my_helper
INFO - 2020-11-05 03:12:20 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:12:20 --> Controller Class Initialized
DEBUG - 2020-11-05 03:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:12:20 --> Final output sent to browser
DEBUG - 2020-11-05 03:12:20 --> Total execution time: 0.2760
INFO - 2020-11-05 03:12:21 --> Config Class Initialized
INFO - 2020-11-05 03:12:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:12:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:12:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:12:21 --> URI Class Initialized
INFO - 2020-11-05 03:12:21 --> Router Class Initialized
INFO - 2020-11-05 03:12:21 --> Output Class Initialized
INFO - 2020-11-05 03:12:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:12:21 --> Input Class Initialized
INFO - 2020-11-05 03:12:21 --> Language Class Initialized
INFO - 2020-11-05 03:12:21 --> Language Class Initialized
INFO - 2020-11-05 03:12:21 --> Config Class Initialized
INFO - 2020-11-05 03:12:21 --> Loader Class Initialized
INFO - 2020-11-05 03:12:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:12:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:12:21 --> Helper loaded: form_helper
INFO - 2020-11-05 03:12:21 --> Helper loaded: my_helper
INFO - 2020-11-05 03:12:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:12:22 --> Controller Class Initialized
DEBUG - 2020-11-05 03:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:12:22 --> Final output sent to browser
DEBUG - 2020-11-05 03:12:22 --> Total execution time: 0.3158
INFO - 2020-11-05 03:12:36 --> Config Class Initialized
INFO - 2020-11-05 03:12:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:12:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:12:36 --> Utf8 Class Initialized
INFO - 2020-11-05 03:12:36 --> URI Class Initialized
INFO - 2020-11-05 03:12:36 --> Router Class Initialized
INFO - 2020-11-05 03:12:36 --> Output Class Initialized
INFO - 2020-11-05 03:12:36 --> Security Class Initialized
DEBUG - 2020-11-05 03:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:12:36 --> Input Class Initialized
INFO - 2020-11-05 03:12:36 --> Language Class Initialized
INFO - 2020-11-05 03:12:36 --> Language Class Initialized
INFO - 2020-11-05 03:12:36 --> Config Class Initialized
INFO - 2020-11-05 03:12:36 --> Loader Class Initialized
INFO - 2020-11-05 03:12:36 --> Helper loaded: url_helper
INFO - 2020-11-05 03:12:36 --> Helper loaded: file_helper
INFO - 2020-11-05 03:12:36 --> Helper loaded: form_helper
INFO - 2020-11-05 03:12:36 --> Helper loaded: my_helper
INFO - 2020-11-05 03:12:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:12:36 --> Controller Class Initialized
INFO - 2020-11-05 03:12:36 --> Config Class Initialized
INFO - 2020-11-05 03:12:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:12:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:12:36 --> Utf8 Class Initialized
INFO - 2020-11-05 03:12:36 --> URI Class Initialized
INFO - 2020-11-05 03:12:36 --> Router Class Initialized
INFO - 2020-11-05 03:12:36 --> Output Class Initialized
INFO - 2020-11-05 03:12:36 --> Security Class Initialized
DEBUG - 2020-11-05 03:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:12:36 --> Input Class Initialized
INFO - 2020-11-05 03:12:36 --> Language Class Initialized
INFO - 2020-11-05 03:12:36 --> Language Class Initialized
INFO - 2020-11-05 03:12:36 --> Config Class Initialized
INFO - 2020-11-05 03:12:36 --> Loader Class Initialized
INFO - 2020-11-05 03:12:36 --> Helper loaded: url_helper
INFO - 2020-11-05 03:12:36 --> Helper loaded: file_helper
INFO - 2020-11-05 03:12:36 --> Helper loaded: form_helper
INFO - 2020-11-05 03:12:36 --> Helper loaded: my_helper
INFO - 2020-11-05 03:12:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:12:36 --> Controller Class Initialized
DEBUG - 2020-11-05 03:12:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:12:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:12:36 --> Final output sent to browser
DEBUG - 2020-11-05 03:12:36 --> Total execution time: 0.2757
INFO - 2020-11-05 03:12:38 --> Config Class Initialized
INFO - 2020-11-05 03:12:38 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:12:38 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:12:38 --> Utf8 Class Initialized
INFO - 2020-11-05 03:12:38 --> URI Class Initialized
INFO - 2020-11-05 03:12:38 --> Router Class Initialized
INFO - 2020-11-05 03:12:38 --> Output Class Initialized
INFO - 2020-11-05 03:12:38 --> Security Class Initialized
DEBUG - 2020-11-05 03:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:12:38 --> Input Class Initialized
INFO - 2020-11-05 03:12:38 --> Language Class Initialized
INFO - 2020-11-05 03:12:38 --> Language Class Initialized
INFO - 2020-11-05 03:12:38 --> Config Class Initialized
INFO - 2020-11-05 03:12:38 --> Loader Class Initialized
INFO - 2020-11-05 03:12:38 --> Helper loaded: url_helper
INFO - 2020-11-05 03:12:38 --> Helper loaded: file_helper
INFO - 2020-11-05 03:12:38 --> Helper loaded: form_helper
INFO - 2020-11-05 03:12:38 --> Helper loaded: my_helper
INFO - 2020-11-05 03:12:38 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:12:38 --> Controller Class Initialized
DEBUG - 2020-11-05 03:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:12:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:12:38 --> Final output sent to browser
DEBUG - 2020-11-05 03:12:38 --> Total execution time: 0.3648
INFO - 2020-11-05 03:13:11 --> Config Class Initialized
INFO - 2020-11-05 03:13:11 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:13:11 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:13:11 --> Utf8 Class Initialized
INFO - 2020-11-05 03:13:11 --> URI Class Initialized
INFO - 2020-11-05 03:13:11 --> Router Class Initialized
INFO - 2020-11-05 03:13:11 --> Output Class Initialized
INFO - 2020-11-05 03:13:11 --> Security Class Initialized
DEBUG - 2020-11-05 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:13:11 --> Input Class Initialized
INFO - 2020-11-05 03:13:11 --> Language Class Initialized
INFO - 2020-11-05 03:13:11 --> Language Class Initialized
INFO - 2020-11-05 03:13:11 --> Config Class Initialized
INFO - 2020-11-05 03:13:11 --> Loader Class Initialized
INFO - 2020-11-05 03:13:11 --> Helper loaded: url_helper
INFO - 2020-11-05 03:13:11 --> Helper loaded: file_helper
INFO - 2020-11-05 03:13:11 --> Helper loaded: form_helper
INFO - 2020-11-05 03:13:11 --> Helper loaded: my_helper
INFO - 2020-11-05 03:13:11 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:13:11 --> Controller Class Initialized
INFO - 2020-11-05 03:13:11 --> Config Class Initialized
INFO - 2020-11-05 03:13:11 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:13:11 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:13:11 --> Utf8 Class Initialized
INFO - 2020-11-05 03:13:11 --> URI Class Initialized
INFO - 2020-11-05 03:13:11 --> Router Class Initialized
INFO - 2020-11-05 03:13:11 --> Output Class Initialized
INFO - 2020-11-05 03:13:11 --> Security Class Initialized
DEBUG - 2020-11-05 03:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:13:11 --> Input Class Initialized
INFO - 2020-11-05 03:13:11 --> Language Class Initialized
INFO - 2020-11-05 03:13:11 --> Language Class Initialized
INFO - 2020-11-05 03:13:11 --> Config Class Initialized
INFO - 2020-11-05 03:13:11 --> Loader Class Initialized
INFO - 2020-11-05 03:13:11 --> Helper loaded: url_helper
INFO - 2020-11-05 03:13:11 --> Helper loaded: file_helper
INFO - 2020-11-05 03:13:11 --> Helper loaded: form_helper
INFO - 2020-11-05 03:13:11 --> Helper loaded: my_helper
INFO - 2020-11-05 03:13:11 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:13:11 --> Controller Class Initialized
DEBUG - 2020-11-05 03:13:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:13:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:13:11 --> Final output sent to browser
DEBUG - 2020-11-05 03:13:11 --> Total execution time: 0.3146
INFO - 2020-11-05 03:13:12 --> Config Class Initialized
INFO - 2020-11-05 03:13:12 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:13:12 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:13:12 --> Utf8 Class Initialized
INFO - 2020-11-05 03:13:12 --> URI Class Initialized
INFO - 2020-11-05 03:13:12 --> Router Class Initialized
INFO - 2020-11-05 03:13:12 --> Output Class Initialized
INFO - 2020-11-05 03:13:12 --> Security Class Initialized
DEBUG - 2020-11-05 03:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:13:12 --> Input Class Initialized
INFO - 2020-11-05 03:13:12 --> Language Class Initialized
INFO - 2020-11-05 03:13:12 --> Language Class Initialized
INFO - 2020-11-05 03:13:12 --> Config Class Initialized
INFO - 2020-11-05 03:13:12 --> Loader Class Initialized
INFO - 2020-11-05 03:13:12 --> Helper loaded: url_helper
INFO - 2020-11-05 03:13:12 --> Helper loaded: file_helper
INFO - 2020-11-05 03:13:12 --> Helper loaded: form_helper
INFO - 2020-11-05 03:13:12 --> Helper loaded: my_helper
INFO - 2020-11-05 03:13:12 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:13:12 --> Controller Class Initialized
DEBUG - 2020-11-05 03:13:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:13:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:13:12 --> Final output sent to browser
DEBUG - 2020-11-05 03:13:12 --> Total execution time: 0.3188
INFO - 2020-11-05 03:13:37 --> Config Class Initialized
INFO - 2020-11-05 03:13:37 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:13:37 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:13:37 --> Utf8 Class Initialized
INFO - 2020-11-05 03:13:37 --> URI Class Initialized
INFO - 2020-11-05 03:13:37 --> Router Class Initialized
INFO - 2020-11-05 03:13:37 --> Output Class Initialized
INFO - 2020-11-05 03:13:37 --> Security Class Initialized
DEBUG - 2020-11-05 03:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:13:37 --> Input Class Initialized
INFO - 2020-11-05 03:13:37 --> Language Class Initialized
INFO - 2020-11-05 03:13:37 --> Language Class Initialized
INFO - 2020-11-05 03:13:37 --> Config Class Initialized
INFO - 2020-11-05 03:13:37 --> Loader Class Initialized
INFO - 2020-11-05 03:13:37 --> Helper loaded: url_helper
INFO - 2020-11-05 03:13:37 --> Helper loaded: file_helper
INFO - 2020-11-05 03:13:37 --> Helper loaded: form_helper
INFO - 2020-11-05 03:13:37 --> Helper loaded: my_helper
INFO - 2020-11-05 03:13:37 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:13:38 --> Controller Class Initialized
INFO - 2020-11-05 03:13:38 --> Config Class Initialized
INFO - 2020-11-05 03:13:38 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:13:38 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:13:38 --> Utf8 Class Initialized
INFO - 2020-11-05 03:13:38 --> URI Class Initialized
INFO - 2020-11-05 03:13:38 --> Router Class Initialized
INFO - 2020-11-05 03:13:38 --> Output Class Initialized
INFO - 2020-11-05 03:13:38 --> Security Class Initialized
DEBUG - 2020-11-05 03:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:13:38 --> Input Class Initialized
INFO - 2020-11-05 03:13:38 --> Language Class Initialized
INFO - 2020-11-05 03:13:38 --> Language Class Initialized
INFO - 2020-11-05 03:13:38 --> Config Class Initialized
INFO - 2020-11-05 03:13:38 --> Loader Class Initialized
INFO - 2020-11-05 03:13:38 --> Helper loaded: url_helper
INFO - 2020-11-05 03:13:38 --> Helper loaded: file_helper
INFO - 2020-11-05 03:13:38 --> Helper loaded: form_helper
INFO - 2020-11-05 03:13:38 --> Helper loaded: my_helper
INFO - 2020-11-05 03:13:38 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:13:38 --> Controller Class Initialized
DEBUG - 2020-11-05 03:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:13:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:13:38 --> Final output sent to browser
DEBUG - 2020-11-05 03:13:38 --> Total execution time: 0.3276
INFO - 2020-11-05 03:13:40 --> Config Class Initialized
INFO - 2020-11-05 03:13:40 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:13:40 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:13:40 --> Utf8 Class Initialized
INFO - 2020-11-05 03:13:40 --> URI Class Initialized
INFO - 2020-11-05 03:13:40 --> Router Class Initialized
INFO - 2020-11-05 03:13:40 --> Output Class Initialized
INFO - 2020-11-05 03:13:40 --> Security Class Initialized
DEBUG - 2020-11-05 03:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:13:40 --> Input Class Initialized
INFO - 2020-11-05 03:13:40 --> Language Class Initialized
INFO - 2020-11-05 03:13:40 --> Language Class Initialized
INFO - 2020-11-05 03:13:40 --> Config Class Initialized
INFO - 2020-11-05 03:13:40 --> Loader Class Initialized
INFO - 2020-11-05 03:13:40 --> Helper loaded: url_helper
INFO - 2020-11-05 03:13:40 --> Helper loaded: file_helper
INFO - 2020-11-05 03:13:40 --> Helper loaded: form_helper
INFO - 2020-11-05 03:13:40 --> Helper loaded: my_helper
INFO - 2020-11-05 03:13:40 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:13:40 --> Controller Class Initialized
DEBUG - 2020-11-05 03:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:13:40 --> Final output sent to browser
DEBUG - 2020-11-05 03:13:40 --> Total execution time: 0.2927
INFO - 2020-11-05 03:14:10 --> Config Class Initialized
INFO - 2020-11-05 03:14:10 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:14:10 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:14:10 --> Utf8 Class Initialized
INFO - 2020-11-05 03:14:10 --> URI Class Initialized
INFO - 2020-11-05 03:14:10 --> Router Class Initialized
INFO - 2020-11-05 03:14:10 --> Output Class Initialized
INFO - 2020-11-05 03:14:10 --> Security Class Initialized
DEBUG - 2020-11-05 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:14:10 --> Input Class Initialized
INFO - 2020-11-05 03:14:10 --> Language Class Initialized
INFO - 2020-11-05 03:14:10 --> Language Class Initialized
INFO - 2020-11-05 03:14:10 --> Config Class Initialized
INFO - 2020-11-05 03:14:10 --> Loader Class Initialized
INFO - 2020-11-05 03:14:10 --> Helper loaded: url_helper
INFO - 2020-11-05 03:14:10 --> Helper loaded: file_helper
INFO - 2020-11-05 03:14:10 --> Helper loaded: form_helper
INFO - 2020-11-05 03:14:10 --> Helper loaded: my_helper
INFO - 2020-11-05 03:14:10 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:14:10 --> Controller Class Initialized
INFO - 2020-11-05 03:14:10 --> Config Class Initialized
INFO - 2020-11-05 03:14:10 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:14:10 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:14:10 --> Utf8 Class Initialized
INFO - 2020-11-05 03:14:10 --> URI Class Initialized
INFO - 2020-11-05 03:14:10 --> Router Class Initialized
INFO - 2020-11-05 03:14:10 --> Output Class Initialized
INFO - 2020-11-05 03:14:10 --> Security Class Initialized
DEBUG - 2020-11-05 03:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:14:10 --> Input Class Initialized
INFO - 2020-11-05 03:14:10 --> Language Class Initialized
INFO - 2020-11-05 03:14:10 --> Language Class Initialized
INFO - 2020-11-05 03:14:10 --> Config Class Initialized
INFO - 2020-11-05 03:14:10 --> Loader Class Initialized
INFO - 2020-11-05 03:14:10 --> Helper loaded: url_helper
INFO - 2020-11-05 03:14:10 --> Helper loaded: file_helper
INFO - 2020-11-05 03:14:10 --> Helper loaded: form_helper
INFO - 2020-11-05 03:14:10 --> Helper loaded: my_helper
INFO - 2020-11-05 03:14:10 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:14:10 --> Controller Class Initialized
DEBUG - 2020-11-05 03:14:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:14:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:14:10 --> Final output sent to browser
DEBUG - 2020-11-05 03:14:10 --> Total execution time: 0.2949
INFO - 2020-11-05 03:14:19 --> Config Class Initialized
INFO - 2020-11-05 03:14:19 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:14:19 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:14:19 --> Utf8 Class Initialized
INFO - 2020-11-05 03:14:19 --> URI Class Initialized
INFO - 2020-11-05 03:14:19 --> Router Class Initialized
INFO - 2020-11-05 03:14:19 --> Output Class Initialized
INFO - 2020-11-05 03:14:19 --> Security Class Initialized
DEBUG - 2020-11-05 03:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:14:19 --> Input Class Initialized
INFO - 2020-11-05 03:14:19 --> Language Class Initialized
INFO - 2020-11-05 03:14:19 --> Language Class Initialized
INFO - 2020-11-05 03:14:19 --> Config Class Initialized
INFO - 2020-11-05 03:14:19 --> Loader Class Initialized
INFO - 2020-11-05 03:14:19 --> Helper loaded: url_helper
INFO - 2020-11-05 03:14:19 --> Helper loaded: file_helper
INFO - 2020-11-05 03:14:19 --> Helper loaded: form_helper
INFO - 2020-11-05 03:14:19 --> Helper loaded: my_helper
INFO - 2020-11-05 03:14:19 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:14:19 --> Controller Class Initialized
DEBUG - 2020-11-05 03:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:14:19 --> Final output sent to browser
DEBUG - 2020-11-05 03:14:19 --> Total execution time: 0.3197
INFO - 2020-11-05 03:14:47 --> Config Class Initialized
INFO - 2020-11-05 03:14:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:14:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:14:47 --> Utf8 Class Initialized
INFO - 2020-11-05 03:14:47 --> URI Class Initialized
INFO - 2020-11-05 03:14:47 --> Router Class Initialized
INFO - 2020-11-05 03:14:47 --> Output Class Initialized
INFO - 2020-11-05 03:14:47 --> Security Class Initialized
DEBUG - 2020-11-05 03:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:14:47 --> Input Class Initialized
INFO - 2020-11-05 03:14:47 --> Language Class Initialized
INFO - 2020-11-05 03:14:47 --> Language Class Initialized
INFO - 2020-11-05 03:14:47 --> Config Class Initialized
INFO - 2020-11-05 03:14:47 --> Loader Class Initialized
INFO - 2020-11-05 03:14:47 --> Helper loaded: url_helper
INFO - 2020-11-05 03:14:47 --> Helper loaded: file_helper
INFO - 2020-11-05 03:14:47 --> Helper loaded: form_helper
INFO - 2020-11-05 03:14:47 --> Helper loaded: my_helper
INFO - 2020-11-05 03:14:47 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:14:47 --> Controller Class Initialized
INFO - 2020-11-05 03:14:47 --> Config Class Initialized
INFO - 2020-11-05 03:14:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:14:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:14:47 --> Utf8 Class Initialized
INFO - 2020-11-05 03:14:47 --> URI Class Initialized
INFO - 2020-11-05 03:14:47 --> Router Class Initialized
INFO - 2020-11-05 03:14:47 --> Output Class Initialized
INFO - 2020-11-05 03:14:47 --> Security Class Initialized
DEBUG - 2020-11-05 03:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:14:47 --> Input Class Initialized
INFO - 2020-11-05 03:14:47 --> Language Class Initialized
INFO - 2020-11-05 03:14:47 --> Language Class Initialized
INFO - 2020-11-05 03:14:47 --> Config Class Initialized
INFO - 2020-11-05 03:14:47 --> Loader Class Initialized
INFO - 2020-11-05 03:14:47 --> Helper loaded: url_helper
INFO - 2020-11-05 03:14:47 --> Helper loaded: file_helper
INFO - 2020-11-05 03:14:47 --> Helper loaded: form_helper
INFO - 2020-11-05 03:14:47 --> Helper loaded: my_helper
INFO - 2020-11-05 03:14:47 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:14:47 --> Controller Class Initialized
DEBUG - 2020-11-05 03:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:14:48 --> Final output sent to browser
DEBUG - 2020-11-05 03:14:48 --> Total execution time: 0.2841
INFO - 2020-11-05 03:14:49 --> Config Class Initialized
INFO - 2020-11-05 03:14:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:14:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:14:49 --> Utf8 Class Initialized
INFO - 2020-11-05 03:14:49 --> URI Class Initialized
INFO - 2020-11-05 03:14:49 --> Router Class Initialized
INFO - 2020-11-05 03:14:49 --> Output Class Initialized
INFO - 2020-11-05 03:14:49 --> Security Class Initialized
DEBUG - 2020-11-05 03:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:14:49 --> Input Class Initialized
INFO - 2020-11-05 03:14:49 --> Language Class Initialized
INFO - 2020-11-05 03:14:49 --> Language Class Initialized
INFO - 2020-11-05 03:14:49 --> Config Class Initialized
INFO - 2020-11-05 03:14:49 --> Loader Class Initialized
INFO - 2020-11-05 03:14:49 --> Helper loaded: url_helper
INFO - 2020-11-05 03:14:49 --> Helper loaded: file_helper
INFO - 2020-11-05 03:14:49 --> Helper loaded: form_helper
INFO - 2020-11-05 03:14:49 --> Helper loaded: my_helper
INFO - 2020-11-05 03:14:49 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:14:49 --> Controller Class Initialized
DEBUG - 2020-11-05 03:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:14:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:14:49 --> Final output sent to browser
DEBUG - 2020-11-05 03:14:49 --> Total execution time: 0.3098
INFO - 2020-11-05 03:15:16 --> Config Class Initialized
INFO - 2020-11-05 03:15:16 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:15:16 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:15:16 --> Utf8 Class Initialized
INFO - 2020-11-05 03:15:16 --> URI Class Initialized
INFO - 2020-11-05 03:15:16 --> Router Class Initialized
INFO - 2020-11-05 03:15:16 --> Output Class Initialized
INFO - 2020-11-05 03:15:16 --> Security Class Initialized
DEBUG - 2020-11-05 03:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:15:16 --> Input Class Initialized
INFO - 2020-11-05 03:15:16 --> Language Class Initialized
INFO - 2020-11-05 03:15:16 --> Language Class Initialized
INFO - 2020-11-05 03:15:16 --> Config Class Initialized
INFO - 2020-11-05 03:15:16 --> Loader Class Initialized
INFO - 2020-11-05 03:15:16 --> Helper loaded: url_helper
INFO - 2020-11-05 03:15:16 --> Helper loaded: file_helper
INFO - 2020-11-05 03:15:16 --> Helper loaded: form_helper
INFO - 2020-11-05 03:15:16 --> Helper loaded: my_helper
INFO - 2020-11-05 03:15:16 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:15:16 --> Controller Class Initialized
INFO - 2020-11-05 03:15:16 --> Config Class Initialized
INFO - 2020-11-05 03:15:16 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:15:16 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:15:16 --> Utf8 Class Initialized
INFO - 2020-11-05 03:15:16 --> URI Class Initialized
INFO - 2020-11-05 03:15:16 --> Router Class Initialized
INFO - 2020-11-05 03:15:16 --> Output Class Initialized
INFO - 2020-11-05 03:15:16 --> Security Class Initialized
DEBUG - 2020-11-05 03:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:15:16 --> Input Class Initialized
INFO - 2020-11-05 03:15:16 --> Language Class Initialized
INFO - 2020-11-05 03:15:16 --> Language Class Initialized
INFO - 2020-11-05 03:15:16 --> Config Class Initialized
INFO - 2020-11-05 03:15:16 --> Loader Class Initialized
INFO - 2020-11-05 03:15:16 --> Helper loaded: url_helper
INFO - 2020-11-05 03:15:16 --> Helper loaded: file_helper
INFO - 2020-11-05 03:15:16 --> Helper loaded: form_helper
INFO - 2020-11-05 03:15:16 --> Helper loaded: my_helper
INFO - 2020-11-05 03:15:16 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:15:16 --> Controller Class Initialized
DEBUG - 2020-11-05 03:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:15:16 --> Final output sent to browser
DEBUG - 2020-11-05 03:15:16 --> Total execution time: 0.2909
INFO - 2020-11-05 03:15:17 --> Config Class Initialized
INFO - 2020-11-05 03:15:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:15:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:15:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:15:17 --> URI Class Initialized
INFO - 2020-11-05 03:15:17 --> Router Class Initialized
INFO - 2020-11-05 03:15:17 --> Output Class Initialized
INFO - 2020-11-05 03:15:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:15:17 --> Input Class Initialized
INFO - 2020-11-05 03:15:17 --> Language Class Initialized
INFO - 2020-11-05 03:15:17 --> Language Class Initialized
INFO - 2020-11-05 03:15:17 --> Config Class Initialized
INFO - 2020-11-05 03:15:17 --> Loader Class Initialized
INFO - 2020-11-05 03:15:17 --> Helper loaded: url_helper
INFO - 2020-11-05 03:15:17 --> Helper loaded: file_helper
INFO - 2020-11-05 03:15:17 --> Helper loaded: form_helper
INFO - 2020-11-05 03:15:17 --> Helper loaded: my_helper
INFO - 2020-11-05 03:15:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:15:17 --> Controller Class Initialized
DEBUG - 2020-11-05 03:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:15:17 --> Final output sent to browser
DEBUG - 2020-11-05 03:15:17 --> Total execution time: 0.2996
INFO - 2020-11-05 03:15:52 --> Config Class Initialized
INFO - 2020-11-05 03:15:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:15:52 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:15:52 --> Utf8 Class Initialized
INFO - 2020-11-05 03:15:52 --> URI Class Initialized
INFO - 2020-11-05 03:15:52 --> Router Class Initialized
INFO - 2020-11-05 03:15:52 --> Output Class Initialized
INFO - 2020-11-05 03:15:52 --> Security Class Initialized
DEBUG - 2020-11-05 03:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:15:52 --> Input Class Initialized
INFO - 2020-11-05 03:15:52 --> Language Class Initialized
INFO - 2020-11-05 03:15:52 --> Language Class Initialized
INFO - 2020-11-05 03:15:52 --> Config Class Initialized
INFO - 2020-11-05 03:15:52 --> Loader Class Initialized
INFO - 2020-11-05 03:15:52 --> Helper loaded: url_helper
INFO - 2020-11-05 03:15:52 --> Helper loaded: file_helper
INFO - 2020-11-05 03:15:52 --> Helper loaded: form_helper
INFO - 2020-11-05 03:15:52 --> Helper loaded: my_helper
INFO - 2020-11-05 03:15:52 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:15:52 --> Controller Class Initialized
INFO - 2020-11-05 03:15:52 --> Config Class Initialized
INFO - 2020-11-05 03:15:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:15:52 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:15:52 --> Utf8 Class Initialized
INFO - 2020-11-05 03:15:52 --> URI Class Initialized
INFO - 2020-11-05 03:15:52 --> Router Class Initialized
INFO - 2020-11-05 03:15:52 --> Output Class Initialized
INFO - 2020-11-05 03:15:52 --> Security Class Initialized
DEBUG - 2020-11-05 03:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:15:52 --> Input Class Initialized
INFO - 2020-11-05 03:15:52 --> Language Class Initialized
INFO - 2020-11-05 03:15:52 --> Language Class Initialized
INFO - 2020-11-05 03:15:52 --> Config Class Initialized
INFO - 2020-11-05 03:15:52 --> Loader Class Initialized
INFO - 2020-11-05 03:15:52 --> Helper loaded: url_helper
INFO - 2020-11-05 03:15:52 --> Helper loaded: file_helper
INFO - 2020-11-05 03:15:52 --> Helper loaded: form_helper
INFO - 2020-11-05 03:15:52 --> Helper loaded: my_helper
INFO - 2020-11-05 03:15:52 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:15:52 --> Controller Class Initialized
DEBUG - 2020-11-05 03:15:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:15:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:15:52 --> Final output sent to browser
DEBUG - 2020-11-05 03:15:52 --> Total execution time: 0.2752
INFO - 2020-11-05 03:16:00 --> Config Class Initialized
INFO - 2020-11-05 03:16:00 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:00 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:00 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:00 --> URI Class Initialized
INFO - 2020-11-05 03:16:00 --> Router Class Initialized
INFO - 2020-11-05 03:16:00 --> Output Class Initialized
INFO - 2020-11-05 03:16:00 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:00 --> Input Class Initialized
INFO - 2020-11-05 03:16:00 --> Language Class Initialized
INFO - 2020-11-05 03:16:00 --> Language Class Initialized
INFO - 2020-11-05 03:16:00 --> Config Class Initialized
INFO - 2020-11-05 03:16:00 --> Loader Class Initialized
INFO - 2020-11-05 03:16:00 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:00 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:00 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:00 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:00 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:00 --> Controller Class Initialized
DEBUG - 2020-11-05 03:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:16:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:16:00 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:00 --> Total execution time: 0.3153
INFO - 2020-11-05 03:16:07 --> Config Class Initialized
INFO - 2020-11-05 03:16:07 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:07 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:08 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:08 --> URI Class Initialized
INFO - 2020-11-05 03:16:08 --> Router Class Initialized
INFO - 2020-11-05 03:16:08 --> Output Class Initialized
INFO - 2020-11-05 03:16:08 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:08 --> Input Class Initialized
INFO - 2020-11-05 03:16:08 --> Language Class Initialized
INFO - 2020-11-05 03:16:08 --> Language Class Initialized
INFO - 2020-11-05 03:16:08 --> Config Class Initialized
INFO - 2020-11-05 03:16:08 --> Loader Class Initialized
INFO - 2020-11-05 03:16:08 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:08 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:08 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:08 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:08 --> Controller Class Initialized
INFO - 2020-11-05 03:16:08 --> Config Class Initialized
INFO - 2020-11-05 03:16:08 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:08 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:08 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:08 --> URI Class Initialized
INFO - 2020-11-05 03:16:08 --> Router Class Initialized
INFO - 2020-11-05 03:16:08 --> Output Class Initialized
INFO - 2020-11-05 03:16:08 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:08 --> Input Class Initialized
INFO - 2020-11-05 03:16:08 --> Language Class Initialized
INFO - 2020-11-05 03:16:08 --> Language Class Initialized
INFO - 2020-11-05 03:16:08 --> Config Class Initialized
INFO - 2020-11-05 03:16:08 --> Loader Class Initialized
INFO - 2020-11-05 03:16:08 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:08 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:08 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:08 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:08 --> Controller Class Initialized
DEBUG - 2020-11-05 03:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:16:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:16:08 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:08 --> Total execution time: 0.2931
INFO - 2020-11-05 03:16:21 --> Config Class Initialized
INFO - 2020-11-05 03:16:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:21 --> URI Class Initialized
INFO - 2020-11-05 03:16:21 --> Router Class Initialized
INFO - 2020-11-05 03:16:21 --> Output Class Initialized
INFO - 2020-11-05 03:16:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:21 --> Input Class Initialized
INFO - 2020-11-05 03:16:21 --> Language Class Initialized
INFO - 2020-11-05 03:16:21 --> Language Class Initialized
INFO - 2020-11-05 03:16:21 --> Config Class Initialized
INFO - 2020-11-05 03:16:21 --> Loader Class Initialized
INFO - 2020-11-05 03:16:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:22 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:22 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:22 --> Controller Class Initialized
DEBUG - 2020-11-05 03:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-05 03:16:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:16:22 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:22 --> Total execution time: 0.3144
INFO - 2020-11-05 03:16:22 --> Config Class Initialized
INFO - 2020-11-05 03:16:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:22 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:22 --> URI Class Initialized
INFO - 2020-11-05 03:16:22 --> Router Class Initialized
INFO - 2020-11-05 03:16:22 --> Output Class Initialized
INFO - 2020-11-05 03:16:22 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:22 --> Input Class Initialized
INFO - 2020-11-05 03:16:22 --> Language Class Initialized
INFO - 2020-11-05 03:16:22 --> Language Class Initialized
INFO - 2020-11-05 03:16:22 --> Config Class Initialized
INFO - 2020-11-05 03:16:22 --> Loader Class Initialized
INFO - 2020-11-05 03:16:22 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:22 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:22 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:22 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:22 --> Controller Class Initialized
INFO - 2020-11-05 03:16:41 --> Config Class Initialized
INFO - 2020-11-05 03:16:41 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:41 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:41 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:41 --> URI Class Initialized
INFO - 2020-11-05 03:16:41 --> Router Class Initialized
INFO - 2020-11-05 03:16:41 --> Output Class Initialized
INFO - 2020-11-05 03:16:41 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:41 --> Input Class Initialized
INFO - 2020-11-05 03:16:41 --> Language Class Initialized
INFO - 2020-11-05 03:16:41 --> Language Class Initialized
INFO - 2020-11-05 03:16:41 --> Config Class Initialized
INFO - 2020-11-05 03:16:41 --> Loader Class Initialized
INFO - 2020-11-05 03:16:41 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:41 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:41 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:41 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:41 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:41 --> Controller Class Initialized
INFO - 2020-11-05 03:16:41 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:41 --> Total execution time: 0.3371
INFO - 2020-11-05 03:16:41 --> Config Class Initialized
INFO - 2020-11-05 03:16:41 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:41 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:41 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:41 --> URI Class Initialized
INFO - 2020-11-05 03:16:41 --> Router Class Initialized
INFO - 2020-11-05 03:16:41 --> Output Class Initialized
INFO - 2020-11-05 03:16:41 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:41 --> Input Class Initialized
INFO - 2020-11-05 03:16:41 --> Language Class Initialized
INFO - 2020-11-05 03:16:41 --> Language Class Initialized
INFO - 2020-11-05 03:16:41 --> Config Class Initialized
INFO - 2020-11-05 03:16:41 --> Loader Class Initialized
INFO - 2020-11-05 03:16:41 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:41 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:41 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:41 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:41 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:41 --> Controller Class Initialized
INFO - 2020-11-05 03:16:44 --> Config Class Initialized
INFO - 2020-11-05 03:16:44 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:44 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:44 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:44 --> URI Class Initialized
INFO - 2020-11-05 03:16:44 --> Router Class Initialized
INFO - 2020-11-05 03:16:44 --> Output Class Initialized
INFO - 2020-11-05 03:16:44 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:45 --> Input Class Initialized
INFO - 2020-11-05 03:16:45 --> Language Class Initialized
INFO - 2020-11-05 03:16:45 --> Language Class Initialized
INFO - 2020-11-05 03:16:45 --> Config Class Initialized
INFO - 2020-11-05 03:16:45 --> Loader Class Initialized
INFO - 2020-11-05 03:16:45 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:45 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:45 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:45 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:45 --> Controller Class Initialized
INFO - 2020-11-05 03:16:45 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:45 --> Total execution time: 0.3183
INFO - 2020-11-05 03:16:45 --> Config Class Initialized
INFO - 2020-11-05 03:16:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:45 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:45 --> URI Class Initialized
INFO - 2020-11-05 03:16:45 --> Router Class Initialized
INFO - 2020-11-05 03:16:45 --> Output Class Initialized
INFO - 2020-11-05 03:16:45 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:45 --> Input Class Initialized
INFO - 2020-11-05 03:16:45 --> Language Class Initialized
INFO - 2020-11-05 03:16:45 --> Language Class Initialized
INFO - 2020-11-05 03:16:45 --> Config Class Initialized
INFO - 2020-11-05 03:16:45 --> Loader Class Initialized
INFO - 2020-11-05 03:16:45 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:45 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:45 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:45 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:45 --> Controller Class Initialized
INFO - 2020-11-05 03:16:47 --> Config Class Initialized
INFO - 2020-11-05 03:16:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:47 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:47 --> URI Class Initialized
INFO - 2020-11-05 03:16:47 --> Router Class Initialized
INFO - 2020-11-05 03:16:47 --> Output Class Initialized
INFO - 2020-11-05 03:16:47 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:48 --> Input Class Initialized
INFO - 2020-11-05 03:16:48 --> Language Class Initialized
INFO - 2020-11-05 03:16:48 --> Language Class Initialized
INFO - 2020-11-05 03:16:48 --> Config Class Initialized
INFO - 2020-11-05 03:16:48 --> Loader Class Initialized
INFO - 2020-11-05 03:16:48 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:48 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:48 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:48 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:48 --> Controller Class Initialized
INFO - 2020-11-05 03:16:48 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:48 --> Total execution time: 0.3490
INFO - 2020-11-05 03:16:48 --> Config Class Initialized
INFO - 2020-11-05 03:16:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:48 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:48 --> URI Class Initialized
INFO - 2020-11-05 03:16:48 --> Router Class Initialized
INFO - 2020-11-05 03:16:48 --> Output Class Initialized
INFO - 2020-11-05 03:16:48 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:48 --> Input Class Initialized
INFO - 2020-11-05 03:16:48 --> Language Class Initialized
INFO - 2020-11-05 03:16:48 --> Language Class Initialized
INFO - 2020-11-05 03:16:48 --> Config Class Initialized
INFO - 2020-11-05 03:16:48 --> Loader Class Initialized
INFO - 2020-11-05 03:16:48 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:48 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:48 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:48 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:48 --> Controller Class Initialized
INFO - 2020-11-05 03:16:50 --> Config Class Initialized
INFO - 2020-11-05 03:16:50 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:50 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:50 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:50 --> URI Class Initialized
INFO - 2020-11-05 03:16:50 --> Router Class Initialized
INFO - 2020-11-05 03:16:50 --> Output Class Initialized
INFO - 2020-11-05 03:16:50 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:50 --> Input Class Initialized
INFO - 2020-11-05 03:16:50 --> Language Class Initialized
INFO - 2020-11-05 03:16:50 --> Language Class Initialized
INFO - 2020-11-05 03:16:50 --> Config Class Initialized
INFO - 2020-11-05 03:16:50 --> Loader Class Initialized
INFO - 2020-11-05 03:16:50 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:50 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:50 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:50 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:50 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:50 --> Controller Class Initialized
INFO - 2020-11-05 03:16:50 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:50 --> Total execution time: 0.3736
INFO - 2020-11-05 03:16:50 --> Config Class Initialized
INFO - 2020-11-05 03:16:50 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:50 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:50 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:50 --> URI Class Initialized
INFO - 2020-11-05 03:16:50 --> Router Class Initialized
INFO - 2020-11-05 03:16:50 --> Output Class Initialized
INFO - 2020-11-05 03:16:50 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:50 --> Input Class Initialized
INFO - 2020-11-05 03:16:50 --> Language Class Initialized
INFO - 2020-11-05 03:16:50 --> Language Class Initialized
INFO - 2020-11-05 03:16:50 --> Config Class Initialized
INFO - 2020-11-05 03:16:50 --> Loader Class Initialized
INFO - 2020-11-05 03:16:50 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:50 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:50 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:50 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:50 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:51 --> Controller Class Initialized
INFO - 2020-11-05 03:16:52 --> Config Class Initialized
INFO - 2020-11-05 03:16:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:52 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:52 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:52 --> URI Class Initialized
INFO - 2020-11-05 03:16:52 --> Router Class Initialized
INFO - 2020-11-05 03:16:52 --> Output Class Initialized
INFO - 2020-11-05 03:16:52 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:52 --> Input Class Initialized
INFO - 2020-11-05 03:16:52 --> Language Class Initialized
INFO - 2020-11-05 03:16:52 --> Language Class Initialized
INFO - 2020-11-05 03:16:52 --> Config Class Initialized
INFO - 2020-11-05 03:16:52 --> Loader Class Initialized
INFO - 2020-11-05 03:16:52 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:52 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:52 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:53 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:53 --> Controller Class Initialized
INFO - 2020-11-05 03:16:53 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:53 --> Total execution time: 0.3357
INFO - 2020-11-05 03:16:53 --> Config Class Initialized
INFO - 2020-11-05 03:16:53 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:53 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:53 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:53 --> URI Class Initialized
INFO - 2020-11-05 03:16:53 --> Router Class Initialized
INFO - 2020-11-05 03:16:53 --> Output Class Initialized
INFO - 2020-11-05 03:16:53 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:53 --> Input Class Initialized
INFO - 2020-11-05 03:16:53 --> Language Class Initialized
INFO - 2020-11-05 03:16:53 --> Language Class Initialized
INFO - 2020-11-05 03:16:53 --> Config Class Initialized
INFO - 2020-11-05 03:16:53 --> Loader Class Initialized
INFO - 2020-11-05 03:16:53 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:53 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:53 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:53 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:53 --> Controller Class Initialized
INFO - 2020-11-05 03:16:54 --> Config Class Initialized
INFO - 2020-11-05 03:16:54 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:54 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:54 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:54 --> URI Class Initialized
INFO - 2020-11-05 03:16:54 --> Router Class Initialized
INFO - 2020-11-05 03:16:54 --> Output Class Initialized
INFO - 2020-11-05 03:16:54 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:55 --> Input Class Initialized
INFO - 2020-11-05 03:16:55 --> Language Class Initialized
INFO - 2020-11-05 03:16:55 --> Language Class Initialized
INFO - 2020-11-05 03:16:55 --> Config Class Initialized
INFO - 2020-11-05 03:16:55 --> Loader Class Initialized
INFO - 2020-11-05 03:16:55 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:55 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:55 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:55 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:55 --> Controller Class Initialized
INFO - 2020-11-05 03:16:55 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:55 --> Total execution time: 0.3862
INFO - 2020-11-05 03:16:55 --> Config Class Initialized
INFO - 2020-11-05 03:16:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:55 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:55 --> URI Class Initialized
INFO - 2020-11-05 03:16:55 --> Router Class Initialized
INFO - 2020-11-05 03:16:55 --> Output Class Initialized
INFO - 2020-11-05 03:16:55 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:55 --> Input Class Initialized
INFO - 2020-11-05 03:16:55 --> Language Class Initialized
INFO - 2020-11-05 03:16:55 --> Language Class Initialized
INFO - 2020-11-05 03:16:55 --> Config Class Initialized
INFO - 2020-11-05 03:16:55 --> Loader Class Initialized
INFO - 2020-11-05 03:16:55 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:55 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:55 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:55 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:55 --> Controller Class Initialized
INFO - 2020-11-05 03:16:56 --> Config Class Initialized
INFO - 2020-11-05 03:16:56 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:56 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:56 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:56 --> URI Class Initialized
INFO - 2020-11-05 03:16:56 --> Router Class Initialized
INFO - 2020-11-05 03:16:56 --> Output Class Initialized
INFO - 2020-11-05 03:16:56 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:56 --> Input Class Initialized
INFO - 2020-11-05 03:16:56 --> Language Class Initialized
INFO - 2020-11-05 03:16:56 --> Language Class Initialized
INFO - 2020-11-05 03:16:56 --> Config Class Initialized
INFO - 2020-11-05 03:16:56 --> Loader Class Initialized
INFO - 2020-11-05 03:16:56 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:56 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:56 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:57 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:57 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:57 --> Controller Class Initialized
INFO - 2020-11-05 03:16:57 --> Final output sent to browser
DEBUG - 2020-11-05 03:16:57 --> Total execution time: 0.3823
INFO - 2020-11-05 03:16:57 --> Config Class Initialized
INFO - 2020-11-05 03:16:57 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:57 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:57 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:57 --> URI Class Initialized
INFO - 2020-11-05 03:16:57 --> Router Class Initialized
INFO - 2020-11-05 03:16:57 --> Output Class Initialized
INFO - 2020-11-05 03:16:57 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:57 --> Input Class Initialized
INFO - 2020-11-05 03:16:57 --> Language Class Initialized
INFO - 2020-11-05 03:16:57 --> Language Class Initialized
INFO - 2020-11-05 03:16:57 --> Config Class Initialized
INFO - 2020-11-05 03:16:57 --> Loader Class Initialized
INFO - 2020-11-05 03:16:57 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:57 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:57 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:57 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:57 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:57 --> Controller Class Initialized
INFO - 2020-11-05 03:16:59 --> Config Class Initialized
INFO - 2020-11-05 03:16:59 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:16:59 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:16:59 --> Utf8 Class Initialized
INFO - 2020-11-05 03:16:59 --> URI Class Initialized
INFO - 2020-11-05 03:16:59 --> Router Class Initialized
INFO - 2020-11-05 03:16:59 --> Output Class Initialized
INFO - 2020-11-05 03:16:59 --> Security Class Initialized
DEBUG - 2020-11-05 03:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:16:59 --> Input Class Initialized
INFO - 2020-11-05 03:16:59 --> Language Class Initialized
INFO - 2020-11-05 03:16:59 --> Language Class Initialized
INFO - 2020-11-05 03:16:59 --> Config Class Initialized
INFO - 2020-11-05 03:16:59 --> Loader Class Initialized
INFO - 2020-11-05 03:16:59 --> Helper loaded: url_helper
INFO - 2020-11-05 03:16:59 --> Helper loaded: file_helper
INFO - 2020-11-05 03:16:59 --> Helper loaded: form_helper
INFO - 2020-11-05 03:16:59 --> Helper loaded: my_helper
INFO - 2020-11-05 03:16:59 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:16:59 --> Controller Class Initialized
ERROR - 2020-11-05 03:16:59 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`id_ekstra`) REFERENCES `m_ekstra` (`id`)) - Invalid query: DELETE FROM m_ekstra WHERE id = '2'
INFO - 2020-11-05 03:16:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 03:17:02 --> Config Class Initialized
INFO - 2020-11-05 03:17:02 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:02 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:02 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:02 --> URI Class Initialized
INFO - 2020-11-05 03:17:02 --> Router Class Initialized
INFO - 2020-11-05 03:17:02 --> Output Class Initialized
INFO - 2020-11-05 03:17:02 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:02 --> Input Class Initialized
INFO - 2020-11-05 03:17:02 --> Language Class Initialized
INFO - 2020-11-05 03:17:02 --> Language Class Initialized
INFO - 2020-11-05 03:17:02 --> Config Class Initialized
INFO - 2020-11-05 03:17:02 --> Loader Class Initialized
INFO - 2020-11-05 03:17:02 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:02 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:02 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:02 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:02 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:02 --> Controller Class Initialized
ERROR - 2020-11-05 03:17:02 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`id_ekstra`) REFERENCES `m_ekstra` (`id`)) - Invalid query: DELETE FROM m_ekstra WHERE id = '2'
INFO - 2020-11-05 03:17:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 03:17:05 --> Config Class Initialized
INFO - 2020-11-05 03:17:05 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:05 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:05 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:05 --> URI Class Initialized
INFO - 2020-11-05 03:17:05 --> Router Class Initialized
INFO - 2020-11-05 03:17:05 --> Output Class Initialized
INFO - 2020-11-05 03:17:05 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:05 --> Input Class Initialized
INFO - 2020-11-05 03:17:05 --> Language Class Initialized
INFO - 2020-11-05 03:17:05 --> Language Class Initialized
INFO - 2020-11-05 03:17:05 --> Config Class Initialized
INFO - 2020-11-05 03:17:05 --> Loader Class Initialized
INFO - 2020-11-05 03:17:05 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:05 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:05 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:05 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:05 --> Controller Class Initialized
ERROR - 2020-11-05 03:17:05 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`id_ekstra`) REFERENCES `m_ekstra` (`id`)) - Invalid query: DELETE FROM m_ekstra WHERE id = '1'
INFO - 2020-11-05 03:17:05 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 03:17:26 --> Config Class Initialized
INFO - 2020-11-05 03:17:26 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:26 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:26 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:26 --> URI Class Initialized
INFO - 2020-11-05 03:17:26 --> Router Class Initialized
INFO - 2020-11-05 03:17:26 --> Output Class Initialized
INFO - 2020-11-05 03:17:26 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:26 --> Input Class Initialized
INFO - 2020-11-05 03:17:26 --> Language Class Initialized
INFO - 2020-11-05 03:17:26 --> Language Class Initialized
INFO - 2020-11-05 03:17:26 --> Config Class Initialized
INFO - 2020-11-05 03:17:26 --> Loader Class Initialized
INFO - 2020-11-05 03:17:26 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:26 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:26 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:26 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:26 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:26 --> Controller Class Initialized
INFO - 2020-11-05 03:17:26 --> Final output sent to browser
DEBUG - 2020-11-05 03:17:26 --> Total execution time: 0.3321
INFO - 2020-11-05 03:17:26 --> Config Class Initialized
INFO - 2020-11-05 03:17:26 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:26 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:26 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:26 --> URI Class Initialized
INFO - 2020-11-05 03:17:26 --> Router Class Initialized
INFO - 2020-11-05 03:17:26 --> Output Class Initialized
INFO - 2020-11-05 03:17:26 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:26 --> Input Class Initialized
INFO - 2020-11-05 03:17:26 --> Language Class Initialized
INFO - 2020-11-05 03:17:26 --> Language Class Initialized
INFO - 2020-11-05 03:17:26 --> Config Class Initialized
INFO - 2020-11-05 03:17:26 --> Loader Class Initialized
INFO - 2020-11-05 03:17:26 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:26 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:26 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:26 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:27 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:27 --> Controller Class Initialized
INFO - 2020-11-05 03:17:28 --> Config Class Initialized
INFO - 2020-11-05 03:17:29 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:29 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:29 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:29 --> URI Class Initialized
INFO - 2020-11-05 03:17:29 --> Router Class Initialized
INFO - 2020-11-05 03:17:29 --> Output Class Initialized
INFO - 2020-11-05 03:17:29 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:29 --> Input Class Initialized
INFO - 2020-11-05 03:17:29 --> Language Class Initialized
INFO - 2020-11-05 03:17:29 --> Language Class Initialized
INFO - 2020-11-05 03:17:29 --> Config Class Initialized
INFO - 2020-11-05 03:17:29 --> Loader Class Initialized
INFO - 2020-11-05 03:17:29 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:29 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:29 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:29 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:29 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:29 --> Controller Class Initialized
INFO - 2020-11-05 03:17:29 --> Final output sent to browser
DEBUG - 2020-11-05 03:17:29 --> Total execution time: 0.3466
INFO - 2020-11-05 03:17:29 --> Config Class Initialized
INFO - 2020-11-05 03:17:29 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:29 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:29 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:29 --> URI Class Initialized
INFO - 2020-11-05 03:17:29 --> Router Class Initialized
INFO - 2020-11-05 03:17:29 --> Output Class Initialized
INFO - 2020-11-05 03:17:29 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:29 --> Input Class Initialized
INFO - 2020-11-05 03:17:29 --> Language Class Initialized
INFO - 2020-11-05 03:17:29 --> Language Class Initialized
INFO - 2020-11-05 03:17:29 --> Config Class Initialized
INFO - 2020-11-05 03:17:29 --> Loader Class Initialized
INFO - 2020-11-05 03:17:29 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:29 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:29 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:29 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:29 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:29 --> Controller Class Initialized
INFO - 2020-11-05 03:17:30 --> Config Class Initialized
INFO - 2020-11-05 03:17:30 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:30 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:30 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:30 --> URI Class Initialized
INFO - 2020-11-05 03:17:30 --> Router Class Initialized
INFO - 2020-11-05 03:17:30 --> Output Class Initialized
INFO - 2020-11-05 03:17:30 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:30 --> Input Class Initialized
INFO - 2020-11-05 03:17:30 --> Language Class Initialized
INFO - 2020-11-05 03:17:30 --> Language Class Initialized
INFO - 2020-11-05 03:17:30 --> Config Class Initialized
INFO - 2020-11-05 03:17:30 --> Loader Class Initialized
INFO - 2020-11-05 03:17:30 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:30 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:30 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:30 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:30 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:30 --> Controller Class Initialized
INFO - 2020-11-05 03:17:30 --> Final output sent to browser
DEBUG - 2020-11-05 03:17:30 --> Total execution time: 0.2841
INFO - 2020-11-05 03:17:45 --> Config Class Initialized
INFO - 2020-11-05 03:17:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:45 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:45 --> URI Class Initialized
INFO - 2020-11-05 03:17:45 --> Router Class Initialized
INFO - 2020-11-05 03:17:45 --> Output Class Initialized
INFO - 2020-11-05 03:17:45 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:45 --> Input Class Initialized
INFO - 2020-11-05 03:17:45 --> Language Class Initialized
INFO - 2020-11-05 03:17:45 --> Language Class Initialized
INFO - 2020-11-05 03:17:45 --> Config Class Initialized
INFO - 2020-11-05 03:17:45 --> Loader Class Initialized
INFO - 2020-11-05 03:17:45 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:45 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:45 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:45 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:45 --> Controller Class Initialized
INFO - 2020-11-05 03:17:45 --> Final output sent to browser
DEBUG - 2020-11-05 03:17:45 --> Total execution time: 0.3309
INFO - 2020-11-05 03:17:45 --> Config Class Initialized
INFO - 2020-11-05 03:17:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:45 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:45 --> URI Class Initialized
INFO - 2020-11-05 03:17:45 --> Router Class Initialized
INFO - 2020-11-05 03:17:45 --> Output Class Initialized
INFO - 2020-11-05 03:17:45 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:45 --> Input Class Initialized
INFO - 2020-11-05 03:17:45 --> Language Class Initialized
INFO - 2020-11-05 03:17:45 --> Language Class Initialized
INFO - 2020-11-05 03:17:45 --> Config Class Initialized
INFO - 2020-11-05 03:17:45 --> Loader Class Initialized
INFO - 2020-11-05 03:17:45 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:45 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:45 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:45 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:46 --> Controller Class Initialized
INFO - 2020-11-05 03:17:48 --> Config Class Initialized
INFO - 2020-11-05 03:17:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:17:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:17:48 --> Utf8 Class Initialized
INFO - 2020-11-05 03:17:48 --> URI Class Initialized
INFO - 2020-11-05 03:17:48 --> Router Class Initialized
INFO - 2020-11-05 03:17:48 --> Output Class Initialized
INFO - 2020-11-05 03:17:48 --> Security Class Initialized
DEBUG - 2020-11-05 03:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:17:48 --> Input Class Initialized
INFO - 2020-11-05 03:17:48 --> Language Class Initialized
INFO - 2020-11-05 03:17:48 --> Language Class Initialized
INFO - 2020-11-05 03:17:48 --> Config Class Initialized
INFO - 2020-11-05 03:17:48 --> Loader Class Initialized
INFO - 2020-11-05 03:17:48 --> Helper loaded: url_helper
INFO - 2020-11-05 03:17:48 --> Helper loaded: file_helper
INFO - 2020-11-05 03:17:48 --> Helper loaded: form_helper
INFO - 2020-11-05 03:17:48 --> Helper loaded: my_helper
INFO - 2020-11-05 03:17:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:17:48 --> Controller Class Initialized
INFO - 2020-11-05 03:17:48 --> Final output sent to browser
DEBUG - 2020-11-05 03:17:48 --> Total execution time: 0.3086
INFO - 2020-11-05 03:18:52 --> Config Class Initialized
INFO - 2020-11-05 03:18:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:18:52 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:18:52 --> Utf8 Class Initialized
INFO - 2020-11-05 03:18:52 --> URI Class Initialized
INFO - 2020-11-05 03:18:52 --> Router Class Initialized
INFO - 2020-11-05 03:18:52 --> Output Class Initialized
INFO - 2020-11-05 03:18:52 --> Security Class Initialized
DEBUG - 2020-11-05 03:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:18:53 --> Input Class Initialized
INFO - 2020-11-05 03:18:53 --> Language Class Initialized
INFO - 2020-11-05 03:18:53 --> Language Class Initialized
INFO - 2020-11-05 03:18:53 --> Config Class Initialized
INFO - 2020-11-05 03:18:53 --> Loader Class Initialized
INFO - 2020-11-05 03:18:53 --> Helper loaded: url_helper
INFO - 2020-11-05 03:18:53 --> Helper loaded: file_helper
INFO - 2020-11-05 03:18:53 --> Helper loaded: form_helper
INFO - 2020-11-05 03:18:53 --> Helper loaded: my_helper
INFO - 2020-11-05 03:18:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:18:53 --> Controller Class Initialized
INFO - 2020-11-05 03:18:53 --> Final output sent to browser
DEBUG - 2020-11-05 03:18:53 --> Total execution time: 0.3228
INFO - 2020-11-05 03:18:53 --> Config Class Initialized
INFO - 2020-11-05 03:18:53 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:18:53 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:18:53 --> Utf8 Class Initialized
INFO - 2020-11-05 03:18:53 --> URI Class Initialized
INFO - 2020-11-05 03:18:53 --> Router Class Initialized
INFO - 2020-11-05 03:18:53 --> Output Class Initialized
INFO - 2020-11-05 03:18:53 --> Security Class Initialized
DEBUG - 2020-11-05 03:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:18:53 --> Input Class Initialized
INFO - 2020-11-05 03:18:53 --> Language Class Initialized
INFO - 2020-11-05 03:18:53 --> Language Class Initialized
INFO - 2020-11-05 03:18:53 --> Config Class Initialized
INFO - 2020-11-05 03:18:53 --> Loader Class Initialized
INFO - 2020-11-05 03:18:53 --> Helper loaded: url_helper
INFO - 2020-11-05 03:18:53 --> Helper loaded: file_helper
INFO - 2020-11-05 03:18:53 --> Helper loaded: form_helper
INFO - 2020-11-05 03:18:53 --> Helper loaded: my_helper
INFO - 2020-11-05 03:18:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:18:53 --> Controller Class Initialized
INFO - 2020-11-05 03:18:58 --> Config Class Initialized
INFO - 2020-11-05 03:18:58 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:18:58 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:18:58 --> Utf8 Class Initialized
INFO - 2020-11-05 03:18:58 --> URI Class Initialized
INFO - 2020-11-05 03:18:58 --> Router Class Initialized
INFO - 2020-11-05 03:18:58 --> Output Class Initialized
INFO - 2020-11-05 03:18:58 --> Security Class Initialized
DEBUG - 2020-11-05 03:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:18:58 --> Input Class Initialized
INFO - 2020-11-05 03:18:58 --> Language Class Initialized
INFO - 2020-11-05 03:18:58 --> Language Class Initialized
INFO - 2020-11-05 03:18:58 --> Config Class Initialized
INFO - 2020-11-05 03:18:58 --> Loader Class Initialized
INFO - 2020-11-05 03:18:58 --> Helper loaded: url_helper
INFO - 2020-11-05 03:18:58 --> Helper loaded: file_helper
INFO - 2020-11-05 03:18:58 --> Helper loaded: form_helper
INFO - 2020-11-05 03:18:58 --> Helper loaded: my_helper
INFO - 2020-11-05 03:18:58 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:18:58 --> Controller Class Initialized
INFO - 2020-11-05 03:18:58 --> Final output sent to browser
DEBUG - 2020-11-05 03:18:58 --> Total execution time: 0.3063
INFO - 2020-11-05 03:19:09 --> Config Class Initialized
INFO - 2020-11-05 03:19:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:09 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:09 --> URI Class Initialized
INFO - 2020-11-05 03:19:09 --> Router Class Initialized
INFO - 2020-11-05 03:19:09 --> Output Class Initialized
INFO - 2020-11-05 03:19:09 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:09 --> Input Class Initialized
INFO - 2020-11-05 03:19:09 --> Language Class Initialized
INFO - 2020-11-05 03:19:09 --> Language Class Initialized
INFO - 2020-11-05 03:19:09 --> Config Class Initialized
INFO - 2020-11-05 03:19:09 --> Loader Class Initialized
INFO - 2020-11-05 03:19:09 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:09 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:09 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:09 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:09 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:09 --> Controller Class Initialized
INFO - 2020-11-05 03:19:09 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:09 --> Total execution time: 0.2922
INFO - 2020-11-05 03:19:09 --> Config Class Initialized
INFO - 2020-11-05 03:19:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:09 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:09 --> URI Class Initialized
INFO - 2020-11-05 03:19:09 --> Router Class Initialized
INFO - 2020-11-05 03:19:09 --> Output Class Initialized
INFO - 2020-11-05 03:19:09 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:09 --> Input Class Initialized
INFO - 2020-11-05 03:19:09 --> Language Class Initialized
INFO - 2020-11-05 03:19:09 --> Language Class Initialized
INFO - 2020-11-05 03:19:09 --> Config Class Initialized
INFO - 2020-11-05 03:19:09 --> Loader Class Initialized
INFO - 2020-11-05 03:19:09 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:09 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:09 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:09 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:09 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:10 --> Controller Class Initialized
INFO - 2020-11-05 03:19:10 --> Config Class Initialized
INFO - 2020-11-05 03:19:10 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:10 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:10 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:10 --> URI Class Initialized
INFO - 2020-11-05 03:19:10 --> Router Class Initialized
INFO - 2020-11-05 03:19:10 --> Output Class Initialized
INFO - 2020-11-05 03:19:10 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:10 --> Input Class Initialized
INFO - 2020-11-05 03:19:10 --> Language Class Initialized
INFO - 2020-11-05 03:19:10 --> Language Class Initialized
INFO - 2020-11-05 03:19:11 --> Config Class Initialized
INFO - 2020-11-05 03:19:11 --> Loader Class Initialized
INFO - 2020-11-05 03:19:11 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:11 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:11 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:11 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:11 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:11 --> Controller Class Initialized
INFO - 2020-11-05 03:19:11 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:11 --> Total execution time: 0.2953
INFO - 2020-11-05 03:19:21 --> Config Class Initialized
INFO - 2020-11-05 03:19:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:21 --> URI Class Initialized
INFO - 2020-11-05 03:19:21 --> Router Class Initialized
INFO - 2020-11-05 03:19:21 --> Output Class Initialized
INFO - 2020-11-05 03:19:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:21 --> Input Class Initialized
INFO - 2020-11-05 03:19:21 --> Language Class Initialized
INFO - 2020-11-05 03:19:21 --> Language Class Initialized
INFO - 2020-11-05 03:19:21 --> Config Class Initialized
INFO - 2020-11-05 03:19:21 --> Loader Class Initialized
INFO - 2020-11-05 03:19:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:21 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:21 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:21 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:21 --> Controller Class Initialized
INFO - 2020-11-05 03:19:21 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:21 --> Total execution time: 0.3097
INFO - 2020-11-05 03:19:21 --> Config Class Initialized
INFO - 2020-11-05 03:19:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:21 --> URI Class Initialized
INFO - 2020-11-05 03:19:21 --> Router Class Initialized
INFO - 2020-11-05 03:19:21 --> Output Class Initialized
INFO - 2020-11-05 03:19:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:21 --> Input Class Initialized
INFO - 2020-11-05 03:19:21 --> Language Class Initialized
INFO - 2020-11-05 03:19:21 --> Language Class Initialized
INFO - 2020-11-05 03:19:21 --> Config Class Initialized
INFO - 2020-11-05 03:19:21 --> Loader Class Initialized
INFO - 2020-11-05 03:19:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:21 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:21 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:21 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:21 --> Controller Class Initialized
INFO - 2020-11-05 03:19:23 --> Config Class Initialized
INFO - 2020-11-05 03:19:23 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:23 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:23 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:23 --> URI Class Initialized
INFO - 2020-11-05 03:19:23 --> Router Class Initialized
INFO - 2020-11-05 03:19:23 --> Output Class Initialized
INFO - 2020-11-05 03:19:23 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:23 --> Input Class Initialized
INFO - 2020-11-05 03:19:23 --> Language Class Initialized
INFO - 2020-11-05 03:19:23 --> Language Class Initialized
INFO - 2020-11-05 03:19:23 --> Config Class Initialized
INFO - 2020-11-05 03:19:23 --> Loader Class Initialized
INFO - 2020-11-05 03:19:23 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:23 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:23 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:23 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:23 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:23 --> Controller Class Initialized
INFO - 2020-11-05 03:19:23 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:23 --> Total execution time: 0.2857
INFO - 2020-11-05 03:19:27 --> Config Class Initialized
INFO - 2020-11-05 03:19:27 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:27 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:27 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:27 --> URI Class Initialized
INFO - 2020-11-05 03:19:27 --> Router Class Initialized
INFO - 2020-11-05 03:19:27 --> Output Class Initialized
INFO - 2020-11-05 03:19:27 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:27 --> Input Class Initialized
INFO - 2020-11-05 03:19:27 --> Language Class Initialized
INFO - 2020-11-05 03:19:27 --> Language Class Initialized
INFO - 2020-11-05 03:19:27 --> Config Class Initialized
INFO - 2020-11-05 03:19:27 --> Loader Class Initialized
INFO - 2020-11-05 03:19:27 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:27 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:27 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:27 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:27 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:27 --> Controller Class Initialized
INFO - 2020-11-05 03:19:27 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:27 --> Total execution time: 0.3273
INFO - 2020-11-05 03:19:27 --> Config Class Initialized
INFO - 2020-11-05 03:19:27 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:27 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:27 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:27 --> URI Class Initialized
INFO - 2020-11-05 03:19:27 --> Router Class Initialized
INFO - 2020-11-05 03:19:27 --> Output Class Initialized
INFO - 2020-11-05 03:19:27 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:27 --> Input Class Initialized
INFO - 2020-11-05 03:19:27 --> Language Class Initialized
INFO - 2020-11-05 03:19:27 --> Language Class Initialized
INFO - 2020-11-05 03:19:27 --> Config Class Initialized
INFO - 2020-11-05 03:19:27 --> Loader Class Initialized
INFO - 2020-11-05 03:19:27 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:27 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:27 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:27 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:27 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:27 --> Controller Class Initialized
INFO - 2020-11-05 03:19:28 --> Config Class Initialized
INFO - 2020-11-05 03:19:28 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:28 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:28 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:29 --> URI Class Initialized
INFO - 2020-11-05 03:19:29 --> Router Class Initialized
INFO - 2020-11-05 03:19:29 --> Output Class Initialized
INFO - 2020-11-05 03:19:29 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:29 --> Input Class Initialized
INFO - 2020-11-05 03:19:29 --> Language Class Initialized
INFO - 2020-11-05 03:19:29 --> Language Class Initialized
INFO - 2020-11-05 03:19:29 --> Config Class Initialized
INFO - 2020-11-05 03:19:29 --> Loader Class Initialized
INFO - 2020-11-05 03:19:29 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:29 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:29 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:29 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:29 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:29 --> Controller Class Initialized
INFO - 2020-11-05 03:19:29 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:29 --> Total execution time: 0.2680
INFO - 2020-11-05 03:19:37 --> Config Class Initialized
INFO - 2020-11-05 03:19:37 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:37 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:37 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:37 --> URI Class Initialized
INFO - 2020-11-05 03:19:37 --> Router Class Initialized
INFO - 2020-11-05 03:19:37 --> Output Class Initialized
INFO - 2020-11-05 03:19:37 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:37 --> Input Class Initialized
INFO - 2020-11-05 03:19:37 --> Language Class Initialized
INFO - 2020-11-05 03:19:37 --> Language Class Initialized
INFO - 2020-11-05 03:19:37 --> Config Class Initialized
INFO - 2020-11-05 03:19:37 --> Loader Class Initialized
INFO - 2020-11-05 03:19:37 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:37 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:37 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:37 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:37 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:37 --> Controller Class Initialized
INFO - 2020-11-05 03:19:37 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:37 --> Total execution time: 0.3368
INFO - 2020-11-05 03:19:37 --> Config Class Initialized
INFO - 2020-11-05 03:19:37 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:37 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:37 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:37 --> URI Class Initialized
INFO - 2020-11-05 03:19:37 --> Router Class Initialized
INFO - 2020-11-05 03:19:37 --> Output Class Initialized
INFO - 2020-11-05 03:19:37 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:37 --> Input Class Initialized
INFO - 2020-11-05 03:19:37 --> Language Class Initialized
INFO - 2020-11-05 03:19:37 --> Language Class Initialized
INFO - 2020-11-05 03:19:37 --> Config Class Initialized
INFO - 2020-11-05 03:19:37 --> Loader Class Initialized
INFO - 2020-11-05 03:19:37 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:37 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:37 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:37 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:37 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:37 --> Controller Class Initialized
INFO - 2020-11-05 03:19:38 --> Config Class Initialized
INFO - 2020-11-05 03:19:38 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:38 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:38 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:38 --> URI Class Initialized
INFO - 2020-11-05 03:19:38 --> Router Class Initialized
INFO - 2020-11-05 03:19:38 --> Output Class Initialized
INFO - 2020-11-05 03:19:38 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:38 --> Input Class Initialized
INFO - 2020-11-05 03:19:38 --> Language Class Initialized
INFO - 2020-11-05 03:19:38 --> Language Class Initialized
INFO - 2020-11-05 03:19:38 --> Config Class Initialized
INFO - 2020-11-05 03:19:38 --> Loader Class Initialized
INFO - 2020-11-05 03:19:38 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:38 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:38 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:38 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:38 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:38 --> Controller Class Initialized
INFO - 2020-11-05 03:19:38 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:38 --> Total execution time: 0.2961
INFO - 2020-11-05 03:19:43 --> Config Class Initialized
INFO - 2020-11-05 03:19:43 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:43 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:43 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:43 --> URI Class Initialized
INFO - 2020-11-05 03:19:43 --> Router Class Initialized
INFO - 2020-11-05 03:19:43 --> Output Class Initialized
INFO - 2020-11-05 03:19:43 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:43 --> Input Class Initialized
INFO - 2020-11-05 03:19:43 --> Language Class Initialized
INFO - 2020-11-05 03:19:43 --> Language Class Initialized
INFO - 2020-11-05 03:19:43 --> Config Class Initialized
INFO - 2020-11-05 03:19:43 --> Loader Class Initialized
INFO - 2020-11-05 03:19:43 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:43 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:43 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:43 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:43 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:43 --> Controller Class Initialized
INFO - 2020-11-05 03:19:43 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:43 --> Total execution time: 0.3741
INFO - 2020-11-05 03:19:44 --> Config Class Initialized
INFO - 2020-11-05 03:19:44 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:44 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:44 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:44 --> URI Class Initialized
INFO - 2020-11-05 03:19:44 --> Router Class Initialized
INFO - 2020-11-05 03:19:44 --> Output Class Initialized
INFO - 2020-11-05 03:19:44 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:44 --> Input Class Initialized
INFO - 2020-11-05 03:19:44 --> Language Class Initialized
INFO - 2020-11-05 03:19:44 --> Language Class Initialized
INFO - 2020-11-05 03:19:44 --> Config Class Initialized
INFO - 2020-11-05 03:19:44 --> Loader Class Initialized
INFO - 2020-11-05 03:19:44 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:44 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:44 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:44 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:44 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:44 --> Controller Class Initialized
INFO - 2020-11-05 03:19:44 --> Config Class Initialized
INFO - 2020-11-05 03:19:44 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:44 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:45 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:45 --> URI Class Initialized
INFO - 2020-11-05 03:19:45 --> Router Class Initialized
INFO - 2020-11-05 03:19:45 --> Output Class Initialized
INFO - 2020-11-05 03:19:45 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:45 --> Input Class Initialized
INFO - 2020-11-05 03:19:45 --> Language Class Initialized
INFO - 2020-11-05 03:19:45 --> Language Class Initialized
INFO - 2020-11-05 03:19:45 --> Config Class Initialized
INFO - 2020-11-05 03:19:45 --> Loader Class Initialized
INFO - 2020-11-05 03:19:45 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:45 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:45 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:45 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:45 --> Controller Class Initialized
INFO - 2020-11-05 03:19:45 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:45 --> Total execution time: 0.2845
INFO - 2020-11-05 03:19:50 --> Config Class Initialized
INFO - 2020-11-05 03:19:50 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:50 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:50 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:50 --> URI Class Initialized
INFO - 2020-11-05 03:19:50 --> Router Class Initialized
INFO - 2020-11-05 03:19:50 --> Output Class Initialized
INFO - 2020-11-05 03:19:50 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:50 --> Input Class Initialized
INFO - 2020-11-05 03:19:50 --> Language Class Initialized
INFO - 2020-11-05 03:19:50 --> Language Class Initialized
INFO - 2020-11-05 03:19:50 --> Config Class Initialized
INFO - 2020-11-05 03:19:50 --> Loader Class Initialized
INFO - 2020-11-05 03:19:50 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:50 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:50 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:50 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:50 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:50 --> Controller Class Initialized
INFO - 2020-11-05 03:19:50 --> Final output sent to browser
DEBUG - 2020-11-05 03:19:50 --> Total execution time: 0.3704
INFO - 2020-11-05 03:19:50 --> Config Class Initialized
INFO - 2020-11-05 03:19:50 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:19:50 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:19:50 --> Utf8 Class Initialized
INFO - 2020-11-05 03:19:50 --> URI Class Initialized
INFO - 2020-11-05 03:19:50 --> Router Class Initialized
INFO - 2020-11-05 03:19:50 --> Output Class Initialized
INFO - 2020-11-05 03:19:50 --> Security Class Initialized
DEBUG - 2020-11-05 03:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:19:50 --> Input Class Initialized
INFO - 2020-11-05 03:19:50 --> Language Class Initialized
INFO - 2020-11-05 03:19:51 --> Language Class Initialized
INFO - 2020-11-05 03:19:51 --> Config Class Initialized
INFO - 2020-11-05 03:19:51 --> Loader Class Initialized
INFO - 2020-11-05 03:19:51 --> Helper loaded: url_helper
INFO - 2020-11-05 03:19:51 --> Helper loaded: file_helper
INFO - 2020-11-05 03:19:51 --> Helper loaded: form_helper
INFO - 2020-11-05 03:19:51 --> Helper loaded: my_helper
INFO - 2020-11-05 03:19:51 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:19:51 --> Controller Class Initialized
INFO - 2020-11-05 03:20:01 --> Config Class Initialized
INFO - 2020-11-05 03:20:01 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:01 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:01 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:01 --> URI Class Initialized
INFO - 2020-11-05 03:20:01 --> Router Class Initialized
INFO - 2020-11-05 03:20:01 --> Output Class Initialized
INFO - 2020-11-05 03:20:01 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:01 --> Input Class Initialized
INFO - 2020-11-05 03:20:01 --> Language Class Initialized
INFO - 2020-11-05 03:20:01 --> Language Class Initialized
INFO - 2020-11-05 03:20:01 --> Config Class Initialized
INFO - 2020-11-05 03:20:01 --> Loader Class Initialized
INFO - 2020-11-05 03:20:01 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:01 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:01 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:01 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:01 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:01 --> Controller Class Initialized
INFO - 2020-11-05 03:20:01 --> Final output sent to browser
DEBUG - 2020-11-05 03:20:01 --> Total execution time: 0.2822
INFO - 2020-11-05 03:20:07 --> Config Class Initialized
INFO - 2020-11-05 03:20:07 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:07 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:07 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:07 --> URI Class Initialized
INFO - 2020-11-05 03:20:07 --> Router Class Initialized
INFO - 2020-11-05 03:20:07 --> Output Class Initialized
INFO - 2020-11-05 03:20:07 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:07 --> Input Class Initialized
INFO - 2020-11-05 03:20:08 --> Language Class Initialized
INFO - 2020-11-05 03:20:08 --> Language Class Initialized
INFO - 2020-11-05 03:20:08 --> Config Class Initialized
INFO - 2020-11-05 03:20:08 --> Loader Class Initialized
INFO - 2020-11-05 03:20:08 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:08 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:08 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:08 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:08 --> Controller Class Initialized
INFO - 2020-11-05 03:20:08 --> Final output sent to browser
DEBUG - 2020-11-05 03:20:08 --> Total execution time: 0.3161
INFO - 2020-11-05 03:20:08 --> Config Class Initialized
INFO - 2020-11-05 03:20:08 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:08 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:08 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:08 --> URI Class Initialized
INFO - 2020-11-05 03:20:08 --> Router Class Initialized
INFO - 2020-11-05 03:20:08 --> Output Class Initialized
INFO - 2020-11-05 03:20:08 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:08 --> Input Class Initialized
INFO - 2020-11-05 03:20:08 --> Language Class Initialized
INFO - 2020-11-05 03:20:08 --> Language Class Initialized
INFO - 2020-11-05 03:20:08 --> Config Class Initialized
INFO - 2020-11-05 03:20:08 --> Loader Class Initialized
INFO - 2020-11-05 03:20:08 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:08 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:08 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:08 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:08 --> Controller Class Initialized
INFO - 2020-11-05 03:20:16 --> Config Class Initialized
INFO - 2020-11-05 03:20:16 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:16 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:16 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:16 --> URI Class Initialized
INFO - 2020-11-05 03:20:16 --> Router Class Initialized
INFO - 2020-11-05 03:20:16 --> Output Class Initialized
INFO - 2020-11-05 03:20:16 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:16 --> Input Class Initialized
INFO - 2020-11-05 03:20:16 --> Language Class Initialized
INFO - 2020-11-05 03:20:16 --> Language Class Initialized
INFO - 2020-11-05 03:20:16 --> Config Class Initialized
INFO - 2020-11-05 03:20:16 --> Loader Class Initialized
INFO - 2020-11-05 03:20:16 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:16 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:16 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:16 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:16 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:16 --> Controller Class Initialized
DEBUG - 2020-11-05 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-11-05 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:20:16 --> Final output sent to browser
DEBUG - 2020-11-05 03:20:16 --> Total execution time: 0.3997
INFO - 2020-11-05 03:20:16 --> Config Class Initialized
INFO - 2020-11-05 03:20:16 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:16 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:16 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:16 --> URI Class Initialized
INFO - 2020-11-05 03:20:16 --> Router Class Initialized
INFO - 2020-11-05 03:20:16 --> Output Class Initialized
INFO - 2020-11-05 03:20:16 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:16 --> Input Class Initialized
INFO - 2020-11-05 03:20:16 --> Language Class Initialized
INFO - 2020-11-05 03:20:16 --> Language Class Initialized
INFO - 2020-11-05 03:20:16 --> Config Class Initialized
INFO - 2020-11-05 03:20:16 --> Loader Class Initialized
INFO - 2020-11-05 03:20:16 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:16 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:16 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:16 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:16 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:17 --> Controller Class Initialized
INFO - 2020-11-05 03:20:17 --> Config Class Initialized
INFO - 2020-11-05 03:20:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:17 --> URI Class Initialized
INFO - 2020-11-05 03:20:17 --> Router Class Initialized
INFO - 2020-11-05 03:20:17 --> Output Class Initialized
INFO - 2020-11-05 03:20:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:17 --> Input Class Initialized
INFO - 2020-11-05 03:20:17 --> Language Class Initialized
INFO - 2020-11-05 03:20:17 --> Language Class Initialized
INFO - 2020-11-05 03:20:17 --> Config Class Initialized
INFO - 2020-11-05 03:20:17 --> Loader Class Initialized
INFO - 2020-11-05 03:20:17 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:17 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:17 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:17 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:17 --> Controller Class Initialized
DEBUG - 2020-11-05 03:20:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:20:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:20:17 --> Final output sent to browser
DEBUG - 2020-11-05 03:20:17 --> Total execution time: 0.3570
INFO - 2020-11-05 03:20:18 --> Config Class Initialized
INFO - 2020-11-05 03:20:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:18 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:18 --> URI Class Initialized
INFO - 2020-11-05 03:20:18 --> Router Class Initialized
INFO - 2020-11-05 03:20:18 --> Output Class Initialized
INFO - 2020-11-05 03:20:19 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:19 --> Input Class Initialized
INFO - 2020-11-05 03:20:19 --> Language Class Initialized
INFO - 2020-11-05 03:20:19 --> Language Class Initialized
INFO - 2020-11-05 03:20:19 --> Config Class Initialized
INFO - 2020-11-05 03:20:19 --> Loader Class Initialized
INFO - 2020-11-05 03:20:19 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:19 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:19 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:19 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:19 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:19 --> Controller Class Initialized
DEBUG - 2020-11-05 03:20:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-05 03:20:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:20:19 --> Final output sent to browser
DEBUG - 2020-11-05 03:20:19 --> Total execution time: 0.3342
INFO - 2020-11-05 03:20:21 --> Config Class Initialized
INFO - 2020-11-05 03:20:21 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:20:21 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:20:21 --> Utf8 Class Initialized
INFO - 2020-11-05 03:20:21 --> URI Class Initialized
INFO - 2020-11-05 03:20:21 --> Router Class Initialized
INFO - 2020-11-05 03:20:21 --> Output Class Initialized
INFO - 2020-11-05 03:20:21 --> Security Class Initialized
DEBUG - 2020-11-05 03:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:20:21 --> Input Class Initialized
INFO - 2020-11-05 03:20:21 --> Language Class Initialized
INFO - 2020-11-05 03:20:21 --> Language Class Initialized
INFO - 2020-11-05 03:20:21 --> Config Class Initialized
INFO - 2020-11-05 03:20:21 --> Loader Class Initialized
INFO - 2020-11-05 03:20:21 --> Helper loaded: url_helper
INFO - 2020-11-05 03:20:21 --> Helper loaded: file_helper
INFO - 2020-11-05 03:20:21 --> Helper loaded: form_helper
INFO - 2020-11-05 03:20:21 --> Helper loaded: my_helper
INFO - 2020-11-05 03:20:21 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:20:21 --> Controller Class Initialized
DEBUG - 2020-11-05 03:20:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-05 03:20:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:20:21 --> Final output sent to browser
DEBUG - 2020-11-05 03:20:21 --> Total execution time: 0.3228
INFO - 2020-11-05 03:23:07 --> Config Class Initialized
INFO - 2020-11-05 03:23:07 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:07 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:07 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:07 --> URI Class Initialized
INFO - 2020-11-05 03:23:07 --> Router Class Initialized
INFO - 2020-11-05 03:23:07 --> Output Class Initialized
INFO - 2020-11-05 03:23:07 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:07 --> Input Class Initialized
INFO - 2020-11-05 03:23:07 --> Language Class Initialized
INFO - 2020-11-05 03:23:07 --> Language Class Initialized
INFO - 2020-11-05 03:23:07 --> Config Class Initialized
INFO - 2020-11-05 03:23:07 --> Loader Class Initialized
INFO - 2020-11-05 03:23:07 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:07 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:07 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:07 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:07 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:07 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-11-05 03:23:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:07 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:07 --> Total execution time: 0.3301
INFO - 2020-11-05 03:23:08 --> Config Class Initialized
INFO - 2020-11-05 03:23:08 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:08 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:08 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:08 --> URI Class Initialized
INFO - 2020-11-05 03:23:08 --> Router Class Initialized
INFO - 2020-11-05 03:23:08 --> Output Class Initialized
INFO - 2020-11-05 03:23:08 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:08 --> Input Class Initialized
INFO - 2020-11-05 03:23:08 --> Language Class Initialized
INFO - 2020-11-05 03:23:08 --> Language Class Initialized
INFO - 2020-11-05 03:23:08 --> Config Class Initialized
INFO - 2020-11-05 03:23:08 --> Loader Class Initialized
INFO - 2020-11-05 03:23:08 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:08 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:08 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:08 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:08 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:08 --> Controller Class Initialized
INFO - 2020-11-05 03:23:09 --> Config Class Initialized
INFO - 2020-11-05 03:23:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:09 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:09 --> URI Class Initialized
INFO - 2020-11-05 03:23:09 --> Router Class Initialized
INFO - 2020-11-05 03:23:09 --> Output Class Initialized
INFO - 2020-11-05 03:23:09 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:09 --> Input Class Initialized
INFO - 2020-11-05 03:23:09 --> Language Class Initialized
INFO - 2020-11-05 03:23:09 --> Language Class Initialized
INFO - 2020-11-05 03:23:09 --> Config Class Initialized
INFO - 2020-11-05 03:23:09 --> Loader Class Initialized
INFO - 2020-11-05 03:23:09 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:09 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:09 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:09 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:09 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:09 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-11-05 03:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:09 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:09 --> Total execution time: 0.3680
INFO - 2020-11-05 03:23:09 --> Config Class Initialized
INFO - 2020-11-05 03:23:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:09 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:09 --> URI Class Initialized
INFO - 2020-11-05 03:23:09 --> Router Class Initialized
INFO - 2020-11-05 03:23:10 --> Output Class Initialized
INFO - 2020-11-05 03:23:10 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:10 --> Input Class Initialized
INFO - 2020-11-05 03:23:10 --> Language Class Initialized
INFO - 2020-11-05 03:23:10 --> Language Class Initialized
INFO - 2020-11-05 03:23:10 --> Config Class Initialized
INFO - 2020-11-05 03:23:10 --> Loader Class Initialized
INFO - 2020-11-05 03:23:10 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:10 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:10 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:10 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:10 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:10 --> Controller Class Initialized
INFO - 2020-11-05 03:23:13 --> Config Class Initialized
INFO - 2020-11-05 03:23:13 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:13 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:13 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:13 --> URI Class Initialized
INFO - 2020-11-05 03:23:13 --> Router Class Initialized
INFO - 2020-11-05 03:23:13 --> Output Class Initialized
INFO - 2020-11-05 03:23:13 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:13 --> Input Class Initialized
INFO - 2020-11-05 03:23:13 --> Language Class Initialized
INFO - 2020-11-05 03:23:13 --> Language Class Initialized
INFO - 2020-11-05 03:23:13 --> Config Class Initialized
INFO - 2020-11-05 03:23:13 --> Loader Class Initialized
INFO - 2020-11-05 03:23:13 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:13 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:13 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:13 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:13 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:13 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-05 03:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:13 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:13 --> Total execution time: 0.3561
INFO - 2020-11-05 03:23:13 --> Config Class Initialized
INFO - 2020-11-05 03:23:13 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:13 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:13 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:13 --> URI Class Initialized
INFO - 2020-11-05 03:23:13 --> Router Class Initialized
INFO - 2020-11-05 03:23:13 --> Output Class Initialized
INFO - 2020-11-05 03:23:14 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:14 --> Input Class Initialized
INFO - 2020-11-05 03:23:14 --> Language Class Initialized
INFO - 2020-11-05 03:23:14 --> Language Class Initialized
INFO - 2020-11-05 03:23:14 --> Config Class Initialized
INFO - 2020-11-05 03:23:14 --> Loader Class Initialized
INFO - 2020-11-05 03:23:14 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:14 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:14 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:14 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:14 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:14 --> Controller Class Initialized
INFO - 2020-11-05 03:23:18 --> Config Class Initialized
INFO - 2020-11-05 03:23:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:18 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:18 --> URI Class Initialized
INFO - 2020-11-05 03:23:18 --> Router Class Initialized
INFO - 2020-11-05 03:23:18 --> Output Class Initialized
INFO - 2020-11-05 03:23:18 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:18 --> Input Class Initialized
INFO - 2020-11-05 03:23:18 --> Language Class Initialized
INFO - 2020-11-05 03:23:18 --> Language Class Initialized
INFO - 2020-11-05 03:23:18 --> Config Class Initialized
INFO - 2020-11-05 03:23:18 --> Loader Class Initialized
INFO - 2020-11-05 03:23:18 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:18 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:18 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:18 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:18 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-05 03:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:18 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:18 --> Total execution time: 0.3320
INFO - 2020-11-05 03:23:18 --> Config Class Initialized
INFO - 2020-11-05 03:23:18 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:18 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:18 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:18 --> URI Class Initialized
INFO - 2020-11-05 03:23:18 --> Router Class Initialized
INFO - 2020-11-05 03:23:18 --> Output Class Initialized
INFO - 2020-11-05 03:23:18 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:18 --> Input Class Initialized
INFO - 2020-11-05 03:23:18 --> Language Class Initialized
INFO - 2020-11-05 03:23:18 --> Language Class Initialized
INFO - 2020-11-05 03:23:18 --> Config Class Initialized
INFO - 2020-11-05 03:23:18 --> Loader Class Initialized
INFO - 2020-11-05 03:23:18 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:18 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:18 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:18 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:18 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:18 --> Controller Class Initialized
INFO - 2020-11-05 03:23:24 --> Config Class Initialized
INFO - 2020-11-05 03:23:24 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:24 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:24 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:24 --> URI Class Initialized
INFO - 2020-11-05 03:23:24 --> Router Class Initialized
INFO - 2020-11-05 03:23:24 --> Output Class Initialized
INFO - 2020-11-05 03:23:24 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:24 --> Input Class Initialized
INFO - 2020-11-05 03:23:24 --> Language Class Initialized
INFO - 2020-11-05 03:23:24 --> Language Class Initialized
INFO - 2020-11-05 03:23:24 --> Config Class Initialized
INFO - 2020-11-05 03:23:24 --> Loader Class Initialized
INFO - 2020-11-05 03:23:24 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:24 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:24 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:24 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:24 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:24 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-11-05 03:23:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:24 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:24 --> Total execution time: 0.3795
INFO - 2020-11-05 03:23:24 --> Config Class Initialized
INFO - 2020-11-05 03:23:24 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:24 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:24 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:24 --> URI Class Initialized
INFO - 2020-11-05 03:23:24 --> Router Class Initialized
INFO - 2020-11-05 03:23:24 --> Output Class Initialized
INFO - 2020-11-05 03:23:24 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:24 --> Input Class Initialized
INFO - 2020-11-05 03:23:24 --> Language Class Initialized
INFO - 2020-11-05 03:23:24 --> Language Class Initialized
INFO - 2020-11-05 03:23:24 --> Config Class Initialized
INFO - 2020-11-05 03:23:24 --> Loader Class Initialized
INFO - 2020-11-05 03:23:24 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:24 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:24 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:24 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:24 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:24 --> Controller Class Initialized
INFO - 2020-11-05 03:23:32 --> Config Class Initialized
INFO - 2020-11-05 03:23:32 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:32 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:32 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:32 --> URI Class Initialized
INFO - 2020-11-05 03:23:32 --> Router Class Initialized
INFO - 2020-11-05 03:23:32 --> Output Class Initialized
INFO - 2020-11-05 03:23:32 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:32 --> Input Class Initialized
INFO - 2020-11-05 03:23:32 --> Language Class Initialized
INFO - 2020-11-05 03:23:32 --> Language Class Initialized
INFO - 2020-11-05 03:23:32 --> Config Class Initialized
INFO - 2020-11-05 03:23:32 --> Loader Class Initialized
INFO - 2020-11-05 03:23:32 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:32 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:32 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:32 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:32 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:32 --> Controller Class Initialized
INFO - 2020-11-05 03:23:32 --> Helper loaded: cookie_helper
INFO - 2020-11-05 03:23:32 --> Config Class Initialized
INFO - 2020-11-05 03:23:32 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:32 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:32 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:32 --> URI Class Initialized
INFO - 2020-11-05 03:23:32 --> Router Class Initialized
INFO - 2020-11-05 03:23:32 --> Output Class Initialized
INFO - 2020-11-05 03:23:32 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:32 --> Input Class Initialized
INFO - 2020-11-05 03:23:32 --> Language Class Initialized
INFO - 2020-11-05 03:23:32 --> Language Class Initialized
INFO - 2020-11-05 03:23:32 --> Config Class Initialized
INFO - 2020-11-05 03:23:32 --> Loader Class Initialized
INFO - 2020-11-05 03:23:32 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:32 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:32 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:32 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:32 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:32 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-05 03:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:32 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:32 --> Total execution time: 0.3195
INFO - 2020-11-05 03:23:42 --> Config Class Initialized
INFO - 2020-11-05 03:23:42 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:42 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:42 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:42 --> URI Class Initialized
INFO - 2020-11-05 03:23:42 --> Router Class Initialized
INFO - 2020-11-05 03:23:42 --> Output Class Initialized
INFO - 2020-11-05 03:23:42 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:42 --> Input Class Initialized
INFO - 2020-11-05 03:23:42 --> Language Class Initialized
INFO - 2020-11-05 03:23:42 --> Language Class Initialized
INFO - 2020-11-05 03:23:42 --> Config Class Initialized
INFO - 2020-11-05 03:23:42 --> Loader Class Initialized
INFO - 2020-11-05 03:23:42 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:42 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:42 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:42 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:42 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:43 --> Controller Class Initialized
INFO - 2020-11-05 03:23:43 --> Helper loaded: cookie_helper
INFO - 2020-11-05 03:23:43 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:43 --> Total execution time: 0.3988
INFO - 2020-11-05 03:23:43 --> Config Class Initialized
INFO - 2020-11-05 03:23:43 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:23:43 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:23:43 --> Utf8 Class Initialized
INFO - 2020-11-05 03:23:43 --> URI Class Initialized
INFO - 2020-11-05 03:23:43 --> Router Class Initialized
INFO - 2020-11-05 03:23:43 --> Output Class Initialized
INFO - 2020-11-05 03:23:43 --> Security Class Initialized
DEBUG - 2020-11-05 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:23:43 --> Input Class Initialized
INFO - 2020-11-05 03:23:43 --> Language Class Initialized
INFO - 2020-11-05 03:23:44 --> Language Class Initialized
INFO - 2020-11-05 03:23:44 --> Config Class Initialized
INFO - 2020-11-05 03:23:44 --> Loader Class Initialized
INFO - 2020-11-05 03:23:44 --> Helper loaded: url_helper
INFO - 2020-11-05 03:23:44 --> Helper loaded: file_helper
INFO - 2020-11-05 03:23:44 --> Helper loaded: form_helper
INFO - 2020-11-05 03:23:44 --> Helper loaded: my_helper
INFO - 2020-11-05 03:23:44 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:23:44 --> Controller Class Initialized
DEBUG - 2020-11-05 03:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-05 03:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:23:44 --> Final output sent to browser
DEBUG - 2020-11-05 03:23:44 --> Total execution time: 0.4367
INFO - 2020-11-05 03:24:09 --> Config Class Initialized
INFO - 2020-11-05 03:24:09 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:24:09 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:24:09 --> Utf8 Class Initialized
INFO - 2020-11-05 03:24:09 --> URI Class Initialized
INFO - 2020-11-05 03:24:09 --> Router Class Initialized
INFO - 2020-11-05 03:24:09 --> Output Class Initialized
INFO - 2020-11-05 03:24:09 --> Security Class Initialized
DEBUG - 2020-11-05 03:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:24:09 --> Input Class Initialized
INFO - 2020-11-05 03:24:09 --> Language Class Initialized
INFO - 2020-11-05 03:24:09 --> Language Class Initialized
INFO - 2020-11-05 03:24:09 --> Config Class Initialized
INFO - 2020-11-05 03:24:09 --> Loader Class Initialized
INFO - 2020-11-05 03:24:09 --> Helper loaded: url_helper
INFO - 2020-11-05 03:24:09 --> Helper loaded: file_helper
INFO - 2020-11-05 03:24:09 --> Helper loaded: form_helper
INFO - 2020-11-05 03:24:09 --> Helper loaded: my_helper
INFO - 2020-11-05 03:24:09 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:24:09 --> Controller Class Initialized
DEBUG - 2020-11-05 03:24:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 03:24:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:24:09 --> Final output sent to browser
DEBUG - 2020-11-05 03:24:09 --> Total execution time: 0.4183
INFO - 2020-11-05 03:24:11 --> Config Class Initialized
INFO - 2020-11-05 03:24:11 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:24:11 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:24:11 --> Utf8 Class Initialized
INFO - 2020-11-05 03:24:11 --> URI Class Initialized
INFO - 2020-11-05 03:24:11 --> Router Class Initialized
INFO - 2020-11-05 03:24:11 --> Output Class Initialized
INFO - 2020-11-05 03:24:11 --> Security Class Initialized
DEBUG - 2020-11-05 03:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:24:11 --> Input Class Initialized
INFO - 2020-11-05 03:24:11 --> Language Class Initialized
INFO - 2020-11-05 03:24:11 --> Language Class Initialized
INFO - 2020-11-05 03:24:11 --> Config Class Initialized
INFO - 2020-11-05 03:24:11 --> Loader Class Initialized
INFO - 2020-11-05 03:24:11 --> Helper loaded: url_helper
INFO - 2020-11-05 03:24:11 --> Helper loaded: file_helper
INFO - 2020-11-05 03:24:11 --> Helper loaded: form_helper
INFO - 2020-11-05 03:24:11 --> Helper loaded: my_helper
INFO - 2020-11-05 03:24:11 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:24:11 --> Controller Class Initialized
INFO - 2020-11-05 03:24:11 --> Final output sent to browser
DEBUG - 2020-11-05 03:24:11 --> Total execution time: 0.3075
INFO - 2020-11-05 03:24:17 --> Config Class Initialized
INFO - 2020-11-05 03:24:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:24:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:24:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:24:17 --> URI Class Initialized
INFO - 2020-11-05 03:24:17 --> Router Class Initialized
INFO - 2020-11-05 03:24:17 --> Output Class Initialized
INFO - 2020-11-05 03:24:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:24:17 --> Input Class Initialized
INFO - 2020-11-05 03:24:17 --> Language Class Initialized
INFO - 2020-11-05 03:24:17 --> Language Class Initialized
INFO - 2020-11-05 03:24:17 --> Config Class Initialized
INFO - 2020-11-05 03:24:17 --> Loader Class Initialized
INFO - 2020-11-05 03:24:17 --> Helper loaded: url_helper
INFO - 2020-11-05 03:24:17 --> Helper loaded: file_helper
INFO - 2020-11-05 03:24:17 --> Helper loaded: form_helper
INFO - 2020-11-05 03:24:17 --> Helper loaded: my_helper
INFO - 2020-11-05 03:24:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:24:17 --> Controller Class Initialized
ERROR - 2020-11-05 03:24:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '10', '1418', 'A', 'Memuaskan, aktif megikuti kegiatan Pramuka mingguan')
INFO - 2020-11-05 03:24:17 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 03:24:34 --> Config Class Initialized
INFO - 2020-11-05 03:24:34 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:24:34 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:24:34 --> Utf8 Class Initialized
INFO - 2020-11-05 03:24:34 --> URI Class Initialized
INFO - 2020-11-05 03:24:34 --> Router Class Initialized
INFO - 2020-11-05 03:24:34 --> Output Class Initialized
INFO - 2020-11-05 03:24:34 --> Security Class Initialized
DEBUG - 2020-11-05 03:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:24:34 --> Input Class Initialized
INFO - 2020-11-05 03:24:34 --> Language Class Initialized
INFO - 2020-11-05 03:24:34 --> Language Class Initialized
INFO - 2020-11-05 03:24:34 --> Config Class Initialized
INFO - 2020-11-05 03:24:34 --> Loader Class Initialized
INFO - 2020-11-05 03:24:34 --> Helper loaded: url_helper
INFO - 2020-11-05 03:24:34 --> Helper loaded: file_helper
INFO - 2020-11-05 03:24:34 --> Helper loaded: form_helper
INFO - 2020-11-05 03:24:34 --> Helper loaded: my_helper
INFO - 2020-11-05 03:24:34 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:24:34 --> Controller Class Initialized
DEBUG - 2020-11-05 03:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 03:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:24:34 --> Final output sent to browser
DEBUG - 2020-11-05 03:24:34 --> Total execution time: 0.3341
INFO - 2020-11-05 03:24:36 --> Config Class Initialized
INFO - 2020-11-05 03:24:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:24:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:24:36 --> Utf8 Class Initialized
INFO - 2020-11-05 03:24:36 --> URI Class Initialized
INFO - 2020-11-05 03:24:36 --> Router Class Initialized
INFO - 2020-11-05 03:24:36 --> Output Class Initialized
INFO - 2020-11-05 03:24:36 --> Security Class Initialized
DEBUG - 2020-11-05 03:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:24:36 --> Input Class Initialized
INFO - 2020-11-05 03:24:36 --> Language Class Initialized
INFO - 2020-11-05 03:24:36 --> Language Class Initialized
INFO - 2020-11-05 03:24:36 --> Config Class Initialized
INFO - 2020-11-05 03:24:36 --> Loader Class Initialized
INFO - 2020-11-05 03:24:36 --> Helper loaded: url_helper
INFO - 2020-11-05 03:24:36 --> Helper loaded: file_helper
INFO - 2020-11-05 03:24:36 --> Helper loaded: form_helper
INFO - 2020-11-05 03:24:36 --> Helper loaded: my_helper
INFO - 2020-11-05 03:24:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:24:36 --> Controller Class Initialized
INFO - 2020-11-05 03:24:36 --> Final output sent to browser
DEBUG - 2020-11-05 03:24:36 --> Total execution time: 0.2694
INFO - 2020-11-05 03:30:30 --> Config Class Initialized
INFO - 2020-11-05 03:30:30 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:30:30 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:30:30 --> Utf8 Class Initialized
INFO - 2020-11-05 03:30:30 --> URI Class Initialized
INFO - 2020-11-05 03:30:31 --> Router Class Initialized
INFO - 2020-11-05 03:30:31 --> Output Class Initialized
INFO - 2020-11-05 03:30:31 --> Security Class Initialized
DEBUG - 2020-11-05 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:30:31 --> Input Class Initialized
INFO - 2020-11-05 03:30:31 --> Language Class Initialized
INFO - 2020-11-05 03:30:31 --> Language Class Initialized
INFO - 2020-11-05 03:30:31 --> Config Class Initialized
INFO - 2020-11-05 03:30:31 --> Loader Class Initialized
INFO - 2020-11-05 03:30:31 --> Helper loaded: url_helper
INFO - 2020-11-05 03:30:31 --> Helper loaded: file_helper
INFO - 2020-11-05 03:30:31 --> Helper loaded: form_helper
INFO - 2020-11-05 03:30:31 --> Helper loaded: my_helper
INFO - 2020-11-05 03:30:31 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:30:31 --> Controller Class Initialized
DEBUG - 2020-11-05 03:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-05 03:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:30:31 --> Final output sent to browser
DEBUG - 2020-11-05 03:30:31 --> Total execution time: 0.3838
INFO - 2020-11-05 03:30:31 --> Config Class Initialized
INFO - 2020-11-05 03:30:31 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:30:31 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:30:31 --> Utf8 Class Initialized
INFO - 2020-11-05 03:30:31 --> URI Class Initialized
INFO - 2020-11-05 03:30:31 --> Router Class Initialized
INFO - 2020-11-05 03:30:31 --> Output Class Initialized
INFO - 2020-11-05 03:30:31 --> Security Class Initialized
DEBUG - 2020-11-05 03:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:30:31 --> Input Class Initialized
INFO - 2020-11-05 03:30:31 --> Language Class Initialized
INFO - 2020-11-05 03:30:31 --> Language Class Initialized
INFO - 2020-11-05 03:30:31 --> Config Class Initialized
INFO - 2020-11-05 03:30:31 --> Loader Class Initialized
INFO - 2020-11-05 03:30:31 --> Helper loaded: url_helper
INFO - 2020-11-05 03:30:31 --> Helper loaded: file_helper
INFO - 2020-11-05 03:30:31 --> Helper loaded: form_helper
INFO - 2020-11-05 03:30:31 --> Helper loaded: my_helper
INFO - 2020-11-05 03:30:31 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:30:31 --> Controller Class Initialized
INFO - 2020-11-05 03:30:53 --> Config Class Initialized
INFO - 2020-11-05 03:30:53 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:30:53 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:30:53 --> Utf8 Class Initialized
INFO - 2020-11-05 03:30:53 --> URI Class Initialized
INFO - 2020-11-05 03:30:53 --> Router Class Initialized
INFO - 2020-11-05 03:30:53 --> Output Class Initialized
INFO - 2020-11-05 03:30:53 --> Security Class Initialized
DEBUG - 2020-11-05 03:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:30:53 --> Input Class Initialized
INFO - 2020-11-05 03:30:53 --> Language Class Initialized
INFO - 2020-11-05 03:30:53 --> Language Class Initialized
INFO - 2020-11-05 03:30:53 --> Config Class Initialized
INFO - 2020-11-05 03:30:53 --> Loader Class Initialized
INFO - 2020-11-05 03:30:54 --> Helper loaded: url_helper
INFO - 2020-11-05 03:30:54 --> Helper loaded: file_helper
INFO - 2020-11-05 03:30:54 --> Helper loaded: form_helper
INFO - 2020-11-05 03:30:54 --> Helper loaded: my_helper
INFO - 2020-11-05 03:30:54 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:30:54 --> Controller Class Initialized
INFO - 2020-11-05 03:30:54 --> Final output sent to browser
DEBUG - 2020-11-05 03:30:54 --> Total execution time: 0.3196
INFO - 2020-11-05 03:30:54 --> Config Class Initialized
INFO - 2020-11-05 03:30:54 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:30:54 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:30:54 --> Utf8 Class Initialized
INFO - 2020-11-05 03:30:54 --> URI Class Initialized
INFO - 2020-11-05 03:30:54 --> Router Class Initialized
INFO - 2020-11-05 03:30:54 --> Output Class Initialized
INFO - 2020-11-05 03:30:54 --> Security Class Initialized
DEBUG - 2020-11-05 03:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:30:54 --> Input Class Initialized
INFO - 2020-11-05 03:30:54 --> Language Class Initialized
INFO - 2020-11-05 03:30:54 --> Language Class Initialized
INFO - 2020-11-05 03:30:54 --> Config Class Initialized
INFO - 2020-11-05 03:30:54 --> Loader Class Initialized
INFO - 2020-11-05 03:30:54 --> Helper loaded: url_helper
INFO - 2020-11-05 03:30:54 --> Helper loaded: file_helper
INFO - 2020-11-05 03:30:54 --> Helper loaded: form_helper
INFO - 2020-11-05 03:30:54 --> Helper loaded: my_helper
INFO - 2020-11-05 03:30:54 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:30:54 --> Controller Class Initialized
INFO - 2020-11-05 03:32:17 --> Config Class Initialized
INFO - 2020-11-05 03:32:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:32:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:32:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:32:17 --> URI Class Initialized
INFO - 2020-11-05 03:32:17 --> Router Class Initialized
INFO - 2020-11-05 03:32:17 --> Output Class Initialized
INFO - 2020-11-05 03:32:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:32:17 --> Input Class Initialized
INFO - 2020-11-05 03:32:17 --> Language Class Initialized
INFO - 2020-11-05 03:32:17 --> Language Class Initialized
INFO - 2020-11-05 03:32:17 --> Config Class Initialized
INFO - 2020-11-05 03:32:17 --> Loader Class Initialized
INFO - 2020-11-05 03:32:17 --> Helper loaded: url_helper
INFO - 2020-11-05 03:32:17 --> Helper loaded: file_helper
INFO - 2020-11-05 03:32:17 --> Helper loaded: form_helper
INFO - 2020-11-05 03:32:17 --> Helper loaded: my_helper
INFO - 2020-11-05 03:32:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:32:17 --> Controller Class Initialized
INFO - 2020-11-05 03:32:17 --> Final output sent to browser
DEBUG - 2020-11-05 03:32:17 --> Total execution time: 0.2974
INFO - 2020-11-05 03:32:17 --> Config Class Initialized
INFO - 2020-11-05 03:32:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:32:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:32:17 --> Utf8 Class Initialized
INFO - 2020-11-05 03:32:17 --> URI Class Initialized
INFO - 2020-11-05 03:32:17 --> Router Class Initialized
INFO - 2020-11-05 03:32:17 --> Output Class Initialized
INFO - 2020-11-05 03:32:17 --> Security Class Initialized
DEBUG - 2020-11-05 03:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:32:17 --> Input Class Initialized
INFO - 2020-11-05 03:32:17 --> Language Class Initialized
INFO - 2020-11-05 03:32:17 --> Language Class Initialized
INFO - 2020-11-05 03:32:17 --> Config Class Initialized
INFO - 2020-11-05 03:32:17 --> Loader Class Initialized
INFO - 2020-11-05 03:32:17 --> Helper loaded: url_helper
INFO - 2020-11-05 03:32:17 --> Helper loaded: file_helper
INFO - 2020-11-05 03:32:17 --> Helper loaded: form_helper
INFO - 2020-11-05 03:32:17 --> Helper loaded: my_helper
INFO - 2020-11-05 03:32:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:32:17 --> Controller Class Initialized
INFO - 2020-11-05 03:33:04 --> Config Class Initialized
INFO - 2020-11-05 03:33:04 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:33:04 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:33:04 --> Utf8 Class Initialized
INFO - 2020-11-05 03:33:04 --> URI Class Initialized
INFO - 2020-11-05 03:33:04 --> Router Class Initialized
INFO - 2020-11-05 03:33:04 --> Output Class Initialized
INFO - 2020-11-05 03:33:04 --> Security Class Initialized
DEBUG - 2020-11-05 03:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:33:04 --> Input Class Initialized
INFO - 2020-11-05 03:33:05 --> Language Class Initialized
INFO - 2020-11-05 03:33:05 --> Language Class Initialized
INFO - 2020-11-05 03:33:05 --> Config Class Initialized
INFO - 2020-11-05 03:33:05 --> Loader Class Initialized
INFO - 2020-11-05 03:33:05 --> Helper loaded: url_helper
INFO - 2020-11-05 03:33:05 --> Helper loaded: file_helper
INFO - 2020-11-05 03:33:05 --> Helper loaded: form_helper
INFO - 2020-11-05 03:33:05 --> Helper loaded: my_helper
INFO - 2020-11-05 03:33:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:33:05 --> Controller Class Initialized
INFO - 2020-11-05 03:33:05 --> Final output sent to browser
DEBUG - 2020-11-05 03:33:05 --> Total execution time: 0.3332
INFO - 2020-11-05 03:33:05 --> Config Class Initialized
INFO - 2020-11-05 03:33:05 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:33:05 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:33:05 --> Utf8 Class Initialized
INFO - 2020-11-05 03:33:05 --> URI Class Initialized
INFO - 2020-11-05 03:33:05 --> Router Class Initialized
INFO - 2020-11-05 03:33:05 --> Output Class Initialized
INFO - 2020-11-05 03:33:05 --> Security Class Initialized
DEBUG - 2020-11-05 03:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:33:05 --> Input Class Initialized
INFO - 2020-11-05 03:33:05 --> Language Class Initialized
INFO - 2020-11-05 03:33:05 --> Language Class Initialized
INFO - 2020-11-05 03:33:05 --> Config Class Initialized
INFO - 2020-11-05 03:33:05 --> Loader Class Initialized
INFO - 2020-11-05 03:33:05 --> Helper loaded: url_helper
INFO - 2020-11-05 03:33:05 --> Helper loaded: file_helper
INFO - 2020-11-05 03:33:05 --> Helper loaded: form_helper
INFO - 2020-11-05 03:33:05 --> Helper loaded: my_helper
INFO - 2020-11-05 03:33:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:33:05 --> Controller Class Initialized
INFO - 2020-11-05 03:35:47 --> Config Class Initialized
INFO - 2020-11-05 03:35:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:35:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:35:47 --> Utf8 Class Initialized
INFO - 2020-11-05 03:35:47 --> URI Class Initialized
INFO - 2020-11-05 03:35:47 --> Router Class Initialized
INFO - 2020-11-05 03:35:47 --> Output Class Initialized
INFO - 2020-11-05 03:35:47 --> Security Class Initialized
DEBUG - 2020-11-05 03:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:35:47 --> Input Class Initialized
INFO - 2020-11-05 03:35:47 --> Language Class Initialized
INFO - 2020-11-05 03:35:47 --> Language Class Initialized
INFO - 2020-11-05 03:35:47 --> Config Class Initialized
INFO - 2020-11-05 03:35:47 --> Loader Class Initialized
INFO - 2020-11-05 03:35:47 --> Helper loaded: url_helper
INFO - 2020-11-05 03:35:47 --> Helper loaded: file_helper
INFO - 2020-11-05 03:35:47 --> Helper loaded: form_helper
INFO - 2020-11-05 03:35:47 --> Helper loaded: my_helper
INFO - 2020-11-05 03:35:47 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:35:47 --> Controller Class Initialized
DEBUG - 2020-11-05 03:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-11-05 03:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:35:47 --> Final output sent to browser
DEBUG - 2020-11-05 03:35:47 --> Total execution time: 0.3672
INFO - 2020-11-05 03:35:49 --> Config Class Initialized
INFO - 2020-11-05 03:35:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:35:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:35:49 --> Utf8 Class Initialized
INFO - 2020-11-05 03:35:49 --> URI Class Initialized
INFO - 2020-11-05 03:35:49 --> Router Class Initialized
INFO - 2020-11-05 03:35:49 --> Output Class Initialized
INFO - 2020-11-05 03:35:49 --> Security Class Initialized
DEBUG - 2020-11-05 03:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:35:49 --> Input Class Initialized
INFO - 2020-11-05 03:35:49 --> Language Class Initialized
INFO - 2020-11-05 03:35:49 --> Language Class Initialized
INFO - 2020-11-05 03:35:49 --> Config Class Initialized
INFO - 2020-11-05 03:35:49 --> Loader Class Initialized
INFO - 2020-11-05 03:35:49 --> Helper loaded: url_helper
INFO - 2020-11-05 03:35:49 --> Helper loaded: file_helper
INFO - 2020-11-05 03:35:49 --> Helper loaded: form_helper
INFO - 2020-11-05 03:35:49 --> Helper loaded: my_helper
INFO - 2020-11-05 03:35:49 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:35:49 --> Controller Class Initialized
DEBUG - 2020-11-05 03:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-05 03:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:35:49 --> Final output sent to browser
DEBUG - 2020-11-05 03:35:49 --> Total execution time: 0.3656
INFO - 2020-11-05 03:35:51 --> Config Class Initialized
INFO - 2020-11-05 03:35:51 --> Hooks Class Initialized
DEBUG - 2020-11-05 03:35:51 --> UTF-8 Support Enabled
INFO - 2020-11-05 03:35:51 --> Utf8 Class Initialized
INFO - 2020-11-05 03:35:51 --> URI Class Initialized
INFO - 2020-11-05 03:35:51 --> Router Class Initialized
INFO - 2020-11-05 03:35:51 --> Output Class Initialized
INFO - 2020-11-05 03:35:51 --> Security Class Initialized
DEBUG - 2020-11-05 03:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 03:35:51 --> Input Class Initialized
INFO - 2020-11-05 03:35:51 --> Language Class Initialized
INFO - 2020-11-05 03:35:51 --> Language Class Initialized
INFO - 2020-11-05 03:35:51 --> Config Class Initialized
INFO - 2020-11-05 03:35:51 --> Loader Class Initialized
INFO - 2020-11-05 03:35:51 --> Helper loaded: url_helper
INFO - 2020-11-05 03:35:51 --> Helper loaded: file_helper
INFO - 2020-11-05 03:35:51 --> Helper loaded: form_helper
INFO - 2020-11-05 03:35:51 --> Helper loaded: my_helper
INFO - 2020-11-05 03:35:51 --> Database Driver Class Initialized
DEBUG - 2020-11-05 03:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 03:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 03:35:51 --> Controller Class Initialized
DEBUG - 2020-11-05 03:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-05 03:35:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 03:35:51 --> Final output sent to browser
DEBUG - 2020-11-05 03:35:51 --> Total execution time: 0.3645
INFO - 2020-11-05 04:29:04 --> Config Class Initialized
INFO - 2020-11-05 04:29:04 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:29:04 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:29:04 --> Utf8 Class Initialized
INFO - 2020-11-05 04:29:04 --> URI Class Initialized
INFO - 2020-11-05 04:29:04 --> Router Class Initialized
INFO - 2020-11-05 04:29:04 --> Output Class Initialized
INFO - 2020-11-05 04:29:04 --> Security Class Initialized
DEBUG - 2020-11-05 04:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:29:04 --> Input Class Initialized
INFO - 2020-11-05 04:29:04 --> Language Class Initialized
INFO - 2020-11-05 04:29:04 --> Language Class Initialized
INFO - 2020-11-05 04:29:04 --> Config Class Initialized
INFO - 2020-11-05 04:29:04 --> Loader Class Initialized
INFO - 2020-11-05 04:29:04 --> Helper loaded: url_helper
INFO - 2020-11-05 04:29:04 --> Helper loaded: file_helper
INFO - 2020-11-05 04:29:05 --> Helper loaded: form_helper
INFO - 2020-11-05 04:29:05 --> Helper loaded: my_helper
INFO - 2020-11-05 04:29:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:29:05 --> Controller Class Initialized
DEBUG - 2020-11-05 04:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 04:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:29:05 --> Final output sent to browser
DEBUG - 2020-11-05 04:29:05 --> Total execution time: 0.3447
INFO - 2020-11-05 04:29:11 --> Config Class Initialized
INFO - 2020-11-05 04:29:11 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:29:11 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:29:11 --> Utf8 Class Initialized
INFO - 2020-11-05 04:29:11 --> URI Class Initialized
INFO - 2020-11-05 04:29:11 --> Router Class Initialized
INFO - 2020-11-05 04:29:11 --> Output Class Initialized
INFO - 2020-11-05 04:29:11 --> Security Class Initialized
DEBUG - 2020-11-05 04:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:29:11 --> Input Class Initialized
INFO - 2020-11-05 04:29:11 --> Language Class Initialized
INFO - 2020-11-05 04:29:11 --> Language Class Initialized
INFO - 2020-11-05 04:29:11 --> Config Class Initialized
INFO - 2020-11-05 04:29:11 --> Loader Class Initialized
INFO - 2020-11-05 04:29:11 --> Helper loaded: url_helper
INFO - 2020-11-05 04:29:11 --> Helper loaded: file_helper
INFO - 2020-11-05 04:29:11 --> Helper loaded: form_helper
INFO - 2020-11-05 04:29:11 --> Helper loaded: my_helper
INFO - 2020-11-05 04:29:11 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:29:11 --> Controller Class Initialized
INFO - 2020-11-05 04:29:11 --> Final output sent to browser
DEBUG - 2020-11-05 04:29:11 --> Total execution time: 0.2640
INFO - 2020-11-05 04:32:45 --> Config Class Initialized
INFO - 2020-11-05 04:32:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:32:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:32:45 --> Utf8 Class Initialized
INFO - 2020-11-05 04:32:45 --> URI Class Initialized
INFO - 2020-11-05 04:32:45 --> Router Class Initialized
INFO - 2020-11-05 04:32:45 --> Output Class Initialized
INFO - 2020-11-05 04:32:45 --> Security Class Initialized
DEBUG - 2020-11-05 04:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:32:45 --> Input Class Initialized
INFO - 2020-11-05 04:32:45 --> Language Class Initialized
INFO - 2020-11-05 04:32:45 --> Language Class Initialized
INFO - 2020-11-05 04:32:45 --> Config Class Initialized
INFO - 2020-11-05 04:32:45 --> Loader Class Initialized
INFO - 2020-11-05 04:32:45 --> Helper loaded: url_helper
INFO - 2020-11-05 04:32:45 --> Helper loaded: file_helper
INFO - 2020-11-05 04:32:45 --> Helper loaded: form_helper
INFO - 2020-11-05 04:32:45 --> Helper loaded: my_helper
INFO - 2020-11-05 04:32:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:32:45 --> Controller Class Initialized
ERROR - 2020-11-05 04:32:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '10', '1418', 'B', 'Cukup memuaskan, aktif mengikuti kegiatan Pramuka mingguan')
INFO - 2020-11-05 04:32:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 04:35:44 --> Config Class Initialized
INFO - 2020-11-05 04:35:44 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:44 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:45 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:45 --> URI Class Initialized
INFO - 2020-11-05 04:35:45 --> Router Class Initialized
INFO - 2020-11-05 04:35:45 --> Output Class Initialized
INFO - 2020-11-05 04:35:45 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:45 --> Input Class Initialized
INFO - 2020-11-05 04:35:45 --> Language Class Initialized
INFO - 2020-11-05 04:35:45 --> Language Class Initialized
INFO - 2020-11-05 04:35:45 --> Config Class Initialized
INFO - 2020-11-05 04:35:45 --> Loader Class Initialized
INFO - 2020-11-05 04:35:45 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:45 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:45 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:45 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:45 --> Controller Class Initialized
DEBUG - 2020-11-05 04:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-05 04:35:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:35:45 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:45 --> Total execution time: 0.4250
INFO - 2020-11-05 04:35:47 --> Config Class Initialized
INFO - 2020-11-05 04:35:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:47 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:47 --> URI Class Initialized
INFO - 2020-11-05 04:35:47 --> Router Class Initialized
INFO - 2020-11-05 04:35:47 --> Output Class Initialized
INFO - 2020-11-05 04:35:47 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:47 --> Input Class Initialized
INFO - 2020-11-05 04:35:47 --> Language Class Initialized
INFO - 2020-11-05 04:35:47 --> Language Class Initialized
INFO - 2020-11-05 04:35:47 --> Config Class Initialized
INFO - 2020-11-05 04:35:47 --> Loader Class Initialized
INFO - 2020-11-05 04:35:47 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:47 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:47 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:47 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:47 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:47 --> Controller Class Initialized
INFO - 2020-11-05 04:35:47 --> Helper loaded: cookie_helper
INFO - 2020-11-05 04:35:48 --> Config Class Initialized
INFO - 2020-11-05 04:35:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:48 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:48 --> URI Class Initialized
INFO - 2020-11-05 04:35:48 --> Router Class Initialized
INFO - 2020-11-05 04:35:48 --> Output Class Initialized
INFO - 2020-11-05 04:35:48 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:48 --> Input Class Initialized
INFO - 2020-11-05 04:35:48 --> Language Class Initialized
INFO - 2020-11-05 04:35:48 --> Language Class Initialized
INFO - 2020-11-05 04:35:48 --> Config Class Initialized
INFO - 2020-11-05 04:35:48 --> Loader Class Initialized
INFO - 2020-11-05 04:35:48 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:48 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:48 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:48 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:48 --> Controller Class Initialized
DEBUG - 2020-11-05 04:35:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-05 04:35:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:35:48 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:48 --> Total execution time: 0.3483
INFO - 2020-11-05 04:35:53 --> Config Class Initialized
INFO - 2020-11-05 04:35:53 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:53 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:53 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:53 --> URI Class Initialized
INFO - 2020-11-05 04:35:53 --> Router Class Initialized
INFO - 2020-11-05 04:35:53 --> Output Class Initialized
INFO - 2020-11-05 04:35:53 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:53 --> Input Class Initialized
INFO - 2020-11-05 04:35:53 --> Language Class Initialized
INFO - 2020-11-05 04:35:53 --> Language Class Initialized
INFO - 2020-11-05 04:35:53 --> Config Class Initialized
INFO - 2020-11-05 04:35:53 --> Loader Class Initialized
INFO - 2020-11-05 04:35:53 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:53 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:53 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:53 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:53 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:53 --> Controller Class Initialized
INFO - 2020-11-05 04:35:53 --> Helper loaded: cookie_helper
INFO - 2020-11-05 04:35:53 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:53 --> Total execution time: 0.4047
INFO - 2020-11-05 04:35:54 --> Config Class Initialized
INFO - 2020-11-05 04:35:54 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:54 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:54 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:54 --> URI Class Initialized
INFO - 2020-11-05 04:35:54 --> Router Class Initialized
INFO - 2020-11-05 04:35:54 --> Output Class Initialized
INFO - 2020-11-05 04:35:54 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:54 --> Input Class Initialized
INFO - 2020-11-05 04:35:54 --> Language Class Initialized
INFO - 2020-11-05 04:35:54 --> Language Class Initialized
INFO - 2020-11-05 04:35:54 --> Config Class Initialized
INFO - 2020-11-05 04:35:54 --> Loader Class Initialized
INFO - 2020-11-05 04:35:54 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:54 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:54 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:54 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:54 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:54 --> Controller Class Initialized
DEBUG - 2020-11-05 04:35:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-05 04:35:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:35:54 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:54 --> Total execution time: 0.4378
INFO - 2020-11-05 04:35:55 --> Config Class Initialized
INFO - 2020-11-05 04:35:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:55 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:55 --> URI Class Initialized
INFO - 2020-11-05 04:35:55 --> Router Class Initialized
INFO - 2020-11-05 04:35:56 --> Output Class Initialized
INFO - 2020-11-05 04:35:56 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:56 --> Input Class Initialized
INFO - 2020-11-05 04:35:56 --> Language Class Initialized
INFO - 2020-11-05 04:35:56 --> Language Class Initialized
INFO - 2020-11-05 04:35:56 --> Config Class Initialized
INFO - 2020-11-05 04:35:56 --> Loader Class Initialized
INFO - 2020-11-05 04:35:56 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:56 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:56 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:56 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:56 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:56 --> Controller Class Initialized
DEBUG - 2020-11-05 04:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-05 04:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:35:56 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:56 --> Total execution time: 0.3914
INFO - 2020-11-05 04:35:57 --> Config Class Initialized
INFO - 2020-11-05 04:35:57 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:57 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:57 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:57 --> URI Class Initialized
INFO - 2020-11-05 04:35:57 --> Router Class Initialized
INFO - 2020-11-05 04:35:57 --> Output Class Initialized
INFO - 2020-11-05 04:35:57 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:57 --> Input Class Initialized
INFO - 2020-11-05 04:35:57 --> Language Class Initialized
INFO - 2020-11-05 04:35:57 --> Language Class Initialized
INFO - 2020-11-05 04:35:57 --> Config Class Initialized
INFO - 2020-11-05 04:35:57 --> Loader Class Initialized
INFO - 2020-11-05 04:35:57 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:57 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:57 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:57 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:57 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:57 --> Controller Class Initialized
DEBUG - 2020-11-05 04:35:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-05 04:35:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:35:57 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:57 --> Total execution time: 0.3837
INFO - 2020-11-05 04:35:57 --> Config Class Initialized
INFO - 2020-11-05 04:35:58 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:58 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:58 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:58 --> URI Class Initialized
INFO - 2020-11-05 04:35:58 --> Router Class Initialized
INFO - 2020-11-05 04:35:58 --> Output Class Initialized
INFO - 2020-11-05 04:35:58 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:58 --> Input Class Initialized
INFO - 2020-11-05 04:35:58 --> Language Class Initialized
INFO - 2020-11-05 04:35:58 --> Language Class Initialized
INFO - 2020-11-05 04:35:58 --> Config Class Initialized
INFO - 2020-11-05 04:35:58 --> Loader Class Initialized
INFO - 2020-11-05 04:35:58 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:58 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:58 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:58 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:58 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:58 --> Controller Class Initialized
INFO - 2020-11-05 04:35:58 --> Config Class Initialized
INFO - 2020-11-05 04:35:58 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:35:58 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:35:58 --> Utf8 Class Initialized
INFO - 2020-11-05 04:35:58 --> URI Class Initialized
INFO - 2020-11-05 04:35:59 --> Router Class Initialized
INFO - 2020-11-05 04:35:59 --> Output Class Initialized
INFO - 2020-11-05 04:35:59 --> Security Class Initialized
DEBUG - 2020-11-05 04:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:35:59 --> Input Class Initialized
INFO - 2020-11-05 04:35:59 --> Language Class Initialized
INFO - 2020-11-05 04:35:59 --> Language Class Initialized
INFO - 2020-11-05 04:35:59 --> Config Class Initialized
INFO - 2020-11-05 04:35:59 --> Loader Class Initialized
INFO - 2020-11-05 04:35:59 --> Helper loaded: url_helper
INFO - 2020-11-05 04:35:59 --> Helper loaded: file_helper
INFO - 2020-11-05 04:35:59 --> Helper loaded: form_helper
INFO - 2020-11-05 04:35:59 --> Helper loaded: my_helper
INFO - 2020-11-05 04:35:59 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:35:59 --> Controller Class Initialized
DEBUG - 2020-11-05 04:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-05 04:35:59 --> Final output sent to browser
DEBUG - 2020-11-05 04:35:59 --> Total execution time: 0.3595
INFO - 2020-11-05 04:36:45 --> Config Class Initialized
INFO - 2020-11-05 04:36:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:36:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:36:45 --> Utf8 Class Initialized
INFO - 2020-11-05 04:36:45 --> URI Class Initialized
INFO - 2020-11-05 04:36:45 --> Router Class Initialized
INFO - 2020-11-05 04:36:45 --> Output Class Initialized
INFO - 2020-11-05 04:36:45 --> Security Class Initialized
DEBUG - 2020-11-05 04:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:36:45 --> Input Class Initialized
INFO - 2020-11-05 04:36:45 --> Language Class Initialized
INFO - 2020-11-05 04:36:45 --> Language Class Initialized
INFO - 2020-11-05 04:36:45 --> Config Class Initialized
INFO - 2020-11-05 04:36:45 --> Loader Class Initialized
INFO - 2020-11-05 04:36:45 --> Helper loaded: url_helper
INFO - 2020-11-05 04:36:45 --> Helper loaded: file_helper
INFO - 2020-11-05 04:36:45 --> Helper loaded: form_helper
INFO - 2020-11-05 04:36:45 --> Helper loaded: my_helper
INFO - 2020-11-05 04:36:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:36:45 --> Controller Class Initialized
INFO - 2020-11-05 04:36:45 --> Helper loaded: cookie_helper
INFO - 2020-11-05 04:36:45 --> Config Class Initialized
INFO - 2020-11-05 04:36:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:36:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:36:45 --> Utf8 Class Initialized
INFO - 2020-11-05 04:36:45 --> URI Class Initialized
INFO - 2020-11-05 04:36:45 --> Router Class Initialized
INFO - 2020-11-05 04:36:45 --> Output Class Initialized
INFO - 2020-11-05 04:36:45 --> Security Class Initialized
DEBUG - 2020-11-05 04:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:36:45 --> Input Class Initialized
INFO - 2020-11-05 04:36:45 --> Language Class Initialized
INFO - 2020-11-05 04:36:45 --> Language Class Initialized
INFO - 2020-11-05 04:36:45 --> Config Class Initialized
INFO - 2020-11-05 04:36:45 --> Loader Class Initialized
INFO - 2020-11-05 04:36:45 --> Helper loaded: url_helper
INFO - 2020-11-05 04:36:45 --> Helper loaded: file_helper
INFO - 2020-11-05 04:36:45 --> Helper loaded: form_helper
INFO - 2020-11-05 04:36:45 --> Helper loaded: my_helper
INFO - 2020-11-05 04:36:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:36:45 --> Controller Class Initialized
DEBUG - 2020-11-05 04:36:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-05 04:36:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:36:45 --> Final output sent to browser
DEBUG - 2020-11-05 04:36:45 --> Total execution time: 0.3403
INFO - 2020-11-05 04:36:52 --> Config Class Initialized
INFO - 2020-11-05 04:36:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:36:52 --> Utf8 Class Initialized
INFO - 2020-11-05 04:36:52 --> URI Class Initialized
INFO - 2020-11-05 04:36:52 --> Router Class Initialized
INFO - 2020-11-05 04:36:52 --> Output Class Initialized
INFO - 2020-11-05 04:36:52 --> Security Class Initialized
DEBUG - 2020-11-05 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:36:52 --> Input Class Initialized
INFO - 2020-11-05 04:36:52 --> Language Class Initialized
INFO - 2020-11-05 04:36:52 --> Language Class Initialized
INFO - 2020-11-05 04:36:52 --> Config Class Initialized
INFO - 2020-11-05 04:36:52 --> Loader Class Initialized
INFO - 2020-11-05 04:36:52 --> Helper loaded: url_helper
INFO - 2020-11-05 04:36:52 --> Helper loaded: file_helper
INFO - 2020-11-05 04:36:52 --> Helper loaded: form_helper
INFO - 2020-11-05 04:36:52 --> Helper loaded: my_helper
INFO - 2020-11-05 04:36:52 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:36:52 --> Controller Class Initialized
INFO - 2020-11-05 04:36:52 --> Helper loaded: cookie_helper
INFO - 2020-11-05 04:36:52 --> Final output sent to browser
DEBUG - 2020-11-05 04:36:52 --> Total execution time: 0.4042
INFO - 2020-11-05 04:36:55 --> Config Class Initialized
INFO - 2020-11-05 04:36:55 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:36:55 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:36:55 --> Utf8 Class Initialized
INFO - 2020-11-05 04:36:55 --> URI Class Initialized
INFO - 2020-11-05 04:36:55 --> Router Class Initialized
INFO - 2020-11-05 04:36:55 --> Output Class Initialized
INFO - 2020-11-05 04:36:55 --> Security Class Initialized
DEBUG - 2020-11-05 04:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:36:55 --> Input Class Initialized
INFO - 2020-11-05 04:36:55 --> Language Class Initialized
INFO - 2020-11-05 04:36:55 --> Language Class Initialized
INFO - 2020-11-05 04:36:55 --> Config Class Initialized
INFO - 2020-11-05 04:36:55 --> Loader Class Initialized
INFO - 2020-11-05 04:36:55 --> Helper loaded: url_helper
INFO - 2020-11-05 04:36:55 --> Helper loaded: file_helper
INFO - 2020-11-05 04:36:55 --> Helper loaded: form_helper
INFO - 2020-11-05 04:36:55 --> Helper loaded: my_helper
INFO - 2020-11-05 04:36:55 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:36:55 --> Controller Class Initialized
DEBUG - 2020-11-05 04:36:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-05 04:36:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:36:55 --> Final output sent to browser
DEBUG - 2020-11-05 04:36:55 --> Total execution time: 0.4553
INFO - 2020-11-05 04:37:05 --> Config Class Initialized
INFO - 2020-11-05 04:37:05 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:05 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:05 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:05 --> URI Class Initialized
INFO - 2020-11-05 04:37:05 --> Router Class Initialized
INFO - 2020-11-05 04:37:05 --> Output Class Initialized
INFO - 2020-11-05 04:37:05 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:05 --> Input Class Initialized
INFO - 2020-11-05 04:37:05 --> Language Class Initialized
INFO - 2020-11-05 04:37:05 --> Language Class Initialized
INFO - 2020-11-05 04:37:05 --> Config Class Initialized
INFO - 2020-11-05 04:37:05 --> Loader Class Initialized
INFO - 2020-11-05 04:37:05 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:05 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:05 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:05 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:05 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:05 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-05 04:37:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:06 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:06 --> Total execution time: 0.3322
INFO - 2020-11-05 04:37:10 --> Config Class Initialized
INFO - 2020-11-05 04:37:10 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:10 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:10 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:10 --> URI Class Initialized
INFO - 2020-11-05 04:37:10 --> Router Class Initialized
INFO - 2020-11-05 04:37:10 --> Output Class Initialized
INFO - 2020-11-05 04:37:10 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:10 --> Input Class Initialized
INFO - 2020-11-05 04:37:10 --> Language Class Initialized
INFO - 2020-11-05 04:37:10 --> Language Class Initialized
INFO - 2020-11-05 04:37:10 --> Config Class Initialized
INFO - 2020-11-05 04:37:10 --> Loader Class Initialized
INFO - 2020-11-05 04:37:10 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:10 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:10 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:10 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:10 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:10 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-05 04:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:10 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:10 --> Total execution time: 0.3472
INFO - 2020-11-05 04:37:12 --> Config Class Initialized
INFO - 2020-11-05 04:37:12 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:12 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:12 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:12 --> URI Class Initialized
INFO - 2020-11-05 04:37:12 --> Router Class Initialized
INFO - 2020-11-05 04:37:12 --> Output Class Initialized
INFO - 2020-11-05 04:37:12 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:12 --> Input Class Initialized
INFO - 2020-11-05 04:37:12 --> Language Class Initialized
INFO - 2020-11-05 04:37:12 --> Language Class Initialized
INFO - 2020-11-05 04:37:12 --> Config Class Initialized
INFO - 2020-11-05 04:37:12 --> Loader Class Initialized
INFO - 2020-11-05 04:37:12 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:12 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:12 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:12 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:12 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:12 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-05 04:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:12 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:12 --> Total execution time: 0.3656
INFO - 2020-11-05 04:37:22 --> Config Class Initialized
INFO - 2020-11-05 04:37:22 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:22 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:22 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:22 --> URI Class Initialized
INFO - 2020-11-05 04:37:22 --> Router Class Initialized
INFO - 2020-11-05 04:37:22 --> Output Class Initialized
INFO - 2020-11-05 04:37:22 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:22 --> Input Class Initialized
INFO - 2020-11-05 04:37:22 --> Language Class Initialized
INFO - 2020-11-05 04:37:22 --> Language Class Initialized
INFO - 2020-11-05 04:37:22 --> Config Class Initialized
INFO - 2020-11-05 04:37:22 --> Loader Class Initialized
INFO - 2020-11-05 04:37:22 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:22 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:22 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:22 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:22 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:22 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-05 04:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:22 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:22 --> Total execution time: 0.3521
INFO - 2020-11-05 04:37:24 --> Config Class Initialized
INFO - 2020-11-05 04:37:24 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:24 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:24 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:24 --> URI Class Initialized
INFO - 2020-11-05 04:37:24 --> Router Class Initialized
INFO - 2020-11-05 04:37:24 --> Output Class Initialized
INFO - 2020-11-05 04:37:24 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:24 --> Input Class Initialized
INFO - 2020-11-05 04:37:25 --> Language Class Initialized
INFO - 2020-11-05 04:37:25 --> Language Class Initialized
INFO - 2020-11-05 04:37:25 --> Config Class Initialized
INFO - 2020-11-05 04:37:25 --> Loader Class Initialized
INFO - 2020-11-05 04:37:25 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:25 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:25 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:25 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:25 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:25 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-05 04:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:25 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:25 --> Total execution time: 0.4312
INFO - 2020-11-05 04:37:25 --> Config Class Initialized
INFO - 2020-11-05 04:37:25 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:25 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:25 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:25 --> URI Class Initialized
INFO - 2020-11-05 04:37:25 --> Router Class Initialized
INFO - 2020-11-05 04:37:25 --> Output Class Initialized
INFO - 2020-11-05 04:37:25 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:25 --> Input Class Initialized
INFO - 2020-11-05 04:37:25 --> Language Class Initialized
INFO - 2020-11-05 04:37:25 --> Language Class Initialized
INFO - 2020-11-05 04:37:25 --> Config Class Initialized
INFO - 2020-11-05 04:37:25 --> Loader Class Initialized
INFO - 2020-11-05 04:37:25 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:25 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:25 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:25 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:25 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:25 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-05 04:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:25 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:25 --> Total execution time: 0.3822
INFO - 2020-11-05 04:37:30 --> Config Class Initialized
INFO - 2020-11-05 04:37:30 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:30 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:30 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:30 --> URI Class Initialized
INFO - 2020-11-05 04:37:30 --> Router Class Initialized
INFO - 2020-11-05 04:37:30 --> Output Class Initialized
INFO - 2020-11-05 04:37:30 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:30 --> Input Class Initialized
INFO - 2020-11-05 04:37:30 --> Language Class Initialized
INFO - 2020-11-05 04:37:30 --> Language Class Initialized
INFO - 2020-11-05 04:37:30 --> Config Class Initialized
INFO - 2020-11-05 04:37:30 --> Loader Class Initialized
INFO - 2020-11-05 04:37:30 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:30 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:30 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:30 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:30 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:30 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 04:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:30 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:30 --> Total execution time: 0.3399
INFO - 2020-11-05 04:37:34 --> Config Class Initialized
INFO - 2020-11-05 04:37:34 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:34 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:34 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:34 --> URI Class Initialized
INFO - 2020-11-05 04:37:34 --> Router Class Initialized
INFO - 2020-11-05 04:37:34 --> Output Class Initialized
INFO - 2020-11-05 04:37:34 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:34 --> Input Class Initialized
INFO - 2020-11-05 04:37:34 --> Language Class Initialized
INFO - 2020-11-05 04:37:34 --> Language Class Initialized
INFO - 2020-11-05 04:37:34 --> Config Class Initialized
INFO - 2020-11-05 04:37:34 --> Loader Class Initialized
INFO - 2020-11-05 04:37:34 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:34 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:34 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:34 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:34 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:34 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-05 04:37:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:34 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:34 --> Total execution time: 0.3569
INFO - 2020-11-05 04:37:34 --> Config Class Initialized
INFO - 2020-11-05 04:37:34 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:34 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:34 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:34 --> URI Class Initialized
INFO - 2020-11-05 04:37:34 --> Router Class Initialized
INFO - 2020-11-05 04:37:34 --> Output Class Initialized
INFO - 2020-11-05 04:37:34 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:34 --> Input Class Initialized
INFO - 2020-11-05 04:37:34 --> Language Class Initialized
INFO - 2020-11-05 04:37:34 --> Language Class Initialized
INFO - 2020-11-05 04:37:34 --> Config Class Initialized
INFO - 2020-11-05 04:37:34 --> Loader Class Initialized
INFO - 2020-11-05 04:37:34 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:34 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:34 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:34 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:34 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:34 --> Controller Class Initialized
INFO - 2020-11-05 04:37:36 --> Config Class Initialized
INFO - 2020-11-05 04:37:36 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:36 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:36 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:36 --> URI Class Initialized
INFO - 2020-11-05 04:37:36 --> Router Class Initialized
INFO - 2020-11-05 04:37:36 --> Output Class Initialized
INFO - 2020-11-05 04:37:36 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:36 --> Input Class Initialized
INFO - 2020-11-05 04:37:36 --> Language Class Initialized
INFO - 2020-11-05 04:37:36 --> Language Class Initialized
INFO - 2020-11-05 04:37:36 --> Config Class Initialized
INFO - 2020-11-05 04:37:36 --> Loader Class Initialized
INFO - 2020-11-05 04:37:36 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:36 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:36 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:36 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:36 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:36 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-05 04:37:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:36 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:36 --> Total execution time: 0.3833
INFO - 2020-11-05 04:37:59 --> Config Class Initialized
INFO - 2020-11-05 04:37:59 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:37:59 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:37:59 --> Utf8 Class Initialized
INFO - 2020-11-05 04:37:59 --> URI Class Initialized
INFO - 2020-11-05 04:37:59 --> Router Class Initialized
INFO - 2020-11-05 04:37:59 --> Output Class Initialized
INFO - 2020-11-05 04:37:59 --> Security Class Initialized
DEBUG - 2020-11-05 04:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:37:59 --> Input Class Initialized
INFO - 2020-11-05 04:37:59 --> Language Class Initialized
INFO - 2020-11-05 04:37:59 --> Language Class Initialized
INFO - 2020-11-05 04:37:59 --> Config Class Initialized
INFO - 2020-11-05 04:37:59 --> Loader Class Initialized
INFO - 2020-11-05 04:37:59 --> Helper loaded: url_helper
INFO - 2020-11-05 04:37:59 --> Helper loaded: file_helper
INFO - 2020-11-05 04:37:59 --> Helper loaded: form_helper
INFO - 2020-11-05 04:37:59 --> Helper loaded: my_helper
INFO - 2020-11-05 04:37:59 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:37:59 --> Controller Class Initialized
DEBUG - 2020-11-05 04:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 04:37:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:37:59 --> Final output sent to browser
DEBUG - 2020-11-05 04:37:59 --> Total execution time: 0.3257
INFO - 2020-11-05 04:38:34 --> Config Class Initialized
INFO - 2020-11-05 04:38:34 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:38:34 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:38:34 --> Utf8 Class Initialized
INFO - 2020-11-05 04:38:34 --> URI Class Initialized
INFO - 2020-11-05 04:38:34 --> Router Class Initialized
INFO - 2020-11-05 04:38:34 --> Output Class Initialized
INFO - 2020-11-05 04:38:34 --> Security Class Initialized
DEBUG - 2020-11-05 04:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:38:34 --> Input Class Initialized
INFO - 2020-11-05 04:38:34 --> Language Class Initialized
INFO - 2020-11-05 04:38:34 --> Language Class Initialized
INFO - 2020-11-05 04:38:34 --> Config Class Initialized
INFO - 2020-11-05 04:38:34 --> Loader Class Initialized
INFO - 2020-11-05 04:38:34 --> Helper loaded: url_helper
INFO - 2020-11-05 04:38:34 --> Helper loaded: file_helper
INFO - 2020-11-05 04:38:34 --> Helper loaded: form_helper
INFO - 2020-11-05 04:38:34 --> Helper loaded: my_helper
INFO - 2020-11-05 04:38:34 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:38:34 --> Controller Class Initialized
DEBUG - 2020-11-05 04:38:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 04:38:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:38:34 --> Final output sent to browser
DEBUG - 2020-11-05 04:38:34 --> Total execution time: 0.3361
INFO - 2020-11-05 04:38:35 --> Config Class Initialized
INFO - 2020-11-05 04:38:35 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:38:35 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:38:35 --> Utf8 Class Initialized
INFO - 2020-11-05 04:38:35 --> URI Class Initialized
INFO - 2020-11-05 04:38:35 --> Router Class Initialized
INFO - 2020-11-05 04:38:35 --> Output Class Initialized
INFO - 2020-11-05 04:38:35 --> Security Class Initialized
DEBUG - 2020-11-05 04:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:38:35 --> Input Class Initialized
INFO - 2020-11-05 04:38:35 --> Language Class Initialized
INFO - 2020-11-05 04:38:35 --> Language Class Initialized
INFO - 2020-11-05 04:38:35 --> Config Class Initialized
INFO - 2020-11-05 04:38:35 --> Loader Class Initialized
INFO - 2020-11-05 04:38:35 --> Helper loaded: url_helper
INFO - 2020-11-05 04:38:35 --> Helper loaded: file_helper
INFO - 2020-11-05 04:38:35 --> Helper loaded: form_helper
INFO - 2020-11-05 04:38:35 --> Helper loaded: my_helper
INFO - 2020-11-05 04:38:35 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:38:36 --> Controller Class Initialized
INFO - 2020-11-05 04:38:36 --> Final output sent to browser
DEBUG - 2020-11-05 04:38:36 --> Total execution time: 0.2983
INFO - 2020-11-05 04:38:41 --> Config Class Initialized
INFO - 2020-11-05 04:38:41 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:38:41 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:38:41 --> Utf8 Class Initialized
INFO - 2020-11-05 04:38:41 --> URI Class Initialized
INFO - 2020-11-05 04:38:41 --> Router Class Initialized
INFO - 2020-11-05 04:38:41 --> Output Class Initialized
INFO - 2020-11-05 04:38:41 --> Security Class Initialized
DEBUG - 2020-11-05 04:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:38:41 --> Input Class Initialized
INFO - 2020-11-05 04:38:41 --> Language Class Initialized
INFO - 2020-11-05 04:38:41 --> Language Class Initialized
INFO - 2020-11-05 04:38:41 --> Config Class Initialized
INFO - 2020-11-05 04:38:41 --> Loader Class Initialized
INFO - 2020-11-05 04:38:41 --> Helper loaded: url_helper
INFO - 2020-11-05 04:38:41 --> Helper loaded: file_helper
INFO - 2020-11-05 04:38:41 --> Helper loaded: form_helper
INFO - 2020-11-05 04:38:41 --> Helper loaded: my_helper
INFO - 2020-11-05 04:38:41 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:38:41 --> Controller Class Initialized
ERROR - 2020-11-05 04:38:41 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '10', '1418', 'B', 'Cukup memuaskan, aktif mengikuti kegiatan Pramuka mingguan')
INFO - 2020-11-05 04:38:41 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 04:39:15 --> Config Class Initialized
INFO - 2020-11-05 04:39:15 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:15 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:15 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:15 --> URI Class Initialized
INFO - 2020-11-05 04:39:15 --> Router Class Initialized
INFO - 2020-11-05 04:39:15 --> Output Class Initialized
INFO - 2020-11-05 04:39:15 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:15 --> Input Class Initialized
INFO - 2020-11-05 04:39:15 --> Language Class Initialized
INFO - 2020-11-05 04:39:15 --> Language Class Initialized
INFO - 2020-11-05 04:39:15 --> Config Class Initialized
INFO - 2020-11-05 04:39:15 --> Loader Class Initialized
INFO - 2020-11-05 04:39:15 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:15 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:15 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:15 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:15 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:15 --> Controller Class Initialized
DEBUG - 2020-11-05 04:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 04:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:39:15 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:15 --> Total execution time: 0.3252
INFO - 2020-11-05 04:39:17 --> Config Class Initialized
INFO - 2020-11-05 04:39:17 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:17 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:17 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:17 --> URI Class Initialized
INFO - 2020-11-05 04:39:17 --> Router Class Initialized
INFO - 2020-11-05 04:39:17 --> Output Class Initialized
INFO - 2020-11-05 04:39:17 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:17 --> Input Class Initialized
INFO - 2020-11-05 04:39:17 --> Language Class Initialized
INFO - 2020-11-05 04:39:17 --> Language Class Initialized
INFO - 2020-11-05 04:39:17 --> Config Class Initialized
INFO - 2020-11-05 04:39:17 --> Loader Class Initialized
INFO - 2020-11-05 04:39:17 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:17 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:17 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:17 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:17 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:17 --> Controller Class Initialized
INFO - 2020-11-05 04:39:17 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:17 --> Total execution time: 0.3111
INFO - 2020-11-05 04:39:25 --> Config Class Initialized
INFO - 2020-11-05 04:39:25 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:25 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:25 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:25 --> URI Class Initialized
INFO - 2020-11-05 04:39:25 --> Router Class Initialized
INFO - 2020-11-05 04:39:25 --> Output Class Initialized
INFO - 2020-11-05 04:39:25 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:25 --> Input Class Initialized
INFO - 2020-11-05 04:39:25 --> Language Class Initialized
INFO - 2020-11-05 04:39:25 --> Language Class Initialized
INFO - 2020-11-05 04:39:25 --> Config Class Initialized
INFO - 2020-11-05 04:39:25 --> Loader Class Initialized
INFO - 2020-11-05 04:39:25 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:25 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:25 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:25 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:25 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:25 --> Controller Class Initialized
ERROR - 2020-11-05 04:39:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '10', '1418', 'B', 'Cukup memuaskan, aktif mengikuti kegiatan Pramuka mingguan')
INFO - 2020-11-05 04:39:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-05 04:39:41 --> Config Class Initialized
INFO - 2020-11-05 04:39:41 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:41 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:41 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:41 --> URI Class Initialized
INFO - 2020-11-05 04:39:41 --> Router Class Initialized
INFO - 2020-11-05 04:39:41 --> Output Class Initialized
INFO - 2020-11-05 04:39:41 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:41 --> Input Class Initialized
INFO - 2020-11-05 04:39:41 --> Language Class Initialized
INFO - 2020-11-05 04:39:41 --> Language Class Initialized
INFO - 2020-11-05 04:39:41 --> Config Class Initialized
INFO - 2020-11-05 04:39:41 --> Loader Class Initialized
INFO - 2020-11-05 04:39:41 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:41 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:41 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:41 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:41 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:41 --> Controller Class Initialized
DEBUG - 2020-11-05 04:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-05 04:39:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-05 04:39:41 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:41 --> Total execution time: 0.4314
INFO - 2020-11-05 04:39:44 --> Config Class Initialized
INFO - 2020-11-05 04:39:44 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:44 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:44 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:44 --> URI Class Initialized
INFO - 2020-11-05 04:39:44 --> Router Class Initialized
INFO - 2020-11-05 04:39:44 --> Output Class Initialized
INFO - 2020-11-05 04:39:44 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:44 --> Input Class Initialized
INFO - 2020-11-05 04:39:44 --> Language Class Initialized
INFO - 2020-11-05 04:39:44 --> Language Class Initialized
INFO - 2020-11-05 04:39:44 --> Config Class Initialized
INFO - 2020-11-05 04:39:44 --> Loader Class Initialized
INFO - 2020-11-05 04:39:44 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:44 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:44 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:44 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:44 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:44 --> Controller Class Initialized
INFO - 2020-11-05 04:39:44 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:44 --> Total execution time: 0.2811
INFO - 2020-11-05 04:39:45 --> Config Class Initialized
INFO - 2020-11-05 04:39:45 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:45 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:45 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:45 --> URI Class Initialized
INFO - 2020-11-05 04:39:45 --> Router Class Initialized
INFO - 2020-11-05 04:39:45 --> Output Class Initialized
INFO - 2020-11-05 04:39:45 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:45 --> Input Class Initialized
INFO - 2020-11-05 04:39:45 --> Language Class Initialized
INFO - 2020-11-05 04:39:45 --> Language Class Initialized
INFO - 2020-11-05 04:39:45 --> Config Class Initialized
INFO - 2020-11-05 04:39:45 --> Loader Class Initialized
INFO - 2020-11-05 04:39:45 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:45 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:45 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:45 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:45 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:45 --> Controller Class Initialized
INFO - 2020-11-05 04:39:45 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:45 --> Total execution time: 0.3054
INFO - 2020-11-05 04:39:46 --> Config Class Initialized
INFO - 2020-11-05 04:39:46 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:46 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:46 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:46 --> URI Class Initialized
INFO - 2020-11-05 04:39:46 --> Router Class Initialized
INFO - 2020-11-05 04:39:46 --> Output Class Initialized
INFO - 2020-11-05 04:39:46 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:46 --> Input Class Initialized
INFO - 2020-11-05 04:39:46 --> Language Class Initialized
INFO - 2020-11-05 04:39:46 --> Language Class Initialized
INFO - 2020-11-05 04:39:46 --> Config Class Initialized
INFO - 2020-11-05 04:39:46 --> Loader Class Initialized
INFO - 2020-11-05 04:39:46 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:46 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:46 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:46 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:46 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:46 --> Controller Class Initialized
INFO - 2020-11-05 04:39:46 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:47 --> Total execution time: 0.2941
INFO - 2020-11-05 04:39:47 --> Config Class Initialized
INFO - 2020-11-05 04:39:47 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:47 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:47 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:47 --> URI Class Initialized
INFO - 2020-11-05 04:39:47 --> Router Class Initialized
INFO - 2020-11-05 04:39:47 --> Output Class Initialized
INFO - 2020-11-05 04:39:47 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:47 --> Input Class Initialized
INFO - 2020-11-05 04:39:47 --> Language Class Initialized
INFO - 2020-11-05 04:39:47 --> Language Class Initialized
INFO - 2020-11-05 04:39:47 --> Config Class Initialized
INFO - 2020-11-05 04:39:47 --> Loader Class Initialized
INFO - 2020-11-05 04:39:47 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:47 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:47 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:47 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:47 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:47 --> Controller Class Initialized
INFO - 2020-11-05 04:39:47 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:47 --> Total execution time: 0.3120
INFO - 2020-11-05 04:39:48 --> Config Class Initialized
INFO - 2020-11-05 04:39:48 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:48 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:48 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:48 --> URI Class Initialized
INFO - 2020-11-05 04:39:48 --> Router Class Initialized
INFO - 2020-11-05 04:39:48 --> Output Class Initialized
INFO - 2020-11-05 04:39:48 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:48 --> Input Class Initialized
INFO - 2020-11-05 04:39:48 --> Language Class Initialized
INFO - 2020-11-05 04:39:48 --> Language Class Initialized
INFO - 2020-11-05 04:39:48 --> Config Class Initialized
INFO - 2020-11-05 04:39:48 --> Loader Class Initialized
INFO - 2020-11-05 04:39:48 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:48 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:48 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:48 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:48 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:48 --> Controller Class Initialized
INFO - 2020-11-05 04:39:48 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:48 --> Total execution time: 0.3001
INFO - 2020-11-05 04:39:49 --> Config Class Initialized
INFO - 2020-11-05 04:39:49 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:49 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:49 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:49 --> URI Class Initialized
INFO - 2020-11-05 04:39:49 --> Router Class Initialized
INFO - 2020-11-05 04:39:49 --> Output Class Initialized
INFO - 2020-11-05 04:39:49 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:49 --> Input Class Initialized
INFO - 2020-11-05 04:39:49 --> Language Class Initialized
INFO - 2020-11-05 04:39:49 --> Language Class Initialized
INFO - 2020-11-05 04:39:49 --> Config Class Initialized
INFO - 2020-11-05 04:39:49 --> Loader Class Initialized
INFO - 2020-11-05 04:39:49 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:49 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:49 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:49 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:49 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:49 --> Controller Class Initialized
INFO - 2020-11-05 04:39:49 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:49 --> Total execution time: 0.3068
INFO - 2020-11-05 04:39:50 --> Config Class Initialized
INFO - 2020-11-05 04:39:50 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:50 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:50 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:50 --> URI Class Initialized
INFO - 2020-11-05 04:39:50 --> Router Class Initialized
INFO - 2020-11-05 04:39:50 --> Output Class Initialized
INFO - 2020-11-05 04:39:50 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:50 --> Input Class Initialized
INFO - 2020-11-05 04:39:50 --> Language Class Initialized
INFO - 2020-11-05 04:39:50 --> Language Class Initialized
INFO - 2020-11-05 04:39:50 --> Config Class Initialized
INFO - 2020-11-05 04:39:50 --> Loader Class Initialized
INFO - 2020-11-05 04:39:50 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:50 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:50 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:50 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:50 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:50 --> Controller Class Initialized
INFO - 2020-11-05 04:39:50 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:50 --> Total execution time: 0.2908
INFO - 2020-11-05 04:39:52 --> Config Class Initialized
INFO - 2020-11-05 04:39:52 --> Hooks Class Initialized
DEBUG - 2020-11-05 04:39:52 --> UTF-8 Support Enabled
INFO - 2020-11-05 04:39:52 --> Utf8 Class Initialized
INFO - 2020-11-05 04:39:52 --> URI Class Initialized
INFO - 2020-11-05 04:39:52 --> Router Class Initialized
INFO - 2020-11-05 04:39:52 --> Output Class Initialized
INFO - 2020-11-05 04:39:52 --> Security Class Initialized
DEBUG - 2020-11-05 04:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-05 04:39:52 --> Input Class Initialized
INFO - 2020-11-05 04:39:52 --> Language Class Initialized
INFO - 2020-11-05 04:39:52 --> Language Class Initialized
INFO - 2020-11-05 04:39:52 --> Config Class Initialized
INFO - 2020-11-05 04:39:52 --> Loader Class Initialized
INFO - 2020-11-05 04:39:52 --> Helper loaded: url_helper
INFO - 2020-11-05 04:39:52 --> Helper loaded: file_helper
INFO - 2020-11-05 04:39:52 --> Helper loaded: form_helper
INFO - 2020-11-05 04:39:52 --> Helper loaded: my_helper
INFO - 2020-11-05 04:39:52 --> Database Driver Class Initialized
DEBUG - 2020-11-05 04:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-05 04:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-05 04:39:52 --> Controller Class Initialized
INFO - 2020-11-05 04:39:52 --> Final output sent to browser
DEBUG - 2020-11-05 04:39:52 --> Total execution time: 0.2890
