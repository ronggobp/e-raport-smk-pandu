<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-23 01:32:13 --> Config Class Initialized
INFO - 2021-01-23 01:32:13 --> Hooks Class Initialized
DEBUG - 2021-01-23 01:32:13 --> UTF-8 Support Enabled
INFO - 2021-01-23 01:32:13 --> Utf8 Class Initialized
INFO - 2021-01-23 01:32:13 --> URI Class Initialized
DEBUG - 2021-01-23 01:32:13 --> No URI present. Default controller set.
INFO - 2021-01-23 01:32:13 --> Router Class Initialized
INFO - 2021-01-23 01:32:13 --> Output Class Initialized
INFO - 2021-01-23 01:32:13 --> Security Class Initialized
DEBUG - 2021-01-23 01:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-23 01:32:13 --> Input Class Initialized
INFO - 2021-01-23 01:32:13 --> Language Class Initialized
INFO - 2021-01-23 01:32:13 --> Language Class Initialized
INFO - 2021-01-23 01:32:13 --> Config Class Initialized
INFO - 2021-01-23 01:32:13 --> Loader Class Initialized
INFO - 2021-01-23 01:32:13 --> Helper loaded: url_helper
INFO - 2021-01-23 01:32:13 --> Helper loaded: file_helper
INFO - 2021-01-23 01:32:13 --> Helper loaded: form_helper
INFO - 2021-01-23 01:32:13 --> Helper loaded: my_helper
INFO - 2021-01-23 01:32:13 --> Database Driver Class Initialized
DEBUG - 2021-01-23 01:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-23 01:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-23 01:32:13 --> Controller Class Initialized
INFO - 2021-01-23 01:32:14 --> Config Class Initialized
INFO - 2021-01-23 01:32:14 --> Hooks Class Initialized
DEBUG - 2021-01-23 01:32:14 --> UTF-8 Support Enabled
INFO - 2021-01-23 01:32:14 --> Utf8 Class Initialized
INFO - 2021-01-23 01:32:14 --> URI Class Initialized
INFO - 2021-01-23 01:32:14 --> Router Class Initialized
INFO - 2021-01-23 01:32:14 --> Output Class Initialized
INFO - 2021-01-23 01:32:14 --> Security Class Initialized
DEBUG - 2021-01-23 01:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-23 01:32:14 --> Input Class Initialized
INFO - 2021-01-23 01:32:14 --> Language Class Initialized
INFO - 2021-01-23 01:32:14 --> Language Class Initialized
INFO - 2021-01-23 01:32:14 --> Config Class Initialized
INFO - 2021-01-23 01:32:14 --> Loader Class Initialized
INFO - 2021-01-23 01:32:14 --> Helper loaded: url_helper
INFO - 2021-01-23 01:32:14 --> Helper loaded: file_helper
INFO - 2021-01-23 01:32:14 --> Helper loaded: form_helper
INFO - 2021-01-23 01:32:14 --> Helper loaded: my_helper
INFO - 2021-01-23 01:32:14 --> Database Driver Class Initialized
DEBUG - 2021-01-23 01:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-23 01:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-23 01:32:14 --> Controller Class Initialized
DEBUG - 2021-01-23 01:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-23 01:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-23 01:32:15 --> Final output sent to browser
DEBUG - 2021-01-23 01:32:15 --> Total execution time: 0.9375
INFO - 2021-01-23 01:32:21 --> Config Class Initialized
INFO - 2021-01-23 01:32:21 --> Hooks Class Initialized
DEBUG - 2021-01-23 01:32:21 --> UTF-8 Support Enabled
INFO - 2021-01-23 01:32:21 --> Utf8 Class Initialized
INFO - 2021-01-23 01:32:21 --> URI Class Initialized
INFO - 2021-01-23 01:32:21 --> Router Class Initialized
INFO - 2021-01-23 01:32:21 --> Output Class Initialized
INFO - 2021-01-23 01:32:21 --> Security Class Initialized
DEBUG - 2021-01-23 01:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-23 01:32:21 --> Input Class Initialized
INFO - 2021-01-23 01:32:21 --> Language Class Initialized
INFO - 2021-01-23 01:32:21 --> Language Class Initialized
INFO - 2021-01-23 01:32:21 --> Config Class Initialized
INFO - 2021-01-23 01:32:21 --> Loader Class Initialized
INFO - 2021-01-23 01:32:21 --> Helper loaded: url_helper
INFO - 2021-01-23 01:32:21 --> Helper loaded: file_helper
INFO - 2021-01-23 01:32:21 --> Helper loaded: form_helper
INFO - 2021-01-23 01:32:21 --> Helper loaded: my_helper
INFO - 2021-01-23 01:32:21 --> Database Driver Class Initialized
DEBUG - 2021-01-23 01:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-23 01:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-23 01:32:21 --> Controller Class Initialized
INFO - 2021-01-23 01:32:21 --> Helper loaded: cookie_helper
INFO - 2021-01-23 01:32:21 --> Final output sent to browser
DEBUG - 2021-01-23 01:32:21 --> Total execution time: 0.5435
INFO - 2021-01-23 01:32:22 --> Config Class Initialized
INFO - 2021-01-23 01:32:22 --> Hooks Class Initialized
DEBUG - 2021-01-23 01:32:22 --> UTF-8 Support Enabled
INFO - 2021-01-23 01:32:22 --> Utf8 Class Initialized
INFO - 2021-01-23 01:32:22 --> URI Class Initialized
INFO - 2021-01-23 01:32:22 --> Router Class Initialized
INFO - 2021-01-23 01:32:22 --> Output Class Initialized
INFO - 2021-01-23 01:32:22 --> Security Class Initialized
DEBUG - 2021-01-23 01:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-23 01:32:22 --> Input Class Initialized
INFO - 2021-01-23 01:32:22 --> Language Class Initialized
INFO - 2021-01-23 01:32:22 --> Language Class Initialized
INFO - 2021-01-23 01:32:22 --> Config Class Initialized
INFO - 2021-01-23 01:32:22 --> Loader Class Initialized
INFO - 2021-01-23 01:32:22 --> Helper loaded: url_helper
INFO - 2021-01-23 01:32:22 --> Helper loaded: file_helper
INFO - 2021-01-23 01:32:22 --> Helper loaded: form_helper
INFO - 2021-01-23 01:32:22 --> Helper loaded: my_helper
INFO - 2021-01-23 01:32:22 --> Database Driver Class Initialized
DEBUG - 2021-01-23 01:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-23 01:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-23 01:32:22 --> Controller Class Initialized
DEBUG - 2021-01-23 01:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-23 01:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-23 01:32:23 --> Final output sent to browser
DEBUG - 2021-01-23 01:32:23 --> Total execution time: 0.9571
INFO - 2021-01-23 01:32:25 --> Config Class Initialized
INFO - 2021-01-23 01:32:25 --> Hooks Class Initialized
DEBUG - 2021-01-23 01:32:25 --> UTF-8 Support Enabled
INFO - 2021-01-23 01:32:25 --> Utf8 Class Initialized
INFO - 2021-01-23 01:32:25 --> URI Class Initialized
INFO - 2021-01-23 01:32:25 --> Router Class Initialized
INFO - 2021-01-23 01:32:25 --> Output Class Initialized
INFO - 2021-01-23 01:32:25 --> Security Class Initialized
DEBUG - 2021-01-23 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-23 01:32:25 --> Input Class Initialized
INFO - 2021-01-23 01:32:25 --> Language Class Initialized
INFO - 2021-01-23 01:32:25 --> Language Class Initialized
INFO - 2021-01-23 01:32:25 --> Config Class Initialized
INFO - 2021-01-23 01:32:25 --> Loader Class Initialized
INFO - 2021-01-23 01:32:25 --> Helper loaded: url_helper
INFO - 2021-01-23 01:32:25 --> Helper loaded: file_helper
INFO - 2021-01-23 01:32:25 --> Helper loaded: form_helper
INFO - 2021-01-23 01:32:25 --> Helper loaded: my_helper
INFO - 2021-01-23 01:32:25 --> Database Driver Class Initialized
DEBUG - 2021-01-23 01:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-23 01:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-23 01:32:26 --> Controller Class Initialized
DEBUG - 2021-01-23 01:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-01-23 01:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-23 01:32:26 --> Final output sent to browser
DEBUG - 2021-01-23 01:32:26 --> Total execution time: 0.6764
