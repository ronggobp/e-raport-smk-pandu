<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-25 07:02:54 --> Config Class Initialized
INFO - 2021-12-25 07:02:54 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:02:54 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:02:54 --> Utf8 Class Initialized
INFO - 2021-12-25 07:02:54 --> URI Class Initialized
DEBUG - 2021-12-25 07:02:54 --> No URI present. Default controller set.
INFO - 2021-12-25 07:02:54 --> Router Class Initialized
INFO - 2021-12-25 07:02:54 --> Output Class Initialized
INFO - 2021-12-25 07:02:54 --> Security Class Initialized
DEBUG - 2021-12-25 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:02:54 --> Input Class Initialized
INFO - 2021-12-25 07:02:54 --> Language Class Initialized
INFO - 2021-12-25 07:02:54 --> Language Class Initialized
INFO - 2021-12-25 07:02:54 --> Config Class Initialized
INFO - 2021-12-25 07:02:54 --> Loader Class Initialized
INFO - 2021-12-25 07:02:54 --> Helper loaded: url_helper
INFO - 2021-12-25 07:02:54 --> Helper loaded: file_helper
INFO - 2021-12-25 07:02:54 --> Helper loaded: form_helper
INFO - 2021-12-25 07:02:54 --> Helper loaded: my_helper
INFO - 2021-12-25 07:02:54 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:02:54 --> Controller Class Initialized
INFO - 2021-12-25 07:02:54 --> Config Class Initialized
INFO - 2021-12-25 07:02:54 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:02:54 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:02:54 --> Utf8 Class Initialized
INFO - 2021-12-25 07:02:54 --> URI Class Initialized
INFO - 2021-12-25 07:02:54 --> Router Class Initialized
INFO - 2021-12-25 07:02:54 --> Output Class Initialized
INFO - 2021-12-25 07:02:54 --> Security Class Initialized
DEBUG - 2021-12-25 07:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:02:54 --> Input Class Initialized
INFO - 2021-12-25 07:02:54 --> Language Class Initialized
INFO - 2021-12-25 07:02:54 --> Language Class Initialized
INFO - 2021-12-25 07:02:54 --> Config Class Initialized
INFO - 2021-12-25 07:02:54 --> Loader Class Initialized
INFO - 2021-12-25 07:02:54 --> Helper loaded: url_helper
INFO - 2021-12-25 07:02:54 --> Helper loaded: file_helper
INFO - 2021-12-25 07:02:54 --> Helper loaded: form_helper
INFO - 2021-12-25 07:02:54 --> Helper loaded: my_helper
INFO - 2021-12-25 07:02:54 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:02:54 --> Controller Class Initialized
DEBUG - 2021-12-25 07:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-25 07:02:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:02:54 --> Final output sent to browser
DEBUG - 2021-12-25 07:02:54 --> Total execution time: 0.0410
INFO - 2021-12-25 07:03:24 --> Config Class Initialized
INFO - 2021-12-25 07:03:24 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:24 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:24 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:24 --> URI Class Initialized
INFO - 2021-12-25 07:03:24 --> Router Class Initialized
INFO - 2021-12-25 07:03:24 --> Output Class Initialized
INFO - 2021-12-25 07:03:24 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:24 --> Input Class Initialized
INFO - 2021-12-25 07:03:24 --> Language Class Initialized
INFO - 2021-12-25 07:03:24 --> Language Class Initialized
INFO - 2021-12-25 07:03:24 --> Config Class Initialized
INFO - 2021-12-25 07:03:24 --> Loader Class Initialized
INFO - 2021-12-25 07:03:24 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:24 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:24 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:24 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:24 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:24 --> Controller Class Initialized
INFO - 2021-12-25 07:03:24 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:03:24 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:24 --> Total execution time: 0.0513
INFO - 2021-12-25 07:03:24 --> Config Class Initialized
INFO - 2021-12-25 07:03:24 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:24 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:24 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:24 --> URI Class Initialized
INFO - 2021-12-25 07:03:24 --> Router Class Initialized
INFO - 2021-12-25 07:03:24 --> Output Class Initialized
INFO - 2021-12-25 07:03:24 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:24 --> Input Class Initialized
INFO - 2021-12-25 07:03:24 --> Language Class Initialized
INFO - 2021-12-25 07:03:24 --> Language Class Initialized
INFO - 2021-12-25 07:03:24 --> Config Class Initialized
INFO - 2021-12-25 07:03:24 --> Loader Class Initialized
INFO - 2021-12-25 07:03:24 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:24 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:24 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:24 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:24 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:24 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-25 07:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:25 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:25 --> Total execution time: 0.2426
INFO - 2021-12-25 07:03:28 --> Config Class Initialized
INFO - 2021-12-25 07:03:28 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:28 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:28 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:28 --> URI Class Initialized
INFO - 2021-12-25 07:03:28 --> Router Class Initialized
INFO - 2021-12-25 07:03:28 --> Output Class Initialized
INFO - 2021-12-25 07:03:28 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:28 --> Input Class Initialized
INFO - 2021-12-25 07:03:28 --> Language Class Initialized
INFO - 2021-12-25 07:03:28 --> Language Class Initialized
INFO - 2021-12-25 07:03:28 --> Config Class Initialized
INFO - 2021-12-25 07:03:28 --> Loader Class Initialized
INFO - 2021-12-25 07:03:28 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:28 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:28 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:28 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:28 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:28 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-25 07:03:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:28 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:28 --> Total execution time: 0.0744
INFO - 2021-12-25 07:03:30 --> Config Class Initialized
INFO - 2021-12-25 07:03:30 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:30 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:30 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:30 --> URI Class Initialized
DEBUG - 2021-12-25 07:03:30 --> No URI present. Default controller set.
INFO - 2021-12-25 07:03:30 --> Router Class Initialized
INFO - 2021-12-25 07:03:30 --> Output Class Initialized
INFO - 2021-12-25 07:03:30 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:30 --> Input Class Initialized
INFO - 2021-12-25 07:03:30 --> Language Class Initialized
INFO - 2021-12-25 07:03:30 --> Language Class Initialized
INFO - 2021-12-25 07:03:30 --> Config Class Initialized
INFO - 2021-12-25 07:03:30 --> Loader Class Initialized
INFO - 2021-12-25 07:03:30 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:30 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:30 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:30 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:30 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:30 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-25 07:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:30 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:30 --> Total execution time: 0.1433
INFO - 2021-12-25 07:03:32 --> Config Class Initialized
INFO - 2021-12-25 07:03:32 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:32 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:32 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:32 --> URI Class Initialized
INFO - 2021-12-25 07:03:32 --> Router Class Initialized
INFO - 2021-12-25 07:03:32 --> Output Class Initialized
INFO - 2021-12-25 07:03:32 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:32 --> Input Class Initialized
INFO - 2021-12-25 07:03:32 --> Language Class Initialized
INFO - 2021-12-25 07:03:32 --> Language Class Initialized
INFO - 2021-12-25 07:03:32 --> Config Class Initialized
INFO - 2021-12-25 07:03:32 --> Loader Class Initialized
INFO - 2021-12-25 07:03:32 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:32 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:32 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:32 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:32 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:32 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-25 07:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:32 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:32 --> Total execution time: 0.0610
INFO - 2021-12-25 07:03:34 --> Config Class Initialized
INFO - 2021-12-25 07:03:34 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:34 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:34 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:34 --> URI Class Initialized
INFO - 2021-12-25 07:03:34 --> Router Class Initialized
INFO - 2021-12-25 07:03:34 --> Output Class Initialized
INFO - 2021-12-25 07:03:34 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:34 --> Input Class Initialized
INFO - 2021-12-25 07:03:34 --> Language Class Initialized
INFO - 2021-12-25 07:03:34 --> Language Class Initialized
INFO - 2021-12-25 07:03:34 --> Config Class Initialized
INFO - 2021-12-25 07:03:34 --> Loader Class Initialized
INFO - 2021-12-25 07:03:34 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:34 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:34 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:34 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:34 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:34 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-25 07:03:34 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:34 --> Total execution time: 0.1806
INFO - 2021-12-25 07:03:52 --> Config Class Initialized
INFO - 2021-12-25 07:03:52 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:52 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:52 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:52 --> URI Class Initialized
INFO - 2021-12-25 07:03:52 --> Router Class Initialized
INFO - 2021-12-25 07:03:52 --> Output Class Initialized
INFO - 2021-12-25 07:03:52 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:52 --> Input Class Initialized
INFO - 2021-12-25 07:03:52 --> Language Class Initialized
INFO - 2021-12-25 07:03:52 --> Language Class Initialized
INFO - 2021-12-25 07:03:52 --> Config Class Initialized
INFO - 2021-12-25 07:03:52 --> Loader Class Initialized
INFO - 2021-12-25 07:03:52 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:52 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:52 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:52 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:52 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:52 --> Controller Class Initialized
INFO - 2021-12-25 07:03:52 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:03:52 --> Config Class Initialized
INFO - 2021-12-25 07:03:52 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:52 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:52 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:52 --> URI Class Initialized
INFO - 2021-12-25 07:03:52 --> Router Class Initialized
INFO - 2021-12-25 07:03:52 --> Output Class Initialized
INFO - 2021-12-25 07:03:52 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:52 --> Input Class Initialized
INFO - 2021-12-25 07:03:52 --> Language Class Initialized
INFO - 2021-12-25 07:03:52 --> Language Class Initialized
INFO - 2021-12-25 07:03:52 --> Config Class Initialized
INFO - 2021-12-25 07:03:52 --> Loader Class Initialized
INFO - 2021-12-25 07:03:52 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:52 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:52 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:52 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:52 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:52 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-25 07:03:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:52 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:52 --> Total execution time: 0.0489
INFO - 2021-12-25 07:03:56 --> Config Class Initialized
INFO - 2021-12-25 07:03:56 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:56 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:56 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:56 --> URI Class Initialized
INFO - 2021-12-25 07:03:56 --> Router Class Initialized
INFO - 2021-12-25 07:03:56 --> Output Class Initialized
INFO - 2021-12-25 07:03:56 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:56 --> Input Class Initialized
INFO - 2021-12-25 07:03:56 --> Language Class Initialized
INFO - 2021-12-25 07:03:56 --> Language Class Initialized
INFO - 2021-12-25 07:03:56 --> Config Class Initialized
INFO - 2021-12-25 07:03:56 --> Loader Class Initialized
INFO - 2021-12-25 07:03:56 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:56 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:56 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:56 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:56 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:56 --> Controller Class Initialized
INFO - 2021-12-25 07:03:56 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:03:56 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:56 --> Total execution time: 0.0456
INFO - 2021-12-25 07:03:56 --> Config Class Initialized
INFO - 2021-12-25 07:03:56 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:56 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:56 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:56 --> URI Class Initialized
INFO - 2021-12-25 07:03:56 --> Router Class Initialized
INFO - 2021-12-25 07:03:56 --> Output Class Initialized
INFO - 2021-12-25 07:03:56 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:56 --> Input Class Initialized
INFO - 2021-12-25 07:03:56 --> Language Class Initialized
INFO - 2021-12-25 07:03:56 --> Language Class Initialized
INFO - 2021-12-25 07:03:56 --> Config Class Initialized
INFO - 2021-12-25 07:03:56 --> Loader Class Initialized
INFO - 2021-12-25 07:03:56 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:56 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:56 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:56 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:56 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:56 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-25 07:03:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:56 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:56 --> Total execution time: 0.2563
INFO - 2021-12-25 07:03:58 --> Config Class Initialized
INFO - 2021-12-25 07:03:58 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:58 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:58 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:58 --> URI Class Initialized
INFO - 2021-12-25 07:03:58 --> Router Class Initialized
INFO - 2021-12-25 07:03:58 --> Output Class Initialized
INFO - 2021-12-25 07:03:58 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:58 --> Input Class Initialized
INFO - 2021-12-25 07:03:58 --> Language Class Initialized
INFO - 2021-12-25 07:03:58 --> Language Class Initialized
INFO - 2021-12-25 07:03:58 --> Config Class Initialized
INFO - 2021-12-25 07:03:58 --> Loader Class Initialized
INFO - 2021-12-25 07:03:58 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:58 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:58 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:58 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:58 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:58 --> Controller Class Initialized
DEBUG - 2021-12-25 07:03:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:03:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:03:58 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:58 --> Total execution time: 0.0427
INFO - 2021-12-25 07:03:59 --> Config Class Initialized
INFO - 2021-12-25 07:03:59 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:03:59 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:03:59 --> Utf8 Class Initialized
INFO - 2021-12-25 07:03:59 --> URI Class Initialized
INFO - 2021-12-25 07:03:59 --> Router Class Initialized
INFO - 2021-12-25 07:03:59 --> Output Class Initialized
INFO - 2021-12-25 07:03:59 --> Security Class Initialized
DEBUG - 2021-12-25 07:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:03:59 --> Input Class Initialized
INFO - 2021-12-25 07:03:59 --> Language Class Initialized
INFO - 2021-12-25 07:03:59 --> Language Class Initialized
INFO - 2021-12-25 07:03:59 --> Config Class Initialized
INFO - 2021-12-25 07:03:59 --> Loader Class Initialized
INFO - 2021-12-25 07:03:59 --> Helper loaded: url_helper
INFO - 2021-12-25 07:03:59 --> Helper loaded: file_helper
INFO - 2021-12-25 07:03:59 --> Helper loaded: form_helper
INFO - 2021-12-25 07:03:59 --> Helper loaded: my_helper
INFO - 2021-12-25 07:03:59 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:03:59 --> Controller Class Initialized
INFO - 2021-12-25 07:03:59 --> Final output sent to browser
DEBUG - 2021-12-25 07:03:59 --> Total execution time: 0.0459
INFO - 2021-12-25 07:04:00 --> Config Class Initialized
INFO - 2021-12-25 07:04:00 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:00 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:00 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:00 --> URI Class Initialized
INFO - 2021-12-25 07:04:00 --> Router Class Initialized
INFO - 2021-12-25 07:04:00 --> Output Class Initialized
INFO - 2021-12-25 07:04:00 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:00 --> Input Class Initialized
INFO - 2021-12-25 07:04:00 --> Language Class Initialized
INFO - 2021-12-25 07:04:00 --> Language Class Initialized
INFO - 2021-12-25 07:04:00 --> Config Class Initialized
INFO - 2021-12-25 07:04:00 --> Loader Class Initialized
INFO - 2021-12-25 07:04:00 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:00 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:00 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:00 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:00 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:00 --> Controller Class Initialized
INFO - 2021-12-25 07:04:00 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:00 --> Total execution time: 0.0385
INFO - 2021-12-25 07:04:01 --> Config Class Initialized
INFO - 2021-12-25 07:04:01 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:01 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:01 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:01 --> URI Class Initialized
INFO - 2021-12-25 07:04:01 --> Router Class Initialized
INFO - 2021-12-25 07:04:01 --> Output Class Initialized
INFO - 2021-12-25 07:04:01 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:01 --> Input Class Initialized
INFO - 2021-12-25 07:04:01 --> Language Class Initialized
INFO - 2021-12-25 07:04:01 --> Language Class Initialized
INFO - 2021-12-25 07:04:01 --> Config Class Initialized
INFO - 2021-12-25 07:04:01 --> Loader Class Initialized
INFO - 2021-12-25 07:04:01 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:01 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:01 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:01 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:01 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:01 --> Controller Class Initialized
INFO - 2021-12-25 07:04:01 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:01 --> Total execution time: 0.0376
INFO - 2021-12-25 07:04:02 --> Config Class Initialized
INFO - 2021-12-25 07:04:02 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:02 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:02 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:02 --> URI Class Initialized
INFO - 2021-12-25 07:04:02 --> Router Class Initialized
INFO - 2021-12-25 07:04:02 --> Output Class Initialized
INFO - 2021-12-25 07:04:02 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:02 --> Input Class Initialized
INFO - 2021-12-25 07:04:02 --> Language Class Initialized
INFO - 2021-12-25 07:04:02 --> Language Class Initialized
INFO - 2021-12-25 07:04:02 --> Config Class Initialized
INFO - 2021-12-25 07:04:02 --> Loader Class Initialized
INFO - 2021-12-25 07:04:02 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:02 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:02 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:02 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:02 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:02 --> Controller Class Initialized
INFO - 2021-12-25 07:04:02 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:02 --> Total execution time: 0.0401
INFO - 2021-12-25 07:04:05 --> Config Class Initialized
INFO - 2021-12-25 07:04:05 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:05 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:05 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:05 --> URI Class Initialized
INFO - 2021-12-25 07:04:05 --> Router Class Initialized
INFO - 2021-12-25 07:04:05 --> Output Class Initialized
INFO - 2021-12-25 07:04:05 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:05 --> Input Class Initialized
INFO - 2021-12-25 07:04:05 --> Language Class Initialized
INFO - 2021-12-25 07:04:05 --> Language Class Initialized
INFO - 2021-12-25 07:04:05 --> Config Class Initialized
INFO - 2021-12-25 07:04:05 --> Loader Class Initialized
INFO - 2021-12-25 07:04:05 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:05 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:05 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:05 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:05 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:05 --> Controller Class Initialized
INFO - 2021-12-25 07:04:05 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:05 --> Total execution time: 0.0389
INFO - 2021-12-25 07:04:05 --> Config Class Initialized
INFO - 2021-12-25 07:04:05 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:05 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:05 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:05 --> URI Class Initialized
INFO - 2021-12-25 07:04:05 --> Router Class Initialized
INFO - 2021-12-25 07:04:05 --> Output Class Initialized
INFO - 2021-12-25 07:04:05 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:05 --> Input Class Initialized
INFO - 2021-12-25 07:04:05 --> Language Class Initialized
INFO - 2021-12-25 07:04:05 --> Language Class Initialized
INFO - 2021-12-25 07:04:05 --> Config Class Initialized
INFO - 2021-12-25 07:04:05 --> Loader Class Initialized
INFO - 2021-12-25 07:04:05 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:05 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:05 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:05 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:05 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:05 --> Controller Class Initialized
INFO - 2021-12-25 07:04:05 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:05 --> Total execution time: 0.0406
INFO - 2021-12-25 07:04:06 --> Config Class Initialized
INFO - 2021-12-25 07:04:06 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:06 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:06 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:06 --> URI Class Initialized
INFO - 2021-12-25 07:04:06 --> Router Class Initialized
INFO - 2021-12-25 07:04:06 --> Output Class Initialized
INFO - 2021-12-25 07:04:06 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:06 --> Input Class Initialized
INFO - 2021-12-25 07:04:06 --> Language Class Initialized
INFO - 2021-12-25 07:04:06 --> Language Class Initialized
INFO - 2021-12-25 07:04:06 --> Config Class Initialized
INFO - 2021-12-25 07:04:06 --> Loader Class Initialized
INFO - 2021-12-25 07:04:06 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:06 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:06 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:06 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:06 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:06 --> Controller Class Initialized
INFO - 2021-12-25 07:04:06 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:06 --> Total execution time: 0.0397
INFO - 2021-12-25 07:04:07 --> Config Class Initialized
INFO - 2021-12-25 07:04:07 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:07 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:07 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:07 --> URI Class Initialized
INFO - 2021-12-25 07:04:07 --> Router Class Initialized
INFO - 2021-12-25 07:04:07 --> Output Class Initialized
INFO - 2021-12-25 07:04:07 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:07 --> Input Class Initialized
INFO - 2021-12-25 07:04:07 --> Language Class Initialized
INFO - 2021-12-25 07:04:07 --> Language Class Initialized
INFO - 2021-12-25 07:04:07 --> Config Class Initialized
INFO - 2021-12-25 07:04:07 --> Loader Class Initialized
INFO - 2021-12-25 07:04:07 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:07 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:07 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:07 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:07 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:07 --> Controller Class Initialized
INFO - 2021-12-25 07:04:07 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:07 --> Total execution time: 0.0389
INFO - 2021-12-25 07:04:08 --> Config Class Initialized
INFO - 2021-12-25 07:04:08 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:08 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:08 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:08 --> URI Class Initialized
INFO - 2021-12-25 07:04:08 --> Router Class Initialized
INFO - 2021-12-25 07:04:08 --> Output Class Initialized
INFO - 2021-12-25 07:04:08 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:08 --> Input Class Initialized
INFO - 2021-12-25 07:04:08 --> Language Class Initialized
INFO - 2021-12-25 07:04:08 --> Language Class Initialized
INFO - 2021-12-25 07:04:08 --> Config Class Initialized
INFO - 2021-12-25 07:04:08 --> Loader Class Initialized
INFO - 2021-12-25 07:04:08 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:08 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:08 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:08 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:08 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:08 --> Controller Class Initialized
DEBUG - 2021-12-25 07:04:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-25 07:04:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:04:08 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:08 --> Total execution time: 0.0482
INFO - 2021-12-25 07:04:11 --> Config Class Initialized
INFO - 2021-12-25 07:04:11 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:11 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:11 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:11 --> URI Class Initialized
INFO - 2021-12-25 07:04:11 --> Router Class Initialized
INFO - 2021-12-25 07:04:11 --> Output Class Initialized
INFO - 2021-12-25 07:04:11 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:11 --> Input Class Initialized
INFO - 2021-12-25 07:04:11 --> Language Class Initialized
INFO - 2021-12-25 07:04:11 --> Language Class Initialized
INFO - 2021-12-25 07:04:11 --> Config Class Initialized
INFO - 2021-12-25 07:04:11 --> Loader Class Initialized
INFO - 2021-12-25 07:04:11 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:11 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:11 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:11 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:11 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:11 --> Controller Class Initialized
DEBUG - 2021-12-25 07:04:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-25 07:04:11 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:11 --> Total execution time: 0.1641
INFO - 2021-12-25 07:04:25 --> Config Class Initialized
INFO - 2021-12-25 07:04:25 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:04:25 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:04:25 --> Utf8 Class Initialized
INFO - 2021-12-25 07:04:25 --> URI Class Initialized
INFO - 2021-12-25 07:04:25 --> Router Class Initialized
INFO - 2021-12-25 07:04:25 --> Output Class Initialized
INFO - 2021-12-25 07:04:25 --> Security Class Initialized
DEBUG - 2021-12-25 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:04:25 --> Input Class Initialized
INFO - 2021-12-25 07:04:25 --> Language Class Initialized
INFO - 2021-12-25 07:04:25 --> Language Class Initialized
INFO - 2021-12-25 07:04:25 --> Config Class Initialized
INFO - 2021-12-25 07:04:25 --> Loader Class Initialized
INFO - 2021-12-25 07:04:25 --> Helper loaded: url_helper
INFO - 2021-12-25 07:04:25 --> Helper loaded: file_helper
INFO - 2021-12-25 07:04:25 --> Helper loaded: form_helper
INFO - 2021-12-25 07:04:25 --> Helper loaded: my_helper
INFO - 2021-12-25 07:04:25 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:04:25 --> Controller Class Initialized
DEBUG - 2021-12-25 07:04:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:04:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:04:25 --> Final output sent to browser
DEBUG - 2021-12-25 07:04:25 --> Total execution time: 0.0503
INFO - 2021-12-25 07:05:17 --> Config Class Initialized
INFO - 2021-12-25 07:05:17 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:17 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:17 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:17 --> URI Class Initialized
INFO - 2021-12-25 07:05:17 --> Router Class Initialized
INFO - 2021-12-25 07:05:17 --> Output Class Initialized
INFO - 2021-12-25 07:05:17 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:17 --> Input Class Initialized
INFO - 2021-12-25 07:05:17 --> Language Class Initialized
INFO - 2021-12-25 07:05:17 --> Language Class Initialized
INFO - 2021-12-25 07:05:17 --> Config Class Initialized
INFO - 2021-12-25 07:05:17 --> Loader Class Initialized
INFO - 2021-12-25 07:05:17 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:17 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:17 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:17 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:17 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:17 --> Controller Class Initialized
INFO - 2021-12-25 07:05:17 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:17 --> Total execution time: 0.0471
INFO - 2021-12-25 07:05:22 --> Config Class Initialized
INFO - 2021-12-25 07:05:22 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:22 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:22 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:22 --> URI Class Initialized
INFO - 2021-12-25 07:05:22 --> Router Class Initialized
INFO - 2021-12-25 07:05:22 --> Output Class Initialized
INFO - 2021-12-25 07:05:22 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:22 --> Input Class Initialized
INFO - 2021-12-25 07:05:22 --> Language Class Initialized
INFO - 2021-12-25 07:05:22 --> Language Class Initialized
INFO - 2021-12-25 07:05:22 --> Config Class Initialized
INFO - 2021-12-25 07:05:22 --> Loader Class Initialized
INFO - 2021-12-25 07:05:22 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:22 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:22 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:22 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:22 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:22 --> Controller Class Initialized
INFO - 2021-12-25 07:05:22 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:05:22 --> Config Class Initialized
INFO - 2021-12-25 07:05:22 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:22 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:22 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:22 --> URI Class Initialized
INFO - 2021-12-25 07:05:22 --> Router Class Initialized
INFO - 2021-12-25 07:05:22 --> Output Class Initialized
INFO - 2021-12-25 07:05:22 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:22 --> Input Class Initialized
INFO - 2021-12-25 07:05:22 --> Language Class Initialized
INFO - 2021-12-25 07:05:22 --> Language Class Initialized
INFO - 2021-12-25 07:05:22 --> Config Class Initialized
INFO - 2021-12-25 07:05:22 --> Loader Class Initialized
INFO - 2021-12-25 07:05:22 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:22 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:22 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:22 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:22 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:22 --> Controller Class Initialized
DEBUG - 2021-12-25 07:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-25 07:05:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:05:22 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:22 --> Total execution time: 0.0385
INFO - 2021-12-25 07:05:25 --> Config Class Initialized
INFO - 2021-12-25 07:05:25 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:25 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:25 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:25 --> URI Class Initialized
INFO - 2021-12-25 07:05:25 --> Router Class Initialized
INFO - 2021-12-25 07:05:25 --> Output Class Initialized
INFO - 2021-12-25 07:05:25 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:25 --> Input Class Initialized
INFO - 2021-12-25 07:05:25 --> Language Class Initialized
INFO - 2021-12-25 07:05:26 --> Language Class Initialized
INFO - 2021-12-25 07:05:26 --> Config Class Initialized
INFO - 2021-12-25 07:05:26 --> Loader Class Initialized
INFO - 2021-12-25 07:05:26 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:26 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:26 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:26 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:26 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:26 --> Controller Class Initialized
INFO - 2021-12-25 07:05:26 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:05:26 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:26 --> Total execution time: 0.0511
INFO - 2021-12-25 07:05:26 --> Config Class Initialized
INFO - 2021-12-25 07:05:26 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:26 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:26 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:26 --> URI Class Initialized
INFO - 2021-12-25 07:05:26 --> Router Class Initialized
INFO - 2021-12-25 07:05:26 --> Output Class Initialized
INFO - 2021-12-25 07:05:26 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:26 --> Input Class Initialized
INFO - 2021-12-25 07:05:26 --> Language Class Initialized
INFO - 2021-12-25 07:05:26 --> Language Class Initialized
INFO - 2021-12-25 07:05:26 --> Config Class Initialized
INFO - 2021-12-25 07:05:26 --> Loader Class Initialized
INFO - 2021-12-25 07:05:26 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:26 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:26 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:26 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:26 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:26 --> Controller Class Initialized
DEBUG - 2021-12-25 07:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-25 07:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:05:26 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:26 --> Total execution time: 0.2152
INFO - 2021-12-25 07:05:27 --> Config Class Initialized
INFO - 2021-12-25 07:05:27 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:27 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:27 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:27 --> URI Class Initialized
INFO - 2021-12-25 07:05:27 --> Router Class Initialized
INFO - 2021-12-25 07:05:27 --> Output Class Initialized
INFO - 2021-12-25 07:05:27 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:27 --> Input Class Initialized
INFO - 2021-12-25 07:05:27 --> Language Class Initialized
INFO - 2021-12-25 07:05:27 --> Language Class Initialized
INFO - 2021-12-25 07:05:27 --> Config Class Initialized
INFO - 2021-12-25 07:05:27 --> Loader Class Initialized
INFO - 2021-12-25 07:05:27 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:27 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:27 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:27 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:27 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:27 --> Controller Class Initialized
DEBUG - 2021-12-25 07:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-12-25 07:05:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:05:27 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:27 --> Total execution time: 0.0593
INFO - 2021-12-25 07:05:27 --> Config Class Initialized
INFO - 2021-12-25 07:05:27 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:27 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:27 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:27 --> URI Class Initialized
INFO - 2021-12-25 07:05:27 --> Router Class Initialized
INFO - 2021-12-25 07:05:27 --> Output Class Initialized
INFO - 2021-12-25 07:05:27 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:27 --> Input Class Initialized
INFO - 2021-12-25 07:05:27 --> Language Class Initialized
INFO - 2021-12-25 07:05:27 --> Language Class Initialized
INFO - 2021-12-25 07:05:27 --> Config Class Initialized
INFO - 2021-12-25 07:05:27 --> Loader Class Initialized
INFO - 2021-12-25 07:05:27 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:27 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:27 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:27 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:27 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:27 --> Controller Class Initialized
INFO - 2021-12-25 07:05:35 --> Config Class Initialized
INFO - 2021-12-25 07:05:35 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:35 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:35 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:35 --> URI Class Initialized
INFO - 2021-12-25 07:05:35 --> Router Class Initialized
INFO - 2021-12-25 07:05:35 --> Output Class Initialized
INFO - 2021-12-25 07:05:35 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:35 --> Input Class Initialized
INFO - 2021-12-25 07:05:35 --> Language Class Initialized
INFO - 2021-12-25 07:05:35 --> Language Class Initialized
INFO - 2021-12-25 07:05:35 --> Config Class Initialized
INFO - 2021-12-25 07:05:35 --> Loader Class Initialized
INFO - 2021-12-25 07:05:35 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:35 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:35 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:35 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:35 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:35 --> Controller Class Initialized
INFO - 2021-12-25 07:05:35 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:35 --> Total execution time: 0.0495
INFO - 2021-12-25 07:05:51 --> Config Class Initialized
INFO - 2021-12-25 07:05:51 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:51 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:51 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:51 --> URI Class Initialized
INFO - 2021-12-25 07:05:51 --> Router Class Initialized
INFO - 2021-12-25 07:05:51 --> Output Class Initialized
INFO - 2021-12-25 07:05:51 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:51 --> Input Class Initialized
INFO - 2021-12-25 07:05:51 --> Language Class Initialized
INFO - 2021-12-25 07:05:51 --> Language Class Initialized
INFO - 2021-12-25 07:05:51 --> Config Class Initialized
INFO - 2021-12-25 07:05:51 --> Loader Class Initialized
INFO - 2021-12-25 07:05:51 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:51 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:51 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:51 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:51 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:51 --> Controller Class Initialized
INFO - 2021-12-25 07:05:51 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:05:51 --> Config Class Initialized
INFO - 2021-12-25 07:05:51 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:51 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:51 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:51 --> URI Class Initialized
INFO - 2021-12-25 07:05:51 --> Router Class Initialized
INFO - 2021-12-25 07:05:51 --> Output Class Initialized
INFO - 2021-12-25 07:05:51 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:51 --> Input Class Initialized
INFO - 2021-12-25 07:05:51 --> Language Class Initialized
INFO - 2021-12-25 07:05:51 --> Language Class Initialized
INFO - 2021-12-25 07:05:51 --> Config Class Initialized
INFO - 2021-12-25 07:05:51 --> Loader Class Initialized
INFO - 2021-12-25 07:05:51 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:51 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:51 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:51 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:51 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:51 --> Controller Class Initialized
DEBUG - 2021-12-25 07:05:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-25 07:05:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:05:51 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:51 --> Total execution time: 0.0485
INFO - 2021-12-25 07:05:56 --> Config Class Initialized
INFO - 2021-12-25 07:05:56 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:56 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:56 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:56 --> URI Class Initialized
INFO - 2021-12-25 07:05:56 --> Router Class Initialized
INFO - 2021-12-25 07:05:56 --> Output Class Initialized
INFO - 2021-12-25 07:05:56 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:56 --> Input Class Initialized
INFO - 2021-12-25 07:05:56 --> Language Class Initialized
INFO - 2021-12-25 07:05:56 --> Language Class Initialized
INFO - 2021-12-25 07:05:56 --> Config Class Initialized
INFO - 2021-12-25 07:05:56 --> Loader Class Initialized
INFO - 2021-12-25 07:05:56 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:56 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:56 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:56 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:56 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:56 --> Controller Class Initialized
INFO - 2021-12-25 07:05:56 --> Helper loaded: cookie_helper
INFO - 2021-12-25 07:05:56 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:56 --> Total execution time: 0.0548
INFO - 2021-12-25 07:05:56 --> Config Class Initialized
INFO - 2021-12-25 07:05:56 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:56 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:56 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:56 --> URI Class Initialized
INFO - 2021-12-25 07:05:56 --> Router Class Initialized
INFO - 2021-12-25 07:05:56 --> Output Class Initialized
INFO - 2021-12-25 07:05:56 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:56 --> Input Class Initialized
INFO - 2021-12-25 07:05:56 --> Language Class Initialized
INFO - 2021-12-25 07:05:56 --> Language Class Initialized
INFO - 2021-12-25 07:05:56 --> Config Class Initialized
INFO - 2021-12-25 07:05:56 --> Loader Class Initialized
INFO - 2021-12-25 07:05:56 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:56 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:56 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:56 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:56 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:56 --> Controller Class Initialized
DEBUG - 2021-12-25 07:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-25 07:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:05:56 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:56 --> Total execution time: 0.1399
INFO - 2021-12-25 07:05:57 --> Config Class Initialized
INFO - 2021-12-25 07:05:57 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:05:58 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:05:58 --> Utf8 Class Initialized
INFO - 2021-12-25 07:05:58 --> URI Class Initialized
INFO - 2021-12-25 07:05:58 --> Router Class Initialized
INFO - 2021-12-25 07:05:58 --> Output Class Initialized
INFO - 2021-12-25 07:05:58 --> Security Class Initialized
DEBUG - 2021-12-25 07:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:05:58 --> Input Class Initialized
INFO - 2021-12-25 07:05:58 --> Language Class Initialized
INFO - 2021-12-25 07:05:58 --> Language Class Initialized
INFO - 2021-12-25 07:05:58 --> Config Class Initialized
INFO - 2021-12-25 07:05:58 --> Loader Class Initialized
INFO - 2021-12-25 07:05:58 --> Helper loaded: url_helper
INFO - 2021-12-25 07:05:58 --> Helper loaded: file_helper
INFO - 2021-12-25 07:05:58 --> Helper loaded: form_helper
INFO - 2021-12-25 07:05:58 --> Helper loaded: my_helper
INFO - 2021-12-25 07:05:58 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:05:58 --> Controller Class Initialized
DEBUG - 2021-12-25 07:05:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:05:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:05:58 --> Final output sent to browser
DEBUG - 2021-12-25 07:05:58 --> Total execution time: 0.0515
INFO - 2021-12-25 07:06:18 --> Config Class Initialized
INFO - 2021-12-25 07:06:18 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:18 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:18 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:18 --> URI Class Initialized
INFO - 2021-12-25 07:06:18 --> Router Class Initialized
INFO - 2021-12-25 07:06:18 --> Output Class Initialized
INFO - 2021-12-25 07:06:18 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:18 --> Input Class Initialized
INFO - 2021-12-25 07:06:18 --> Language Class Initialized
INFO - 2021-12-25 07:06:18 --> Language Class Initialized
INFO - 2021-12-25 07:06:18 --> Config Class Initialized
INFO - 2021-12-25 07:06:18 --> Loader Class Initialized
INFO - 2021-12-25 07:06:18 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:18 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:18 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:18 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:18 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:18 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:18 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:18 --> Total execution time: 0.0406
INFO - 2021-12-25 07:06:20 --> Config Class Initialized
INFO - 2021-12-25 07:06:20 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:20 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:20 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:20 --> URI Class Initialized
INFO - 2021-12-25 07:06:20 --> Router Class Initialized
INFO - 2021-12-25 07:06:20 --> Output Class Initialized
INFO - 2021-12-25 07:06:20 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:20 --> Input Class Initialized
INFO - 2021-12-25 07:06:20 --> Language Class Initialized
INFO - 2021-12-25 07:06:20 --> Language Class Initialized
INFO - 2021-12-25 07:06:20 --> Config Class Initialized
INFO - 2021-12-25 07:06:20 --> Loader Class Initialized
INFO - 2021-12-25 07:06:20 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:20 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:20 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:20 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:20 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:20 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-25 07:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:20 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:20 --> Total execution time: 0.0550
INFO - 2021-12-25 07:06:24 --> Config Class Initialized
INFO - 2021-12-25 07:06:24 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:24 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:24 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:24 --> URI Class Initialized
INFO - 2021-12-25 07:06:24 --> Router Class Initialized
INFO - 2021-12-25 07:06:24 --> Output Class Initialized
INFO - 2021-12-25 07:06:24 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:24 --> Input Class Initialized
INFO - 2021-12-25 07:06:24 --> Language Class Initialized
INFO - 2021-12-25 07:06:24 --> Language Class Initialized
INFO - 2021-12-25 07:06:24 --> Config Class Initialized
INFO - 2021-12-25 07:06:24 --> Loader Class Initialized
INFO - 2021-12-25 07:06:24 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:24 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:24 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:24 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:24 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:24 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-25 07:06:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:24 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:24 --> Total execution time: 0.1389
INFO - 2021-12-25 07:06:26 --> Config Class Initialized
INFO - 2021-12-25 07:06:26 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:26 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:26 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:26 --> URI Class Initialized
INFO - 2021-12-25 07:06:26 --> Router Class Initialized
INFO - 2021-12-25 07:06:26 --> Output Class Initialized
INFO - 2021-12-25 07:06:26 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:26 --> Input Class Initialized
INFO - 2021-12-25 07:06:26 --> Language Class Initialized
INFO - 2021-12-25 07:06:26 --> Language Class Initialized
INFO - 2021-12-25 07:06:26 --> Config Class Initialized
INFO - 2021-12-25 07:06:26 --> Loader Class Initialized
INFO - 2021-12-25 07:06:26 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:26 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:26 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:26 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:26 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:26 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-25 07:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:26 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:26 --> Total execution time: 0.0564
INFO - 2021-12-25 07:06:27 --> Config Class Initialized
INFO - 2021-12-25 07:06:27 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:27 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:27 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:27 --> URI Class Initialized
INFO - 2021-12-25 07:06:27 --> Router Class Initialized
INFO - 2021-12-25 07:06:27 --> Output Class Initialized
INFO - 2021-12-25 07:06:27 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:27 --> Input Class Initialized
INFO - 2021-12-25 07:06:27 --> Language Class Initialized
INFO - 2021-12-25 07:06:27 --> Language Class Initialized
INFO - 2021-12-25 07:06:27 --> Config Class Initialized
INFO - 2021-12-25 07:06:27 --> Loader Class Initialized
INFO - 2021-12-25 07:06:27 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:27 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:27 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:27 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:27 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:27 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:27 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:27 --> Total execution time: 0.0509
INFO - 2021-12-25 07:06:28 --> Config Class Initialized
INFO - 2021-12-25 07:06:28 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:28 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:28 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:28 --> URI Class Initialized
INFO - 2021-12-25 07:06:28 --> Router Class Initialized
INFO - 2021-12-25 07:06:28 --> Output Class Initialized
INFO - 2021-12-25 07:06:28 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:28 --> Input Class Initialized
INFO - 2021-12-25 07:06:28 --> Language Class Initialized
INFO - 2021-12-25 07:06:28 --> Language Class Initialized
INFO - 2021-12-25 07:06:28 --> Config Class Initialized
INFO - 2021-12-25 07:06:28 --> Loader Class Initialized
INFO - 2021-12-25 07:06:28 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:28 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:28 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:28 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:28 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:28 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:28 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:28 --> Total execution time: 0.0467
INFO - 2021-12-25 07:06:37 --> Config Class Initialized
INFO - 2021-12-25 07:06:37 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:37 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:37 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:37 --> URI Class Initialized
INFO - 2021-12-25 07:06:37 --> Router Class Initialized
INFO - 2021-12-25 07:06:37 --> Output Class Initialized
INFO - 2021-12-25 07:06:37 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:37 --> Input Class Initialized
INFO - 2021-12-25 07:06:37 --> Language Class Initialized
INFO - 2021-12-25 07:06:37 --> Language Class Initialized
INFO - 2021-12-25 07:06:37 --> Config Class Initialized
INFO - 2021-12-25 07:06:37 --> Loader Class Initialized
INFO - 2021-12-25 07:06:37 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:37 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:37 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:37 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:37 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:37 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-25 07:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:37 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:37 --> Total execution time: 0.0854
INFO - 2021-12-25 07:06:39 --> Config Class Initialized
INFO - 2021-12-25 07:06:39 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:06:39 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:06:39 --> Utf8 Class Initialized
INFO - 2021-12-25 07:06:39 --> URI Class Initialized
INFO - 2021-12-25 07:06:39 --> Router Class Initialized
INFO - 2021-12-25 07:06:39 --> Output Class Initialized
INFO - 2021-12-25 07:06:39 --> Security Class Initialized
DEBUG - 2021-12-25 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:06:39 --> Input Class Initialized
INFO - 2021-12-25 07:06:39 --> Language Class Initialized
INFO - 2021-12-25 07:06:39 --> Language Class Initialized
INFO - 2021-12-25 07:06:39 --> Config Class Initialized
INFO - 2021-12-25 07:06:39 --> Loader Class Initialized
INFO - 2021-12-25 07:06:39 --> Helper loaded: url_helper
INFO - 2021-12-25 07:06:39 --> Helper loaded: file_helper
INFO - 2021-12-25 07:06:39 --> Helper loaded: form_helper
INFO - 2021-12-25 07:06:39 --> Helper loaded: my_helper
INFO - 2021-12-25 07:06:39 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:06:39 --> Controller Class Initialized
DEBUG - 2021-12-25 07:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:06:39 --> Final output sent to browser
DEBUG - 2021-12-25 07:06:39 --> Total execution time: 0.0423
INFO - 2021-12-25 07:07:01 --> Config Class Initialized
INFO - 2021-12-25 07:07:01 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:07:01 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:07:01 --> Utf8 Class Initialized
INFO - 2021-12-25 07:07:01 --> URI Class Initialized
INFO - 2021-12-25 07:07:01 --> Router Class Initialized
INFO - 2021-12-25 07:07:01 --> Output Class Initialized
INFO - 2021-12-25 07:07:01 --> Security Class Initialized
DEBUG - 2021-12-25 07:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:07:01 --> Input Class Initialized
INFO - 2021-12-25 07:07:01 --> Language Class Initialized
INFO - 2021-12-25 07:07:01 --> Language Class Initialized
INFO - 2021-12-25 07:07:01 --> Config Class Initialized
INFO - 2021-12-25 07:07:01 --> Loader Class Initialized
INFO - 2021-12-25 07:07:01 --> Helper loaded: url_helper
INFO - 2021-12-25 07:07:01 --> Helper loaded: file_helper
INFO - 2021-12-25 07:07:01 --> Helper loaded: form_helper
INFO - 2021-12-25 07:07:01 --> Helper loaded: my_helper
INFO - 2021-12-25 07:07:01 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:07:01 --> Controller Class Initialized
DEBUG - 2021-12-25 07:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-25 07:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:07:01 --> Final output sent to browser
DEBUG - 2021-12-25 07:07:01 --> Total execution time: 0.0545
INFO - 2021-12-25 07:15:00 --> Config Class Initialized
INFO - 2021-12-25 07:15:00 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:00 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:00 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:00 --> URI Class Initialized
INFO - 2021-12-25 07:15:00 --> Router Class Initialized
INFO - 2021-12-25 07:15:00 --> Output Class Initialized
INFO - 2021-12-25 07:15:00 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:00 --> Input Class Initialized
INFO - 2021-12-25 07:15:00 --> Language Class Initialized
INFO - 2021-12-25 07:15:00 --> Language Class Initialized
INFO - 2021-12-25 07:15:00 --> Config Class Initialized
INFO - 2021-12-25 07:15:00 --> Loader Class Initialized
INFO - 2021-12-25 07:15:00 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:00 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:00 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:00 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:00 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:01 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-25 07:15:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:01 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:01 --> Total execution time: 0.6575
INFO - 2021-12-25 07:15:03 --> Config Class Initialized
INFO - 2021-12-25 07:15:03 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:03 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:03 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:03 --> URI Class Initialized
INFO - 2021-12-25 07:15:03 --> Router Class Initialized
INFO - 2021-12-25 07:15:03 --> Output Class Initialized
INFO - 2021-12-25 07:15:03 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:03 --> Input Class Initialized
INFO - 2021-12-25 07:15:03 --> Language Class Initialized
INFO - 2021-12-25 07:15:03 --> Language Class Initialized
INFO - 2021-12-25 07:15:03 --> Config Class Initialized
INFO - 2021-12-25 07:15:03 --> Loader Class Initialized
INFO - 2021-12-25 07:15:03 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:03 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:03 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:03 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:03 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:03 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:03 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:03 --> Total execution time: 0.0830
INFO - 2021-12-25 07:15:05 --> Config Class Initialized
INFO - 2021-12-25 07:15:05 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:05 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:05 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:05 --> URI Class Initialized
INFO - 2021-12-25 07:15:05 --> Router Class Initialized
INFO - 2021-12-25 07:15:05 --> Output Class Initialized
INFO - 2021-12-25 07:15:05 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:05 --> Input Class Initialized
INFO - 2021-12-25 07:15:05 --> Language Class Initialized
INFO - 2021-12-25 07:15:05 --> Language Class Initialized
INFO - 2021-12-25 07:15:05 --> Config Class Initialized
INFO - 2021-12-25 07:15:05 --> Loader Class Initialized
INFO - 2021-12-25 07:15:05 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:05 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:05 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:05 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:05 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:05 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-25 07:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:05 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:05 --> Total execution time: 0.0837
INFO - 2021-12-25 07:15:06 --> Config Class Initialized
INFO - 2021-12-25 07:15:06 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:06 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:06 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:06 --> URI Class Initialized
INFO - 2021-12-25 07:15:06 --> Router Class Initialized
INFO - 2021-12-25 07:15:06 --> Output Class Initialized
INFO - 2021-12-25 07:15:06 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:06 --> Input Class Initialized
INFO - 2021-12-25 07:15:06 --> Language Class Initialized
INFO - 2021-12-25 07:15:06 --> Language Class Initialized
INFO - 2021-12-25 07:15:06 --> Config Class Initialized
INFO - 2021-12-25 07:15:06 --> Loader Class Initialized
INFO - 2021-12-25 07:15:06 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:06 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:06 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:06 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:06 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:06 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-25 07:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:06 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:06 --> Total execution time: 0.1761
INFO - 2021-12-25 07:15:07 --> Config Class Initialized
INFO - 2021-12-25 07:15:07 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:07 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:07 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:07 --> URI Class Initialized
INFO - 2021-12-25 07:15:07 --> Router Class Initialized
INFO - 2021-12-25 07:15:07 --> Output Class Initialized
INFO - 2021-12-25 07:15:07 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:07 --> Input Class Initialized
INFO - 2021-12-25 07:15:07 --> Language Class Initialized
INFO - 2021-12-25 07:15:07 --> Language Class Initialized
INFO - 2021-12-25 07:15:07 --> Config Class Initialized
INFO - 2021-12-25 07:15:07 --> Loader Class Initialized
INFO - 2021-12-25 07:15:07 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:07 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:07 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:07 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:07 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:07 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-12-25 07:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:07 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:07 --> Total execution time: 0.0748
INFO - 2021-12-25 07:15:08 --> Config Class Initialized
INFO - 2021-12-25 07:15:08 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:08 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:08 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:08 --> URI Class Initialized
INFO - 2021-12-25 07:15:08 --> Router Class Initialized
INFO - 2021-12-25 07:15:08 --> Output Class Initialized
INFO - 2021-12-25 07:15:08 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:08 --> Input Class Initialized
INFO - 2021-12-25 07:15:08 --> Language Class Initialized
INFO - 2021-12-25 07:15:08 --> Language Class Initialized
INFO - 2021-12-25 07:15:08 --> Config Class Initialized
INFO - 2021-12-25 07:15:08 --> Loader Class Initialized
INFO - 2021-12-25 07:15:08 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:08 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:08 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:08 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:08 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:08 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-25 07:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:08 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:08 --> Total execution time: 0.0805
INFO - 2021-12-25 07:15:09 --> Config Class Initialized
INFO - 2021-12-25 07:15:09 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:09 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:09 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:09 --> URI Class Initialized
INFO - 2021-12-25 07:15:09 --> Router Class Initialized
INFO - 2021-12-25 07:15:09 --> Output Class Initialized
INFO - 2021-12-25 07:15:09 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:09 --> Input Class Initialized
INFO - 2021-12-25 07:15:09 --> Language Class Initialized
INFO - 2021-12-25 07:15:09 --> Language Class Initialized
INFO - 2021-12-25 07:15:09 --> Config Class Initialized
INFO - 2021-12-25 07:15:09 --> Loader Class Initialized
INFO - 2021-12-25 07:15:09 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:09 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:09 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:09 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:09 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:09 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-25 07:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:09 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:09 --> Total execution time: 0.0578
INFO - 2021-12-25 07:15:16 --> Config Class Initialized
INFO - 2021-12-25 07:15:16 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:16 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:16 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:16 --> URI Class Initialized
INFO - 2021-12-25 07:15:16 --> Router Class Initialized
INFO - 2021-12-25 07:15:16 --> Output Class Initialized
INFO - 2021-12-25 07:15:16 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:16 --> Input Class Initialized
INFO - 2021-12-25 07:15:16 --> Language Class Initialized
INFO - 2021-12-25 07:15:16 --> Language Class Initialized
INFO - 2021-12-25 07:15:16 --> Config Class Initialized
INFO - 2021-12-25 07:15:16 --> Loader Class Initialized
INFO - 2021-12-25 07:15:16 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:16 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:16 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:16 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:16 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:16 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-25 07:15:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:16 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:16 --> Total execution time: 0.0670
INFO - 2021-12-25 07:15:17 --> Config Class Initialized
INFO - 2021-12-25 07:15:17 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:17 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:17 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:17 --> URI Class Initialized
INFO - 2021-12-25 07:15:17 --> Router Class Initialized
INFO - 2021-12-25 07:15:17 --> Output Class Initialized
INFO - 2021-12-25 07:15:17 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:17 --> Input Class Initialized
INFO - 2021-12-25 07:15:17 --> Language Class Initialized
INFO - 2021-12-25 07:15:17 --> Language Class Initialized
INFO - 2021-12-25 07:15:17 --> Config Class Initialized
INFO - 2021-12-25 07:15:17 --> Loader Class Initialized
INFO - 2021-12-25 07:15:17 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:17 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:17 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:17 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:17 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:17 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:17 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:17 --> Total execution time: 0.0545
INFO - 2021-12-25 07:15:19 --> Config Class Initialized
INFO - 2021-12-25 07:15:19 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:19 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:19 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:19 --> URI Class Initialized
INFO - 2021-12-25 07:15:19 --> Router Class Initialized
INFO - 2021-12-25 07:15:19 --> Output Class Initialized
INFO - 2021-12-25 07:15:19 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:19 --> Input Class Initialized
INFO - 2021-12-25 07:15:19 --> Language Class Initialized
INFO - 2021-12-25 07:15:19 --> Language Class Initialized
INFO - 2021-12-25 07:15:19 --> Config Class Initialized
INFO - 2021-12-25 07:15:19 --> Loader Class Initialized
INFO - 2021-12-25 07:15:19 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:19 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:19 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:19 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:19 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:19 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:19 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:19 --> Total execution time: 0.0791
INFO - 2021-12-25 07:15:22 --> Config Class Initialized
INFO - 2021-12-25 07:15:22 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:22 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:22 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:22 --> URI Class Initialized
INFO - 2021-12-25 07:15:22 --> Router Class Initialized
INFO - 2021-12-25 07:15:22 --> Output Class Initialized
INFO - 2021-12-25 07:15:22 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:22 --> Input Class Initialized
INFO - 2021-12-25 07:15:22 --> Language Class Initialized
INFO - 2021-12-25 07:15:22 --> Language Class Initialized
INFO - 2021-12-25 07:15:22 --> Config Class Initialized
INFO - 2021-12-25 07:15:22 --> Loader Class Initialized
INFO - 2021-12-25 07:15:22 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:22 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:22 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:22 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:22 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:22 --> Controller Class Initialized
INFO - 2021-12-25 07:15:22 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:22 --> Total execution time: 0.0400
INFO - 2021-12-25 07:15:42 --> Config Class Initialized
INFO - 2021-12-25 07:15:42 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:42 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:42 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:42 --> URI Class Initialized
INFO - 2021-12-25 07:15:42 --> Router Class Initialized
INFO - 2021-12-25 07:15:42 --> Output Class Initialized
INFO - 2021-12-25 07:15:42 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:42 --> Input Class Initialized
INFO - 2021-12-25 07:15:42 --> Language Class Initialized
INFO - 2021-12-25 07:15:42 --> Language Class Initialized
INFO - 2021-12-25 07:15:42 --> Config Class Initialized
INFO - 2021-12-25 07:15:42 --> Loader Class Initialized
INFO - 2021-12-25 07:15:42 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:42 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:42 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:42 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:42 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:42 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:15:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:42 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:42 --> Total execution time: 0.0538
INFO - 2021-12-25 07:15:46 --> Config Class Initialized
INFO - 2021-12-25 07:15:46 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:46 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:46 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:46 --> URI Class Initialized
INFO - 2021-12-25 07:15:46 --> Router Class Initialized
INFO - 2021-12-25 07:15:46 --> Output Class Initialized
INFO - 2021-12-25 07:15:46 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:46 --> Input Class Initialized
INFO - 2021-12-25 07:15:46 --> Language Class Initialized
INFO - 2021-12-25 07:15:46 --> Language Class Initialized
INFO - 2021-12-25 07:15:46 --> Config Class Initialized
INFO - 2021-12-25 07:15:46 --> Loader Class Initialized
INFO - 2021-12-25 07:15:46 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:46 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:46 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:46 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:46 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:46 --> Controller Class Initialized
DEBUG - 2021-12-25 07:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:15:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:15:46 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:46 --> Total execution time: 0.0514
INFO - 2021-12-25 07:15:48 --> Config Class Initialized
INFO - 2021-12-25 07:15:48 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:15:48 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:15:48 --> Utf8 Class Initialized
INFO - 2021-12-25 07:15:48 --> URI Class Initialized
INFO - 2021-12-25 07:15:48 --> Router Class Initialized
INFO - 2021-12-25 07:15:48 --> Output Class Initialized
INFO - 2021-12-25 07:15:48 --> Security Class Initialized
DEBUG - 2021-12-25 07:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:15:48 --> Input Class Initialized
INFO - 2021-12-25 07:15:48 --> Language Class Initialized
INFO - 2021-12-25 07:15:48 --> Language Class Initialized
INFO - 2021-12-25 07:15:48 --> Config Class Initialized
INFO - 2021-12-25 07:15:48 --> Loader Class Initialized
INFO - 2021-12-25 07:15:48 --> Helper loaded: url_helper
INFO - 2021-12-25 07:15:48 --> Helper loaded: file_helper
INFO - 2021-12-25 07:15:48 --> Helper loaded: form_helper
INFO - 2021-12-25 07:15:48 --> Helper loaded: my_helper
INFO - 2021-12-25 07:15:48 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:15:48 --> Controller Class Initialized
INFO - 2021-12-25 07:15:48 --> Final output sent to browser
DEBUG - 2021-12-25 07:15:48 --> Total execution time: 0.0480
INFO - 2021-12-25 07:17:56 --> Config Class Initialized
INFO - 2021-12-25 07:17:56 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:17:56 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:17:56 --> Utf8 Class Initialized
INFO - 2021-12-25 07:17:56 --> URI Class Initialized
INFO - 2021-12-25 07:17:56 --> Router Class Initialized
INFO - 2021-12-25 07:17:56 --> Output Class Initialized
INFO - 2021-12-25 07:17:56 --> Security Class Initialized
DEBUG - 2021-12-25 07:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:17:56 --> Input Class Initialized
INFO - 2021-12-25 07:17:56 --> Language Class Initialized
INFO - 2021-12-25 07:17:56 --> Language Class Initialized
INFO - 2021-12-25 07:17:56 --> Config Class Initialized
INFO - 2021-12-25 07:17:56 --> Loader Class Initialized
INFO - 2021-12-25 07:17:56 --> Helper loaded: url_helper
INFO - 2021-12-25 07:17:56 --> Helper loaded: file_helper
INFO - 2021-12-25 07:17:56 --> Helper loaded: form_helper
INFO - 2021-12-25 07:17:56 --> Helper loaded: my_helper
INFO - 2021-12-25 07:17:56 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:17:56 --> Controller Class Initialized
DEBUG - 2021-12-25 07:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:17:56 --> Final output sent to browser
DEBUG - 2021-12-25 07:17:56 --> Total execution time: 0.0516
INFO - 2021-12-25 07:17:57 --> Config Class Initialized
INFO - 2021-12-25 07:17:57 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:17:57 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:17:57 --> Utf8 Class Initialized
INFO - 2021-12-25 07:17:57 --> URI Class Initialized
INFO - 2021-12-25 07:17:57 --> Router Class Initialized
INFO - 2021-12-25 07:17:57 --> Output Class Initialized
INFO - 2021-12-25 07:17:57 --> Security Class Initialized
DEBUG - 2021-12-25 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:17:57 --> Input Class Initialized
INFO - 2021-12-25 07:17:57 --> Language Class Initialized
INFO - 2021-12-25 07:17:57 --> Language Class Initialized
INFO - 2021-12-25 07:17:57 --> Config Class Initialized
INFO - 2021-12-25 07:17:57 --> Loader Class Initialized
INFO - 2021-12-25 07:17:57 --> Helper loaded: url_helper
INFO - 2021-12-25 07:17:57 --> Helper loaded: file_helper
INFO - 2021-12-25 07:17:57 --> Helper loaded: form_helper
INFO - 2021-12-25 07:17:57 --> Helper loaded: my_helper
INFO - 2021-12-25 07:17:57 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:17:57 --> Controller Class Initialized
INFO - 2021-12-25 07:17:57 --> Final output sent to browser
DEBUG - 2021-12-25 07:17:57 --> Total execution time: 0.0497
INFO - 2021-12-25 07:18:13 --> Config Class Initialized
INFO - 2021-12-25 07:18:13 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:18:13 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:18:13 --> Utf8 Class Initialized
INFO - 2021-12-25 07:18:13 --> URI Class Initialized
INFO - 2021-12-25 07:18:13 --> Router Class Initialized
INFO - 2021-12-25 07:18:13 --> Output Class Initialized
INFO - 2021-12-25 07:18:13 --> Security Class Initialized
DEBUG - 2021-12-25 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:18:13 --> Input Class Initialized
INFO - 2021-12-25 07:18:13 --> Language Class Initialized
ERROR - 2021-12-25 07:18:13 --> 404 Page Not Found: /index
INFO - 2021-12-25 07:19:40 --> Config Class Initialized
INFO - 2021-12-25 07:19:40 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:19:40 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:19:40 --> Utf8 Class Initialized
INFO - 2021-12-25 07:19:40 --> URI Class Initialized
INFO - 2021-12-25 07:19:40 --> Router Class Initialized
INFO - 2021-12-25 07:19:40 --> Output Class Initialized
INFO - 2021-12-25 07:19:40 --> Security Class Initialized
DEBUG - 2021-12-25 07:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:19:40 --> Input Class Initialized
INFO - 2021-12-25 07:19:40 --> Language Class Initialized
INFO - 2021-12-25 07:19:40 --> Language Class Initialized
INFO - 2021-12-25 07:19:40 --> Config Class Initialized
INFO - 2021-12-25 07:19:40 --> Loader Class Initialized
INFO - 2021-12-25 07:19:40 --> Helper loaded: url_helper
INFO - 2021-12-25 07:19:40 --> Helper loaded: file_helper
INFO - 2021-12-25 07:19:40 --> Helper loaded: form_helper
INFO - 2021-12-25 07:19:40 --> Helper loaded: my_helper
INFO - 2021-12-25 07:19:40 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:19:40 --> Controller Class Initialized
DEBUG - 2021-12-25 07:19:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:19:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:19:40 --> Final output sent to browser
DEBUG - 2021-12-25 07:19:40 --> Total execution time: 0.0488
INFO - 2021-12-25 07:19:41 --> Config Class Initialized
INFO - 2021-12-25 07:19:41 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:19:41 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:19:41 --> Utf8 Class Initialized
INFO - 2021-12-25 07:19:41 --> URI Class Initialized
INFO - 2021-12-25 07:19:41 --> Router Class Initialized
INFO - 2021-12-25 07:19:41 --> Output Class Initialized
INFO - 2021-12-25 07:19:41 --> Security Class Initialized
DEBUG - 2021-12-25 07:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:19:41 --> Input Class Initialized
INFO - 2021-12-25 07:19:41 --> Language Class Initialized
INFO - 2021-12-25 07:19:41 --> Language Class Initialized
INFO - 2021-12-25 07:19:41 --> Config Class Initialized
INFO - 2021-12-25 07:19:41 --> Loader Class Initialized
INFO - 2021-12-25 07:19:41 --> Helper loaded: url_helper
INFO - 2021-12-25 07:19:41 --> Helper loaded: file_helper
INFO - 2021-12-25 07:19:41 --> Helper loaded: form_helper
INFO - 2021-12-25 07:19:41 --> Helper loaded: my_helper
INFO - 2021-12-25 07:19:41 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:19:41 --> Controller Class Initialized
INFO - 2021-12-25 07:19:41 --> Final output sent to browser
DEBUG - 2021-12-25 07:19:41 --> Total execution time: 0.0496
INFO - 2021-12-25 07:19:54 --> Config Class Initialized
INFO - 2021-12-25 07:19:54 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:19:54 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:19:54 --> Utf8 Class Initialized
INFO - 2021-12-25 07:19:54 --> URI Class Initialized
INFO - 2021-12-25 07:19:54 --> Router Class Initialized
INFO - 2021-12-25 07:19:54 --> Output Class Initialized
INFO - 2021-12-25 07:19:54 --> Security Class Initialized
DEBUG - 2021-12-25 07:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:19:54 --> Input Class Initialized
INFO - 2021-12-25 07:19:54 --> Language Class Initialized
INFO - 2021-12-25 07:19:54 --> Language Class Initialized
INFO - 2021-12-25 07:19:54 --> Config Class Initialized
INFO - 2021-12-25 07:19:54 --> Loader Class Initialized
INFO - 2021-12-25 07:19:54 --> Helper loaded: url_helper
INFO - 2021-12-25 07:19:54 --> Helper loaded: file_helper
INFO - 2021-12-25 07:19:54 --> Helper loaded: form_helper
INFO - 2021-12-25 07:19:54 --> Helper loaded: my_helper
INFO - 2021-12-25 07:19:54 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:19:54 --> Controller Class Initialized
INFO - 2021-12-25 07:19:54 --> Final output sent to browser
DEBUG - 2021-12-25 07:19:54 --> Total execution time: 0.0393
INFO - 2021-12-25 07:19:55 --> Config Class Initialized
INFO - 2021-12-25 07:19:55 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:19:55 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:19:55 --> Utf8 Class Initialized
INFO - 2021-12-25 07:19:55 --> URI Class Initialized
INFO - 2021-12-25 07:19:55 --> Router Class Initialized
INFO - 2021-12-25 07:19:55 --> Output Class Initialized
INFO - 2021-12-25 07:19:55 --> Security Class Initialized
DEBUG - 2021-12-25 07:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:19:55 --> Input Class Initialized
INFO - 2021-12-25 07:19:55 --> Language Class Initialized
INFO - 2021-12-25 07:19:55 --> Language Class Initialized
INFO - 2021-12-25 07:19:55 --> Config Class Initialized
INFO - 2021-12-25 07:19:55 --> Loader Class Initialized
INFO - 2021-12-25 07:19:55 --> Helper loaded: url_helper
INFO - 2021-12-25 07:19:55 --> Helper loaded: file_helper
INFO - 2021-12-25 07:19:55 --> Helper loaded: form_helper
INFO - 2021-12-25 07:19:55 --> Helper loaded: my_helper
INFO - 2021-12-25 07:19:55 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:19:55 --> Controller Class Initialized
INFO - 2021-12-25 07:19:55 --> Final output sent to browser
DEBUG - 2021-12-25 07:19:55 --> Total execution time: 0.0499
INFO - 2021-12-25 07:20:04 --> Config Class Initialized
INFO - 2021-12-25 07:20:04 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:20:04 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:20:04 --> Utf8 Class Initialized
INFO - 2021-12-25 07:20:04 --> URI Class Initialized
INFO - 2021-12-25 07:20:04 --> Router Class Initialized
INFO - 2021-12-25 07:20:04 --> Output Class Initialized
INFO - 2021-12-25 07:20:04 --> Security Class Initialized
DEBUG - 2021-12-25 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:20:04 --> Input Class Initialized
INFO - 2021-12-25 07:20:04 --> Language Class Initialized
INFO - 2021-12-25 07:20:04 --> Language Class Initialized
INFO - 2021-12-25 07:20:04 --> Config Class Initialized
INFO - 2021-12-25 07:20:04 --> Loader Class Initialized
INFO - 2021-12-25 07:20:04 --> Helper loaded: url_helper
INFO - 2021-12-25 07:20:04 --> Helper loaded: file_helper
INFO - 2021-12-25 07:20:04 --> Helper loaded: form_helper
INFO - 2021-12-25 07:20:04 --> Helper loaded: my_helper
INFO - 2021-12-25 07:20:04 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:20:04 --> Controller Class Initialized
INFO - 2021-12-25 07:20:04 --> Final output sent to browser
DEBUG - 2021-12-25 07:20:04 --> Total execution time: 0.0482
INFO - 2021-12-25 07:23:06 --> Config Class Initialized
INFO - 2021-12-25 07:23:06 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:06 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:06 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:06 --> URI Class Initialized
INFO - 2021-12-25 07:23:06 --> Router Class Initialized
INFO - 2021-12-25 07:23:06 --> Output Class Initialized
INFO - 2021-12-25 07:23:06 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:06 --> Input Class Initialized
INFO - 2021-12-25 07:23:06 --> Language Class Initialized
INFO - 2021-12-25 07:23:06 --> Language Class Initialized
INFO - 2021-12-25 07:23:06 --> Config Class Initialized
INFO - 2021-12-25 07:23:06 --> Loader Class Initialized
INFO - 2021-12-25 07:23:06 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:06 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:06 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:06 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:06 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:06 --> Controller Class Initialized
DEBUG - 2021-12-25 07:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:23:06 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:06 --> Total execution time: 0.0412
INFO - 2021-12-25 07:23:07 --> Config Class Initialized
INFO - 2021-12-25 07:23:07 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:07 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:07 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:07 --> URI Class Initialized
INFO - 2021-12-25 07:23:07 --> Router Class Initialized
INFO - 2021-12-25 07:23:07 --> Output Class Initialized
INFO - 2021-12-25 07:23:07 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:07 --> Input Class Initialized
INFO - 2021-12-25 07:23:07 --> Language Class Initialized
INFO - 2021-12-25 07:23:07 --> Language Class Initialized
INFO - 2021-12-25 07:23:07 --> Config Class Initialized
INFO - 2021-12-25 07:23:07 --> Loader Class Initialized
INFO - 2021-12-25 07:23:07 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:07 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:07 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:07 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:07 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:07 --> Controller Class Initialized
INFO - 2021-12-25 07:23:07 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:07 --> Total execution time: 0.0495
INFO - 2021-12-25 07:23:18 --> Config Class Initialized
INFO - 2021-12-25 07:23:18 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:18 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:18 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:18 --> URI Class Initialized
INFO - 2021-12-25 07:23:18 --> Router Class Initialized
INFO - 2021-12-25 07:23:18 --> Output Class Initialized
INFO - 2021-12-25 07:23:18 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:18 --> Input Class Initialized
INFO - 2021-12-25 07:23:18 --> Language Class Initialized
INFO - 2021-12-25 07:23:18 --> Language Class Initialized
INFO - 2021-12-25 07:23:18 --> Config Class Initialized
INFO - 2021-12-25 07:23:18 --> Loader Class Initialized
INFO - 2021-12-25 07:23:18 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:18 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:18 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:18 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:18 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:18 --> Controller Class Initialized
DEBUG - 2021-12-25 07:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:23:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:23:18 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:18 --> Total execution time: 0.0510
INFO - 2021-12-25 07:23:19 --> Config Class Initialized
INFO - 2021-12-25 07:23:19 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:19 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:19 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:19 --> URI Class Initialized
INFO - 2021-12-25 07:23:19 --> Router Class Initialized
INFO - 2021-12-25 07:23:19 --> Output Class Initialized
INFO - 2021-12-25 07:23:19 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:19 --> Input Class Initialized
INFO - 2021-12-25 07:23:19 --> Language Class Initialized
INFO - 2021-12-25 07:23:19 --> Language Class Initialized
INFO - 2021-12-25 07:23:19 --> Config Class Initialized
INFO - 2021-12-25 07:23:19 --> Loader Class Initialized
INFO - 2021-12-25 07:23:19 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:19 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:19 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:19 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:19 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:19 --> Controller Class Initialized
INFO - 2021-12-25 07:23:19 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:19 --> Total execution time: 0.0494
INFO - 2021-12-25 07:23:52 --> Config Class Initialized
INFO - 2021-12-25 07:23:52 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:52 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:52 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:52 --> URI Class Initialized
INFO - 2021-12-25 07:23:52 --> Router Class Initialized
INFO - 2021-12-25 07:23:52 --> Output Class Initialized
INFO - 2021-12-25 07:23:52 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:52 --> Input Class Initialized
INFO - 2021-12-25 07:23:52 --> Language Class Initialized
INFO - 2021-12-25 07:23:52 --> Language Class Initialized
INFO - 2021-12-25 07:23:52 --> Config Class Initialized
INFO - 2021-12-25 07:23:52 --> Loader Class Initialized
INFO - 2021-12-25 07:23:52 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:52 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:52 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:52 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:52 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:52 --> Controller Class Initialized
DEBUG - 2021-12-25 07:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:23:52 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:52 --> Total execution time: 0.0502
INFO - 2021-12-25 07:23:53 --> Config Class Initialized
INFO - 2021-12-25 07:23:53 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:53 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:53 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:53 --> URI Class Initialized
INFO - 2021-12-25 07:23:53 --> Router Class Initialized
INFO - 2021-12-25 07:23:53 --> Output Class Initialized
INFO - 2021-12-25 07:23:53 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:53 --> Input Class Initialized
INFO - 2021-12-25 07:23:53 --> Language Class Initialized
INFO - 2021-12-25 07:23:53 --> Language Class Initialized
INFO - 2021-12-25 07:23:53 --> Config Class Initialized
INFO - 2021-12-25 07:23:53 --> Loader Class Initialized
INFO - 2021-12-25 07:23:53 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:53 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:53 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:53 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:53 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:53 --> Controller Class Initialized
INFO - 2021-12-25 07:23:53 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:53 --> Total execution time: 0.0485
INFO - 2021-12-25 07:23:57 --> Config Class Initialized
INFO - 2021-12-25 07:23:57 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:23:57 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:23:57 --> Utf8 Class Initialized
INFO - 2021-12-25 07:23:57 --> URI Class Initialized
INFO - 2021-12-25 07:23:57 --> Router Class Initialized
INFO - 2021-12-25 07:23:57 --> Output Class Initialized
INFO - 2021-12-25 07:23:57 --> Security Class Initialized
DEBUG - 2021-12-25 07:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:23:57 --> Input Class Initialized
INFO - 2021-12-25 07:23:57 --> Language Class Initialized
INFO - 2021-12-25 07:23:57 --> Language Class Initialized
INFO - 2021-12-25 07:23:57 --> Config Class Initialized
INFO - 2021-12-25 07:23:57 --> Loader Class Initialized
INFO - 2021-12-25 07:23:57 --> Helper loaded: url_helper
INFO - 2021-12-25 07:23:57 --> Helper loaded: file_helper
INFO - 2021-12-25 07:23:57 --> Helper loaded: form_helper
INFO - 2021-12-25 07:23:57 --> Helper loaded: my_helper
INFO - 2021-12-25 07:23:57 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:23:57 --> Controller Class Initialized
INFO - 2021-12-25 07:23:57 --> Final output sent to browser
DEBUG - 2021-12-25 07:23:57 --> Total execution time: 0.1070
INFO - 2021-12-25 07:24:17 --> Config Class Initialized
INFO - 2021-12-25 07:24:17 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:24:17 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:24:17 --> Utf8 Class Initialized
INFO - 2021-12-25 07:24:17 --> URI Class Initialized
INFO - 2021-12-25 07:24:17 --> Router Class Initialized
INFO - 2021-12-25 07:24:17 --> Output Class Initialized
INFO - 2021-12-25 07:24:17 --> Security Class Initialized
DEBUG - 2021-12-25 07:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:24:17 --> Input Class Initialized
INFO - 2021-12-25 07:24:17 --> Language Class Initialized
INFO - 2021-12-25 07:24:17 --> Language Class Initialized
INFO - 2021-12-25 07:24:17 --> Config Class Initialized
INFO - 2021-12-25 07:24:17 --> Loader Class Initialized
INFO - 2021-12-25 07:24:17 --> Helper loaded: url_helper
INFO - 2021-12-25 07:24:17 --> Helper loaded: file_helper
INFO - 2021-12-25 07:24:17 --> Helper loaded: form_helper
INFO - 2021-12-25 07:24:17 --> Helper loaded: my_helper
INFO - 2021-12-25 07:24:17 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:24:17 --> Controller Class Initialized
DEBUG - 2021-12-25 07:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-25 07:24:17 --> Final output sent to browser
DEBUG - 2021-12-25 07:24:17 --> Total execution time: 0.0938
INFO - 2021-12-25 07:32:31 --> Config Class Initialized
INFO - 2021-12-25 07:32:31 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:32:31 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:32:31 --> Utf8 Class Initialized
INFO - 2021-12-25 07:32:31 --> URI Class Initialized
INFO - 2021-12-25 07:32:31 --> Router Class Initialized
INFO - 2021-12-25 07:32:31 --> Output Class Initialized
INFO - 2021-12-25 07:32:31 --> Security Class Initialized
DEBUG - 2021-12-25 07:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:32:31 --> Input Class Initialized
INFO - 2021-12-25 07:32:31 --> Language Class Initialized
ERROR - 2021-12-25 07:32:31 --> 404 Page Not Found: ../modules/n_ekstra/controllers/N_ekstra/index
INFO - 2021-12-25 07:33:28 --> Config Class Initialized
INFO - 2021-12-25 07:33:28 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:33:28 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:33:28 --> Utf8 Class Initialized
INFO - 2021-12-25 07:33:28 --> URI Class Initialized
INFO - 2021-12-25 07:33:28 --> Router Class Initialized
INFO - 2021-12-25 07:33:28 --> Output Class Initialized
INFO - 2021-12-25 07:33:28 --> Security Class Initialized
DEBUG - 2021-12-25 07:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:33:28 --> Input Class Initialized
INFO - 2021-12-25 07:33:28 --> Language Class Initialized
INFO - 2021-12-25 07:33:28 --> Language Class Initialized
INFO - 2021-12-25 07:33:28 --> Config Class Initialized
INFO - 2021-12-25 07:33:28 --> Loader Class Initialized
INFO - 2021-12-25 07:33:28 --> Helper loaded: url_helper
INFO - 2021-12-25 07:33:28 --> Helper loaded: file_helper
INFO - 2021-12-25 07:33:28 --> Helper loaded: form_helper
INFO - 2021-12-25 07:33:28 --> Helper loaded: my_helper
INFO - 2021-12-25 07:33:28 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:33:28 --> Controller Class Initialized
DEBUG - 2021-12-25 07:33:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:33:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:33:28 --> Final output sent to browser
DEBUG - 2021-12-25 07:33:28 --> Total execution time: 0.0536
INFO - 2021-12-25 07:36:41 --> Config Class Initialized
INFO - 2021-12-25 07:36:41 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:36:41 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:36:41 --> Utf8 Class Initialized
INFO - 2021-12-25 07:36:41 --> URI Class Initialized
INFO - 2021-12-25 07:36:41 --> Router Class Initialized
INFO - 2021-12-25 07:36:41 --> Output Class Initialized
INFO - 2021-12-25 07:36:41 --> Security Class Initialized
DEBUG - 2021-12-25 07:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:36:41 --> Input Class Initialized
INFO - 2021-12-25 07:36:41 --> Language Class Initialized
INFO - 2021-12-25 07:36:41 --> Language Class Initialized
INFO - 2021-12-25 07:36:41 --> Config Class Initialized
INFO - 2021-12-25 07:36:41 --> Loader Class Initialized
INFO - 2021-12-25 07:36:41 --> Helper loaded: url_helper
INFO - 2021-12-25 07:36:41 --> Helper loaded: file_helper
INFO - 2021-12-25 07:36:41 --> Helper loaded: form_helper
INFO - 2021-12-25 07:36:41 --> Helper loaded: my_helper
INFO - 2021-12-25 07:36:41 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:36:41 --> Controller Class Initialized
DEBUG - 2021-12-25 07:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:36:41 --> Final output sent to browser
DEBUG - 2021-12-25 07:36:41 --> Total execution time: 0.0451
INFO - 2021-12-25 07:36:43 --> Config Class Initialized
INFO - 2021-12-25 07:36:43 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:36:43 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:36:43 --> Utf8 Class Initialized
INFO - 2021-12-25 07:36:43 --> URI Class Initialized
INFO - 2021-12-25 07:36:43 --> Router Class Initialized
INFO - 2021-12-25 07:36:43 --> Output Class Initialized
INFO - 2021-12-25 07:36:43 --> Security Class Initialized
DEBUG - 2021-12-25 07:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:36:43 --> Input Class Initialized
INFO - 2021-12-25 07:36:43 --> Language Class Initialized
INFO - 2021-12-25 07:36:43 --> Language Class Initialized
INFO - 2021-12-25 07:36:43 --> Config Class Initialized
INFO - 2021-12-25 07:36:43 --> Loader Class Initialized
INFO - 2021-12-25 07:36:43 --> Helper loaded: url_helper
INFO - 2021-12-25 07:36:43 --> Helper loaded: file_helper
INFO - 2021-12-25 07:36:43 --> Helper loaded: form_helper
INFO - 2021-12-25 07:36:43 --> Helper loaded: my_helper
INFO - 2021-12-25 07:36:43 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:36:43 --> Controller Class Initialized
DEBUG - 2021-12-25 07:36:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:36:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:36:43 --> Final output sent to browser
DEBUG - 2021-12-25 07:36:43 --> Total execution time: 0.0538
INFO - 2021-12-25 07:36:52 --> Config Class Initialized
INFO - 2021-12-25 07:36:52 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:36:52 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:36:52 --> Utf8 Class Initialized
INFO - 2021-12-25 07:36:52 --> URI Class Initialized
INFO - 2021-12-25 07:36:52 --> Router Class Initialized
INFO - 2021-12-25 07:36:52 --> Output Class Initialized
INFO - 2021-12-25 07:36:52 --> Security Class Initialized
DEBUG - 2021-12-25 07:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:36:52 --> Input Class Initialized
INFO - 2021-12-25 07:36:52 --> Language Class Initialized
INFO - 2021-12-25 07:36:52 --> Language Class Initialized
INFO - 2021-12-25 07:36:52 --> Config Class Initialized
INFO - 2021-12-25 07:36:52 --> Loader Class Initialized
INFO - 2021-12-25 07:36:52 --> Helper loaded: url_helper
INFO - 2021-12-25 07:36:52 --> Helper loaded: file_helper
INFO - 2021-12-25 07:36:52 --> Helper loaded: form_helper
INFO - 2021-12-25 07:36:52 --> Helper loaded: my_helper
INFO - 2021-12-25 07:36:52 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:36:52 --> Controller Class Initialized
INFO - 2021-12-25 07:36:52 --> Final output sent to browser
DEBUG - 2021-12-25 07:36:52 --> Total execution time: 0.0939
INFO - 2021-12-25 07:36:55 --> Config Class Initialized
INFO - 2021-12-25 07:36:55 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:36:55 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:36:55 --> Utf8 Class Initialized
INFO - 2021-12-25 07:36:55 --> URI Class Initialized
INFO - 2021-12-25 07:36:55 --> Router Class Initialized
INFO - 2021-12-25 07:36:55 --> Output Class Initialized
INFO - 2021-12-25 07:36:55 --> Security Class Initialized
DEBUG - 2021-12-25 07:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:36:55 --> Input Class Initialized
INFO - 2021-12-25 07:36:55 --> Language Class Initialized
INFO - 2021-12-25 07:36:55 --> Language Class Initialized
INFO - 2021-12-25 07:36:55 --> Config Class Initialized
INFO - 2021-12-25 07:36:55 --> Loader Class Initialized
INFO - 2021-12-25 07:36:55 --> Helper loaded: url_helper
INFO - 2021-12-25 07:36:55 --> Helper loaded: file_helper
INFO - 2021-12-25 07:36:55 --> Helper loaded: form_helper
INFO - 2021-12-25 07:36:55 --> Helper loaded: my_helper
INFO - 2021-12-25 07:36:55 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:36:55 --> Controller Class Initialized
DEBUG - 2021-12-25 07:36:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-12-25 07:36:55 --> Final output sent to browser
DEBUG - 2021-12-25 07:36:55 --> Total execution time: 0.0679
INFO - 2021-12-25 07:42:33 --> Config Class Initialized
INFO - 2021-12-25 07:42:33 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:42:33 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:42:33 --> Utf8 Class Initialized
INFO - 2021-12-25 07:42:33 --> URI Class Initialized
INFO - 2021-12-25 07:42:33 --> Router Class Initialized
INFO - 2021-12-25 07:42:33 --> Output Class Initialized
INFO - 2021-12-25 07:42:33 --> Security Class Initialized
DEBUG - 2021-12-25 07:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:42:33 --> Input Class Initialized
INFO - 2021-12-25 07:42:33 --> Language Class Initialized
INFO - 2021-12-25 07:42:33 --> Language Class Initialized
INFO - 2021-12-25 07:42:33 --> Config Class Initialized
INFO - 2021-12-25 07:42:33 --> Loader Class Initialized
INFO - 2021-12-25 07:42:33 --> Helper loaded: url_helper
INFO - 2021-12-25 07:42:33 --> Helper loaded: file_helper
INFO - 2021-12-25 07:42:33 --> Helper loaded: form_helper
INFO - 2021-12-25 07:42:33 --> Helper loaded: my_helper
INFO - 2021-12-25 07:42:33 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:42:33 --> Controller Class Initialized
DEBUG - 2021-12-25 07:42:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-25 07:42:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:42:33 --> Final output sent to browser
DEBUG - 2021-12-25 07:42:33 --> Total execution time: 0.0552
INFO - 2021-12-25 07:42:34 --> Config Class Initialized
INFO - 2021-12-25 07:42:34 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:42:34 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:42:34 --> Utf8 Class Initialized
INFO - 2021-12-25 07:42:34 --> URI Class Initialized
INFO - 2021-12-25 07:42:34 --> Router Class Initialized
INFO - 2021-12-25 07:42:34 --> Output Class Initialized
INFO - 2021-12-25 07:42:34 --> Security Class Initialized
DEBUG - 2021-12-25 07:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:42:34 --> Input Class Initialized
INFO - 2021-12-25 07:42:34 --> Language Class Initialized
INFO - 2021-12-25 07:42:34 --> Language Class Initialized
INFO - 2021-12-25 07:42:34 --> Config Class Initialized
INFO - 2021-12-25 07:42:34 --> Loader Class Initialized
INFO - 2021-12-25 07:42:34 --> Helper loaded: url_helper
INFO - 2021-12-25 07:42:34 --> Helper loaded: file_helper
INFO - 2021-12-25 07:42:34 --> Helper loaded: form_helper
INFO - 2021-12-25 07:42:34 --> Helper loaded: my_helper
INFO - 2021-12-25 07:42:34 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:42:34 --> Controller Class Initialized
DEBUG - 2021-12-25 07:42:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:42:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:42:34 --> Final output sent to browser
DEBUG - 2021-12-25 07:42:34 --> Total execution time: 0.0436
INFO - 2021-12-25 07:42:37 --> Config Class Initialized
INFO - 2021-12-25 07:42:37 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:42:37 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:42:37 --> Utf8 Class Initialized
INFO - 2021-12-25 07:42:37 --> URI Class Initialized
INFO - 2021-12-25 07:42:37 --> Router Class Initialized
INFO - 2021-12-25 07:42:37 --> Output Class Initialized
INFO - 2021-12-25 07:42:37 --> Security Class Initialized
DEBUG - 2021-12-25 07:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:42:37 --> Input Class Initialized
INFO - 2021-12-25 07:42:37 --> Language Class Initialized
INFO - 2021-12-25 07:42:37 --> Language Class Initialized
INFO - 2021-12-25 07:42:37 --> Config Class Initialized
INFO - 2021-12-25 07:42:37 --> Loader Class Initialized
INFO - 2021-12-25 07:42:37 --> Helper loaded: url_helper
INFO - 2021-12-25 07:42:37 --> Helper loaded: file_helper
INFO - 2021-12-25 07:42:37 --> Helper loaded: form_helper
INFO - 2021-12-25 07:42:37 --> Helper loaded: my_helper
INFO - 2021-12-25 07:42:37 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:42:37 --> Controller Class Initialized
INFO - 2021-12-25 07:42:37 --> Final output sent to browser
DEBUG - 2021-12-25 07:42:37 --> Total execution time: 0.0400
INFO - 2021-12-25 07:43:16 --> Config Class Initialized
INFO - 2021-12-25 07:43:16 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:43:16 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:43:16 --> Utf8 Class Initialized
INFO - 2021-12-25 07:43:16 --> URI Class Initialized
INFO - 2021-12-25 07:43:16 --> Router Class Initialized
INFO - 2021-12-25 07:43:16 --> Output Class Initialized
INFO - 2021-12-25 07:43:16 --> Security Class Initialized
DEBUG - 2021-12-25 07:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:43:16 --> Input Class Initialized
INFO - 2021-12-25 07:43:16 --> Language Class Initialized
INFO - 2021-12-25 07:43:16 --> Language Class Initialized
INFO - 2021-12-25 07:43:16 --> Config Class Initialized
INFO - 2021-12-25 07:43:16 --> Loader Class Initialized
INFO - 2021-12-25 07:43:16 --> Helper loaded: url_helper
INFO - 2021-12-25 07:43:16 --> Helper loaded: file_helper
INFO - 2021-12-25 07:43:16 --> Helper loaded: form_helper
INFO - 2021-12-25 07:43:16 --> Helper loaded: my_helper
INFO - 2021-12-25 07:43:16 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:43:16 --> Controller Class Initialized
DEBUG - 2021-12-25 07:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:43:16 --> Final output sent to browser
DEBUG - 2021-12-25 07:43:16 --> Total execution time: 0.0507
INFO - 2021-12-25 07:43:17 --> Config Class Initialized
INFO - 2021-12-25 07:43:17 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:43:17 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:43:17 --> Utf8 Class Initialized
INFO - 2021-12-25 07:43:17 --> URI Class Initialized
INFO - 2021-12-25 07:43:17 --> Router Class Initialized
INFO - 2021-12-25 07:43:17 --> Output Class Initialized
INFO - 2021-12-25 07:43:17 --> Security Class Initialized
DEBUG - 2021-12-25 07:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:43:17 --> Input Class Initialized
INFO - 2021-12-25 07:43:17 --> Language Class Initialized
INFO - 2021-12-25 07:43:17 --> Language Class Initialized
INFO - 2021-12-25 07:43:17 --> Config Class Initialized
INFO - 2021-12-25 07:43:17 --> Loader Class Initialized
INFO - 2021-12-25 07:43:17 --> Helper loaded: url_helper
INFO - 2021-12-25 07:43:17 --> Helper loaded: file_helper
INFO - 2021-12-25 07:43:17 --> Helper loaded: form_helper
INFO - 2021-12-25 07:43:17 --> Helper loaded: my_helper
INFO - 2021-12-25 07:43:17 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:43:17 --> Controller Class Initialized
INFO - 2021-12-25 07:43:17 --> Final output sent to browser
DEBUG - 2021-12-25 07:43:17 --> Total execution time: 0.0502
INFO - 2021-12-25 07:43:50 --> Config Class Initialized
INFO - 2021-12-25 07:43:50 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:43:50 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:43:50 --> Utf8 Class Initialized
INFO - 2021-12-25 07:43:50 --> URI Class Initialized
INFO - 2021-12-25 07:43:50 --> Router Class Initialized
INFO - 2021-12-25 07:43:50 --> Output Class Initialized
INFO - 2021-12-25 07:43:50 --> Security Class Initialized
DEBUG - 2021-12-25 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:43:50 --> Input Class Initialized
INFO - 2021-12-25 07:43:50 --> Language Class Initialized
INFO - 2021-12-25 07:43:50 --> Language Class Initialized
INFO - 2021-12-25 07:43:50 --> Config Class Initialized
INFO - 2021-12-25 07:43:50 --> Loader Class Initialized
INFO - 2021-12-25 07:43:50 --> Helper loaded: url_helper
INFO - 2021-12-25 07:43:50 --> Helper loaded: file_helper
INFO - 2021-12-25 07:43:50 --> Helper loaded: form_helper
INFO - 2021-12-25 07:43:50 --> Helper loaded: my_helper
INFO - 2021-12-25 07:43:50 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:43:50 --> Controller Class Initialized
DEBUG - 2021-12-25 07:43:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-25 07:43:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-25 07:43:50 --> Final output sent to browser
DEBUG - 2021-12-25 07:43:50 --> Total execution time: 0.0511
INFO - 2021-12-25 07:43:51 --> Config Class Initialized
INFO - 2021-12-25 07:43:51 --> Hooks Class Initialized
DEBUG - 2021-12-25 07:43:51 --> UTF-8 Support Enabled
INFO - 2021-12-25 07:43:51 --> Utf8 Class Initialized
INFO - 2021-12-25 07:43:51 --> URI Class Initialized
INFO - 2021-12-25 07:43:51 --> Router Class Initialized
INFO - 2021-12-25 07:43:51 --> Output Class Initialized
INFO - 2021-12-25 07:43:51 --> Security Class Initialized
DEBUG - 2021-12-25 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-25 07:43:51 --> Input Class Initialized
INFO - 2021-12-25 07:43:51 --> Language Class Initialized
INFO - 2021-12-25 07:43:51 --> Language Class Initialized
INFO - 2021-12-25 07:43:51 --> Config Class Initialized
INFO - 2021-12-25 07:43:51 --> Loader Class Initialized
INFO - 2021-12-25 07:43:51 --> Helper loaded: url_helper
INFO - 2021-12-25 07:43:51 --> Helper loaded: file_helper
INFO - 2021-12-25 07:43:51 --> Helper loaded: form_helper
INFO - 2021-12-25 07:43:51 --> Helper loaded: my_helper
INFO - 2021-12-25 07:43:51 --> Database Driver Class Initialized
DEBUG - 2021-12-25 07:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-25 07:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-25 07:43:51 --> Controller Class Initialized
INFO - 2021-12-25 07:43:51 --> Final output sent to browser
DEBUG - 2021-12-25 07:43:51 --> Total execution time: 0.0409
