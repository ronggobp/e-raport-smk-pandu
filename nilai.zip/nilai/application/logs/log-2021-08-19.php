<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-19 07:04:06 --> Config Class Initialized
INFO - 2021-08-19 07:04:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:06 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:06 --> URI Class Initialized
INFO - 2021-08-19 07:04:06 --> Router Class Initialized
INFO - 2021-08-19 07:04:06 --> Output Class Initialized
INFO - 2021-08-19 07:04:06 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:06 --> Input Class Initialized
INFO - 2021-08-19 07:04:06 --> Language Class Initialized
INFO - 2021-08-19 07:04:06 --> Language Class Initialized
INFO - 2021-08-19 07:04:06 --> Config Class Initialized
INFO - 2021-08-19 07:04:06 --> Loader Class Initialized
INFO - 2021-08-19 07:04:06 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:06 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:06 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:06 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:07 --> Controller Class Initialized
DEBUG - 2021-08-19 07:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 07:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:04:07 --> Final output sent to browser
DEBUG - 2021-08-19 07:04:07 --> Total execution time: 0.7370
INFO - 2021-08-19 07:04:07 --> Config Class Initialized
INFO - 2021-08-19 07:04:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:07 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:07 --> URI Class Initialized
INFO - 2021-08-19 07:04:07 --> Router Class Initialized
INFO - 2021-08-19 07:04:07 --> Output Class Initialized
INFO - 2021-08-19 07:04:07 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:07 --> Input Class Initialized
INFO - 2021-08-19 07:04:07 --> Language Class Initialized
INFO - 2021-08-19 07:04:07 --> Language Class Initialized
INFO - 2021-08-19 07:04:07 --> Config Class Initialized
INFO - 2021-08-19 07:04:07 --> Loader Class Initialized
INFO - 2021-08-19 07:04:07 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:07 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:07 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:07 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:07 --> Controller Class Initialized
DEBUG - 2021-08-19 07:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 07:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:04:07 --> Final output sent to browser
DEBUG - 2021-08-19 07:04:07 --> Total execution time: 0.0495
INFO - 2021-08-19 07:04:48 --> Config Class Initialized
INFO - 2021-08-19 07:04:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:48 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:48 --> URI Class Initialized
INFO - 2021-08-19 07:04:48 --> Router Class Initialized
INFO - 2021-08-19 07:04:48 --> Output Class Initialized
INFO - 2021-08-19 07:04:48 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:48 --> Input Class Initialized
INFO - 2021-08-19 07:04:48 --> Language Class Initialized
INFO - 2021-08-19 07:04:48 --> Language Class Initialized
INFO - 2021-08-19 07:04:48 --> Config Class Initialized
INFO - 2021-08-19 07:04:48 --> Loader Class Initialized
INFO - 2021-08-19 07:04:48 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:48 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:48 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:48 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:48 --> Controller Class Initialized
INFO - 2021-08-19 07:04:49 --> Helper loaded: cookie_helper
INFO - 2021-08-19 07:04:49 --> Final output sent to browser
DEBUG - 2021-08-19 07:04:49 --> Total execution time: 0.3488
INFO - 2021-08-19 07:04:49 --> Config Class Initialized
INFO - 2021-08-19 07:04:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:49 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:49 --> URI Class Initialized
INFO - 2021-08-19 07:04:49 --> Router Class Initialized
INFO - 2021-08-19 07:04:49 --> Output Class Initialized
INFO - 2021-08-19 07:04:49 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:49 --> Input Class Initialized
INFO - 2021-08-19 07:04:49 --> Language Class Initialized
INFO - 2021-08-19 07:04:49 --> Language Class Initialized
INFO - 2021-08-19 07:04:49 --> Config Class Initialized
INFO - 2021-08-19 07:04:49 --> Loader Class Initialized
INFO - 2021-08-19 07:04:49 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:49 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:49 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:49 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:49 --> Controller Class Initialized
DEBUG - 2021-08-19 07:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 07:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:04:51 --> Final output sent to browser
DEBUG - 2021-08-19 07:04:51 --> Total execution time: 1.8624
INFO - 2021-08-19 07:04:54 --> Config Class Initialized
INFO - 2021-08-19 07:04:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:54 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:54 --> URI Class Initialized
INFO - 2021-08-19 07:04:54 --> Router Class Initialized
INFO - 2021-08-19 07:04:54 --> Output Class Initialized
INFO - 2021-08-19 07:04:54 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:54 --> Input Class Initialized
INFO - 2021-08-19 07:04:54 --> Language Class Initialized
INFO - 2021-08-19 07:04:54 --> Language Class Initialized
INFO - 2021-08-19 07:04:54 --> Config Class Initialized
INFO - 2021-08-19 07:04:54 --> Loader Class Initialized
INFO - 2021-08-19 07:04:54 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:54 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:54 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:54 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:54 --> Controller Class Initialized
DEBUG - 2021-08-19 07:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-08-19 07:04:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:04:54 --> Final output sent to browser
DEBUG - 2021-08-19 07:04:54 --> Total execution time: 0.1604
INFO - 2021-08-19 07:04:54 --> Config Class Initialized
INFO - 2021-08-19 07:04:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:54 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:54 --> URI Class Initialized
INFO - 2021-08-19 07:04:54 --> Router Class Initialized
INFO - 2021-08-19 07:04:54 --> Output Class Initialized
INFO - 2021-08-19 07:04:54 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:54 --> Input Class Initialized
INFO - 2021-08-19 07:04:54 --> Language Class Initialized
INFO - 2021-08-19 07:04:54 --> Language Class Initialized
INFO - 2021-08-19 07:04:54 --> Config Class Initialized
INFO - 2021-08-19 07:04:54 --> Loader Class Initialized
INFO - 2021-08-19 07:04:54 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:54 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:54 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:54 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:54 --> Controller Class Initialized
INFO - 2021-08-19 07:04:55 --> Config Class Initialized
INFO - 2021-08-19 07:04:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:55 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:55 --> URI Class Initialized
INFO - 2021-08-19 07:04:55 --> Router Class Initialized
INFO - 2021-08-19 07:04:55 --> Output Class Initialized
INFO - 2021-08-19 07:04:55 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:55 --> Input Class Initialized
INFO - 2021-08-19 07:04:55 --> Language Class Initialized
INFO - 2021-08-19 07:04:55 --> Language Class Initialized
INFO - 2021-08-19 07:04:55 --> Config Class Initialized
INFO - 2021-08-19 07:04:55 --> Loader Class Initialized
INFO - 2021-08-19 07:04:55 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:55 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:55 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:55 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:55 --> Controller Class Initialized
DEBUG - 2021-08-19 07:04:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 07:04:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:04:55 --> Final output sent to browser
DEBUG - 2021-08-19 07:04:55 --> Total execution time: 0.0691
INFO - 2021-08-19 07:04:55 --> Config Class Initialized
INFO - 2021-08-19 07:04:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:04:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:04:55 --> Utf8 Class Initialized
INFO - 2021-08-19 07:04:55 --> URI Class Initialized
INFO - 2021-08-19 07:04:55 --> Router Class Initialized
INFO - 2021-08-19 07:04:55 --> Output Class Initialized
INFO - 2021-08-19 07:04:55 --> Security Class Initialized
DEBUG - 2021-08-19 07:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:04:55 --> Input Class Initialized
INFO - 2021-08-19 07:04:55 --> Language Class Initialized
INFO - 2021-08-19 07:04:55 --> Language Class Initialized
INFO - 2021-08-19 07:04:55 --> Config Class Initialized
INFO - 2021-08-19 07:04:55 --> Loader Class Initialized
INFO - 2021-08-19 07:04:55 --> Helper loaded: url_helper
INFO - 2021-08-19 07:04:55 --> Helper loaded: file_helper
INFO - 2021-08-19 07:04:55 --> Helper loaded: form_helper
INFO - 2021-08-19 07:04:55 --> Helper loaded: my_helper
INFO - 2021-08-19 07:04:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:04:55 --> Controller Class Initialized
INFO - 2021-08-19 07:05:00 --> Config Class Initialized
INFO - 2021-08-19 07:05:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:00 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:00 --> URI Class Initialized
INFO - 2021-08-19 07:05:00 --> Router Class Initialized
INFO - 2021-08-19 07:05:00 --> Output Class Initialized
INFO - 2021-08-19 07:05:00 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:00 --> Input Class Initialized
INFO - 2021-08-19 07:05:00 --> Language Class Initialized
INFO - 2021-08-19 07:05:00 --> Language Class Initialized
INFO - 2021-08-19 07:05:00 --> Config Class Initialized
INFO - 2021-08-19 07:05:00 --> Loader Class Initialized
INFO - 2021-08-19 07:05:00 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:00 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:00 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:00 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:00 --> Controller Class Initialized
INFO - 2021-08-19 07:05:01 --> Config Class Initialized
INFO - 2021-08-19 07:05:01 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:01 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:01 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:01 --> URI Class Initialized
INFO - 2021-08-19 07:05:01 --> Router Class Initialized
INFO - 2021-08-19 07:05:01 --> Output Class Initialized
INFO - 2021-08-19 07:05:01 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:01 --> Input Class Initialized
INFO - 2021-08-19 07:05:01 --> Language Class Initialized
INFO - 2021-08-19 07:05:01 --> Language Class Initialized
INFO - 2021-08-19 07:05:01 --> Config Class Initialized
INFO - 2021-08-19 07:05:01 --> Loader Class Initialized
INFO - 2021-08-19 07:05:01 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:01 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:01 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:01 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:01 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:02 --> Controller Class Initialized
INFO - 2021-08-19 07:05:03 --> Config Class Initialized
INFO - 2021-08-19 07:05:03 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:03 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:03 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:03 --> URI Class Initialized
INFO - 2021-08-19 07:05:03 --> Router Class Initialized
INFO - 2021-08-19 07:05:03 --> Output Class Initialized
INFO - 2021-08-19 07:05:03 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:03 --> Input Class Initialized
INFO - 2021-08-19 07:05:03 --> Language Class Initialized
INFO - 2021-08-19 07:05:04 --> Language Class Initialized
INFO - 2021-08-19 07:05:04 --> Config Class Initialized
INFO - 2021-08-19 07:05:04 --> Loader Class Initialized
INFO - 2021-08-19 07:05:04 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:04 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:04 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:04 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:04 --> Controller Class Initialized
INFO - 2021-08-19 07:05:04 --> Config Class Initialized
INFO - 2021-08-19 07:05:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:04 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:04 --> URI Class Initialized
INFO - 2021-08-19 07:05:04 --> Router Class Initialized
INFO - 2021-08-19 07:05:04 --> Output Class Initialized
INFO - 2021-08-19 07:05:04 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:04 --> Input Class Initialized
INFO - 2021-08-19 07:05:04 --> Language Class Initialized
INFO - 2021-08-19 07:05:04 --> Language Class Initialized
INFO - 2021-08-19 07:05:04 --> Config Class Initialized
INFO - 2021-08-19 07:05:04 --> Loader Class Initialized
INFO - 2021-08-19 07:05:04 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:04 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:04 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:04 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:04 --> Controller Class Initialized
INFO - 2021-08-19 07:05:05 --> Config Class Initialized
INFO - 2021-08-19 07:05:05 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:05 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:05 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:05 --> URI Class Initialized
INFO - 2021-08-19 07:05:05 --> Router Class Initialized
INFO - 2021-08-19 07:05:05 --> Output Class Initialized
INFO - 2021-08-19 07:05:05 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:05 --> Input Class Initialized
INFO - 2021-08-19 07:05:05 --> Language Class Initialized
INFO - 2021-08-19 07:05:05 --> Language Class Initialized
INFO - 2021-08-19 07:05:05 --> Config Class Initialized
INFO - 2021-08-19 07:05:05 --> Loader Class Initialized
INFO - 2021-08-19 07:05:05 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:05 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:05 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:05 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:05 --> Controller Class Initialized
INFO - 2021-08-19 07:05:05 --> Config Class Initialized
INFO - 2021-08-19 07:05:05 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:05 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:05 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:05 --> URI Class Initialized
INFO - 2021-08-19 07:05:05 --> Router Class Initialized
INFO - 2021-08-19 07:05:05 --> Output Class Initialized
INFO - 2021-08-19 07:05:05 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:05 --> Input Class Initialized
INFO - 2021-08-19 07:05:05 --> Language Class Initialized
INFO - 2021-08-19 07:05:05 --> Language Class Initialized
INFO - 2021-08-19 07:05:05 --> Config Class Initialized
INFO - 2021-08-19 07:05:05 --> Loader Class Initialized
INFO - 2021-08-19 07:05:05 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:05 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:05 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:05 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:05 --> Controller Class Initialized
INFO - 2021-08-19 07:05:06 --> Config Class Initialized
INFO - 2021-08-19 07:05:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:06 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:06 --> URI Class Initialized
INFO - 2021-08-19 07:05:06 --> Router Class Initialized
INFO - 2021-08-19 07:05:06 --> Output Class Initialized
INFO - 2021-08-19 07:05:06 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:06 --> Input Class Initialized
INFO - 2021-08-19 07:05:06 --> Language Class Initialized
INFO - 2021-08-19 07:05:06 --> Language Class Initialized
INFO - 2021-08-19 07:05:06 --> Config Class Initialized
INFO - 2021-08-19 07:05:06 --> Loader Class Initialized
INFO - 2021-08-19 07:05:06 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:06 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:06 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:06 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:06 --> Controller Class Initialized
INFO - 2021-08-19 07:05:16 --> Config Class Initialized
INFO - 2021-08-19 07:05:16 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:16 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:16 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:16 --> URI Class Initialized
INFO - 2021-08-19 07:05:16 --> Router Class Initialized
INFO - 2021-08-19 07:05:16 --> Output Class Initialized
INFO - 2021-08-19 07:05:16 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:16 --> Input Class Initialized
INFO - 2021-08-19 07:05:16 --> Language Class Initialized
INFO - 2021-08-19 07:05:16 --> Language Class Initialized
INFO - 2021-08-19 07:05:16 --> Config Class Initialized
INFO - 2021-08-19 07:05:16 --> Loader Class Initialized
INFO - 2021-08-19 07:05:16 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:16 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:16 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:16 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:16 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:16 --> Controller Class Initialized
DEBUG - 2021-08-19 07:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 07:05:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:05:16 --> Final output sent to browser
DEBUG - 2021-08-19 07:05:16 --> Total execution time: 0.0423
INFO - 2021-08-19 07:05:17 --> Config Class Initialized
INFO - 2021-08-19 07:05:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:17 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:17 --> URI Class Initialized
INFO - 2021-08-19 07:05:17 --> Router Class Initialized
INFO - 2021-08-19 07:05:17 --> Output Class Initialized
INFO - 2021-08-19 07:05:17 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:17 --> Input Class Initialized
INFO - 2021-08-19 07:05:17 --> Language Class Initialized
INFO - 2021-08-19 07:05:17 --> Language Class Initialized
INFO - 2021-08-19 07:05:17 --> Config Class Initialized
INFO - 2021-08-19 07:05:17 --> Loader Class Initialized
INFO - 2021-08-19 07:05:17 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:17 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:17 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:17 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:17 --> Controller Class Initialized
INFO - 2021-08-19 07:05:42 --> Config Class Initialized
INFO - 2021-08-19 07:05:42 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:42 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:42 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:42 --> URI Class Initialized
INFO - 2021-08-19 07:05:42 --> Router Class Initialized
INFO - 2021-08-19 07:05:42 --> Output Class Initialized
INFO - 2021-08-19 07:05:42 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:42 --> Input Class Initialized
INFO - 2021-08-19 07:05:42 --> Language Class Initialized
INFO - 2021-08-19 07:05:42 --> Language Class Initialized
INFO - 2021-08-19 07:05:42 --> Config Class Initialized
INFO - 2021-08-19 07:05:42 --> Loader Class Initialized
INFO - 2021-08-19 07:05:42 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:42 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:42 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:42 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:42 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:42 --> Controller Class Initialized
INFO - 2021-08-19 07:05:43 --> Config Class Initialized
INFO - 2021-08-19 07:05:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:43 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:43 --> URI Class Initialized
INFO - 2021-08-19 07:05:43 --> Router Class Initialized
INFO - 2021-08-19 07:05:43 --> Output Class Initialized
INFO - 2021-08-19 07:05:43 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:43 --> Input Class Initialized
INFO - 2021-08-19 07:05:43 --> Language Class Initialized
INFO - 2021-08-19 07:05:43 --> Language Class Initialized
INFO - 2021-08-19 07:05:43 --> Config Class Initialized
INFO - 2021-08-19 07:05:43 --> Loader Class Initialized
INFO - 2021-08-19 07:05:43 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:43 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:43 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:43 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:43 --> Controller Class Initialized
INFO - 2021-08-19 07:05:43 --> Config Class Initialized
INFO - 2021-08-19 07:05:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:43 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:43 --> URI Class Initialized
INFO - 2021-08-19 07:05:43 --> Router Class Initialized
INFO - 2021-08-19 07:05:43 --> Output Class Initialized
INFO - 2021-08-19 07:05:43 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:43 --> Input Class Initialized
INFO - 2021-08-19 07:05:43 --> Language Class Initialized
INFO - 2021-08-19 07:05:43 --> Language Class Initialized
INFO - 2021-08-19 07:05:43 --> Config Class Initialized
INFO - 2021-08-19 07:05:43 --> Loader Class Initialized
INFO - 2021-08-19 07:05:43 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:43 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:43 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:43 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:43 --> Controller Class Initialized
INFO - 2021-08-19 07:05:44 --> Config Class Initialized
INFO - 2021-08-19 07:05:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:44 --> URI Class Initialized
INFO - 2021-08-19 07:05:44 --> Router Class Initialized
INFO - 2021-08-19 07:05:44 --> Output Class Initialized
INFO - 2021-08-19 07:05:44 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:44 --> Input Class Initialized
INFO - 2021-08-19 07:05:44 --> Language Class Initialized
INFO - 2021-08-19 07:05:44 --> Language Class Initialized
INFO - 2021-08-19 07:05:44 --> Config Class Initialized
INFO - 2021-08-19 07:05:44 --> Loader Class Initialized
INFO - 2021-08-19 07:05:44 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:44 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:44 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:44 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:44 --> Controller Class Initialized
INFO - 2021-08-19 07:05:44 --> Config Class Initialized
INFO - 2021-08-19 07:05:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:44 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:44 --> URI Class Initialized
INFO - 2021-08-19 07:05:44 --> Router Class Initialized
INFO - 2021-08-19 07:05:44 --> Output Class Initialized
INFO - 2021-08-19 07:05:44 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:44 --> Input Class Initialized
INFO - 2021-08-19 07:05:44 --> Language Class Initialized
INFO - 2021-08-19 07:05:44 --> Language Class Initialized
INFO - 2021-08-19 07:05:44 --> Config Class Initialized
INFO - 2021-08-19 07:05:44 --> Loader Class Initialized
INFO - 2021-08-19 07:05:44 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:44 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:44 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:44 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:44 --> Controller Class Initialized
INFO - 2021-08-19 07:05:45 --> Config Class Initialized
INFO - 2021-08-19 07:05:45 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:45 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:45 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:45 --> URI Class Initialized
INFO - 2021-08-19 07:05:45 --> Router Class Initialized
INFO - 2021-08-19 07:05:45 --> Output Class Initialized
INFO - 2021-08-19 07:05:45 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:45 --> Input Class Initialized
INFO - 2021-08-19 07:05:45 --> Language Class Initialized
INFO - 2021-08-19 07:05:45 --> Language Class Initialized
INFO - 2021-08-19 07:05:45 --> Config Class Initialized
INFO - 2021-08-19 07:05:45 --> Loader Class Initialized
INFO - 2021-08-19 07:05:45 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:45 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:45 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:45 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:45 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:45 --> Controller Class Initialized
INFO - 2021-08-19 07:05:47 --> Config Class Initialized
INFO - 2021-08-19 07:05:47 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:05:47 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:05:47 --> Utf8 Class Initialized
INFO - 2021-08-19 07:05:47 --> URI Class Initialized
INFO - 2021-08-19 07:05:47 --> Router Class Initialized
INFO - 2021-08-19 07:05:47 --> Output Class Initialized
INFO - 2021-08-19 07:05:47 --> Security Class Initialized
DEBUG - 2021-08-19 07:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:05:47 --> Input Class Initialized
INFO - 2021-08-19 07:05:47 --> Language Class Initialized
INFO - 2021-08-19 07:05:47 --> Language Class Initialized
INFO - 2021-08-19 07:05:47 --> Config Class Initialized
INFO - 2021-08-19 07:05:47 --> Loader Class Initialized
INFO - 2021-08-19 07:05:47 --> Helper loaded: url_helper
INFO - 2021-08-19 07:05:47 --> Helper loaded: file_helper
INFO - 2021-08-19 07:05:47 --> Helper loaded: form_helper
INFO - 2021-08-19 07:05:47 --> Helper loaded: my_helper
INFO - 2021-08-19 07:05:47 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:05:47 --> Controller Class Initialized
INFO - 2021-08-19 07:06:25 --> Config Class Initialized
INFO - 2021-08-19 07:06:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:25 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:25 --> URI Class Initialized
INFO - 2021-08-19 07:06:25 --> Router Class Initialized
INFO - 2021-08-19 07:06:25 --> Output Class Initialized
INFO - 2021-08-19 07:06:25 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:25 --> Input Class Initialized
INFO - 2021-08-19 07:06:25 --> Language Class Initialized
INFO - 2021-08-19 07:06:25 --> Language Class Initialized
INFO - 2021-08-19 07:06:25 --> Config Class Initialized
INFO - 2021-08-19 07:06:25 --> Loader Class Initialized
INFO - 2021-08-19 07:06:25 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:25 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:25 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:25 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:25 --> Controller Class Initialized
INFO - 2021-08-19 07:06:25 --> Config Class Initialized
INFO - 2021-08-19 07:06:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:25 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:25 --> URI Class Initialized
INFO - 2021-08-19 07:06:25 --> Router Class Initialized
INFO - 2021-08-19 07:06:25 --> Output Class Initialized
INFO - 2021-08-19 07:06:25 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:25 --> Input Class Initialized
INFO - 2021-08-19 07:06:25 --> Language Class Initialized
INFO - 2021-08-19 07:06:25 --> Language Class Initialized
INFO - 2021-08-19 07:06:25 --> Config Class Initialized
INFO - 2021-08-19 07:06:25 --> Loader Class Initialized
INFO - 2021-08-19 07:06:25 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:25 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:25 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:25 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:25 --> Controller Class Initialized
INFO - 2021-08-19 07:06:26 --> Config Class Initialized
INFO - 2021-08-19 07:06:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:26 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:26 --> URI Class Initialized
INFO - 2021-08-19 07:06:26 --> Router Class Initialized
INFO - 2021-08-19 07:06:26 --> Output Class Initialized
INFO - 2021-08-19 07:06:26 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:26 --> Input Class Initialized
INFO - 2021-08-19 07:06:26 --> Language Class Initialized
INFO - 2021-08-19 07:06:26 --> Language Class Initialized
INFO - 2021-08-19 07:06:26 --> Config Class Initialized
INFO - 2021-08-19 07:06:26 --> Loader Class Initialized
INFO - 2021-08-19 07:06:26 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:26 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:26 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:26 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:26 --> Controller Class Initialized
INFO - 2021-08-19 07:06:26 --> Config Class Initialized
INFO - 2021-08-19 07:06:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:26 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:26 --> URI Class Initialized
INFO - 2021-08-19 07:06:26 --> Router Class Initialized
INFO - 2021-08-19 07:06:26 --> Output Class Initialized
INFO - 2021-08-19 07:06:26 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:26 --> Input Class Initialized
INFO - 2021-08-19 07:06:26 --> Language Class Initialized
INFO - 2021-08-19 07:06:26 --> Language Class Initialized
INFO - 2021-08-19 07:06:26 --> Config Class Initialized
INFO - 2021-08-19 07:06:26 --> Loader Class Initialized
INFO - 2021-08-19 07:06:26 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:26 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:26 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:26 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:27 --> Controller Class Initialized
INFO - 2021-08-19 07:06:27 --> Config Class Initialized
INFO - 2021-08-19 07:06:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:27 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:27 --> URI Class Initialized
INFO - 2021-08-19 07:06:27 --> Router Class Initialized
INFO - 2021-08-19 07:06:27 --> Output Class Initialized
INFO - 2021-08-19 07:06:27 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:27 --> Input Class Initialized
INFO - 2021-08-19 07:06:27 --> Language Class Initialized
INFO - 2021-08-19 07:06:27 --> Language Class Initialized
INFO - 2021-08-19 07:06:27 --> Config Class Initialized
INFO - 2021-08-19 07:06:27 --> Loader Class Initialized
INFO - 2021-08-19 07:06:27 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:27 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:27 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:27 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:27 --> Controller Class Initialized
INFO - 2021-08-19 07:06:28 --> Config Class Initialized
INFO - 2021-08-19 07:06:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:28 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:28 --> URI Class Initialized
INFO - 2021-08-19 07:06:28 --> Router Class Initialized
INFO - 2021-08-19 07:06:28 --> Output Class Initialized
INFO - 2021-08-19 07:06:28 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:28 --> Input Class Initialized
INFO - 2021-08-19 07:06:28 --> Language Class Initialized
INFO - 2021-08-19 07:06:28 --> Language Class Initialized
INFO - 2021-08-19 07:06:28 --> Config Class Initialized
INFO - 2021-08-19 07:06:28 --> Loader Class Initialized
INFO - 2021-08-19 07:06:28 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:28 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:28 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:28 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:28 --> Controller Class Initialized
INFO - 2021-08-19 07:06:28 --> Config Class Initialized
INFO - 2021-08-19 07:06:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:28 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:28 --> URI Class Initialized
INFO - 2021-08-19 07:06:29 --> Router Class Initialized
INFO - 2021-08-19 07:06:29 --> Output Class Initialized
INFO - 2021-08-19 07:06:29 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:29 --> Input Class Initialized
INFO - 2021-08-19 07:06:29 --> Language Class Initialized
INFO - 2021-08-19 07:06:29 --> Language Class Initialized
INFO - 2021-08-19 07:06:29 --> Config Class Initialized
INFO - 2021-08-19 07:06:29 --> Loader Class Initialized
INFO - 2021-08-19 07:06:29 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:29 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:29 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:29 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:29 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:29 --> Controller Class Initialized
INFO - 2021-08-19 07:06:35 --> Config Class Initialized
INFO - 2021-08-19 07:06:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:35 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:35 --> URI Class Initialized
INFO - 2021-08-19 07:06:35 --> Router Class Initialized
INFO - 2021-08-19 07:06:35 --> Output Class Initialized
INFO - 2021-08-19 07:06:35 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:35 --> Input Class Initialized
INFO - 2021-08-19 07:06:35 --> Language Class Initialized
INFO - 2021-08-19 07:06:35 --> Language Class Initialized
INFO - 2021-08-19 07:06:35 --> Config Class Initialized
INFO - 2021-08-19 07:06:35 --> Loader Class Initialized
INFO - 2021-08-19 07:06:35 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:35 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:35 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:35 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:35 --> Controller Class Initialized
INFO - 2021-08-19 07:06:38 --> Config Class Initialized
INFO - 2021-08-19 07:06:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:06:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:06:38 --> Utf8 Class Initialized
INFO - 2021-08-19 07:06:38 --> URI Class Initialized
INFO - 2021-08-19 07:06:38 --> Router Class Initialized
INFO - 2021-08-19 07:06:38 --> Output Class Initialized
INFO - 2021-08-19 07:06:38 --> Security Class Initialized
DEBUG - 2021-08-19 07:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:06:38 --> Input Class Initialized
INFO - 2021-08-19 07:06:38 --> Language Class Initialized
INFO - 2021-08-19 07:06:38 --> Language Class Initialized
INFO - 2021-08-19 07:06:38 --> Config Class Initialized
INFO - 2021-08-19 07:06:38 --> Loader Class Initialized
INFO - 2021-08-19 07:06:38 --> Helper loaded: url_helper
INFO - 2021-08-19 07:06:38 --> Helper loaded: file_helper
INFO - 2021-08-19 07:06:38 --> Helper loaded: form_helper
INFO - 2021-08-19 07:06:38 --> Helper loaded: my_helper
INFO - 2021-08-19 07:06:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:06:38 --> Controller Class Initialized
INFO - 2021-08-19 07:14:36 --> Config Class Initialized
INFO - 2021-08-19 07:14:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:14:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:14:36 --> Utf8 Class Initialized
INFO - 2021-08-19 07:14:36 --> URI Class Initialized
INFO - 2021-08-19 07:14:36 --> Router Class Initialized
INFO - 2021-08-19 07:14:36 --> Output Class Initialized
INFO - 2021-08-19 07:14:36 --> Security Class Initialized
DEBUG - 2021-08-19 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:14:36 --> Input Class Initialized
INFO - 2021-08-19 07:14:36 --> Language Class Initialized
INFO - 2021-08-19 07:14:36 --> Language Class Initialized
INFO - 2021-08-19 07:14:36 --> Config Class Initialized
INFO - 2021-08-19 07:14:36 --> Loader Class Initialized
INFO - 2021-08-19 07:14:36 --> Helper loaded: url_helper
INFO - 2021-08-19 07:14:36 --> Helper loaded: file_helper
INFO - 2021-08-19 07:14:36 --> Helper loaded: form_helper
INFO - 2021-08-19 07:14:36 --> Helper loaded: my_helper
INFO - 2021-08-19 07:14:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:14:36 --> Controller Class Initialized
INFO - 2021-08-19 07:14:36 --> Helper loaded: cookie_helper
INFO - 2021-08-19 07:14:36 --> Config Class Initialized
INFO - 2021-08-19 07:14:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:14:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:14:36 --> Utf8 Class Initialized
INFO - 2021-08-19 07:14:36 --> URI Class Initialized
INFO - 2021-08-19 07:14:36 --> Router Class Initialized
INFO - 2021-08-19 07:14:36 --> Output Class Initialized
INFO - 2021-08-19 07:14:36 --> Security Class Initialized
DEBUG - 2021-08-19 07:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:14:36 --> Input Class Initialized
INFO - 2021-08-19 07:14:36 --> Language Class Initialized
INFO - 2021-08-19 07:14:36 --> Language Class Initialized
INFO - 2021-08-19 07:14:36 --> Config Class Initialized
INFO - 2021-08-19 07:14:36 --> Loader Class Initialized
INFO - 2021-08-19 07:14:36 --> Helper loaded: url_helper
INFO - 2021-08-19 07:14:36 --> Helper loaded: file_helper
INFO - 2021-08-19 07:14:36 --> Helper loaded: form_helper
INFO - 2021-08-19 07:14:36 --> Helper loaded: my_helper
INFO - 2021-08-19 07:14:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:14:36 --> Controller Class Initialized
DEBUG - 2021-08-19 07:14:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 07:14:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:14:36 --> Final output sent to browser
DEBUG - 2021-08-19 07:14:36 --> Total execution time: 0.0456
INFO - 2021-08-19 07:14:47 --> Config Class Initialized
INFO - 2021-08-19 07:14:47 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:14:47 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:14:47 --> Utf8 Class Initialized
INFO - 2021-08-19 07:14:47 --> URI Class Initialized
INFO - 2021-08-19 07:14:47 --> Router Class Initialized
INFO - 2021-08-19 07:14:47 --> Output Class Initialized
INFO - 2021-08-19 07:14:47 --> Security Class Initialized
DEBUG - 2021-08-19 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:14:47 --> Input Class Initialized
INFO - 2021-08-19 07:14:47 --> Language Class Initialized
INFO - 2021-08-19 07:14:47 --> Language Class Initialized
INFO - 2021-08-19 07:14:47 --> Config Class Initialized
INFO - 2021-08-19 07:14:47 --> Loader Class Initialized
INFO - 2021-08-19 07:14:47 --> Helper loaded: url_helper
INFO - 2021-08-19 07:14:47 --> Helper loaded: file_helper
INFO - 2021-08-19 07:14:47 --> Helper loaded: form_helper
INFO - 2021-08-19 07:14:47 --> Helper loaded: my_helper
INFO - 2021-08-19 07:14:47 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:14:47 --> Controller Class Initialized
INFO - 2021-08-19 07:14:47 --> Helper loaded: cookie_helper
INFO - 2021-08-19 07:14:47 --> Final output sent to browser
DEBUG - 2021-08-19 07:14:47 --> Total execution time: 0.0738
INFO - 2021-08-19 07:14:47 --> Config Class Initialized
INFO - 2021-08-19 07:14:47 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:14:47 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:14:47 --> Utf8 Class Initialized
INFO - 2021-08-19 07:14:47 --> URI Class Initialized
INFO - 2021-08-19 07:14:47 --> Router Class Initialized
INFO - 2021-08-19 07:14:47 --> Output Class Initialized
INFO - 2021-08-19 07:14:47 --> Security Class Initialized
DEBUG - 2021-08-19 07:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:14:47 --> Input Class Initialized
INFO - 2021-08-19 07:14:47 --> Language Class Initialized
INFO - 2021-08-19 07:14:47 --> Language Class Initialized
INFO - 2021-08-19 07:14:47 --> Config Class Initialized
INFO - 2021-08-19 07:14:47 --> Loader Class Initialized
INFO - 2021-08-19 07:14:47 --> Helper loaded: url_helper
INFO - 2021-08-19 07:14:47 --> Helper loaded: file_helper
INFO - 2021-08-19 07:14:47 --> Helper loaded: form_helper
INFO - 2021-08-19 07:14:47 --> Helper loaded: my_helper
INFO - 2021-08-19 07:14:47 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:14:47 --> Controller Class Initialized
DEBUG - 2021-08-19 07:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 07:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:14:48 --> Final output sent to browser
DEBUG - 2021-08-19 07:14:48 --> Total execution time: 0.6187
INFO - 2021-08-19 07:14:50 --> Config Class Initialized
INFO - 2021-08-19 07:14:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:14:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:14:50 --> Utf8 Class Initialized
INFO - 2021-08-19 07:14:50 --> URI Class Initialized
INFO - 2021-08-19 07:14:50 --> Router Class Initialized
INFO - 2021-08-19 07:14:50 --> Output Class Initialized
INFO - 2021-08-19 07:14:50 --> Security Class Initialized
DEBUG - 2021-08-19 07:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:14:50 --> Input Class Initialized
INFO - 2021-08-19 07:14:50 --> Language Class Initialized
INFO - 2021-08-19 07:14:50 --> Language Class Initialized
INFO - 2021-08-19 07:14:50 --> Config Class Initialized
INFO - 2021-08-19 07:14:50 --> Loader Class Initialized
INFO - 2021-08-19 07:14:50 --> Helper loaded: url_helper
INFO - 2021-08-19 07:14:50 --> Helper loaded: file_helper
INFO - 2021-08-19 07:14:50 --> Helper loaded: form_helper
INFO - 2021-08-19 07:14:50 --> Helper loaded: my_helper
INFO - 2021-08-19 07:14:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:14:51 --> Controller Class Initialized
DEBUG - 2021-08-19 07:14:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 07:14:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:14:51 --> Final output sent to browser
DEBUG - 2021-08-19 07:14:51 --> Total execution time: 0.1006
INFO - 2021-08-19 07:15:01 --> Config Class Initialized
INFO - 2021-08-19 07:15:01 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:15:01 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:15:01 --> Utf8 Class Initialized
INFO - 2021-08-19 07:15:01 --> URI Class Initialized
INFO - 2021-08-19 07:15:01 --> Router Class Initialized
INFO - 2021-08-19 07:15:01 --> Output Class Initialized
INFO - 2021-08-19 07:15:01 --> Security Class Initialized
DEBUG - 2021-08-19 07:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:15:01 --> Input Class Initialized
INFO - 2021-08-19 07:15:01 --> Language Class Initialized
INFO - 2021-08-19 07:15:01 --> Language Class Initialized
INFO - 2021-08-19 07:15:01 --> Config Class Initialized
INFO - 2021-08-19 07:15:01 --> Loader Class Initialized
INFO - 2021-08-19 07:15:01 --> Helper loaded: url_helper
INFO - 2021-08-19 07:15:01 --> Helper loaded: file_helper
INFO - 2021-08-19 07:15:01 --> Helper loaded: form_helper
INFO - 2021-08-19 07:15:01 --> Helper loaded: my_helper
INFO - 2021-08-19 07:15:01 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:15:01 --> Controller Class Initialized
DEBUG - 2021-08-19 07:15:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 07:15:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:15:01 --> Final output sent to browser
DEBUG - 2021-08-19 07:15:01 --> Total execution time: 0.1054
INFO - 2021-08-19 07:15:01 --> Config Class Initialized
INFO - 2021-08-19 07:15:01 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:15:01 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:15:01 --> Utf8 Class Initialized
INFO - 2021-08-19 07:15:01 --> URI Class Initialized
INFO - 2021-08-19 07:15:01 --> Router Class Initialized
INFO - 2021-08-19 07:15:01 --> Output Class Initialized
INFO - 2021-08-19 07:15:01 --> Security Class Initialized
DEBUG - 2021-08-19 07:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:15:01 --> Input Class Initialized
INFO - 2021-08-19 07:15:01 --> Language Class Initialized
INFO - 2021-08-19 07:15:01 --> Language Class Initialized
INFO - 2021-08-19 07:15:01 --> Config Class Initialized
INFO - 2021-08-19 07:15:01 --> Loader Class Initialized
INFO - 2021-08-19 07:15:02 --> Helper loaded: url_helper
INFO - 2021-08-19 07:15:02 --> Helper loaded: file_helper
INFO - 2021-08-19 07:15:02 --> Helper loaded: form_helper
INFO - 2021-08-19 07:15:02 --> Helper loaded: my_helper
INFO - 2021-08-19 07:15:02 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:15:02 --> Controller Class Initialized
INFO - 2021-08-19 07:15:03 --> Config Class Initialized
INFO - 2021-08-19 07:15:03 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:15:03 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:15:03 --> Utf8 Class Initialized
INFO - 2021-08-19 07:15:03 --> URI Class Initialized
INFO - 2021-08-19 07:15:03 --> Router Class Initialized
INFO - 2021-08-19 07:15:03 --> Output Class Initialized
INFO - 2021-08-19 07:15:03 --> Security Class Initialized
DEBUG - 2021-08-19 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:15:03 --> Input Class Initialized
INFO - 2021-08-19 07:15:03 --> Language Class Initialized
INFO - 2021-08-19 07:15:03 --> Language Class Initialized
INFO - 2021-08-19 07:15:03 --> Config Class Initialized
INFO - 2021-08-19 07:15:03 --> Loader Class Initialized
INFO - 2021-08-19 07:15:03 --> Helper loaded: url_helper
INFO - 2021-08-19 07:15:03 --> Helper loaded: file_helper
INFO - 2021-08-19 07:15:03 --> Helper loaded: form_helper
INFO - 2021-08-19 07:15:03 --> Helper loaded: my_helper
INFO - 2021-08-19 07:15:03 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:15:03 --> Controller Class Initialized
DEBUG - 2021-08-19 07:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 07:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:15:03 --> Final output sent to browser
DEBUG - 2021-08-19 07:15:03 --> Total execution time: 0.1304
INFO - 2021-08-19 07:15:06 --> Config Class Initialized
INFO - 2021-08-19 07:15:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:15:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:15:06 --> Utf8 Class Initialized
INFO - 2021-08-19 07:15:06 --> URI Class Initialized
INFO - 2021-08-19 07:15:06 --> Router Class Initialized
INFO - 2021-08-19 07:15:06 --> Output Class Initialized
INFO - 2021-08-19 07:15:06 --> Security Class Initialized
DEBUG - 2021-08-19 07:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:15:06 --> Input Class Initialized
INFO - 2021-08-19 07:15:06 --> Language Class Initialized
INFO - 2021-08-19 07:15:06 --> Language Class Initialized
INFO - 2021-08-19 07:15:06 --> Config Class Initialized
INFO - 2021-08-19 07:15:06 --> Loader Class Initialized
INFO - 2021-08-19 07:15:06 --> Helper loaded: url_helper
INFO - 2021-08-19 07:15:06 --> Helper loaded: file_helper
INFO - 2021-08-19 07:15:06 --> Helper loaded: form_helper
INFO - 2021-08-19 07:15:06 --> Helper loaded: my_helper
INFO - 2021-08-19 07:15:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:15:06 --> Controller Class Initialized
INFO - 2021-08-19 07:15:09 --> Config Class Initialized
INFO - 2021-08-19 07:15:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:15:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:15:09 --> Utf8 Class Initialized
INFO - 2021-08-19 07:15:09 --> URI Class Initialized
INFO - 2021-08-19 07:15:09 --> Router Class Initialized
INFO - 2021-08-19 07:15:09 --> Output Class Initialized
INFO - 2021-08-19 07:15:09 --> Security Class Initialized
DEBUG - 2021-08-19 07:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:15:09 --> Input Class Initialized
INFO - 2021-08-19 07:15:09 --> Language Class Initialized
INFO - 2021-08-19 07:15:09 --> Language Class Initialized
INFO - 2021-08-19 07:15:09 --> Config Class Initialized
INFO - 2021-08-19 07:15:09 --> Loader Class Initialized
INFO - 2021-08-19 07:15:09 --> Helper loaded: url_helper
INFO - 2021-08-19 07:15:09 --> Helper loaded: file_helper
INFO - 2021-08-19 07:15:09 --> Helper loaded: form_helper
INFO - 2021-08-19 07:15:09 --> Helper loaded: my_helper
INFO - 2021-08-19 07:15:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:15:09 --> Controller Class Initialized
INFO - 2021-08-19 07:16:21 --> Config Class Initialized
INFO - 2021-08-19 07:16:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:16:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:16:21 --> Utf8 Class Initialized
INFO - 2021-08-19 07:16:21 --> URI Class Initialized
INFO - 2021-08-19 07:16:21 --> Router Class Initialized
INFO - 2021-08-19 07:16:21 --> Output Class Initialized
INFO - 2021-08-19 07:16:21 --> Security Class Initialized
DEBUG - 2021-08-19 07:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:16:21 --> Input Class Initialized
INFO - 2021-08-19 07:16:21 --> Language Class Initialized
INFO - 2021-08-19 07:16:21 --> Language Class Initialized
INFO - 2021-08-19 07:16:21 --> Config Class Initialized
INFO - 2021-08-19 07:16:21 --> Loader Class Initialized
INFO - 2021-08-19 07:16:21 --> Helper loaded: url_helper
INFO - 2021-08-19 07:16:21 --> Helper loaded: file_helper
INFO - 2021-08-19 07:16:21 --> Helper loaded: form_helper
INFO - 2021-08-19 07:16:21 --> Helper loaded: my_helper
INFO - 2021-08-19 07:16:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:16:21 --> Controller Class Initialized
DEBUG - 2021-08-19 07:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 07:16:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:16:21 --> Final output sent to browser
DEBUG - 2021-08-19 07:16:21 --> Total execution time: 0.0532
INFO - 2021-08-19 07:16:21 --> Config Class Initialized
INFO - 2021-08-19 07:16:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:16:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:16:21 --> Utf8 Class Initialized
INFO - 2021-08-19 07:16:21 --> URI Class Initialized
INFO - 2021-08-19 07:16:21 --> Router Class Initialized
INFO - 2021-08-19 07:16:21 --> Output Class Initialized
INFO - 2021-08-19 07:16:21 --> Security Class Initialized
DEBUG - 2021-08-19 07:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:16:21 --> Input Class Initialized
INFO - 2021-08-19 07:16:21 --> Language Class Initialized
INFO - 2021-08-19 07:16:21 --> Language Class Initialized
INFO - 2021-08-19 07:16:21 --> Config Class Initialized
INFO - 2021-08-19 07:16:21 --> Loader Class Initialized
INFO - 2021-08-19 07:16:21 --> Helper loaded: url_helper
INFO - 2021-08-19 07:16:21 --> Helper loaded: file_helper
INFO - 2021-08-19 07:16:21 --> Helper loaded: form_helper
INFO - 2021-08-19 07:16:21 --> Helper loaded: my_helper
INFO - 2021-08-19 07:16:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:16:21 --> Controller Class Initialized
INFO - 2021-08-19 07:16:25 --> Config Class Initialized
INFO - 2021-08-19 07:16:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:16:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:16:25 --> Utf8 Class Initialized
INFO - 2021-08-19 07:16:25 --> URI Class Initialized
INFO - 2021-08-19 07:16:25 --> Router Class Initialized
INFO - 2021-08-19 07:16:25 --> Output Class Initialized
INFO - 2021-08-19 07:16:25 --> Security Class Initialized
DEBUG - 2021-08-19 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:16:25 --> Input Class Initialized
INFO - 2021-08-19 07:16:25 --> Language Class Initialized
INFO - 2021-08-19 07:16:25 --> Language Class Initialized
INFO - 2021-08-19 07:16:25 --> Config Class Initialized
INFO - 2021-08-19 07:16:25 --> Loader Class Initialized
INFO - 2021-08-19 07:16:25 --> Helper loaded: url_helper
INFO - 2021-08-19 07:16:25 --> Helper loaded: file_helper
INFO - 2021-08-19 07:16:25 --> Helper loaded: form_helper
INFO - 2021-08-19 07:16:25 --> Helper loaded: my_helper
INFO - 2021-08-19 07:16:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:16:25 --> Controller Class Initialized
INFO - 2021-08-19 07:16:25 --> Final output sent to browser
DEBUG - 2021-08-19 07:16:25 --> Total execution time: 0.0654
INFO - 2021-08-19 07:17:02 --> Config Class Initialized
INFO - 2021-08-19 07:17:02 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:17:02 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:17:02 --> Utf8 Class Initialized
INFO - 2021-08-19 07:17:02 --> URI Class Initialized
INFO - 2021-08-19 07:17:02 --> Router Class Initialized
INFO - 2021-08-19 07:17:02 --> Output Class Initialized
INFO - 2021-08-19 07:17:02 --> Security Class Initialized
DEBUG - 2021-08-19 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:17:02 --> Input Class Initialized
INFO - 2021-08-19 07:17:02 --> Language Class Initialized
INFO - 2021-08-19 07:17:02 --> Language Class Initialized
INFO - 2021-08-19 07:17:02 --> Config Class Initialized
INFO - 2021-08-19 07:17:02 --> Loader Class Initialized
INFO - 2021-08-19 07:17:02 --> Helper loaded: url_helper
INFO - 2021-08-19 07:17:02 --> Helper loaded: file_helper
INFO - 2021-08-19 07:17:02 --> Helper loaded: form_helper
INFO - 2021-08-19 07:17:02 --> Helper loaded: my_helper
INFO - 2021-08-19 07:17:02 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:17:02 --> Controller Class Initialized
INFO - 2021-08-19 07:17:02 --> Helper loaded: cookie_helper
INFO - 2021-08-19 07:17:02 --> Config Class Initialized
INFO - 2021-08-19 07:17:02 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:17:02 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:17:02 --> Utf8 Class Initialized
INFO - 2021-08-19 07:17:02 --> URI Class Initialized
INFO - 2021-08-19 07:17:02 --> Router Class Initialized
INFO - 2021-08-19 07:17:02 --> Output Class Initialized
INFO - 2021-08-19 07:17:02 --> Security Class Initialized
DEBUG - 2021-08-19 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:17:02 --> Input Class Initialized
INFO - 2021-08-19 07:17:02 --> Language Class Initialized
INFO - 2021-08-19 07:17:02 --> Language Class Initialized
INFO - 2021-08-19 07:17:02 --> Config Class Initialized
INFO - 2021-08-19 07:17:02 --> Loader Class Initialized
INFO - 2021-08-19 07:17:02 --> Helper loaded: url_helper
INFO - 2021-08-19 07:17:02 --> Helper loaded: file_helper
INFO - 2021-08-19 07:17:02 --> Helper loaded: form_helper
INFO - 2021-08-19 07:17:02 --> Helper loaded: my_helper
INFO - 2021-08-19 07:17:02 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:17:02 --> Controller Class Initialized
DEBUG - 2021-08-19 07:17:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 07:17:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:17:02 --> Final output sent to browser
DEBUG - 2021-08-19 07:17:02 --> Total execution time: 0.0449
INFO - 2021-08-19 07:17:10 --> Config Class Initialized
INFO - 2021-08-19 07:17:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:17:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:17:10 --> Utf8 Class Initialized
INFO - 2021-08-19 07:17:10 --> URI Class Initialized
INFO - 2021-08-19 07:17:10 --> Router Class Initialized
INFO - 2021-08-19 07:17:10 --> Output Class Initialized
INFO - 2021-08-19 07:17:10 --> Security Class Initialized
DEBUG - 2021-08-19 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:17:10 --> Input Class Initialized
INFO - 2021-08-19 07:17:10 --> Language Class Initialized
INFO - 2021-08-19 07:17:10 --> Language Class Initialized
INFO - 2021-08-19 07:17:10 --> Config Class Initialized
INFO - 2021-08-19 07:17:10 --> Loader Class Initialized
INFO - 2021-08-19 07:17:10 --> Helper loaded: url_helper
INFO - 2021-08-19 07:17:10 --> Helper loaded: file_helper
INFO - 2021-08-19 07:17:10 --> Helper loaded: form_helper
INFO - 2021-08-19 07:17:10 --> Helper loaded: my_helper
INFO - 2021-08-19 07:17:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:17:10 --> Controller Class Initialized
INFO - 2021-08-19 07:17:10 --> Helper loaded: cookie_helper
INFO - 2021-08-19 07:17:10 --> Final output sent to browser
DEBUG - 2021-08-19 07:17:10 --> Total execution time: 0.0602
INFO - 2021-08-19 07:17:10 --> Config Class Initialized
INFO - 2021-08-19 07:17:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:17:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:17:10 --> Utf8 Class Initialized
INFO - 2021-08-19 07:17:10 --> URI Class Initialized
INFO - 2021-08-19 07:17:10 --> Router Class Initialized
INFO - 2021-08-19 07:17:10 --> Output Class Initialized
INFO - 2021-08-19 07:17:10 --> Security Class Initialized
DEBUG - 2021-08-19 07:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:17:10 --> Input Class Initialized
INFO - 2021-08-19 07:17:10 --> Language Class Initialized
INFO - 2021-08-19 07:17:10 --> Language Class Initialized
INFO - 2021-08-19 07:17:10 --> Config Class Initialized
INFO - 2021-08-19 07:17:10 --> Loader Class Initialized
INFO - 2021-08-19 07:17:10 --> Helper loaded: url_helper
INFO - 2021-08-19 07:17:10 --> Helper loaded: file_helper
INFO - 2021-08-19 07:17:10 --> Helper loaded: form_helper
INFO - 2021-08-19 07:17:10 --> Helper loaded: my_helper
INFO - 2021-08-19 07:17:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:17:10 --> Controller Class Initialized
DEBUG - 2021-08-19 07:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 07:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:17:11 --> Final output sent to browser
DEBUG - 2021-08-19 07:17:11 --> Total execution time: 0.7202
INFO - 2021-08-19 07:17:17 --> Config Class Initialized
INFO - 2021-08-19 07:17:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:17:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:17:17 --> Utf8 Class Initialized
INFO - 2021-08-19 07:17:17 --> URI Class Initialized
INFO - 2021-08-19 07:17:17 --> Router Class Initialized
INFO - 2021-08-19 07:17:17 --> Output Class Initialized
INFO - 2021-08-19 07:17:17 --> Security Class Initialized
DEBUG - 2021-08-19 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:17:17 --> Input Class Initialized
INFO - 2021-08-19 07:17:17 --> Language Class Initialized
INFO - 2021-08-19 07:17:17 --> Language Class Initialized
INFO - 2021-08-19 07:17:17 --> Config Class Initialized
INFO - 2021-08-19 07:17:17 --> Loader Class Initialized
INFO - 2021-08-19 07:17:17 --> Helper loaded: url_helper
INFO - 2021-08-19 07:17:17 --> Helper loaded: file_helper
INFO - 2021-08-19 07:17:17 --> Helper loaded: form_helper
INFO - 2021-08-19 07:17:17 --> Helper loaded: my_helper
INFO - 2021-08-19 07:17:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:17:17 --> Controller Class Initialized
DEBUG - 2021-08-19 07:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-19 07:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:17:17 --> Final output sent to browser
DEBUG - 2021-08-19 07:17:17 --> Total execution time: 0.0853
INFO - 2021-08-19 07:17:17 --> Config Class Initialized
INFO - 2021-08-19 07:17:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:17:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:17:17 --> Utf8 Class Initialized
INFO - 2021-08-19 07:17:17 --> URI Class Initialized
INFO - 2021-08-19 07:17:17 --> Router Class Initialized
INFO - 2021-08-19 07:17:17 --> Output Class Initialized
INFO - 2021-08-19 07:17:17 --> Security Class Initialized
DEBUG - 2021-08-19 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:17:17 --> Input Class Initialized
INFO - 2021-08-19 07:17:17 --> Language Class Initialized
INFO - 2021-08-19 07:17:17 --> Language Class Initialized
INFO - 2021-08-19 07:17:17 --> Config Class Initialized
INFO - 2021-08-19 07:17:17 --> Loader Class Initialized
INFO - 2021-08-19 07:17:17 --> Helper loaded: url_helper
INFO - 2021-08-19 07:17:17 --> Helper loaded: file_helper
INFO - 2021-08-19 07:17:17 --> Helper loaded: form_helper
INFO - 2021-08-19 07:17:17 --> Helper loaded: my_helper
INFO - 2021-08-19 07:17:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:17:17 --> Controller Class Initialized
INFO - 2021-08-19 07:31:23 --> Config Class Initialized
INFO - 2021-08-19 07:31:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:31:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:31:23 --> Utf8 Class Initialized
INFO - 2021-08-19 07:31:23 --> URI Class Initialized
INFO - 2021-08-19 07:31:23 --> Router Class Initialized
INFO - 2021-08-19 07:31:23 --> Output Class Initialized
INFO - 2021-08-19 07:31:23 --> Security Class Initialized
DEBUG - 2021-08-19 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:31:23 --> Input Class Initialized
INFO - 2021-08-19 07:31:23 --> Language Class Initialized
INFO - 2021-08-19 07:31:23 --> Language Class Initialized
INFO - 2021-08-19 07:31:23 --> Config Class Initialized
INFO - 2021-08-19 07:31:23 --> Loader Class Initialized
INFO - 2021-08-19 07:31:23 --> Helper loaded: url_helper
INFO - 2021-08-19 07:31:23 --> Helper loaded: file_helper
INFO - 2021-08-19 07:31:23 --> Helper loaded: form_helper
INFO - 2021-08-19 07:31:23 --> Helper loaded: my_helper
INFO - 2021-08-19 07:31:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:31:23 --> Controller Class Initialized
ERROR - 2021-08-19 07:31:23 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-08-19 07:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-08-19 07:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:31:23 --> Final output sent to browser
DEBUG - 2021-08-19 07:31:23 --> Total execution time: 0.5859
INFO - 2021-08-19 07:44:09 --> Config Class Initialized
INFO - 2021-08-19 07:44:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:09 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:09 --> URI Class Initialized
INFO - 2021-08-19 07:44:09 --> Router Class Initialized
INFO - 2021-08-19 07:44:09 --> Output Class Initialized
INFO - 2021-08-19 07:44:09 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:09 --> Input Class Initialized
INFO - 2021-08-19 07:44:09 --> Language Class Initialized
INFO - 2021-08-19 07:44:09 --> Language Class Initialized
INFO - 2021-08-19 07:44:09 --> Config Class Initialized
INFO - 2021-08-19 07:44:09 --> Loader Class Initialized
INFO - 2021-08-19 07:44:09 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:09 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:09 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:09 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:09 --> Controller Class Initialized
DEBUG - 2021-08-19 07:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-19 07:44:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:44:09 --> Final output sent to browser
DEBUG - 2021-08-19 07:44:09 --> Total execution time: 0.0607
INFO - 2021-08-19 07:44:09 --> Config Class Initialized
INFO - 2021-08-19 07:44:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:09 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:09 --> URI Class Initialized
INFO - 2021-08-19 07:44:09 --> Router Class Initialized
INFO - 2021-08-19 07:44:09 --> Output Class Initialized
INFO - 2021-08-19 07:44:09 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:09 --> Input Class Initialized
INFO - 2021-08-19 07:44:09 --> Language Class Initialized
INFO - 2021-08-19 07:44:09 --> Language Class Initialized
INFO - 2021-08-19 07:44:09 --> Config Class Initialized
INFO - 2021-08-19 07:44:09 --> Loader Class Initialized
INFO - 2021-08-19 07:44:09 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:09 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:09 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:09 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:09 --> Controller Class Initialized
INFO - 2021-08-19 07:44:10 --> Config Class Initialized
INFO - 2021-08-19 07:44:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:10 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:10 --> URI Class Initialized
INFO - 2021-08-19 07:44:10 --> Router Class Initialized
INFO - 2021-08-19 07:44:10 --> Output Class Initialized
INFO - 2021-08-19 07:44:10 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:10 --> Input Class Initialized
INFO - 2021-08-19 07:44:10 --> Language Class Initialized
INFO - 2021-08-19 07:44:10 --> Language Class Initialized
INFO - 2021-08-19 07:44:10 --> Config Class Initialized
INFO - 2021-08-19 07:44:10 --> Loader Class Initialized
INFO - 2021-08-19 07:44:10 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:10 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:10 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:10 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:10 --> Controller Class Initialized
DEBUG - 2021-08-19 07:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-08-19 07:44:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:44:10 --> Final output sent to browser
DEBUG - 2021-08-19 07:44:10 --> Total execution time: 0.0773
INFO - 2021-08-19 07:44:17 --> Config Class Initialized
INFO - 2021-08-19 07:44:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:17 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:17 --> URI Class Initialized
INFO - 2021-08-19 07:44:17 --> Router Class Initialized
INFO - 2021-08-19 07:44:17 --> Output Class Initialized
INFO - 2021-08-19 07:44:17 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:17 --> Input Class Initialized
INFO - 2021-08-19 07:44:17 --> Language Class Initialized
INFO - 2021-08-19 07:44:17 --> Language Class Initialized
INFO - 2021-08-19 07:44:17 --> Config Class Initialized
INFO - 2021-08-19 07:44:17 --> Loader Class Initialized
INFO - 2021-08-19 07:44:17 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:17 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:17 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:17 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:17 --> Controller Class Initialized
INFO - 2021-08-19 07:44:20 --> Config Class Initialized
INFO - 2021-08-19 07:44:20 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:20 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:20 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:20 --> URI Class Initialized
INFO - 2021-08-19 07:44:20 --> Router Class Initialized
INFO - 2021-08-19 07:44:20 --> Output Class Initialized
INFO - 2021-08-19 07:44:20 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:20 --> Input Class Initialized
INFO - 2021-08-19 07:44:20 --> Language Class Initialized
INFO - 2021-08-19 07:44:20 --> Language Class Initialized
INFO - 2021-08-19 07:44:20 --> Config Class Initialized
INFO - 2021-08-19 07:44:20 --> Loader Class Initialized
INFO - 2021-08-19 07:44:20 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:20 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:20 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:20 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:20 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:20 --> Controller Class Initialized
DEBUG - 2021-08-19 07:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-08-19 07:44:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:44:20 --> Final output sent to browser
DEBUG - 2021-08-19 07:44:20 --> Total execution time: 0.0609
INFO - 2021-08-19 07:44:22 --> Config Class Initialized
INFO - 2021-08-19 07:44:22 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:22 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:22 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:22 --> URI Class Initialized
INFO - 2021-08-19 07:44:22 --> Router Class Initialized
INFO - 2021-08-19 07:44:22 --> Output Class Initialized
INFO - 2021-08-19 07:44:22 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:22 --> Input Class Initialized
INFO - 2021-08-19 07:44:22 --> Language Class Initialized
INFO - 2021-08-19 07:44:22 --> Language Class Initialized
INFO - 2021-08-19 07:44:22 --> Config Class Initialized
INFO - 2021-08-19 07:44:22 --> Loader Class Initialized
INFO - 2021-08-19 07:44:22 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:22 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:22 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:22 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:23 --> Controller Class Initialized
DEBUG - 2021-08-19 07:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-08-19 07:44:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:44:23 --> Final output sent to browser
DEBUG - 2021-08-19 07:44:23 --> Total execution time: 0.0545
INFO - 2021-08-19 07:44:23 --> Config Class Initialized
INFO - 2021-08-19 07:44:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:23 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:23 --> URI Class Initialized
INFO - 2021-08-19 07:44:23 --> Router Class Initialized
INFO - 2021-08-19 07:44:23 --> Output Class Initialized
INFO - 2021-08-19 07:44:23 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:23 --> Input Class Initialized
INFO - 2021-08-19 07:44:23 --> Language Class Initialized
INFO - 2021-08-19 07:44:23 --> Language Class Initialized
INFO - 2021-08-19 07:44:23 --> Config Class Initialized
INFO - 2021-08-19 07:44:23 --> Loader Class Initialized
INFO - 2021-08-19 07:44:23 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:23 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:23 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:23 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:23 --> Controller Class Initialized
INFO - 2021-08-19 07:44:28 --> Config Class Initialized
INFO - 2021-08-19 07:44:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:28 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:28 --> URI Class Initialized
INFO - 2021-08-19 07:44:28 --> Router Class Initialized
INFO - 2021-08-19 07:44:28 --> Output Class Initialized
INFO - 2021-08-19 07:44:28 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:28 --> Input Class Initialized
INFO - 2021-08-19 07:44:28 --> Language Class Initialized
INFO - 2021-08-19 07:44:28 --> Language Class Initialized
INFO - 2021-08-19 07:44:28 --> Config Class Initialized
INFO - 2021-08-19 07:44:28 --> Loader Class Initialized
INFO - 2021-08-19 07:44:28 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:28 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:28 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:28 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:28 --> Controller Class Initialized
DEBUG - 2021-08-19 07:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-08-19 07:44:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:44:28 --> Final output sent to browser
DEBUG - 2021-08-19 07:44:28 --> Total execution time: 0.0941
INFO - 2021-08-19 07:44:37 --> Config Class Initialized
INFO - 2021-08-19 07:44:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 07:44:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 07:44:37 --> Utf8 Class Initialized
INFO - 2021-08-19 07:44:37 --> URI Class Initialized
INFO - 2021-08-19 07:44:37 --> Router Class Initialized
INFO - 2021-08-19 07:44:37 --> Output Class Initialized
INFO - 2021-08-19 07:44:37 --> Security Class Initialized
DEBUG - 2021-08-19 07:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 07:44:37 --> Input Class Initialized
INFO - 2021-08-19 07:44:37 --> Language Class Initialized
INFO - 2021-08-19 07:44:37 --> Language Class Initialized
INFO - 2021-08-19 07:44:37 --> Config Class Initialized
INFO - 2021-08-19 07:44:37 --> Loader Class Initialized
INFO - 2021-08-19 07:44:37 --> Helper loaded: url_helper
INFO - 2021-08-19 07:44:37 --> Helper loaded: file_helper
INFO - 2021-08-19 07:44:37 --> Helper loaded: form_helper
INFO - 2021-08-19 07:44:37 --> Helper loaded: my_helper
INFO - 2021-08-19 07:44:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 07:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 07:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 07:44:37 --> Controller Class Initialized
DEBUG - 2021-08-19 07:44:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-08-19 07:44:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 07:44:37 --> Final output sent to browser
DEBUG - 2021-08-19 07:44:37 --> Total execution time: 0.0734
INFO - 2021-08-19 08:02:44 --> Config Class Initialized
INFO - 2021-08-19 08:02:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:02:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:02:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:02:44 --> URI Class Initialized
INFO - 2021-08-19 08:02:44 --> Router Class Initialized
INFO - 2021-08-19 08:02:44 --> Output Class Initialized
INFO - 2021-08-19 08:02:44 --> Security Class Initialized
DEBUG - 2021-08-19 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:02:44 --> Input Class Initialized
INFO - 2021-08-19 08:02:44 --> Language Class Initialized
INFO - 2021-08-19 08:02:44 --> Language Class Initialized
INFO - 2021-08-19 08:02:44 --> Config Class Initialized
INFO - 2021-08-19 08:02:44 --> Loader Class Initialized
INFO - 2021-08-19 08:02:44 --> Helper loaded: url_helper
INFO - 2021-08-19 08:02:44 --> Helper loaded: file_helper
INFO - 2021-08-19 08:02:44 --> Helper loaded: form_helper
INFO - 2021-08-19 08:02:44 --> Helper loaded: my_helper
INFO - 2021-08-19 08:02:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:02:44 --> Controller Class Initialized
DEBUG - 2021-08-19 08:02:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:02:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:02:44 --> Final output sent to browser
DEBUG - 2021-08-19 08:02:44 --> Total execution time: 0.0537
INFO - 2021-08-19 08:02:52 --> Config Class Initialized
INFO - 2021-08-19 08:02:52 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:02:52 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:02:52 --> Utf8 Class Initialized
INFO - 2021-08-19 08:02:52 --> URI Class Initialized
INFO - 2021-08-19 08:02:52 --> Router Class Initialized
INFO - 2021-08-19 08:02:52 --> Output Class Initialized
INFO - 2021-08-19 08:02:52 --> Security Class Initialized
DEBUG - 2021-08-19 08:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:02:52 --> Input Class Initialized
INFO - 2021-08-19 08:02:52 --> Language Class Initialized
INFO - 2021-08-19 08:02:52 --> Language Class Initialized
INFO - 2021-08-19 08:02:52 --> Config Class Initialized
INFO - 2021-08-19 08:02:52 --> Loader Class Initialized
INFO - 2021-08-19 08:02:52 --> Helper loaded: url_helper
INFO - 2021-08-19 08:02:52 --> Helper loaded: file_helper
INFO - 2021-08-19 08:02:52 --> Helper loaded: form_helper
INFO - 2021-08-19 08:02:52 --> Helper loaded: my_helper
INFO - 2021-08-19 08:02:52 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:02:52 --> Controller Class Initialized
INFO - 2021-08-19 08:02:52 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:02:52 --> Final output sent to browser
DEBUG - 2021-08-19 08:02:52 --> Total execution time: 0.0536
INFO - 2021-08-19 08:02:52 --> Config Class Initialized
INFO - 2021-08-19 08:02:52 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:02:52 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:02:52 --> Utf8 Class Initialized
INFO - 2021-08-19 08:02:52 --> URI Class Initialized
INFO - 2021-08-19 08:02:52 --> Router Class Initialized
INFO - 2021-08-19 08:02:52 --> Output Class Initialized
INFO - 2021-08-19 08:02:52 --> Security Class Initialized
DEBUG - 2021-08-19 08:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:02:52 --> Input Class Initialized
INFO - 2021-08-19 08:02:52 --> Language Class Initialized
INFO - 2021-08-19 08:02:52 --> Language Class Initialized
INFO - 2021-08-19 08:02:52 --> Config Class Initialized
INFO - 2021-08-19 08:02:52 --> Loader Class Initialized
INFO - 2021-08-19 08:02:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:02:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:02:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:02:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:02:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:02:53 --> Controller Class Initialized
DEBUG - 2021-08-19 08:02:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:02:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:02:53 --> Final output sent to browser
DEBUG - 2021-08-19 08:02:53 --> Total execution time: 0.7672
INFO - 2021-08-19 08:02:59 --> Config Class Initialized
INFO - 2021-08-19 08:02:59 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:02:59 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:02:59 --> Utf8 Class Initialized
INFO - 2021-08-19 08:02:59 --> URI Class Initialized
INFO - 2021-08-19 08:02:59 --> Router Class Initialized
INFO - 2021-08-19 08:02:59 --> Output Class Initialized
INFO - 2021-08-19 08:02:59 --> Security Class Initialized
DEBUG - 2021-08-19 08:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:02:59 --> Input Class Initialized
INFO - 2021-08-19 08:02:59 --> Language Class Initialized
INFO - 2021-08-19 08:02:59 --> Language Class Initialized
INFO - 2021-08-19 08:02:59 --> Config Class Initialized
INFO - 2021-08-19 08:02:59 --> Loader Class Initialized
INFO - 2021-08-19 08:02:59 --> Helper loaded: url_helper
INFO - 2021-08-19 08:02:59 --> Helper loaded: file_helper
INFO - 2021-08-19 08:02:59 --> Helper loaded: form_helper
INFO - 2021-08-19 08:02:59 --> Helper loaded: my_helper
INFO - 2021-08-19 08:02:59 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:02:59 --> Controller Class Initialized
DEBUG - 2021-08-19 08:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-08-19 08:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:02:59 --> Final output sent to browser
DEBUG - 2021-08-19 08:02:59 --> Total execution time: 0.0757
INFO - 2021-08-19 08:03:09 --> Config Class Initialized
INFO - 2021-08-19 08:03:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:09 --> URI Class Initialized
INFO - 2021-08-19 08:03:09 --> Router Class Initialized
INFO - 2021-08-19 08:03:09 --> Output Class Initialized
INFO - 2021-08-19 08:03:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:09 --> Input Class Initialized
INFO - 2021-08-19 08:03:09 --> Language Class Initialized
INFO - 2021-08-19 08:03:10 --> Language Class Initialized
INFO - 2021-08-19 08:03:10 --> Config Class Initialized
INFO - 2021-08-19 08:03:10 --> Loader Class Initialized
INFO - 2021-08-19 08:03:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:10 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-08-19 08:03:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:10 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:10 --> Total execution time: 0.0884
INFO - 2021-08-19 08:03:14 --> Config Class Initialized
INFO - 2021-08-19 08:03:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:14 --> URI Class Initialized
INFO - 2021-08-19 08:03:14 --> Router Class Initialized
INFO - 2021-08-19 08:03:14 --> Output Class Initialized
INFO - 2021-08-19 08:03:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:14 --> Input Class Initialized
INFO - 2021-08-19 08:03:14 --> Language Class Initialized
INFO - 2021-08-19 08:03:14 --> Language Class Initialized
INFO - 2021-08-19 08:03:14 --> Config Class Initialized
INFO - 2021-08-19 08:03:14 --> Loader Class Initialized
INFO - 2021-08-19 08:03:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:14 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-08-19 08:03:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:14 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:14 --> Total execution time: 0.0441
INFO - 2021-08-19 08:03:17 --> Config Class Initialized
INFO - 2021-08-19 08:03:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:17 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:17 --> URI Class Initialized
INFO - 2021-08-19 08:03:17 --> Router Class Initialized
INFO - 2021-08-19 08:03:17 --> Output Class Initialized
INFO - 2021-08-19 08:03:17 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:17 --> Input Class Initialized
INFO - 2021-08-19 08:03:17 --> Language Class Initialized
INFO - 2021-08-19 08:03:17 --> Language Class Initialized
INFO - 2021-08-19 08:03:17 --> Config Class Initialized
INFO - 2021-08-19 08:03:17 --> Loader Class Initialized
INFO - 2021-08-19 08:03:17 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:17 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:17 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:17 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:17 --> Controller Class Initialized
INFO - 2021-08-19 08:03:17 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:03:17 --> Config Class Initialized
INFO - 2021-08-19 08:03:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:17 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:17 --> URI Class Initialized
INFO - 2021-08-19 08:03:17 --> Router Class Initialized
INFO - 2021-08-19 08:03:17 --> Output Class Initialized
INFO - 2021-08-19 08:03:17 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:17 --> Input Class Initialized
INFO - 2021-08-19 08:03:17 --> Language Class Initialized
INFO - 2021-08-19 08:03:17 --> Language Class Initialized
INFO - 2021-08-19 08:03:17 --> Config Class Initialized
INFO - 2021-08-19 08:03:17 --> Loader Class Initialized
INFO - 2021-08-19 08:03:17 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:17 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:17 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:17 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:17 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:03:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:17 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:17 --> Total execution time: 0.0537
INFO - 2021-08-19 08:03:23 --> Config Class Initialized
INFO - 2021-08-19 08:03:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:23 --> URI Class Initialized
INFO - 2021-08-19 08:03:23 --> Router Class Initialized
INFO - 2021-08-19 08:03:23 --> Output Class Initialized
INFO - 2021-08-19 08:03:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:23 --> Input Class Initialized
INFO - 2021-08-19 08:03:23 --> Language Class Initialized
INFO - 2021-08-19 08:03:23 --> Language Class Initialized
INFO - 2021-08-19 08:03:23 --> Config Class Initialized
INFO - 2021-08-19 08:03:23 --> Loader Class Initialized
INFO - 2021-08-19 08:03:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:23 --> Controller Class Initialized
INFO - 2021-08-19 08:03:23 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:03:23 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:23 --> Total execution time: 0.0470
INFO - 2021-08-19 08:03:23 --> Config Class Initialized
INFO - 2021-08-19 08:03:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:23 --> URI Class Initialized
INFO - 2021-08-19 08:03:23 --> Router Class Initialized
INFO - 2021-08-19 08:03:23 --> Output Class Initialized
INFO - 2021-08-19 08:03:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:23 --> Input Class Initialized
INFO - 2021-08-19 08:03:23 --> Language Class Initialized
INFO - 2021-08-19 08:03:23 --> Language Class Initialized
INFO - 2021-08-19 08:03:23 --> Config Class Initialized
INFO - 2021-08-19 08:03:23 --> Loader Class Initialized
INFO - 2021-08-19 08:03:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:23 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:03:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:24 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:24 --> Total execution time: 0.7039
INFO - 2021-08-19 08:03:31 --> Config Class Initialized
INFO - 2021-08-19 08:03:31 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:31 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:31 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:31 --> URI Class Initialized
INFO - 2021-08-19 08:03:31 --> Router Class Initialized
INFO - 2021-08-19 08:03:31 --> Output Class Initialized
INFO - 2021-08-19 08:03:31 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:31 --> Input Class Initialized
INFO - 2021-08-19 08:03:31 --> Language Class Initialized
INFO - 2021-08-19 08:03:31 --> Language Class Initialized
INFO - 2021-08-19 08:03:31 --> Config Class Initialized
INFO - 2021-08-19 08:03:31 --> Loader Class Initialized
INFO - 2021-08-19 08:03:31 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:31 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:31 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:31 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:31 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:31 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:03:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:31 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:31 --> Total execution time: 0.0653
INFO - 2021-08-19 08:03:31 --> Config Class Initialized
INFO - 2021-08-19 08:03:31 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:31 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:31 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:31 --> URI Class Initialized
INFO - 2021-08-19 08:03:31 --> Router Class Initialized
INFO - 2021-08-19 08:03:31 --> Output Class Initialized
INFO - 2021-08-19 08:03:31 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:31 --> Input Class Initialized
INFO - 2021-08-19 08:03:31 --> Language Class Initialized
INFO - 2021-08-19 08:03:31 --> Language Class Initialized
INFO - 2021-08-19 08:03:31 --> Config Class Initialized
INFO - 2021-08-19 08:03:31 --> Loader Class Initialized
INFO - 2021-08-19 08:03:31 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:31 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:31 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:31 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:31 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:31 --> Controller Class Initialized
INFO - 2021-08-19 08:03:34 --> Config Class Initialized
INFO - 2021-08-19 08:03:34 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:34 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:34 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:34 --> URI Class Initialized
INFO - 2021-08-19 08:03:34 --> Router Class Initialized
INFO - 2021-08-19 08:03:34 --> Output Class Initialized
INFO - 2021-08-19 08:03:34 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:34 --> Input Class Initialized
INFO - 2021-08-19 08:03:34 --> Language Class Initialized
INFO - 2021-08-19 08:03:34 --> Language Class Initialized
INFO - 2021-08-19 08:03:34 --> Config Class Initialized
INFO - 2021-08-19 08:03:34 --> Loader Class Initialized
INFO - 2021-08-19 08:03:34 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:34 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:34 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:34 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:34 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:34 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:03:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:34 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:34 --> Total execution time: 0.0663
INFO - 2021-08-19 08:03:36 --> Config Class Initialized
INFO - 2021-08-19 08:03:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:36 --> URI Class Initialized
INFO - 2021-08-19 08:03:36 --> Router Class Initialized
INFO - 2021-08-19 08:03:36 --> Output Class Initialized
INFO - 2021-08-19 08:03:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:36 --> Input Class Initialized
INFO - 2021-08-19 08:03:36 --> Language Class Initialized
INFO - 2021-08-19 08:03:36 --> Language Class Initialized
INFO - 2021-08-19 08:03:36 --> Config Class Initialized
INFO - 2021-08-19 08:03:36 --> Loader Class Initialized
INFO - 2021-08-19 08:03:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:36 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:03:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:36 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:36 --> Total execution time: 0.0464
INFO - 2021-08-19 08:03:37 --> Config Class Initialized
INFO - 2021-08-19 08:03:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:37 --> URI Class Initialized
INFO - 2021-08-19 08:03:37 --> Router Class Initialized
INFO - 2021-08-19 08:03:37 --> Output Class Initialized
INFO - 2021-08-19 08:03:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:37 --> Input Class Initialized
INFO - 2021-08-19 08:03:37 --> Language Class Initialized
INFO - 2021-08-19 08:03:37 --> Language Class Initialized
INFO - 2021-08-19 08:03:37 --> Config Class Initialized
INFO - 2021-08-19 08:03:37 --> Loader Class Initialized
INFO - 2021-08-19 08:03:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:37 --> Controller Class Initialized
INFO - 2021-08-19 08:03:38 --> Config Class Initialized
INFO - 2021-08-19 08:03:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:38 --> URI Class Initialized
INFO - 2021-08-19 08:03:38 --> Router Class Initialized
INFO - 2021-08-19 08:03:38 --> Output Class Initialized
INFO - 2021-08-19 08:03:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:38 --> Input Class Initialized
INFO - 2021-08-19 08:03:38 --> Language Class Initialized
INFO - 2021-08-19 08:03:38 --> Language Class Initialized
INFO - 2021-08-19 08:03:38 --> Config Class Initialized
INFO - 2021-08-19 08:03:38 --> Loader Class Initialized
INFO - 2021-08-19 08:03:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:38 --> Controller Class Initialized
INFO - 2021-08-19 08:03:38 --> Config Class Initialized
INFO - 2021-08-19 08:03:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:38 --> URI Class Initialized
INFO - 2021-08-19 08:03:38 --> Router Class Initialized
INFO - 2021-08-19 08:03:38 --> Output Class Initialized
INFO - 2021-08-19 08:03:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:38 --> Input Class Initialized
INFO - 2021-08-19 08:03:38 --> Language Class Initialized
INFO - 2021-08-19 08:03:38 --> Language Class Initialized
INFO - 2021-08-19 08:03:38 --> Config Class Initialized
INFO - 2021-08-19 08:03:38 --> Loader Class Initialized
INFO - 2021-08-19 08:03:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:38 --> Controller Class Initialized
INFO - 2021-08-19 08:03:43 --> Config Class Initialized
INFO - 2021-08-19 08:03:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:43 --> URI Class Initialized
INFO - 2021-08-19 08:03:43 --> Router Class Initialized
INFO - 2021-08-19 08:03:43 --> Output Class Initialized
INFO - 2021-08-19 08:03:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:43 --> Input Class Initialized
INFO - 2021-08-19 08:03:43 --> Language Class Initialized
INFO - 2021-08-19 08:03:43 --> Language Class Initialized
INFO - 2021-08-19 08:03:43 --> Config Class Initialized
INFO - 2021-08-19 08:03:43 --> Loader Class Initialized
INFO - 2021-08-19 08:03:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:43 --> Controller Class Initialized
INFO - 2021-08-19 08:03:46 --> Config Class Initialized
INFO - 2021-08-19 08:03:46 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:46 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:46 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:46 --> URI Class Initialized
INFO - 2021-08-19 08:03:46 --> Router Class Initialized
INFO - 2021-08-19 08:03:46 --> Output Class Initialized
INFO - 2021-08-19 08:03:46 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:46 --> Input Class Initialized
INFO - 2021-08-19 08:03:46 --> Language Class Initialized
INFO - 2021-08-19 08:03:46 --> Language Class Initialized
INFO - 2021-08-19 08:03:46 --> Config Class Initialized
INFO - 2021-08-19 08:03:46 --> Loader Class Initialized
INFO - 2021-08-19 08:03:46 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:46 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:46 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:46 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:46 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:46 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:03:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:46 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:46 --> Total execution time: 0.0497
INFO - 2021-08-19 08:03:57 --> Config Class Initialized
INFO - 2021-08-19 08:03:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:57 --> URI Class Initialized
INFO - 2021-08-19 08:03:57 --> Router Class Initialized
INFO - 2021-08-19 08:03:57 --> Output Class Initialized
INFO - 2021-08-19 08:03:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:57 --> Input Class Initialized
INFO - 2021-08-19 08:03:57 --> Language Class Initialized
INFO - 2021-08-19 08:03:57 --> Language Class Initialized
INFO - 2021-08-19 08:03:57 --> Config Class Initialized
INFO - 2021-08-19 08:03:57 --> Loader Class Initialized
INFO - 2021-08-19 08:03:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:57 --> Controller Class Initialized
INFO - 2021-08-19 08:03:57 --> Config Class Initialized
INFO - 2021-08-19 08:03:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:57 --> URI Class Initialized
INFO - 2021-08-19 08:03:57 --> Router Class Initialized
INFO - 2021-08-19 08:03:57 --> Output Class Initialized
INFO - 2021-08-19 08:03:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:57 --> Input Class Initialized
INFO - 2021-08-19 08:03:57 --> Language Class Initialized
INFO - 2021-08-19 08:03:57 --> Language Class Initialized
INFO - 2021-08-19 08:03:57 --> Config Class Initialized
INFO - 2021-08-19 08:03:57 --> Loader Class Initialized
INFO - 2021-08-19 08:03:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:57 --> Controller Class Initialized
DEBUG - 2021-08-19 08:03:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:03:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:03:57 --> Final output sent to browser
DEBUG - 2021-08-19 08:03:57 --> Total execution time: 0.0459
INFO - 2021-08-19 08:03:57 --> Config Class Initialized
INFO - 2021-08-19 08:03:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:03:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:03:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:03:57 --> URI Class Initialized
INFO - 2021-08-19 08:03:57 --> Router Class Initialized
INFO - 2021-08-19 08:03:57 --> Output Class Initialized
INFO - 2021-08-19 08:03:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:03:57 --> Input Class Initialized
INFO - 2021-08-19 08:03:57 --> Language Class Initialized
INFO - 2021-08-19 08:03:57 --> Language Class Initialized
INFO - 2021-08-19 08:03:57 --> Config Class Initialized
INFO - 2021-08-19 08:03:57 --> Loader Class Initialized
INFO - 2021-08-19 08:03:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:03:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:03:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:03:57 --> Controller Class Initialized
INFO - 2021-08-19 08:04:03 --> Config Class Initialized
INFO - 2021-08-19 08:04:03 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:03 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:03 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:03 --> URI Class Initialized
INFO - 2021-08-19 08:04:03 --> Router Class Initialized
INFO - 2021-08-19 08:04:03 --> Output Class Initialized
INFO - 2021-08-19 08:04:03 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:03 --> Input Class Initialized
INFO - 2021-08-19 08:04:03 --> Language Class Initialized
INFO - 2021-08-19 08:04:03 --> Language Class Initialized
INFO - 2021-08-19 08:04:03 --> Config Class Initialized
INFO - 2021-08-19 08:04:03 --> Loader Class Initialized
INFO - 2021-08-19 08:04:03 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:03 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:03 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:03 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:03 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:03 --> Controller Class Initialized
INFO - 2021-08-19 08:04:04 --> Config Class Initialized
INFO - 2021-08-19 08:04:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:04 --> URI Class Initialized
INFO - 2021-08-19 08:04:04 --> Router Class Initialized
INFO - 2021-08-19 08:04:04 --> Output Class Initialized
INFO - 2021-08-19 08:04:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:04 --> Input Class Initialized
INFO - 2021-08-19 08:04:04 --> Language Class Initialized
INFO - 2021-08-19 08:04:04 --> Language Class Initialized
INFO - 2021-08-19 08:04:04 --> Config Class Initialized
INFO - 2021-08-19 08:04:04 --> Loader Class Initialized
INFO - 2021-08-19 08:04:04 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:04 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:04 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:04 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:04 --> Controller Class Initialized
INFO - 2021-08-19 08:04:08 --> Config Class Initialized
INFO - 2021-08-19 08:04:08 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:08 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:08 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:08 --> URI Class Initialized
INFO - 2021-08-19 08:04:08 --> Router Class Initialized
INFO - 2021-08-19 08:04:08 --> Output Class Initialized
INFO - 2021-08-19 08:04:08 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:08 --> Input Class Initialized
INFO - 2021-08-19 08:04:08 --> Language Class Initialized
INFO - 2021-08-19 08:04:08 --> Language Class Initialized
INFO - 2021-08-19 08:04:08 --> Config Class Initialized
INFO - 2021-08-19 08:04:08 --> Loader Class Initialized
INFO - 2021-08-19 08:04:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:08 --> Controller Class Initialized
INFO - 2021-08-19 08:04:08 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:04:08 --> Config Class Initialized
INFO - 2021-08-19 08:04:08 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:08 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:08 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:08 --> URI Class Initialized
INFO - 2021-08-19 08:04:08 --> Router Class Initialized
INFO - 2021-08-19 08:04:08 --> Output Class Initialized
INFO - 2021-08-19 08:04:08 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:08 --> Input Class Initialized
INFO - 2021-08-19 08:04:08 --> Language Class Initialized
INFO - 2021-08-19 08:04:08 --> Language Class Initialized
INFO - 2021-08-19 08:04:08 --> Config Class Initialized
INFO - 2021-08-19 08:04:08 --> Loader Class Initialized
INFO - 2021-08-19 08:04:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:08 --> Controller Class Initialized
DEBUG - 2021-08-19 08:04:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:04:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:04:08 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:08 --> Total execution time: 0.0447
INFO - 2021-08-19 08:04:14 --> Config Class Initialized
INFO - 2021-08-19 08:04:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:14 --> URI Class Initialized
INFO - 2021-08-19 08:04:14 --> Router Class Initialized
INFO - 2021-08-19 08:04:14 --> Output Class Initialized
INFO - 2021-08-19 08:04:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:14 --> Input Class Initialized
INFO - 2021-08-19 08:04:14 --> Language Class Initialized
INFO - 2021-08-19 08:04:14 --> Language Class Initialized
INFO - 2021-08-19 08:04:14 --> Config Class Initialized
INFO - 2021-08-19 08:04:14 --> Loader Class Initialized
INFO - 2021-08-19 08:04:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:14 --> Controller Class Initialized
INFO - 2021-08-19 08:04:14 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:04:14 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:14 --> Total execution time: 0.0454
INFO - 2021-08-19 08:04:14 --> Config Class Initialized
INFO - 2021-08-19 08:04:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:14 --> URI Class Initialized
INFO - 2021-08-19 08:04:14 --> Router Class Initialized
INFO - 2021-08-19 08:04:14 --> Output Class Initialized
INFO - 2021-08-19 08:04:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:14 --> Input Class Initialized
INFO - 2021-08-19 08:04:14 --> Language Class Initialized
INFO - 2021-08-19 08:04:14 --> Language Class Initialized
INFO - 2021-08-19 08:04:14 --> Config Class Initialized
INFO - 2021-08-19 08:04:14 --> Loader Class Initialized
INFO - 2021-08-19 08:04:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:14 --> Controller Class Initialized
DEBUG - 2021-08-19 08:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:04:15 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:15 --> Total execution time: 0.6375
INFO - 2021-08-19 08:04:17 --> Config Class Initialized
INFO - 2021-08-19 08:04:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:17 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:17 --> URI Class Initialized
INFO - 2021-08-19 08:04:17 --> Router Class Initialized
INFO - 2021-08-19 08:04:17 --> Output Class Initialized
INFO - 2021-08-19 08:04:17 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:17 --> Input Class Initialized
INFO - 2021-08-19 08:04:17 --> Language Class Initialized
INFO - 2021-08-19 08:04:17 --> Language Class Initialized
INFO - 2021-08-19 08:04:17 --> Config Class Initialized
INFO - 2021-08-19 08:04:17 --> Loader Class Initialized
INFO - 2021-08-19 08:04:17 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:17 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:17 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:17 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:17 --> Controller Class Initialized
DEBUG - 2021-08-19 08:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:04:17 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:17 --> Total execution time: 0.0450
INFO - 2021-08-19 08:04:20 --> Config Class Initialized
INFO - 2021-08-19 08:04:20 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:20 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:20 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:20 --> URI Class Initialized
INFO - 2021-08-19 08:04:20 --> Router Class Initialized
INFO - 2021-08-19 08:04:20 --> Output Class Initialized
INFO - 2021-08-19 08:04:20 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:20 --> Input Class Initialized
INFO - 2021-08-19 08:04:20 --> Language Class Initialized
INFO - 2021-08-19 08:04:20 --> Language Class Initialized
INFO - 2021-08-19 08:04:20 --> Config Class Initialized
INFO - 2021-08-19 08:04:20 --> Loader Class Initialized
INFO - 2021-08-19 08:04:20 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:20 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:20 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:20 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:20 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:20 --> Controller Class Initialized
DEBUG - 2021-08-19 08:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:04:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:04:20 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:20 --> Total execution time: 0.0530
INFO - 2021-08-19 08:04:20 --> Config Class Initialized
INFO - 2021-08-19 08:04:20 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:20 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:20 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:20 --> URI Class Initialized
INFO - 2021-08-19 08:04:20 --> Router Class Initialized
INFO - 2021-08-19 08:04:20 --> Output Class Initialized
INFO - 2021-08-19 08:04:20 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:20 --> Input Class Initialized
INFO - 2021-08-19 08:04:20 --> Language Class Initialized
INFO - 2021-08-19 08:04:20 --> Language Class Initialized
INFO - 2021-08-19 08:04:20 --> Config Class Initialized
INFO - 2021-08-19 08:04:20 --> Loader Class Initialized
INFO - 2021-08-19 08:04:20 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:20 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:20 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:20 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:20 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:20 --> Controller Class Initialized
INFO - 2021-08-19 08:04:21 --> Config Class Initialized
INFO - 2021-08-19 08:04:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:21 --> URI Class Initialized
INFO - 2021-08-19 08:04:21 --> Router Class Initialized
INFO - 2021-08-19 08:04:21 --> Output Class Initialized
INFO - 2021-08-19 08:04:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:21 --> Input Class Initialized
INFO - 2021-08-19 08:04:21 --> Language Class Initialized
INFO - 2021-08-19 08:04:21 --> Language Class Initialized
INFO - 2021-08-19 08:04:21 --> Config Class Initialized
INFO - 2021-08-19 08:04:21 --> Loader Class Initialized
INFO - 2021-08-19 08:04:21 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:21 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:21 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:21 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:21 --> Controller Class Initialized
DEBUG - 2021-08-19 08:04:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:04:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:04:21 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:21 --> Total execution time: 0.0497
INFO - 2021-08-19 08:04:24 --> Config Class Initialized
INFO - 2021-08-19 08:04:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:24 --> URI Class Initialized
INFO - 2021-08-19 08:04:24 --> Router Class Initialized
INFO - 2021-08-19 08:04:24 --> Output Class Initialized
INFO - 2021-08-19 08:04:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:24 --> Input Class Initialized
INFO - 2021-08-19 08:04:24 --> Language Class Initialized
INFO - 2021-08-19 08:04:24 --> Language Class Initialized
INFO - 2021-08-19 08:04:24 --> Config Class Initialized
INFO - 2021-08-19 08:04:24 --> Loader Class Initialized
INFO - 2021-08-19 08:04:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:24 --> Controller Class Initialized
INFO - 2021-08-19 08:04:24 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:24 --> Total execution time: 0.0801
INFO - 2021-08-19 08:04:28 --> Config Class Initialized
INFO - 2021-08-19 08:04:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:04:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:04:28 --> Utf8 Class Initialized
INFO - 2021-08-19 08:04:28 --> URI Class Initialized
INFO - 2021-08-19 08:04:28 --> Router Class Initialized
INFO - 2021-08-19 08:04:28 --> Output Class Initialized
INFO - 2021-08-19 08:04:28 --> Security Class Initialized
DEBUG - 2021-08-19 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:04:28 --> Input Class Initialized
INFO - 2021-08-19 08:04:28 --> Language Class Initialized
INFO - 2021-08-19 08:04:28 --> Language Class Initialized
INFO - 2021-08-19 08:04:28 --> Config Class Initialized
INFO - 2021-08-19 08:04:28 --> Loader Class Initialized
INFO - 2021-08-19 08:04:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:04:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:04:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:04:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:04:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:04:28 --> Controller Class Initialized
INFO - 2021-08-19 08:04:28 --> Final output sent to browser
DEBUG - 2021-08-19 08:04:28 --> Total execution time: 0.0937
INFO - 2021-08-19 08:05:04 --> Config Class Initialized
INFO - 2021-08-19 08:05:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:04 --> URI Class Initialized
INFO - 2021-08-19 08:05:04 --> Router Class Initialized
INFO - 2021-08-19 08:05:04 --> Output Class Initialized
INFO - 2021-08-19 08:05:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:04 --> Input Class Initialized
INFO - 2021-08-19 08:05:04 --> Language Class Initialized
INFO - 2021-08-19 08:05:04 --> Language Class Initialized
INFO - 2021-08-19 08:05:04 --> Config Class Initialized
INFO - 2021-08-19 08:05:04 --> Loader Class Initialized
INFO - 2021-08-19 08:05:04 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:04 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:04 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:04 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:04 --> Controller Class Initialized
DEBUG - 2021-08-19 08:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:05:04 --> Final output sent to browser
DEBUG - 2021-08-19 08:05:04 --> Total execution time: 0.0512
INFO - 2021-08-19 08:05:04 --> Config Class Initialized
INFO - 2021-08-19 08:05:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:04 --> URI Class Initialized
INFO - 2021-08-19 08:05:04 --> Router Class Initialized
INFO - 2021-08-19 08:05:04 --> Output Class Initialized
INFO - 2021-08-19 08:05:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:04 --> Input Class Initialized
INFO - 2021-08-19 08:05:04 --> Language Class Initialized
INFO - 2021-08-19 08:05:04 --> Language Class Initialized
INFO - 2021-08-19 08:05:04 --> Config Class Initialized
INFO - 2021-08-19 08:05:04 --> Loader Class Initialized
INFO - 2021-08-19 08:05:04 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:04 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:04 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:04 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:04 --> Controller Class Initialized
INFO - 2021-08-19 08:05:05 --> Config Class Initialized
INFO - 2021-08-19 08:05:05 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:05 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:05 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:05 --> URI Class Initialized
INFO - 2021-08-19 08:05:05 --> Router Class Initialized
INFO - 2021-08-19 08:05:05 --> Output Class Initialized
INFO - 2021-08-19 08:05:05 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:05 --> Input Class Initialized
INFO - 2021-08-19 08:05:05 --> Language Class Initialized
INFO - 2021-08-19 08:05:05 --> Language Class Initialized
INFO - 2021-08-19 08:05:05 --> Config Class Initialized
INFO - 2021-08-19 08:05:05 --> Loader Class Initialized
INFO - 2021-08-19 08:05:05 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:05 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:05 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:05 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:05 --> Controller Class Initialized
DEBUG - 2021-08-19 08:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:05:05 --> Final output sent to browser
DEBUG - 2021-08-19 08:05:05 --> Total execution time: 0.0493
INFO - 2021-08-19 08:05:10 --> Config Class Initialized
INFO - 2021-08-19 08:05:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:10 --> URI Class Initialized
INFO - 2021-08-19 08:05:10 --> Router Class Initialized
INFO - 2021-08-19 08:05:10 --> Output Class Initialized
INFO - 2021-08-19 08:05:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:10 --> Input Class Initialized
INFO - 2021-08-19 08:05:10 --> Language Class Initialized
INFO - 2021-08-19 08:05:10 --> Language Class Initialized
INFO - 2021-08-19 08:05:10 --> Config Class Initialized
INFO - 2021-08-19 08:05:10 --> Loader Class Initialized
INFO - 2021-08-19 08:05:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:10 --> Controller Class Initialized
INFO - 2021-08-19 08:05:13 --> Config Class Initialized
INFO - 2021-08-19 08:05:13 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:13 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:13 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:13 --> URI Class Initialized
INFO - 2021-08-19 08:05:13 --> Router Class Initialized
INFO - 2021-08-19 08:05:13 --> Output Class Initialized
INFO - 2021-08-19 08:05:13 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:13 --> Input Class Initialized
INFO - 2021-08-19 08:05:13 --> Language Class Initialized
INFO - 2021-08-19 08:05:13 --> Language Class Initialized
INFO - 2021-08-19 08:05:13 --> Config Class Initialized
INFO - 2021-08-19 08:05:13 --> Loader Class Initialized
INFO - 2021-08-19 08:05:13 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:13 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:13 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:13 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:13 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:13 --> Controller Class Initialized
INFO - 2021-08-19 08:05:49 --> Config Class Initialized
INFO - 2021-08-19 08:05:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:49 --> URI Class Initialized
INFO - 2021-08-19 08:05:49 --> Router Class Initialized
INFO - 2021-08-19 08:05:49 --> Output Class Initialized
INFO - 2021-08-19 08:05:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:49 --> Input Class Initialized
INFO - 2021-08-19 08:05:49 --> Language Class Initialized
INFO - 2021-08-19 08:05:49 --> Language Class Initialized
INFO - 2021-08-19 08:05:49 --> Config Class Initialized
INFO - 2021-08-19 08:05:49 --> Loader Class Initialized
INFO - 2021-08-19 08:05:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:49 --> Controller Class Initialized
INFO - 2021-08-19 08:05:49 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:05:49 --> Config Class Initialized
INFO - 2021-08-19 08:05:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:49 --> URI Class Initialized
INFO - 2021-08-19 08:05:49 --> Router Class Initialized
INFO - 2021-08-19 08:05:49 --> Output Class Initialized
INFO - 2021-08-19 08:05:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:49 --> Input Class Initialized
INFO - 2021-08-19 08:05:49 --> Language Class Initialized
INFO - 2021-08-19 08:05:49 --> Language Class Initialized
INFO - 2021-08-19 08:05:49 --> Config Class Initialized
INFO - 2021-08-19 08:05:49 --> Loader Class Initialized
INFO - 2021-08-19 08:05:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:49 --> Controller Class Initialized
DEBUG - 2021-08-19 08:05:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:05:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:05:49 --> Final output sent to browser
DEBUG - 2021-08-19 08:05:49 --> Total execution time: 0.0541
INFO - 2021-08-19 08:05:55 --> Config Class Initialized
INFO - 2021-08-19 08:05:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:55 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:55 --> URI Class Initialized
INFO - 2021-08-19 08:05:55 --> Router Class Initialized
INFO - 2021-08-19 08:05:55 --> Output Class Initialized
INFO - 2021-08-19 08:05:55 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:55 --> Input Class Initialized
INFO - 2021-08-19 08:05:55 --> Language Class Initialized
INFO - 2021-08-19 08:05:55 --> Language Class Initialized
INFO - 2021-08-19 08:05:55 --> Config Class Initialized
INFO - 2021-08-19 08:05:55 --> Loader Class Initialized
INFO - 2021-08-19 08:05:55 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:55 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:55 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:55 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:55 --> Controller Class Initialized
INFO - 2021-08-19 08:05:55 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:05:55 --> Final output sent to browser
DEBUG - 2021-08-19 08:05:55 --> Total execution time: 0.0494
INFO - 2021-08-19 08:05:55 --> Config Class Initialized
INFO - 2021-08-19 08:05:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:55 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:55 --> URI Class Initialized
INFO - 2021-08-19 08:05:55 --> Router Class Initialized
INFO - 2021-08-19 08:05:55 --> Output Class Initialized
INFO - 2021-08-19 08:05:55 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:55 --> Input Class Initialized
INFO - 2021-08-19 08:05:55 --> Language Class Initialized
INFO - 2021-08-19 08:05:55 --> Language Class Initialized
INFO - 2021-08-19 08:05:55 --> Config Class Initialized
INFO - 2021-08-19 08:05:55 --> Loader Class Initialized
INFO - 2021-08-19 08:05:55 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:55 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:55 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:55 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:55 --> Controller Class Initialized
DEBUG - 2021-08-19 08:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:05:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:05:56 --> Final output sent to browser
DEBUG - 2021-08-19 08:05:56 --> Total execution time: 0.7434
INFO - 2021-08-19 08:05:58 --> Config Class Initialized
INFO - 2021-08-19 08:05:58 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:05:58 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:05:58 --> Utf8 Class Initialized
INFO - 2021-08-19 08:05:58 --> URI Class Initialized
INFO - 2021-08-19 08:05:58 --> Router Class Initialized
INFO - 2021-08-19 08:05:58 --> Output Class Initialized
INFO - 2021-08-19 08:05:58 --> Security Class Initialized
DEBUG - 2021-08-19 08:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:05:58 --> Input Class Initialized
INFO - 2021-08-19 08:05:58 --> Language Class Initialized
INFO - 2021-08-19 08:05:58 --> Language Class Initialized
INFO - 2021-08-19 08:05:58 --> Config Class Initialized
INFO - 2021-08-19 08:05:58 --> Loader Class Initialized
INFO - 2021-08-19 08:05:58 --> Helper loaded: url_helper
INFO - 2021-08-19 08:05:58 --> Helper loaded: file_helper
INFO - 2021-08-19 08:05:58 --> Helper loaded: form_helper
INFO - 2021-08-19 08:05:58 --> Helper loaded: my_helper
INFO - 2021-08-19 08:05:58 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:05:58 --> Controller Class Initialized
DEBUG - 2021-08-19 08:05:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:05:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:05:58 --> Final output sent to browser
DEBUG - 2021-08-19 08:05:58 --> Total execution time: 0.0616
INFO - 2021-08-19 08:06:05 --> Config Class Initialized
INFO - 2021-08-19 08:06:05 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:05 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:05 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:05 --> URI Class Initialized
INFO - 2021-08-19 08:06:05 --> Router Class Initialized
INFO - 2021-08-19 08:06:05 --> Output Class Initialized
INFO - 2021-08-19 08:06:05 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:05 --> Input Class Initialized
INFO - 2021-08-19 08:06:05 --> Language Class Initialized
INFO - 2021-08-19 08:06:05 --> Language Class Initialized
INFO - 2021-08-19 08:06:05 --> Config Class Initialized
INFO - 2021-08-19 08:06:05 --> Loader Class Initialized
INFO - 2021-08-19 08:06:05 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:05 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:05 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:05 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:05 --> Controller Class Initialized
DEBUG - 2021-08-19 08:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:06:05 --> Final output sent to browser
DEBUG - 2021-08-19 08:06:05 --> Total execution time: 0.0536
INFO - 2021-08-19 08:06:05 --> Config Class Initialized
INFO - 2021-08-19 08:06:05 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:05 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:05 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:05 --> URI Class Initialized
INFO - 2021-08-19 08:06:05 --> Router Class Initialized
INFO - 2021-08-19 08:06:05 --> Output Class Initialized
INFO - 2021-08-19 08:06:05 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:05 --> Input Class Initialized
INFO - 2021-08-19 08:06:05 --> Language Class Initialized
INFO - 2021-08-19 08:06:05 --> Language Class Initialized
INFO - 2021-08-19 08:06:05 --> Config Class Initialized
INFO - 2021-08-19 08:06:05 --> Loader Class Initialized
INFO - 2021-08-19 08:06:05 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:05 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:05 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:05 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:05 --> Controller Class Initialized
INFO - 2021-08-19 08:06:06 --> Config Class Initialized
INFO - 2021-08-19 08:06:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:06 --> URI Class Initialized
INFO - 2021-08-19 08:06:06 --> Router Class Initialized
INFO - 2021-08-19 08:06:06 --> Output Class Initialized
INFO - 2021-08-19 08:06:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:06 --> Input Class Initialized
INFO - 2021-08-19 08:06:06 --> Language Class Initialized
INFO - 2021-08-19 08:06:06 --> Language Class Initialized
INFO - 2021-08-19 08:06:06 --> Config Class Initialized
INFO - 2021-08-19 08:06:06 --> Loader Class Initialized
INFO - 2021-08-19 08:06:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:06 --> Controller Class Initialized
DEBUG - 2021-08-19 08:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:06:06 --> Final output sent to browser
DEBUG - 2021-08-19 08:06:06 --> Total execution time: 0.0494
INFO - 2021-08-19 08:06:09 --> Config Class Initialized
INFO - 2021-08-19 08:06:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:09 --> URI Class Initialized
INFO - 2021-08-19 08:06:09 --> Router Class Initialized
INFO - 2021-08-19 08:06:09 --> Output Class Initialized
INFO - 2021-08-19 08:06:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:09 --> Input Class Initialized
INFO - 2021-08-19 08:06:09 --> Language Class Initialized
INFO - 2021-08-19 08:06:09 --> Language Class Initialized
INFO - 2021-08-19 08:06:09 --> Config Class Initialized
INFO - 2021-08-19 08:06:09 --> Loader Class Initialized
INFO - 2021-08-19 08:06:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:09 --> Controller Class Initialized
INFO - 2021-08-19 08:06:10 --> Config Class Initialized
INFO - 2021-08-19 08:06:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:10 --> URI Class Initialized
INFO - 2021-08-19 08:06:10 --> Router Class Initialized
INFO - 2021-08-19 08:06:10 --> Output Class Initialized
INFO - 2021-08-19 08:06:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:10 --> Input Class Initialized
INFO - 2021-08-19 08:06:10 --> Language Class Initialized
INFO - 2021-08-19 08:06:10 --> Language Class Initialized
INFO - 2021-08-19 08:06:10 --> Config Class Initialized
INFO - 2021-08-19 08:06:10 --> Loader Class Initialized
INFO - 2021-08-19 08:06:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:10 --> Controller Class Initialized
INFO - 2021-08-19 08:06:22 --> Config Class Initialized
INFO - 2021-08-19 08:06:22 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:22 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:22 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:22 --> URI Class Initialized
INFO - 2021-08-19 08:06:22 --> Router Class Initialized
INFO - 2021-08-19 08:06:22 --> Output Class Initialized
INFO - 2021-08-19 08:06:22 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:22 --> Input Class Initialized
INFO - 2021-08-19 08:06:22 --> Language Class Initialized
INFO - 2021-08-19 08:06:22 --> Language Class Initialized
INFO - 2021-08-19 08:06:22 --> Config Class Initialized
INFO - 2021-08-19 08:06:22 --> Loader Class Initialized
INFO - 2021-08-19 08:06:22 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:22 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:22 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:22 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:22 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:22 --> Controller Class Initialized
INFO - 2021-08-19 08:06:22 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:06:22 --> Config Class Initialized
INFO - 2021-08-19 08:06:22 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:22 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:22 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:22 --> URI Class Initialized
INFO - 2021-08-19 08:06:22 --> Router Class Initialized
INFO - 2021-08-19 08:06:22 --> Output Class Initialized
INFO - 2021-08-19 08:06:22 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:22 --> Input Class Initialized
INFO - 2021-08-19 08:06:22 --> Language Class Initialized
INFO - 2021-08-19 08:06:22 --> Language Class Initialized
INFO - 2021-08-19 08:06:22 --> Config Class Initialized
INFO - 2021-08-19 08:06:22 --> Loader Class Initialized
INFO - 2021-08-19 08:06:22 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:22 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:22 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:22 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:22 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:22 --> Controller Class Initialized
DEBUG - 2021-08-19 08:06:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:06:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:06:22 --> Final output sent to browser
DEBUG - 2021-08-19 08:06:22 --> Total execution time: 0.0551
INFO - 2021-08-19 08:06:29 --> Config Class Initialized
INFO - 2021-08-19 08:06:29 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:29 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:29 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:29 --> URI Class Initialized
INFO - 2021-08-19 08:06:29 --> Router Class Initialized
INFO - 2021-08-19 08:06:29 --> Output Class Initialized
INFO - 2021-08-19 08:06:29 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:29 --> Input Class Initialized
INFO - 2021-08-19 08:06:29 --> Language Class Initialized
INFO - 2021-08-19 08:06:29 --> Language Class Initialized
INFO - 2021-08-19 08:06:29 --> Config Class Initialized
INFO - 2021-08-19 08:06:29 --> Loader Class Initialized
INFO - 2021-08-19 08:06:29 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:29 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:29 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:29 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:29 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:29 --> Controller Class Initialized
INFO - 2021-08-19 08:06:29 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:06:29 --> Final output sent to browser
DEBUG - 2021-08-19 08:06:29 --> Total execution time: 0.0553
INFO - 2021-08-19 08:06:29 --> Config Class Initialized
INFO - 2021-08-19 08:06:29 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:29 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:29 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:29 --> URI Class Initialized
INFO - 2021-08-19 08:06:29 --> Router Class Initialized
INFO - 2021-08-19 08:06:29 --> Output Class Initialized
INFO - 2021-08-19 08:06:29 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:29 --> Input Class Initialized
INFO - 2021-08-19 08:06:29 --> Language Class Initialized
INFO - 2021-08-19 08:06:29 --> Language Class Initialized
INFO - 2021-08-19 08:06:29 --> Config Class Initialized
INFO - 2021-08-19 08:06:29 --> Loader Class Initialized
INFO - 2021-08-19 08:06:29 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:29 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:29 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:29 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:29 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:29 --> Controller Class Initialized
DEBUG - 2021-08-19 08:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:06:30 --> Final output sent to browser
DEBUG - 2021-08-19 08:06:30 --> Total execution time: 0.7286
INFO - 2021-08-19 08:06:31 --> Config Class Initialized
INFO - 2021-08-19 08:06:31 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:06:31 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:06:31 --> Utf8 Class Initialized
INFO - 2021-08-19 08:06:31 --> URI Class Initialized
INFO - 2021-08-19 08:06:31 --> Router Class Initialized
INFO - 2021-08-19 08:06:31 --> Output Class Initialized
INFO - 2021-08-19 08:06:31 --> Security Class Initialized
DEBUG - 2021-08-19 08:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:06:31 --> Input Class Initialized
INFO - 2021-08-19 08:06:31 --> Language Class Initialized
INFO - 2021-08-19 08:06:31 --> Language Class Initialized
INFO - 2021-08-19 08:06:31 --> Config Class Initialized
INFO - 2021-08-19 08:06:31 --> Loader Class Initialized
INFO - 2021-08-19 08:06:31 --> Helper loaded: url_helper
INFO - 2021-08-19 08:06:31 --> Helper loaded: file_helper
INFO - 2021-08-19 08:06:31 --> Helper loaded: form_helper
INFO - 2021-08-19 08:06:31 --> Helper loaded: my_helper
INFO - 2021-08-19 08:06:31 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:06:31 --> Controller Class Initialized
DEBUG - 2021-08-19 08:06:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:06:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:06:31 --> Final output sent to browser
DEBUG - 2021-08-19 08:06:31 --> Total execution time: 0.0646
INFO - 2021-08-19 08:07:12 --> Config Class Initialized
INFO - 2021-08-19 08:07:12 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:12 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:12 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:12 --> URI Class Initialized
INFO - 2021-08-19 08:07:12 --> Router Class Initialized
INFO - 2021-08-19 08:07:12 --> Output Class Initialized
INFO - 2021-08-19 08:07:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:12 --> Input Class Initialized
INFO - 2021-08-19 08:07:12 --> Language Class Initialized
INFO - 2021-08-19 08:07:12 --> Language Class Initialized
INFO - 2021-08-19 08:07:12 --> Config Class Initialized
INFO - 2021-08-19 08:07:12 --> Loader Class Initialized
INFO - 2021-08-19 08:07:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:12 --> Controller Class Initialized
INFO - 2021-08-19 08:07:12 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:07:12 --> Config Class Initialized
INFO - 2021-08-19 08:07:12 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:12 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:12 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:12 --> URI Class Initialized
INFO - 2021-08-19 08:07:12 --> Router Class Initialized
INFO - 2021-08-19 08:07:12 --> Output Class Initialized
INFO - 2021-08-19 08:07:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:12 --> Input Class Initialized
INFO - 2021-08-19 08:07:12 --> Language Class Initialized
INFO - 2021-08-19 08:07:12 --> Language Class Initialized
INFO - 2021-08-19 08:07:12 --> Config Class Initialized
INFO - 2021-08-19 08:07:12 --> Loader Class Initialized
INFO - 2021-08-19 08:07:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:12 --> Controller Class Initialized
DEBUG - 2021-08-19 08:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:07:12 --> Final output sent to browser
DEBUG - 2021-08-19 08:07:12 --> Total execution time: 0.0563
INFO - 2021-08-19 08:07:17 --> Config Class Initialized
INFO - 2021-08-19 08:07:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:17 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:17 --> URI Class Initialized
INFO - 2021-08-19 08:07:17 --> Router Class Initialized
INFO - 2021-08-19 08:07:17 --> Output Class Initialized
INFO - 2021-08-19 08:07:17 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:17 --> Input Class Initialized
INFO - 2021-08-19 08:07:17 --> Language Class Initialized
INFO - 2021-08-19 08:07:17 --> Language Class Initialized
INFO - 2021-08-19 08:07:17 --> Config Class Initialized
INFO - 2021-08-19 08:07:17 --> Loader Class Initialized
INFO - 2021-08-19 08:07:17 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:17 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:17 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:17 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:17 --> Controller Class Initialized
INFO - 2021-08-19 08:07:17 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:07:17 --> Final output sent to browser
DEBUG - 2021-08-19 08:07:17 --> Total execution time: 0.0460
INFO - 2021-08-19 08:07:17 --> Config Class Initialized
INFO - 2021-08-19 08:07:17 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:17 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:17 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:17 --> URI Class Initialized
INFO - 2021-08-19 08:07:17 --> Router Class Initialized
INFO - 2021-08-19 08:07:17 --> Output Class Initialized
INFO - 2021-08-19 08:07:17 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:17 --> Input Class Initialized
INFO - 2021-08-19 08:07:17 --> Language Class Initialized
INFO - 2021-08-19 08:07:17 --> Language Class Initialized
INFO - 2021-08-19 08:07:17 --> Config Class Initialized
INFO - 2021-08-19 08:07:17 --> Loader Class Initialized
INFO - 2021-08-19 08:07:17 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:17 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:17 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:17 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:17 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:17 --> Controller Class Initialized
DEBUG - 2021-08-19 08:07:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:07:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:07:18 --> Final output sent to browser
DEBUG - 2021-08-19 08:07:18 --> Total execution time: 0.6487
INFO - 2021-08-19 08:07:21 --> Config Class Initialized
INFO - 2021-08-19 08:07:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:21 --> URI Class Initialized
INFO - 2021-08-19 08:07:21 --> Router Class Initialized
INFO - 2021-08-19 08:07:21 --> Output Class Initialized
INFO - 2021-08-19 08:07:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:21 --> Input Class Initialized
INFO - 2021-08-19 08:07:21 --> Language Class Initialized
INFO - 2021-08-19 08:07:21 --> Language Class Initialized
INFO - 2021-08-19 08:07:21 --> Config Class Initialized
INFO - 2021-08-19 08:07:22 --> Loader Class Initialized
INFO - 2021-08-19 08:07:22 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:22 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:22 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:22 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:22 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:22 --> Controller Class Initialized
DEBUG - 2021-08-19 08:07:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:07:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:07:22 --> Final output sent to browser
DEBUG - 2021-08-19 08:07:22 --> Total execution time: 0.0689
INFO - 2021-08-19 08:07:22 --> Config Class Initialized
INFO - 2021-08-19 08:07:22 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:22 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:22 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:22 --> URI Class Initialized
INFO - 2021-08-19 08:07:22 --> Router Class Initialized
INFO - 2021-08-19 08:07:22 --> Output Class Initialized
INFO - 2021-08-19 08:07:22 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:22 --> Input Class Initialized
INFO - 2021-08-19 08:07:22 --> Language Class Initialized
INFO - 2021-08-19 08:07:22 --> Language Class Initialized
INFO - 2021-08-19 08:07:22 --> Config Class Initialized
INFO - 2021-08-19 08:07:22 --> Loader Class Initialized
INFO - 2021-08-19 08:07:22 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:22 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:22 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:22 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:22 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:22 --> Controller Class Initialized
INFO - 2021-08-19 08:07:24 --> Config Class Initialized
INFO - 2021-08-19 08:07:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:24 --> URI Class Initialized
INFO - 2021-08-19 08:07:24 --> Router Class Initialized
INFO - 2021-08-19 08:07:24 --> Output Class Initialized
INFO - 2021-08-19 08:07:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:24 --> Input Class Initialized
INFO - 2021-08-19 08:07:24 --> Language Class Initialized
INFO - 2021-08-19 08:07:24 --> Language Class Initialized
INFO - 2021-08-19 08:07:24 --> Config Class Initialized
INFO - 2021-08-19 08:07:24 --> Loader Class Initialized
INFO - 2021-08-19 08:07:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:24 --> Controller Class Initialized
INFO - 2021-08-19 08:07:25 --> Config Class Initialized
INFO - 2021-08-19 08:07:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:25 --> URI Class Initialized
INFO - 2021-08-19 08:07:25 --> Router Class Initialized
INFO - 2021-08-19 08:07:25 --> Output Class Initialized
INFO - 2021-08-19 08:07:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:25 --> Input Class Initialized
INFO - 2021-08-19 08:07:25 --> Language Class Initialized
INFO - 2021-08-19 08:07:25 --> Language Class Initialized
INFO - 2021-08-19 08:07:25 --> Config Class Initialized
INFO - 2021-08-19 08:07:25 --> Loader Class Initialized
INFO - 2021-08-19 08:07:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:25 --> Controller Class Initialized
INFO - 2021-08-19 08:07:25 --> Config Class Initialized
INFO - 2021-08-19 08:07:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:25 --> URI Class Initialized
INFO - 2021-08-19 08:07:25 --> Router Class Initialized
INFO - 2021-08-19 08:07:25 --> Output Class Initialized
INFO - 2021-08-19 08:07:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:25 --> Input Class Initialized
INFO - 2021-08-19 08:07:25 --> Language Class Initialized
INFO - 2021-08-19 08:07:25 --> Language Class Initialized
INFO - 2021-08-19 08:07:25 --> Config Class Initialized
INFO - 2021-08-19 08:07:25 --> Loader Class Initialized
INFO - 2021-08-19 08:07:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:25 --> Controller Class Initialized
INFO - 2021-08-19 08:07:35 --> Config Class Initialized
INFO - 2021-08-19 08:07:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:35 --> URI Class Initialized
INFO - 2021-08-19 08:07:35 --> Router Class Initialized
INFO - 2021-08-19 08:07:35 --> Output Class Initialized
INFO - 2021-08-19 08:07:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:35 --> Input Class Initialized
INFO - 2021-08-19 08:07:35 --> Language Class Initialized
INFO - 2021-08-19 08:07:35 --> Language Class Initialized
INFO - 2021-08-19 08:07:35 --> Config Class Initialized
INFO - 2021-08-19 08:07:35 --> Loader Class Initialized
INFO - 2021-08-19 08:07:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:35 --> Controller Class Initialized
INFO - 2021-08-19 08:07:41 --> Config Class Initialized
INFO - 2021-08-19 08:07:41 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:41 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:41 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:41 --> URI Class Initialized
INFO - 2021-08-19 08:07:41 --> Router Class Initialized
INFO - 2021-08-19 08:07:41 --> Output Class Initialized
INFO - 2021-08-19 08:07:41 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:41 --> Input Class Initialized
INFO - 2021-08-19 08:07:41 --> Language Class Initialized
INFO - 2021-08-19 08:07:41 --> Language Class Initialized
INFO - 2021-08-19 08:07:41 --> Config Class Initialized
INFO - 2021-08-19 08:07:41 --> Loader Class Initialized
INFO - 2021-08-19 08:07:41 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:41 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:41 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:41 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:41 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:41 --> Controller Class Initialized
INFO - 2021-08-19 08:07:44 --> Config Class Initialized
INFO - 2021-08-19 08:07:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:44 --> URI Class Initialized
INFO - 2021-08-19 08:07:44 --> Router Class Initialized
INFO - 2021-08-19 08:07:44 --> Output Class Initialized
INFO - 2021-08-19 08:07:44 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:44 --> Input Class Initialized
INFO - 2021-08-19 08:07:44 --> Language Class Initialized
INFO - 2021-08-19 08:07:44 --> Language Class Initialized
INFO - 2021-08-19 08:07:44 --> Config Class Initialized
INFO - 2021-08-19 08:07:44 --> Loader Class Initialized
INFO - 2021-08-19 08:07:44 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:44 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:44 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:44 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:44 --> Controller Class Initialized
INFO - 2021-08-19 08:07:45 --> Config Class Initialized
INFO - 2021-08-19 08:07:45 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:07:45 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:07:45 --> Utf8 Class Initialized
INFO - 2021-08-19 08:07:45 --> URI Class Initialized
INFO - 2021-08-19 08:07:45 --> Router Class Initialized
INFO - 2021-08-19 08:07:45 --> Output Class Initialized
INFO - 2021-08-19 08:07:45 --> Security Class Initialized
DEBUG - 2021-08-19 08:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:07:45 --> Input Class Initialized
INFO - 2021-08-19 08:07:45 --> Language Class Initialized
INFO - 2021-08-19 08:07:45 --> Language Class Initialized
INFO - 2021-08-19 08:07:45 --> Config Class Initialized
INFO - 2021-08-19 08:07:45 --> Loader Class Initialized
INFO - 2021-08-19 08:07:45 --> Helper loaded: url_helper
INFO - 2021-08-19 08:07:45 --> Helper loaded: file_helper
INFO - 2021-08-19 08:07:45 --> Helper loaded: form_helper
INFO - 2021-08-19 08:07:45 --> Helper loaded: my_helper
INFO - 2021-08-19 08:07:45 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:07:45 --> Controller Class Initialized
INFO - 2021-08-19 08:08:23 --> Config Class Initialized
INFO - 2021-08-19 08:08:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:08:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:08:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:08:23 --> URI Class Initialized
INFO - 2021-08-19 08:08:23 --> Router Class Initialized
INFO - 2021-08-19 08:08:23 --> Output Class Initialized
INFO - 2021-08-19 08:08:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:08:23 --> Input Class Initialized
INFO - 2021-08-19 08:08:23 --> Language Class Initialized
INFO - 2021-08-19 08:08:23 --> Language Class Initialized
INFO - 2021-08-19 08:08:23 --> Config Class Initialized
INFO - 2021-08-19 08:08:23 --> Loader Class Initialized
INFO - 2021-08-19 08:08:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:08:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:08:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:08:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:08:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:08:23 --> Controller Class Initialized
DEBUG - 2021-08-19 08:08:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:08:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:08:23 --> Final output sent to browser
DEBUG - 2021-08-19 08:08:23 --> Total execution time: 0.0552
INFO - 2021-08-19 08:08:23 --> Config Class Initialized
INFO - 2021-08-19 08:08:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:08:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:08:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:08:23 --> URI Class Initialized
INFO - 2021-08-19 08:08:23 --> Router Class Initialized
INFO - 2021-08-19 08:08:23 --> Output Class Initialized
INFO - 2021-08-19 08:08:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:08:23 --> Input Class Initialized
INFO - 2021-08-19 08:08:23 --> Language Class Initialized
INFO - 2021-08-19 08:08:23 --> Language Class Initialized
INFO - 2021-08-19 08:08:23 --> Config Class Initialized
INFO - 2021-08-19 08:08:23 --> Loader Class Initialized
INFO - 2021-08-19 08:08:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:08:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:08:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:08:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:08:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:08:23 --> Controller Class Initialized
INFO - 2021-08-19 08:08:24 --> Config Class Initialized
INFO - 2021-08-19 08:08:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:08:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:08:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:08:24 --> URI Class Initialized
INFO - 2021-08-19 08:08:24 --> Router Class Initialized
INFO - 2021-08-19 08:08:24 --> Output Class Initialized
INFO - 2021-08-19 08:08:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:08:24 --> Input Class Initialized
INFO - 2021-08-19 08:08:24 --> Language Class Initialized
INFO - 2021-08-19 08:08:24 --> Language Class Initialized
INFO - 2021-08-19 08:08:24 --> Config Class Initialized
INFO - 2021-08-19 08:08:24 --> Loader Class Initialized
INFO - 2021-08-19 08:08:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:08:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:08:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:08:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:08:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:08:24 --> Controller Class Initialized
DEBUG - 2021-08-19 08:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:08:24 --> Final output sent to browser
DEBUG - 2021-08-19 08:08:24 --> Total execution time: 0.0478
INFO - 2021-08-19 08:09:09 --> Config Class Initialized
INFO - 2021-08-19 08:09:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:09 --> URI Class Initialized
INFO - 2021-08-19 08:09:09 --> Router Class Initialized
INFO - 2021-08-19 08:09:09 --> Output Class Initialized
INFO - 2021-08-19 08:09:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:09 --> Input Class Initialized
INFO - 2021-08-19 08:09:09 --> Language Class Initialized
INFO - 2021-08-19 08:09:09 --> Language Class Initialized
INFO - 2021-08-19 08:09:09 --> Config Class Initialized
INFO - 2021-08-19 08:09:09 --> Loader Class Initialized
INFO - 2021-08-19 08:09:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:09 --> Controller Class Initialized
INFO - 2021-08-19 08:09:09 --> Config Class Initialized
INFO - 2021-08-19 08:09:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:09 --> URI Class Initialized
INFO - 2021-08-19 08:09:09 --> Router Class Initialized
INFO - 2021-08-19 08:09:09 --> Output Class Initialized
INFO - 2021-08-19 08:09:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:09 --> Input Class Initialized
INFO - 2021-08-19 08:09:09 --> Language Class Initialized
INFO - 2021-08-19 08:09:09 --> Language Class Initialized
INFO - 2021-08-19 08:09:09 --> Config Class Initialized
INFO - 2021-08-19 08:09:09 --> Loader Class Initialized
INFO - 2021-08-19 08:09:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:09 --> Controller Class Initialized
DEBUG - 2021-08-19 08:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:09:09 --> Final output sent to browser
DEBUG - 2021-08-19 08:09:09 --> Total execution time: 0.0670
INFO - 2021-08-19 08:09:09 --> Config Class Initialized
INFO - 2021-08-19 08:09:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:09 --> URI Class Initialized
INFO - 2021-08-19 08:09:09 --> Router Class Initialized
INFO - 2021-08-19 08:09:09 --> Output Class Initialized
INFO - 2021-08-19 08:09:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:09 --> Input Class Initialized
INFO - 2021-08-19 08:09:09 --> Language Class Initialized
INFO - 2021-08-19 08:09:09 --> Language Class Initialized
INFO - 2021-08-19 08:09:09 --> Config Class Initialized
INFO - 2021-08-19 08:09:09 --> Loader Class Initialized
INFO - 2021-08-19 08:09:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:09 --> Controller Class Initialized
INFO - 2021-08-19 08:09:10 --> Config Class Initialized
INFO - 2021-08-19 08:09:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:10 --> URI Class Initialized
INFO - 2021-08-19 08:09:10 --> Router Class Initialized
INFO - 2021-08-19 08:09:10 --> Output Class Initialized
INFO - 2021-08-19 08:09:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:10 --> Input Class Initialized
INFO - 2021-08-19 08:09:10 --> Language Class Initialized
INFO - 2021-08-19 08:09:10 --> Language Class Initialized
INFO - 2021-08-19 08:09:10 --> Config Class Initialized
INFO - 2021-08-19 08:09:10 --> Loader Class Initialized
INFO - 2021-08-19 08:09:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:10 --> Controller Class Initialized
DEBUG - 2021-08-19 08:09:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:09:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:09:10 --> Final output sent to browser
DEBUG - 2021-08-19 08:09:10 --> Total execution time: 0.0670
INFO - 2021-08-19 08:09:24 --> Config Class Initialized
INFO - 2021-08-19 08:09:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:24 --> URI Class Initialized
INFO - 2021-08-19 08:09:24 --> Router Class Initialized
INFO - 2021-08-19 08:09:24 --> Output Class Initialized
INFO - 2021-08-19 08:09:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:24 --> Input Class Initialized
INFO - 2021-08-19 08:09:24 --> Language Class Initialized
INFO - 2021-08-19 08:09:24 --> Language Class Initialized
INFO - 2021-08-19 08:09:24 --> Config Class Initialized
INFO - 2021-08-19 08:09:24 --> Loader Class Initialized
INFO - 2021-08-19 08:09:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:24 --> Controller Class Initialized
INFO - 2021-08-19 08:09:24 --> Config Class Initialized
INFO - 2021-08-19 08:09:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:24 --> URI Class Initialized
INFO - 2021-08-19 08:09:24 --> Router Class Initialized
INFO - 2021-08-19 08:09:24 --> Output Class Initialized
INFO - 2021-08-19 08:09:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:24 --> Input Class Initialized
INFO - 2021-08-19 08:09:24 --> Language Class Initialized
INFO - 2021-08-19 08:09:24 --> Language Class Initialized
INFO - 2021-08-19 08:09:24 --> Config Class Initialized
INFO - 2021-08-19 08:09:24 --> Loader Class Initialized
INFO - 2021-08-19 08:09:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:24 --> Controller Class Initialized
DEBUG - 2021-08-19 08:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:09:24 --> Final output sent to browser
DEBUG - 2021-08-19 08:09:24 --> Total execution time: 0.0465
INFO - 2021-08-19 08:09:24 --> Config Class Initialized
INFO - 2021-08-19 08:09:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:24 --> URI Class Initialized
INFO - 2021-08-19 08:09:24 --> Router Class Initialized
INFO - 2021-08-19 08:09:24 --> Output Class Initialized
INFO - 2021-08-19 08:09:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:24 --> Input Class Initialized
INFO - 2021-08-19 08:09:24 --> Language Class Initialized
INFO - 2021-08-19 08:09:24 --> Language Class Initialized
INFO - 2021-08-19 08:09:24 --> Config Class Initialized
INFO - 2021-08-19 08:09:24 --> Loader Class Initialized
INFO - 2021-08-19 08:09:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:24 --> Controller Class Initialized
INFO - 2021-08-19 08:09:34 --> Config Class Initialized
INFO - 2021-08-19 08:09:34 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:34 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:34 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:34 --> URI Class Initialized
INFO - 2021-08-19 08:09:34 --> Router Class Initialized
INFO - 2021-08-19 08:09:34 --> Output Class Initialized
INFO - 2021-08-19 08:09:34 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:34 --> Input Class Initialized
INFO - 2021-08-19 08:09:34 --> Language Class Initialized
INFO - 2021-08-19 08:09:34 --> Language Class Initialized
INFO - 2021-08-19 08:09:34 --> Config Class Initialized
INFO - 2021-08-19 08:09:34 --> Loader Class Initialized
INFO - 2021-08-19 08:09:34 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:34 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:34 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:34 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:34 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:34 --> Controller Class Initialized
DEBUG - 2021-08-19 08:09:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:09:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:09:34 --> Final output sent to browser
DEBUG - 2021-08-19 08:09:34 --> Total execution time: 0.0639
INFO - 2021-08-19 08:09:48 --> Config Class Initialized
INFO - 2021-08-19 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:48 --> URI Class Initialized
INFO - 2021-08-19 08:09:48 --> Router Class Initialized
INFO - 2021-08-19 08:09:48 --> Output Class Initialized
INFO - 2021-08-19 08:09:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:48 --> Input Class Initialized
INFO - 2021-08-19 08:09:48 --> Language Class Initialized
INFO - 2021-08-19 08:09:48 --> Language Class Initialized
INFO - 2021-08-19 08:09:48 --> Config Class Initialized
INFO - 2021-08-19 08:09:48 --> Loader Class Initialized
INFO - 2021-08-19 08:09:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:48 --> Controller Class Initialized
INFO - 2021-08-19 08:09:48 --> Config Class Initialized
INFO - 2021-08-19 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:48 --> URI Class Initialized
INFO - 2021-08-19 08:09:48 --> Router Class Initialized
INFO - 2021-08-19 08:09:48 --> Output Class Initialized
INFO - 2021-08-19 08:09:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:48 --> Input Class Initialized
INFO - 2021-08-19 08:09:48 --> Language Class Initialized
INFO - 2021-08-19 08:09:48 --> Language Class Initialized
INFO - 2021-08-19 08:09:48 --> Config Class Initialized
INFO - 2021-08-19 08:09:48 --> Loader Class Initialized
INFO - 2021-08-19 08:09:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:48 --> Controller Class Initialized
DEBUG - 2021-08-19 08:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:09:48 --> Final output sent to browser
DEBUG - 2021-08-19 08:09:48 --> Total execution time: 0.0683
INFO - 2021-08-19 08:09:48 --> Config Class Initialized
INFO - 2021-08-19 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:48 --> URI Class Initialized
INFO - 2021-08-19 08:09:48 --> Router Class Initialized
INFO - 2021-08-19 08:09:48 --> Output Class Initialized
INFO - 2021-08-19 08:09:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:48 --> Input Class Initialized
INFO - 2021-08-19 08:09:48 --> Language Class Initialized
INFO - 2021-08-19 08:09:48 --> Language Class Initialized
INFO - 2021-08-19 08:09:48 --> Config Class Initialized
INFO - 2021-08-19 08:09:48 --> Loader Class Initialized
INFO - 2021-08-19 08:09:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:48 --> Controller Class Initialized
INFO - 2021-08-19 08:09:49 --> Config Class Initialized
INFO - 2021-08-19 08:09:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:09:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:09:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:09:49 --> URI Class Initialized
INFO - 2021-08-19 08:09:49 --> Router Class Initialized
INFO - 2021-08-19 08:09:49 --> Output Class Initialized
INFO - 2021-08-19 08:09:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:09:49 --> Input Class Initialized
INFO - 2021-08-19 08:09:49 --> Language Class Initialized
INFO - 2021-08-19 08:09:49 --> Language Class Initialized
INFO - 2021-08-19 08:09:49 --> Config Class Initialized
INFO - 2021-08-19 08:09:49 --> Loader Class Initialized
INFO - 2021-08-19 08:09:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:09:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:09:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:09:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:09:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:09:49 --> Controller Class Initialized
DEBUG - 2021-08-19 08:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:09:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:09:49 --> Final output sent to browser
DEBUG - 2021-08-19 08:09:49 --> Total execution time: 0.0714
INFO - 2021-08-19 08:10:07 --> Config Class Initialized
INFO - 2021-08-19 08:10:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:07 --> URI Class Initialized
INFO - 2021-08-19 08:10:07 --> Router Class Initialized
INFO - 2021-08-19 08:10:07 --> Output Class Initialized
INFO - 2021-08-19 08:10:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:07 --> Input Class Initialized
INFO - 2021-08-19 08:10:07 --> Language Class Initialized
INFO - 2021-08-19 08:10:07 --> Language Class Initialized
INFO - 2021-08-19 08:10:07 --> Config Class Initialized
INFO - 2021-08-19 08:10:07 --> Loader Class Initialized
INFO - 2021-08-19 08:10:07 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:07 --> Controller Class Initialized
INFO - 2021-08-19 08:10:07 --> Config Class Initialized
INFO - 2021-08-19 08:10:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:07 --> URI Class Initialized
INFO - 2021-08-19 08:10:07 --> Router Class Initialized
INFO - 2021-08-19 08:10:07 --> Output Class Initialized
INFO - 2021-08-19 08:10:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:07 --> Input Class Initialized
INFO - 2021-08-19 08:10:07 --> Language Class Initialized
INFO - 2021-08-19 08:10:07 --> Language Class Initialized
INFO - 2021-08-19 08:10:07 --> Config Class Initialized
INFO - 2021-08-19 08:10:07 --> Loader Class Initialized
INFO - 2021-08-19 08:10:07 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:07 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:07 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:07 --> Total execution time: 0.0687
INFO - 2021-08-19 08:10:07 --> Config Class Initialized
INFO - 2021-08-19 08:10:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:07 --> URI Class Initialized
INFO - 2021-08-19 08:10:07 --> Router Class Initialized
INFO - 2021-08-19 08:10:07 --> Output Class Initialized
INFO - 2021-08-19 08:10:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:07 --> Input Class Initialized
INFO - 2021-08-19 08:10:07 --> Language Class Initialized
INFO - 2021-08-19 08:10:07 --> Language Class Initialized
INFO - 2021-08-19 08:10:07 --> Config Class Initialized
INFO - 2021-08-19 08:10:07 --> Loader Class Initialized
INFO - 2021-08-19 08:10:07 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:07 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:07 --> Controller Class Initialized
INFO - 2021-08-19 08:10:09 --> Config Class Initialized
INFO - 2021-08-19 08:10:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:09 --> URI Class Initialized
INFO - 2021-08-19 08:10:09 --> Router Class Initialized
INFO - 2021-08-19 08:10:09 --> Output Class Initialized
INFO - 2021-08-19 08:10:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:09 --> Input Class Initialized
INFO - 2021-08-19 08:10:09 --> Language Class Initialized
INFO - 2021-08-19 08:10:09 --> Language Class Initialized
INFO - 2021-08-19 08:10:09 --> Config Class Initialized
INFO - 2021-08-19 08:10:09 --> Loader Class Initialized
INFO - 2021-08-19 08:10:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:09 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:10:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:09 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:09 --> Total execution time: 0.0479
INFO - 2021-08-19 08:10:23 --> Config Class Initialized
INFO - 2021-08-19 08:10:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:23 --> URI Class Initialized
INFO - 2021-08-19 08:10:23 --> Router Class Initialized
INFO - 2021-08-19 08:10:23 --> Output Class Initialized
INFO - 2021-08-19 08:10:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:23 --> Input Class Initialized
INFO - 2021-08-19 08:10:23 --> Language Class Initialized
INFO - 2021-08-19 08:10:23 --> Language Class Initialized
INFO - 2021-08-19 08:10:23 --> Config Class Initialized
INFO - 2021-08-19 08:10:23 --> Loader Class Initialized
INFO - 2021-08-19 08:10:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:23 --> Controller Class Initialized
INFO - 2021-08-19 08:10:23 --> Config Class Initialized
INFO - 2021-08-19 08:10:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:23 --> URI Class Initialized
INFO - 2021-08-19 08:10:23 --> Router Class Initialized
INFO - 2021-08-19 08:10:23 --> Output Class Initialized
INFO - 2021-08-19 08:10:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:23 --> Input Class Initialized
INFO - 2021-08-19 08:10:23 --> Language Class Initialized
INFO - 2021-08-19 08:10:23 --> Language Class Initialized
INFO - 2021-08-19 08:10:23 --> Config Class Initialized
INFO - 2021-08-19 08:10:23 --> Loader Class Initialized
INFO - 2021-08-19 08:10:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:23 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:10:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:23 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:23 --> Total execution time: 0.0694
INFO - 2021-08-19 08:10:23 --> Config Class Initialized
INFO - 2021-08-19 08:10:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:23 --> URI Class Initialized
INFO - 2021-08-19 08:10:23 --> Router Class Initialized
INFO - 2021-08-19 08:10:23 --> Output Class Initialized
INFO - 2021-08-19 08:10:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:23 --> Input Class Initialized
INFO - 2021-08-19 08:10:23 --> Language Class Initialized
INFO - 2021-08-19 08:10:23 --> Language Class Initialized
INFO - 2021-08-19 08:10:23 --> Config Class Initialized
INFO - 2021-08-19 08:10:23 --> Loader Class Initialized
INFO - 2021-08-19 08:10:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:23 --> Controller Class Initialized
INFO - 2021-08-19 08:10:25 --> Config Class Initialized
INFO - 2021-08-19 08:10:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:25 --> URI Class Initialized
INFO - 2021-08-19 08:10:25 --> Router Class Initialized
INFO - 2021-08-19 08:10:25 --> Output Class Initialized
INFO - 2021-08-19 08:10:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:25 --> Input Class Initialized
INFO - 2021-08-19 08:10:25 --> Language Class Initialized
INFO - 2021-08-19 08:10:25 --> Language Class Initialized
INFO - 2021-08-19 08:10:25 --> Config Class Initialized
INFO - 2021-08-19 08:10:25 --> Loader Class Initialized
INFO - 2021-08-19 08:10:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:25 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:25 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:25 --> Total execution time: 0.0606
INFO - 2021-08-19 08:10:35 --> Config Class Initialized
INFO - 2021-08-19 08:10:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:35 --> URI Class Initialized
INFO - 2021-08-19 08:10:35 --> Router Class Initialized
INFO - 2021-08-19 08:10:35 --> Output Class Initialized
INFO - 2021-08-19 08:10:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:35 --> Input Class Initialized
INFO - 2021-08-19 08:10:35 --> Language Class Initialized
INFO - 2021-08-19 08:10:35 --> Language Class Initialized
INFO - 2021-08-19 08:10:35 --> Config Class Initialized
INFO - 2021-08-19 08:10:35 --> Loader Class Initialized
INFO - 2021-08-19 08:10:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:35 --> Controller Class Initialized
INFO - 2021-08-19 08:10:35 --> Config Class Initialized
INFO - 2021-08-19 08:10:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:35 --> URI Class Initialized
INFO - 2021-08-19 08:10:35 --> Router Class Initialized
INFO - 2021-08-19 08:10:35 --> Output Class Initialized
INFO - 2021-08-19 08:10:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:35 --> Input Class Initialized
INFO - 2021-08-19 08:10:35 --> Language Class Initialized
INFO - 2021-08-19 08:10:35 --> Language Class Initialized
INFO - 2021-08-19 08:10:35 --> Config Class Initialized
INFO - 2021-08-19 08:10:35 --> Loader Class Initialized
INFO - 2021-08-19 08:10:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:35 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:35 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:35 --> Total execution time: 0.0449
INFO - 2021-08-19 08:10:36 --> Config Class Initialized
INFO - 2021-08-19 08:10:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:36 --> URI Class Initialized
INFO - 2021-08-19 08:10:36 --> Router Class Initialized
INFO - 2021-08-19 08:10:36 --> Output Class Initialized
INFO - 2021-08-19 08:10:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:36 --> Input Class Initialized
INFO - 2021-08-19 08:10:36 --> Language Class Initialized
INFO - 2021-08-19 08:10:36 --> Language Class Initialized
INFO - 2021-08-19 08:10:36 --> Config Class Initialized
INFO - 2021-08-19 08:10:36 --> Loader Class Initialized
INFO - 2021-08-19 08:10:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:36 --> Controller Class Initialized
INFO - 2021-08-19 08:10:37 --> Config Class Initialized
INFO - 2021-08-19 08:10:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:37 --> URI Class Initialized
INFO - 2021-08-19 08:10:37 --> Router Class Initialized
INFO - 2021-08-19 08:10:37 --> Output Class Initialized
INFO - 2021-08-19 08:10:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:37 --> Input Class Initialized
INFO - 2021-08-19 08:10:37 --> Language Class Initialized
INFO - 2021-08-19 08:10:37 --> Language Class Initialized
INFO - 2021-08-19 08:10:37 --> Config Class Initialized
INFO - 2021-08-19 08:10:37 --> Loader Class Initialized
INFO - 2021-08-19 08:10:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:37 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:10:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:37 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:37 --> Total execution time: 0.0687
INFO - 2021-08-19 08:10:49 --> Config Class Initialized
INFO - 2021-08-19 08:10:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:49 --> URI Class Initialized
INFO - 2021-08-19 08:10:49 --> Router Class Initialized
INFO - 2021-08-19 08:10:49 --> Output Class Initialized
INFO - 2021-08-19 08:10:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:49 --> Input Class Initialized
INFO - 2021-08-19 08:10:49 --> Language Class Initialized
INFO - 2021-08-19 08:10:49 --> Language Class Initialized
INFO - 2021-08-19 08:10:49 --> Config Class Initialized
INFO - 2021-08-19 08:10:49 --> Loader Class Initialized
INFO - 2021-08-19 08:10:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:49 --> Controller Class Initialized
INFO - 2021-08-19 08:10:49 --> Config Class Initialized
INFO - 2021-08-19 08:10:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:49 --> URI Class Initialized
INFO - 2021-08-19 08:10:49 --> Router Class Initialized
INFO - 2021-08-19 08:10:49 --> Output Class Initialized
INFO - 2021-08-19 08:10:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:49 --> Input Class Initialized
INFO - 2021-08-19 08:10:49 --> Language Class Initialized
INFO - 2021-08-19 08:10:49 --> Language Class Initialized
INFO - 2021-08-19 08:10:49 --> Config Class Initialized
INFO - 2021-08-19 08:10:49 --> Loader Class Initialized
INFO - 2021-08-19 08:10:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:49 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:49 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:49 --> Total execution time: 0.0700
INFO - 2021-08-19 08:10:49 --> Config Class Initialized
INFO - 2021-08-19 08:10:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:49 --> URI Class Initialized
INFO - 2021-08-19 08:10:49 --> Router Class Initialized
INFO - 2021-08-19 08:10:49 --> Output Class Initialized
INFO - 2021-08-19 08:10:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:49 --> Input Class Initialized
INFO - 2021-08-19 08:10:49 --> Language Class Initialized
INFO - 2021-08-19 08:10:49 --> Language Class Initialized
INFO - 2021-08-19 08:10:49 --> Config Class Initialized
INFO - 2021-08-19 08:10:49 --> Loader Class Initialized
INFO - 2021-08-19 08:10:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:49 --> Controller Class Initialized
INFO - 2021-08-19 08:10:53 --> Config Class Initialized
INFO - 2021-08-19 08:10:53 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:10:53 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:10:53 --> Utf8 Class Initialized
INFO - 2021-08-19 08:10:53 --> URI Class Initialized
INFO - 2021-08-19 08:10:53 --> Router Class Initialized
INFO - 2021-08-19 08:10:53 --> Output Class Initialized
INFO - 2021-08-19 08:10:53 --> Security Class Initialized
DEBUG - 2021-08-19 08:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:10:53 --> Input Class Initialized
INFO - 2021-08-19 08:10:53 --> Language Class Initialized
INFO - 2021-08-19 08:10:53 --> Language Class Initialized
INFO - 2021-08-19 08:10:53 --> Config Class Initialized
INFO - 2021-08-19 08:10:53 --> Loader Class Initialized
INFO - 2021-08-19 08:10:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:10:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:10:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:10:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:10:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:10:53 --> Controller Class Initialized
DEBUG - 2021-08-19 08:10:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:10:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:10:53 --> Final output sent to browser
DEBUG - 2021-08-19 08:10:53 --> Total execution time: 0.0590
INFO - 2021-08-19 08:11:06 --> Config Class Initialized
INFO - 2021-08-19 08:11:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:06 --> URI Class Initialized
INFO - 2021-08-19 08:11:06 --> Router Class Initialized
INFO - 2021-08-19 08:11:06 --> Output Class Initialized
INFO - 2021-08-19 08:11:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:06 --> Input Class Initialized
INFO - 2021-08-19 08:11:06 --> Language Class Initialized
INFO - 2021-08-19 08:11:06 --> Language Class Initialized
INFO - 2021-08-19 08:11:06 --> Config Class Initialized
INFO - 2021-08-19 08:11:06 --> Loader Class Initialized
INFO - 2021-08-19 08:11:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:06 --> Controller Class Initialized
INFO - 2021-08-19 08:11:06 --> Config Class Initialized
INFO - 2021-08-19 08:11:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:06 --> URI Class Initialized
INFO - 2021-08-19 08:11:06 --> Router Class Initialized
INFO - 2021-08-19 08:11:06 --> Output Class Initialized
INFO - 2021-08-19 08:11:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:06 --> Input Class Initialized
INFO - 2021-08-19 08:11:06 --> Language Class Initialized
INFO - 2021-08-19 08:11:06 --> Language Class Initialized
INFO - 2021-08-19 08:11:06 --> Config Class Initialized
INFO - 2021-08-19 08:11:06 --> Loader Class Initialized
INFO - 2021-08-19 08:11:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:06 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:06 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:06 --> Total execution time: 0.0743
INFO - 2021-08-19 08:11:06 --> Config Class Initialized
INFO - 2021-08-19 08:11:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:06 --> URI Class Initialized
INFO - 2021-08-19 08:11:06 --> Router Class Initialized
INFO - 2021-08-19 08:11:06 --> Output Class Initialized
INFO - 2021-08-19 08:11:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:06 --> Input Class Initialized
INFO - 2021-08-19 08:11:06 --> Language Class Initialized
INFO - 2021-08-19 08:11:06 --> Language Class Initialized
INFO - 2021-08-19 08:11:06 --> Config Class Initialized
INFO - 2021-08-19 08:11:06 --> Loader Class Initialized
INFO - 2021-08-19 08:11:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:06 --> Controller Class Initialized
INFO - 2021-08-19 08:11:07 --> Config Class Initialized
INFO - 2021-08-19 08:11:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:07 --> URI Class Initialized
INFO - 2021-08-19 08:11:07 --> Router Class Initialized
INFO - 2021-08-19 08:11:07 --> Output Class Initialized
INFO - 2021-08-19 08:11:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:07 --> Input Class Initialized
INFO - 2021-08-19 08:11:07 --> Language Class Initialized
INFO - 2021-08-19 08:11:07 --> Language Class Initialized
INFO - 2021-08-19 08:11:07 --> Config Class Initialized
INFO - 2021-08-19 08:11:07 --> Loader Class Initialized
INFO - 2021-08-19 08:11:07 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:07 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:07 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:07 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:07 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:07 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:07 --> Total execution time: 0.0483
INFO - 2021-08-19 08:11:25 --> Config Class Initialized
INFO - 2021-08-19 08:11:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:25 --> URI Class Initialized
INFO - 2021-08-19 08:11:25 --> Router Class Initialized
INFO - 2021-08-19 08:11:25 --> Output Class Initialized
INFO - 2021-08-19 08:11:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:25 --> Input Class Initialized
INFO - 2021-08-19 08:11:25 --> Language Class Initialized
INFO - 2021-08-19 08:11:25 --> Language Class Initialized
INFO - 2021-08-19 08:11:25 --> Config Class Initialized
INFO - 2021-08-19 08:11:25 --> Loader Class Initialized
INFO - 2021-08-19 08:11:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:25 --> Controller Class Initialized
INFO - 2021-08-19 08:11:25 --> Config Class Initialized
INFO - 2021-08-19 08:11:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:25 --> URI Class Initialized
INFO - 2021-08-19 08:11:25 --> Router Class Initialized
INFO - 2021-08-19 08:11:25 --> Output Class Initialized
INFO - 2021-08-19 08:11:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:25 --> Input Class Initialized
INFO - 2021-08-19 08:11:25 --> Language Class Initialized
INFO - 2021-08-19 08:11:25 --> Language Class Initialized
INFO - 2021-08-19 08:11:25 --> Config Class Initialized
INFO - 2021-08-19 08:11:25 --> Loader Class Initialized
INFO - 2021-08-19 08:11:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:25 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:11:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:25 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:25 --> Total execution time: 0.0656
INFO - 2021-08-19 08:11:26 --> Config Class Initialized
INFO - 2021-08-19 08:11:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:26 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:26 --> URI Class Initialized
INFO - 2021-08-19 08:11:26 --> Router Class Initialized
INFO - 2021-08-19 08:11:26 --> Output Class Initialized
INFO - 2021-08-19 08:11:26 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:26 --> Input Class Initialized
INFO - 2021-08-19 08:11:26 --> Language Class Initialized
INFO - 2021-08-19 08:11:26 --> Language Class Initialized
INFO - 2021-08-19 08:11:26 --> Config Class Initialized
INFO - 2021-08-19 08:11:26 --> Loader Class Initialized
INFO - 2021-08-19 08:11:26 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:26 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:26 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:26 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:26 --> Controller Class Initialized
INFO - 2021-08-19 08:11:27 --> Config Class Initialized
INFO - 2021-08-19 08:11:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:27 --> URI Class Initialized
INFO - 2021-08-19 08:11:27 --> Router Class Initialized
INFO - 2021-08-19 08:11:27 --> Output Class Initialized
INFO - 2021-08-19 08:11:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:27 --> Input Class Initialized
INFO - 2021-08-19 08:11:27 --> Language Class Initialized
INFO - 2021-08-19 08:11:27 --> Language Class Initialized
INFO - 2021-08-19 08:11:27 --> Config Class Initialized
INFO - 2021-08-19 08:11:27 --> Loader Class Initialized
INFO - 2021-08-19 08:11:27 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:27 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:27 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:27 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:27 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:11:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:27 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:27 --> Total execution time: 0.0724
INFO - 2021-08-19 08:11:40 --> Config Class Initialized
INFO - 2021-08-19 08:11:40 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:40 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:40 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:40 --> URI Class Initialized
INFO - 2021-08-19 08:11:40 --> Router Class Initialized
INFO - 2021-08-19 08:11:40 --> Output Class Initialized
INFO - 2021-08-19 08:11:40 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:40 --> Input Class Initialized
INFO - 2021-08-19 08:11:40 --> Language Class Initialized
INFO - 2021-08-19 08:11:40 --> Language Class Initialized
INFO - 2021-08-19 08:11:40 --> Config Class Initialized
INFO - 2021-08-19 08:11:40 --> Loader Class Initialized
INFO - 2021-08-19 08:11:40 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:40 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:40 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:40 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:40 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:40 --> Controller Class Initialized
INFO - 2021-08-19 08:11:40 --> Config Class Initialized
INFO - 2021-08-19 08:11:40 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:40 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:40 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:40 --> URI Class Initialized
INFO - 2021-08-19 08:11:40 --> Router Class Initialized
INFO - 2021-08-19 08:11:40 --> Output Class Initialized
INFO - 2021-08-19 08:11:40 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:40 --> Input Class Initialized
INFO - 2021-08-19 08:11:40 --> Language Class Initialized
INFO - 2021-08-19 08:11:40 --> Language Class Initialized
INFO - 2021-08-19 08:11:40 --> Config Class Initialized
INFO - 2021-08-19 08:11:40 --> Loader Class Initialized
INFO - 2021-08-19 08:11:40 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:40 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:40 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:40 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:41 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:41 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:41 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:41 --> Total execution time: 0.0674
INFO - 2021-08-19 08:11:41 --> Config Class Initialized
INFO - 2021-08-19 08:11:41 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:41 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:41 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:41 --> URI Class Initialized
INFO - 2021-08-19 08:11:41 --> Router Class Initialized
INFO - 2021-08-19 08:11:41 --> Output Class Initialized
INFO - 2021-08-19 08:11:41 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:41 --> Input Class Initialized
INFO - 2021-08-19 08:11:41 --> Language Class Initialized
INFO - 2021-08-19 08:11:41 --> Language Class Initialized
INFO - 2021-08-19 08:11:41 --> Config Class Initialized
INFO - 2021-08-19 08:11:41 --> Loader Class Initialized
INFO - 2021-08-19 08:11:41 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:41 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:41 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:41 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:41 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:41 --> Controller Class Initialized
INFO - 2021-08-19 08:11:42 --> Config Class Initialized
INFO - 2021-08-19 08:11:42 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:42 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:42 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:42 --> URI Class Initialized
INFO - 2021-08-19 08:11:42 --> Router Class Initialized
INFO - 2021-08-19 08:11:42 --> Output Class Initialized
INFO - 2021-08-19 08:11:42 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:42 --> Input Class Initialized
INFO - 2021-08-19 08:11:42 --> Language Class Initialized
INFO - 2021-08-19 08:11:42 --> Language Class Initialized
INFO - 2021-08-19 08:11:42 --> Config Class Initialized
INFO - 2021-08-19 08:11:42 --> Loader Class Initialized
INFO - 2021-08-19 08:11:42 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:42 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:42 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:42 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:42 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:42 --> Controller Class Initialized
INFO - 2021-08-19 08:11:43 --> Config Class Initialized
INFO - 2021-08-19 08:11:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:43 --> URI Class Initialized
INFO - 2021-08-19 08:11:43 --> Router Class Initialized
INFO - 2021-08-19 08:11:43 --> Output Class Initialized
INFO - 2021-08-19 08:11:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:43 --> Input Class Initialized
INFO - 2021-08-19 08:11:43 --> Language Class Initialized
INFO - 2021-08-19 08:11:43 --> Language Class Initialized
INFO - 2021-08-19 08:11:43 --> Config Class Initialized
INFO - 2021-08-19 08:11:43 --> Loader Class Initialized
INFO - 2021-08-19 08:11:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:43 --> Controller Class Initialized
INFO - 2021-08-19 08:11:43 --> Config Class Initialized
INFO - 2021-08-19 08:11:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:43 --> URI Class Initialized
INFO - 2021-08-19 08:11:43 --> Router Class Initialized
INFO - 2021-08-19 08:11:43 --> Output Class Initialized
INFO - 2021-08-19 08:11:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:43 --> Input Class Initialized
INFO - 2021-08-19 08:11:43 --> Language Class Initialized
INFO - 2021-08-19 08:11:43 --> Language Class Initialized
INFO - 2021-08-19 08:11:43 --> Config Class Initialized
INFO - 2021-08-19 08:11:43 --> Loader Class Initialized
INFO - 2021-08-19 08:11:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:43 --> Controller Class Initialized
INFO - 2021-08-19 08:11:43 --> Config Class Initialized
INFO - 2021-08-19 08:11:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:43 --> URI Class Initialized
INFO - 2021-08-19 08:11:43 --> Router Class Initialized
INFO - 2021-08-19 08:11:43 --> Output Class Initialized
INFO - 2021-08-19 08:11:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:43 --> Input Class Initialized
INFO - 2021-08-19 08:11:43 --> Language Class Initialized
INFO - 2021-08-19 08:11:43 --> Language Class Initialized
INFO - 2021-08-19 08:11:43 --> Config Class Initialized
INFO - 2021-08-19 08:11:43 --> Loader Class Initialized
INFO - 2021-08-19 08:11:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:44 --> Controller Class Initialized
INFO - 2021-08-19 08:11:50 --> Config Class Initialized
INFO - 2021-08-19 08:11:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:50 --> URI Class Initialized
INFO - 2021-08-19 08:11:50 --> Router Class Initialized
INFO - 2021-08-19 08:11:50 --> Output Class Initialized
INFO - 2021-08-19 08:11:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:50 --> Input Class Initialized
INFO - 2021-08-19 08:11:50 --> Language Class Initialized
INFO - 2021-08-19 08:11:50 --> Language Class Initialized
INFO - 2021-08-19 08:11:50 --> Config Class Initialized
INFO - 2021-08-19 08:11:50 --> Loader Class Initialized
INFO - 2021-08-19 08:11:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:50 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:50 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:50 --> Total execution time: 0.0575
INFO - 2021-08-19 08:11:53 --> Config Class Initialized
INFO - 2021-08-19 08:11:53 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:53 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:53 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:53 --> URI Class Initialized
INFO - 2021-08-19 08:11:53 --> Router Class Initialized
INFO - 2021-08-19 08:11:53 --> Output Class Initialized
INFO - 2021-08-19 08:11:53 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:53 --> Input Class Initialized
INFO - 2021-08-19 08:11:53 --> Language Class Initialized
INFO - 2021-08-19 08:11:53 --> Language Class Initialized
INFO - 2021-08-19 08:11:53 --> Config Class Initialized
INFO - 2021-08-19 08:11:53 --> Loader Class Initialized
INFO - 2021-08-19 08:11:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:53 --> Controller Class Initialized
DEBUG - 2021-08-19 08:11:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:11:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:11:53 --> Final output sent to browser
DEBUG - 2021-08-19 08:11:53 --> Total execution time: 0.0475
INFO - 2021-08-19 08:11:53 --> Config Class Initialized
INFO - 2021-08-19 08:11:53 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:53 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:53 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:53 --> URI Class Initialized
INFO - 2021-08-19 08:11:53 --> Router Class Initialized
INFO - 2021-08-19 08:11:53 --> Output Class Initialized
INFO - 2021-08-19 08:11:53 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:53 --> Input Class Initialized
INFO - 2021-08-19 08:11:53 --> Language Class Initialized
INFO - 2021-08-19 08:11:53 --> Language Class Initialized
INFO - 2021-08-19 08:11:53 --> Config Class Initialized
INFO - 2021-08-19 08:11:53 --> Loader Class Initialized
INFO - 2021-08-19 08:11:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:53 --> Controller Class Initialized
INFO - 2021-08-19 08:11:54 --> Config Class Initialized
INFO - 2021-08-19 08:11:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:54 --> URI Class Initialized
INFO - 2021-08-19 08:11:54 --> Router Class Initialized
INFO - 2021-08-19 08:11:54 --> Output Class Initialized
INFO - 2021-08-19 08:11:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:54 --> Input Class Initialized
INFO - 2021-08-19 08:11:54 --> Language Class Initialized
INFO - 2021-08-19 08:11:54 --> Language Class Initialized
INFO - 2021-08-19 08:11:54 --> Config Class Initialized
INFO - 2021-08-19 08:11:54 --> Loader Class Initialized
INFO - 2021-08-19 08:11:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:54 --> Controller Class Initialized
INFO - 2021-08-19 08:11:54 --> Config Class Initialized
INFO - 2021-08-19 08:11:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:54 --> URI Class Initialized
INFO - 2021-08-19 08:11:54 --> Router Class Initialized
INFO - 2021-08-19 08:11:54 --> Output Class Initialized
INFO - 2021-08-19 08:11:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:54 --> Input Class Initialized
INFO - 2021-08-19 08:11:54 --> Language Class Initialized
INFO - 2021-08-19 08:11:54 --> Language Class Initialized
INFO - 2021-08-19 08:11:54 --> Config Class Initialized
INFO - 2021-08-19 08:11:54 --> Loader Class Initialized
INFO - 2021-08-19 08:11:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:54 --> Controller Class Initialized
INFO - 2021-08-19 08:11:55 --> Config Class Initialized
INFO - 2021-08-19 08:11:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:55 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:55 --> URI Class Initialized
INFO - 2021-08-19 08:11:55 --> Router Class Initialized
INFO - 2021-08-19 08:11:55 --> Output Class Initialized
INFO - 2021-08-19 08:11:55 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:55 --> Input Class Initialized
INFO - 2021-08-19 08:11:55 --> Language Class Initialized
INFO - 2021-08-19 08:11:55 --> Language Class Initialized
INFO - 2021-08-19 08:11:55 --> Config Class Initialized
INFO - 2021-08-19 08:11:55 --> Loader Class Initialized
INFO - 2021-08-19 08:11:55 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:55 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:55 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:55 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:55 --> Controller Class Initialized
INFO - 2021-08-19 08:11:55 --> Config Class Initialized
INFO - 2021-08-19 08:11:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:55 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:55 --> URI Class Initialized
INFO - 2021-08-19 08:11:55 --> Router Class Initialized
INFO - 2021-08-19 08:11:55 --> Output Class Initialized
INFO - 2021-08-19 08:11:55 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:55 --> Input Class Initialized
INFO - 2021-08-19 08:11:55 --> Language Class Initialized
INFO - 2021-08-19 08:11:55 --> Language Class Initialized
INFO - 2021-08-19 08:11:55 --> Config Class Initialized
INFO - 2021-08-19 08:11:55 --> Loader Class Initialized
INFO - 2021-08-19 08:11:55 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:55 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:55 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:55 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:55 --> Controller Class Initialized
INFO - 2021-08-19 08:11:59 --> Config Class Initialized
INFO - 2021-08-19 08:11:59 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:11:59 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:11:59 --> Utf8 Class Initialized
INFO - 2021-08-19 08:11:59 --> URI Class Initialized
INFO - 2021-08-19 08:11:59 --> Router Class Initialized
INFO - 2021-08-19 08:11:59 --> Output Class Initialized
INFO - 2021-08-19 08:11:59 --> Security Class Initialized
DEBUG - 2021-08-19 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:11:59 --> Input Class Initialized
INFO - 2021-08-19 08:11:59 --> Language Class Initialized
INFO - 2021-08-19 08:11:59 --> Language Class Initialized
INFO - 2021-08-19 08:11:59 --> Config Class Initialized
INFO - 2021-08-19 08:11:59 --> Loader Class Initialized
INFO - 2021-08-19 08:11:59 --> Helper loaded: url_helper
INFO - 2021-08-19 08:11:59 --> Helper loaded: file_helper
INFO - 2021-08-19 08:11:59 --> Helper loaded: form_helper
INFO - 2021-08-19 08:11:59 --> Helper loaded: my_helper
INFO - 2021-08-19 08:11:59 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:11:59 --> Controller Class Initialized
INFO - 2021-08-19 08:12:02 --> Config Class Initialized
INFO - 2021-08-19 08:12:02 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:02 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:02 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:02 --> URI Class Initialized
INFO - 2021-08-19 08:12:02 --> Router Class Initialized
INFO - 2021-08-19 08:12:02 --> Output Class Initialized
INFO - 2021-08-19 08:12:02 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:02 --> Input Class Initialized
INFO - 2021-08-19 08:12:02 --> Language Class Initialized
INFO - 2021-08-19 08:12:02 --> Language Class Initialized
INFO - 2021-08-19 08:12:02 --> Config Class Initialized
INFO - 2021-08-19 08:12:02 --> Loader Class Initialized
INFO - 2021-08-19 08:12:02 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:02 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:02 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:02 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:02 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:02 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:12:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:02 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:02 --> Total execution time: 0.0621
INFO - 2021-08-19 08:12:18 --> Config Class Initialized
INFO - 2021-08-19 08:12:18 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:18 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:18 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:18 --> URI Class Initialized
INFO - 2021-08-19 08:12:18 --> Router Class Initialized
INFO - 2021-08-19 08:12:18 --> Output Class Initialized
INFO - 2021-08-19 08:12:18 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:19 --> Input Class Initialized
INFO - 2021-08-19 08:12:19 --> Language Class Initialized
INFO - 2021-08-19 08:12:19 --> Language Class Initialized
INFO - 2021-08-19 08:12:19 --> Config Class Initialized
INFO - 2021-08-19 08:12:19 --> Loader Class Initialized
INFO - 2021-08-19 08:12:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:19 --> Controller Class Initialized
INFO - 2021-08-19 08:12:19 --> Config Class Initialized
INFO - 2021-08-19 08:12:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:19 --> URI Class Initialized
INFO - 2021-08-19 08:12:19 --> Router Class Initialized
INFO - 2021-08-19 08:12:19 --> Output Class Initialized
INFO - 2021-08-19 08:12:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:19 --> Input Class Initialized
INFO - 2021-08-19 08:12:19 --> Language Class Initialized
INFO - 2021-08-19 08:12:19 --> Language Class Initialized
INFO - 2021-08-19 08:12:19 --> Config Class Initialized
INFO - 2021-08-19 08:12:19 --> Loader Class Initialized
INFO - 2021-08-19 08:12:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:19 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:19 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:19 --> Total execution time: 0.0454
INFO - 2021-08-19 08:12:19 --> Config Class Initialized
INFO - 2021-08-19 08:12:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:19 --> URI Class Initialized
INFO - 2021-08-19 08:12:19 --> Router Class Initialized
INFO - 2021-08-19 08:12:19 --> Output Class Initialized
INFO - 2021-08-19 08:12:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:19 --> Input Class Initialized
INFO - 2021-08-19 08:12:19 --> Language Class Initialized
INFO - 2021-08-19 08:12:19 --> Language Class Initialized
INFO - 2021-08-19 08:12:19 --> Config Class Initialized
INFO - 2021-08-19 08:12:19 --> Loader Class Initialized
INFO - 2021-08-19 08:12:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:19 --> Controller Class Initialized
INFO - 2021-08-19 08:12:20 --> Config Class Initialized
INFO - 2021-08-19 08:12:20 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:20 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:20 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:20 --> URI Class Initialized
INFO - 2021-08-19 08:12:20 --> Router Class Initialized
INFO - 2021-08-19 08:12:20 --> Output Class Initialized
INFO - 2021-08-19 08:12:20 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:20 --> Input Class Initialized
INFO - 2021-08-19 08:12:20 --> Language Class Initialized
INFO - 2021-08-19 08:12:20 --> Language Class Initialized
INFO - 2021-08-19 08:12:20 --> Config Class Initialized
INFO - 2021-08-19 08:12:20 --> Loader Class Initialized
INFO - 2021-08-19 08:12:20 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:20 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:20 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:20 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:20 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:20 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:20 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:20 --> Total execution time: 0.0779
INFO - 2021-08-19 08:12:36 --> Config Class Initialized
INFO - 2021-08-19 08:12:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:36 --> URI Class Initialized
INFO - 2021-08-19 08:12:36 --> Router Class Initialized
INFO - 2021-08-19 08:12:36 --> Output Class Initialized
INFO - 2021-08-19 08:12:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:36 --> Input Class Initialized
INFO - 2021-08-19 08:12:36 --> Language Class Initialized
INFO - 2021-08-19 08:12:36 --> Language Class Initialized
INFO - 2021-08-19 08:12:36 --> Config Class Initialized
INFO - 2021-08-19 08:12:36 --> Loader Class Initialized
INFO - 2021-08-19 08:12:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:36 --> Controller Class Initialized
INFO - 2021-08-19 08:12:36 --> Config Class Initialized
INFO - 2021-08-19 08:12:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:36 --> URI Class Initialized
INFO - 2021-08-19 08:12:36 --> Router Class Initialized
INFO - 2021-08-19 08:12:36 --> Output Class Initialized
INFO - 2021-08-19 08:12:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:36 --> Input Class Initialized
INFO - 2021-08-19 08:12:36 --> Language Class Initialized
INFO - 2021-08-19 08:12:36 --> Language Class Initialized
INFO - 2021-08-19 08:12:36 --> Config Class Initialized
INFO - 2021-08-19 08:12:36 --> Loader Class Initialized
INFO - 2021-08-19 08:12:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:36 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:12:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:36 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:36 --> Total execution time: 0.0685
INFO - 2021-08-19 08:12:36 --> Config Class Initialized
INFO - 2021-08-19 08:12:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:36 --> URI Class Initialized
INFO - 2021-08-19 08:12:36 --> Router Class Initialized
INFO - 2021-08-19 08:12:36 --> Output Class Initialized
INFO - 2021-08-19 08:12:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:36 --> Input Class Initialized
INFO - 2021-08-19 08:12:36 --> Language Class Initialized
INFO - 2021-08-19 08:12:36 --> Language Class Initialized
INFO - 2021-08-19 08:12:36 --> Config Class Initialized
INFO - 2021-08-19 08:12:36 --> Loader Class Initialized
INFO - 2021-08-19 08:12:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:36 --> Controller Class Initialized
INFO - 2021-08-19 08:12:37 --> Config Class Initialized
INFO - 2021-08-19 08:12:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:37 --> URI Class Initialized
INFO - 2021-08-19 08:12:37 --> Router Class Initialized
INFO - 2021-08-19 08:12:37 --> Output Class Initialized
INFO - 2021-08-19 08:12:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:37 --> Input Class Initialized
INFO - 2021-08-19 08:12:37 --> Language Class Initialized
INFO - 2021-08-19 08:12:37 --> Language Class Initialized
INFO - 2021-08-19 08:12:37 --> Config Class Initialized
INFO - 2021-08-19 08:12:37 --> Loader Class Initialized
INFO - 2021-08-19 08:12:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:37 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-08-19 08:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:37 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:37 --> Total execution time: 0.0639
INFO - 2021-08-19 08:12:49 --> Config Class Initialized
INFO - 2021-08-19 08:12:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:49 --> URI Class Initialized
INFO - 2021-08-19 08:12:49 --> Router Class Initialized
INFO - 2021-08-19 08:12:49 --> Output Class Initialized
INFO - 2021-08-19 08:12:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:49 --> Input Class Initialized
INFO - 2021-08-19 08:12:49 --> Language Class Initialized
INFO - 2021-08-19 08:12:49 --> Language Class Initialized
INFO - 2021-08-19 08:12:49 --> Config Class Initialized
INFO - 2021-08-19 08:12:49 --> Loader Class Initialized
INFO - 2021-08-19 08:12:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:49 --> Controller Class Initialized
INFO - 2021-08-19 08:12:49 --> Config Class Initialized
INFO - 2021-08-19 08:12:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:49 --> URI Class Initialized
INFO - 2021-08-19 08:12:49 --> Router Class Initialized
INFO - 2021-08-19 08:12:49 --> Output Class Initialized
INFO - 2021-08-19 08:12:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:49 --> Input Class Initialized
INFO - 2021-08-19 08:12:49 --> Language Class Initialized
INFO - 2021-08-19 08:12:49 --> Language Class Initialized
INFO - 2021-08-19 08:12:49 --> Config Class Initialized
INFO - 2021-08-19 08:12:49 --> Loader Class Initialized
INFO - 2021-08-19 08:12:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:49 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-08-19 08:12:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:49 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:49 --> Total execution time: 0.0546
INFO - 2021-08-19 08:12:49 --> Config Class Initialized
INFO - 2021-08-19 08:12:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:49 --> URI Class Initialized
INFO - 2021-08-19 08:12:49 --> Router Class Initialized
INFO - 2021-08-19 08:12:49 --> Output Class Initialized
INFO - 2021-08-19 08:12:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:49 --> Input Class Initialized
INFO - 2021-08-19 08:12:49 --> Language Class Initialized
INFO - 2021-08-19 08:12:49 --> Language Class Initialized
INFO - 2021-08-19 08:12:49 --> Config Class Initialized
INFO - 2021-08-19 08:12:49 --> Loader Class Initialized
INFO - 2021-08-19 08:12:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:49 --> Controller Class Initialized
INFO - 2021-08-19 08:12:50 --> Config Class Initialized
INFO - 2021-08-19 08:12:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:50 --> URI Class Initialized
INFO - 2021-08-19 08:12:50 --> Router Class Initialized
INFO - 2021-08-19 08:12:50 --> Output Class Initialized
INFO - 2021-08-19 08:12:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:50 --> Input Class Initialized
INFO - 2021-08-19 08:12:50 --> Language Class Initialized
INFO - 2021-08-19 08:12:50 --> Language Class Initialized
INFO - 2021-08-19 08:12:50 --> Config Class Initialized
INFO - 2021-08-19 08:12:50 --> Loader Class Initialized
INFO - 2021-08-19 08:12:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:51 --> Controller Class Initialized
INFO - 2021-08-19 08:12:51 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:12:51 --> Config Class Initialized
INFO - 2021-08-19 08:12:51 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:12:51 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:12:51 --> Utf8 Class Initialized
INFO - 2021-08-19 08:12:51 --> URI Class Initialized
INFO - 2021-08-19 08:12:51 --> Router Class Initialized
INFO - 2021-08-19 08:12:51 --> Output Class Initialized
INFO - 2021-08-19 08:12:51 --> Security Class Initialized
DEBUG - 2021-08-19 08:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:12:51 --> Input Class Initialized
INFO - 2021-08-19 08:12:51 --> Language Class Initialized
INFO - 2021-08-19 08:12:51 --> Language Class Initialized
INFO - 2021-08-19 08:12:51 --> Config Class Initialized
INFO - 2021-08-19 08:12:51 --> Loader Class Initialized
INFO - 2021-08-19 08:12:51 --> Helper loaded: url_helper
INFO - 2021-08-19 08:12:51 --> Helper loaded: file_helper
INFO - 2021-08-19 08:12:51 --> Helper loaded: form_helper
INFO - 2021-08-19 08:12:51 --> Helper loaded: my_helper
INFO - 2021-08-19 08:12:51 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:12:51 --> Controller Class Initialized
DEBUG - 2021-08-19 08:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:12:51 --> Final output sent to browser
DEBUG - 2021-08-19 08:12:51 --> Total execution time: 0.0536
INFO - 2021-08-19 08:13:22 --> Config Class Initialized
INFO - 2021-08-19 08:13:22 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:22 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:22 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:22 --> URI Class Initialized
INFO - 2021-08-19 08:13:22 --> Router Class Initialized
INFO - 2021-08-19 08:13:22 --> Output Class Initialized
INFO - 2021-08-19 08:13:22 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:22 --> Input Class Initialized
INFO - 2021-08-19 08:13:22 --> Language Class Initialized
INFO - 2021-08-19 08:13:22 --> Language Class Initialized
INFO - 2021-08-19 08:13:22 --> Config Class Initialized
INFO - 2021-08-19 08:13:22 --> Loader Class Initialized
INFO - 2021-08-19 08:13:22 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:22 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:22 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:22 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:22 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:22 --> Controller Class Initialized
INFO - 2021-08-19 08:13:22 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:13:22 --> Final output sent to browser
DEBUG - 2021-08-19 08:13:22 --> Total execution time: 0.0482
INFO - 2021-08-19 08:13:23 --> Config Class Initialized
INFO - 2021-08-19 08:13:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:23 --> URI Class Initialized
INFO - 2021-08-19 08:13:23 --> Router Class Initialized
INFO - 2021-08-19 08:13:23 --> Output Class Initialized
INFO - 2021-08-19 08:13:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:23 --> Input Class Initialized
INFO - 2021-08-19 08:13:23 --> Language Class Initialized
INFO - 2021-08-19 08:13:23 --> Language Class Initialized
INFO - 2021-08-19 08:13:23 --> Config Class Initialized
INFO - 2021-08-19 08:13:23 --> Loader Class Initialized
INFO - 2021-08-19 08:13:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:23 --> Controller Class Initialized
DEBUG - 2021-08-19 08:13:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:13:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:13:23 --> Final output sent to browser
DEBUG - 2021-08-19 08:13:23 --> Total execution time: 0.6449
INFO - 2021-08-19 08:13:25 --> Config Class Initialized
INFO - 2021-08-19 08:13:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:25 --> URI Class Initialized
INFO - 2021-08-19 08:13:25 --> Router Class Initialized
INFO - 2021-08-19 08:13:25 --> Output Class Initialized
INFO - 2021-08-19 08:13:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:25 --> Input Class Initialized
INFO - 2021-08-19 08:13:25 --> Language Class Initialized
INFO - 2021-08-19 08:13:25 --> Language Class Initialized
INFO - 2021-08-19 08:13:25 --> Config Class Initialized
INFO - 2021-08-19 08:13:25 --> Loader Class Initialized
INFO - 2021-08-19 08:13:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:25 --> Controller Class Initialized
DEBUG - 2021-08-19 08:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:13:25 --> Final output sent to browser
DEBUG - 2021-08-19 08:13:25 --> Total execution time: 0.0628
INFO - 2021-08-19 08:13:43 --> Config Class Initialized
INFO - 2021-08-19 08:13:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:43 --> URI Class Initialized
INFO - 2021-08-19 08:13:43 --> Router Class Initialized
INFO - 2021-08-19 08:13:43 --> Output Class Initialized
INFO - 2021-08-19 08:13:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:43 --> Input Class Initialized
INFO - 2021-08-19 08:13:43 --> Language Class Initialized
INFO - 2021-08-19 08:13:43 --> Language Class Initialized
INFO - 2021-08-19 08:13:43 --> Config Class Initialized
INFO - 2021-08-19 08:13:43 --> Loader Class Initialized
INFO - 2021-08-19 08:13:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:43 --> Controller Class Initialized
DEBUG - 2021-08-19 08:13:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:13:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:13:43 --> Final output sent to browser
DEBUG - 2021-08-19 08:13:43 --> Total execution time: 0.0524
INFO - 2021-08-19 08:13:44 --> Config Class Initialized
INFO - 2021-08-19 08:13:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:44 --> URI Class Initialized
INFO - 2021-08-19 08:13:44 --> Router Class Initialized
INFO - 2021-08-19 08:13:44 --> Output Class Initialized
INFO - 2021-08-19 08:13:44 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:44 --> Input Class Initialized
INFO - 2021-08-19 08:13:44 --> Language Class Initialized
INFO - 2021-08-19 08:13:44 --> Language Class Initialized
INFO - 2021-08-19 08:13:44 --> Config Class Initialized
INFO - 2021-08-19 08:13:44 --> Loader Class Initialized
INFO - 2021-08-19 08:13:44 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:44 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:44 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:44 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:44 --> Controller Class Initialized
INFO - 2021-08-19 08:13:45 --> Config Class Initialized
INFO - 2021-08-19 08:13:45 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:45 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:45 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:45 --> URI Class Initialized
INFO - 2021-08-19 08:13:45 --> Router Class Initialized
INFO - 2021-08-19 08:13:45 --> Output Class Initialized
INFO - 2021-08-19 08:13:45 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:45 --> Input Class Initialized
INFO - 2021-08-19 08:13:45 --> Language Class Initialized
INFO - 2021-08-19 08:13:45 --> Language Class Initialized
INFO - 2021-08-19 08:13:45 --> Config Class Initialized
INFO - 2021-08-19 08:13:45 --> Loader Class Initialized
INFO - 2021-08-19 08:13:45 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:45 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:45 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:45 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:45 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:45 --> Controller Class Initialized
DEBUG - 2021-08-19 08:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:13:45 --> Final output sent to browser
DEBUG - 2021-08-19 08:13:45 --> Total execution time: 0.0505
INFO - 2021-08-19 08:13:49 --> Config Class Initialized
INFO - 2021-08-19 08:13:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:49 --> URI Class Initialized
INFO - 2021-08-19 08:13:49 --> Router Class Initialized
INFO - 2021-08-19 08:13:49 --> Output Class Initialized
INFO - 2021-08-19 08:13:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:49 --> Input Class Initialized
INFO - 2021-08-19 08:13:49 --> Language Class Initialized
INFO - 2021-08-19 08:13:49 --> Language Class Initialized
INFO - 2021-08-19 08:13:49 --> Config Class Initialized
INFO - 2021-08-19 08:13:49 --> Loader Class Initialized
INFO - 2021-08-19 08:13:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:49 --> Controller Class Initialized
INFO - 2021-08-19 08:13:52 --> Config Class Initialized
INFO - 2021-08-19 08:13:52 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:13:52 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:13:52 --> Utf8 Class Initialized
INFO - 2021-08-19 08:13:52 --> URI Class Initialized
INFO - 2021-08-19 08:13:52 --> Router Class Initialized
INFO - 2021-08-19 08:13:52 --> Output Class Initialized
INFO - 2021-08-19 08:13:52 --> Security Class Initialized
DEBUG - 2021-08-19 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:13:52 --> Input Class Initialized
INFO - 2021-08-19 08:13:52 --> Language Class Initialized
INFO - 2021-08-19 08:13:52 --> Language Class Initialized
INFO - 2021-08-19 08:13:52 --> Config Class Initialized
INFO - 2021-08-19 08:13:52 --> Loader Class Initialized
INFO - 2021-08-19 08:13:52 --> Helper loaded: url_helper
INFO - 2021-08-19 08:13:52 --> Helper loaded: file_helper
INFO - 2021-08-19 08:13:52 --> Helper loaded: form_helper
INFO - 2021-08-19 08:13:52 --> Helper loaded: my_helper
INFO - 2021-08-19 08:13:52 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:13:52 --> Controller Class Initialized
INFO - 2021-08-19 08:14:11 --> Config Class Initialized
INFO - 2021-08-19 08:14:11 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:11 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:11 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:11 --> URI Class Initialized
INFO - 2021-08-19 08:14:11 --> Router Class Initialized
INFO - 2021-08-19 08:14:11 --> Output Class Initialized
INFO - 2021-08-19 08:14:11 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:11 --> Input Class Initialized
INFO - 2021-08-19 08:14:11 --> Language Class Initialized
INFO - 2021-08-19 08:14:11 --> Language Class Initialized
INFO - 2021-08-19 08:14:11 --> Config Class Initialized
INFO - 2021-08-19 08:14:11 --> Loader Class Initialized
INFO - 2021-08-19 08:14:11 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:11 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:11 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:11 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:11 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:11 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:11 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:11 --> Total execution time: 0.0529
INFO - 2021-08-19 08:14:11 --> Config Class Initialized
INFO - 2021-08-19 08:14:11 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:11 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:11 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:11 --> URI Class Initialized
INFO - 2021-08-19 08:14:11 --> Router Class Initialized
INFO - 2021-08-19 08:14:11 --> Output Class Initialized
INFO - 2021-08-19 08:14:11 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:11 --> Input Class Initialized
INFO - 2021-08-19 08:14:11 --> Language Class Initialized
INFO - 2021-08-19 08:14:11 --> Language Class Initialized
INFO - 2021-08-19 08:14:11 --> Config Class Initialized
INFO - 2021-08-19 08:14:11 --> Loader Class Initialized
INFO - 2021-08-19 08:14:11 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:11 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:11 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:11 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:11 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:11 --> Controller Class Initialized
INFO - 2021-08-19 08:14:12 --> Config Class Initialized
INFO - 2021-08-19 08:14:12 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:12 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:12 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:12 --> URI Class Initialized
INFO - 2021-08-19 08:14:12 --> Router Class Initialized
INFO - 2021-08-19 08:14:12 --> Output Class Initialized
INFO - 2021-08-19 08:14:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:12 --> Input Class Initialized
INFO - 2021-08-19 08:14:12 --> Language Class Initialized
INFO - 2021-08-19 08:14:12 --> Language Class Initialized
INFO - 2021-08-19 08:14:12 --> Config Class Initialized
INFO - 2021-08-19 08:14:12 --> Loader Class Initialized
INFO - 2021-08-19 08:14:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:12 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:12 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:12 --> Total execution time: 0.0511
INFO - 2021-08-19 08:14:14 --> Config Class Initialized
INFO - 2021-08-19 08:14:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:14 --> URI Class Initialized
INFO - 2021-08-19 08:14:14 --> Router Class Initialized
INFO - 2021-08-19 08:14:14 --> Output Class Initialized
INFO - 2021-08-19 08:14:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:14 --> Input Class Initialized
INFO - 2021-08-19 08:14:14 --> Language Class Initialized
INFO - 2021-08-19 08:14:14 --> Language Class Initialized
INFO - 2021-08-19 08:14:14 --> Config Class Initialized
INFO - 2021-08-19 08:14:14 --> Loader Class Initialized
INFO - 2021-08-19 08:14:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:14 --> Controller Class Initialized
INFO - 2021-08-19 08:14:16 --> Config Class Initialized
INFO - 2021-08-19 08:14:16 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:16 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:16 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:16 --> URI Class Initialized
INFO - 2021-08-19 08:14:16 --> Router Class Initialized
INFO - 2021-08-19 08:14:16 --> Output Class Initialized
INFO - 2021-08-19 08:14:16 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:16 --> Input Class Initialized
INFO - 2021-08-19 08:14:16 --> Language Class Initialized
INFO - 2021-08-19 08:14:16 --> Language Class Initialized
INFO - 2021-08-19 08:14:16 --> Config Class Initialized
INFO - 2021-08-19 08:14:16 --> Loader Class Initialized
INFO - 2021-08-19 08:14:16 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:16 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:16 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:16 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:16 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:16 --> Controller Class Initialized
INFO - 2021-08-19 08:14:25 --> Config Class Initialized
INFO - 2021-08-19 08:14:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:25 --> URI Class Initialized
INFO - 2021-08-19 08:14:25 --> Router Class Initialized
INFO - 2021-08-19 08:14:25 --> Output Class Initialized
INFO - 2021-08-19 08:14:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:25 --> Input Class Initialized
INFO - 2021-08-19 08:14:25 --> Language Class Initialized
INFO - 2021-08-19 08:14:25 --> Language Class Initialized
INFO - 2021-08-19 08:14:25 --> Config Class Initialized
INFO - 2021-08-19 08:14:25 --> Loader Class Initialized
INFO - 2021-08-19 08:14:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:25 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:25 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:25 --> Total execution time: 0.0508
INFO - 2021-08-19 08:14:25 --> Config Class Initialized
INFO - 2021-08-19 08:14:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:25 --> URI Class Initialized
INFO - 2021-08-19 08:14:25 --> Router Class Initialized
INFO - 2021-08-19 08:14:25 --> Output Class Initialized
INFO - 2021-08-19 08:14:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:25 --> Input Class Initialized
INFO - 2021-08-19 08:14:25 --> Language Class Initialized
INFO - 2021-08-19 08:14:25 --> Language Class Initialized
INFO - 2021-08-19 08:14:25 --> Config Class Initialized
INFO - 2021-08-19 08:14:25 --> Loader Class Initialized
INFO - 2021-08-19 08:14:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:25 --> Controller Class Initialized
INFO - 2021-08-19 08:14:26 --> Config Class Initialized
INFO - 2021-08-19 08:14:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:26 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:26 --> URI Class Initialized
INFO - 2021-08-19 08:14:26 --> Router Class Initialized
INFO - 2021-08-19 08:14:26 --> Output Class Initialized
INFO - 2021-08-19 08:14:26 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:26 --> Input Class Initialized
INFO - 2021-08-19 08:14:26 --> Language Class Initialized
INFO - 2021-08-19 08:14:26 --> Language Class Initialized
INFO - 2021-08-19 08:14:26 --> Config Class Initialized
INFO - 2021-08-19 08:14:26 --> Loader Class Initialized
INFO - 2021-08-19 08:14:26 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:26 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:26 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:26 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:26 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:14:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:26 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:26 --> Total execution time: 0.0494
INFO - 2021-08-19 08:14:27 --> Config Class Initialized
INFO - 2021-08-19 08:14:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:27 --> URI Class Initialized
INFO - 2021-08-19 08:14:27 --> Router Class Initialized
INFO - 2021-08-19 08:14:27 --> Output Class Initialized
INFO - 2021-08-19 08:14:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:27 --> Input Class Initialized
INFO - 2021-08-19 08:14:27 --> Language Class Initialized
INFO - 2021-08-19 08:14:27 --> Language Class Initialized
INFO - 2021-08-19 08:14:27 --> Config Class Initialized
INFO - 2021-08-19 08:14:27 --> Loader Class Initialized
INFO - 2021-08-19 08:14:27 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:27 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:27 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:27 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:27 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:14:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:27 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:27 --> Total execution time: 0.0497
INFO - 2021-08-19 08:14:27 --> Config Class Initialized
INFO - 2021-08-19 08:14:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:27 --> URI Class Initialized
INFO - 2021-08-19 08:14:27 --> Router Class Initialized
INFO - 2021-08-19 08:14:27 --> Output Class Initialized
INFO - 2021-08-19 08:14:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:27 --> Input Class Initialized
INFO - 2021-08-19 08:14:27 --> Language Class Initialized
INFO - 2021-08-19 08:14:27 --> Language Class Initialized
INFO - 2021-08-19 08:14:27 --> Config Class Initialized
INFO - 2021-08-19 08:14:27 --> Loader Class Initialized
INFO - 2021-08-19 08:14:27 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:27 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:27 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:27 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:27 --> Controller Class Initialized
INFO - 2021-08-19 08:14:28 --> Config Class Initialized
INFO - 2021-08-19 08:14:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:28 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:28 --> URI Class Initialized
INFO - 2021-08-19 08:14:28 --> Router Class Initialized
INFO - 2021-08-19 08:14:28 --> Output Class Initialized
INFO - 2021-08-19 08:14:28 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:28 --> Input Class Initialized
INFO - 2021-08-19 08:14:28 --> Language Class Initialized
INFO - 2021-08-19 08:14:28 --> Language Class Initialized
INFO - 2021-08-19 08:14:28 --> Config Class Initialized
INFO - 2021-08-19 08:14:28 --> Loader Class Initialized
INFO - 2021-08-19 08:14:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:28 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:14:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:28 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:28 --> Total execution time: 0.0514
INFO - 2021-08-19 08:14:30 --> Config Class Initialized
INFO - 2021-08-19 08:14:30 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:30 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:30 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:30 --> URI Class Initialized
INFO - 2021-08-19 08:14:30 --> Router Class Initialized
INFO - 2021-08-19 08:14:30 --> Output Class Initialized
INFO - 2021-08-19 08:14:30 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:30 --> Input Class Initialized
INFO - 2021-08-19 08:14:30 --> Language Class Initialized
INFO - 2021-08-19 08:14:30 --> Language Class Initialized
INFO - 2021-08-19 08:14:30 --> Config Class Initialized
INFO - 2021-08-19 08:14:30 --> Loader Class Initialized
INFO - 2021-08-19 08:14:30 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:30 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:30 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:30 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:30 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:30 --> Controller Class Initialized
INFO - 2021-08-19 08:14:32 --> Config Class Initialized
INFO - 2021-08-19 08:14:32 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:32 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:32 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:32 --> URI Class Initialized
INFO - 2021-08-19 08:14:32 --> Router Class Initialized
INFO - 2021-08-19 08:14:32 --> Output Class Initialized
INFO - 2021-08-19 08:14:32 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:32 --> Input Class Initialized
INFO - 2021-08-19 08:14:32 --> Language Class Initialized
INFO - 2021-08-19 08:14:32 --> Language Class Initialized
INFO - 2021-08-19 08:14:32 --> Config Class Initialized
INFO - 2021-08-19 08:14:32 --> Loader Class Initialized
INFO - 2021-08-19 08:14:32 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:32 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:32 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:32 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:32 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:32 --> Controller Class Initialized
INFO - 2021-08-19 08:14:33 --> Config Class Initialized
INFO - 2021-08-19 08:14:33 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:33 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:33 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:33 --> URI Class Initialized
INFO - 2021-08-19 08:14:33 --> Router Class Initialized
INFO - 2021-08-19 08:14:33 --> Output Class Initialized
INFO - 2021-08-19 08:14:33 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:33 --> Input Class Initialized
INFO - 2021-08-19 08:14:33 --> Language Class Initialized
INFO - 2021-08-19 08:14:33 --> Language Class Initialized
INFO - 2021-08-19 08:14:33 --> Config Class Initialized
INFO - 2021-08-19 08:14:33 --> Loader Class Initialized
INFO - 2021-08-19 08:14:33 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:33 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:33 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:33 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:33 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:33 --> Controller Class Initialized
INFO - 2021-08-19 08:14:36 --> Config Class Initialized
INFO - 2021-08-19 08:14:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:36 --> URI Class Initialized
INFO - 2021-08-19 08:14:36 --> Router Class Initialized
INFO - 2021-08-19 08:14:36 --> Output Class Initialized
INFO - 2021-08-19 08:14:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:36 --> Input Class Initialized
INFO - 2021-08-19 08:14:36 --> Language Class Initialized
INFO - 2021-08-19 08:14:36 --> Language Class Initialized
INFO - 2021-08-19 08:14:36 --> Config Class Initialized
INFO - 2021-08-19 08:14:36 --> Loader Class Initialized
INFO - 2021-08-19 08:14:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:36 --> Controller Class Initialized
INFO - 2021-08-19 08:14:53 --> Config Class Initialized
INFO - 2021-08-19 08:14:53 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:53 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:53 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:53 --> URI Class Initialized
INFO - 2021-08-19 08:14:53 --> Router Class Initialized
INFO - 2021-08-19 08:14:53 --> Output Class Initialized
INFO - 2021-08-19 08:14:53 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:53 --> Input Class Initialized
INFO - 2021-08-19 08:14:53 --> Language Class Initialized
INFO - 2021-08-19 08:14:53 --> Language Class Initialized
INFO - 2021-08-19 08:14:53 --> Config Class Initialized
INFO - 2021-08-19 08:14:53 --> Loader Class Initialized
INFO - 2021-08-19 08:14:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:54 --> Controller Class Initialized
INFO - 2021-08-19 08:14:54 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:14:54 --> Config Class Initialized
INFO - 2021-08-19 08:14:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:54 --> URI Class Initialized
INFO - 2021-08-19 08:14:54 --> Router Class Initialized
INFO - 2021-08-19 08:14:54 --> Output Class Initialized
INFO - 2021-08-19 08:14:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:54 --> Input Class Initialized
INFO - 2021-08-19 08:14:54 --> Language Class Initialized
INFO - 2021-08-19 08:14:54 --> Language Class Initialized
INFO - 2021-08-19 08:14:54 --> Config Class Initialized
INFO - 2021-08-19 08:14:54 --> Loader Class Initialized
INFO - 2021-08-19 08:14:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:54 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:54 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:54 --> Total execution time: 0.0625
INFO - 2021-08-19 08:14:57 --> Config Class Initialized
INFO - 2021-08-19 08:14:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:57 --> URI Class Initialized
INFO - 2021-08-19 08:14:57 --> Router Class Initialized
INFO - 2021-08-19 08:14:57 --> Output Class Initialized
INFO - 2021-08-19 08:14:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:57 --> Input Class Initialized
INFO - 2021-08-19 08:14:57 --> Language Class Initialized
INFO - 2021-08-19 08:14:57 --> Language Class Initialized
INFO - 2021-08-19 08:14:57 --> Config Class Initialized
INFO - 2021-08-19 08:14:57 --> Loader Class Initialized
INFO - 2021-08-19 08:14:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:57 --> Controller Class Initialized
INFO - 2021-08-19 08:14:57 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:14:57 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:57 --> Total execution time: 0.0682
INFO - 2021-08-19 08:14:57 --> Config Class Initialized
INFO - 2021-08-19 08:14:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:57 --> URI Class Initialized
INFO - 2021-08-19 08:14:57 --> Router Class Initialized
INFO - 2021-08-19 08:14:57 --> Output Class Initialized
INFO - 2021-08-19 08:14:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:57 --> Input Class Initialized
INFO - 2021-08-19 08:14:57 --> Language Class Initialized
INFO - 2021-08-19 08:14:57 --> Language Class Initialized
INFO - 2021-08-19 08:14:57 --> Config Class Initialized
INFO - 2021-08-19 08:14:57 --> Loader Class Initialized
INFO - 2021-08-19 08:14:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:57 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:58 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:58 --> Total execution time: 0.7322
INFO - 2021-08-19 08:14:59 --> Config Class Initialized
INFO - 2021-08-19 08:14:59 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:14:59 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:14:59 --> Utf8 Class Initialized
INFO - 2021-08-19 08:14:59 --> URI Class Initialized
INFO - 2021-08-19 08:14:59 --> Router Class Initialized
INFO - 2021-08-19 08:14:59 --> Output Class Initialized
INFO - 2021-08-19 08:14:59 --> Security Class Initialized
DEBUG - 2021-08-19 08:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:14:59 --> Input Class Initialized
INFO - 2021-08-19 08:14:59 --> Language Class Initialized
INFO - 2021-08-19 08:14:59 --> Language Class Initialized
INFO - 2021-08-19 08:14:59 --> Config Class Initialized
INFO - 2021-08-19 08:14:59 --> Loader Class Initialized
INFO - 2021-08-19 08:14:59 --> Helper loaded: url_helper
INFO - 2021-08-19 08:14:59 --> Helper loaded: file_helper
INFO - 2021-08-19 08:14:59 --> Helper loaded: form_helper
INFO - 2021-08-19 08:14:59 --> Helper loaded: my_helper
INFO - 2021-08-19 08:14:59 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:14:59 --> Controller Class Initialized
DEBUG - 2021-08-19 08:14:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:14:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:14:59 --> Final output sent to browser
DEBUG - 2021-08-19 08:14:59 --> Total execution time: 0.0662
INFO - 2021-08-19 08:15:06 --> Config Class Initialized
INFO - 2021-08-19 08:15:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:06 --> URI Class Initialized
INFO - 2021-08-19 08:15:06 --> Router Class Initialized
INFO - 2021-08-19 08:15:06 --> Output Class Initialized
INFO - 2021-08-19 08:15:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:06 --> Input Class Initialized
INFO - 2021-08-19 08:15:06 --> Language Class Initialized
INFO - 2021-08-19 08:15:06 --> Language Class Initialized
INFO - 2021-08-19 08:15:06 --> Config Class Initialized
INFO - 2021-08-19 08:15:06 --> Loader Class Initialized
INFO - 2021-08-19 08:15:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:07 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:07 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:07 --> Total execution time: 0.0573
INFO - 2021-08-19 08:15:07 --> Config Class Initialized
INFO - 2021-08-19 08:15:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:07 --> URI Class Initialized
INFO - 2021-08-19 08:15:07 --> Router Class Initialized
INFO - 2021-08-19 08:15:07 --> Output Class Initialized
INFO - 2021-08-19 08:15:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:07 --> Input Class Initialized
INFO - 2021-08-19 08:15:07 --> Language Class Initialized
INFO - 2021-08-19 08:15:07 --> Language Class Initialized
INFO - 2021-08-19 08:15:07 --> Config Class Initialized
INFO - 2021-08-19 08:15:07 --> Loader Class Initialized
INFO - 2021-08-19 08:15:07 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:07 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:07 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:07 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:07 --> Controller Class Initialized
INFO - 2021-08-19 08:15:08 --> Config Class Initialized
INFO - 2021-08-19 08:15:08 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:08 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:08 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:08 --> URI Class Initialized
INFO - 2021-08-19 08:15:08 --> Router Class Initialized
INFO - 2021-08-19 08:15:08 --> Output Class Initialized
INFO - 2021-08-19 08:15:08 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:08 --> Input Class Initialized
INFO - 2021-08-19 08:15:08 --> Language Class Initialized
INFO - 2021-08-19 08:15:08 --> Language Class Initialized
INFO - 2021-08-19 08:15:08 --> Config Class Initialized
INFO - 2021-08-19 08:15:08 --> Loader Class Initialized
INFO - 2021-08-19 08:15:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:08 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:08 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:08 --> Total execution time: 0.0486
INFO - 2021-08-19 08:15:10 --> Config Class Initialized
INFO - 2021-08-19 08:15:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:10 --> URI Class Initialized
INFO - 2021-08-19 08:15:10 --> Router Class Initialized
INFO - 2021-08-19 08:15:10 --> Output Class Initialized
INFO - 2021-08-19 08:15:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:10 --> Input Class Initialized
INFO - 2021-08-19 08:15:10 --> Language Class Initialized
INFO - 2021-08-19 08:15:10 --> Language Class Initialized
INFO - 2021-08-19 08:15:10 --> Config Class Initialized
INFO - 2021-08-19 08:15:10 --> Loader Class Initialized
INFO - 2021-08-19 08:15:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:10 --> Controller Class Initialized
INFO - 2021-08-19 08:15:12 --> Config Class Initialized
INFO - 2021-08-19 08:15:12 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:12 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:12 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:12 --> URI Class Initialized
INFO - 2021-08-19 08:15:12 --> Router Class Initialized
INFO - 2021-08-19 08:15:12 --> Output Class Initialized
INFO - 2021-08-19 08:15:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:12 --> Input Class Initialized
INFO - 2021-08-19 08:15:12 --> Language Class Initialized
INFO - 2021-08-19 08:15:12 --> Language Class Initialized
INFO - 2021-08-19 08:15:12 --> Config Class Initialized
INFO - 2021-08-19 08:15:12 --> Loader Class Initialized
INFO - 2021-08-19 08:15:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:12 --> Controller Class Initialized
INFO - 2021-08-19 08:15:25 --> Config Class Initialized
INFO - 2021-08-19 08:15:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:25 --> URI Class Initialized
INFO - 2021-08-19 08:15:25 --> Router Class Initialized
INFO - 2021-08-19 08:15:25 --> Output Class Initialized
INFO - 2021-08-19 08:15:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:25 --> Input Class Initialized
INFO - 2021-08-19 08:15:25 --> Language Class Initialized
INFO - 2021-08-19 08:15:25 --> Language Class Initialized
INFO - 2021-08-19 08:15:25 --> Config Class Initialized
INFO - 2021-08-19 08:15:25 --> Loader Class Initialized
INFO - 2021-08-19 08:15:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:25 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:15:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:25 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:25 --> Total execution time: 0.0490
INFO - 2021-08-19 08:15:25 --> Config Class Initialized
INFO - 2021-08-19 08:15:25 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:25 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:25 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:25 --> URI Class Initialized
INFO - 2021-08-19 08:15:25 --> Router Class Initialized
INFO - 2021-08-19 08:15:25 --> Output Class Initialized
INFO - 2021-08-19 08:15:25 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:25 --> Input Class Initialized
INFO - 2021-08-19 08:15:25 --> Language Class Initialized
INFO - 2021-08-19 08:15:25 --> Language Class Initialized
INFO - 2021-08-19 08:15:25 --> Config Class Initialized
INFO - 2021-08-19 08:15:25 --> Loader Class Initialized
INFO - 2021-08-19 08:15:25 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:25 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:25 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:25 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:25 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:25 --> Controller Class Initialized
INFO - 2021-08-19 08:15:26 --> Config Class Initialized
INFO - 2021-08-19 08:15:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:26 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:26 --> URI Class Initialized
INFO - 2021-08-19 08:15:26 --> Router Class Initialized
INFO - 2021-08-19 08:15:26 --> Output Class Initialized
INFO - 2021-08-19 08:15:26 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:26 --> Input Class Initialized
INFO - 2021-08-19 08:15:26 --> Language Class Initialized
INFO - 2021-08-19 08:15:26 --> Language Class Initialized
INFO - 2021-08-19 08:15:26 --> Config Class Initialized
INFO - 2021-08-19 08:15:26 --> Loader Class Initialized
INFO - 2021-08-19 08:15:26 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:26 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:26 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:26 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:26 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:26 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:26 --> Total execution time: 0.0573
INFO - 2021-08-19 08:15:28 --> Config Class Initialized
INFO - 2021-08-19 08:15:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:28 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:28 --> URI Class Initialized
INFO - 2021-08-19 08:15:28 --> Router Class Initialized
INFO - 2021-08-19 08:15:28 --> Output Class Initialized
INFO - 2021-08-19 08:15:28 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:28 --> Input Class Initialized
INFO - 2021-08-19 08:15:28 --> Language Class Initialized
INFO - 2021-08-19 08:15:28 --> Language Class Initialized
INFO - 2021-08-19 08:15:28 --> Config Class Initialized
INFO - 2021-08-19 08:15:28 --> Loader Class Initialized
INFO - 2021-08-19 08:15:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:28 --> Controller Class Initialized
INFO - 2021-08-19 08:15:30 --> Config Class Initialized
INFO - 2021-08-19 08:15:30 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:30 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:30 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:30 --> URI Class Initialized
INFO - 2021-08-19 08:15:30 --> Router Class Initialized
INFO - 2021-08-19 08:15:30 --> Output Class Initialized
INFO - 2021-08-19 08:15:30 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:30 --> Input Class Initialized
INFO - 2021-08-19 08:15:30 --> Language Class Initialized
INFO - 2021-08-19 08:15:30 --> Language Class Initialized
INFO - 2021-08-19 08:15:30 --> Config Class Initialized
INFO - 2021-08-19 08:15:30 --> Loader Class Initialized
INFO - 2021-08-19 08:15:30 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:30 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:30 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:30 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:30 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:30 --> Controller Class Initialized
INFO - 2021-08-19 08:15:49 --> Config Class Initialized
INFO - 2021-08-19 08:15:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:49 --> URI Class Initialized
INFO - 2021-08-19 08:15:49 --> Router Class Initialized
INFO - 2021-08-19 08:15:49 --> Output Class Initialized
INFO - 2021-08-19 08:15:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:49 --> Input Class Initialized
INFO - 2021-08-19 08:15:49 --> Language Class Initialized
INFO - 2021-08-19 08:15:49 --> Language Class Initialized
INFO - 2021-08-19 08:15:49 --> Config Class Initialized
INFO - 2021-08-19 08:15:49 --> Loader Class Initialized
INFO - 2021-08-19 08:15:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:49 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:15:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:49 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:49 --> Total execution time: 0.0511
INFO - 2021-08-19 08:15:49 --> Config Class Initialized
INFO - 2021-08-19 08:15:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:49 --> URI Class Initialized
INFO - 2021-08-19 08:15:49 --> Router Class Initialized
INFO - 2021-08-19 08:15:49 --> Output Class Initialized
INFO - 2021-08-19 08:15:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:49 --> Input Class Initialized
INFO - 2021-08-19 08:15:49 --> Language Class Initialized
INFO - 2021-08-19 08:15:49 --> Language Class Initialized
INFO - 2021-08-19 08:15:49 --> Config Class Initialized
INFO - 2021-08-19 08:15:49 --> Loader Class Initialized
INFO - 2021-08-19 08:15:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:49 --> Controller Class Initialized
INFO - 2021-08-19 08:15:50 --> Config Class Initialized
INFO - 2021-08-19 08:15:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:50 --> URI Class Initialized
INFO - 2021-08-19 08:15:50 --> Router Class Initialized
INFO - 2021-08-19 08:15:50 --> Output Class Initialized
INFO - 2021-08-19 08:15:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:50 --> Input Class Initialized
INFO - 2021-08-19 08:15:50 --> Language Class Initialized
INFO - 2021-08-19 08:15:50 --> Language Class Initialized
INFO - 2021-08-19 08:15:50 --> Config Class Initialized
INFO - 2021-08-19 08:15:50 --> Loader Class Initialized
INFO - 2021-08-19 08:15:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:50 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:50 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:50 --> Total execution time: 0.0498
INFO - 2021-08-19 08:15:54 --> Config Class Initialized
INFO - 2021-08-19 08:15:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:54 --> URI Class Initialized
INFO - 2021-08-19 08:15:54 --> Router Class Initialized
INFO - 2021-08-19 08:15:54 --> Output Class Initialized
INFO - 2021-08-19 08:15:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:54 --> Input Class Initialized
INFO - 2021-08-19 08:15:54 --> Language Class Initialized
INFO - 2021-08-19 08:15:54 --> Language Class Initialized
INFO - 2021-08-19 08:15:54 --> Config Class Initialized
INFO - 2021-08-19 08:15:54 --> Loader Class Initialized
INFO - 2021-08-19 08:15:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:54 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:54 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:54 --> Total execution time: 0.0514
INFO - 2021-08-19 08:15:54 --> Config Class Initialized
INFO - 2021-08-19 08:15:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:54 --> URI Class Initialized
INFO - 2021-08-19 08:15:54 --> Router Class Initialized
INFO - 2021-08-19 08:15:54 --> Output Class Initialized
INFO - 2021-08-19 08:15:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:54 --> Input Class Initialized
INFO - 2021-08-19 08:15:54 --> Language Class Initialized
INFO - 2021-08-19 08:15:54 --> Language Class Initialized
INFO - 2021-08-19 08:15:54 --> Config Class Initialized
INFO - 2021-08-19 08:15:54 --> Loader Class Initialized
INFO - 2021-08-19 08:15:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:54 --> Controller Class Initialized
INFO - 2021-08-19 08:15:55 --> Config Class Initialized
INFO - 2021-08-19 08:15:55 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:15:55 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:15:55 --> Utf8 Class Initialized
INFO - 2021-08-19 08:15:55 --> URI Class Initialized
INFO - 2021-08-19 08:15:55 --> Router Class Initialized
INFO - 2021-08-19 08:15:55 --> Output Class Initialized
INFO - 2021-08-19 08:15:55 --> Security Class Initialized
DEBUG - 2021-08-19 08:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:15:55 --> Input Class Initialized
INFO - 2021-08-19 08:15:55 --> Language Class Initialized
INFO - 2021-08-19 08:15:55 --> Language Class Initialized
INFO - 2021-08-19 08:15:55 --> Config Class Initialized
INFO - 2021-08-19 08:15:55 --> Loader Class Initialized
INFO - 2021-08-19 08:15:55 --> Helper loaded: url_helper
INFO - 2021-08-19 08:15:55 --> Helper loaded: file_helper
INFO - 2021-08-19 08:15:55 --> Helper loaded: form_helper
INFO - 2021-08-19 08:15:55 --> Helper loaded: my_helper
INFO - 2021-08-19 08:15:55 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:15:55 --> Controller Class Initialized
DEBUG - 2021-08-19 08:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:15:55 --> Final output sent to browser
DEBUG - 2021-08-19 08:15:55 --> Total execution time: 0.0491
INFO - 2021-08-19 08:16:06 --> Config Class Initialized
INFO - 2021-08-19 08:16:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:06 --> URI Class Initialized
INFO - 2021-08-19 08:16:06 --> Router Class Initialized
INFO - 2021-08-19 08:16:06 --> Output Class Initialized
INFO - 2021-08-19 08:16:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:06 --> Input Class Initialized
INFO - 2021-08-19 08:16:06 --> Language Class Initialized
INFO - 2021-08-19 08:16:06 --> Language Class Initialized
INFO - 2021-08-19 08:16:06 --> Config Class Initialized
INFO - 2021-08-19 08:16:06 --> Loader Class Initialized
INFO - 2021-08-19 08:16:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:06 --> Controller Class Initialized
INFO - 2021-08-19 08:16:08 --> Config Class Initialized
INFO - 2021-08-19 08:16:08 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:08 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:08 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:08 --> URI Class Initialized
INFO - 2021-08-19 08:16:08 --> Router Class Initialized
INFO - 2021-08-19 08:16:08 --> Output Class Initialized
INFO - 2021-08-19 08:16:08 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:08 --> Input Class Initialized
INFO - 2021-08-19 08:16:08 --> Language Class Initialized
INFO - 2021-08-19 08:16:08 --> Language Class Initialized
INFO - 2021-08-19 08:16:08 --> Config Class Initialized
INFO - 2021-08-19 08:16:08 --> Loader Class Initialized
INFO - 2021-08-19 08:16:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:08 --> Controller Class Initialized
INFO - 2021-08-19 08:16:09 --> Config Class Initialized
INFO - 2021-08-19 08:16:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:09 --> URI Class Initialized
INFO - 2021-08-19 08:16:09 --> Router Class Initialized
INFO - 2021-08-19 08:16:09 --> Output Class Initialized
INFO - 2021-08-19 08:16:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:09 --> Input Class Initialized
INFO - 2021-08-19 08:16:09 --> Language Class Initialized
INFO - 2021-08-19 08:16:09 --> Language Class Initialized
INFO - 2021-08-19 08:16:09 --> Config Class Initialized
INFO - 2021-08-19 08:16:09 --> Loader Class Initialized
INFO - 2021-08-19 08:16:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:09 --> Controller Class Initialized
INFO - 2021-08-19 08:16:11 --> Config Class Initialized
INFO - 2021-08-19 08:16:11 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:11 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:11 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:11 --> URI Class Initialized
INFO - 2021-08-19 08:16:11 --> Router Class Initialized
INFO - 2021-08-19 08:16:11 --> Output Class Initialized
INFO - 2021-08-19 08:16:11 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:11 --> Input Class Initialized
INFO - 2021-08-19 08:16:11 --> Language Class Initialized
INFO - 2021-08-19 08:16:11 --> Language Class Initialized
INFO - 2021-08-19 08:16:11 --> Config Class Initialized
INFO - 2021-08-19 08:16:11 --> Loader Class Initialized
INFO - 2021-08-19 08:16:11 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:11 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:11 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:11 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:11 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:11 --> Controller Class Initialized
INFO - 2021-08-19 08:16:27 --> Config Class Initialized
INFO - 2021-08-19 08:16:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:27 --> URI Class Initialized
INFO - 2021-08-19 08:16:27 --> Router Class Initialized
INFO - 2021-08-19 08:16:27 --> Output Class Initialized
INFO - 2021-08-19 08:16:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:27 --> Input Class Initialized
INFO - 2021-08-19 08:16:27 --> Language Class Initialized
INFO - 2021-08-19 08:16:27 --> Language Class Initialized
INFO - 2021-08-19 08:16:27 --> Config Class Initialized
INFO - 2021-08-19 08:16:27 --> Loader Class Initialized
INFO - 2021-08-19 08:16:27 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:27 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:27 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:27 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:27 --> Controller Class Initialized
INFO - 2021-08-19 08:16:27 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:16:27 --> Config Class Initialized
INFO - 2021-08-19 08:16:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:27 --> URI Class Initialized
INFO - 2021-08-19 08:16:27 --> Router Class Initialized
INFO - 2021-08-19 08:16:27 --> Output Class Initialized
INFO - 2021-08-19 08:16:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:27 --> Input Class Initialized
INFO - 2021-08-19 08:16:27 --> Language Class Initialized
INFO - 2021-08-19 08:16:27 --> Language Class Initialized
INFO - 2021-08-19 08:16:27 --> Config Class Initialized
INFO - 2021-08-19 08:16:27 --> Loader Class Initialized
INFO - 2021-08-19 08:16:27 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:27 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:27 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:27 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:27 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:16:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:27 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:27 --> Total execution time: 0.0542
INFO - 2021-08-19 08:16:30 --> Config Class Initialized
INFO - 2021-08-19 08:16:30 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:30 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:30 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:30 --> URI Class Initialized
INFO - 2021-08-19 08:16:30 --> Router Class Initialized
INFO - 2021-08-19 08:16:30 --> Output Class Initialized
INFO - 2021-08-19 08:16:30 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:30 --> Input Class Initialized
INFO - 2021-08-19 08:16:30 --> Language Class Initialized
INFO - 2021-08-19 08:16:30 --> Language Class Initialized
INFO - 2021-08-19 08:16:30 --> Config Class Initialized
INFO - 2021-08-19 08:16:30 --> Loader Class Initialized
INFO - 2021-08-19 08:16:30 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:30 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:30 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:30 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:30 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:30 --> Controller Class Initialized
INFO - 2021-08-19 08:16:30 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:16:30 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:30 --> Total execution time: 0.0650
INFO - 2021-08-19 08:16:30 --> Config Class Initialized
INFO - 2021-08-19 08:16:30 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:30 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:30 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:30 --> URI Class Initialized
INFO - 2021-08-19 08:16:30 --> Router Class Initialized
INFO - 2021-08-19 08:16:30 --> Output Class Initialized
INFO - 2021-08-19 08:16:30 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:30 --> Input Class Initialized
INFO - 2021-08-19 08:16:30 --> Language Class Initialized
INFO - 2021-08-19 08:16:30 --> Language Class Initialized
INFO - 2021-08-19 08:16:30 --> Config Class Initialized
INFO - 2021-08-19 08:16:30 --> Loader Class Initialized
INFO - 2021-08-19 08:16:30 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:30 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:30 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:30 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:30 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:30 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:16:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:31 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:31 --> Total execution time: 0.7406
INFO - 2021-08-19 08:16:33 --> Config Class Initialized
INFO - 2021-08-19 08:16:33 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:33 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:33 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:33 --> URI Class Initialized
INFO - 2021-08-19 08:16:33 --> Router Class Initialized
INFO - 2021-08-19 08:16:33 --> Output Class Initialized
INFO - 2021-08-19 08:16:33 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:33 --> Input Class Initialized
INFO - 2021-08-19 08:16:33 --> Language Class Initialized
INFO - 2021-08-19 08:16:33 --> Language Class Initialized
INFO - 2021-08-19 08:16:33 --> Config Class Initialized
INFO - 2021-08-19 08:16:33 --> Loader Class Initialized
INFO - 2021-08-19 08:16:33 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:33 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:33 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:33 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:33 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:33 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:16:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:33 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:33 --> Total execution time: 0.0476
INFO - 2021-08-19 08:16:38 --> Config Class Initialized
INFO - 2021-08-19 08:16:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:38 --> URI Class Initialized
INFO - 2021-08-19 08:16:38 --> Router Class Initialized
INFO - 2021-08-19 08:16:38 --> Output Class Initialized
INFO - 2021-08-19 08:16:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:38 --> Input Class Initialized
INFO - 2021-08-19 08:16:38 --> Language Class Initialized
INFO - 2021-08-19 08:16:38 --> Language Class Initialized
INFO - 2021-08-19 08:16:38 --> Config Class Initialized
INFO - 2021-08-19 08:16:38 --> Loader Class Initialized
INFO - 2021-08-19 08:16:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:38 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:38 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:38 --> Total execution time: 0.0535
INFO - 2021-08-19 08:16:38 --> Config Class Initialized
INFO - 2021-08-19 08:16:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:38 --> URI Class Initialized
INFO - 2021-08-19 08:16:38 --> Router Class Initialized
INFO - 2021-08-19 08:16:38 --> Output Class Initialized
INFO - 2021-08-19 08:16:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:38 --> Input Class Initialized
INFO - 2021-08-19 08:16:38 --> Language Class Initialized
INFO - 2021-08-19 08:16:38 --> Language Class Initialized
INFO - 2021-08-19 08:16:38 --> Config Class Initialized
INFO - 2021-08-19 08:16:38 --> Loader Class Initialized
INFO - 2021-08-19 08:16:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:38 --> Controller Class Initialized
INFO - 2021-08-19 08:16:39 --> Config Class Initialized
INFO - 2021-08-19 08:16:39 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:39 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:39 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:39 --> URI Class Initialized
INFO - 2021-08-19 08:16:39 --> Router Class Initialized
INFO - 2021-08-19 08:16:39 --> Output Class Initialized
INFO - 2021-08-19 08:16:39 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:39 --> Input Class Initialized
INFO - 2021-08-19 08:16:39 --> Language Class Initialized
INFO - 2021-08-19 08:16:39 --> Language Class Initialized
INFO - 2021-08-19 08:16:39 --> Config Class Initialized
INFO - 2021-08-19 08:16:39 --> Loader Class Initialized
INFO - 2021-08-19 08:16:39 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:39 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:39 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:39 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:39 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:39 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:16:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:39 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:39 --> Total execution time: 0.0502
INFO - 2021-08-19 08:16:41 --> Config Class Initialized
INFO - 2021-08-19 08:16:41 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:41 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:41 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:41 --> URI Class Initialized
INFO - 2021-08-19 08:16:41 --> Router Class Initialized
INFO - 2021-08-19 08:16:41 --> Output Class Initialized
INFO - 2021-08-19 08:16:41 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:41 --> Input Class Initialized
INFO - 2021-08-19 08:16:41 --> Language Class Initialized
INFO - 2021-08-19 08:16:41 --> Language Class Initialized
INFO - 2021-08-19 08:16:41 --> Config Class Initialized
INFO - 2021-08-19 08:16:41 --> Loader Class Initialized
INFO - 2021-08-19 08:16:41 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:41 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:41 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:41 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:41 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:41 --> Controller Class Initialized
INFO - 2021-08-19 08:16:43 --> Config Class Initialized
INFO - 2021-08-19 08:16:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:43 --> URI Class Initialized
INFO - 2021-08-19 08:16:43 --> Router Class Initialized
INFO - 2021-08-19 08:16:43 --> Output Class Initialized
INFO - 2021-08-19 08:16:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:43 --> Input Class Initialized
INFO - 2021-08-19 08:16:43 --> Language Class Initialized
INFO - 2021-08-19 08:16:43 --> Language Class Initialized
INFO - 2021-08-19 08:16:43 --> Config Class Initialized
INFO - 2021-08-19 08:16:43 --> Loader Class Initialized
INFO - 2021-08-19 08:16:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:43 --> Controller Class Initialized
INFO - 2021-08-19 08:16:56 --> Config Class Initialized
INFO - 2021-08-19 08:16:56 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:56 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:56 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:56 --> URI Class Initialized
INFO - 2021-08-19 08:16:56 --> Router Class Initialized
INFO - 2021-08-19 08:16:56 --> Output Class Initialized
INFO - 2021-08-19 08:16:56 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:56 --> Input Class Initialized
INFO - 2021-08-19 08:16:56 --> Language Class Initialized
INFO - 2021-08-19 08:16:56 --> Language Class Initialized
INFO - 2021-08-19 08:16:56 --> Config Class Initialized
INFO - 2021-08-19 08:16:56 --> Loader Class Initialized
INFO - 2021-08-19 08:16:56 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:56 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:56 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:56 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:56 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:56 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:56 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:56 --> Total execution time: 0.0508
INFO - 2021-08-19 08:16:56 --> Config Class Initialized
INFO - 2021-08-19 08:16:56 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:56 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:56 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:56 --> URI Class Initialized
INFO - 2021-08-19 08:16:56 --> Router Class Initialized
INFO - 2021-08-19 08:16:56 --> Output Class Initialized
INFO - 2021-08-19 08:16:56 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:56 --> Input Class Initialized
INFO - 2021-08-19 08:16:56 --> Language Class Initialized
INFO - 2021-08-19 08:16:56 --> Language Class Initialized
INFO - 2021-08-19 08:16:56 --> Config Class Initialized
INFO - 2021-08-19 08:16:56 --> Loader Class Initialized
INFO - 2021-08-19 08:16:56 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:56 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:56 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:56 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:56 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:56 --> Controller Class Initialized
INFO - 2021-08-19 08:16:58 --> Config Class Initialized
INFO - 2021-08-19 08:16:58 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:16:58 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:16:58 --> Utf8 Class Initialized
INFO - 2021-08-19 08:16:58 --> URI Class Initialized
INFO - 2021-08-19 08:16:58 --> Router Class Initialized
INFO - 2021-08-19 08:16:58 --> Output Class Initialized
INFO - 2021-08-19 08:16:58 --> Security Class Initialized
DEBUG - 2021-08-19 08:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:16:58 --> Input Class Initialized
INFO - 2021-08-19 08:16:58 --> Language Class Initialized
INFO - 2021-08-19 08:16:58 --> Language Class Initialized
INFO - 2021-08-19 08:16:58 --> Config Class Initialized
INFO - 2021-08-19 08:16:58 --> Loader Class Initialized
INFO - 2021-08-19 08:16:58 --> Helper loaded: url_helper
INFO - 2021-08-19 08:16:58 --> Helper loaded: file_helper
INFO - 2021-08-19 08:16:58 --> Helper loaded: form_helper
INFO - 2021-08-19 08:16:58 --> Helper loaded: my_helper
INFO - 2021-08-19 08:16:58 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:16:58 --> Controller Class Initialized
DEBUG - 2021-08-19 08:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:16:58 --> Final output sent to browser
DEBUG - 2021-08-19 08:16:58 --> Total execution time: 0.0600
INFO - 2021-08-19 08:17:00 --> Config Class Initialized
INFO - 2021-08-19 08:17:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:00 --> URI Class Initialized
INFO - 2021-08-19 08:17:00 --> Router Class Initialized
INFO - 2021-08-19 08:17:00 --> Output Class Initialized
INFO - 2021-08-19 08:17:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:00 --> Input Class Initialized
INFO - 2021-08-19 08:17:00 --> Language Class Initialized
INFO - 2021-08-19 08:17:00 --> Language Class Initialized
INFO - 2021-08-19 08:17:00 --> Config Class Initialized
INFO - 2021-08-19 08:17:00 --> Loader Class Initialized
INFO - 2021-08-19 08:17:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:00 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:00 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:00 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:17:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:00 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:00 --> Total execution time: 0.0564
INFO - 2021-08-19 08:17:00 --> Config Class Initialized
INFO - 2021-08-19 08:17:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:00 --> URI Class Initialized
INFO - 2021-08-19 08:17:00 --> Router Class Initialized
INFO - 2021-08-19 08:17:00 --> Output Class Initialized
INFO - 2021-08-19 08:17:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:00 --> Input Class Initialized
INFO - 2021-08-19 08:17:00 --> Language Class Initialized
INFO - 2021-08-19 08:17:00 --> Language Class Initialized
INFO - 2021-08-19 08:17:00 --> Config Class Initialized
INFO - 2021-08-19 08:17:00 --> Loader Class Initialized
INFO - 2021-08-19 08:17:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:00 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:00 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:01 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:01 --> Controller Class Initialized
INFO - 2021-08-19 08:17:01 --> Config Class Initialized
INFO - 2021-08-19 08:17:01 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:01 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:01 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:01 --> URI Class Initialized
INFO - 2021-08-19 08:17:01 --> Router Class Initialized
INFO - 2021-08-19 08:17:01 --> Output Class Initialized
INFO - 2021-08-19 08:17:01 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:01 --> Input Class Initialized
INFO - 2021-08-19 08:17:01 --> Language Class Initialized
INFO - 2021-08-19 08:17:01 --> Language Class Initialized
INFO - 2021-08-19 08:17:01 --> Config Class Initialized
INFO - 2021-08-19 08:17:01 --> Loader Class Initialized
INFO - 2021-08-19 08:17:01 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:01 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:01 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:01 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:01 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:01 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:17:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:02 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:02 --> Total execution time: 0.0496
INFO - 2021-08-19 08:17:04 --> Config Class Initialized
INFO - 2021-08-19 08:17:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:04 --> URI Class Initialized
INFO - 2021-08-19 08:17:04 --> Router Class Initialized
INFO - 2021-08-19 08:17:04 --> Output Class Initialized
INFO - 2021-08-19 08:17:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:04 --> Input Class Initialized
INFO - 2021-08-19 08:17:04 --> Language Class Initialized
INFO - 2021-08-19 08:17:04 --> Language Class Initialized
INFO - 2021-08-19 08:17:04 --> Config Class Initialized
INFO - 2021-08-19 08:17:04 --> Loader Class Initialized
INFO - 2021-08-19 08:17:04 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:04 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:04 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:04 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:04 --> Controller Class Initialized
INFO - 2021-08-19 08:17:06 --> Config Class Initialized
INFO - 2021-08-19 08:17:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:06 --> URI Class Initialized
INFO - 2021-08-19 08:17:06 --> Router Class Initialized
INFO - 2021-08-19 08:17:06 --> Output Class Initialized
INFO - 2021-08-19 08:17:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:06 --> Input Class Initialized
INFO - 2021-08-19 08:17:06 --> Language Class Initialized
INFO - 2021-08-19 08:17:06 --> Language Class Initialized
INFO - 2021-08-19 08:17:06 --> Config Class Initialized
INFO - 2021-08-19 08:17:06 --> Loader Class Initialized
INFO - 2021-08-19 08:17:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:06 --> Controller Class Initialized
INFO - 2021-08-19 08:17:11 --> Config Class Initialized
INFO - 2021-08-19 08:17:11 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:11 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:11 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:11 --> URI Class Initialized
INFO - 2021-08-19 08:17:11 --> Router Class Initialized
INFO - 2021-08-19 08:17:11 --> Output Class Initialized
INFO - 2021-08-19 08:17:11 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:11 --> Input Class Initialized
INFO - 2021-08-19 08:17:11 --> Language Class Initialized
INFO - 2021-08-19 08:17:11 --> Language Class Initialized
INFO - 2021-08-19 08:17:11 --> Config Class Initialized
INFO - 2021-08-19 08:17:11 --> Loader Class Initialized
INFO - 2021-08-19 08:17:11 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:11 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:11 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:11 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:11 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:11 --> Controller Class Initialized
INFO - 2021-08-19 08:17:11 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:17:11 --> Config Class Initialized
INFO - 2021-08-19 08:17:11 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:11 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:11 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:11 --> URI Class Initialized
INFO - 2021-08-19 08:17:11 --> Router Class Initialized
INFO - 2021-08-19 08:17:11 --> Output Class Initialized
INFO - 2021-08-19 08:17:11 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:11 --> Input Class Initialized
INFO - 2021-08-19 08:17:11 --> Language Class Initialized
INFO - 2021-08-19 08:17:11 --> Language Class Initialized
INFO - 2021-08-19 08:17:11 --> Config Class Initialized
INFO - 2021-08-19 08:17:11 --> Loader Class Initialized
INFO - 2021-08-19 08:17:11 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:11 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:11 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:11 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:11 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:11 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:11 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:11 --> Total execution time: 0.0551
INFO - 2021-08-19 08:17:21 --> Config Class Initialized
INFO - 2021-08-19 08:17:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:21 --> URI Class Initialized
INFO - 2021-08-19 08:17:21 --> Router Class Initialized
INFO - 2021-08-19 08:17:21 --> Output Class Initialized
INFO - 2021-08-19 08:17:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:21 --> Input Class Initialized
INFO - 2021-08-19 08:17:21 --> Language Class Initialized
INFO - 2021-08-19 08:17:21 --> Language Class Initialized
INFO - 2021-08-19 08:17:21 --> Config Class Initialized
INFO - 2021-08-19 08:17:21 --> Loader Class Initialized
INFO - 2021-08-19 08:17:21 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:21 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:21 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:21 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:21 --> Controller Class Initialized
INFO - 2021-08-19 08:17:21 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:17:21 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:21 --> Total execution time: 0.0600
INFO - 2021-08-19 08:17:21 --> Config Class Initialized
INFO - 2021-08-19 08:17:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:21 --> URI Class Initialized
INFO - 2021-08-19 08:17:21 --> Router Class Initialized
INFO - 2021-08-19 08:17:21 --> Output Class Initialized
INFO - 2021-08-19 08:17:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:21 --> Input Class Initialized
INFO - 2021-08-19 08:17:21 --> Language Class Initialized
INFO - 2021-08-19 08:17:21 --> Language Class Initialized
INFO - 2021-08-19 08:17:21 --> Config Class Initialized
INFO - 2021-08-19 08:17:21 --> Loader Class Initialized
INFO - 2021-08-19 08:17:21 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:21 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:21 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:21 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:21 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:17:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:22 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:22 --> Total execution time: 0.7311
INFO - 2021-08-19 08:17:26 --> Config Class Initialized
INFO - 2021-08-19 08:17:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:26 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:26 --> URI Class Initialized
INFO - 2021-08-19 08:17:26 --> Router Class Initialized
INFO - 2021-08-19 08:17:26 --> Output Class Initialized
INFO - 2021-08-19 08:17:26 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:26 --> Input Class Initialized
INFO - 2021-08-19 08:17:26 --> Language Class Initialized
INFO - 2021-08-19 08:17:26 --> Language Class Initialized
INFO - 2021-08-19 08:17:26 --> Config Class Initialized
INFO - 2021-08-19 08:17:26 --> Loader Class Initialized
INFO - 2021-08-19 08:17:26 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:26 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:26 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:26 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:26 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:17:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:26 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:26 --> Total execution time: 0.0607
INFO - 2021-08-19 08:17:31 --> Config Class Initialized
INFO - 2021-08-19 08:17:31 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:31 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:31 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:31 --> URI Class Initialized
INFO - 2021-08-19 08:17:31 --> Router Class Initialized
INFO - 2021-08-19 08:17:31 --> Output Class Initialized
INFO - 2021-08-19 08:17:31 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:31 --> Input Class Initialized
INFO - 2021-08-19 08:17:31 --> Language Class Initialized
INFO - 2021-08-19 08:17:31 --> Language Class Initialized
INFO - 2021-08-19 08:17:31 --> Config Class Initialized
INFO - 2021-08-19 08:17:31 --> Loader Class Initialized
INFO - 2021-08-19 08:17:31 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:31 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:31 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:31 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:31 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:31 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:31 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:31 --> Total execution time: 0.0595
INFO - 2021-08-19 08:17:31 --> Config Class Initialized
INFO - 2021-08-19 08:17:31 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:31 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:31 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:31 --> URI Class Initialized
INFO - 2021-08-19 08:17:31 --> Router Class Initialized
INFO - 2021-08-19 08:17:31 --> Output Class Initialized
INFO - 2021-08-19 08:17:31 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:31 --> Input Class Initialized
INFO - 2021-08-19 08:17:31 --> Language Class Initialized
INFO - 2021-08-19 08:17:31 --> Language Class Initialized
INFO - 2021-08-19 08:17:31 --> Config Class Initialized
INFO - 2021-08-19 08:17:31 --> Loader Class Initialized
INFO - 2021-08-19 08:17:31 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:31 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:31 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:31 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:31 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:31 --> Controller Class Initialized
INFO - 2021-08-19 08:17:32 --> Config Class Initialized
INFO - 2021-08-19 08:17:32 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:32 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:32 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:32 --> URI Class Initialized
INFO - 2021-08-19 08:17:32 --> Router Class Initialized
INFO - 2021-08-19 08:17:32 --> Output Class Initialized
INFO - 2021-08-19 08:17:32 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:32 --> Input Class Initialized
INFO - 2021-08-19 08:17:32 --> Language Class Initialized
INFO - 2021-08-19 08:17:32 --> Language Class Initialized
INFO - 2021-08-19 08:17:32 --> Config Class Initialized
INFO - 2021-08-19 08:17:32 --> Loader Class Initialized
INFO - 2021-08-19 08:17:32 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:32 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:32 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:32 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:32 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:32 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:17:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:32 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:32 --> Total execution time: 0.0493
INFO - 2021-08-19 08:17:35 --> Config Class Initialized
INFO - 2021-08-19 08:17:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:35 --> URI Class Initialized
INFO - 2021-08-19 08:17:35 --> Router Class Initialized
INFO - 2021-08-19 08:17:35 --> Output Class Initialized
INFO - 2021-08-19 08:17:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:35 --> Input Class Initialized
INFO - 2021-08-19 08:17:35 --> Language Class Initialized
INFO - 2021-08-19 08:17:35 --> Language Class Initialized
INFO - 2021-08-19 08:17:35 --> Config Class Initialized
INFO - 2021-08-19 08:17:35 --> Loader Class Initialized
INFO - 2021-08-19 08:17:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:35 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:17:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:35 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:35 --> Total execution time: 0.0486
INFO - 2021-08-19 08:17:35 --> Config Class Initialized
INFO - 2021-08-19 08:17:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:35 --> URI Class Initialized
INFO - 2021-08-19 08:17:35 --> Router Class Initialized
INFO - 2021-08-19 08:17:35 --> Output Class Initialized
INFO - 2021-08-19 08:17:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:35 --> Input Class Initialized
INFO - 2021-08-19 08:17:35 --> Language Class Initialized
INFO - 2021-08-19 08:17:35 --> Language Class Initialized
INFO - 2021-08-19 08:17:35 --> Config Class Initialized
INFO - 2021-08-19 08:17:35 --> Loader Class Initialized
INFO - 2021-08-19 08:17:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:35 --> Controller Class Initialized
INFO - 2021-08-19 08:17:36 --> Config Class Initialized
INFO - 2021-08-19 08:17:36 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:36 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:36 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:36 --> URI Class Initialized
INFO - 2021-08-19 08:17:36 --> Router Class Initialized
INFO - 2021-08-19 08:17:36 --> Output Class Initialized
INFO - 2021-08-19 08:17:36 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:36 --> Input Class Initialized
INFO - 2021-08-19 08:17:36 --> Language Class Initialized
INFO - 2021-08-19 08:17:36 --> Language Class Initialized
INFO - 2021-08-19 08:17:36 --> Config Class Initialized
INFO - 2021-08-19 08:17:36 --> Loader Class Initialized
INFO - 2021-08-19 08:17:36 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:36 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:36 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:36 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:36 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:36 --> Controller Class Initialized
DEBUG - 2021-08-19 08:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:17:36 --> Final output sent to browser
DEBUG - 2021-08-19 08:17:36 --> Total execution time: 0.0483
INFO - 2021-08-19 08:17:45 --> Config Class Initialized
INFO - 2021-08-19 08:17:45 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:45 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:45 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:45 --> URI Class Initialized
INFO - 2021-08-19 08:17:45 --> Router Class Initialized
INFO - 2021-08-19 08:17:45 --> Output Class Initialized
INFO - 2021-08-19 08:17:45 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:45 --> Input Class Initialized
INFO - 2021-08-19 08:17:45 --> Language Class Initialized
INFO - 2021-08-19 08:17:45 --> Language Class Initialized
INFO - 2021-08-19 08:17:45 --> Config Class Initialized
INFO - 2021-08-19 08:17:45 --> Loader Class Initialized
INFO - 2021-08-19 08:17:45 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:45 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:45 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:45 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:45 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:45 --> Controller Class Initialized
INFO - 2021-08-19 08:17:47 --> Config Class Initialized
INFO - 2021-08-19 08:17:47 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:47 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:47 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:47 --> URI Class Initialized
INFO - 2021-08-19 08:17:47 --> Router Class Initialized
INFO - 2021-08-19 08:17:47 --> Output Class Initialized
INFO - 2021-08-19 08:17:47 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:47 --> Input Class Initialized
INFO - 2021-08-19 08:17:47 --> Language Class Initialized
INFO - 2021-08-19 08:17:47 --> Language Class Initialized
INFO - 2021-08-19 08:17:47 --> Config Class Initialized
INFO - 2021-08-19 08:17:47 --> Loader Class Initialized
INFO - 2021-08-19 08:17:47 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:47 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:47 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:47 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:47 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:47 --> Controller Class Initialized
INFO - 2021-08-19 08:17:48 --> Config Class Initialized
INFO - 2021-08-19 08:17:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:48 --> URI Class Initialized
INFO - 2021-08-19 08:17:48 --> Router Class Initialized
INFO - 2021-08-19 08:17:48 --> Output Class Initialized
INFO - 2021-08-19 08:17:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:48 --> Input Class Initialized
INFO - 2021-08-19 08:17:48 --> Language Class Initialized
INFO - 2021-08-19 08:17:48 --> Language Class Initialized
INFO - 2021-08-19 08:17:48 --> Config Class Initialized
INFO - 2021-08-19 08:17:48 --> Loader Class Initialized
INFO - 2021-08-19 08:17:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:48 --> Controller Class Initialized
INFO - 2021-08-19 08:17:50 --> Config Class Initialized
INFO - 2021-08-19 08:17:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:50 --> URI Class Initialized
INFO - 2021-08-19 08:17:50 --> Router Class Initialized
INFO - 2021-08-19 08:17:50 --> Output Class Initialized
INFO - 2021-08-19 08:17:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:50 --> Input Class Initialized
INFO - 2021-08-19 08:17:50 --> Language Class Initialized
INFO - 2021-08-19 08:17:50 --> Language Class Initialized
INFO - 2021-08-19 08:17:50 --> Config Class Initialized
INFO - 2021-08-19 08:17:50 --> Loader Class Initialized
INFO - 2021-08-19 08:17:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:50 --> Controller Class Initialized
INFO - 2021-08-19 08:17:59 --> Config Class Initialized
INFO - 2021-08-19 08:17:59 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:59 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:59 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:59 --> URI Class Initialized
INFO - 2021-08-19 08:17:59 --> Router Class Initialized
INFO - 2021-08-19 08:17:59 --> Output Class Initialized
INFO - 2021-08-19 08:17:59 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:59 --> Input Class Initialized
INFO - 2021-08-19 08:17:59 --> Language Class Initialized
INFO - 2021-08-19 08:17:59 --> Language Class Initialized
INFO - 2021-08-19 08:17:59 --> Config Class Initialized
INFO - 2021-08-19 08:17:59 --> Loader Class Initialized
INFO - 2021-08-19 08:17:59 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:59 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:59 --> Helper loaded: form_helper
INFO - 2021-08-19 08:17:59 --> Helper loaded: my_helper
INFO - 2021-08-19 08:17:59 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:17:59 --> Controller Class Initialized
INFO - 2021-08-19 08:17:59 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:17:59 --> Config Class Initialized
INFO - 2021-08-19 08:17:59 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:17:59 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:17:59 --> Utf8 Class Initialized
INFO - 2021-08-19 08:17:59 --> URI Class Initialized
INFO - 2021-08-19 08:17:59 --> Router Class Initialized
INFO - 2021-08-19 08:17:59 --> Output Class Initialized
INFO - 2021-08-19 08:17:59 --> Security Class Initialized
DEBUG - 2021-08-19 08:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:17:59 --> Input Class Initialized
INFO - 2021-08-19 08:17:59 --> Language Class Initialized
INFO - 2021-08-19 08:17:59 --> Language Class Initialized
INFO - 2021-08-19 08:17:59 --> Config Class Initialized
INFO - 2021-08-19 08:17:59 --> Loader Class Initialized
INFO - 2021-08-19 08:17:59 --> Helper loaded: url_helper
INFO - 2021-08-19 08:17:59 --> Helper loaded: file_helper
INFO - 2021-08-19 08:17:59 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:00 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:00 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:00 --> Total execution time: 0.0438
INFO - 2021-08-19 08:18:14 --> Config Class Initialized
INFO - 2021-08-19 08:18:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:14 --> URI Class Initialized
INFO - 2021-08-19 08:18:14 --> Router Class Initialized
INFO - 2021-08-19 08:18:14 --> Output Class Initialized
INFO - 2021-08-19 08:18:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:14 --> Input Class Initialized
INFO - 2021-08-19 08:18:14 --> Language Class Initialized
INFO - 2021-08-19 08:18:14 --> Language Class Initialized
INFO - 2021-08-19 08:18:14 --> Config Class Initialized
INFO - 2021-08-19 08:18:14 --> Loader Class Initialized
INFO - 2021-08-19 08:18:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:14 --> Controller Class Initialized
INFO - 2021-08-19 08:18:14 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:18:14 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:14 --> Total execution time: 0.0623
INFO - 2021-08-19 08:18:14 --> Config Class Initialized
INFO - 2021-08-19 08:18:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:14 --> URI Class Initialized
INFO - 2021-08-19 08:18:14 --> Router Class Initialized
INFO - 2021-08-19 08:18:14 --> Output Class Initialized
INFO - 2021-08-19 08:18:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:14 --> Input Class Initialized
INFO - 2021-08-19 08:18:14 --> Language Class Initialized
INFO - 2021-08-19 08:18:14 --> Language Class Initialized
INFO - 2021-08-19 08:18:14 --> Config Class Initialized
INFO - 2021-08-19 08:18:14 --> Loader Class Initialized
INFO - 2021-08-19 08:18:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:14 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:18:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:15 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:15 --> Total execution time: 0.7369
INFO - 2021-08-19 08:18:16 --> Config Class Initialized
INFO - 2021-08-19 08:18:16 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:16 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:16 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:16 --> URI Class Initialized
INFO - 2021-08-19 08:18:16 --> Router Class Initialized
INFO - 2021-08-19 08:18:16 --> Output Class Initialized
INFO - 2021-08-19 08:18:16 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:16 --> Input Class Initialized
INFO - 2021-08-19 08:18:16 --> Language Class Initialized
INFO - 2021-08-19 08:18:16 --> Language Class Initialized
INFO - 2021-08-19 08:18:16 --> Config Class Initialized
INFO - 2021-08-19 08:18:16 --> Loader Class Initialized
INFO - 2021-08-19 08:18:16 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:16 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:16 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:16 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:16 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:16 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:16 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:16 --> Total execution time: 0.0690
INFO - 2021-08-19 08:18:19 --> Config Class Initialized
INFO - 2021-08-19 08:18:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:19 --> URI Class Initialized
INFO - 2021-08-19 08:18:19 --> Router Class Initialized
INFO - 2021-08-19 08:18:19 --> Output Class Initialized
INFO - 2021-08-19 08:18:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:19 --> Input Class Initialized
INFO - 2021-08-19 08:18:19 --> Language Class Initialized
INFO - 2021-08-19 08:18:19 --> Language Class Initialized
INFO - 2021-08-19 08:18:19 --> Config Class Initialized
INFO - 2021-08-19 08:18:19 --> Loader Class Initialized
INFO - 2021-08-19 08:18:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:19 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:19 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:19 --> Total execution time: 0.0522
INFO - 2021-08-19 08:18:19 --> Config Class Initialized
INFO - 2021-08-19 08:18:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:19 --> URI Class Initialized
INFO - 2021-08-19 08:18:19 --> Router Class Initialized
INFO - 2021-08-19 08:18:19 --> Output Class Initialized
INFO - 2021-08-19 08:18:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:19 --> Input Class Initialized
INFO - 2021-08-19 08:18:19 --> Language Class Initialized
INFO - 2021-08-19 08:18:19 --> Language Class Initialized
INFO - 2021-08-19 08:18:19 --> Config Class Initialized
INFO - 2021-08-19 08:18:19 --> Loader Class Initialized
INFO - 2021-08-19 08:18:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:19 --> Controller Class Initialized
INFO - 2021-08-19 08:18:20 --> Config Class Initialized
INFO - 2021-08-19 08:18:20 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:20 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:20 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:20 --> URI Class Initialized
INFO - 2021-08-19 08:18:20 --> Router Class Initialized
INFO - 2021-08-19 08:18:20 --> Output Class Initialized
INFO - 2021-08-19 08:18:20 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:20 --> Input Class Initialized
INFO - 2021-08-19 08:18:20 --> Language Class Initialized
INFO - 2021-08-19 08:18:20 --> Language Class Initialized
INFO - 2021-08-19 08:18:20 --> Config Class Initialized
INFO - 2021-08-19 08:18:20 --> Loader Class Initialized
INFO - 2021-08-19 08:18:20 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:20 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:20 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:20 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:20 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:20 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:20 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:20 --> Total execution time: 0.0501
INFO - 2021-08-19 08:18:23 --> Config Class Initialized
INFO - 2021-08-19 08:18:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:23 --> URI Class Initialized
INFO - 2021-08-19 08:18:23 --> Router Class Initialized
INFO - 2021-08-19 08:18:23 --> Output Class Initialized
INFO - 2021-08-19 08:18:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:23 --> Input Class Initialized
INFO - 2021-08-19 08:18:23 --> Language Class Initialized
INFO - 2021-08-19 08:18:23 --> Language Class Initialized
INFO - 2021-08-19 08:18:23 --> Config Class Initialized
INFO - 2021-08-19 08:18:23 --> Loader Class Initialized
INFO - 2021-08-19 08:18:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:23 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:23 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:23 --> Total execution time: 0.0488
INFO - 2021-08-19 08:18:23 --> Config Class Initialized
INFO - 2021-08-19 08:18:23 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:23 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:23 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:23 --> URI Class Initialized
INFO - 2021-08-19 08:18:23 --> Router Class Initialized
INFO - 2021-08-19 08:18:23 --> Output Class Initialized
INFO - 2021-08-19 08:18:23 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:23 --> Input Class Initialized
INFO - 2021-08-19 08:18:23 --> Language Class Initialized
INFO - 2021-08-19 08:18:23 --> Language Class Initialized
INFO - 2021-08-19 08:18:23 --> Config Class Initialized
INFO - 2021-08-19 08:18:23 --> Loader Class Initialized
INFO - 2021-08-19 08:18:23 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:23 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:23 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:23 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:23 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:23 --> Controller Class Initialized
INFO - 2021-08-19 08:18:24 --> Config Class Initialized
INFO - 2021-08-19 08:18:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:24 --> URI Class Initialized
INFO - 2021-08-19 08:18:24 --> Router Class Initialized
INFO - 2021-08-19 08:18:24 --> Output Class Initialized
INFO - 2021-08-19 08:18:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:24 --> Input Class Initialized
INFO - 2021-08-19 08:18:24 --> Language Class Initialized
INFO - 2021-08-19 08:18:24 --> Language Class Initialized
INFO - 2021-08-19 08:18:24 --> Config Class Initialized
INFO - 2021-08-19 08:18:24 --> Loader Class Initialized
INFO - 2021-08-19 08:18:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:24 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:18:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:24 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:24 --> Total execution time: 0.0564
INFO - 2021-08-19 08:18:26 --> Config Class Initialized
INFO - 2021-08-19 08:18:26 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:26 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:26 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:26 --> URI Class Initialized
INFO - 2021-08-19 08:18:26 --> Router Class Initialized
INFO - 2021-08-19 08:18:26 --> Output Class Initialized
INFO - 2021-08-19 08:18:26 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:26 --> Input Class Initialized
INFO - 2021-08-19 08:18:26 --> Language Class Initialized
INFO - 2021-08-19 08:18:26 --> Language Class Initialized
INFO - 2021-08-19 08:18:26 --> Config Class Initialized
INFO - 2021-08-19 08:18:26 --> Loader Class Initialized
INFO - 2021-08-19 08:18:26 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:26 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:26 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:26 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:26 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:26 --> Controller Class Initialized
INFO - 2021-08-19 08:18:27 --> Config Class Initialized
INFO - 2021-08-19 08:18:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:27 --> URI Class Initialized
INFO - 2021-08-19 08:18:27 --> Router Class Initialized
INFO - 2021-08-19 08:18:27 --> Output Class Initialized
INFO - 2021-08-19 08:18:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:27 --> Input Class Initialized
INFO - 2021-08-19 08:18:27 --> Language Class Initialized
INFO - 2021-08-19 08:18:27 --> Language Class Initialized
INFO - 2021-08-19 08:18:27 --> Config Class Initialized
INFO - 2021-08-19 08:18:27 --> Loader Class Initialized
INFO - 2021-08-19 08:18:27 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:27 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:27 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:27 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:27 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:27 --> Controller Class Initialized
INFO - 2021-08-19 08:18:29 --> Config Class Initialized
INFO - 2021-08-19 08:18:29 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:29 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:29 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:29 --> URI Class Initialized
INFO - 2021-08-19 08:18:29 --> Router Class Initialized
INFO - 2021-08-19 08:18:29 --> Output Class Initialized
INFO - 2021-08-19 08:18:29 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:29 --> Input Class Initialized
INFO - 2021-08-19 08:18:29 --> Language Class Initialized
INFO - 2021-08-19 08:18:29 --> Language Class Initialized
INFO - 2021-08-19 08:18:29 --> Config Class Initialized
INFO - 2021-08-19 08:18:29 --> Loader Class Initialized
INFO - 2021-08-19 08:18:29 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:29 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:29 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:29 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:29 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:29 --> Controller Class Initialized
INFO - 2021-08-19 08:18:32 --> Config Class Initialized
INFO - 2021-08-19 08:18:32 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:32 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:32 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:32 --> URI Class Initialized
INFO - 2021-08-19 08:18:32 --> Router Class Initialized
INFO - 2021-08-19 08:18:32 --> Output Class Initialized
INFO - 2021-08-19 08:18:32 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:32 --> Input Class Initialized
INFO - 2021-08-19 08:18:32 --> Language Class Initialized
INFO - 2021-08-19 08:18:32 --> Language Class Initialized
INFO - 2021-08-19 08:18:32 --> Config Class Initialized
INFO - 2021-08-19 08:18:32 --> Loader Class Initialized
INFO - 2021-08-19 08:18:32 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:32 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:32 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:32 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:32 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:32 --> Controller Class Initialized
INFO - 2021-08-19 08:18:37 --> Config Class Initialized
INFO - 2021-08-19 08:18:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:37 --> URI Class Initialized
INFO - 2021-08-19 08:18:37 --> Router Class Initialized
INFO - 2021-08-19 08:18:37 --> Output Class Initialized
INFO - 2021-08-19 08:18:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:37 --> Input Class Initialized
INFO - 2021-08-19 08:18:37 --> Language Class Initialized
INFO - 2021-08-19 08:18:37 --> Language Class Initialized
INFO - 2021-08-19 08:18:37 --> Config Class Initialized
INFO - 2021-08-19 08:18:37 --> Loader Class Initialized
INFO - 2021-08-19 08:18:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:37 --> Controller Class Initialized
INFO - 2021-08-19 08:18:37 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:18:37 --> Config Class Initialized
INFO - 2021-08-19 08:18:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:37 --> URI Class Initialized
INFO - 2021-08-19 08:18:37 --> Router Class Initialized
INFO - 2021-08-19 08:18:37 --> Output Class Initialized
INFO - 2021-08-19 08:18:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:37 --> Input Class Initialized
INFO - 2021-08-19 08:18:37 --> Language Class Initialized
INFO - 2021-08-19 08:18:37 --> Language Class Initialized
INFO - 2021-08-19 08:18:37 --> Config Class Initialized
INFO - 2021-08-19 08:18:37 --> Loader Class Initialized
INFO - 2021-08-19 08:18:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:37 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:37 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:37 --> Total execution time: 0.0543
INFO - 2021-08-19 08:18:47 --> Config Class Initialized
INFO - 2021-08-19 08:18:47 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:47 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:47 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:47 --> URI Class Initialized
INFO - 2021-08-19 08:18:47 --> Router Class Initialized
INFO - 2021-08-19 08:18:47 --> Output Class Initialized
INFO - 2021-08-19 08:18:47 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:47 --> Input Class Initialized
INFO - 2021-08-19 08:18:47 --> Language Class Initialized
INFO - 2021-08-19 08:18:47 --> Language Class Initialized
INFO - 2021-08-19 08:18:47 --> Config Class Initialized
INFO - 2021-08-19 08:18:47 --> Loader Class Initialized
INFO - 2021-08-19 08:18:47 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:47 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:47 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:47 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:47 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:47 --> Controller Class Initialized
INFO - 2021-08-19 08:18:47 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:18:47 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:47 --> Total execution time: 0.0625
INFO - 2021-08-19 08:18:48 --> Config Class Initialized
INFO - 2021-08-19 08:18:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:48 --> URI Class Initialized
INFO - 2021-08-19 08:18:48 --> Router Class Initialized
INFO - 2021-08-19 08:18:48 --> Output Class Initialized
INFO - 2021-08-19 08:18:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:48 --> Input Class Initialized
INFO - 2021-08-19 08:18:48 --> Language Class Initialized
INFO - 2021-08-19 08:18:48 --> Language Class Initialized
INFO - 2021-08-19 08:18:48 --> Config Class Initialized
INFO - 2021-08-19 08:18:48 --> Loader Class Initialized
INFO - 2021-08-19 08:18:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:48 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:18:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:49 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:49 --> Total execution time: 0.7331
INFO - 2021-08-19 08:18:57 --> Config Class Initialized
INFO - 2021-08-19 08:18:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:18:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:18:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:18:57 --> URI Class Initialized
INFO - 2021-08-19 08:18:57 --> Router Class Initialized
INFO - 2021-08-19 08:18:57 --> Output Class Initialized
INFO - 2021-08-19 08:18:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:18:57 --> Input Class Initialized
INFO - 2021-08-19 08:18:57 --> Language Class Initialized
INFO - 2021-08-19 08:18:57 --> Language Class Initialized
INFO - 2021-08-19 08:18:57 --> Config Class Initialized
INFO - 2021-08-19 08:18:57 --> Loader Class Initialized
INFO - 2021-08-19 08:18:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:18:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:18:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:18:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:18:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:18:58 --> Controller Class Initialized
DEBUG - 2021-08-19 08:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:18:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:18:58 --> Final output sent to browser
DEBUG - 2021-08-19 08:18:58 --> Total execution time: 0.0664
INFO - 2021-08-19 08:19:07 --> Config Class Initialized
INFO - 2021-08-19 08:19:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:07 --> URI Class Initialized
INFO - 2021-08-19 08:19:07 --> Router Class Initialized
INFO - 2021-08-19 08:19:07 --> Output Class Initialized
INFO - 2021-08-19 08:19:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:07 --> Input Class Initialized
INFO - 2021-08-19 08:19:07 --> Language Class Initialized
INFO - 2021-08-19 08:19:07 --> Language Class Initialized
INFO - 2021-08-19 08:19:07 --> Config Class Initialized
INFO - 2021-08-19 08:19:07 --> Loader Class Initialized
INFO - 2021-08-19 08:19:07 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:07 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:07 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:07 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:07 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:07 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:07 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:07 --> Total execution time: 0.0519
INFO - 2021-08-19 08:19:07 --> Config Class Initialized
INFO - 2021-08-19 08:19:07 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:07 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:07 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:07 --> URI Class Initialized
INFO - 2021-08-19 08:19:07 --> Router Class Initialized
INFO - 2021-08-19 08:19:07 --> Output Class Initialized
INFO - 2021-08-19 08:19:07 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:07 --> Input Class Initialized
INFO - 2021-08-19 08:19:07 --> Language Class Initialized
INFO - 2021-08-19 08:19:08 --> Language Class Initialized
INFO - 2021-08-19 08:19:08 --> Config Class Initialized
INFO - 2021-08-19 08:19:08 --> Loader Class Initialized
INFO - 2021-08-19 08:19:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:08 --> Controller Class Initialized
INFO - 2021-08-19 08:19:09 --> Config Class Initialized
INFO - 2021-08-19 08:19:09 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:09 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:09 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:09 --> URI Class Initialized
INFO - 2021-08-19 08:19:09 --> Router Class Initialized
INFO - 2021-08-19 08:19:09 --> Output Class Initialized
INFO - 2021-08-19 08:19:09 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:09 --> Input Class Initialized
INFO - 2021-08-19 08:19:09 --> Language Class Initialized
INFO - 2021-08-19 08:19:09 --> Language Class Initialized
INFO - 2021-08-19 08:19:09 --> Config Class Initialized
INFO - 2021-08-19 08:19:09 --> Loader Class Initialized
INFO - 2021-08-19 08:19:09 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:09 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:09 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:09 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:09 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:09 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:09 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:09 --> Total execution time: 0.0519
INFO - 2021-08-19 08:19:10 --> Config Class Initialized
INFO - 2021-08-19 08:19:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:10 --> URI Class Initialized
INFO - 2021-08-19 08:19:10 --> Router Class Initialized
INFO - 2021-08-19 08:19:10 --> Output Class Initialized
INFO - 2021-08-19 08:19:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:10 --> Input Class Initialized
INFO - 2021-08-19 08:19:10 --> Language Class Initialized
INFO - 2021-08-19 08:19:10 --> Language Class Initialized
INFO - 2021-08-19 08:19:10 --> Config Class Initialized
INFO - 2021-08-19 08:19:10 --> Loader Class Initialized
INFO - 2021-08-19 08:19:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:10 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:10 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:10 --> Total execution time: 0.0508
INFO - 2021-08-19 08:19:10 --> Config Class Initialized
INFO - 2021-08-19 08:19:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:10 --> URI Class Initialized
INFO - 2021-08-19 08:19:10 --> Router Class Initialized
INFO - 2021-08-19 08:19:10 --> Output Class Initialized
INFO - 2021-08-19 08:19:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:10 --> Input Class Initialized
INFO - 2021-08-19 08:19:10 --> Language Class Initialized
INFO - 2021-08-19 08:19:10 --> Language Class Initialized
INFO - 2021-08-19 08:19:10 --> Config Class Initialized
INFO - 2021-08-19 08:19:10 --> Loader Class Initialized
INFO - 2021-08-19 08:19:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:10 --> Controller Class Initialized
INFO - 2021-08-19 08:19:12 --> Config Class Initialized
INFO - 2021-08-19 08:19:12 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:12 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:12 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:12 --> URI Class Initialized
INFO - 2021-08-19 08:19:12 --> Router Class Initialized
INFO - 2021-08-19 08:19:12 --> Output Class Initialized
INFO - 2021-08-19 08:19:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:12 --> Input Class Initialized
INFO - 2021-08-19 08:19:12 --> Language Class Initialized
INFO - 2021-08-19 08:19:12 --> Language Class Initialized
INFO - 2021-08-19 08:19:12 --> Config Class Initialized
INFO - 2021-08-19 08:19:12 --> Loader Class Initialized
INFO - 2021-08-19 08:19:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:12 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:12 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:12 --> Total execution time: 0.0487
INFO - 2021-08-19 08:19:15 --> Config Class Initialized
INFO - 2021-08-19 08:19:15 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:15 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:15 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:15 --> URI Class Initialized
INFO - 2021-08-19 08:19:15 --> Router Class Initialized
INFO - 2021-08-19 08:19:15 --> Output Class Initialized
INFO - 2021-08-19 08:19:15 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:15 --> Input Class Initialized
INFO - 2021-08-19 08:19:15 --> Language Class Initialized
INFO - 2021-08-19 08:19:15 --> Language Class Initialized
INFO - 2021-08-19 08:19:15 --> Config Class Initialized
INFO - 2021-08-19 08:19:15 --> Loader Class Initialized
INFO - 2021-08-19 08:19:15 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:15 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:15 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:15 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:15 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:15 --> Controller Class Initialized
INFO - 2021-08-19 08:19:18 --> Config Class Initialized
INFO - 2021-08-19 08:19:18 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:18 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:18 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:18 --> URI Class Initialized
INFO - 2021-08-19 08:19:18 --> Router Class Initialized
INFO - 2021-08-19 08:19:18 --> Output Class Initialized
INFO - 2021-08-19 08:19:18 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:18 --> Input Class Initialized
INFO - 2021-08-19 08:19:18 --> Language Class Initialized
INFO - 2021-08-19 08:19:18 --> Language Class Initialized
INFO - 2021-08-19 08:19:18 --> Config Class Initialized
INFO - 2021-08-19 08:19:18 --> Loader Class Initialized
INFO - 2021-08-19 08:19:18 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:18 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:18 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:18 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:18 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:18 --> Controller Class Initialized
INFO - 2021-08-19 08:19:19 --> Config Class Initialized
INFO - 2021-08-19 08:19:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:19 --> URI Class Initialized
INFO - 2021-08-19 08:19:19 --> Router Class Initialized
INFO - 2021-08-19 08:19:19 --> Output Class Initialized
INFO - 2021-08-19 08:19:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:19 --> Input Class Initialized
INFO - 2021-08-19 08:19:19 --> Language Class Initialized
INFO - 2021-08-19 08:19:19 --> Language Class Initialized
INFO - 2021-08-19 08:19:19 --> Config Class Initialized
INFO - 2021-08-19 08:19:19 --> Loader Class Initialized
INFO - 2021-08-19 08:19:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:19 --> Controller Class Initialized
INFO - 2021-08-19 08:19:22 --> Config Class Initialized
INFO - 2021-08-19 08:19:22 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:22 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:22 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:22 --> URI Class Initialized
INFO - 2021-08-19 08:19:22 --> Router Class Initialized
INFO - 2021-08-19 08:19:22 --> Output Class Initialized
INFO - 2021-08-19 08:19:22 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:22 --> Input Class Initialized
INFO - 2021-08-19 08:19:22 --> Language Class Initialized
INFO - 2021-08-19 08:19:22 --> Language Class Initialized
INFO - 2021-08-19 08:19:22 --> Config Class Initialized
INFO - 2021-08-19 08:19:22 --> Loader Class Initialized
INFO - 2021-08-19 08:19:22 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:22 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:22 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:22 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:22 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:22 --> Controller Class Initialized
INFO - 2021-08-19 08:19:28 --> Config Class Initialized
INFO - 2021-08-19 08:19:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:28 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:28 --> URI Class Initialized
INFO - 2021-08-19 08:19:28 --> Router Class Initialized
INFO - 2021-08-19 08:19:28 --> Output Class Initialized
INFO - 2021-08-19 08:19:28 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:28 --> Input Class Initialized
INFO - 2021-08-19 08:19:28 --> Language Class Initialized
INFO - 2021-08-19 08:19:28 --> Language Class Initialized
INFO - 2021-08-19 08:19:28 --> Config Class Initialized
INFO - 2021-08-19 08:19:28 --> Loader Class Initialized
INFO - 2021-08-19 08:19:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:28 --> Controller Class Initialized
INFO - 2021-08-19 08:19:28 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:19:28 --> Config Class Initialized
INFO - 2021-08-19 08:19:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:28 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:28 --> URI Class Initialized
INFO - 2021-08-19 08:19:28 --> Router Class Initialized
INFO - 2021-08-19 08:19:28 --> Output Class Initialized
INFO - 2021-08-19 08:19:28 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:28 --> Input Class Initialized
INFO - 2021-08-19 08:19:28 --> Language Class Initialized
INFO - 2021-08-19 08:19:28 --> Language Class Initialized
INFO - 2021-08-19 08:19:28 --> Config Class Initialized
INFO - 2021-08-19 08:19:28 --> Loader Class Initialized
INFO - 2021-08-19 08:19:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:28 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:19:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:28 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:28 --> Total execution time: 0.0532
INFO - 2021-08-19 08:19:34 --> Config Class Initialized
INFO - 2021-08-19 08:19:34 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:34 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:34 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:34 --> URI Class Initialized
INFO - 2021-08-19 08:19:34 --> Router Class Initialized
INFO - 2021-08-19 08:19:34 --> Output Class Initialized
INFO - 2021-08-19 08:19:34 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:34 --> Input Class Initialized
INFO - 2021-08-19 08:19:34 --> Language Class Initialized
INFO - 2021-08-19 08:19:34 --> Language Class Initialized
INFO - 2021-08-19 08:19:34 --> Config Class Initialized
INFO - 2021-08-19 08:19:34 --> Loader Class Initialized
INFO - 2021-08-19 08:19:34 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:34 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:34 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:34 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:34 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:34 --> Controller Class Initialized
INFO - 2021-08-19 08:19:34 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:19:34 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:34 --> Total execution time: 0.0488
INFO - 2021-08-19 08:19:35 --> Config Class Initialized
INFO - 2021-08-19 08:19:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:35 --> URI Class Initialized
INFO - 2021-08-19 08:19:35 --> Router Class Initialized
INFO - 2021-08-19 08:19:35 --> Output Class Initialized
INFO - 2021-08-19 08:19:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:35 --> Input Class Initialized
INFO - 2021-08-19 08:19:35 --> Language Class Initialized
INFO - 2021-08-19 08:19:35 --> Language Class Initialized
INFO - 2021-08-19 08:19:35 --> Config Class Initialized
INFO - 2021-08-19 08:19:35 --> Loader Class Initialized
INFO - 2021-08-19 08:19:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:35 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:35 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:35 --> Total execution time: 0.7342
INFO - 2021-08-19 08:19:37 --> Config Class Initialized
INFO - 2021-08-19 08:19:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:37 --> URI Class Initialized
INFO - 2021-08-19 08:19:37 --> Router Class Initialized
INFO - 2021-08-19 08:19:37 --> Output Class Initialized
INFO - 2021-08-19 08:19:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:37 --> Input Class Initialized
INFO - 2021-08-19 08:19:37 --> Language Class Initialized
INFO - 2021-08-19 08:19:38 --> Language Class Initialized
INFO - 2021-08-19 08:19:38 --> Config Class Initialized
INFO - 2021-08-19 08:19:38 --> Loader Class Initialized
INFO - 2021-08-19 08:19:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:38 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:19:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:38 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:38 --> Total execution time: 0.0657
INFO - 2021-08-19 08:19:41 --> Config Class Initialized
INFO - 2021-08-19 08:19:41 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:41 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:41 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:41 --> URI Class Initialized
INFO - 2021-08-19 08:19:41 --> Router Class Initialized
INFO - 2021-08-19 08:19:41 --> Output Class Initialized
INFO - 2021-08-19 08:19:41 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:41 --> Input Class Initialized
INFO - 2021-08-19 08:19:41 --> Language Class Initialized
INFO - 2021-08-19 08:19:41 --> Language Class Initialized
INFO - 2021-08-19 08:19:41 --> Config Class Initialized
INFO - 2021-08-19 08:19:41 --> Loader Class Initialized
INFO - 2021-08-19 08:19:41 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:41 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:41 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:41 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:41 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:41 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:19:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:41 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:41 --> Total execution time: 0.0548
INFO - 2021-08-19 08:19:42 --> Config Class Initialized
INFO - 2021-08-19 08:19:42 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:42 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:42 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:42 --> URI Class Initialized
INFO - 2021-08-19 08:19:42 --> Router Class Initialized
INFO - 2021-08-19 08:19:42 --> Output Class Initialized
INFO - 2021-08-19 08:19:42 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:42 --> Input Class Initialized
INFO - 2021-08-19 08:19:42 --> Language Class Initialized
INFO - 2021-08-19 08:19:42 --> Language Class Initialized
INFO - 2021-08-19 08:19:42 --> Config Class Initialized
INFO - 2021-08-19 08:19:42 --> Loader Class Initialized
INFO - 2021-08-19 08:19:42 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:42 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:42 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:42 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:42 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:42 --> Controller Class Initialized
INFO - 2021-08-19 08:19:43 --> Config Class Initialized
INFO - 2021-08-19 08:19:43 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:43 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:43 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:43 --> URI Class Initialized
INFO - 2021-08-19 08:19:43 --> Router Class Initialized
INFO - 2021-08-19 08:19:43 --> Output Class Initialized
INFO - 2021-08-19 08:19:43 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:43 --> Input Class Initialized
INFO - 2021-08-19 08:19:43 --> Language Class Initialized
INFO - 2021-08-19 08:19:43 --> Language Class Initialized
INFO - 2021-08-19 08:19:43 --> Config Class Initialized
INFO - 2021-08-19 08:19:43 --> Loader Class Initialized
INFO - 2021-08-19 08:19:43 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:43 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:43 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:43 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:43 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:43 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:43 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:43 --> Total execution time: 0.0498
INFO - 2021-08-19 08:19:46 --> Config Class Initialized
INFO - 2021-08-19 08:19:46 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:46 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:46 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:46 --> URI Class Initialized
INFO - 2021-08-19 08:19:46 --> Router Class Initialized
INFO - 2021-08-19 08:19:46 --> Output Class Initialized
INFO - 2021-08-19 08:19:46 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:46 --> Input Class Initialized
INFO - 2021-08-19 08:19:46 --> Language Class Initialized
INFO - 2021-08-19 08:19:46 --> Language Class Initialized
INFO - 2021-08-19 08:19:46 --> Config Class Initialized
INFO - 2021-08-19 08:19:46 --> Loader Class Initialized
INFO - 2021-08-19 08:19:46 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:46 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:46 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:46 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:46 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:46 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:46 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:46 --> Total execution time: 0.0504
INFO - 2021-08-19 08:19:46 --> Config Class Initialized
INFO - 2021-08-19 08:19:46 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:46 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:46 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:46 --> URI Class Initialized
INFO - 2021-08-19 08:19:46 --> Router Class Initialized
INFO - 2021-08-19 08:19:46 --> Output Class Initialized
INFO - 2021-08-19 08:19:46 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:46 --> Input Class Initialized
INFO - 2021-08-19 08:19:46 --> Language Class Initialized
INFO - 2021-08-19 08:19:46 --> Language Class Initialized
INFO - 2021-08-19 08:19:46 --> Config Class Initialized
INFO - 2021-08-19 08:19:46 --> Loader Class Initialized
INFO - 2021-08-19 08:19:46 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:46 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:46 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:46 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:46 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:46 --> Controller Class Initialized
INFO - 2021-08-19 08:19:47 --> Config Class Initialized
INFO - 2021-08-19 08:19:47 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:47 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:47 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:47 --> URI Class Initialized
INFO - 2021-08-19 08:19:47 --> Router Class Initialized
INFO - 2021-08-19 08:19:47 --> Output Class Initialized
INFO - 2021-08-19 08:19:47 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:47 --> Input Class Initialized
INFO - 2021-08-19 08:19:47 --> Language Class Initialized
INFO - 2021-08-19 08:19:47 --> Language Class Initialized
INFO - 2021-08-19 08:19:47 --> Config Class Initialized
INFO - 2021-08-19 08:19:47 --> Loader Class Initialized
INFO - 2021-08-19 08:19:47 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:47 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:47 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:47 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:47 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:47 --> Controller Class Initialized
DEBUG - 2021-08-19 08:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:19:47 --> Final output sent to browser
DEBUG - 2021-08-19 08:19:47 --> Total execution time: 0.0510
INFO - 2021-08-19 08:19:50 --> Config Class Initialized
INFO - 2021-08-19 08:19:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:50 --> URI Class Initialized
INFO - 2021-08-19 08:19:50 --> Router Class Initialized
INFO - 2021-08-19 08:19:50 --> Output Class Initialized
INFO - 2021-08-19 08:19:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:50 --> Input Class Initialized
INFO - 2021-08-19 08:19:50 --> Language Class Initialized
INFO - 2021-08-19 08:19:50 --> Language Class Initialized
INFO - 2021-08-19 08:19:50 --> Config Class Initialized
INFO - 2021-08-19 08:19:50 --> Loader Class Initialized
INFO - 2021-08-19 08:19:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:50 --> Controller Class Initialized
INFO - 2021-08-19 08:19:52 --> Config Class Initialized
INFO - 2021-08-19 08:19:52 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:52 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:52 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:52 --> URI Class Initialized
INFO - 2021-08-19 08:19:52 --> Router Class Initialized
INFO - 2021-08-19 08:19:52 --> Output Class Initialized
INFO - 2021-08-19 08:19:52 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:52 --> Input Class Initialized
INFO - 2021-08-19 08:19:52 --> Language Class Initialized
INFO - 2021-08-19 08:19:52 --> Language Class Initialized
INFO - 2021-08-19 08:19:52 --> Config Class Initialized
INFO - 2021-08-19 08:19:52 --> Loader Class Initialized
INFO - 2021-08-19 08:19:52 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:52 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:52 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:52 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:52 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:52 --> Controller Class Initialized
INFO - 2021-08-19 08:19:54 --> Config Class Initialized
INFO - 2021-08-19 08:19:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:54 --> URI Class Initialized
INFO - 2021-08-19 08:19:54 --> Router Class Initialized
INFO - 2021-08-19 08:19:54 --> Output Class Initialized
INFO - 2021-08-19 08:19:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:54 --> Input Class Initialized
INFO - 2021-08-19 08:19:54 --> Language Class Initialized
INFO - 2021-08-19 08:19:54 --> Language Class Initialized
INFO - 2021-08-19 08:19:54 --> Config Class Initialized
INFO - 2021-08-19 08:19:54 --> Loader Class Initialized
INFO - 2021-08-19 08:19:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:54 --> Controller Class Initialized
INFO - 2021-08-19 08:19:57 --> Config Class Initialized
INFO - 2021-08-19 08:19:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:19:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:19:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:19:57 --> URI Class Initialized
INFO - 2021-08-19 08:19:57 --> Router Class Initialized
INFO - 2021-08-19 08:19:57 --> Output Class Initialized
INFO - 2021-08-19 08:19:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:19:57 --> Input Class Initialized
INFO - 2021-08-19 08:19:57 --> Language Class Initialized
INFO - 2021-08-19 08:19:57 --> Language Class Initialized
INFO - 2021-08-19 08:19:57 --> Config Class Initialized
INFO - 2021-08-19 08:19:57 --> Loader Class Initialized
INFO - 2021-08-19 08:19:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:19:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:19:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:19:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:19:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:19:57 --> Controller Class Initialized
INFO - 2021-08-19 08:20:04 --> Config Class Initialized
INFO - 2021-08-19 08:20:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:04 --> URI Class Initialized
INFO - 2021-08-19 08:20:04 --> Router Class Initialized
INFO - 2021-08-19 08:20:04 --> Output Class Initialized
INFO - 2021-08-19 08:20:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:04 --> Input Class Initialized
INFO - 2021-08-19 08:20:04 --> Language Class Initialized
INFO - 2021-08-19 08:20:04 --> Language Class Initialized
INFO - 2021-08-19 08:20:04 --> Config Class Initialized
INFO - 2021-08-19 08:20:04 --> Loader Class Initialized
INFO - 2021-08-19 08:20:04 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:04 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:04 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:04 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:04 --> Controller Class Initialized
INFO - 2021-08-19 08:20:04 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:20:04 --> Config Class Initialized
INFO - 2021-08-19 08:20:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:04 --> URI Class Initialized
INFO - 2021-08-19 08:20:04 --> Router Class Initialized
INFO - 2021-08-19 08:20:04 --> Output Class Initialized
INFO - 2021-08-19 08:20:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:04 --> Input Class Initialized
INFO - 2021-08-19 08:20:04 --> Language Class Initialized
INFO - 2021-08-19 08:20:04 --> Language Class Initialized
INFO - 2021-08-19 08:20:04 --> Config Class Initialized
INFO - 2021-08-19 08:20:04 --> Loader Class Initialized
INFO - 2021-08-19 08:20:04 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:04 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:04 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:04 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:04 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:04 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:04 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:04 --> Total execution time: 0.0432
INFO - 2021-08-19 08:20:13 --> Config Class Initialized
INFO - 2021-08-19 08:20:13 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:13 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:13 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:13 --> URI Class Initialized
INFO - 2021-08-19 08:20:13 --> Router Class Initialized
INFO - 2021-08-19 08:20:13 --> Output Class Initialized
INFO - 2021-08-19 08:20:13 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:13 --> Input Class Initialized
INFO - 2021-08-19 08:20:13 --> Language Class Initialized
INFO - 2021-08-19 08:20:13 --> Language Class Initialized
INFO - 2021-08-19 08:20:13 --> Config Class Initialized
INFO - 2021-08-19 08:20:13 --> Loader Class Initialized
INFO - 2021-08-19 08:20:13 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:13 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:13 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:13 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:13 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:13 --> Controller Class Initialized
INFO - 2021-08-19 08:20:13 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:20:13 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:13 --> Total execution time: 0.0572
INFO - 2021-08-19 08:20:14 --> Config Class Initialized
INFO - 2021-08-19 08:20:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:14 --> URI Class Initialized
INFO - 2021-08-19 08:20:14 --> Router Class Initialized
INFO - 2021-08-19 08:20:14 --> Output Class Initialized
INFO - 2021-08-19 08:20:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:14 --> Input Class Initialized
INFO - 2021-08-19 08:20:14 --> Language Class Initialized
INFO - 2021-08-19 08:20:14 --> Language Class Initialized
INFO - 2021-08-19 08:20:14 --> Config Class Initialized
INFO - 2021-08-19 08:20:14 --> Loader Class Initialized
INFO - 2021-08-19 08:20:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:14 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:20:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:14 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:14 --> Total execution time: 0.7393
INFO - 2021-08-19 08:20:15 --> Config Class Initialized
INFO - 2021-08-19 08:20:15 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:15 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:15 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:15 --> URI Class Initialized
INFO - 2021-08-19 08:20:15 --> Router Class Initialized
INFO - 2021-08-19 08:20:15 --> Output Class Initialized
INFO - 2021-08-19 08:20:15 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:15 --> Input Class Initialized
INFO - 2021-08-19 08:20:15 --> Language Class Initialized
INFO - 2021-08-19 08:20:15 --> Language Class Initialized
INFO - 2021-08-19 08:20:15 --> Config Class Initialized
INFO - 2021-08-19 08:20:15 --> Loader Class Initialized
INFO - 2021-08-19 08:20:15 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:15 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:15 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:15 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:15 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:15 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:15 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:15 --> Total execution time: 0.0667
INFO - 2021-08-19 08:20:18 --> Config Class Initialized
INFO - 2021-08-19 08:20:18 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:18 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:18 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:18 --> URI Class Initialized
INFO - 2021-08-19 08:20:18 --> Router Class Initialized
INFO - 2021-08-19 08:20:18 --> Output Class Initialized
INFO - 2021-08-19 08:20:18 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:18 --> Input Class Initialized
INFO - 2021-08-19 08:20:18 --> Language Class Initialized
INFO - 2021-08-19 08:20:18 --> Language Class Initialized
INFO - 2021-08-19 08:20:18 --> Config Class Initialized
INFO - 2021-08-19 08:20:18 --> Loader Class Initialized
INFO - 2021-08-19 08:20:18 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:18 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:18 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:18 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:18 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:18 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:20:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:18 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:18 --> Total execution time: 0.0507
INFO - 2021-08-19 08:20:18 --> Config Class Initialized
INFO - 2021-08-19 08:20:18 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:18 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:18 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:18 --> URI Class Initialized
INFO - 2021-08-19 08:20:18 --> Router Class Initialized
INFO - 2021-08-19 08:20:18 --> Output Class Initialized
INFO - 2021-08-19 08:20:18 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:18 --> Input Class Initialized
INFO - 2021-08-19 08:20:18 --> Language Class Initialized
INFO - 2021-08-19 08:20:18 --> Language Class Initialized
INFO - 2021-08-19 08:20:18 --> Config Class Initialized
INFO - 2021-08-19 08:20:18 --> Loader Class Initialized
INFO - 2021-08-19 08:20:18 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:18 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:18 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:18 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:18 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:18 --> Controller Class Initialized
INFO - 2021-08-19 08:20:19 --> Config Class Initialized
INFO - 2021-08-19 08:20:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:19 --> URI Class Initialized
INFO - 2021-08-19 08:20:19 --> Router Class Initialized
INFO - 2021-08-19 08:20:19 --> Output Class Initialized
INFO - 2021-08-19 08:20:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:19 --> Input Class Initialized
INFO - 2021-08-19 08:20:19 --> Language Class Initialized
INFO - 2021-08-19 08:20:19 --> Language Class Initialized
INFO - 2021-08-19 08:20:19 --> Config Class Initialized
INFO - 2021-08-19 08:20:19 --> Loader Class Initialized
INFO - 2021-08-19 08:20:20 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:20 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:20 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:20 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:20 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:20 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:20 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:20 --> Total execution time: 0.0506
INFO - 2021-08-19 08:20:21 --> Config Class Initialized
INFO - 2021-08-19 08:20:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:21 --> URI Class Initialized
INFO - 2021-08-19 08:20:21 --> Router Class Initialized
INFO - 2021-08-19 08:20:21 --> Output Class Initialized
INFO - 2021-08-19 08:20:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:21 --> Input Class Initialized
INFO - 2021-08-19 08:20:21 --> Language Class Initialized
INFO - 2021-08-19 08:20:21 --> Language Class Initialized
INFO - 2021-08-19 08:20:21 --> Config Class Initialized
INFO - 2021-08-19 08:20:21 --> Loader Class Initialized
INFO - 2021-08-19 08:20:21 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:21 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:21 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:21 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:21 --> Controller Class Initialized
INFO - 2021-08-19 08:20:24 --> Config Class Initialized
INFO - 2021-08-19 08:20:24 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:24 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:24 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:24 --> URI Class Initialized
INFO - 2021-08-19 08:20:24 --> Router Class Initialized
INFO - 2021-08-19 08:20:24 --> Output Class Initialized
INFO - 2021-08-19 08:20:24 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:24 --> Input Class Initialized
INFO - 2021-08-19 08:20:24 --> Language Class Initialized
INFO - 2021-08-19 08:20:24 --> Language Class Initialized
INFO - 2021-08-19 08:20:24 --> Config Class Initialized
INFO - 2021-08-19 08:20:24 --> Loader Class Initialized
INFO - 2021-08-19 08:20:24 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:24 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:24 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:24 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:24 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:24 --> Controller Class Initialized
INFO - 2021-08-19 08:20:27 --> Config Class Initialized
INFO - 2021-08-19 08:20:27 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:27 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:27 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:27 --> URI Class Initialized
INFO - 2021-08-19 08:20:27 --> Router Class Initialized
INFO - 2021-08-19 08:20:27 --> Output Class Initialized
INFO - 2021-08-19 08:20:27 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:27 --> Input Class Initialized
INFO - 2021-08-19 08:20:27 --> Language Class Initialized
INFO - 2021-08-19 08:20:27 --> Language Class Initialized
INFO - 2021-08-19 08:20:27 --> Config Class Initialized
INFO - 2021-08-19 08:20:27 --> Loader Class Initialized
INFO - 2021-08-19 08:20:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:28 --> Controller Class Initialized
INFO - 2021-08-19 08:20:28 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:20:28 --> Config Class Initialized
INFO - 2021-08-19 08:20:28 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:28 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:28 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:28 --> URI Class Initialized
INFO - 2021-08-19 08:20:28 --> Router Class Initialized
INFO - 2021-08-19 08:20:28 --> Output Class Initialized
INFO - 2021-08-19 08:20:28 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:28 --> Input Class Initialized
INFO - 2021-08-19 08:20:28 --> Language Class Initialized
INFO - 2021-08-19 08:20:28 --> Language Class Initialized
INFO - 2021-08-19 08:20:28 --> Config Class Initialized
INFO - 2021-08-19 08:20:28 --> Loader Class Initialized
INFO - 2021-08-19 08:20:28 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:28 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:28 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:28 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:28 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:28 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:28 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:28 --> Total execution time: 0.0533
INFO - 2021-08-19 08:20:38 --> Config Class Initialized
INFO - 2021-08-19 08:20:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:38 --> URI Class Initialized
INFO - 2021-08-19 08:20:38 --> Router Class Initialized
INFO - 2021-08-19 08:20:38 --> Output Class Initialized
INFO - 2021-08-19 08:20:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:38 --> Input Class Initialized
INFO - 2021-08-19 08:20:38 --> Language Class Initialized
INFO - 2021-08-19 08:20:38 --> Language Class Initialized
INFO - 2021-08-19 08:20:38 --> Config Class Initialized
INFO - 2021-08-19 08:20:38 --> Loader Class Initialized
INFO - 2021-08-19 08:20:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:38 --> Controller Class Initialized
INFO - 2021-08-19 08:20:38 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:20:38 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:38 --> Total execution time: 0.0693
INFO - 2021-08-19 08:20:38 --> Config Class Initialized
INFO - 2021-08-19 08:20:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:38 --> URI Class Initialized
INFO - 2021-08-19 08:20:38 --> Router Class Initialized
INFO - 2021-08-19 08:20:38 --> Output Class Initialized
INFO - 2021-08-19 08:20:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:38 --> Input Class Initialized
INFO - 2021-08-19 08:20:38 --> Language Class Initialized
INFO - 2021-08-19 08:20:38 --> Language Class Initialized
INFO - 2021-08-19 08:20:38 --> Config Class Initialized
INFO - 2021-08-19 08:20:38 --> Loader Class Initialized
INFO - 2021-08-19 08:20:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:38 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:20:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:39 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:39 --> Total execution time: 0.7257
INFO - 2021-08-19 08:20:40 --> Config Class Initialized
INFO - 2021-08-19 08:20:40 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:40 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:40 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:40 --> URI Class Initialized
INFO - 2021-08-19 08:20:40 --> Router Class Initialized
INFO - 2021-08-19 08:20:40 --> Output Class Initialized
INFO - 2021-08-19 08:20:40 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:40 --> Input Class Initialized
INFO - 2021-08-19 08:20:40 --> Language Class Initialized
INFO - 2021-08-19 08:20:40 --> Language Class Initialized
INFO - 2021-08-19 08:20:40 --> Config Class Initialized
INFO - 2021-08-19 08:20:40 --> Loader Class Initialized
INFO - 2021-08-19 08:20:40 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:40 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:40 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:40 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:40 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:40 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:20:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:40 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:40 --> Total execution time: 0.0742
INFO - 2021-08-19 08:20:44 --> Config Class Initialized
INFO - 2021-08-19 08:20:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:44 --> URI Class Initialized
INFO - 2021-08-19 08:20:44 --> Router Class Initialized
INFO - 2021-08-19 08:20:44 --> Output Class Initialized
INFO - 2021-08-19 08:20:44 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:44 --> Input Class Initialized
INFO - 2021-08-19 08:20:44 --> Language Class Initialized
INFO - 2021-08-19 08:20:44 --> Language Class Initialized
INFO - 2021-08-19 08:20:44 --> Config Class Initialized
INFO - 2021-08-19 08:20:44 --> Loader Class Initialized
INFO - 2021-08-19 08:20:44 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:44 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:44 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:44 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:44 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:20:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:44 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:44 --> Total execution time: 0.0533
INFO - 2021-08-19 08:20:44 --> Config Class Initialized
INFO - 2021-08-19 08:20:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:44 --> URI Class Initialized
INFO - 2021-08-19 08:20:44 --> Router Class Initialized
INFO - 2021-08-19 08:20:44 --> Output Class Initialized
INFO - 2021-08-19 08:20:44 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:44 --> Input Class Initialized
INFO - 2021-08-19 08:20:44 --> Language Class Initialized
INFO - 2021-08-19 08:20:44 --> Language Class Initialized
INFO - 2021-08-19 08:20:44 --> Config Class Initialized
INFO - 2021-08-19 08:20:44 --> Loader Class Initialized
INFO - 2021-08-19 08:20:44 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:44 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:44 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:44 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:44 --> Controller Class Initialized
INFO - 2021-08-19 08:20:46 --> Config Class Initialized
INFO - 2021-08-19 08:20:46 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:46 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:46 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:46 --> URI Class Initialized
INFO - 2021-08-19 08:20:46 --> Router Class Initialized
INFO - 2021-08-19 08:20:46 --> Output Class Initialized
INFO - 2021-08-19 08:20:46 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:46 --> Input Class Initialized
INFO - 2021-08-19 08:20:46 --> Language Class Initialized
INFO - 2021-08-19 08:20:46 --> Language Class Initialized
INFO - 2021-08-19 08:20:46 --> Config Class Initialized
INFO - 2021-08-19 08:20:46 --> Loader Class Initialized
INFO - 2021-08-19 08:20:46 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:46 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:46 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:46 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:46 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:46 --> Controller Class Initialized
DEBUG - 2021-08-19 08:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:20:46 --> Final output sent to browser
DEBUG - 2021-08-19 08:20:46 --> Total execution time: 0.0500
INFO - 2021-08-19 08:20:48 --> Config Class Initialized
INFO - 2021-08-19 08:20:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:48 --> URI Class Initialized
INFO - 2021-08-19 08:20:48 --> Router Class Initialized
INFO - 2021-08-19 08:20:48 --> Output Class Initialized
INFO - 2021-08-19 08:20:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:48 --> Input Class Initialized
INFO - 2021-08-19 08:20:48 --> Language Class Initialized
INFO - 2021-08-19 08:20:48 --> Language Class Initialized
INFO - 2021-08-19 08:20:48 --> Config Class Initialized
INFO - 2021-08-19 08:20:48 --> Loader Class Initialized
INFO - 2021-08-19 08:20:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:48 --> Controller Class Initialized
INFO - 2021-08-19 08:20:50 --> Config Class Initialized
INFO - 2021-08-19 08:20:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:50 --> URI Class Initialized
INFO - 2021-08-19 08:20:50 --> Router Class Initialized
INFO - 2021-08-19 08:20:50 --> Output Class Initialized
INFO - 2021-08-19 08:20:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:50 --> Input Class Initialized
INFO - 2021-08-19 08:20:50 --> Language Class Initialized
INFO - 2021-08-19 08:20:50 --> Language Class Initialized
INFO - 2021-08-19 08:20:50 --> Config Class Initialized
INFO - 2021-08-19 08:20:50 --> Loader Class Initialized
INFO - 2021-08-19 08:20:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:50 --> Controller Class Initialized
INFO - 2021-08-19 08:20:59 --> Config Class Initialized
INFO - 2021-08-19 08:20:59 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:20:59 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:20:59 --> Utf8 Class Initialized
INFO - 2021-08-19 08:20:59 --> URI Class Initialized
INFO - 2021-08-19 08:20:59 --> Router Class Initialized
INFO - 2021-08-19 08:20:59 --> Output Class Initialized
INFO - 2021-08-19 08:20:59 --> Security Class Initialized
DEBUG - 2021-08-19 08:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:20:59 --> Input Class Initialized
INFO - 2021-08-19 08:20:59 --> Language Class Initialized
INFO - 2021-08-19 08:20:59 --> Language Class Initialized
INFO - 2021-08-19 08:20:59 --> Config Class Initialized
INFO - 2021-08-19 08:20:59 --> Loader Class Initialized
INFO - 2021-08-19 08:20:59 --> Helper loaded: url_helper
INFO - 2021-08-19 08:20:59 --> Helper loaded: file_helper
INFO - 2021-08-19 08:20:59 --> Helper loaded: form_helper
INFO - 2021-08-19 08:20:59 --> Helper loaded: my_helper
INFO - 2021-08-19 08:20:59 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:20:59 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:00 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:00 --> Total execution time: 0.0504
INFO - 2021-08-19 08:21:00 --> Config Class Initialized
INFO - 2021-08-19 08:21:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:00 --> URI Class Initialized
INFO - 2021-08-19 08:21:00 --> Router Class Initialized
INFO - 2021-08-19 08:21:00 --> Output Class Initialized
INFO - 2021-08-19 08:21:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:00 --> Input Class Initialized
INFO - 2021-08-19 08:21:00 --> Language Class Initialized
INFO - 2021-08-19 08:21:00 --> Language Class Initialized
INFO - 2021-08-19 08:21:00 --> Config Class Initialized
INFO - 2021-08-19 08:21:00 --> Loader Class Initialized
INFO - 2021-08-19 08:21:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:00 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:00 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:00 --> Controller Class Initialized
INFO - 2021-08-19 08:21:01 --> Config Class Initialized
INFO - 2021-08-19 08:21:01 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:01 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:01 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:01 --> URI Class Initialized
INFO - 2021-08-19 08:21:01 --> Router Class Initialized
INFO - 2021-08-19 08:21:01 --> Output Class Initialized
INFO - 2021-08-19 08:21:01 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:01 --> Input Class Initialized
INFO - 2021-08-19 08:21:01 --> Language Class Initialized
INFO - 2021-08-19 08:21:01 --> Language Class Initialized
INFO - 2021-08-19 08:21:01 --> Config Class Initialized
INFO - 2021-08-19 08:21:01 --> Loader Class Initialized
INFO - 2021-08-19 08:21:01 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:01 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:01 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:01 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:01 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:01 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:01 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:01 --> Total execution time: 0.0512
INFO - 2021-08-19 08:21:02 --> Config Class Initialized
INFO - 2021-08-19 08:21:02 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:02 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:02 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:02 --> URI Class Initialized
INFO - 2021-08-19 08:21:02 --> Router Class Initialized
INFO - 2021-08-19 08:21:02 --> Output Class Initialized
INFO - 2021-08-19 08:21:02 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:02 --> Input Class Initialized
INFO - 2021-08-19 08:21:02 --> Language Class Initialized
INFO - 2021-08-19 08:21:02 --> Language Class Initialized
INFO - 2021-08-19 08:21:02 --> Config Class Initialized
INFO - 2021-08-19 08:21:02 --> Loader Class Initialized
INFO - 2021-08-19 08:21:02 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:02 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:02 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:02 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:02 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:02 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:02 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:02 --> Total execution time: 0.0505
INFO - 2021-08-19 08:21:02 --> Config Class Initialized
INFO - 2021-08-19 08:21:02 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:02 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:02 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:02 --> URI Class Initialized
INFO - 2021-08-19 08:21:02 --> Router Class Initialized
INFO - 2021-08-19 08:21:02 --> Output Class Initialized
INFO - 2021-08-19 08:21:02 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:02 --> Input Class Initialized
INFO - 2021-08-19 08:21:02 --> Language Class Initialized
INFO - 2021-08-19 08:21:02 --> Language Class Initialized
INFO - 2021-08-19 08:21:02 --> Config Class Initialized
INFO - 2021-08-19 08:21:02 --> Loader Class Initialized
INFO - 2021-08-19 08:21:02 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:02 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:02 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:02 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:02 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:02 --> Controller Class Initialized
INFO - 2021-08-19 08:21:03 --> Config Class Initialized
INFO - 2021-08-19 08:21:03 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:03 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:03 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:03 --> URI Class Initialized
INFO - 2021-08-19 08:21:03 --> Router Class Initialized
INFO - 2021-08-19 08:21:03 --> Output Class Initialized
INFO - 2021-08-19 08:21:03 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:03 --> Input Class Initialized
INFO - 2021-08-19 08:21:03 --> Language Class Initialized
INFO - 2021-08-19 08:21:03 --> Language Class Initialized
INFO - 2021-08-19 08:21:03 --> Config Class Initialized
INFO - 2021-08-19 08:21:03 --> Loader Class Initialized
INFO - 2021-08-19 08:21:03 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:03 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:03 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:03 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:03 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:03 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:21:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:03 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:03 --> Total execution time: 0.0500
INFO - 2021-08-19 08:21:06 --> Config Class Initialized
INFO - 2021-08-19 08:21:06 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:06 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:06 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:06 --> URI Class Initialized
INFO - 2021-08-19 08:21:06 --> Router Class Initialized
INFO - 2021-08-19 08:21:06 --> Output Class Initialized
INFO - 2021-08-19 08:21:06 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:06 --> Input Class Initialized
INFO - 2021-08-19 08:21:06 --> Language Class Initialized
INFO - 2021-08-19 08:21:06 --> Language Class Initialized
INFO - 2021-08-19 08:21:06 --> Config Class Initialized
INFO - 2021-08-19 08:21:06 --> Loader Class Initialized
INFO - 2021-08-19 08:21:06 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:06 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:06 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:06 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:06 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:06 --> Controller Class Initialized
INFO - 2021-08-19 08:21:08 --> Config Class Initialized
INFO - 2021-08-19 08:21:08 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:08 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:08 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:08 --> URI Class Initialized
INFO - 2021-08-19 08:21:08 --> Router Class Initialized
INFO - 2021-08-19 08:21:08 --> Output Class Initialized
INFO - 2021-08-19 08:21:08 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:08 --> Input Class Initialized
INFO - 2021-08-19 08:21:08 --> Language Class Initialized
INFO - 2021-08-19 08:21:08 --> Language Class Initialized
INFO - 2021-08-19 08:21:08 --> Config Class Initialized
INFO - 2021-08-19 08:21:08 --> Loader Class Initialized
INFO - 2021-08-19 08:21:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:08 --> Controller Class Initialized
INFO - 2021-08-19 08:21:10 --> Config Class Initialized
INFO - 2021-08-19 08:21:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:10 --> URI Class Initialized
INFO - 2021-08-19 08:21:10 --> Router Class Initialized
INFO - 2021-08-19 08:21:10 --> Output Class Initialized
INFO - 2021-08-19 08:21:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:10 --> Input Class Initialized
INFO - 2021-08-19 08:21:10 --> Language Class Initialized
INFO - 2021-08-19 08:21:10 --> Language Class Initialized
INFO - 2021-08-19 08:21:10 --> Config Class Initialized
INFO - 2021-08-19 08:21:10 --> Loader Class Initialized
INFO - 2021-08-19 08:21:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:10 --> Controller Class Initialized
INFO - 2021-08-19 08:21:12 --> Config Class Initialized
INFO - 2021-08-19 08:21:12 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:12 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:12 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:12 --> URI Class Initialized
INFO - 2021-08-19 08:21:12 --> Router Class Initialized
INFO - 2021-08-19 08:21:12 --> Output Class Initialized
INFO - 2021-08-19 08:21:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:12 --> Input Class Initialized
INFO - 2021-08-19 08:21:12 --> Language Class Initialized
INFO - 2021-08-19 08:21:12 --> Language Class Initialized
INFO - 2021-08-19 08:21:12 --> Config Class Initialized
INFO - 2021-08-19 08:21:12 --> Loader Class Initialized
INFO - 2021-08-19 08:21:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:12 --> Controller Class Initialized
INFO - 2021-08-19 08:21:21 --> Config Class Initialized
INFO - 2021-08-19 08:21:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:21 --> URI Class Initialized
INFO - 2021-08-19 08:21:21 --> Router Class Initialized
INFO - 2021-08-19 08:21:21 --> Output Class Initialized
INFO - 2021-08-19 08:21:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:21 --> Input Class Initialized
INFO - 2021-08-19 08:21:21 --> Language Class Initialized
INFO - 2021-08-19 08:21:21 --> Language Class Initialized
INFO - 2021-08-19 08:21:21 --> Config Class Initialized
INFO - 2021-08-19 08:21:21 --> Loader Class Initialized
INFO - 2021-08-19 08:21:21 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:21 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:21 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:21 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:21 --> Controller Class Initialized
INFO - 2021-08-19 08:21:21 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:21:21 --> Config Class Initialized
INFO - 2021-08-19 08:21:21 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:21 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:21 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:21 --> URI Class Initialized
INFO - 2021-08-19 08:21:21 --> Router Class Initialized
INFO - 2021-08-19 08:21:21 --> Output Class Initialized
INFO - 2021-08-19 08:21:21 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:21 --> Input Class Initialized
INFO - 2021-08-19 08:21:21 --> Language Class Initialized
INFO - 2021-08-19 08:21:21 --> Language Class Initialized
INFO - 2021-08-19 08:21:21 --> Config Class Initialized
INFO - 2021-08-19 08:21:21 --> Loader Class Initialized
INFO - 2021-08-19 08:21:21 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:21 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:21 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:21 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:21 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:21 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:21 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:21 --> Total execution time: 0.0548
INFO - 2021-08-19 08:21:29 --> Config Class Initialized
INFO - 2021-08-19 08:21:29 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:29 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:29 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:29 --> URI Class Initialized
INFO - 2021-08-19 08:21:29 --> Router Class Initialized
INFO - 2021-08-19 08:21:29 --> Output Class Initialized
INFO - 2021-08-19 08:21:29 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:29 --> Input Class Initialized
INFO - 2021-08-19 08:21:29 --> Language Class Initialized
INFO - 2021-08-19 08:21:29 --> Language Class Initialized
INFO - 2021-08-19 08:21:29 --> Config Class Initialized
INFO - 2021-08-19 08:21:29 --> Loader Class Initialized
INFO - 2021-08-19 08:21:29 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:29 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:29 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:29 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:29 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:29 --> Controller Class Initialized
INFO - 2021-08-19 08:21:29 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:21:29 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:29 --> Total execution time: 0.0704
INFO - 2021-08-19 08:21:30 --> Config Class Initialized
INFO - 2021-08-19 08:21:30 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:30 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:30 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:30 --> URI Class Initialized
INFO - 2021-08-19 08:21:30 --> Router Class Initialized
INFO - 2021-08-19 08:21:30 --> Output Class Initialized
INFO - 2021-08-19 08:21:30 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:30 --> Input Class Initialized
INFO - 2021-08-19 08:21:30 --> Language Class Initialized
INFO - 2021-08-19 08:21:30 --> Language Class Initialized
INFO - 2021-08-19 08:21:30 --> Config Class Initialized
INFO - 2021-08-19 08:21:30 --> Loader Class Initialized
INFO - 2021-08-19 08:21:30 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:30 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:30 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:30 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:30 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:30 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:30 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:30 --> Total execution time: 0.7336
INFO - 2021-08-19 08:21:32 --> Config Class Initialized
INFO - 2021-08-19 08:21:32 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:32 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:32 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:32 --> URI Class Initialized
INFO - 2021-08-19 08:21:32 --> Router Class Initialized
INFO - 2021-08-19 08:21:32 --> Output Class Initialized
INFO - 2021-08-19 08:21:32 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:32 --> Input Class Initialized
INFO - 2021-08-19 08:21:32 --> Language Class Initialized
INFO - 2021-08-19 08:21:32 --> Language Class Initialized
INFO - 2021-08-19 08:21:32 --> Config Class Initialized
INFO - 2021-08-19 08:21:32 --> Loader Class Initialized
INFO - 2021-08-19 08:21:32 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:32 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:32 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:32 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:32 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:32 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:21:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:32 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:32 --> Total execution time: 0.0509
INFO - 2021-08-19 08:21:34 --> Config Class Initialized
INFO - 2021-08-19 08:21:34 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:34 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:34 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:34 --> URI Class Initialized
INFO - 2021-08-19 08:21:34 --> Router Class Initialized
INFO - 2021-08-19 08:21:34 --> Output Class Initialized
INFO - 2021-08-19 08:21:34 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:34 --> Input Class Initialized
INFO - 2021-08-19 08:21:34 --> Language Class Initialized
INFO - 2021-08-19 08:21:34 --> Language Class Initialized
INFO - 2021-08-19 08:21:34 --> Config Class Initialized
INFO - 2021-08-19 08:21:34 --> Loader Class Initialized
INFO - 2021-08-19 08:21:34 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:34 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:34 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:34 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:34 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:34 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:21:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:34 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:34 --> Total execution time: 0.0550
INFO - 2021-08-19 08:21:35 --> Config Class Initialized
INFO - 2021-08-19 08:21:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:35 --> URI Class Initialized
INFO - 2021-08-19 08:21:35 --> Router Class Initialized
INFO - 2021-08-19 08:21:35 --> Output Class Initialized
INFO - 2021-08-19 08:21:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:35 --> Input Class Initialized
INFO - 2021-08-19 08:21:35 --> Language Class Initialized
INFO - 2021-08-19 08:21:35 --> Language Class Initialized
INFO - 2021-08-19 08:21:35 --> Config Class Initialized
INFO - 2021-08-19 08:21:35 --> Loader Class Initialized
INFO - 2021-08-19 08:21:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:35 --> Controller Class Initialized
INFO - 2021-08-19 08:21:35 --> Config Class Initialized
INFO - 2021-08-19 08:21:35 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:35 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:35 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:35 --> URI Class Initialized
INFO - 2021-08-19 08:21:35 --> Router Class Initialized
INFO - 2021-08-19 08:21:35 --> Output Class Initialized
INFO - 2021-08-19 08:21:35 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:35 --> Input Class Initialized
INFO - 2021-08-19 08:21:35 --> Language Class Initialized
INFO - 2021-08-19 08:21:35 --> Language Class Initialized
INFO - 2021-08-19 08:21:35 --> Config Class Initialized
INFO - 2021-08-19 08:21:35 --> Loader Class Initialized
INFO - 2021-08-19 08:21:35 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:35 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:35 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:35 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:35 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:35 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:35 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:35 --> Total execution time: 0.0516
INFO - 2021-08-19 08:21:38 --> Config Class Initialized
INFO - 2021-08-19 08:21:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:38 --> URI Class Initialized
INFO - 2021-08-19 08:21:38 --> Router Class Initialized
INFO - 2021-08-19 08:21:38 --> Output Class Initialized
INFO - 2021-08-19 08:21:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:38 --> Input Class Initialized
INFO - 2021-08-19 08:21:38 --> Language Class Initialized
INFO - 2021-08-19 08:21:38 --> Language Class Initialized
INFO - 2021-08-19 08:21:38 --> Config Class Initialized
INFO - 2021-08-19 08:21:38 --> Loader Class Initialized
INFO - 2021-08-19 08:21:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:38 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:38 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:38 --> Total execution time: 0.0509
INFO - 2021-08-19 08:21:38 --> Config Class Initialized
INFO - 2021-08-19 08:21:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:38 --> URI Class Initialized
INFO - 2021-08-19 08:21:38 --> Router Class Initialized
INFO - 2021-08-19 08:21:38 --> Output Class Initialized
INFO - 2021-08-19 08:21:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:38 --> Input Class Initialized
INFO - 2021-08-19 08:21:38 --> Language Class Initialized
INFO - 2021-08-19 08:21:38 --> Language Class Initialized
INFO - 2021-08-19 08:21:38 --> Config Class Initialized
INFO - 2021-08-19 08:21:38 --> Loader Class Initialized
INFO - 2021-08-19 08:21:38 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:38 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:38 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:38 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:38 --> Controller Class Initialized
INFO - 2021-08-19 08:21:39 --> Config Class Initialized
INFO - 2021-08-19 08:21:39 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:39 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:39 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:39 --> URI Class Initialized
INFO - 2021-08-19 08:21:39 --> Router Class Initialized
INFO - 2021-08-19 08:21:39 --> Output Class Initialized
INFO - 2021-08-19 08:21:39 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:39 --> Input Class Initialized
INFO - 2021-08-19 08:21:39 --> Language Class Initialized
INFO - 2021-08-19 08:21:39 --> Language Class Initialized
INFO - 2021-08-19 08:21:39 --> Config Class Initialized
INFO - 2021-08-19 08:21:39 --> Loader Class Initialized
INFO - 2021-08-19 08:21:39 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:39 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:39 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:39 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:39 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:39 --> Controller Class Initialized
DEBUG - 2021-08-19 08:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:21:39 --> Final output sent to browser
DEBUG - 2021-08-19 08:21:39 --> Total execution time: 0.0486
INFO - 2021-08-19 08:21:42 --> Config Class Initialized
INFO - 2021-08-19 08:21:42 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:42 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:42 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:42 --> URI Class Initialized
INFO - 2021-08-19 08:21:42 --> Router Class Initialized
INFO - 2021-08-19 08:21:42 --> Output Class Initialized
INFO - 2021-08-19 08:21:42 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:42 --> Input Class Initialized
INFO - 2021-08-19 08:21:42 --> Language Class Initialized
INFO - 2021-08-19 08:21:42 --> Language Class Initialized
INFO - 2021-08-19 08:21:42 --> Config Class Initialized
INFO - 2021-08-19 08:21:42 --> Loader Class Initialized
INFO - 2021-08-19 08:21:42 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:42 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:42 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:42 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:42 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:42 --> Controller Class Initialized
INFO - 2021-08-19 08:21:44 --> Config Class Initialized
INFO - 2021-08-19 08:21:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:44 --> URI Class Initialized
INFO - 2021-08-19 08:21:44 --> Router Class Initialized
INFO - 2021-08-19 08:21:44 --> Output Class Initialized
INFO - 2021-08-19 08:21:44 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:44 --> Input Class Initialized
INFO - 2021-08-19 08:21:44 --> Language Class Initialized
INFO - 2021-08-19 08:21:44 --> Language Class Initialized
INFO - 2021-08-19 08:21:44 --> Config Class Initialized
INFO - 2021-08-19 08:21:44 --> Loader Class Initialized
INFO - 2021-08-19 08:21:44 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:44 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:44 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:44 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:44 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:44 --> Controller Class Initialized
INFO - 2021-08-19 08:21:45 --> Config Class Initialized
INFO - 2021-08-19 08:21:45 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:45 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:45 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:45 --> URI Class Initialized
INFO - 2021-08-19 08:21:45 --> Router Class Initialized
INFO - 2021-08-19 08:21:45 --> Output Class Initialized
INFO - 2021-08-19 08:21:45 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:45 --> Input Class Initialized
INFO - 2021-08-19 08:21:45 --> Language Class Initialized
INFO - 2021-08-19 08:21:45 --> Language Class Initialized
INFO - 2021-08-19 08:21:45 --> Config Class Initialized
INFO - 2021-08-19 08:21:45 --> Loader Class Initialized
INFO - 2021-08-19 08:21:45 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:45 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:45 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:45 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:45 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:45 --> Controller Class Initialized
INFO - 2021-08-19 08:21:49 --> Config Class Initialized
INFO - 2021-08-19 08:21:49 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:21:49 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:21:49 --> Utf8 Class Initialized
INFO - 2021-08-19 08:21:49 --> URI Class Initialized
INFO - 2021-08-19 08:21:49 --> Router Class Initialized
INFO - 2021-08-19 08:21:49 --> Output Class Initialized
INFO - 2021-08-19 08:21:49 --> Security Class Initialized
DEBUG - 2021-08-19 08:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:21:49 --> Input Class Initialized
INFO - 2021-08-19 08:21:49 --> Language Class Initialized
INFO - 2021-08-19 08:21:49 --> Language Class Initialized
INFO - 2021-08-19 08:21:49 --> Config Class Initialized
INFO - 2021-08-19 08:21:49 --> Loader Class Initialized
INFO - 2021-08-19 08:21:49 --> Helper loaded: url_helper
INFO - 2021-08-19 08:21:49 --> Helper loaded: file_helper
INFO - 2021-08-19 08:21:49 --> Helper loaded: form_helper
INFO - 2021-08-19 08:21:49 --> Helper loaded: my_helper
INFO - 2021-08-19 08:21:49 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:21:49 --> Controller Class Initialized
INFO - 2021-08-19 08:22:00 --> Config Class Initialized
INFO - 2021-08-19 08:22:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:22:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:22:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:22:00 --> URI Class Initialized
INFO - 2021-08-19 08:22:00 --> Router Class Initialized
INFO - 2021-08-19 08:22:00 --> Output Class Initialized
INFO - 2021-08-19 08:22:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:22:00 --> Input Class Initialized
INFO - 2021-08-19 08:22:00 --> Language Class Initialized
INFO - 2021-08-19 08:22:00 --> Language Class Initialized
INFO - 2021-08-19 08:22:00 --> Config Class Initialized
INFO - 2021-08-19 08:22:00 --> Loader Class Initialized
INFO - 2021-08-19 08:22:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:22:00 --> Helper loaded: file_helper
INFO - 2021-08-19 08:22:00 --> Helper loaded: form_helper
INFO - 2021-08-19 08:22:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:22:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:22:00 --> Controller Class Initialized
INFO - 2021-08-19 08:22:00 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:22:00 --> Config Class Initialized
INFO - 2021-08-19 08:22:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:22:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:22:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:22:00 --> URI Class Initialized
INFO - 2021-08-19 08:22:00 --> Router Class Initialized
INFO - 2021-08-19 08:22:00 --> Output Class Initialized
INFO - 2021-08-19 08:22:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:22:00 --> Input Class Initialized
INFO - 2021-08-19 08:22:00 --> Language Class Initialized
INFO - 2021-08-19 08:22:00 --> Language Class Initialized
INFO - 2021-08-19 08:22:00 --> Config Class Initialized
INFO - 2021-08-19 08:22:00 --> Loader Class Initialized
INFO - 2021-08-19 08:22:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:22:00 --> Helper loaded: file_helper
INFO - 2021-08-19 08:22:00 --> Helper loaded: form_helper
INFO - 2021-08-19 08:22:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:22:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:22:00 --> Controller Class Initialized
DEBUG - 2021-08-19 08:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:22:00 --> Final output sent to browser
DEBUG - 2021-08-19 08:22:00 --> Total execution time: 0.0543
INFO - 2021-08-19 08:22:15 --> Config Class Initialized
INFO - 2021-08-19 08:22:15 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:22:15 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:22:15 --> Utf8 Class Initialized
INFO - 2021-08-19 08:22:15 --> URI Class Initialized
INFO - 2021-08-19 08:22:15 --> Router Class Initialized
INFO - 2021-08-19 08:22:15 --> Output Class Initialized
INFO - 2021-08-19 08:22:15 --> Security Class Initialized
DEBUG - 2021-08-19 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:22:15 --> Input Class Initialized
INFO - 2021-08-19 08:22:15 --> Language Class Initialized
INFO - 2021-08-19 08:22:15 --> Language Class Initialized
INFO - 2021-08-19 08:22:15 --> Config Class Initialized
INFO - 2021-08-19 08:22:15 --> Loader Class Initialized
INFO - 2021-08-19 08:22:15 --> Helper loaded: url_helper
INFO - 2021-08-19 08:22:15 --> Helper loaded: file_helper
INFO - 2021-08-19 08:22:15 --> Helper loaded: form_helper
INFO - 2021-08-19 08:22:15 --> Helper loaded: my_helper
INFO - 2021-08-19 08:22:15 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:22:15 --> Controller Class Initialized
INFO - 2021-08-19 08:22:15 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:22:15 --> Final output sent to browser
DEBUG - 2021-08-19 08:22:15 --> Total execution time: 0.0570
INFO - 2021-08-19 08:22:15 --> Config Class Initialized
INFO - 2021-08-19 08:22:15 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:22:15 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:22:15 --> Utf8 Class Initialized
INFO - 2021-08-19 08:22:15 --> URI Class Initialized
INFO - 2021-08-19 08:22:15 --> Router Class Initialized
INFO - 2021-08-19 08:22:15 --> Output Class Initialized
INFO - 2021-08-19 08:22:15 --> Security Class Initialized
DEBUG - 2021-08-19 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:22:15 --> Input Class Initialized
INFO - 2021-08-19 08:22:15 --> Language Class Initialized
INFO - 2021-08-19 08:22:15 --> Language Class Initialized
INFO - 2021-08-19 08:22:15 --> Config Class Initialized
INFO - 2021-08-19 08:22:15 --> Loader Class Initialized
INFO - 2021-08-19 08:22:15 --> Helper loaded: url_helper
INFO - 2021-08-19 08:22:15 --> Helper loaded: file_helper
INFO - 2021-08-19 08:22:15 --> Helper loaded: form_helper
INFO - 2021-08-19 08:22:15 --> Helper loaded: my_helper
INFO - 2021-08-19 08:22:15 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:22:15 --> Controller Class Initialized
DEBUG - 2021-08-19 08:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:22:16 --> Final output sent to browser
DEBUG - 2021-08-19 08:22:16 --> Total execution time: 0.7424
INFO - 2021-08-19 08:24:29 --> Config Class Initialized
INFO - 2021-08-19 08:24:29 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:29 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:29 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:29 --> URI Class Initialized
INFO - 2021-08-19 08:24:29 --> Router Class Initialized
INFO - 2021-08-19 08:24:29 --> Output Class Initialized
INFO - 2021-08-19 08:24:29 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:29 --> Input Class Initialized
INFO - 2021-08-19 08:24:29 --> Language Class Initialized
INFO - 2021-08-19 08:24:29 --> Language Class Initialized
INFO - 2021-08-19 08:24:29 --> Config Class Initialized
INFO - 2021-08-19 08:24:29 --> Loader Class Initialized
INFO - 2021-08-19 08:24:29 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:29 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:29 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:29 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:29 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:29 --> Controller Class Initialized
DEBUG - 2021-08-19 08:24:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:24:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:24:29 --> Final output sent to browser
DEBUG - 2021-08-19 08:24:29 --> Total execution time: 0.0753
INFO - 2021-08-19 08:24:33 --> Config Class Initialized
INFO - 2021-08-19 08:24:33 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:33 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:33 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:33 --> URI Class Initialized
INFO - 2021-08-19 08:24:33 --> Router Class Initialized
INFO - 2021-08-19 08:24:33 --> Output Class Initialized
INFO - 2021-08-19 08:24:33 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:33 --> Input Class Initialized
INFO - 2021-08-19 08:24:33 --> Language Class Initialized
INFO - 2021-08-19 08:24:33 --> Language Class Initialized
INFO - 2021-08-19 08:24:33 --> Config Class Initialized
INFO - 2021-08-19 08:24:33 --> Loader Class Initialized
INFO - 2021-08-19 08:24:33 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:33 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:33 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:33 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:33 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:33 --> Controller Class Initialized
DEBUG - 2021-08-19 08:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:24:33 --> Final output sent to browser
DEBUG - 2021-08-19 08:24:33 --> Total execution time: 0.0642
INFO - 2021-08-19 08:24:33 --> Config Class Initialized
INFO - 2021-08-19 08:24:33 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:33 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:33 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:33 --> URI Class Initialized
INFO - 2021-08-19 08:24:33 --> Router Class Initialized
INFO - 2021-08-19 08:24:33 --> Output Class Initialized
INFO - 2021-08-19 08:24:33 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:33 --> Input Class Initialized
INFO - 2021-08-19 08:24:33 --> Language Class Initialized
INFO - 2021-08-19 08:24:33 --> Language Class Initialized
INFO - 2021-08-19 08:24:33 --> Config Class Initialized
INFO - 2021-08-19 08:24:33 --> Loader Class Initialized
INFO - 2021-08-19 08:24:33 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:33 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:33 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:33 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:33 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:33 --> Controller Class Initialized
INFO - 2021-08-19 08:24:34 --> Config Class Initialized
INFO - 2021-08-19 08:24:34 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:34 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:34 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:34 --> URI Class Initialized
INFO - 2021-08-19 08:24:34 --> Router Class Initialized
INFO - 2021-08-19 08:24:34 --> Output Class Initialized
INFO - 2021-08-19 08:24:34 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:34 --> Input Class Initialized
INFO - 2021-08-19 08:24:34 --> Language Class Initialized
INFO - 2021-08-19 08:24:34 --> Language Class Initialized
INFO - 2021-08-19 08:24:34 --> Config Class Initialized
INFO - 2021-08-19 08:24:34 --> Loader Class Initialized
INFO - 2021-08-19 08:24:34 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:34 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:34 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:34 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:34 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:34 --> Controller Class Initialized
DEBUG - 2021-08-19 08:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:24:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:24:34 --> Final output sent to browser
DEBUG - 2021-08-19 08:24:34 --> Total execution time: 0.0517
INFO - 2021-08-19 08:24:37 --> Config Class Initialized
INFO - 2021-08-19 08:24:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:37 --> URI Class Initialized
INFO - 2021-08-19 08:24:37 --> Router Class Initialized
INFO - 2021-08-19 08:24:37 --> Output Class Initialized
INFO - 2021-08-19 08:24:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:37 --> Input Class Initialized
INFO - 2021-08-19 08:24:37 --> Language Class Initialized
INFO - 2021-08-19 08:24:37 --> Language Class Initialized
INFO - 2021-08-19 08:24:37 --> Config Class Initialized
INFO - 2021-08-19 08:24:37 --> Loader Class Initialized
INFO - 2021-08-19 08:24:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:37 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:37 --> Controller Class Initialized
DEBUG - 2021-08-19 08:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:24:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:24:37 --> Final output sent to browser
DEBUG - 2021-08-19 08:24:37 --> Total execution time: 0.0506
INFO - 2021-08-19 08:24:37 --> Config Class Initialized
INFO - 2021-08-19 08:24:37 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:37 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:37 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:37 --> URI Class Initialized
INFO - 2021-08-19 08:24:37 --> Router Class Initialized
INFO - 2021-08-19 08:24:37 --> Output Class Initialized
INFO - 2021-08-19 08:24:37 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:37 --> Input Class Initialized
INFO - 2021-08-19 08:24:37 --> Language Class Initialized
INFO - 2021-08-19 08:24:37 --> Language Class Initialized
INFO - 2021-08-19 08:24:37 --> Config Class Initialized
INFO - 2021-08-19 08:24:37 --> Loader Class Initialized
INFO - 2021-08-19 08:24:37 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:37 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:37 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:37 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:38 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:38 --> Controller Class Initialized
INFO - 2021-08-19 08:24:38 --> Config Class Initialized
INFO - 2021-08-19 08:24:38 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:24:38 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:24:38 --> Utf8 Class Initialized
INFO - 2021-08-19 08:24:38 --> URI Class Initialized
INFO - 2021-08-19 08:24:38 --> Router Class Initialized
INFO - 2021-08-19 08:24:38 --> Output Class Initialized
INFO - 2021-08-19 08:24:38 --> Security Class Initialized
DEBUG - 2021-08-19 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:24:38 --> Input Class Initialized
INFO - 2021-08-19 08:24:38 --> Language Class Initialized
INFO - 2021-08-19 08:24:38 --> Language Class Initialized
INFO - 2021-08-19 08:24:39 --> Config Class Initialized
INFO - 2021-08-19 08:24:39 --> Loader Class Initialized
INFO - 2021-08-19 08:24:39 --> Helper loaded: url_helper
INFO - 2021-08-19 08:24:39 --> Helper loaded: file_helper
INFO - 2021-08-19 08:24:39 --> Helper loaded: form_helper
INFO - 2021-08-19 08:24:39 --> Helper loaded: my_helper
INFO - 2021-08-19 08:24:39 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:24:39 --> Controller Class Initialized
DEBUG - 2021-08-19 08:24:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:24:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:24:39 --> Final output sent to browser
DEBUG - 2021-08-19 08:24:39 --> Total execution time: 0.0507
INFO - 2021-08-19 08:25:39 --> Config Class Initialized
INFO - 2021-08-19 08:25:39 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:25:39 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:25:39 --> Utf8 Class Initialized
INFO - 2021-08-19 08:25:39 --> URI Class Initialized
INFO - 2021-08-19 08:25:39 --> Router Class Initialized
INFO - 2021-08-19 08:25:39 --> Output Class Initialized
INFO - 2021-08-19 08:25:39 --> Security Class Initialized
DEBUG - 2021-08-19 08:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:25:39 --> Input Class Initialized
INFO - 2021-08-19 08:25:39 --> Language Class Initialized
INFO - 2021-08-19 08:25:39 --> Language Class Initialized
INFO - 2021-08-19 08:25:39 --> Config Class Initialized
INFO - 2021-08-19 08:25:39 --> Loader Class Initialized
INFO - 2021-08-19 08:25:39 --> Helper loaded: url_helper
INFO - 2021-08-19 08:25:39 --> Helper loaded: file_helper
INFO - 2021-08-19 08:25:39 --> Helper loaded: form_helper
INFO - 2021-08-19 08:25:39 --> Helper loaded: my_helper
INFO - 2021-08-19 08:25:39 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:25:39 --> Controller Class Initialized
INFO - 2021-08-19 08:25:41 --> Config Class Initialized
INFO - 2021-08-19 08:25:41 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:25:41 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:25:41 --> Utf8 Class Initialized
INFO - 2021-08-19 08:25:41 --> URI Class Initialized
INFO - 2021-08-19 08:25:41 --> Router Class Initialized
INFO - 2021-08-19 08:25:41 --> Output Class Initialized
INFO - 2021-08-19 08:25:41 --> Security Class Initialized
DEBUG - 2021-08-19 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:25:41 --> Input Class Initialized
INFO - 2021-08-19 08:25:41 --> Language Class Initialized
INFO - 2021-08-19 08:25:41 --> Language Class Initialized
INFO - 2021-08-19 08:25:41 --> Config Class Initialized
INFO - 2021-08-19 08:25:41 --> Loader Class Initialized
INFO - 2021-08-19 08:25:41 --> Helper loaded: url_helper
INFO - 2021-08-19 08:25:41 --> Helper loaded: file_helper
INFO - 2021-08-19 08:25:41 --> Helper loaded: form_helper
INFO - 2021-08-19 08:25:41 --> Helper loaded: my_helper
INFO - 2021-08-19 08:25:41 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:25:41 --> Controller Class Initialized
INFO - 2021-08-19 08:25:42 --> Config Class Initialized
INFO - 2021-08-19 08:25:42 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:25:42 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:25:42 --> Utf8 Class Initialized
INFO - 2021-08-19 08:25:42 --> URI Class Initialized
INFO - 2021-08-19 08:25:42 --> Router Class Initialized
INFO - 2021-08-19 08:25:42 --> Output Class Initialized
INFO - 2021-08-19 08:25:42 --> Security Class Initialized
DEBUG - 2021-08-19 08:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:25:42 --> Input Class Initialized
INFO - 2021-08-19 08:25:42 --> Language Class Initialized
INFO - 2021-08-19 08:25:42 --> Language Class Initialized
INFO - 2021-08-19 08:25:42 --> Config Class Initialized
INFO - 2021-08-19 08:25:42 --> Loader Class Initialized
INFO - 2021-08-19 08:25:42 --> Helper loaded: url_helper
INFO - 2021-08-19 08:25:42 --> Helper loaded: file_helper
INFO - 2021-08-19 08:25:42 --> Helper loaded: form_helper
INFO - 2021-08-19 08:25:42 --> Helper loaded: my_helper
INFO - 2021-08-19 08:25:42 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:25:42 --> Controller Class Initialized
INFO - 2021-08-19 08:25:44 --> Config Class Initialized
INFO - 2021-08-19 08:25:44 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:25:44 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:25:44 --> Utf8 Class Initialized
INFO - 2021-08-19 08:25:44 --> URI Class Initialized
INFO - 2021-08-19 08:25:45 --> Router Class Initialized
INFO - 2021-08-19 08:25:45 --> Output Class Initialized
INFO - 2021-08-19 08:25:45 --> Security Class Initialized
DEBUG - 2021-08-19 08:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:25:45 --> Input Class Initialized
INFO - 2021-08-19 08:25:45 --> Language Class Initialized
INFO - 2021-08-19 08:25:45 --> Language Class Initialized
INFO - 2021-08-19 08:25:45 --> Config Class Initialized
INFO - 2021-08-19 08:25:45 --> Loader Class Initialized
INFO - 2021-08-19 08:25:45 --> Helper loaded: url_helper
INFO - 2021-08-19 08:25:45 --> Helper loaded: file_helper
INFO - 2021-08-19 08:25:45 --> Helper loaded: form_helper
INFO - 2021-08-19 08:25:45 --> Helper loaded: my_helper
INFO - 2021-08-19 08:25:45 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:25:45 --> Controller Class Initialized
INFO - 2021-08-19 08:26:00 --> Config Class Initialized
INFO - 2021-08-19 08:26:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:26:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:26:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:26:00 --> URI Class Initialized
INFO - 2021-08-19 08:26:00 --> Router Class Initialized
INFO - 2021-08-19 08:26:00 --> Output Class Initialized
INFO - 2021-08-19 08:26:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:26:00 --> Input Class Initialized
INFO - 2021-08-19 08:26:00 --> Language Class Initialized
INFO - 2021-08-19 08:26:00 --> Language Class Initialized
INFO - 2021-08-19 08:26:00 --> Config Class Initialized
INFO - 2021-08-19 08:26:00 --> Loader Class Initialized
INFO - 2021-08-19 08:26:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:26:00 --> Helper loaded: file_helper
INFO - 2021-08-19 08:26:00 --> Helper loaded: form_helper
INFO - 2021-08-19 08:26:00 --> Helper loaded: my_helper
INFO - 2021-08-19 08:26:00 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:26:00 --> Controller Class Initialized
INFO - 2021-08-19 08:26:00 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:26:00 --> Config Class Initialized
INFO - 2021-08-19 08:26:00 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:26:00 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:26:00 --> Utf8 Class Initialized
INFO - 2021-08-19 08:26:00 --> URI Class Initialized
INFO - 2021-08-19 08:26:00 --> Router Class Initialized
INFO - 2021-08-19 08:26:00 --> Output Class Initialized
INFO - 2021-08-19 08:26:00 --> Security Class Initialized
DEBUG - 2021-08-19 08:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:26:00 --> Input Class Initialized
INFO - 2021-08-19 08:26:00 --> Language Class Initialized
INFO - 2021-08-19 08:26:00 --> Language Class Initialized
INFO - 2021-08-19 08:26:00 --> Config Class Initialized
INFO - 2021-08-19 08:26:00 --> Loader Class Initialized
INFO - 2021-08-19 08:26:00 --> Helper loaded: url_helper
INFO - 2021-08-19 08:26:01 --> Helper loaded: file_helper
INFO - 2021-08-19 08:26:01 --> Helper loaded: form_helper
INFO - 2021-08-19 08:26:01 --> Helper loaded: my_helper
INFO - 2021-08-19 08:26:01 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:26:01 --> Controller Class Initialized
DEBUG - 2021-08-19 08:26:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:26:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:26:01 --> Final output sent to browser
DEBUG - 2021-08-19 08:26:01 --> Total execution time: 0.0556
INFO - 2021-08-19 08:26:04 --> Config Class Initialized
INFO - 2021-08-19 08:26:04 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:26:04 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:26:04 --> Utf8 Class Initialized
INFO - 2021-08-19 08:26:04 --> URI Class Initialized
INFO - 2021-08-19 08:26:04 --> Router Class Initialized
INFO - 2021-08-19 08:26:04 --> Output Class Initialized
INFO - 2021-08-19 08:26:04 --> Security Class Initialized
DEBUG - 2021-08-19 08:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:26:04 --> Input Class Initialized
INFO - 2021-08-19 08:26:04 --> Language Class Initialized
INFO - 2021-08-19 08:26:05 --> Language Class Initialized
INFO - 2021-08-19 08:26:05 --> Config Class Initialized
INFO - 2021-08-19 08:26:05 --> Loader Class Initialized
INFO - 2021-08-19 08:26:05 --> Helper loaded: url_helper
INFO - 2021-08-19 08:26:05 --> Helper loaded: file_helper
INFO - 2021-08-19 08:26:05 --> Helper loaded: form_helper
INFO - 2021-08-19 08:26:05 --> Helper loaded: my_helper
INFO - 2021-08-19 08:26:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:26:05 --> Controller Class Initialized
INFO - 2021-08-19 08:26:05 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:26:05 --> Final output sent to browser
DEBUG - 2021-08-19 08:26:05 --> Total execution time: 0.0741
INFO - 2021-08-19 08:26:05 --> Config Class Initialized
INFO - 2021-08-19 08:26:05 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:26:05 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:26:05 --> Utf8 Class Initialized
INFO - 2021-08-19 08:26:05 --> URI Class Initialized
INFO - 2021-08-19 08:26:05 --> Router Class Initialized
INFO - 2021-08-19 08:26:05 --> Output Class Initialized
INFO - 2021-08-19 08:26:05 --> Security Class Initialized
DEBUG - 2021-08-19 08:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:26:05 --> Input Class Initialized
INFO - 2021-08-19 08:26:05 --> Language Class Initialized
INFO - 2021-08-19 08:26:05 --> Language Class Initialized
INFO - 2021-08-19 08:26:05 --> Config Class Initialized
INFO - 2021-08-19 08:26:05 --> Loader Class Initialized
INFO - 2021-08-19 08:26:05 --> Helper loaded: url_helper
INFO - 2021-08-19 08:26:05 --> Helper loaded: file_helper
INFO - 2021-08-19 08:26:05 --> Helper loaded: form_helper
INFO - 2021-08-19 08:26:05 --> Helper loaded: my_helper
INFO - 2021-08-19 08:26:05 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:26:05 --> Controller Class Initialized
DEBUG - 2021-08-19 08:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-19 08:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:26:05 --> Final output sent to browser
DEBUG - 2021-08-19 08:26:05 --> Total execution time: 0.7379
INFO - 2021-08-19 08:28:48 --> Config Class Initialized
INFO - 2021-08-19 08:28:48 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:48 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:48 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:48 --> URI Class Initialized
INFO - 2021-08-19 08:28:48 --> Router Class Initialized
INFO - 2021-08-19 08:28:48 --> Output Class Initialized
INFO - 2021-08-19 08:28:48 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:48 --> Input Class Initialized
INFO - 2021-08-19 08:28:48 --> Language Class Initialized
INFO - 2021-08-19 08:28:48 --> Language Class Initialized
INFO - 2021-08-19 08:28:48 --> Config Class Initialized
INFO - 2021-08-19 08:28:48 --> Loader Class Initialized
INFO - 2021-08-19 08:28:48 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:48 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:48 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:48 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:48 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:48 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:48 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:48 --> Total execution time: 0.0645
INFO - 2021-08-19 08:28:50 --> Config Class Initialized
INFO - 2021-08-19 08:28:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:50 --> URI Class Initialized
INFO - 2021-08-19 08:28:50 --> Router Class Initialized
INFO - 2021-08-19 08:28:50 --> Output Class Initialized
INFO - 2021-08-19 08:28:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:50 --> Input Class Initialized
INFO - 2021-08-19 08:28:50 --> Language Class Initialized
INFO - 2021-08-19 08:28:50 --> Language Class Initialized
INFO - 2021-08-19 08:28:50 --> Config Class Initialized
INFO - 2021-08-19 08:28:50 --> Loader Class Initialized
INFO - 2021-08-19 08:28:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:50 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:28:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:50 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:50 --> Total execution time: 0.0602
INFO - 2021-08-19 08:28:50 --> Config Class Initialized
INFO - 2021-08-19 08:28:50 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:50 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:50 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:50 --> URI Class Initialized
INFO - 2021-08-19 08:28:50 --> Router Class Initialized
INFO - 2021-08-19 08:28:50 --> Output Class Initialized
INFO - 2021-08-19 08:28:50 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:50 --> Input Class Initialized
INFO - 2021-08-19 08:28:50 --> Language Class Initialized
INFO - 2021-08-19 08:28:50 --> Language Class Initialized
INFO - 2021-08-19 08:28:50 --> Config Class Initialized
INFO - 2021-08-19 08:28:50 --> Loader Class Initialized
INFO - 2021-08-19 08:28:50 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:50 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:50 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:50 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:50 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:50 --> Controller Class Initialized
INFO - 2021-08-19 08:28:51 --> Config Class Initialized
INFO - 2021-08-19 08:28:51 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:51 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:51 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:51 --> URI Class Initialized
INFO - 2021-08-19 08:28:51 --> Router Class Initialized
INFO - 2021-08-19 08:28:51 --> Output Class Initialized
INFO - 2021-08-19 08:28:51 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:51 --> Input Class Initialized
INFO - 2021-08-19 08:28:51 --> Language Class Initialized
INFO - 2021-08-19 08:28:51 --> Language Class Initialized
INFO - 2021-08-19 08:28:51 --> Config Class Initialized
INFO - 2021-08-19 08:28:51 --> Loader Class Initialized
INFO - 2021-08-19 08:28:51 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:51 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:51 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:51 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:51 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:51 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-08-19 08:28:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:51 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:51 --> Total execution time: 0.0470
INFO - 2021-08-19 08:28:53 --> Config Class Initialized
INFO - 2021-08-19 08:28:53 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:53 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:53 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:53 --> URI Class Initialized
INFO - 2021-08-19 08:28:53 --> Router Class Initialized
INFO - 2021-08-19 08:28:53 --> Output Class Initialized
INFO - 2021-08-19 08:28:53 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:53 --> Input Class Initialized
INFO - 2021-08-19 08:28:53 --> Language Class Initialized
INFO - 2021-08-19 08:28:53 --> Language Class Initialized
INFO - 2021-08-19 08:28:53 --> Config Class Initialized
INFO - 2021-08-19 08:28:53 --> Loader Class Initialized
INFO - 2021-08-19 08:28:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:53 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:53 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:53 --> Total execution time: 0.0516
INFO - 2021-08-19 08:28:53 --> Config Class Initialized
INFO - 2021-08-19 08:28:53 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:53 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:53 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:53 --> URI Class Initialized
INFO - 2021-08-19 08:28:53 --> Router Class Initialized
INFO - 2021-08-19 08:28:53 --> Output Class Initialized
INFO - 2021-08-19 08:28:53 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:53 --> Input Class Initialized
INFO - 2021-08-19 08:28:53 --> Language Class Initialized
INFO - 2021-08-19 08:28:53 --> Language Class Initialized
INFO - 2021-08-19 08:28:53 --> Config Class Initialized
INFO - 2021-08-19 08:28:53 --> Loader Class Initialized
INFO - 2021-08-19 08:28:53 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:53 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:53 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:53 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:53 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:53 --> Controller Class Initialized
INFO - 2021-08-19 08:28:54 --> Config Class Initialized
INFO - 2021-08-19 08:28:54 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:54 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:54 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:54 --> URI Class Initialized
INFO - 2021-08-19 08:28:54 --> Router Class Initialized
INFO - 2021-08-19 08:28:54 --> Output Class Initialized
INFO - 2021-08-19 08:28:54 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:54 --> Input Class Initialized
INFO - 2021-08-19 08:28:54 --> Language Class Initialized
INFO - 2021-08-19 08:28:54 --> Language Class Initialized
INFO - 2021-08-19 08:28:54 --> Config Class Initialized
INFO - 2021-08-19 08:28:54 --> Loader Class Initialized
INFO - 2021-08-19 08:28:54 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:54 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:54 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:54 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:54 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:54 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:54 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:54 --> Total execution time: 0.0521
INFO - 2021-08-19 08:28:56 --> Config Class Initialized
INFO - 2021-08-19 08:28:56 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:56 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:56 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:56 --> URI Class Initialized
INFO - 2021-08-19 08:28:56 --> Router Class Initialized
INFO - 2021-08-19 08:28:56 --> Output Class Initialized
INFO - 2021-08-19 08:28:56 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:56 --> Input Class Initialized
INFO - 2021-08-19 08:28:56 --> Language Class Initialized
INFO - 2021-08-19 08:28:56 --> Language Class Initialized
INFO - 2021-08-19 08:28:56 --> Config Class Initialized
INFO - 2021-08-19 08:28:56 --> Loader Class Initialized
INFO - 2021-08-19 08:28:56 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:56 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:56 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:56 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:56 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:56 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-08-19 08:28:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:56 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:56 --> Total execution time: 0.0501
INFO - 2021-08-19 08:28:56 --> Config Class Initialized
INFO - 2021-08-19 08:28:56 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:56 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:56 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:56 --> URI Class Initialized
INFO - 2021-08-19 08:28:56 --> Router Class Initialized
INFO - 2021-08-19 08:28:56 --> Output Class Initialized
INFO - 2021-08-19 08:28:56 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:56 --> Input Class Initialized
INFO - 2021-08-19 08:28:56 --> Language Class Initialized
INFO - 2021-08-19 08:28:56 --> Language Class Initialized
INFO - 2021-08-19 08:28:56 --> Config Class Initialized
INFO - 2021-08-19 08:28:56 --> Loader Class Initialized
INFO - 2021-08-19 08:28:56 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:56 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:56 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:56 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:56 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:56 --> Controller Class Initialized
INFO - 2021-08-19 08:28:57 --> Config Class Initialized
INFO - 2021-08-19 08:28:57 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:28:57 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:28:57 --> Utf8 Class Initialized
INFO - 2021-08-19 08:28:57 --> URI Class Initialized
INFO - 2021-08-19 08:28:57 --> Router Class Initialized
INFO - 2021-08-19 08:28:57 --> Output Class Initialized
INFO - 2021-08-19 08:28:57 --> Security Class Initialized
DEBUG - 2021-08-19 08:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:28:57 --> Input Class Initialized
INFO - 2021-08-19 08:28:57 --> Language Class Initialized
INFO - 2021-08-19 08:28:57 --> Language Class Initialized
INFO - 2021-08-19 08:28:57 --> Config Class Initialized
INFO - 2021-08-19 08:28:57 --> Loader Class Initialized
INFO - 2021-08-19 08:28:57 --> Helper loaded: url_helper
INFO - 2021-08-19 08:28:57 --> Helper loaded: file_helper
INFO - 2021-08-19 08:28:57 --> Helper loaded: form_helper
INFO - 2021-08-19 08:28:57 --> Helper loaded: my_helper
INFO - 2021-08-19 08:28:57 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:28:57 --> Controller Class Initialized
DEBUG - 2021-08-19 08:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-08-19 08:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:28:57 --> Final output sent to browser
DEBUG - 2021-08-19 08:28:57 --> Total execution time: 0.0491
INFO - 2021-08-19 08:29:08 --> Config Class Initialized
INFO - 2021-08-19 08:29:08 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:29:08 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:29:08 --> Utf8 Class Initialized
INFO - 2021-08-19 08:29:08 --> URI Class Initialized
INFO - 2021-08-19 08:29:08 --> Router Class Initialized
INFO - 2021-08-19 08:29:08 --> Output Class Initialized
INFO - 2021-08-19 08:29:08 --> Security Class Initialized
DEBUG - 2021-08-19 08:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:29:08 --> Input Class Initialized
INFO - 2021-08-19 08:29:08 --> Language Class Initialized
INFO - 2021-08-19 08:29:08 --> Language Class Initialized
INFO - 2021-08-19 08:29:08 --> Config Class Initialized
INFO - 2021-08-19 08:29:08 --> Loader Class Initialized
INFO - 2021-08-19 08:29:08 --> Helper loaded: url_helper
INFO - 2021-08-19 08:29:08 --> Helper loaded: file_helper
INFO - 2021-08-19 08:29:08 --> Helper loaded: form_helper
INFO - 2021-08-19 08:29:08 --> Helper loaded: my_helper
INFO - 2021-08-19 08:29:08 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:29:08 --> Controller Class Initialized
INFO - 2021-08-19 08:29:10 --> Config Class Initialized
INFO - 2021-08-19 08:29:10 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:29:10 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:29:10 --> Utf8 Class Initialized
INFO - 2021-08-19 08:29:10 --> URI Class Initialized
INFO - 2021-08-19 08:29:10 --> Router Class Initialized
INFO - 2021-08-19 08:29:10 --> Output Class Initialized
INFO - 2021-08-19 08:29:10 --> Security Class Initialized
DEBUG - 2021-08-19 08:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:29:10 --> Input Class Initialized
INFO - 2021-08-19 08:29:10 --> Language Class Initialized
INFO - 2021-08-19 08:29:10 --> Language Class Initialized
INFO - 2021-08-19 08:29:10 --> Config Class Initialized
INFO - 2021-08-19 08:29:10 --> Loader Class Initialized
INFO - 2021-08-19 08:29:10 --> Helper loaded: url_helper
INFO - 2021-08-19 08:29:10 --> Helper loaded: file_helper
INFO - 2021-08-19 08:29:10 --> Helper loaded: form_helper
INFO - 2021-08-19 08:29:10 --> Helper loaded: my_helper
INFO - 2021-08-19 08:29:10 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:29:10 --> Controller Class Initialized
INFO - 2021-08-19 08:29:11 --> Config Class Initialized
INFO - 2021-08-19 08:29:11 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:29:11 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:29:11 --> Utf8 Class Initialized
INFO - 2021-08-19 08:29:11 --> URI Class Initialized
INFO - 2021-08-19 08:29:11 --> Router Class Initialized
INFO - 2021-08-19 08:29:11 --> Output Class Initialized
INFO - 2021-08-19 08:29:12 --> Security Class Initialized
DEBUG - 2021-08-19 08:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:29:12 --> Input Class Initialized
INFO - 2021-08-19 08:29:12 --> Language Class Initialized
INFO - 2021-08-19 08:29:12 --> Language Class Initialized
INFO - 2021-08-19 08:29:12 --> Config Class Initialized
INFO - 2021-08-19 08:29:12 --> Loader Class Initialized
INFO - 2021-08-19 08:29:12 --> Helper loaded: url_helper
INFO - 2021-08-19 08:29:12 --> Helper loaded: file_helper
INFO - 2021-08-19 08:29:12 --> Helper loaded: form_helper
INFO - 2021-08-19 08:29:12 --> Helper loaded: my_helper
INFO - 2021-08-19 08:29:12 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:29:12 --> Controller Class Initialized
INFO - 2021-08-19 08:29:14 --> Config Class Initialized
INFO - 2021-08-19 08:29:14 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:29:14 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:29:14 --> Utf8 Class Initialized
INFO - 2021-08-19 08:29:14 --> URI Class Initialized
INFO - 2021-08-19 08:29:14 --> Router Class Initialized
INFO - 2021-08-19 08:29:14 --> Output Class Initialized
INFO - 2021-08-19 08:29:14 --> Security Class Initialized
DEBUG - 2021-08-19 08:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:29:14 --> Input Class Initialized
INFO - 2021-08-19 08:29:14 --> Language Class Initialized
INFO - 2021-08-19 08:29:14 --> Language Class Initialized
INFO - 2021-08-19 08:29:14 --> Config Class Initialized
INFO - 2021-08-19 08:29:14 --> Loader Class Initialized
INFO - 2021-08-19 08:29:14 --> Helper loaded: url_helper
INFO - 2021-08-19 08:29:14 --> Helper loaded: file_helper
INFO - 2021-08-19 08:29:14 --> Helper loaded: form_helper
INFO - 2021-08-19 08:29:14 --> Helper loaded: my_helper
INFO - 2021-08-19 08:29:14 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:29:14 --> Controller Class Initialized
INFO - 2021-08-19 08:29:19 --> Config Class Initialized
INFO - 2021-08-19 08:29:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:29:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:29:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:29:19 --> URI Class Initialized
INFO - 2021-08-19 08:29:19 --> Router Class Initialized
INFO - 2021-08-19 08:29:19 --> Output Class Initialized
INFO - 2021-08-19 08:29:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:29:19 --> Input Class Initialized
INFO - 2021-08-19 08:29:19 --> Language Class Initialized
INFO - 2021-08-19 08:29:19 --> Language Class Initialized
INFO - 2021-08-19 08:29:19 --> Config Class Initialized
INFO - 2021-08-19 08:29:19 --> Loader Class Initialized
INFO - 2021-08-19 08:29:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:29:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:29:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:29:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:29:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:29:19 --> Controller Class Initialized
INFO - 2021-08-19 08:29:19 --> Helper loaded: cookie_helper
INFO - 2021-08-19 08:29:19 --> Config Class Initialized
INFO - 2021-08-19 08:29:19 --> Hooks Class Initialized
DEBUG - 2021-08-19 08:29:19 --> UTF-8 Support Enabled
INFO - 2021-08-19 08:29:19 --> Utf8 Class Initialized
INFO - 2021-08-19 08:29:19 --> URI Class Initialized
INFO - 2021-08-19 08:29:19 --> Router Class Initialized
INFO - 2021-08-19 08:29:19 --> Output Class Initialized
INFO - 2021-08-19 08:29:19 --> Security Class Initialized
DEBUG - 2021-08-19 08:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-19 08:29:19 --> Input Class Initialized
INFO - 2021-08-19 08:29:19 --> Language Class Initialized
INFO - 2021-08-19 08:29:19 --> Language Class Initialized
INFO - 2021-08-19 08:29:19 --> Config Class Initialized
INFO - 2021-08-19 08:29:19 --> Loader Class Initialized
INFO - 2021-08-19 08:29:19 --> Helper loaded: url_helper
INFO - 2021-08-19 08:29:19 --> Helper loaded: file_helper
INFO - 2021-08-19 08:29:19 --> Helper loaded: form_helper
INFO - 2021-08-19 08:29:19 --> Helper loaded: my_helper
INFO - 2021-08-19 08:29:19 --> Database Driver Class Initialized
DEBUG - 2021-08-19 08:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-19 08:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-19 08:29:19 --> Controller Class Initialized
DEBUG - 2021-08-19 08:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-19 08:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-19 08:29:19 --> Final output sent to browser
DEBUG - 2021-08-19 08:29:19 --> Total execution time: 0.0541
