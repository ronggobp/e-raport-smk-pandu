<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-18 01:10:52 --> Config Class Initialized
INFO - 2020-11-18 01:10:52 --> Hooks Class Initialized
DEBUG - 2020-11-18 01:10:52 --> UTF-8 Support Enabled
INFO - 2020-11-18 01:10:52 --> Utf8 Class Initialized
INFO - 2020-11-18 01:10:52 --> URI Class Initialized
DEBUG - 2020-11-18 01:10:53 --> No URI present. Default controller set.
INFO - 2020-11-18 01:10:53 --> Router Class Initialized
INFO - 2020-11-18 01:10:53 --> Output Class Initialized
INFO - 2020-11-18 01:10:53 --> Security Class Initialized
DEBUG - 2020-11-18 01:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 01:10:53 --> Input Class Initialized
INFO - 2020-11-18 01:10:53 --> Language Class Initialized
INFO - 2020-11-18 01:10:53 --> Language Class Initialized
INFO - 2020-11-18 01:10:53 --> Config Class Initialized
INFO - 2020-11-18 01:10:53 --> Loader Class Initialized
INFO - 2020-11-18 01:10:53 --> Helper loaded: url_helper
INFO - 2020-11-18 01:10:53 --> Helper loaded: file_helper
INFO - 2020-11-18 01:10:53 --> Helper loaded: form_helper
INFO - 2020-11-18 01:10:53 --> Helper loaded: my_helper
INFO - 2020-11-18 01:10:53 --> Database Driver Class Initialized
DEBUG - 2020-11-18 01:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 01:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 01:10:53 --> Controller Class Initialized
INFO - 2020-11-18 01:10:54 --> Config Class Initialized
INFO - 2020-11-18 01:10:54 --> Hooks Class Initialized
DEBUG - 2020-11-18 01:10:54 --> UTF-8 Support Enabled
INFO - 2020-11-18 01:10:54 --> Utf8 Class Initialized
INFO - 2020-11-18 01:10:54 --> URI Class Initialized
INFO - 2020-11-18 01:10:54 --> Router Class Initialized
INFO - 2020-11-18 01:10:54 --> Output Class Initialized
INFO - 2020-11-18 01:10:54 --> Security Class Initialized
DEBUG - 2020-11-18 01:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 01:10:54 --> Input Class Initialized
INFO - 2020-11-18 01:10:54 --> Language Class Initialized
INFO - 2020-11-18 01:10:54 --> Language Class Initialized
INFO - 2020-11-18 01:10:54 --> Config Class Initialized
INFO - 2020-11-18 01:10:54 --> Loader Class Initialized
INFO - 2020-11-18 01:10:54 --> Helper loaded: url_helper
INFO - 2020-11-18 01:10:54 --> Helper loaded: file_helper
INFO - 2020-11-18 01:10:54 --> Helper loaded: form_helper
INFO - 2020-11-18 01:10:54 --> Helper loaded: my_helper
INFO - 2020-11-18 01:10:54 --> Database Driver Class Initialized
DEBUG - 2020-11-18 01:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 01:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 01:10:54 --> Controller Class Initialized
DEBUG - 2020-11-18 01:10:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-18 01:10:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 01:10:54 --> Final output sent to browser
DEBUG - 2020-11-18 01:10:54 --> Total execution time: 0.4159
INFO - 2020-11-18 02:16:45 --> Config Class Initialized
INFO - 2020-11-18 02:16:45 --> Hooks Class Initialized
DEBUG - 2020-11-18 02:16:45 --> UTF-8 Support Enabled
INFO - 2020-11-18 02:16:45 --> Utf8 Class Initialized
INFO - 2020-11-18 02:16:45 --> URI Class Initialized
INFO - 2020-11-18 02:16:45 --> Router Class Initialized
INFO - 2020-11-18 02:16:45 --> Output Class Initialized
INFO - 2020-11-18 02:16:45 --> Security Class Initialized
DEBUG - 2020-11-18 02:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 02:16:45 --> Input Class Initialized
INFO - 2020-11-18 02:16:45 --> Language Class Initialized
INFO - 2020-11-18 02:16:45 --> Language Class Initialized
INFO - 2020-11-18 02:16:45 --> Config Class Initialized
INFO - 2020-11-18 02:16:45 --> Loader Class Initialized
INFO - 2020-11-18 02:16:45 --> Helper loaded: url_helper
INFO - 2020-11-18 02:16:45 --> Helper loaded: file_helper
INFO - 2020-11-18 02:16:45 --> Helper loaded: form_helper
INFO - 2020-11-18 02:16:45 --> Helper loaded: my_helper
INFO - 2020-11-18 02:16:45 --> Database Driver Class Initialized
DEBUG - 2020-11-18 02:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 02:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 02:16:45 --> Controller Class Initialized
INFO - 2020-11-18 02:16:46 --> Helper loaded: cookie_helper
INFO - 2020-11-18 02:16:46 --> Final output sent to browser
DEBUG - 2020-11-18 02:16:46 --> Total execution time: 0.3219
INFO - 2020-11-18 02:16:47 --> Config Class Initialized
INFO - 2020-11-18 02:16:47 --> Hooks Class Initialized
DEBUG - 2020-11-18 02:16:47 --> UTF-8 Support Enabled
INFO - 2020-11-18 02:16:47 --> Utf8 Class Initialized
INFO - 2020-11-18 02:16:47 --> URI Class Initialized
INFO - 2020-11-18 02:16:47 --> Router Class Initialized
INFO - 2020-11-18 02:16:47 --> Output Class Initialized
INFO - 2020-11-18 02:16:47 --> Security Class Initialized
DEBUG - 2020-11-18 02:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 02:16:47 --> Input Class Initialized
INFO - 2020-11-18 02:16:47 --> Language Class Initialized
INFO - 2020-11-18 02:16:47 --> Language Class Initialized
INFO - 2020-11-18 02:16:47 --> Config Class Initialized
INFO - 2020-11-18 02:16:47 --> Loader Class Initialized
INFO - 2020-11-18 02:16:47 --> Helper loaded: url_helper
INFO - 2020-11-18 02:16:47 --> Helper loaded: file_helper
INFO - 2020-11-18 02:16:47 --> Helper loaded: form_helper
INFO - 2020-11-18 02:16:47 --> Helper loaded: my_helper
INFO - 2020-11-18 02:16:47 --> Database Driver Class Initialized
DEBUG - 2020-11-18 02:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 02:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 02:16:47 --> Controller Class Initialized
DEBUG - 2020-11-18 02:16:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-18 02:16:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 02:16:47 --> Final output sent to browser
DEBUG - 2020-11-18 02:16:48 --> Total execution time: 0.3978
INFO - 2020-11-18 02:16:54 --> Config Class Initialized
INFO - 2020-11-18 02:16:54 --> Hooks Class Initialized
DEBUG - 2020-11-18 02:16:54 --> UTF-8 Support Enabled
INFO - 2020-11-18 02:16:54 --> Utf8 Class Initialized
INFO - 2020-11-18 02:16:54 --> URI Class Initialized
INFO - 2020-11-18 02:16:54 --> Router Class Initialized
INFO - 2020-11-18 02:16:54 --> Output Class Initialized
INFO - 2020-11-18 02:16:54 --> Security Class Initialized
DEBUG - 2020-11-18 02:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 02:16:54 --> Input Class Initialized
INFO - 2020-11-18 02:16:54 --> Language Class Initialized
INFO - 2020-11-18 02:16:54 --> Language Class Initialized
INFO - 2020-11-18 02:16:54 --> Config Class Initialized
INFO - 2020-11-18 02:16:54 --> Loader Class Initialized
INFO - 2020-11-18 02:16:54 --> Helper loaded: url_helper
INFO - 2020-11-18 02:16:54 --> Helper loaded: file_helper
INFO - 2020-11-18 02:16:54 --> Helper loaded: form_helper
INFO - 2020-11-18 02:16:54 --> Helper loaded: my_helper
INFO - 2020-11-18 02:16:54 --> Database Driver Class Initialized
DEBUG - 2020-11-18 02:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 02:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 02:16:55 --> Controller Class Initialized
DEBUG - 2020-11-18 02:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-18 02:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 02:16:55 --> Final output sent to browser
DEBUG - 2020-11-18 02:16:55 --> Total execution time: 0.2855
INFO - 2020-11-18 03:17:27 --> Config Class Initialized
INFO - 2020-11-18 03:17:27 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:17:27 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:17:27 --> Utf8 Class Initialized
INFO - 2020-11-18 03:17:27 --> URI Class Initialized
INFO - 2020-11-18 03:17:27 --> Router Class Initialized
INFO - 2020-11-18 03:17:27 --> Output Class Initialized
INFO - 2020-11-18 03:17:27 --> Security Class Initialized
DEBUG - 2020-11-18 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:17:27 --> Input Class Initialized
INFO - 2020-11-18 03:17:27 --> Language Class Initialized
INFO - 2020-11-18 03:17:27 --> Language Class Initialized
INFO - 2020-11-18 03:17:27 --> Config Class Initialized
INFO - 2020-11-18 03:17:27 --> Loader Class Initialized
INFO - 2020-11-18 03:17:27 --> Helper loaded: url_helper
INFO - 2020-11-18 03:17:27 --> Helper loaded: file_helper
INFO - 2020-11-18 03:17:27 --> Helper loaded: form_helper
INFO - 2020-11-18 03:17:27 --> Helper loaded: my_helper
INFO - 2020-11-18 03:17:27 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:17:27 --> Controller Class Initialized
INFO - 2020-11-18 03:17:27 --> Helper loaded: cookie_helper
INFO - 2020-11-18 03:17:27 --> Config Class Initialized
INFO - 2020-11-18 03:17:27 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:17:27 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:17:27 --> Utf8 Class Initialized
INFO - 2020-11-18 03:17:27 --> URI Class Initialized
INFO - 2020-11-18 03:17:27 --> Router Class Initialized
INFO - 2020-11-18 03:17:27 --> Output Class Initialized
INFO - 2020-11-18 03:17:27 --> Security Class Initialized
DEBUG - 2020-11-18 03:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:17:27 --> Input Class Initialized
INFO - 2020-11-18 03:17:27 --> Language Class Initialized
INFO - 2020-11-18 03:17:27 --> Language Class Initialized
INFO - 2020-11-18 03:17:27 --> Config Class Initialized
INFO - 2020-11-18 03:17:27 --> Loader Class Initialized
INFO - 2020-11-18 03:17:27 --> Helper loaded: url_helper
INFO - 2020-11-18 03:17:27 --> Helper loaded: file_helper
INFO - 2020-11-18 03:17:27 --> Helper loaded: form_helper
INFO - 2020-11-18 03:17:27 --> Helper loaded: my_helper
INFO - 2020-11-18 03:17:27 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:17:28 --> Controller Class Initialized
DEBUG - 2020-11-18 03:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-18 03:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:17:28 --> Final output sent to browser
DEBUG - 2020-11-18 03:17:28 --> Total execution time: 0.2387
INFO - 2020-11-18 03:17:45 --> Config Class Initialized
INFO - 2020-11-18 03:17:45 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:17:45 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:17:45 --> Utf8 Class Initialized
INFO - 2020-11-18 03:17:45 --> URI Class Initialized
INFO - 2020-11-18 03:17:45 --> Router Class Initialized
INFO - 2020-11-18 03:17:45 --> Output Class Initialized
INFO - 2020-11-18 03:17:45 --> Security Class Initialized
DEBUG - 2020-11-18 03:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:17:45 --> Input Class Initialized
INFO - 2020-11-18 03:17:45 --> Language Class Initialized
INFO - 2020-11-18 03:17:45 --> Language Class Initialized
INFO - 2020-11-18 03:17:45 --> Config Class Initialized
INFO - 2020-11-18 03:17:45 --> Loader Class Initialized
INFO - 2020-11-18 03:17:45 --> Helper loaded: url_helper
INFO - 2020-11-18 03:17:45 --> Helper loaded: file_helper
INFO - 2020-11-18 03:17:45 --> Helper loaded: form_helper
INFO - 2020-11-18 03:17:45 --> Helper loaded: my_helper
INFO - 2020-11-18 03:17:45 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:17:45 --> Controller Class Initialized
INFO - 2020-11-18 03:17:45 --> Helper loaded: cookie_helper
INFO - 2020-11-18 03:17:45 --> Final output sent to browser
DEBUG - 2020-11-18 03:17:45 --> Total execution time: 0.2678
INFO - 2020-11-18 03:17:46 --> Config Class Initialized
INFO - 2020-11-18 03:17:46 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:17:46 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:17:46 --> Utf8 Class Initialized
INFO - 2020-11-18 03:17:46 --> URI Class Initialized
INFO - 2020-11-18 03:17:46 --> Router Class Initialized
INFO - 2020-11-18 03:17:46 --> Output Class Initialized
INFO - 2020-11-18 03:17:46 --> Security Class Initialized
DEBUG - 2020-11-18 03:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:17:46 --> Input Class Initialized
INFO - 2020-11-18 03:17:46 --> Language Class Initialized
INFO - 2020-11-18 03:17:46 --> Language Class Initialized
INFO - 2020-11-18 03:17:46 --> Config Class Initialized
INFO - 2020-11-18 03:17:46 --> Loader Class Initialized
INFO - 2020-11-18 03:17:46 --> Helper loaded: url_helper
INFO - 2020-11-18 03:17:46 --> Helper loaded: file_helper
INFO - 2020-11-18 03:17:46 --> Helper loaded: form_helper
INFO - 2020-11-18 03:17:46 --> Helper loaded: my_helper
INFO - 2020-11-18 03:17:46 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:17:46 --> Controller Class Initialized
DEBUG - 2020-11-18 03:17:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-18 03:17:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:17:46 --> Final output sent to browser
DEBUG - 2020-11-18 03:17:46 --> Total execution time: 0.3029
INFO - 2020-11-18 03:38:18 --> Config Class Initialized
INFO - 2020-11-18 03:38:18 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:38:18 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:38:18 --> Utf8 Class Initialized
INFO - 2020-11-18 03:38:18 --> URI Class Initialized
INFO - 2020-11-18 03:38:18 --> Router Class Initialized
INFO - 2020-11-18 03:38:18 --> Output Class Initialized
INFO - 2020-11-18 03:38:18 --> Security Class Initialized
DEBUG - 2020-11-18 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:38:18 --> Input Class Initialized
INFO - 2020-11-18 03:38:18 --> Language Class Initialized
INFO - 2020-11-18 03:38:18 --> Language Class Initialized
INFO - 2020-11-18 03:38:18 --> Config Class Initialized
INFO - 2020-11-18 03:38:18 --> Loader Class Initialized
INFO - 2020-11-18 03:38:18 --> Helper loaded: url_helper
INFO - 2020-11-18 03:38:18 --> Helper loaded: file_helper
INFO - 2020-11-18 03:38:18 --> Helper loaded: form_helper
INFO - 2020-11-18 03:38:18 --> Helper loaded: my_helper
INFO - 2020-11-18 03:38:18 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:38:18 --> Controller Class Initialized
INFO - 2020-11-18 03:38:18 --> Helper loaded: cookie_helper
INFO - 2020-11-18 03:38:18 --> Config Class Initialized
INFO - 2020-11-18 03:38:18 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:38:18 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:38:18 --> Utf8 Class Initialized
INFO - 2020-11-18 03:38:18 --> URI Class Initialized
INFO - 2020-11-18 03:38:18 --> Router Class Initialized
INFO - 2020-11-18 03:38:18 --> Output Class Initialized
INFO - 2020-11-18 03:38:18 --> Security Class Initialized
DEBUG - 2020-11-18 03:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:38:18 --> Input Class Initialized
INFO - 2020-11-18 03:38:18 --> Language Class Initialized
INFO - 2020-11-18 03:38:18 --> Language Class Initialized
INFO - 2020-11-18 03:38:18 --> Config Class Initialized
INFO - 2020-11-18 03:38:18 --> Loader Class Initialized
INFO - 2020-11-18 03:38:18 --> Helper loaded: url_helper
INFO - 2020-11-18 03:38:18 --> Helper loaded: file_helper
INFO - 2020-11-18 03:38:18 --> Helper loaded: form_helper
INFO - 2020-11-18 03:38:18 --> Helper loaded: my_helper
INFO - 2020-11-18 03:38:18 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:38:19 --> Controller Class Initialized
DEBUG - 2020-11-18 03:38:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-18 03:38:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:38:19 --> Final output sent to browser
DEBUG - 2020-11-18 03:38:19 --> Total execution time: 0.2431
INFO - 2020-11-18 03:38:25 --> Config Class Initialized
INFO - 2020-11-18 03:38:25 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:38:25 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:38:25 --> Utf8 Class Initialized
INFO - 2020-11-18 03:38:25 --> URI Class Initialized
INFO - 2020-11-18 03:38:25 --> Router Class Initialized
INFO - 2020-11-18 03:38:25 --> Output Class Initialized
INFO - 2020-11-18 03:38:25 --> Security Class Initialized
DEBUG - 2020-11-18 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:38:25 --> Input Class Initialized
INFO - 2020-11-18 03:38:25 --> Language Class Initialized
INFO - 2020-11-18 03:38:25 --> Language Class Initialized
INFO - 2020-11-18 03:38:25 --> Config Class Initialized
INFO - 2020-11-18 03:38:25 --> Loader Class Initialized
INFO - 2020-11-18 03:38:25 --> Helper loaded: url_helper
INFO - 2020-11-18 03:38:25 --> Helper loaded: file_helper
INFO - 2020-11-18 03:38:25 --> Helper loaded: form_helper
INFO - 2020-11-18 03:38:25 --> Helper loaded: my_helper
INFO - 2020-11-18 03:38:25 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:38:26 --> Controller Class Initialized
INFO - 2020-11-18 03:38:26 --> Helper loaded: cookie_helper
INFO - 2020-11-18 03:38:26 --> Final output sent to browser
DEBUG - 2020-11-18 03:38:26 --> Total execution time: 0.2652
INFO - 2020-11-18 03:38:27 --> Config Class Initialized
INFO - 2020-11-18 03:38:27 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:38:27 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:38:27 --> Utf8 Class Initialized
INFO - 2020-11-18 03:38:27 --> URI Class Initialized
INFO - 2020-11-18 03:38:27 --> Router Class Initialized
INFO - 2020-11-18 03:38:27 --> Output Class Initialized
INFO - 2020-11-18 03:38:27 --> Security Class Initialized
DEBUG - 2020-11-18 03:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:38:27 --> Input Class Initialized
INFO - 2020-11-18 03:38:27 --> Language Class Initialized
INFO - 2020-11-18 03:38:27 --> Language Class Initialized
INFO - 2020-11-18 03:38:27 --> Config Class Initialized
INFO - 2020-11-18 03:38:27 --> Loader Class Initialized
INFO - 2020-11-18 03:38:27 --> Helper loaded: url_helper
INFO - 2020-11-18 03:38:27 --> Helper loaded: file_helper
INFO - 2020-11-18 03:38:27 --> Helper loaded: form_helper
INFO - 2020-11-18 03:38:27 --> Helper loaded: my_helper
INFO - 2020-11-18 03:38:27 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:38:27 --> Controller Class Initialized
DEBUG - 2020-11-18 03:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-18 03:38:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:38:27 --> Final output sent to browser
DEBUG - 2020-11-18 03:38:27 --> Total execution time: 0.2961
INFO - 2020-11-18 03:38:29 --> Config Class Initialized
INFO - 2020-11-18 03:38:29 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:38:29 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:38:29 --> Utf8 Class Initialized
INFO - 2020-11-18 03:38:29 --> URI Class Initialized
INFO - 2020-11-18 03:38:29 --> Router Class Initialized
INFO - 2020-11-18 03:38:29 --> Output Class Initialized
INFO - 2020-11-18 03:38:29 --> Security Class Initialized
DEBUG - 2020-11-18 03:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:38:29 --> Input Class Initialized
INFO - 2020-11-18 03:38:29 --> Language Class Initialized
INFO - 2020-11-18 03:38:29 --> Language Class Initialized
INFO - 2020-11-18 03:38:30 --> Config Class Initialized
INFO - 2020-11-18 03:38:30 --> Loader Class Initialized
INFO - 2020-11-18 03:38:30 --> Helper loaded: url_helper
INFO - 2020-11-18 03:38:30 --> Helper loaded: file_helper
INFO - 2020-11-18 03:38:30 --> Helper loaded: form_helper
INFO - 2020-11-18 03:38:30 --> Helper loaded: my_helper
INFO - 2020-11-18 03:38:30 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:38:30 --> Controller Class Initialized
DEBUG - 2020-11-18 03:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 03:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:38:30 --> Final output sent to browser
DEBUG - 2020-11-18 03:38:30 --> Total execution time: 0.2615
INFO - 2020-11-18 03:50:06 --> Config Class Initialized
INFO - 2020-11-18 03:50:06 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:50:06 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:50:06 --> Utf8 Class Initialized
INFO - 2020-11-18 03:50:06 --> URI Class Initialized
INFO - 2020-11-18 03:50:06 --> Router Class Initialized
INFO - 2020-11-18 03:50:06 --> Output Class Initialized
INFO - 2020-11-18 03:50:06 --> Security Class Initialized
DEBUG - 2020-11-18 03:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:50:06 --> Input Class Initialized
INFO - 2020-11-18 03:50:06 --> Language Class Initialized
INFO - 2020-11-18 03:50:06 --> Language Class Initialized
INFO - 2020-11-18 03:50:06 --> Config Class Initialized
INFO - 2020-11-18 03:50:06 --> Loader Class Initialized
INFO - 2020-11-18 03:50:06 --> Helper loaded: url_helper
INFO - 2020-11-18 03:50:06 --> Helper loaded: file_helper
INFO - 2020-11-18 03:50:06 --> Helper loaded: form_helper
INFO - 2020-11-18 03:50:06 --> Helper loaded: my_helper
INFO - 2020-11-18 03:50:06 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:50:06 --> Controller Class Initialized
DEBUG - 2020-11-18 03:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 03:50:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:50:06 --> Final output sent to browser
DEBUG - 2020-11-18 03:50:06 --> Total execution time: 0.2029
INFO - 2020-11-18 03:51:34 --> Config Class Initialized
INFO - 2020-11-18 03:51:34 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:51:34 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:51:34 --> Utf8 Class Initialized
INFO - 2020-11-18 03:51:34 --> URI Class Initialized
INFO - 2020-11-18 03:51:34 --> Router Class Initialized
INFO - 2020-11-18 03:51:34 --> Output Class Initialized
INFO - 2020-11-18 03:51:34 --> Security Class Initialized
DEBUG - 2020-11-18 03:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:51:34 --> Input Class Initialized
INFO - 2020-11-18 03:51:34 --> Language Class Initialized
INFO - 2020-11-18 03:51:34 --> Language Class Initialized
INFO - 2020-11-18 03:51:34 --> Config Class Initialized
INFO - 2020-11-18 03:51:34 --> Loader Class Initialized
INFO - 2020-11-18 03:51:34 --> Helper loaded: url_helper
INFO - 2020-11-18 03:51:34 --> Helper loaded: file_helper
INFO - 2020-11-18 03:51:34 --> Helper loaded: form_helper
INFO - 2020-11-18 03:51:34 --> Helper loaded: my_helper
INFO - 2020-11-18 03:51:34 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:51:34 --> Controller Class Initialized
DEBUG - 2020-11-18 03:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 03:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:51:34 --> Final output sent to browser
DEBUG - 2020-11-18 03:51:34 --> Total execution time: 0.2139
INFO - 2020-11-18 03:51:51 --> Config Class Initialized
INFO - 2020-11-18 03:51:51 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:51:51 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:51:51 --> Utf8 Class Initialized
INFO - 2020-11-18 03:51:51 --> URI Class Initialized
INFO - 2020-11-18 03:51:51 --> Router Class Initialized
INFO - 2020-11-18 03:51:51 --> Output Class Initialized
INFO - 2020-11-18 03:51:51 --> Security Class Initialized
DEBUG - 2020-11-18 03:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:51:51 --> Input Class Initialized
INFO - 2020-11-18 03:51:51 --> Language Class Initialized
INFO - 2020-11-18 03:51:51 --> Language Class Initialized
INFO - 2020-11-18 03:51:51 --> Config Class Initialized
INFO - 2020-11-18 03:51:51 --> Loader Class Initialized
INFO - 2020-11-18 03:51:51 --> Helper loaded: url_helper
INFO - 2020-11-18 03:51:51 --> Helper loaded: file_helper
INFO - 2020-11-18 03:51:51 --> Helper loaded: form_helper
INFO - 2020-11-18 03:51:51 --> Helper loaded: my_helper
INFO - 2020-11-18 03:51:51 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:51:51 --> Controller Class Initialized
DEBUG - 2020-11-18 03:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 03:51:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:51:51 --> Final output sent to browser
DEBUG - 2020-11-18 03:51:51 --> Total execution time: 0.2496
INFO - 2020-11-18 03:56:32 --> Config Class Initialized
INFO - 2020-11-18 03:56:33 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:56:33 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:56:33 --> Utf8 Class Initialized
INFO - 2020-11-18 03:56:33 --> URI Class Initialized
INFO - 2020-11-18 03:56:33 --> Router Class Initialized
INFO - 2020-11-18 03:56:33 --> Output Class Initialized
INFO - 2020-11-18 03:56:33 --> Security Class Initialized
DEBUG - 2020-11-18 03:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:56:33 --> Input Class Initialized
INFO - 2020-11-18 03:56:33 --> Language Class Initialized
INFO - 2020-11-18 03:56:33 --> Language Class Initialized
INFO - 2020-11-18 03:56:33 --> Config Class Initialized
INFO - 2020-11-18 03:56:33 --> Loader Class Initialized
INFO - 2020-11-18 03:56:33 --> Helper loaded: url_helper
INFO - 2020-11-18 03:56:33 --> Helper loaded: file_helper
INFO - 2020-11-18 03:56:33 --> Helper loaded: form_helper
INFO - 2020-11-18 03:56:33 --> Helper loaded: my_helper
INFO - 2020-11-18 03:56:33 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:56:33 --> Controller Class Initialized
ERROR - 2020-11-18 03:56:33 --> Query error: Table 'db_nilai.t_mapel_kd' doesn't exist - Invalid query: SELECT id, nama_kd FROM t_mapel_kd 
                                    WHERE jenis = 'Sso'
INFO - 2020-11-18 03:56:33 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-18 03:57:02 --> Config Class Initialized
INFO - 2020-11-18 03:57:02 --> Hooks Class Initialized
DEBUG - 2020-11-18 03:57:02 --> UTF-8 Support Enabled
INFO - 2020-11-18 03:57:02 --> Utf8 Class Initialized
INFO - 2020-11-18 03:57:02 --> URI Class Initialized
INFO - 2020-11-18 03:57:02 --> Router Class Initialized
INFO - 2020-11-18 03:57:02 --> Output Class Initialized
INFO - 2020-11-18 03:57:02 --> Security Class Initialized
DEBUG - 2020-11-18 03:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 03:57:02 --> Input Class Initialized
INFO - 2020-11-18 03:57:02 --> Language Class Initialized
INFO - 2020-11-18 03:57:02 --> Language Class Initialized
INFO - 2020-11-18 03:57:02 --> Config Class Initialized
INFO - 2020-11-18 03:57:02 --> Loader Class Initialized
INFO - 2020-11-18 03:57:02 --> Helper loaded: url_helper
INFO - 2020-11-18 03:57:02 --> Helper loaded: file_helper
INFO - 2020-11-18 03:57:02 --> Helper loaded: form_helper
INFO - 2020-11-18 03:57:02 --> Helper loaded: my_helper
INFO - 2020-11-18 03:57:02 --> Database Driver Class Initialized
DEBUG - 2020-11-18 03:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 03:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 03:57:02 --> Controller Class Initialized
DEBUG - 2020-11-18 03:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 03:57:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 03:57:02 --> Final output sent to browser
DEBUG - 2020-11-18 03:57:02 --> Total execution time: 0.2252
INFO - 2020-11-18 04:17:30 --> Config Class Initialized
INFO - 2020-11-18 04:17:30 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:17:30 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:17:30 --> Utf8 Class Initialized
INFO - 2020-11-18 04:17:30 --> URI Class Initialized
INFO - 2020-11-18 04:17:30 --> Router Class Initialized
INFO - 2020-11-18 04:17:30 --> Output Class Initialized
INFO - 2020-11-18 04:17:30 --> Security Class Initialized
DEBUG - 2020-11-18 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:17:30 --> Input Class Initialized
INFO - 2020-11-18 04:17:30 --> Language Class Initialized
INFO - 2020-11-18 04:17:30 --> Language Class Initialized
INFO - 2020-11-18 04:17:30 --> Config Class Initialized
INFO - 2020-11-18 04:17:30 --> Loader Class Initialized
INFO - 2020-11-18 04:17:30 --> Helper loaded: url_helper
INFO - 2020-11-18 04:17:30 --> Helper loaded: file_helper
INFO - 2020-11-18 04:17:30 --> Helper loaded: form_helper
INFO - 2020-11-18 04:17:30 --> Helper loaded: my_helper
INFO - 2020-11-18 04:17:30 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:17:30 --> Controller Class Initialized
DEBUG - 2020-11-18 04:17:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-18 04:17:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:17:30 --> Final output sent to browser
DEBUG - 2020-11-18 04:17:30 --> Total execution time: 0.2530
INFO - 2020-11-18 04:17:55 --> Config Class Initialized
INFO - 2020-11-18 04:17:55 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:17:55 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:17:55 --> Utf8 Class Initialized
INFO - 2020-11-18 04:17:55 --> URI Class Initialized
INFO - 2020-11-18 04:17:55 --> Router Class Initialized
INFO - 2020-11-18 04:17:55 --> Output Class Initialized
INFO - 2020-11-18 04:17:55 --> Security Class Initialized
DEBUG - 2020-11-18 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:17:55 --> Input Class Initialized
INFO - 2020-11-18 04:17:55 --> Language Class Initialized
INFO - 2020-11-18 04:17:55 --> Language Class Initialized
INFO - 2020-11-18 04:17:55 --> Config Class Initialized
INFO - 2020-11-18 04:17:55 --> Loader Class Initialized
INFO - 2020-11-18 04:17:55 --> Helper loaded: url_helper
INFO - 2020-11-18 04:17:55 --> Helper loaded: file_helper
INFO - 2020-11-18 04:17:55 --> Helper loaded: form_helper
INFO - 2020-11-18 04:17:55 --> Helper loaded: my_helper
INFO - 2020-11-18 04:17:55 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:17:55 --> Controller Class Initialized
DEBUG - 2020-11-18 04:17:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-18 04:17:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:17:55 --> Final output sent to browser
DEBUG - 2020-11-18 04:17:55 --> Total execution time: 0.2953
INFO - 2020-11-18 04:18:05 --> Config Class Initialized
INFO - 2020-11-18 04:18:05 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:18:05 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:18:06 --> Utf8 Class Initialized
INFO - 2020-11-18 04:18:06 --> URI Class Initialized
INFO - 2020-11-18 04:18:06 --> Router Class Initialized
INFO - 2020-11-18 04:18:06 --> Output Class Initialized
INFO - 2020-11-18 04:18:06 --> Security Class Initialized
DEBUG - 2020-11-18 04:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:18:06 --> Input Class Initialized
INFO - 2020-11-18 04:18:06 --> Language Class Initialized
INFO - 2020-11-18 04:18:06 --> Language Class Initialized
INFO - 2020-11-18 04:18:06 --> Config Class Initialized
INFO - 2020-11-18 04:18:06 --> Loader Class Initialized
INFO - 2020-11-18 04:18:06 --> Helper loaded: url_helper
INFO - 2020-11-18 04:18:06 --> Helper loaded: file_helper
INFO - 2020-11-18 04:18:06 --> Helper loaded: form_helper
INFO - 2020-11-18 04:18:06 --> Helper loaded: my_helper
INFO - 2020-11-18 04:18:06 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:18:06 --> Controller Class Initialized
INFO - 2020-11-18 04:18:06 --> Final output sent to browser
DEBUG - 2020-11-18 04:18:06 --> Total execution time: 0.2770
INFO - 2020-11-18 04:18:08 --> Config Class Initialized
INFO - 2020-11-18 04:18:08 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:18:08 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:18:08 --> Utf8 Class Initialized
INFO - 2020-11-18 04:18:08 --> URI Class Initialized
INFO - 2020-11-18 04:18:08 --> Router Class Initialized
INFO - 2020-11-18 04:18:08 --> Output Class Initialized
INFO - 2020-11-18 04:18:08 --> Security Class Initialized
DEBUG - 2020-11-18 04:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:18:08 --> Input Class Initialized
INFO - 2020-11-18 04:18:08 --> Language Class Initialized
INFO - 2020-11-18 04:18:08 --> Language Class Initialized
INFO - 2020-11-18 04:18:08 --> Config Class Initialized
INFO - 2020-11-18 04:18:08 --> Loader Class Initialized
INFO - 2020-11-18 04:18:08 --> Helper loaded: url_helper
INFO - 2020-11-18 04:18:08 --> Helper loaded: file_helper
INFO - 2020-11-18 04:18:08 --> Helper loaded: form_helper
INFO - 2020-11-18 04:18:08 --> Helper loaded: my_helper
INFO - 2020-11-18 04:18:08 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:18:08 --> Controller Class Initialized
DEBUG - 2020-11-18 04:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_karakter/views/list.php
DEBUG - 2020-11-18 04:18:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:18:08 --> Final output sent to browser
DEBUG - 2020-11-18 04:18:08 --> Total execution time: 0.2871
INFO - 2020-11-18 04:18:10 --> Config Class Initialized
INFO - 2020-11-18 04:18:11 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:18:11 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:18:11 --> Utf8 Class Initialized
INFO - 2020-11-18 04:18:11 --> URI Class Initialized
INFO - 2020-11-18 04:18:11 --> Router Class Initialized
INFO - 2020-11-18 04:18:11 --> Output Class Initialized
INFO - 2020-11-18 04:18:11 --> Security Class Initialized
DEBUG - 2020-11-18 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:18:11 --> Input Class Initialized
INFO - 2020-11-18 04:18:11 --> Language Class Initialized
INFO - 2020-11-18 04:18:11 --> Language Class Initialized
INFO - 2020-11-18 04:18:11 --> Config Class Initialized
INFO - 2020-11-18 04:18:11 --> Loader Class Initialized
INFO - 2020-11-18 04:18:11 --> Helper loaded: url_helper
INFO - 2020-11-18 04:18:11 --> Helper loaded: file_helper
INFO - 2020-11-18 04:18:11 --> Helper loaded: form_helper
INFO - 2020-11-18 04:18:11 --> Helper loaded: my_helper
INFO - 2020-11-18 04:18:11 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:18:11 --> Controller Class Initialized
DEBUG - 2020-11-18 04:18:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-18 04:18:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:18:11 --> Final output sent to browser
DEBUG - 2020-11-18 04:18:11 --> Total execution time: 0.2226
INFO - 2020-11-18 04:20:01 --> Config Class Initialized
INFO - 2020-11-18 04:20:01 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:20:01 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:20:01 --> Utf8 Class Initialized
INFO - 2020-11-18 04:20:01 --> URI Class Initialized
INFO - 2020-11-18 04:20:01 --> Router Class Initialized
INFO - 2020-11-18 04:20:01 --> Output Class Initialized
INFO - 2020-11-18 04:20:01 --> Security Class Initialized
DEBUG - 2020-11-18 04:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:20:01 --> Input Class Initialized
INFO - 2020-11-18 04:20:01 --> Language Class Initialized
INFO - 2020-11-18 04:20:01 --> Language Class Initialized
INFO - 2020-11-18 04:20:01 --> Config Class Initialized
INFO - 2020-11-18 04:20:01 --> Loader Class Initialized
INFO - 2020-11-18 04:20:01 --> Helper loaded: url_helper
INFO - 2020-11-18 04:20:01 --> Helper loaded: file_helper
INFO - 2020-11-18 04:20:01 --> Helper loaded: form_helper
INFO - 2020-11-18 04:20:01 --> Helper loaded: my_helper
INFO - 2020-11-18 04:20:01 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:20:01 --> Controller Class Initialized
DEBUG - 2020-11-18 04:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 04:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:20:01 --> Final output sent to browser
DEBUG - 2020-11-18 04:20:01 --> Total execution time: 0.2944
INFO - 2020-11-18 04:20:05 --> Config Class Initialized
INFO - 2020-11-18 04:20:05 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:20:05 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:20:05 --> Utf8 Class Initialized
INFO - 2020-11-18 04:20:05 --> URI Class Initialized
INFO - 2020-11-18 04:20:05 --> Router Class Initialized
INFO - 2020-11-18 04:20:05 --> Output Class Initialized
INFO - 2020-11-18 04:20:05 --> Security Class Initialized
DEBUG - 2020-11-18 04:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:20:05 --> Input Class Initialized
INFO - 2020-11-18 04:20:05 --> Language Class Initialized
INFO - 2020-11-18 04:20:05 --> Language Class Initialized
INFO - 2020-11-18 04:20:05 --> Config Class Initialized
INFO - 2020-11-18 04:20:05 --> Loader Class Initialized
INFO - 2020-11-18 04:20:05 --> Helper loaded: url_helper
INFO - 2020-11-18 04:20:05 --> Helper loaded: file_helper
INFO - 2020-11-18 04:20:05 --> Helper loaded: form_helper
INFO - 2020-11-18 04:20:05 --> Helper loaded: my_helper
INFO - 2020-11-18 04:20:05 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:20:05 --> Controller Class Initialized
DEBUG - 2020-11-18 04:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 04:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:20:05 --> Final output sent to browser
DEBUG - 2020-11-18 04:20:05 --> Total execution time: 0.2568
INFO - 2020-11-18 04:20:06 --> Config Class Initialized
INFO - 2020-11-18 04:20:06 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:20:06 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:20:06 --> Utf8 Class Initialized
INFO - 2020-11-18 04:20:06 --> URI Class Initialized
INFO - 2020-11-18 04:20:06 --> Router Class Initialized
INFO - 2020-11-18 04:20:06 --> Output Class Initialized
INFO - 2020-11-18 04:20:06 --> Security Class Initialized
DEBUG - 2020-11-18 04:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:20:06 --> Input Class Initialized
INFO - 2020-11-18 04:20:06 --> Language Class Initialized
INFO - 2020-11-18 04:20:06 --> Language Class Initialized
INFO - 2020-11-18 04:20:06 --> Config Class Initialized
INFO - 2020-11-18 04:20:06 --> Loader Class Initialized
INFO - 2020-11-18 04:20:06 --> Helper loaded: url_helper
INFO - 2020-11-18 04:20:07 --> Helper loaded: file_helper
INFO - 2020-11-18 04:20:07 --> Helper loaded: form_helper
INFO - 2020-11-18 04:20:07 --> Helper loaded: my_helper
INFO - 2020-11-18 04:20:07 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:20:07 --> Controller Class Initialized
DEBUG - 2020-11-18 04:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-11-18 04:20:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:20:07 --> Final output sent to browser
DEBUG - 2020-11-18 04:20:07 --> Total execution time: 0.2669
INFO - 2020-11-18 04:20:08 --> Config Class Initialized
INFO - 2020-11-18 04:20:08 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:20:08 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:20:08 --> Utf8 Class Initialized
INFO - 2020-11-18 04:20:08 --> URI Class Initialized
INFO - 2020-11-18 04:20:08 --> Router Class Initialized
INFO - 2020-11-18 04:20:08 --> Output Class Initialized
INFO - 2020-11-18 04:20:08 --> Security Class Initialized
DEBUG - 2020-11-18 04:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:20:08 --> Input Class Initialized
INFO - 2020-11-18 04:20:08 --> Language Class Initialized
INFO - 2020-11-18 04:20:08 --> Language Class Initialized
INFO - 2020-11-18 04:20:08 --> Config Class Initialized
INFO - 2020-11-18 04:20:08 --> Loader Class Initialized
INFO - 2020-11-18 04:20:08 --> Helper loaded: url_helper
INFO - 2020-11-18 04:20:08 --> Helper loaded: file_helper
INFO - 2020-11-18 04:20:08 --> Helper loaded: form_helper
INFO - 2020-11-18 04:20:08 --> Helper loaded: my_helper
INFO - 2020-11-18 04:20:08 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:20:08 --> Controller Class Initialized
DEBUG - 2020-11-18 04:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-18 04:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:20:08 --> Final output sent to browser
DEBUG - 2020-11-18 04:20:08 --> Total execution time: 0.2271
INFO - 2020-11-18 04:20:10 --> Config Class Initialized
INFO - 2020-11-18 04:20:10 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:20:10 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:20:10 --> Utf8 Class Initialized
INFO - 2020-11-18 04:20:10 --> URI Class Initialized
INFO - 2020-11-18 04:20:10 --> Router Class Initialized
INFO - 2020-11-18 04:20:10 --> Output Class Initialized
INFO - 2020-11-18 04:20:10 --> Security Class Initialized
DEBUG - 2020-11-18 04:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:20:10 --> Input Class Initialized
INFO - 2020-11-18 04:20:10 --> Language Class Initialized
INFO - 2020-11-18 04:20:10 --> Language Class Initialized
INFO - 2020-11-18 04:20:10 --> Config Class Initialized
INFO - 2020-11-18 04:20:10 --> Loader Class Initialized
INFO - 2020-11-18 04:20:10 --> Helper loaded: url_helper
INFO - 2020-11-18 04:20:10 --> Helper loaded: file_helper
INFO - 2020-11-18 04:20:10 --> Helper loaded: form_helper
INFO - 2020-11-18 04:20:10 --> Helper loaded: my_helper
INFO - 2020-11-18 04:20:10 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:20:10 --> Controller Class Initialized
DEBUG - 2020-11-18 04:20:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-18 04:20:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 04:20:10 --> Final output sent to browser
DEBUG - 2020-11-18 04:20:10 --> Total execution time: 0.2751
INFO - 2020-11-18 04:20:12 --> Config Class Initialized
INFO - 2020-11-18 04:20:12 --> Hooks Class Initialized
DEBUG - 2020-11-18 04:20:12 --> UTF-8 Support Enabled
INFO - 2020-11-18 04:20:12 --> Utf8 Class Initialized
INFO - 2020-11-18 04:20:12 --> URI Class Initialized
INFO - 2020-11-18 04:20:12 --> Router Class Initialized
INFO - 2020-11-18 04:20:12 --> Output Class Initialized
INFO - 2020-11-18 04:20:12 --> Security Class Initialized
DEBUG - 2020-11-18 04:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 04:20:12 --> Input Class Initialized
INFO - 2020-11-18 04:20:12 --> Language Class Initialized
INFO - 2020-11-18 04:20:12 --> Language Class Initialized
INFO - 2020-11-18 04:20:12 --> Config Class Initialized
INFO - 2020-11-18 04:20:12 --> Loader Class Initialized
INFO - 2020-11-18 04:20:12 --> Helper loaded: url_helper
INFO - 2020-11-18 04:20:12 --> Helper loaded: file_helper
INFO - 2020-11-18 04:20:12 --> Helper loaded: form_helper
INFO - 2020-11-18 04:20:12 --> Helper loaded: my_helper
INFO - 2020-11-18 04:20:12 --> Database Driver Class Initialized
DEBUG - 2020-11-18 04:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 04:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 04:20:12 --> Controller Class Initialized
INFO - 2020-11-18 04:20:12 --> Final output sent to browser
DEBUG - 2020-11-18 04:20:12 --> Total execution time: 0.1989
INFO - 2020-11-18 05:03:59 --> Config Class Initialized
INFO - 2020-11-18 05:03:59 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:03:59 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:03:59 --> Utf8 Class Initialized
INFO - 2020-11-18 05:03:59 --> URI Class Initialized
INFO - 2020-11-18 05:03:59 --> Router Class Initialized
INFO - 2020-11-18 05:03:59 --> Output Class Initialized
INFO - 2020-11-18 05:03:59 --> Security Class Initialized
DEBUG - 2020-11-18 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:03:59 --> Input Class Initialized
INFO - 2020-11-18 05:03:59 --> Language Class Initialized
INFO - 2020-11-18 05:03:59 --> Language Class Initialized
INFO - 2020-11-18 05:03:59 --> Config Class Initialized
INFO - 2020-11-18 05:03:59 --> Loader Class Initialized
INFO - 2020-11-18 05:03:59 --> Helper loaded: url_helper
INFO - 2020-11-18 05:03:59 --> Helper loaded: file_helper
INFO - 2020-11-18 05:03:59 --> Helper loaded: form_helper
INFO - 2020-11-18 05:03:59 --> Helper loaded: my_helper
INFO - 2020-11-18 05:03:59 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:03:59 --> Controller Class Initialized
DEBUG - 2020-11-18 05:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-18 05:03:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 05:03:59 --> Final output sent to browser
DEBUG - 2020-11-18 05:04:00 --> Total execution time: 0.7515
INFO - 2020-11-18 05:04:35 --> Config Class Initialized
INFO - 2020-11-18 05:04:35 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:04:35 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:04:35 --> Utf8 Class Initialized
INFO - 2020-11-18 05:04:35 --> URI Class Initialized
INFO - 2020-11-18 05:04:35 --> Router Class Initialized
INFO - 2020-11-18 05:04:35 --> Output Class Initialized
INFO - 2020-11-18 05:04:35 --> Security Class Initialized
DEBUG - 2020-11-18 05:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:04:36 --> Input Class Initialized
INFO - 2020-11-18 05:04:36 --> Language Class Initialized
INFO - 2020-11-18 05:04:36 --> Language Class Initialized
INFO - 2020-11-18 05:04:36 --> Config Class Initialized
INFO - 2020-11-18 05:04:36 --> Loader Class Initialized
INFO - 2020-11-18 05:04:36 --> Helper loaded: url_helper
INFO - 2020-11-18 05:04:36 --> Helper loaded: file_helper
INFO - 2020-11-18 05:04:36 --> Helper loaded: form_helper
INFO - 2020-11-18 05:04:36 --> Helper loaded: my_helper
INFO - 2020-11-18 05:04:36 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:04:36 --> Controller Class Initialized
INFO - 2020-11-18 05:04:36 --> Final output sent to browser
DEBUG - 2020-11-18 05:04:36 --> Total execution time: 0.6836
INFO - 2020-11-18 05:08:11 --> Config Class Initialized
INFO - 2020-11-18 05:08:11 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:08:11 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:08:11 --> Utf8 Class Initialized
INFO - 2020-11-18 05:08:11 --> URI Class Initialized
INFO - 2020-11-18 05:08:12 --> Router Class Initialized
INFO - 2020-11-18 05:08:12 --> Output Class Initialized
INFO - 2020-11-18 05:08:12 --> Security Class Initialized
DEBUG - 2020-11-18 05:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:08:12 --> Input Class Initialized
INFO - 2020-11-18 05:08:12 --> Language Class Initialized
INFO - 2020-11-18 05:08:12 --> Language Class Initialized
INFO - 2020-11-18 05:08:12 --> Config Class Initialized
INFO - 2020-11-18 05:08:12 --> Loader Class Initialized
INFO - 2020-11-18 05:08:12 --> Helper loaded: url_helper
INFO - 2020-11-18 05:08:12 --> Helper loaded: file_helper
INFO - 2020-11-18 05:08:12 --> Helper loaded: form_helper
INFO - 2020-11-18 05:08:12 --> Helper loaded: my_helper
INFO - 2020-11-18 05:08:12 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:08:12 --> Controller Class Initialized
INFO - 2020-11-18 05:08:12 --> Final output sent to browser
DEBUG - 2020-11-18 05:08:12 --> Total execution time: 0.7769
INFO - 2020-11-18 05:08:22 --> Config Class Initialized
INFO - 2020-11-18 05:08:22 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:08:22 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:08:22 --> Utf8 Class Initialized
INFO - 2020-11-18 05:08:22 --> URI Class Initialized
INFO - 2020-11-18 05:08:22 --> Router Class Initialized
INFO - 2020-11-18 05:08:22 --> Output Class Initialized
INFO - 2020-11-18 05:08:22 --> Security Class Initialized
DEBUG - 2020-11-18 05:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:08:22 --> Input Class Initialized
INFO - 2020-11-18 05:08:22 --> Language Class Initialized
INFO - 2020-11-18 05:08:22 --> Language Class Initialized
INFO - 2020-11-18 05:08:22 --> Config Class Initialized
INFO - 2020-11-18 05:08:22 --> Loader Class Initialized
INFO - 2020-11-18 05:08:22 --> Helper loaded: url_helper
INFO - 2020-11-18 05:08:22 --> Helper loaded: file_helper
INFO - 2020-11-18 05:08:22 --> Helper loaded: form_helper
INFO - 2020-11-18 05:08:22 --> Helper loaded: my_helper
INFO - 2020-11-18 05:08:22 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:08:22 --> Controller Class Initialized
INFO - 2020-11-18 05:08:22 --> Final output sent to browser
DEBUG - 2020-11-18 05:08:22 --> Total execution time: 0.6377
INFO - 2020-11-18 05:15:32 --> Config Class Initialized
INFO - 2020-11-18 05:15:33 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:15:33 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:15:33 --> Utf8 Class Initialized
INFO - 2020-11-18 05:15:33 --> URI Class Initialized
INFO - 2020-11-18 05:15:33 --> Router Class Initialized
INFO - 2020-11-18 05:15:33 --> Output Class Initialized
INFO - 2020-11-18 05:15:33 --> Security Class Initialized
DEBUG - 2020-11-18 05:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:15:33 --> Input Class Initialized
INFO - 2020-11-18 05:15:33 --> Language Class Initialized
INFO - 2020-11-18 05:15:33 --> Language Class Initialized
INFO - 2020-11-18 05:15:33 --> Config Class Initialized
INFO - 2020-11-18 05:15:33 --> Loader Class Initialized
INFO - 2020-11-18 05:15:33 --> Helper loaded: url_helper
INFO - 2020-11-18 05:15:33 --> Helper loaded: file_helper
INFO - 2020-11-18 05:15:33 --> Helper loaded: form_helper
INFO - 2020-11-18 05:15:33 --> Helper loaded: my_helper
INFO - 2020-11-18 05:15:33 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:15:33 --> Controller Class Initialized
DEBUG - 2020-11-18 05:15:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/cetak.php
INFO - 2020-11-18 05:15:33 --> Final output sent to browser
DEBUG - 2020-11-18 05:15:33 --> Total execution time: 0.2626
INFO - 2020-11-18 05:15:41 --> Config Class Initialized
INFO - 2020-11-18 05:15:41 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:15:41 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:15:41 --> Utf8 Class Initialized
INFO - 2020-11-18 05:15:41 --> URI Class Initialized
INFO - 2020-11-18 05:15:41 --> Router Class Initialized
INFO - 2020-11-18 05:15:41 --> Output Class Initialized
INFO - 2020-11-18 05:15:41 --> Security Class Initialized
DEBUG - 2020-11-18 05:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:15:41 --> Input Class Initialized
INFO - 2020-11-18 05:15:41 --> Language Class Initialized
INFO - 2020-11-18 05:15:41 --> Language Class Initialized
INFO - 2020-11-18 05:15:41 --> Config Class Initialized
INFO - 2020-11-18 05:15:41 --> Loader Class Initialized
INFO - 2020-11-18 05:15:41 --> Helper loaded: url_helper
INFO - 2020-11-18 05:15:41 --> Helper loaded: file_helper
INFO - 2020-11-18 05:15:41 --> Helper loaded: form_helper
INFO - 2020-11-18 05:15:41 --> Helper loaded: my_helper
INFO - 2020-11-18 05:15:41 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:15:41 --> Controller Class Initialized
INFO - 2020-11-18 05:15:41 --> Final output sent to browser
DEBUG - 2020-11-18 05:15:41 --> Total execution time: 0.2579
INFO - 2020-11-18 05:15:49 --> Config Class Initialized
INFO - 2020-11-18 05:15:49 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:15:49 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:15:49 --> Utf8 Class Initialized
INFO - 2020-11-18 05:15:49 --> URI Class Initialized
INFO - 2020-11-18 05:15:49 --> Router Class Initialized
INFO - 2020-11-18 05:15:49 --> Output Class Initialized
INFO - 2020-11-18 05:15:49 --> Security Class Initialized
DEBUG - 2020-11-18 05:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:15:49 --> Input Class Initialized
INFO - 2020-11-18 05:15:49 --> Language Class Initialized
INFO - 2020-11-18 05:15:49 --> Language Class Initialized
INFO - 2020-11-18 05:15:49 --> Config Class Initialized
INFO - 2020-11-18 05:15:49 --> Loader Class Initialized
INFO - 2020-11-18 05:15:49 --> Helper loaded: url_helper
INFO - 2020-11-18 05:15:49 --> Helper loaded: file_helper
INFO - 2020-11-18 05:15:49 --> Helper loaded: form_helper
INFO - 2020-11-18 05:15:49 --> Helper loaded: my_helper
INFO - 2020-11-18 05:15:49 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:15:49 --> Controller Class Initialized
INFO - 2020-11-18 05:15:49 --> Final output sent to browser
DEBUG - 2020-11-18 05:15:49 --> Total execution time: 0.2182
INFO - 2020-11-18 05:16:17 --> Config Class Initialized
INFO - 2020-11-18 05:16:17 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:16:17 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:16:17 --> Utf8 Class Initialized
INFO - 2020-11-18 05:16:17 --> URI Class Initialized
INFO - 2020-11-18 05:16:17 --> Router Class Initialized
INFO - 2020-11-18 05:16:17 --> Output Class Initialized
INFO - 2020-11-18 05:16:17 --> Security Class Initialized
DEBUG - 2020-11-18 05:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:16:17 --> Input Class Initialized
INFO - 2020-11-18 05:16:17 --> Language Class Initialized
INFO - 2020-11-18 05:16:17 --> Language Class Initialized
INFO - 2020-11-18 05:16:17 --> Config Class Initialized
INFO - 2020-11-18 05:16:17 --> Loader Class Initialized
INFO - 2020-11-18 05:16:17 --> Helper loaded: url_helper
INFO - 2020-11-18 05:16:17 --> Helper loaded: file_helper
INFO - 2020-11-18 05:16:18 --> Helper loaded: form_helper
INFO - 2020-11-18 05:16:18 --> Helper loaded: my_helper
INFO - 2020-11-18 05:16:18 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:16:18 --> Controller Class Initialized
INFO - 2020-11-18 05:16:18 --> Final output sent to browser
DEBUG - 2020-11-18 05:16:18 --> Total execution time: 0.2157
INFO - 2020-11-18 05:34:59 --> Config Class Initialized
INFO - 2020-11-18 05:34:59 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:34:59 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:34:59 --> Utf8 Class Initialized
INFO - 2020-11-18 05:34:59 --> URI Class Initialized
INFO - 2020-11-18 05:34:59 --> Router Class Initialized
INFO - 2020-11-18 05:34:59 --> Output Class Initialized
INFO - 2020-11-18 05:34:59 --> Security Class Initialized
DEBUG - 2020-11-18 05:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:34:59 --> Input Class Initialized
INFO - 2020-11-18 05:34:59 --> Language Class Initialized
INFO - 2020-11-18 05:34:59 --> Language Class Initialized
INFO - 2020-11-18 05:34:59 --> Config Class Initialized
INFO - 2020-11-18 05:34:59 --> Loader Class Initialized
INFO - 2020-11-18 05:35:00 --> Helper loaded: url_helper
INFO - 2020-11-18 05:35:00 --> Helper loaded: file_helper
INFO - 2020-11-18 05:35:00 --> Helper loaded: form_helper
INFO - 2020-11-18 05:35:00 --> Helper loaded: my_helper
INFO - 2020-11-18 05:35:00 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:35:00 --> Controller Class Initialized
DEBUG - 2020-11-18 05:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-18 05:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 05:35:00 --> Final output sent to browser
DEBUG - 2020-11-18 05:35:00 --> Total execution time: 0.3444
INFO - 2020-11-18 05:35:02 --> Config Class Initialized
INFO - 2020-11-18 05:35:02 --> Hooks Class Initialized
DEBUG - 2020-11-18 05:35:02 --> UTF-8 Support Enabled
INFO - 2020-11-18 05:35:02 --> Utf8 Class Initialized
INFO - 2020-11-18 05:35:02 --> URI Class Initialized
INFO - 2020-11-18 05:35:02 --> Router Class Initialized
INFO - 2020-11-18 05:35:02 --> Output Class Initialized
INFO - 2020-11-18 05:35:02 --> Security Class Initialized
DEBUG - 2020-11-18 05:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 05:35:02 --> Input Class Initialized
INFO - 2020-11-18 05:35:02 --> Language Class Initialized
INFO - 2020-11-18 05:35:02 --> Language Class Initialized
INFO - 2020-11-18 05:35:02 --> Config Class Initialized
INFO - 2020-11-18 05:35:02 --> Loader Class Initialized
INFO - 2020-11-18 05:35:02 --> Helper loaded: url_helper
INFO - 2020-11-18 05:35:02 --> Helper loaded: file_helper
INFO - 2020-11-18 05:35:02 --> Helper loaded: form_helper
INFO - 2020-11-18 05:35:02 --> Helper loaded: my_helper
INFO - 2020-11-18 05:35:02 --> Database Driver Class Initialized
DEBUG - 2020-11-18 05:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 05:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 05:35:02 --> Controller Class Initialized
INFO - 2020-11-18 05:35:02 --> Final output sent to browser
DEBUG - 2020-11-18 05:35:02 --> Total execution time: 0.2534
INFO - 2020-11-18 09:21:52 --> Config Class Initialized
INFO - 2020-11-18 09:21:52 --> Hooks Class Initialized
DEBUG - 2020-11-18 09:21:52 --> UTF-8 Support Enabled
INFO - 2020-11-18 09:21:52 --> Utf8 Class Initialized
INFO - 2020-11-18 09:21:52 --> URI Class Initialized
INFO - 2020-11-18 09:21:52 --> Router Class Initialized
INFO - 2020-11-18 09:21:52 --> Output Class Initialized
INFO - 2020-11-18 09:21:52 --> Security Class Initialized
DEBUG - 2020-11-18 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 09:21:52 --> Input Class Initialized
INFO - 2020-11-18 09:21:53 --> Language Class Initialized
INFO - 2020-11-18 09:21:53 --> Language Class Initialized
INFO - 2020-11-18 09:21:53 --> Config Class Initialized
INFO - 2020-11-18 09:21:53 --> Loader Class Initialized
INFO - 2020-11-18 09:21:53 --> Helper loaded: url_helper
INFO - 2020-11-18 09:21:53 --> Helper loaded: file_helper
INFO - 2020-11-18 09:21:53 --> Helper loaded: form_helper
INFO - 2020-11-18 09:21:53 --> Helper loaded: my_helper
INFO - 2020-11-18 09:21:53 --> Database Driver Class Initialized
DEBUG - 2020-11-18 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 09:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 09:21:53 --> Controller Class Initialized
INFO - 2020-11-18 09:21:53 --> Helper loaded: cookie_helper
INFO - 2020-11-18 09:21:53 --> Config Class Initialized
INFO - 2020-11-18 09:21:53 --> Hooks Class Initialized
DEBUG - 2020-11-18 09:21:53 --> UTF-8 Support Enabled
INFO - 2020-11-18 09:21:53 --> Utf8 Class Initialized
INFO - 2020-11-18 09:21:53 --> URI Class Initialized
INFO - 2020-11-18 09:21:53 --> Router Class Initialized
INFO - 2020-11-18 09:21:53 --> Output Class Initialized
INFO - 2020-11-18 09:21:53 --> Security Class Initialized
DEBUG - 2020-11-18 09:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-18 09:21:53 --> Input Class Initialized
INFO - 2020-11-18 09:21:53 --> Language Class Initialized
INFO - 2020-11-18 09:21:53 --> Language Class Initialized
INFO - 2020-11-18 09:21:53 --> Config Class Initialized
INFO - 2020-11-18 09:21:53 --> Loader Class Initialized
INFO - 2020-11-18 09:21:53 --> Helper loaded: url_helper
INFO - 2020-11-18 09:21:54 --> Helper loaded: file_helper
INFO - 2020-11-18 09:21:54 --> Helper loaded: form_helper
INFO - 2020-11-18 09:21:54 --> Helper loaded: my_helper
INFO - 2020-11-18 09:21:54 --> Database Driver Class Initialized
DEBUG - 2020-11-18 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-18 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-18 09:21:54 --> Controller Class Initialized
DEBUG - 2020-11-18 09:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-18 09:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-18 09:21:54 --> Final output sent to browser
DEBUG - 2020-11-18 09:21:54 --> Total execution time: 0.7616
