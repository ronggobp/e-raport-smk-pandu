<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-11-20 02:12:17 --> Config Class Initialized
INFO - 2021-11-20 02:12:17 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:12:17 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:12:17 --> Utf8 Class Initialized
INFO - 2021-11-20 02:12:17 --> URI Class Initialized
DEBUG - 2021-11-20 02:12:17 --> No URI present. Default controller set.
INFO - 2021-11-20 02:12:17 --> Router Class Initialized
INFO - 2021-11-20 02:12:17 --> Output Class Initialized
INFO - 2021-11-20 02:12:17 --> Security Class Initialized
DEBUG - 2021-11-20 02:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:12:18 --> Input Class Initialized
INFO - 2021-11-20 02:12:18 --> Language Class Initialized
INFO - 2021-11-20 02:12:18 --> Language Class Initialized
INFO - 2021-11-20 02:12:18 --> Config Class Initialized
INFO - 2021-11-20 02:12:18 --> Loader Class Initialized
INFO - 2021-11-20 02:12:18 --> Helper loaded: url_helper
INFO - 2021-11-20 02:12:18 --> Helper loaded: file_helper
INFO - 2021-11-20 02:12:18 --> Helper loaded: form_helper
INFO - 2021-11-20 02:12:18 --> Helper loaded: my_helper
INFO - 2021-11-20 02:12:18 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:12:18 --> Controller Class Initialized
INFO - 2021-11-20 02:12:18 --> Config Class Initialized
INFO - 2021-11-20 02:12:18 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:12:18 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:12:18 --> Utf8 Class Initialized
INFO - 2021-11-20 02:12:18 --> URI Class Initialized
INFO - 2021-11-20 02:12:18 --> Router Class Initialized
INFO - 2021-11-20 02:12:18 --> Output Class Initialized
INFO - 2021-11-20 02:12:18 --> Security Class Initialized
DEBUG - 2021-11-20 02:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:12:18 --> Input Class Initialized
INFO - 2021-11-20 02:12:18 --> Language Class Initialized
INFO - 2021-11-20 02:12:18 --> Language Class Initialized
INFO - 2021-11-20 02:12:18 --> Config Class Initialized
INFO - 2021-11-20 02:12:18 --> Loader Class Initialized
INFO - 2021-11-20 02:12:18 --> Helper loaded: url_helper
INFO - 2021-11-20 02:12:18 --> Helper loaded: file_helper
INFO - 2021-11-20 02:12:18 --> Helper loaded: form_helper
INFO - 2021-11-20 02:12:18 --> Helper loaded: my_helper
INFO - 2021-11-20 02:12:18 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:12:18 --> Controller Class Initialized
DEBUG - 2021-11-20 02:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 02:12:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:12:18 --> Final output sent to browser
DEBUG - 2021-11-20 02:12:18 --> Total execution time: 0.1239
INFO - 2021-11-20 02:20:32 --> Config Class Initialized
INFO - 2021-11-20 02:20:32 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:32 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:32 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:32 --> URI Class Initialized
INFO - 2021-11-20 02:20:32 --> Router Class Initialized
INFO - 2021-11-20 02:20:32 --> Output Class Initialized
INFO - 2021-11-20 02:20:32 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:32 --> Input Class Initialized
INFO - 2021-11-20 02:20:32 --> Language Class Initialized
INFO - 2021-11-20 02:20:32 --> Language Class Initialized
INFO - 2021-11-20 02:20:32 --> Config Class Initialized
INFO - 2021-11-20 02:20:32 --> Loader Class Initialized
INFO - 2021-11-20 02:20:32 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:32 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:32 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:32 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:32 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:32 --> Controller Class Initialized
INFO - 2021-11-20 02:20:32 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:20:32 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:32 --> Total execution time: 0.1162
INFO - 2021-11-20 02:20:32 --> Config Class Initialized
INFO - 2021-11-20 02:20:32 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:32 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:32 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:32 --> URI Class Initialized
INFO - 2021-11-20 02:20:32 --> Router Class Initialized
INFO - 2021-11-20 02:20:32 --> Output Class Initialized
INFO - 2021-11-20 02:20:32 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:32 --> Input Class Initialized
INFO - 2021-11-20 02:20:32 --> Language Class Initialized
INFO - 2021-11-20 02:20:32 --> Language Class Initialized
INFO - 2021-11-20 02:20:32 --> Config Class Initialized
INFO - 2021-11-20 02:20:32 --> Loader Class Initialized
INFO - 2021-11-20 02:20:32 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:32 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:32 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:33 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:33 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:33 --> Controller Class Initialized
DEBUG - 2021-11-20 02:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 02:20:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:20:34 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:34 --> Total execution time: 1.1644
INFO - 2021-11-20 02:20:36 --> Config Class Initialized
INFO - 2021-11-20 02:20:36 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:36 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:36 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:36 --> URI Class Initialized
INFO - 2021-11-20 02:20:36 --> Router Class Initialized
INFO - 2021-11-20 02:20:36 --> Output Class Initialized
INFO - 2021-11-20 02:20:36 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:36 --> Input Class Initialized
INFO - 2021-11-20 02:20:36 --> Language Class Initialized
INFO - 2021-11-20 02:20:36 --> Language Class Initialized
INFO - 2021-11-20 02:20:36 --> Config Class Initialized
INFO - 2021-11-20 02:20:36 --> Loader Class Initialized
INFO - 2021-11-20 02:20:36 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:36 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:36 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:36 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:36 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:36 --> Controller Class Initialized
DEBUG - 2021-11-20 02:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-11-20 02:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:20:36 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:36 --> Total execution time: 0.1277
INFO - 2021-11-20 02:20:36 --> Config Class Initialized
INFO - 2021-11-20 02:20:36 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:36 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:36 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:36 --> URI Class Initialized
INFO - 2021-11-20 02:20:36 --> Router Class Initialized
INFO - 2021-11-20 02:20:36 --> Output Class Initialized
INFO - 2021-11-20 02:20:36 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:36 --> Input Class Initialized
INFO - 2021-11-20 02:20:36 --> Language Class Initialized
INFO - 2021-11-20 02:20:36 --> Language Class Initialized
INFO - 2021-11-20 02:20:36 --> Config Class Initialized
INFO - 2021-11-20 02:20:36 --> Loader Class Initialized
INFO - 2021-11-20 02:20:36 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:36 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:36 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:36 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:36 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:36 --> Controller Class Initialized
INFO - 2021-11-20 02:20:37 --> Config Class Initialized
INFO - 2021-11-20 02:20:37 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:37 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:37 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:37 --> URI Class Initialized
INFO - 2021-11-20 02:20:37 --> Router Class Initialized
INFO - 2021-11-20 02:20:37 --> Output Class Initialized
INFO - 2021-11-20 02:20:37 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:37 --> Input Class Initialized
INFO - 2021-11-20 02:20:37 --> Language Class Initialized
INFO - 2021-11-20 02:20:37 --> Language Class Initialized
INFO - 2021-11-20 02:20:37 --> Config Class Initialized
INFO - 2021-11-20 02:20:37 --> Loader Class Initialized
INFO - 2021-11-20 02:20:37 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:37 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:37 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:37 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:37 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:37 --> Controller Class Initialized
DEBUG - 2021-11-20 02:20:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-11-20 02:20:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:20:37 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:37 --> Total execution time: 0.0945
INFO - 2021-11-20 02:20:37 --> Config Class Initialized
INFO - 2021-11-20 02:20:37 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:37 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:37 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:37 --> URI Class Initialized
INFO - 2021-11-20 02:20:37 --> Router Class Initialized
INFO - 2021-11-20 02:20:37 --> Output Class Initialized
INFO - 2021-11-20 02:20:37 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:37 --> Input Class Initialized
INFO - 2021-11-20 02:20:37 --> Language Class Initialized
INFO - 2021-11-20 02:20:37 --> Language Class Initialized
INFO - 2021-11-20 02:20:37 --> Config Class Initialized
INFO - 2021-11-20 02:20:37 --> Loader Class Initialized
INFO - 2021-11-20 02:20:37 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:37 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:37 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:37 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:37 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:37 --> Controller Class Initialized
INFO - 2021-11-20 02:20:39 --> Config Class Initialized
INFO - 2021-11-20 02:20:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:39 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:39 --> URI Class Initialized
INFO - 2021-11-20 02:20:39 --> Router Class Initialized
INFO - 2021-11-20 02:20:39 --> Output Class Initialized
INFO - 2021-11-20 02:20:39 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:39 --> Input Class Initialized
INFO - 2021-11-20 02:20:39 --> Language Class Initialized
INFO - 2021-11-20 02:20:39 --> Language Class Initialized
INFO - 2021-11-20 02:20:39 --> Config Class Initialized
INFO - 2021-11-20 02:20:39 --> Loader Class Initialized
INFO - 2021-11-20 02:20:39 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:39 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:39 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:39 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:39 --> Controller Class Initialized
DEBUG - 2021-11-20 02:20:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-20 02:20:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:20:39 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:39 --> Total execution time: 0.1083
INFO - 2021-11-20 02:20:39 --> Config Class Initialized
INFO - 2021-11-20 02:20:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:39 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:39 --> URI Class Initialized
INFO - 2021-11-20 02:20:39 --> Router Class Initialized
INFO - 2021-11-20 02:20:39 --> Output Class Initialized
INFO - 2021-11-20 02:20:39 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:39 --> Input Class Initialized
INFO - 2021-11-20 02:20:39 --> Language Class Initialized
INFO - 2021-11-20 02:20:39 --> Language Class Initialized
INFO - 2021-11-20 02:20:39 --> Config Class Initialized
INFO - 2021-11-20 02:20:39 --> Loader Class Initialized
INFO - 2021-11-20 02:20:39 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:39 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:39 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:39 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:39 --> Controller Class Initialized
INFO - 2021-11-20 02:20:53 --> Config Class Initialized
INFO - 2021-11-20 02:20:53 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:53 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:53 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:53 --> URI Class Initialized
INFO - 2021-11-20 02:20:53 --> Router Class Initialized
INFO - 2021-11-20 02:20:53 --> Output Class Initialized
INFO - 2021-11-20 02:20:53 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:53 --> Input Class Initialized
INFO - 2021-11-20 02:20:53 --> Language Class Initialized
INFO - 2021-11-20 02:20:53 --> Language Class Initialized
INFO - 2021-11-20 02:20:53 --> Config Class Initialized
INFO - 2021-11-20 02:20:53 --> Loader Class Initialized
INFO - 2021-11-20 02:20:53 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:53 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:53 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:53 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:53 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:53 --> Controller Class Initialized
INFO - 2021-11-20 02:20:53 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:53 --> Total execution time: 0.0930
INFO - 2021-11-20 02:20:53 --> Config Class Initialized
INFO - 2021-11-20 02:20:53 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:53 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:53 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:53 --> URI Class Initialized
INFO - 2021-11-20 02:20:53 --> Router Class Initialized
INFO - 2021-11-20 02:20:53 --> Output Class Initialized
INFO - 2021-11-20 02:20:53 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:53 --> Input Class Initialized
INFO - 2021-11-20 02:20:53 --> Language Class Initialized
INFO - 2021-11-20 02:20:53 --> Language Class Initialized
INFO - 2021-11-20 02:20:53 --> Config Class Initialized
INFO - 2021-11-20 02:20:53 --> Loader Class Initialized
INFO - 2021-11-20 02:20:53 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:53 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:53 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:53 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:53 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:53 --> Controller Class Initialized
INFO - 2021-11-20 02:20:57 --> Config Class Initialized
INFO - 2021-11-20 02:20:57 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:57 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:57 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:57 --> URI Class Initialized
INFO - 2021-11-20 02:20:57 --> Router Class Initialized
INFO - 2021-11-20 02:20:57 --> Output Class Initialized
INFO - 2021-11-20 02:20:57 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:57 --> Input Class Initialized
INFO - 2021-11-20 02:20:57 --> Language Class Initialized
INFO - 2021-11-20 02:20:57 --> Language Class Initialized
INFO - 2021-11-20 02:20:57 --> Config Class Initialized
INFO - 2021-11-20 02:20:57 --> Loader Class Initialized
INFO - 2021-11-20 02:20:57 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:57 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:57 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:57 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:57 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:57 --> Controller Class Initialized
INFO - 2021-11-20 02:20:57 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:20:58 --> Config Class Initialized
INFO - 2021-11-20 02:20:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:20:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:20:58 --> Utf8 Class Initialized
INFO - 2021-11-20 02:20:58 --> URI Class Initialized
INFO - 2021-11-20 02:20:58 --> Router Class Initialized
INFO - 2021-11-20 02:20:58 --> Output Class Initialized
INFO - 2021-11-20 02:20:58 --> Security Class Initialized
DEBUG - 2021-11-20 02:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:20:58 --> Input Class Initialized
INFO - 2021-11-20 02:20:58 --> Language Class Initialized
INFO - 2021-11-20 02:20:58 --> Language Class Initialized
INFO - 2021-11-20 02:20:58 --> Config Class Initialized
INFO - 2021-11-20 02:20:58 --> Loader Class Initialized
INFO - 2021-11-20 02:20:58 --> Helper loaded: url_helper
INFO - 2021-11-20 02:20:58 --> Helper loaded: file_helper
INFO - 2021-11-20 02:20:58 --> Helper loaded: form_helper
INFO - 2021-11-20 02:20:58 --> Helper loaded: my_helper
INFO - 2021-11-20 02:20:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:20:58 --> Controller Class Initialized
DEBUG - 2021-11-20 02:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 02:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:20:58 --> Final output sent to browser
DEBUG - 2021-11-20 02:20:58 --> Total execution time: 0.0643
INFO - 2021-11-20 02:23:51 --> Config Class Initialized
INFO - 2021-11-20 02:23:51 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:23:51 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:23:51 --> Utf8 Class Initialized
INFO - 2021-11-20 02:23:51 --> URI Class Initialized
INFO - 2021-11-20 02:23:51 --> Router Class Initialized
INFO - 2021-11-20 02:23:51 --> Output Class Initialized
INFO - 2021-11-20 02:23:51 --> Security Class Initialized
DEBUG - 2021-11-20 02:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:23:51 --> Input Class Initialized
INFO - 2021-11-20 02:23:51 --> Language Class Initialized
INFO - 2021-11-20 02:23:51 --> Language Class Initialized
INFO - 2021-11-20 02:23:51 --> Config Class Initialized
INFO - 2021-11-20 02:23:51 --> Loader Class Initialized
INFO - 2021-11-20 02:23:51 --> Helper loaded: url_helper
INFO - 2021-11-20 02:23:51 --> Helper loaded: file_helper
INFO - 2021-11-20 02:23:51 --> Helper loaded: form_helper
INFO - 2021-11-20 02:23:51 --> Helper loaded: my_helper
INFO - 2021-11-20 02:23:51 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:23:51 --> Controller Class Initialized
INFO - 2021-11-20 02:23:51 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:23:51 --> Final output sent to browser
DEBUG - 2021-11-20 02:23:51 --> Total execution time: 0.0906
INFO - 2021-11-20 02:23:51 --> Config Class Initialized
INFO - 2021-11-20 02:23:51 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:23:51 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:23:51 --> Utf8 Class Initialized
INFO - 2021-11-20 02:23:51 --> URI Class Initialized
INFO - 2021-11-20 02:23:51 --> Router Class Initialized
INFO - 2021-11-20 02:23:51 --> Output Class Initialized
INFO - 2021-11-20 02:23:51 --> Security Class Initialized
DEBUG - 2021-11-20 02:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:23:51 --> Input Class Initialized
INFO - 2021-11-20 02:23:51 --> Language Class Initialized
INFO - 2021-11-20 02:23:51 --> Language Class Initialized
INFO - 2021-11-20 02:23:51 --> Config Class Initialized
INFO - 2021-11-20 02:23:51 --> Loader Class Initialized
INFO - 2021-11-20 02:23:51 --> Helper loaded: url_helper
INFO - 2021-11-20 02:23:51 --> Helper loaded: file_helper
INFO - 2021-11-20 02:23:51 --> Helper loaded: form_helper
INFO - 2021-11-20 02:23:51 --> Helper loaded: my_helper
INFO - 2021-11-20 02:23:51 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:23:51 --> Controller Class Initialized
DEBUG - 2021-11-20 02:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 02:23:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:23:51 --> Final output sent to browser
DEBUG - 2021-11-20 02:23:51 --> Total execution time: 0.2326
INFO - 2021-11-20 02:23:58 --> Config Class Initialized
INFO - 2021-11-20 02:23:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:23:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:23:58 --> Utf8 Class Initialized
INFO - 2021-11-20 02:23:58 --> URI Class Initialized
INFO - 2021-11-20 02:23:58 --> Router Class Initialized
INFO - 2021-11-20 02:23:58 --> Output Class Initialized
INFO - 2021-11-20 02:23:58 --> Security Class Initialized
DEBUG - 2021-11-20 02:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:23:58 --> Input Class Initialized
INFO - 2021-11-20 02:23:58 --> Language Class Initialized
INFO - 2021-11-20 02:23:59 --> Language Class Initialized
INFO - 2021-11-20 02:23:59 --> Config Class Initialized
INFO - 2021-11-20 02:23:59 --> Loader Class Initialized
INFO - 2021-11-20 02:23:59 --> Helper loaded: url_helper
INFO - 2021-11-20 02:23:59 --> Helper loaded: file_helper
INFO - 2021-11-20 02:23:59 --> Helper loaded: form_helper
INFO - 2021-11-20 02:23:59 --> Helper loaded: my_helper
INFO - 2021-11-20 02:23:59 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:23:59 --> Controller Class Initialized
DEBUG - 2021-11-20 02:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-11-20 02:23:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:23:59 --> Final output sent to browser
DEBUG - 2021-11-20 02:23:59 --> Total execution time: 0.1201
INFO - 2021-11-20 02:24:06 --> Config Class Initialized
INFO - 2021-11-20 02:24:06 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:24:06 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:24:06 --> Utf8 Class Initialized
INFO - 2021-11-20 02:24:06 --> URI Class Initialized
INFO - 2021-11-20 02:24:06 --> Router Class Initialized
INFO - 2021-11-20 02:24:06 --> Output Class Initialized
INFO - 2021-11-20 02:24:06 --> Security Class Initialized
DEBUG - 2021-11-20 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:24:06 --> Input Class Initialized
INFO - 2021-11-20 02:24:06 --> Language Class Initialized
INFO - 2021-11-20 02:24:06 --> Language Class Initialized
INFO - 2021-11-20 02:24:06 --> Config Class Initialized
INFO - 2021-11-20 02:24:06 --> Loader Class Initialized
INFO - 2021-11-20 02:24:06 --> Helper loaded: url_helper
INFO - 2021-11-20 02:24:06 --> Helper loaded: file_helper
INFO - 2021-11-20 02:24:06 --> Helper loaded: form_helper
INFO - 2021-11-20 02:24:06 --> Helper loaded: my_helper
INFO - 2021-11-20 02:24:06 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:24:06 --> Controller Class Initialized
DEBUG - 2021-11-20 02:24:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 02:24:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:24:06 --> Final output sent to browser
DEBUG - 2021-11-20 02:24:06 --> Total execution time: 0.1719
INFO - 2021-11-20 02:24:08 --> Config Class Initialized
INFO - 2021-11-20 02:24:08 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:24:08 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:24:08 --> Utf8 Class Initialized
INFO - 2021-11-20 02:24:08 --> URI Class Initialized
INFO - 2021-11-20 02:24:08 --> Router Class Initialized
INFO - 2021-11-20 02:24:08 --> Output Class Initialized
INFO - 2021-11-20 02:24:08 --> Security Class Initialized
DEBUG - 2021-11-20 02:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:24:08 --> Input Class Initialized
INFO - 2021-11-20 02:24:08 --> Language Class Initialized
INFO - 2021-11-20 02:24:08 --> Language Class Initialized
INFO - 2021-11-20 02:24:08 --> Config Class Initialized
INFO - 2021-11-20 02:24:08 --> Loader Class Initialized
INFO - 2021-11-20 02:24:08 --> Helper loaded: url_helper
INFO - 2021-11-20 02:24:08 --> Helper loaded: file_helper
INFO - 2021-11-20 02:24:08 --> Helper loaded: form_helper
INFO - 2021-11-20 02:24:08 --> Helper loaded: my_helper
INFO - 2021-11-20 02:24:08 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:24:08 --> Controller Class Initialized
DEBUG - 2021-11-20 02:24:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-20 02:24:08 --> Final output sent to browser
DEBUG - 2021-11-20 02:24:08 --> Total execution time: 0.2617
INFO - 2021-11-20 02:26:02 --> Config Class Initialized
INFO - 2021-11-20 02:26:02 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:26:02 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:26:02 --> Utf8 Class Initialized
INFO - 2021-11-20 02:26:02 --> URI Class Initialized
INFO - 2021-11-20 02:26:02 --> Router Class Initialized
INFO - 2021-11-20 02:26:02 --> Output Class Initialized
INFO - 2021-11-20 02:26:02 --> Security Class Initialized
DEBUG - 2021-11-20 02:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:26:02 --> Input Class Initialized
INFO - 2021-11-20 02:26:02 --> Language Class Initialized
INFO - 2021-11-20 02:26:02 --> Language Class Initialized
INFO - 2021-11-20 02:26:02 --> Config Class Initialized
INFO - 2021-11-20 02:26:02 --> Loader Class Initialized
INFO - 2021-11-20 02:26:02 --> Helper loaded: url_helper
INFO - 2021-11-20 02:26:02 --> Helper loaded: file_helper
INFO - 2021-11-20 02:26:02 --> Helper loaded: form_helper
INFO - 2021-11-20 02:26:02 --> Helper loaded: my_helper
INFO - 2021-11-20 02:26:02 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:26:02 --> Controller Class Initialized
DEBUG - 2021-11-20 02:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-20 02:26:02 --> Final output sent to browser
DEBUG - 2021-11-20 02:26:02 --> Total execution time: 0.0890
INFO - 2021-11-20 02:26:14 --> Config Class Initialized
INFO - 2021-11-20 02:26:14 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:26:14 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:26:14 --> Utf8 Class Initialized
INFO - 2021-11-20 02:26:14 --> URI Class Initialized
INFO - 2021-11-20 02:26:14 --> Router Class Initialized
INFO - 2021-11-20 02:26:14 --> Output Class Initialized
INFO - 2021-11-20 02:26:14 --> Security Class Initialized
DEBUG - 2021-11-20 02:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:26:14 --> Input Class Initialized
INFO - 2021-11-20 02:26:14 --> Language Class Initialized
INFO - 2021-11-20 02:26:14 --> Language Class Initialized
INFO - 2021-11-20 02:26:14 --> Config Class Initialized
INFO - 2021-11-20 02:26:14 --> Loader Class Initialized
INFO - 2021-11-20 02:26:14 --> Helper loaded: url_helper
INFO - 2021-11-20 02:26:14 --> Helper loaded: file_helper
INFO - 2021-11-20 02:26:14 --> Helper loaded: form_helper
INFO - 2021-11-20 02:26:14 --> Helper loaded: my_helper
INFO - 2021-11-20 02:26:14 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:26:14 --> Controller Class Initialized
DEBUG - 2021-11-20 02:26:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-20 02:26:14 --> Final output sent to browser
DEBUG - 2021-11-20 02:26:14 --> Total execution time: 0.0756
INFO - 2021-11-20 02:26:24 --> Config Class Initialized
INFO - 2021-11-20 02:26:24 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:26:24 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:26:24 --> Utf8 Class Initialized
INFO - 2021-11-20 02:26:24 --> URI Class Initialized
INFO - 2021-11-20 02:26:24 --> Router Class Initialized
INFO - 2021-11-20 02:26:24 --> Output Class Initialized
INFO - 2021-11-20 02:26:24 --> Security Class Initialized
DEBUG - 2021-11-20 02:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:26:24 --> Input Class Initialized
INFO - 2021-11-20 02:26:24 --> Language Class Initialized
INFO - 2021-11-20 02:26:24 --> Language Class Initialized
INFO - 2021-11-20 02:26:24 --> Config Class Initialized
INFO - 2021-11-20 02:26:24 --> Loader Class Initialized
INFO - 2021-11-20 02:26:24 --> Helper loaded: url_helper
INFO - 2021-11-20 02:26:24 --> Helper loaded: file_helper
INFO - 2021-11-20 02:26:24 --> Helper loaded: form_helper
INFO - 2021-11-20 02:26:24 --> Helper loaded: my_helper
INFO - 2021-11-20 02:26:24 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:26:24 --> Controller Class Initialized
DEBUG - 2021-11-20 02:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-20 02:26:24 --> Final output sent to browser
DEBUG - 2021-11-20 02:26:24 --> Total execution time: 0.0823
INFO - 2021-11-20 02:26:31 --> Config Class Initialized
INFO - 2021-11-20 02:26:31 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:26:31 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:26:31 --> Utf8 Class Initialized
INFO - 2021-11-20 02:26:31 --> URI Class Initialized
INFO - 2021-11-20 02:26:31 --> Router Class Initialized
INFO - 2021-11-20 02:26:31 --> Output Class Initialized
INFO - 2021-11-20 02:26:31 --> Security Class Initialized
DEBUG - 2021-11-20 02:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:26:31 --> Input Class Initialized
INFO - 2021-11-20 02:26:31 --> Language Class Initialized
INFO - 2021-11-20 02:26:31 --> Language Class Initialized
INFO - 2021-11-20 02:26:31 --> Config Class Initialized
INFO - 2021-11-20 02:26:31 --> Loader Class Initialized
INFO - 2021-11-20 02:26:31 --> Helper loaded: url_helper
INFO - 2021-11-20 02:26:31 --> Helper loaded: file_helper
INFO - 2021-11-20 02:26:31 --> Helper loaded: form_helper
INFO - 2021-11-20 02:26:31 --> Helper loaded: my_helper
INFO - 2021-11-20 02:26:31 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:26:31 --> Controller Class Initialized
DEBUG - 2021-11-20 02:26:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-20 02:26:31 --> Final output sent to browser
DEBUG - 2021-11-20 02:26:31 --> Total execution time: 0.0855
INFO - 2021-11-20 02:26:38 --> Config Class Initialized
INFO - 2021-11-20 02:26:38 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:26:38 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:26:38 --> Utf8 Class Initialized
INFO - 2021-11-20 02:26:38 --> URI Class Initialized
INFO - 2021-11-20 02:26:38 --> Router Class Initialized
INFO - 2021-11-20 02:26:38 --> Output Class Initialized
INFO - 2021-11-20 02:26:38 --> Security Class Initialized
DEBUG - 2021-11-20 02:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:26:38 --> Input Class Initialized
INFO - 2021-11-20 02:26:38 --> Language Class Initialized
INFO - 2021-11-20 02:26:38 --> Language Class Initialized
INFO - 2021-11-20 02:26:38 --> Config Class Initialized
INFO - 2021-11-20 02:26:38 --> Loader Class Initialized
INFO - 2021-11-20 02:26:38 --> Helper loaded: url_helper
INFO - 2021-11-20 02:26:38 --> Helper loaded: file_helper
INFO - 2021-11-20 02:26:38 --> Helper loaded: form_helper
INFO - 2021-11-20 02:26:38 --> Helper loaded: my_helper
INFO - 2021-11-20 02:26:38 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:26:39 --> Controller Class Initialized
DEBUG - 2021-11-20 02:26:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-11-20 02:26:39 --> Final output sent to browser
DEBUG - 2021-11-20 02:26:39 --> Total execution time: 0.0839
INFO - 2021-11-20 02:49:02 --> Config Class Initialized
INFO - 2021-11-20 02:49:02 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:02 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:02 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:02 --> URI Class Initialized
INFO - 2021-11-20 02:49:02 --> Router Class Initialized
INFO - 2021-11-20 02:49:02 --> Output Class Initialized
INFO - 2021-11-20 02:49:02 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:02 --> Input Class Initialized
INFO - 2021-11-20 02:49:02 --> Language Class Initialized
INFO - 2021-11-20 02:49:02 --> Language Class Initialized
INFO - 2021-11-20 02:49:02 --> Config Class Initialized
INFO - 2021-11-20 02:49:02 --> Loader Class Initialized
INFO - 2021-11-20 02:49:02 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:02 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:02 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:02 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:02 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:02 --> Controller Class Initialized
INFO - 2021-11-20 02:49:02 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:49:02 --> Config Class Initialized
INFO - 2021-11-20 02:49:02 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:02 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:02 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:02 --> URI Class Initialized
INFO - 2021-11-20 02:49:02 --> Router Class Initialized
INFO - 2021-11-20 02:49:02 --> Output Class Initialized
INFO - 2021-11-20 02:49:02 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:02 --> Input Class Initialized
INFO - 2021-11-20 02:49:02 --> Language Class Initialized
INFO - 2021-11-20 02:49:02 --> Language Class Initialized
INFO - 2021-11-20 02:49:02 --> Config Class Initialized
INFO - 2021-11-20 02:49:02 --> Loader Class Initialized
INFO - 2021-11-20 02:49:02 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:02 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:02 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:02 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:02 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:02 --> Controller Class Initialized
DEBUG - 2021-11-20 02:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 02:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:49:02 --> Final output sent to browser
DEBUG - 2021-11-20 02:49:02 --> Total execution time: 0.0649
INFO - 2021-11-20 02:49:06 --> Config Class Initialized
INFO - 2021-11-20 02:49:06 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:07 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:07 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:07 --> URI Class Initialized
INFO - 2021-11-20 02:49:07 --> Router Class Initialized
INFO - 2021-11-20 02:49:07 --> Output Class Initialized
INFO - 2021-11-20 02:49:07 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:07 --> Input Class Initialized
INFO - 2021-11-20 02:49:07 --> Language Class Initialized
INFO - 2021-11-20 02:49:07 --> Language Class Initialized
INFO - 2021-11-20 02:49:07 --> Config Class Initialized
INFO - 2021-11-20 02:49:07 --> Loader Class Initialized
INFO - 2021-11-20 02:49:07 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:07 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:07 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:07 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:07 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:07 --> Controller Class Initialized
INFO - 2021-11-20 02:49:07 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:49:07 --> Final output sent to browser
DEBUG - 2021-11-20 02:49:07 --> Total execution time: 0.0824
INFO - 2021-11-20 02:49:07 --> Config Class Initialized
INFO - 2021-11-20 02:49:07 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:07 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:07 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:07 --> URI Class Initialized
INFO - 2021-11-20 02:49:07 --> Router Class Initialized
INFO - 2021-11-20 02:49:07 --> Output Class Initialized
INFO - 2021-11-20 02:49:07 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:07 --> Input Class Initialized
INFO - 2021-11-20 02:49:07 --> Language Class Initialized
INFO - 2021-11-20 02:49:07 --> Language Class Initialized
INFO - 2021-11-20 02:49:07 --> Config Class Initialized
INFO - 2021-11-20 02:49:07 --> Loader Class Initialized
INFO - 2021-11-20 02:49:07 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:07 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:07 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:07 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:07 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:07 --> Controller Class Initialized
DEBUG - 2021-11-20 02:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 02:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:49:07 --> Final output sent to browser
DEBUG - 2021-11-20 02:49:07 --> Total execution time: 0.2367
INFO - 2021-11-20 02:49:15 --> Config Class Initialized
INFO - 2021-11-20 02:49:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:15 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:15 --> URI Class Initialized
INFO - 2021-11-20 02:49:15 --> Router Class Initialized
INFO - 2021-11-20 02:49:15 --> Output Class Initialized
INFO - 2021-11-20 02:49:15 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:15 --> Input Class Initialized
INFO - 2021-11-20 02:49:15 --> Language Class Initialized
INFO - 2021-11-20 02:49:15 --> Language Class Initialized
INFO - 2021-11-20 02:49:15 --> Config Class Initialized
INFO - 2021-11-20 02:49:15 --> Loader Class Initialized
INFO - 2021-11-20 02:49:15 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:15 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:15 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:15 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:15 --> Controller Class Initialized
DEBUG - 2021-11-20 02:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 02:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:49:15 --> Final output sent to browser
DEBUG - 2021-11-20 02:49:15 --> Total execution time: 0.0770
INFO - 2021-11-20 02:49:28 --> Config Class Initialized
INFO - 2021-11-20 02:49:28 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:28 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:28 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:28 --> URI Class Initialized
INFO - 2021-11-20 02:49:28 --> Router Class Initialized
INFO - 2021-11-20 02:49:28 --> Output Class Initialized
INFO - 2021-11-20 02:49:28 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:28 --> Input Class Initialized
INFO - 2021-11-20 02:49:28 --> Language Class Initialized
INFO - 2021-11-20 02:49:28 --> Language Class Initialized
INFO - 2021-11-20 02:49:28 --> Config Class Initialized
INFO - 2021-11-20 02:49:28 --> Loader Class Initialized
INFO - 2021-11-20 02:49:28 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:28 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:28 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:28 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:28 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:28 --> Controller Class Initialized
DEBUG - 2021-11-20 02:49:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-20 02:49:28 --> Final output sent to browser
DEBUG - 2021-11-20 02:49:28 --> Total execution time: 0.2341
INFO - 2021-11-20 02:49:41 --> Config Class Initialized
INFO - 2021-11-20 02:49:41 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:49:41 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:49:41 --> Utf8 Class Initialized
INFO - 2021-11-20 02:49:41 --> URI Class Initialized
INFO - 2021-11-20 02:49:41 --> Router Class Initialized
INFO - 2021-11-20 02:49:41 --> Output Class Initialized
INFO - 2021-11-20 02:49:41 --> Security Class Initialized
DEBUG - 2021-11-20 02:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:49:41 --> Input Class Initialized
INFO - 2021-11-20 02:49:41 --> Language Class Initialized
INFO - 2021-11-20 02:49:41 --> Language Class Initialized
INFO - 2021-11-20 02:49:41 --> Config Class Initialized
INFO - 2021-11-20 02:49:41 --> Loader Class Initialized
INFO - 2021-11-20 02:49:41 --> Helper loaded: url_helper
INFO - 2021-11-20 02:49:41 --> Helper loaded: file_helper
INFO - 2021-11-20 02:49:41 --> Helper loaded: form_helper
INFO - 2021-11-20 02:49:41 --> Helper loaded: my_helper
INFO - 2021-11-20 02:49:41 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:49:41 --> Controller Class Initialized
DEBUG - 2021-11-20 02:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 02:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:49:41 --> Final output sent to browser
DEBUG - 2021-11-20 02:49:41 --> Total execution time: 0.1764
INFO - 2021-11-20 02:51:20 --> Config Class Initialized
INFO - 2021-11-20 02:51:20 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:51:20 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:51:20 --> Utf8 Class Initialized
INFO - 2021-11-20 02:51:20 --> URI Class Initialized
INFO - 2021-11-20 02:51:20 --> Router Class Initialized
INFO - 2021-11-20 02:51:20 --> Output Class Initialized
INFO - 2021-11-20 02:51:20 --> Security Class Initialized
DEBUG - 2021-11-20 02:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:51:20 --> Input Class Initialized
INFO - 2021-11-20 02:51:20 --> Language Class Initialized
INFO - 2021-11-20 02:51:20 --> Language Class Initialized
INFO - 2021-11-20 02:51:20 --> Config Class Initialized
INFO - 2021-11-20 02:51:20 --> Loader Class Initialized
INFO - 2021-11-20 02:51:20 --> Helper loaded: url_helper
INFO - 2021-11-20 02:51:20 --> Helper loaded: file_helper
INFO - 2021-11-20 02:51:20 --> Helper loaded: form_helper
INFO - 2021-11-20 02:51:20 --> Helper loaded: my_helper
INFO - 2021-11-20 02:51:20 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:51:20 --> Controller Class Initialized
INFO - 2021-11-20 02:51:20 --> Final output sent to browser
DEBUG - 2021-11-20 02:51:20 --> Total execution time: 0.1033
INFO - 2021-11-20 02:51:38 --> Config Class Initialized
INFO - 2021-11-20 02:51:38 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:51:38 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:51:38 --> Utf8 Class Initialized
INFO - 2021-11-20 02:51:38 --> URI Class Initialized
INFO - 2021-11-20 02:51:38 --> Router Class Initialized
INFO - 2021-11-20 02:51:38 --> Output Class Initialized
INFO - 2021-11-20 02:51:38 --> Security Class Initialized
DEBUG - 2021-11-20 02:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:51:38 --> Input Class Initialized
INFO - 2021-11-20 02:51:38 --> Language Class Initialized
INFO - 2021-11-20 02:51:38 --> Language Class Initialized
INFO - 2021-11-20 02:51:38 --> Config Class Initialized
INFO - 2021-11-20 02:51:38 --> Loader Class Initialized
INFO - 2021-11-20 02:51:38 --> Helper loaded: url_helper
INFO - 2021-11-20 02:51:38 --> Helper loaded: file_helper
INFO - 2021-11-20 02:51:38 --> Helper loaded: form_helper
INFO - 2021-11-20 02:51:38 --> Helper loaded: my_helper
INFO - 2021-11-20 02:51:38 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:51:38 --> Controller Class Initialized
DEBUG - 2021-11-20 02:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 02:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:51:38 --> Final output sent to browser
DEBUG - 2021-11-20 02:51:38 --> Total execution time: 0.2332
INFO - 2021-11-20 02:51:48 --> Config Class Initialized
INFO - 2021-11-20 02:51:48 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:51:48 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:51:48 --> Utf8 Class Initialized
INFO - 2021-11-20 02:51:48 --> URI Class Initialized
INFO - 2021-11-20 02:51:48 --> Router Class Initialized
INFO - 2021-11-20 02:51:48 --> Output Class Initialized
INFO - 2021-11-20 02:51:48 --> Security Class Initialized
DEBUG - 2021-11-20 02:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:51:48 --> Input Class Initialized
INFO - 2021-11-20 02:51:48 --> Language Class Initialized
INFO - 2021-11-20 02:51:48 --> Language Class Initialized
INFO - 2021-11-20 02:51:48 --> Config Class Initialized
INFO - 2021-11-20 02:51:48 --> Loader Class Initialized
INFO - 2021-11-20 02:51:48 --> Helper loaded: url_helper
INFO - 2021-11-20 02:51:48 --> Helper loaded: file_helper
INFO - 2021-11-20 02:51:48 --> Helper loaded: form_helper
INFO - 2021-11-20 02:51:48 --> Helper loaded: my_helper
INFO - 2021-11-20 02:51:48 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:51:48 --> Controller Class Initialized
INFO - 2021-11-20 02:51:48 --> Final output sent to browser
DEBUG - 2021-11-20 02:51:48 --> Total execution time: 0.0928
INFO - 2021-11-20 02:51:50 --> Config Class Initialized
INFO - 2021-11-20 02:51:50 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:51:50 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:51:50 --> Utf8 Class Initialized
INFO - 2021-11-20 02:51:50 --> URI Class Initialized
INFO - 2021-11-20 02:51:50 --> Router Class Initialized
INFO - 2021-11-20 02:51:50 --> Output Class Initialized
INFO - 2021-11-20 02:51:50 --> Security Class Initialized
DEBUG - 2021-11-20 02:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:51:50 --> Input Class Initialized
INFO - 2021-11-20 02:51:50 --> Language Class Initialized
INFO - 2021-11-20 02:51:50 --> Language Class Initialized
INFO - 2021-11-20 02:51:50 --> Config Class Initialized
INFO - 2021-11-20 02:51:50 --> Loader Class Initialized
INFO - 2021-11-20 02:51:50 --> Helper loaded: url_helper
INFO - 2021-11-20 02:51:50 --> Helper loaded: file_helper
INFO - 2021-11-20 02:51:50 --> Helper loaded: form_helper
INFO - 2021-11-20 02:51:50 --> Helper loaded: my_helper
INFO - 2021-11-20 02:51:50 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:51:50 --> Controller Class Initialized
DEBUG - 2021-11-20 02:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-20 02:51:50 --> Final output sent to browser
DEBUG - 2021-11-20 02:51:50 --> Total execution time: 0.0764
INFO - 2021-11-20 02:52:24 --> Config Class Initialized
INFO - 2021-11-20 02:52:24 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:52:24 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:52:24 --> Utf8 Class Initialized
INFO - 2021-11-20 02:52:24 --> URI Class Initialized
INFO - 2021-11-20 02:52:24 --> Router Class Initialized
INFO - 2021-11-20 02:52:24 --> Output Class Initialized
INFO - 2021-11-20 02:52:24 --> Security Class Initialized
DEBUG - 2021-11-20 02:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:52:24 --> Input Class Initialized
INFO - 2021-11-20 02:52:24 --> Language Class Initialized
INFO - 2021-11-20 02:52:24 --> Language Class Initialized
INFO - 2021-11-20 02:52:24 --> Config Class Initialized
INFO - 2021-11-20 02:52:24 --> Loader Class Initialized
INFO - 2021-11-20 02:52:24 --> Helper loaded: url_helper
INFO - 2021-11-20 02:52:24 --> Helper loaded: file_helper
INFO - 2021-11-20 02:52:24 --> Helper loaded: form_helper
INFO - 2021-11-20 02:52:24 --> Helper loaded: my_helper
INFO - 2021-11-20 02:52:24 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:52:24 --> Controller Class Initialized
DEBUG - 2021-11-20 02:52:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-20 02:52:24 --> Final output sent to browser
DEBUG - 2021-11-20 02:52:24 --> Total execution time: 0.0777
INFO - 2021-11-20 02:55:51 --> Config Class Initialized
INFO - 2021-11-20 02:55:51 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:55:51 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:55:51 --> Utf8 Class Initialized
INFO - 2021-11-20 02:55:51 --> URI Class Initialized
INFO - 2021-11-20 02:55:51 --> Router Class Initialized
INFO - 2021-11-20 02:55:51 --> Output Class Initialized
INFO - 2021-11-20 02:55:51 --> Security Class Initialized
DEBUG - 2021-11-20 02:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:55:51 --> Input Class Initialized
INFO - 2021-11-20 02:55:51 --> Language Class Initialized
INFO - 2021-11-20 02:55:51 --> Language Class Initialized
INFO - 2021-11-20 02:55:51 --> Config Class Initialized
INFO - 2021-11-20 02:55:51 --> Loader Class Initialized
INFO - 2021-11-20 02:55:51 --> Helper loaded: url_helper
INFO - 2021-11-20 02:55:51 --> Helper loaded: file_helper
INFO - 2021-11-20 02:55:51 --> Helper loaded: form_helper
INFO - 2021-11-20 02:55:51 --> Helper loaded: my_helper
INFO - 2021-11-20 02:55:51 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:55:51 --> Controller Class Initialized
DEBUG - 2021-11-20 02:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-11-20 02:55:51 --> Final output sent to browser
DEBUG - 2021-11-20 02:55:51 --> Total execution time: 0.0764
INFO - 2021-11-20 02:57:19 --> Config Class Initialized
INFO - 2021-11-20 02:57:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:57:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:57:19 --> Utf8 Class Initialized
INFO - 2021-11-20 02:57:19 --> URI Class Initialized
INFO - 2021-11-20 02:57:19 --> Router Class Initialized
INFO - 2021-11-20 02:57:19 --> Output Class Initialized
INFO - 2021-11-20 02:57:19 --> Security Class Initialized
DEBUG - 2021-11-20 02:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:57:19 --> Input Class Initialized
INFO - 2021-11-20 02:57:19 --> Language Class Initialized
INFO - 2021-11-20 02:57:19 --> Language Class Initialized
INFO - 2021-11-20 02:57:19 --> Config Class Initialized
INFO - 2021-11-20 02:57:19 --> Loader Class Initialized
INFO - 2021-11-20 02:57:19 --> Helper loaded: url_helper
INFO - 2021-11-20 02:57:19 --> Helper loaded: file_helper
INFO - 2021-11-20 02:57:19 --> Helper loaded: form_helper
INFO - 2021-11-20 02:57:19 --> Helper loaded: my_helper
INFO - 2021-11-20 02:57:19 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:57:19 --> Controller Class Initialized
INFO - 2021-11-20 02:57:19 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:57:19 --> Config Class Initialized
INFO - 2021-11-20 02:57:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:57:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:57:19 --> Utf8 Class Initialized
INFO - 2021-11-20 02:57:19 --> URI Class Initialized
INFO - 2021-11-20 02:57:19 --> Router Class Initialized
INFO - 2021-11-20 02:57:19 --> Output Class Initialized
INFO - 2021-11-20 02:57:19 --> Security Class Initialized
DEBUG - 2021-11-20 02:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:57:19 --> Input Class Initialized
INFO - 2021-11-20 02:57:19 --> Language Class Initialized
INFO - 2021-11-20 02:57:19 --> Language Class Initialized
INFO - 2021-11-20 02:57:19 --> Config Class Initialized
INFO - 2021-11-20 02:57:19 --> Loader Class Initialized
INFO - 2021-11-20 02:57:19 --> Helper loaded: url_helper
INFO - 2021-11-20 02:57:19 --> Helper loaded: file_helper
INFO - 2021-11-20 02:57:19 --> Helper loaded: form_helper
INFO - 2021-11-20 02:57:19 --> Helper loaded: my_helper
INFO - 2021-11-20 02:57:19 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:57:19 --> Controller Class Initialized
DEBUG - 2021-11-20 02:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 02:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:57:19 --> Final output sent to browser
DEBUG - 2021-11-20 02:57:19 --> Total execution time: 0.0527
INFO - 2021-11-20 02:57:27 --> Config Class Initialized
INFO - 2021-11-20 02:57:27 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:57:27 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:57:27 --> Utf8 Class Initialized
INFO - 2021-11-20 02:57:27 --> URI Class Initialized
INFO - 2021-11-20 02:57:27 --> Router Class Initialized
INFO - 2021-11-20 02:57:27 --> Output Class Initialized
INFO - 2021-11-20 02:57:27 --> Security Class Initialized
DEBUG - 2021-11-20 02:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:57:27 --> Input Class Initialized
INFO - 2021-11-20 02:57:27 --> Language Class Initialized
INFO - 2021-11-20 02:57:27 --> Language Class Initialized
INFO - 2021-11-20 02:57:27 --> Config Class Initialized
INFO - 2021-11-20 02:57:27 --> Loader Class Initialized
INFO - 2021-11-20 02:57:27 --> Helper loaded: url_helper
INFO - 2021-11-20 02:57:27 --> Helper loaded: file_helper
INFO - 2021-11-20 02:57:27 --> Helper loaded: form_helper
INFO - 2021-11-20 02:57:27 --> Helper loaded: my_helper
INFO - 2021-11-20 02:57:27 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:57:27 --> Controller Class Initialized
INFO - 2021-11-20 02:57:27 --> Helper loaded: cookie_helper
INFO - 2021-11-20 02:57:27 --> Final output sent to browser
DEBUG - 2021-11-20 02:57:27 --> Total execution time: 0.1023
INFO - 2021-11-20 02:57:28 --> Config Class Initialized
INFO - 2021-11-20 02:57:28 --> Hooks Class Initialized
DEBUG - 2021-11-20 02:57:28 --> UTF-8 Support Enabled
INFO - 2021-11-20 02:57:28 --> Utf8 Class Initialized
INFO - 2021-11-20 02:57:28 --> URI Class Initialized
INFO - 2021-11-20 02:57:28 --> Router Class Initialized
INFO - 2021-11-20 02:57:28 --> Output Class Initialized
INFO - 2021-11-20 02:57:28 --> Security Class Initialized
DEBUG - 2021-11-20 02:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 02:57:28 --> Input Class Initialized
INFO - 2021-11-20 02:57:28 --> Language Class Initialized
INFO - 2021-11-20 02:57:28 --> Language Class Initialized
INFO - 2021-11-20 02:57:28 --> Config Class Initialized
INFO - 2021-11-20 02:57:28 --> Loader Class Initialized
INFO - 2021-11-20 02:57:28 --> Helper loaded: url_helper
INFO - 2021-11-20 02:57:28 --> Helper loaded: file_helper
INFO - 2021-11-20 02:57:28 --> Helper loaded: form_helper
INFO - 2021-11-20 02:57:28 --> Helper loaded: my_helper
INFO - 2021-11-20 02:57:28 --> Database Driver Class Initialized
DEBUG - 2021-11-20 02:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 02:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 02:57:28 --> Controller Class Initialized
DEBUG - 2021-11-20 02:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 02:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 02:57:28 --> Final output sent to browser
DEBUG - 2021-11-20 02:57:28 --> Total execution time: 0.2897
INFO - 2021-11-20 03:51:00 --> Config Class Initialized
INFO - 2021-11-20 03:51:00 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:00 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:00 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:00 --> URI Class Initialized
INFO - 2021-11-20 03:51:00 --> Router Class Initialized
INFO - 2021-11-20 03:51:00 --> Output Class Initialized
INFO - 2021-11-20 03:51:00 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:00 --> Input Class Initialized
INFO - 2021-11-20 03:51:00 --> Language Class Initialized
INFO - 2021-11-20 03:51:00 --> Language Class Initialized
INFO - 2021-11-20 03:51:00 --> Config Class Initialized
INFO - 2021-11-20 03:51:00 --> Loader Class Initialized
INFO - 2021-11-20 03:51:00 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:00 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:00 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:00 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:00 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:00 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 03:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:51:00 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:00 --> Total execution time: 0.0981
INFO - 2021-11-20 03:51:03 --> Config Class Initialized
INFO - 2021-11-20 03:51:03 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:03 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:03 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:03 --> URI Class Initialized
INFO - 2021-11-20 03:51:03 --> Router Class Initialized
INFO - 2021-11-20 03:51:03 --> Output Class Initialized
INFO - 2021-11-20 03:51:03 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:03 --> Input Class Initialized
INFO - 2021-11-20 03:51:03 --> Language Class Initialized
INFO - 2021-11-20 03:51:03 --> Language Class Initialized
INFO - 2021-11-20 03:51:03 --> Config Class Initialized
INFO - 2021-11-20 03:51:03 --> Loader Class Initialized
INFO - 2021-11-20 03:51:03 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:03 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:03 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:03 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:03 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:03 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-20 03:51:03 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:03 --> Total execution time: 0.1482
INFO - 2021-11-20 03:51:11 --> Config Class Initialized
INFO - 2021-11-20 03:51:11 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:11 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:11 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:11 --> URI Class Initialized
INFO - 2021-11-20 03:51:11 --> Router Class Initialized
INFO - 2021-11-20 03:51:11 --> Output Class Initialized
INFO - 2021-11-20 03:51:11 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:11 --> Input Class Initialized
INFO - 2021-11-20 03:51:11 --> Language Class Initialized
INFO - 2021-11-20 03:51:11 --> Language Class Initialized
INFO - 2021-11-20 03:51:11 --> Config Class Initialized
INFO - 2021-11-20 03:51:11 --> Loader Class Initialized
INFO - 2021-11-20 03:51:11 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:11 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:11 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:11 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:11 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:11 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 03:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:51:11 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:11 --> Total execution time: 0.0933
INFO - 2021-11-20 03:51:15 --> Config Class Initialized
INFO - 2021-11-20 03:51:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:15 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:15 --> URI Class Initialized
INFO - 2021-11-20 03:51:15 --> Router Class Initialized
INFO - 2021-11-20 03:51:15 --> Output Class Initialized
INFO - 2021-11-20 03:51:15 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:15 --> Input Class Initialized
INFO - 2021-11-20 03:51:15 --> Language Class Initialized
INFO - 2021-11-20 03:51:15 --> Language Class Initialized
INFO - 2021-11-20 03:51:15 --> Config Class Initialized
INFO - 2021-11-20 03:51:15 --> Loader Class Initialized
INFO - 2021-11-20 03:51:15 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:15 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:15 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:15 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:15 --> Controller Class Initialized
INFO - 2021-11-20 03:51:15 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:15 --> Total execution time: 0.0857
INFO - 2021-11-20 03:51:17 --> Config Class Initialized
INFO - 2021-11-20 03:51:17 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:17 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:17 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:17 --> URI Class Initialized
INFO - 2021-11-20 03:51:17 --> Router Class Initialized
INFO - 2021-11-20 03:51:17 --> Output Class Initialized
INFO - 2021-11-20 03:51:17 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:17 --> Input Class Initialized
INFO - 2021-11-20 03:51:17 --> Language Class Initialized
INFO - 2021-11-20 03:51:17 --> Language Class Initialized
INFO - 2021-11-20 03:51:17 --> Config Class Initialized
INFO - 2021-11-20 03:51:17 --> Loader Class Initialized
INFO - 2021-11-20 03:51:17 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:17 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:17 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:17 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:17 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:17 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-11-20 03:51:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:51:17 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:17 --> Total execution time: 0.1474
INFO - 2021-11-20 03:51:19 --> Config Class Initialized
INFO - 2021-11-20 03:51:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:19 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:19 --> URI Class Initialized
INFO - 2021-11-20 03:51:19 --> Router Class Initialized
INFO - 2021-11-20 03:51:19 --> Output Class Initialized
INFO - 2021-11-20 03:51:19 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:19 --> Input Class Initialized
INFO - 2021-11-20 03:51:19 --> Language Class Initialized
INFO - 2021-11-20 03:51:19 --> Language Class Initialized
INFO - 2021-11-20 03:51:19 --> Config Class Initialized
INFO - 2021-11-20 03:51:19 --> Loader Class Initialized
INFO - 2021-11-20 03:51:19 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:19 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:19 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:19 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:19 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:19 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 03:51:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:51:19 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:19 --> Total execution time: 0.0939
INFO - 2021-11-20 03:51:21 --> Config Class Initialized
INFO - 2021-11-20 03:51:21 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:21 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:21 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:21 --> URI Class Initialized
INFO - 2021-11-20 03:51:21 --> Router Class Initialized
INFO - 2021-11-20 03:51:21 --> Output Class Initialized
INFO - 2021-11-20 03:51:21 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:21 --> Input Class Initialized
INFO - 2021-11-20 03:51:21 --> Language Class Initialized
INFO - 2021-11-20 03:51:21 --> Language Class Initialized
INFO - 2021-11-20 03:51:21 --> Config Class Initialized
INFO - 2021-11-20 03:51:21 --> Loader Class Initialized
INFO - 2021-11-20 03:51:21 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:21 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:21 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:21 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:21 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:21 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-11-20 03:51:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:51:21 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:21 --> Total execution time: 0.1172
INFO - 2021-11-20 03:51:30 --> Config Class Initialized
INFO - 2021-11-20 03:51:30 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:30 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:30 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:30 --> URI Class Initialized
INFO - 2021-11-20 03:51:30 --> Router Class Initialized
INFO - 2021-11-20 03:51:30 --> Output Class Initialized
INFO - 2021-11-20 03:51:30 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:30 --> Input Class Initialized
INFO - 2021-11-20 03:51:30 --> Language Class Initialized
INFO - 2021-11-20 03:51:30 --> Language Class Initialized
INFO - 2021-11-20 03:51:30 --> Config Class Initialized
INFO - 2021-11-20 03:51:30 --> Loader Class Initialized
INFO - 2021-11-20 03:51:30 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:30 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:30 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:30 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:30 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:30 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 03:51:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:51:30 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:30 --> Total execution time: 0.0927
INFO - 2021-11-20 03:51:39 --> Config Class Initialized
INFO - 2021-11-20 03:51:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:39 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:39 --> URI Class Initialized
INFO - 2021-11-20 03:51:39 --> Router Class Initialized
INFO - 2021-11-20 03:51:39 --> Output Class Initialized
INFO - 2021-11-20 03:51:39 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:39 --> Input Class Initialized
INFO - 2021-11-20 03:51:39 --> Language Class Initialized
INFO - 2021-11-20 03:51:39 --> Language Class Initialized
INFO - 2021-11-20 03:51:39 --> Config Class Initialized
INFO - 2021-11-20 03:51:39 --> Loader Class Initialized
INFO - 2021-11-20 03:51:39 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:39 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:39 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:39 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:39 --> Controller Class Initialized
INFO - 2021-11-20 03:51:39 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:39 --> Total execution time: 0.1027
INFO - 2021-11-20 03:51:41 --> Config Class Initialized
INFO - 2021-11-20 03:51:41 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:51:41 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:51:41 --> Utf8 Class Initialized
INFO - 2021-11-20 03:51:41 --> URI Class Initialized
INFO - 2021-11-20 03:51:41 --> Router Class Initialized
INFO - 2021-11-20 03:51:41 --> Output Class Initialized
INFO - 2021-11-20 03:51:41 --> Security Class Initialized
DEBUG - 2021-11-20 03:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:51:41 --> Input Class Initialized
INFO - 2021-11-20 03:51:41 --> Language Class Initialized
INFO - 2021-11-20 03:51:41 --> Language Class Initialized
INFO - 2021-11-20 03:51:41 --> Config Class Initialized
INFO - 2021-11-20 03:51:41 --> Loader Class Initialized
INFO - 2021-11-20 03:51:41 --> Helper loaded: url_helper
INFO - 2021-11-20 03:51:41 --> Helper loaded: file_helper
INFO - 2021-11-20 03:51:41 --> Helper loaded: form_helper
INFO - 2021-11-20 03:51:41 --> Helper loaded: my_helper
INFO - 2021-11-20 03:51:41 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:51:41 --> Controller Class Initialized
DEBUG - 2021-11-20 03:51:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-20 03:51:41 --> Final output sent to browser
DEBUG - 2021-11-20 03:51:41 --> Total execution time: 0.0950
INFO - 2021-11-20 03:52:14 --> Config Class Initialized
INFO - 2021-11-20 03:52:14 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:52:14 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:52:14 --> Utf8 Class Initialized
INFO - 2021-11-20 03:52:14 --> URI Class Initialized
INFO - 2021-11-20 03:52:14 --> Router Class Initialized
INFO - 2021-11-20 03:52:14 --> Output Class Initialized
INFO - 2021-11-20 03:52:14 --> Security Class Initialized
DEBUG - 2021-11-20 03:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:52:14 --> Input Class Initialized
INFO - 2021-11-20 03:52:14 --> Language Class Initialized
INFO - 2021-11-20 03:52:14 --> Language Class Initialized
INFO - 2021-11-20 03:52:14 --> Config Class Initialized
INFO - 2021-11-20 03:52:14 --> Loader Class Initialized
INFO - 2021-11-20 03:52:14 --> Helper loaded: url_helper
INFO - 2021-11-20 03:52:14 --> Helper loaded: file_helper
INFO - 2021-11-20 03:52:14 --> Helper loaded: form_helper
INFO - 2021-11-20 03:52:14 --> Helper loaded: my_helper
INFO - 2021-11-20 03:52:14 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:52:14 --> Controller Class Initialized
DEBUG - 2021-11-20 03:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-20 03:52:14 --> Final output sent to browser
DEBUG - 2021-11-20 03:52:14 --> Total execution time: 0.0868
INFO - 2021-11-20 03:52:25 --> Config Class Initialized
INFO - 2021-11-20 03:52:25 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:52:25 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:52:25 --> Utf8 Class Initialized
INFO - 2021-11-20 03:52:25 --> URI Class Initialized
INFO - 2021-11-20 03:52:25 --> Router Class Initialized
INFO - 2021-11-20 03:52:25 --> Output Class Initialized
INFO - 2021-11-20 03:52:25 --> Security Class Initialized
DEBUG - 2021-11-20 03:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:52:25 --> Input Class Initialized
INFO - 2021-11-20 03:52:25 --> Language Class Initialized
INFO - 2021-11-20 03:52:25 --> Language Class Initialized
INFO - 2021-11-20 03:52:25 --> Config Class Initialized
INFO - 2021-11-20 03:52:25 --> Loader Class Initialized
INFO - 2021-11-20 03:52:25 --> Helper loaded: url_helper
INFO - 2021-11-20 03:52:25 --> Helper loaded: file_helper
INFO - 2021-11-20 03:52:25 --> Helper loaded: form_helper
INFO - 2021-11-20 03:52:25 --> Helper loaded: my_helper
INFO - 2021-11-20 03:52:25 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:52:25 --> Controller Class Initialized
DEBUG - 2021-11-20 03:52:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-20 03:52:25 --> Final output sent to browser
DEBUG - 2021-11-20 03:52:25 --> Total execution time: 0.0918
INFO - 2021-11-20 03:52:36 --> Config Class Initialized
INFO - 2021-11-20 03:52:36 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:52:36 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:52:36 --> Utf8 Class Initialized
INFO - 2021-11-20 03:52:36 --> URI Class Initialized
INFO - 2021-11-20 03:52:36 --> Router Class Initialized
INFO - 2021-11-20 03:52:36 --> Output Class Initialized
INFO - 2021-11-20 03:52:36 --> Security Class Initialized
DEBUG - 2021-11-20 03:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:52:36 --> Input Class Initialized
INFO - 2021-11-20 03:52:36 --> Language Class Initialized
INFO - 2021-11-20 03:52:36 --> Language Class Initialized
INFO - 2021-11-20 03:52:36 --> Config Class Initialized
INFO - 2021-11-20 03:52:36 --> Loader Class Initialized
INFO - 2021-11-20 03:52:36 --> Helper loaded: url_helper
INFO - 2021-11-20 03:52:36 --> Helper loaded: file_helper
INFO - 2021-11-20 03:52:36 --> Helper loaded: form_helper
INFO - 2021-11-20 03:52:36 --> Helper loaded: my_helper
INFO - 2021-11-20 03:52:36 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:52:36 --> Controller Class Initialized
DEBUG - 2021-11-20 03:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-20 03:52:36 --> Final output sent to browser
DEBUG - 2021-11-20 03:52:36 --> Total execution time: 0.0953
INFO - 2021-11-20 03:52:49 --> Config Class Initialized
INFO - 2021-11-20 03:52:49 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:52:49 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:52:49 --> Utf8 Class Initialized
INFO - 2021-11-20 03:52:49 --> URI Class Initialized
INFO - 2021-11-20 03:52:49 --> Router Class Initialized
INFO - 2021-11-20 03:52:49 --> Output Class Initialized
INFO - 2021-11-20 03:52:49 --> Security Class Initialized
DEBUG - 2021-11-20 03:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:52:49 --> Input Class Initialized
INFO - 2021-11-20 03:52:49 --> Language Class Initialized
INFO - 2021-11-20 03:52:49 --> Language Class Initialized
INFO - 2021-11-20 03:52:49 --> Config Class Initialized
INFO - 2021-11-20 03:52:49 --> Loader Class Initialized
INFO - 2021-11-20 03:52:49 --> Helper loaded: url_helper
INFO - 2021-11-20 03:52:49 --> Helper loaded: file_helper
INFO - 2021-11-20 03:52:49 --> Helper loaded: form_helper
INFO - 2021-11-20 03:52:49 --> Helper loaded: my_helper
INFO - 2021-11-20 03:52:49 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:52:49 --> Controller Class Initialized
DEBUG - 2021-11-20 03:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xi.php
INFO - 2021-11-20 03:52:49 --> Final output sent to browser
DEBUG - 2021-11-20 03:52:49 --> Total execution time: 0.1088
INFO - 2021-11-20 03:52:56 --> Config Class Initialized
INFO - 2021-11-20 03:52:56 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:52:56 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:52:56 --> Utf8 Class Initialized
INFO - 2021-11-20 03:52:56 --> URI Class Initialized
INFO - 2021-11-20 03:52:56 --> Router Class Initialized
INFO - 2021-11-20 03:52:56 --> Output Class Initialized
INFO - 2021-11-20 03:52:56 --> Security Class Initialized
DEBUG - 2021-11-20 03:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:52:56 --> Input Class Initialized
INFO - 2021-11-20 03:52:56 --> Language Class Initialized
INFO - 2021-11-20 03:52:56 --> Language Class Initialized
INFO - 2021-11-20 03:52:56 --> Config Class Initialized
INFO - 2021-11-20 03:52:56 --> Loader Class Initialized
INFO - 2021-11-20 03:52:56 --> Helper loaded: url_helper
INFO - 2021-11-20 03:52:56 --> Helper loaded: file_helper
INFO - 2021-11-20 03:52:56 --> Helper loaded: form_helper
INFO - 2021-11-20 03:52:56 --> Helper loaded: my_helper
INFO - 2021-11-20 03:52:56 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:52:56 --> Controller Class Initialized
INFO - 2021-11-20 03:52:56 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:52:56 --> Config Class Initialized
INFO - 2021-11-20 03:52:56 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:52:56 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:52:56 --> Utf8 Class Initialized
INFO - 2021-11-20 03:52:56 --> URI Class Initialized
INFO - 2021-11-20 03:52:56 --> Router Class Initialized
INFO - 2021-11-20 03:52:56 --> Output Class Initialized
INFO - 2021-11-20 03:52:56 --> Security Class Initialized
DEBUG - 2021-11-20 03:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:52:56 --> Input Class Initialized
INFO - 2021-11-20 03:52:56 --> Language Class Initialized
INFO - 2021-11-20 03:52:56 --> Language Class Initialized
INFO - 2021-11-20 03:52:56 --> Config Class Initialized
INFO - 2021-11-20 03:52:56 --> Loader Class Initialized
INFO - 2021-11-20 03:52:56 --> Helper loaded: url_helper
INFO - 2021-11-20 03:52:56 --> Helper loaded: file_helper
INFO - 2021-11-20 03:52:56 --> Helper loaded: form_helper
INFO - 2021-11-20 03:52:56 --> Helper loaded: my_helper
INFO - 2021-11-20 03:52:56 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:52:56 --> Controller Class Initialized
DEBUG - 2021-11-20 03:52:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 03:52:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:52:56 --> Final output sent to browser
DEBUG - 2021-11-20 03:52:56 --> Total execution time: 0.0526
INFO - 2021-11-20 03:53:15 --> Config Class Initialized
INFO - 2021-11-20 03:53:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:15 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:15 --> URI Class Initialized
INFO - 2021-11-20 03:53:15 --> Router Class Initialized
INFO - 2021-11-20 03:53:15 --> Output Class Initialized
INFO - 2021-11-20 03:53:15 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:15 --> Input Class Initialized
INFO - 2021-11-20 03:53:15 --> Language Class Initialized
INFO - 2021-11-20 03:53:15 --> Language Class Initialized
INFO - 2021-11-20 03:53:15 --> Config Class Initialized
INFO - 2021-11-20 03:53:15 --> Loader Class Initialized
INFO - 2021-11-20 03:53:15 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:15 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:15 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:15 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:15 --> Controller Class Initialized
INFO - 2021-11-20 03:53:15 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:53:15 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:15 --> Total execution time: 0.0690
INFO - 2021-11-20 03:53:16 --> Config Class Initialized
INFO - 2021-11-20 03:53:16 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:16 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:16 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:16 --> URI Class Initialized
INFO - 2021-11-20 03:53:16 --> Router Class Initialized
INFO - 2021-11-20 03:53:16 --> Output Class Initialized
INFO - 2021-11-20 03:53:16 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:16 --> Input Class Initialized
INFO - 2021-11-20 03:53:16 --> Language Class Initialized
INFO - 2021-11-20 03:53:16 --> Language Class Initialized
INFO - 2021-11-20 03:53:16 --> Config Class Initialized
INFO - 2021-11-20 03:53:16 --> Loader Class Initialized
INFO - 2021-11-20 03:53:16 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:16 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:16 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:16 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:16 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:16 --> Controller Class Initialized
DEBUG - 2021-11-20 03:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 03:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:53:16 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:16 --> Total execution time: 0.2394
INFO - 2021-11-20 03:53:20 --> Config Class Initialized
INFO - 2021-11-20 03:53:20 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:20 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:20 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:20 --> URI Class Initialized
INFO - 2021-11-20 03:53:20 --> Router Class Initialized
INFO - 2021-11-20 03:53:20 --> Output Class Initialized
INFO - 2021-11-20 03:53:20 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:20 --> Input Class Initialized
INFO - 2021-11-20 03:53:20 --> Language Class Initialized
INFO - 2021-11-20 03:53:20 --> Language Class Initialized
INFO - 2021-11-20 03:53:20 --> Config Class Initialized
INFO - 2021-11-20 03:53:20 --> Loader Class Initialized
INFO - 2021-11-20 03:53:20 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:20 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:20 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:20 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:20 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:20 --> Controller Class Initialized
DEBUG - 2021-11-20 03:53:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 03:53:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:53:20 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:20 --> Total execution time: 0.1133
INFO - 2021-11-20 03:53:32 --> Config Class Initialized
INFO - 2021-11-20 03:53:32 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:32 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:32 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:32 --> URI Class Initialized
INFO - 2021-11-20 03:53:32 --> Router Class Initialized
INFO - 2021-11-20 03:53:32 --> Output Class Initialized
INFO - 2021-11-20 03:53:32 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:32 --> Input Class Initialized
INFO - 2021-11-20 03:53:32 --> Language Class Initialized
INFO - 2021-11-20 03:53:32 --> Language Class Initialized
INFO - 2021-11-20 03:53:32 --> Config Class Initialized
INFO - 2021-11-20 03:53:32 --> Loader Class Initialized
INFO - 2021-11-20 03:53:32 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:32 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:32 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:32 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:32 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:32 --> Controller Class Initialized
DEBUG - 2021-11-20 03:53:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-20 03:53:32 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:32 --> Total execution time: 0.2355
INFO - 2021-11-20 03:53:54 --> Config Class Initialized
INFO - 2021-11-20 03:53:54 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:54 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:54 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:54 --> URI Class Initialized
INFO - 2021-11-20 03:53:54 --> Router Class Initialized
INFO - 2021-11-20 03:53:54 --> Output Class Initialized
INFO - 2021-11-20 03:53:54 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:54 --> Input Class Initialized
INFO - 2021-11-20 03:53:54 --> Language Class Initialized
INFO - 2021-11-20 03:53:54 --> Language Class Initialized
INFO - 2021-11-20 03:53:54 --> Config Class Initialized
INFO - 2021-11-20 03:53:54 --> Loader Class Initialized
INFO - 2021-11-20 03:53:54 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:54 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:54 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:54 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:54 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:54 --> Controller Class Initialized
DEBUG - 2021-11-20 03:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 03:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:53:54 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:54 --> Total execution time: 0.0754
INFO - 2021-11-20 03:53:58 --> Config Class Initialized
INFO - 2021-11-20 03:53:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:58 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:58 --> URI Class Initialized
INFO - 2021-11-20 03:53:58 --> Router Class Initialized
INFO - 2021-11-20 03:53:58 --> Output Class Initialized
INFO - 2021-11-20 03:53:58 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:58 --> Input Class Initialized
INFO - 2021-11-20 03:53:58 --> Language Class Initialized
INFO - 2021-11-20 03:53:58 --> Language Class Initialized
INFO - 2021-11-20 03:53:58 --> Config Class Initialized
INFO - 2021-11-20 03:53:58 --> Loader Class Initialized
INFO - 2021-11-20 03:53:58 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:58 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:58 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:58 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:58 --> Controller Class Initialized
INFO - 2021-11-20 03:53:58 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:58 --> Total execution time: 0.1051
INFO - 2021-11-20 03:53:59 --> Config Class Initialized
INFO - 2021-11-20 03:53:59 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:53:59 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:53:59 --> Utf8 Class Initialized
INFO - 2021-11-20 03:53:59 --> URI Class Initialized
INFO - 2021-11-20 03:53:59 --> Router Class Initialized
INFO - 2021-11-20 03:53:59 --> Output Class Initialized
INFO - 2021-11-20 03:53:59 --> Security Class Initialized
DEBUG - 2021-11-20 03:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:53:59 --> Input Class Initialized
INFO - 2021-11-20 03:53:59 --> Language Class Initialized
INFO - 2021-11-20 03:53:59 --> Language Class Initialized
INFO - 2021-11-20 03:53:59 --> Config Class Initialized
INFO - 2021-11-20 03:53:59 --> Loader Class Initialized
INFO - 2021-11-20 03:53:59 --> Helper loaded: url_helper
INFO - 2021-11-20 03:53:59 --> Helper loaded: file_helper
INFO - 2021-11-20 03:53:59 --> Helper loaded: form_helper
INFO - 2021-11-20 03:53:59 --> Helper loaded: my_helper
INFO - 2021-11-20 03:53:59 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:53:59 --> Controller Class Initialized
DEBUG - 2021-11-20 03:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 03:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:53:59 --> Final output sent to browser
DEBUG - 2021-11-20 03:53:59 --> Total execution time: 0.1031
INFO - 2021-11-20 03:54:09 --> Config Class Initialized
INFO - 2021-11-20 03:54:09 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:54:09 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:54:09 --> Utf8 Class Initialized
INFO - 2021-11-20 03:54:09 --> URI Class Initialized
INFO - 2021-11-20 03:54:09 --> Router Class Initialized
INFO - 2021-11-20 03:54:09 --> Output Class Initialized
INFO - 2021-11-20 03:54:09 --> Security Class Initialized
DEBUG - 2021-11-20 03:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:54:09 --> Input Class Initialized
INFO - 2021-11-20 03:54:09 --> Language Class Initialized
INFO - 2021-11-20 03:54:09 --> Language Class Initialized
INFO - 2021-11-20 03:54:09 --> Config Class Initialized
INFO - 2021-11-20 03:54:09 --> Loader Class Initialized
INFO - 2021-11-20 03:54:09 --> Helper loaded: url_helper
INFO - 2021-11-20 03:54:09 --> Helper loaded: file_helper
INFO - 2021-11-20 03:54:09 --> Helper loaded: form_helper
INFO - 2021-11-20 03:54:09 --> Helper loaded: my_helper
INFO - 2021-11-20 03:54:09 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:54:09 --> Controller Class Initialized
INFO - 2021-11-20 03:54:09 --> Final output sent to browser
DEBUG - 2021-11-20 03:54:09 --> Total execution time: 0.1383
INFO - 2021-11-20 03:54:17 --> Config Class Initialized
INFO - 2021-11-20 03:54:17 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:54:17 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:54:17 --> Utf8 Class Initialized
INFO - 2021-11-20 03:54:17 --> URI Class Initialized
INFO - 2021-11-20 03:54:17 --> Router Class Initialized
INFO - 2021-11-20 03:54:17 --> Output Class Initialized
INFO - 2021-11-20 03:54:17 --> Security Class Initialized
DEBUG - 2021-11-20 03:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:54:17 --> Input Class Initialized
INFO - 2021-11-20 03:54:17 --> Language Class Initialized
INFO - 2021-11-20 03:54:17 --> Language Class Initialized
INFO - 2021-11-20 03:54:17 --> Config Class Initialized
INFO - 2021-11-20 03:54:17 --> Loader Class Initialized
INFO - 2021-11-20 03:54:17 --> Helper loaded: url_helper
INFO - 2021-11-20 03:54:17 --> Helper loaded: file_helper
INFO - 2021-11-20 03:54:17 --> Helper loaded: form_helper
INFO - 2021-11-20 03:54:17 --> Helper loaded: my_helper
INFO - 2021-11-20 03:54:17 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:54:17 --> Controller Class Initialized
DEBUG - 2021-11-20 03:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-20 03:54:17 --> Final output sent to browser
DEBUG - 2021-11-20 03:54:17 --> Total execution time: 0.0929
INFO - 2021-11-20 03:55:47 --> Config Class Initialized
INFO - 2021-11-20 03:55:47 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:55:47 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:55:47 --> Utf8 Class Initialized
INFO - 2021-11-20 03:55:47 --> URI Class Initialized
INFO - 2021-11-20 03:55:47 --> Router Class Initialized
INFO - 2021-11-20 03:55:47 --> Output Class Initialized
INFO - 2021-11-20 03:55:47 --> Security Class Initialized
DEBUG - 2021-11-20 03:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:55:47 --> Input Class Initialized
INFO - 2021-11-20 03:55:47 --> Language Class Initialized
INFO - 2021-11-20 03:55:47 --> Language Class Initialized
INFO - 2021-11-20 03:55:47 --> Config Class Initialized
INFO - 2021-11-20 03:55:47 --> Loader Class Initialized
INFO - 2021-11-20 03:55:47 --> Helper loaded: url_helper
INFO - 2021-11-20 03:55:47 --> Helper loaded: file_helper
INFO - 2021-11-20 03:55:47 --> Helper loaded: form_helper
INFO - 2021-11-20 03:55:47 --> Helper loaded: my_helper
INFO - 2021-11-20 03:55:47 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:55:47 --> Controller Class Initialized
INFO - 2021-11-20 03:55:47 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:55:47 --> Config Class Initialized
INFO - 2021-11-20 03:55:47 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:55:47 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:55:47 --> Utf8 Class Initialized
INFO - 2021-11-20 03:55:47 --> URI Class Initialized
INFO - 2021-11-20 03:55:47 --> Router Class Initialized
INFO - 2021-11-20 03:55:47 --> Output Class Initialized
INFO - 2021-11-20 03:55:47 --> Security Class Initialized
DEBUG - 2021-11-20 03:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:55:47 --> Input Class Initialized
INFO - 2021-11-20 03:55:47 --> Language Class Initialized
INFO - 2021-11-20 03:55:47 --> Language Class Initialized
INFO - 2021-11-20 03:55:47 --> Config Class Initialized
INFO - 2021-11-20 03:55:47 --> Loader Class Initialized
INFO - 2021-11-20 03:55:47 --> Helper loaded: url_helper
INFO - 2021-11-20 03:55:47 --> Helper loaded: file_helper
INFO - 2021-11-20 03:55:47 --> Helper loaded: form_helper
INFO - 2021-11-20 03:55:47 --> Helper loaded: my_helper
INFO - 2021-11-20 03:55:47 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:55:47 --> Controller Class Initialized
DEBUG - 2021-11-20 03:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 03:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:55:47 --> Final output sent to browser
DEBUG - 2021-11-20 03:55:47 --> Total execution time: 0.0628
INFO - 2021-11-20 03:55:53 --> Config Class Initialized
INFO - 2021-11-20 03:55:53 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:55:53 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:55:53 --> Utf8 Class Initialized
INFO - 2021-11-20 03:55:53 --> URI Class Initialized
INFO - 2021-11-20 03:55:53 --> Router Class Initialized
INFO - 2021-11-20 03:55:53 --> Output Class Initialized
INFO - 2021-11-20 03:55:53 --> Security Class Initialized
DEBUG - 2021-11-20 03:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:55:53 --> Input Class Initialized
INFO - 2021-11-20 03:55:53 --> Language Class Initialized
INFO - 2021-11-20 03:55:53 --> Language Class Initialized
INFO - 2021-11-20 03:55:53 --> Config Class Initialized
INFO - 2021-11-20 03:55:53 --> Loader Class Initialized
INFO - 2021-11-20 03:55:53 --> Helper loaded: url_helper
INFO - 2021-11-20 03:55:53 --> Helper loaded: file_helper
INFO - 2021-11-20 03:55:53 --> Helper loaded: form_helper
INFO - 2021-11-20 03:55:53 --> Helper loaded: my_helper
INFO - 2021-11-20 03:55:53 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:55:53 --> Controller Class Initialized
INFO - 2021-11-20 03:55:53 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:55:53 --> Final output sent to browser
DEBUG - 2021-11-20 03:55:53 --> Total execution time: 0.0851
INFO - 2021-11-20 03:55:53 --> Config Class Initialized
INFO - 2021-11-20 03:55:53 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:55:53 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:55:53 --> Utf8 Class Initialized
INFO - 2021-11-20 03:55:53 --> URI Class Initialized
INFO - 2021-11-20 03:55:53 --> Router Class Initialized
INFO - 2021-11-20 03:55:53 --> Output Class Initialized
INFO - 2021-11-20 03:55:53 --> Security Class Initialized
DEBUG - 2021-11-20 03:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:55:53 --> Input Class Initialized
INFO - 2021-11-20 03:55:53 --> Language Class Initialized
INFO - 2021-11-20 03:55:53 --> Language Class Initialized
INFO - 2021-11-20 03:55:53 --> Config Class Initialized
INFO - 2021-11-20 03:55:53 --> Loader Class Initialized
INFO - 2021-11-20 03:55:53 --> Helper loaded: url_helper
INFO - 2021-11-20 03:55:53 --> Helper loaded: file_helper
INFO - 2021-11-20 03:55:53 --> Helper loaded: form_helper
INFO - 2021-11-20 03:55:53 --> Helper loaded: my_helper
INFO - 2021-11-20 03:55:53 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:55:53 --> Controller Class Initialized
DEBUG - 2021-11-20 03:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 03:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:55:53 --> Final output sent to browser
DEBUG - 2021-11-20 03:55:53 --> Total execution time: 0.2529
INFO - 2021-11-20 03:55:57 --> Config Class Initialized
INFO - 2021-11-20 03:55:57 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:55:57 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:55:57 --> Utf8 Class Initialized
INFO - 2021-11-20 03:55:57 --> URI Class Initialized
INFO - 2021-11-20 03:55:57 --> Router Class Initialized
INFO - 2021-11-20 03:55:57 --> Output Class Initialized
INFO - 2021-11-20 03:55:57 --> Security Class Initialized
DEBUG - 2021-11-20 03:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:55:57 --> Input Class Initialized
INFO - 2021-11-20 03:55:57 --> Language Class Initialized
INFO - 2021-11-20 03:55:57 --> Language Class Initialized
INFO - 2021-11-20 03:55:57 --> Config Class Initialized
INFO - 2021-11-20 03:55:57 --> Loader Class Initialized
INFO - 2021-11-20 03:55:57 --> Helper loaded: url_helper
INFO - 2021-11-20 03:55:57 --> Helper loaded: file_helper
INFO - 2021-11-20 03:55:57 --> Helper loaded: form_helper
INFO - 2021-11-20 03:55:57 --> Helper loaded: my_helper
INFO - 2021-11-20 03:55:57 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:55:57 --> Controller Class Initialized
DEBUG - 2021-11-20 03:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 03:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:55:57 --> Final output sent to browser
DEBUG - 2021-11-20 03:55:57 --> Total execution time: 0.0726
INFO - 2021-11-20 03:56:00 --> Config Class Initialized
INFO - 2021-11-20 03:56:00 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:00 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:00 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:00 --> URI Class Initialized
INFO - 2021-11-20 03:56:00 --> Router Class Initialized
INFO - 2021-11-20 03:56:00 --> Output Class Initialized
INFO - 2021-11-20 03:56:00 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:00 --> Input Class Initialized
INFO - 2021-11-20 03:56:00 --> Language Class Initialized
INFO - 2021-11-20 03:56:00 --> Language Class Initialized
INFO - 2021-11-20 03:56:00 --> Config Class Initialized
INFO - 2021-11-20 03:56:00 --> Loader Class Initialized
INFO - 2021-11-20 03:56:00 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:00 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:00 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:00 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:00 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:00 --> Controller Class Initialized
DEBUG - 2021-11-20 03:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 03:56:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:56:00 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:00 --> Total execution time: 0.1362
INFO - 2021-11-20 03:56:12 --> Config Class Initialized
INFO - 2021-11-20 03:56:12 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:12 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:12 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:12 --> URI Class Initialized
INFO - 2021-11-20 03:56:12 --> Router Class Initialized
INFO - 2021-11-20 03:56:12 --> Output Class Initialized
INFO - 2021-11-20 03:56:12 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:12 --> Input Class Initialized
INFO - 2021-11-20 03:56:12 --> Language Class Initialized
INFO - 2021-11-20 03:56:12 --> Language Class Initialized
INFO - 2021-11-20 03:56:12 --> Config Class Initialized
INFO - 2021-11-20 03:56:12 --> Loader Class Initialized
INFO - 2021-11-20 03:56:12 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:12 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:12 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:12 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:12 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:12 --> Controller Class Initialized
INFO - 2021-11-20 03:56:12 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:12 --> Total execution time: 0.1080
INFO - 2021-11-20 03:56:14 --> Config Class Initialized
INFO - 2021-11-20 03:56:14 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:14 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:14 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:14 --> URI Class Initialized
INFO - 2021-11-20 03:56:14 --> Router Class Initialized
INFO - 2021-11-20 03:56:14 --> Output Class Initialized
INFO - 2021-11-20 03:56:14 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:14 --> Input Class Initialized
INFO - 2021-11-20 03:56:14 --> Language Class Initialized
INFO - 2021-11-20 03:56:14 --> Language Class Initialized
INFO - 2021-11-20 03:56:14 --> Config Class Initialized
INFO - 2021-11-20 03:56:14 --> Loader Class Initialized
INFO - 2021-11-20 03:56:14 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:14 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:14 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:14 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:15 --> Controller Class Initialized
DEBUG - 2021-11-20 03:56:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 03:56:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:56:15 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:15 --> Total execution time: 0.0910
INFO - 2021-11-20 03:56:16 --> Config Class Initialized
INFO - 2021-11-20 03:56:16 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:16 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:16 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:16 --> URI Class Initialized
INFO - 2021-11-20 03:56:16 --> Router Class Initialized
INFO - 2021-11-20 03:56:16 --> Output Class Initialized
INFO - 2021-11-20 03:56:16 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:16 --> Input Class Initialized
INFO - 2021-11-20 03:56:16 --> Language Class Initialized
INFO - 2021-11-20 03:56:16 --> Language Class Initialized
INFO - 2021-11-20 03:56:16 --> Config Class Initialized
INFO - 2021-11-20 03:56:16 --> Loader Class Initialized
INFO - 2021-11-20 03:56:16 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:16 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:16 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:16 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:16 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:16 --> Controller Class Initialized
DEBUG - 2021-11-20 03:56:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-20 03:56:17 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:17 --> Total execution time: 0.1302
INFO - 2021-11-20 03:56:28 --> Config Class Initialized
INFO - 2021-11-20 03:56:28 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:28 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:28 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:28 --> URI Class Initialized
INFO - 2021-11-20 03:56:28 --> Router Class Initialized
INFO - 2021-11-20 03:56:28 --> Output Class Initialized
INFO - 2021-11-20 03:56:28 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:28 --> Input Class Initialized
INFO - 2021-11-20 03:56:28 --> Language Class Initialized
INFO - 2021-11-20 03:56:28 --> Language Class Initialized
INFO - 2021-11-20 03:56:28 --> Config Class Initialized
INFO - 2021-11-20 03:56:28 --> Loader Class Initialized
INFO - 2021-11-20 03:56:28 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:28 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:28 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:28 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:28 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:28 --> Controller Class Initialized
DEBUG - 2021-11-20 03:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 03:56:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:56:28 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:28 --> Total execution time: 0.0907
INFO - 2021-11-20 03:56:31 --> Config Class Initialized
INFO - 2021-11-20 03:56:31 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:31 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:31 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:31 --> URI Class Initialized
INFO - 2021-11-20 03:56:31 --> Router Class Initialized
INFO - 2021-11-20 03:56:31 --> Output Class Initialized
INFO - 2021-11-20 03:56:31 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:31 --> Input Class Initialized
INFO - 2021-11-20 03:56:31 --> Language Class Initialized
INFO - 2021-11-20 03:56:31 --> Language Class Initialized
INFO - 2021-11-20 03:56:31 --> Config Class Initialized
INFO - 2021-11-20 03:56:31 --> Loader Class Initialized
INFO - 2021-11-20 03:56:31 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:31 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:31 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:31 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:31 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:31 --> Controller Class Initialized
INFO - 2021-11-20 03:56:31 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:31 --> Total execution time: 0.1184
INFO - 2021-11-20 03:56:34 --> Config Class Initialized
INFO - 2021-11-20 03:56:34 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:34 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:34 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:34 --> URI Class Initialized
INFO - 2021-11-20 03:56:34 --> Router Class Initialized
INFO - 2021-11-20 03:56:34 --> Output Class Initialized
INFO - 2021-11-20 03:56:34 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:34 --> Input Class Initialized
INFO - 2021-11-20 03:56:34 --> Language Class Initialized
INFO - 2021-11-20 03:56:34 --> Language Class Initialized
INFO - 2021-11-20 03:56:34 --> Config Class Initialized
INFO - 2021-11-20 03:56:34 --> Loader Class Initialized
INFO - 2021-11-20 03:56:34 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:34 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:34 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:34 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:34 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:34 --> Controller Class Initialized
DEBUG - 2021-11-20 03:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-20 03:56:34 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:34 --> Total execution time: 0.0967
INFO - 2021-11-20 03:56:59 --> Config Class Initialized
INFO - 2021-11-20 03:56:59 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:56:59 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:56:59 --> Utf8 Class Initialized
INFO - 2021-11-20 03:56:59 --> URI Class Initialized
INFO - 2021-11-20 03:56:59 --> Router Class Initialized
INFO - 2021-11-20 03:56:59 --> Output Class Initialized
INFO - 2021-11-20 03:56:59 --> Security Class Initialized
DEBUG - 2021-11-20 03:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:56:59 --> Input Class Initialized
INFO - 2021-11-20 03:56:59 --> Language Class Initialized
INFO - 2021-11-20 03:56:59 --> Language Class Initialized
INFO - 2021-11-20 03:56:59 --> Config Class Initialized
INFO - 2021-11-20 03:56:59 --> Loader Class Initialized
INFO - 2021-11-20 03:56:59 --> Helper loaded: url_helper
INFO - 2021-11-20 03:56:59 --> Helper loaded: file_helper
INFO - 2021-11-20 03:56:59 --> Helper loaded: form_helper
INFO - 2021-11-20 03:56:59 --> Helper loaded: my_helper
INFO - 2021-11-20 03:56:59 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:56:59 --> Controller Class Initialized
DEBUG - 2021-11-20 03:56:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-20 03:56:59 --> Final output sent to browser
DEBUG - 2021-11-20 03:56:59 --> Total execution time: 0.0684
INFO - 2021-11-20 03:57:08 --> Config Class Initialized
INFO - 2021-11-20 03:57:08 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:08 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:08 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:08 --> URI Class Initialized
INFO - 2021-11-20 03:57:08 --> Router Class Initialized
INFO - 2021-11-20 03:57:08 --> Output Class Initialized
INFO - 2021-11-20 03:57:08 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:08 --> Input Class Initialized
INFO - 2021-11-20 03:57:08 --> Language Class Initialized
INFO - 2021-11-20 03:57:08 --> Language Class Initialized
INFO - 2021-11-20 03:57:08 --> Config Class Initialized
INFO - 2021-11-20 03:57:08 --> Loader Class Initialized
INFO - 2021-11-20 03:57:08 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:08 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:08 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:08 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:08 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:08 --> Controller Class Initialized
DEBUG - 2021-11-20 03:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_otr_xii.php
INFO - 2021-11-20 03:57:08 --> Final output sent to browser
DEBUG - 2021-11-20 03:57:08 --> Total execution time: 0.1024
INFO - 2021-11-20 03:57:22 --> Config Class Initialized
INFO - 2021-11-20 03:57:22 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:22 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:22 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:22 --> URI Class Initialized
INFO - 2021-11-20 03:57:22 --> Router Class Initialized
INFO - 2021-11-20 03:57:22 --> Output Class Initialized
INFO - 2021-11-20 03:57:22 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:22 --> Input Class Initialized
INFO - 2021-11-20 03:57:22 --> Language Class Initialized
INFO - 2021-11-20 03:57:22 --> Language Class Initialized
INFO - 2021-11-20 03:57:22 --> Config Class Initialized
INFO - 2021-11-20 03:57:22 --> Loader Class Initialized
INFO - 2021-11-20 03:57:22 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:22 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:22 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:22 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:22 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:22 --> Controller Class Initialized
INFO - 2021-11-20 03:57:22 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:57:22 --> Config Class Initialized
INFO - 2021-11-20 03:57:22 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:22 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:22 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:22 --> URI Class Initialized
INFO - 2021-11-20 03:57:22 --> Router Class Initialized
INFO - 2021-11-20 03:57:22 --> Output Class Initialized
INFO - 2021-11-20 03:57:22 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:22 --> Input Class Initialized
INFO - 2021-11-20 03:57:22 --> Language Class Initialized
INFO - 2021-11-20 03:57:22 --> Language Class Initialized
INFO - 2021-11-20 03:57:22 --> Config Class Initialized
INFO - 2021-11-20 03:57:22 --> Loader Class Initialized
INFO - 2021-11-20 03:57:22 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:22 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:22 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:22 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:22 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:22 --> Controller Class Initialized
DEBUG - 2021-11-20 03:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 03:57:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:57:22 --> Final output sent to browser
DEBUG - 2021-11-20 03:57:22 --> Total execution time: 0.0822
INFO - 2021-11-20 03:57:39 --> Config Class Initialized
INFO - 2021-11-20 03:57:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:39 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:39 --> URI Class Initialized
INFO - 2021-11-20 03:57:39 --> Router Class Initialized
INFO - 2021-11-20 03:57:39 --> Output Class Initialized
INFO - 2021-11-20 03:57:39 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:39 --> Input Class Initialized
INFO - 2021-11-20 03:57:39 --> Language Class Initialized
INFO - 2021-11-20 03:57:39 --> Language Class Initialized
INFO - 2021-11-20 03:57:39 --> Config Class Initialized
INFO - 2021-11-20 03:57:39 --> Loader Class Initialized
INFO - 2021-11-20 03:57:39 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:39 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:39 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:39 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:39 --> Controller Class Initialized
INFO - 2021-11-20 03:57:39 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:57:39 --> Final output sent to browser
DEBUG - 2021-11-20 03:57:39 --> Total execution time: 0.0852
INFO - 2021-11-20 03:57:39 --> Config Class Initialized
INFO - 2021-11-20 03:57:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:39 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:39 --> URI Class Initialized
INFO - 2021-11-20 03:57:39 --> Router Class Initialized
INFO - 2021-11-20 03:57:39 --> Output Class Initialized
INFO - 2021-11-20 03:57:39 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:39 --> Input Class Initialized
INFO - 2021-11-20 03:57:39 --> Language Class Initialized
INFO - 2021-11-20 03:57:39 --> Language Class Initialized
INFO - 2021-11-20 03:57:39 --> Config Class Initialized
INFO - 2021-11-20 03:57:39 --> Loader Class Initialized
INFO - 2021-11-20 03:57:39 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:39 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:39 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:39 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:39 --> Controller Class Initialized
DEBUG - 2021-11-20 03:57:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 03:57:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:57:40 --> Final output sent to browser
DEBUG - 2021-11-20 03:57:40 --> Total execution time: 0.2464
INFO - 2021-11-20 03:57:50 --> Config Class Initialized
INFO - 2021-11-20 03:57:50 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:50 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:50 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:50 --> URI Class Initialized
INFO - 2021-11-20 03:57:50 --> Router Class Initialized
INFO - 2021-11-20 03:57:50 --> Output Class Initialized
INFO - 2021-11-20 03:57:50 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:50 --> Input Class Initialized
INFO - 2021-11-20 03:57:50 --> Language Class Initialized
INFO - 2021-11-20 03:57:50 --> Language Class Initialized
INFO - 2021-11-20 03:57:50 --> Config Class Initialized
INFO - 2021-11-20 03:57:50 --> Loader Class Initialized
INFO - 2021-11-20 03:57:50 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:50 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:50 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:50 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:50 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:50 --> Controller Class Initialized
DEBUG - 2021-11-20 03:57:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 03:57:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:57:50 --> Final output sent to browser
DEBUG - 2021-11-20 03:57:50 --> Total execution time: 0.0910
INFO - 2021-11-20 03:57:53 --> Config Class Initialized
INFO - 2021-11-20 03:57:53 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:57:53 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:57:53 --> Utf8 Class Initialized
INFO - 2021-11-20 03:57:53 --> URI Class Initialized
INFO - 2021-11-20 03:57:53 --> Router Class Initialized
INFO - 2021-11-20 03:57:53 --> Output Class Initialized
INFO - 2021-11-20 03:57:53 --> Security Class Initialized
DEBUG - 2021-11-20 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:57:53 --> Input Class Initialized
INFO - 2021-11-20 03:57:53 --> Language Class Initialized
INFO - 2021-11-20 03:57:53 --> Language Class Initialized
INFO - 2021-11-20 03:57:53 --> Config Class Initialized
INFO - 2021-11-20 03:57:53 --> Loader Class Initialized
INFO - 2021-11-20 03:57:53 --> Helper loaded: url_helper
INFO - 2021-11-20 03:57:53 --> Helper loaded: file_helper
INFO - 2021-11-20 03:57:53 --> Helper loaded: form_helper
INFO - 2021-11-20 03:57:53 --> Helper loaded: my_helper
INFO - 2021-11-20 03:57:53 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:57:53 --> Controller Class Initialized
DEBUG - 2021-11-20 03:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-20 03:57:53 --> Final output sent to browser
DEBUG - 2021-11-20 03:57:53 --> Total execution time: 0.1702
INFO - 2021-11-20 03:58:40 --> Config Class Initialized
INFO - 2021-11-20 03:58:40 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:58:40 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:58:40 --> Utf8 Class Initialized
INFO - 2021-11-20 03:58:40 --> URI Class Initialized
INFO - 2021-11-20 03:58:40 --> Router Class Initialized
INFO - 2021-11-20 03:58:40 --> Output Class Initialized
INFO - 2021-11-20 03:58:40 --> Security Class Initialized
DEBUG - 2021-11-20 03:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:58:40 --> Input Class Initialized
INFO - 2021-11-20 03:58:40 --> Language Class Initialized
INFO - 2021-11-20 03:58:40 --> Language Class Initialized
INFO - 2021-11-20 03:58:40 --> Config Class Initialized
INFO - 2021-11-20 03:58:40 --> Loader Class Initialized
INFO - 2021-11-20 03:58:40 --> Helper loaded: url_helper
INFO - 2021-11-20 03:58:40 --> Helper loaded: file_helper
INFO - 2021-11-20 03:58:40 --> Helper loaded: form_helper
INFO - 2021-11-20 03:58:40 --> Helper loaded: my_helper
INFO - 2021-11-20 03:58:40 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:58:40 --> Controller Class Initialized
DEBUG - 2021-11-20 03:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-20 03:58:40 --> Final output sent to browser
DEBUG - 2021-11-20 03:58:40 --> Total execution time: 0.1003
INFO - 2021-11-20 03:58:53 --> Config Class Initialized
INFO - 2021-11-20 03:58:53 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:58:53 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:58:53 --> Utf8 Class Initialized
INFO - 2021-11-20 03:58:53 --> URI Class Initialized
INFO - 2021-11-20 03:58:53 --> Router Class Initialized
INFO - 2021-11-20 03:58:53 --> Output Class Initialized
INFO - 2021-11-20 03:58:53 --> Security Class Initialized
DEBUG - 2021-11-20 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:58:53 --> Input Class Initialized
INFO - 2021-11-20 03:58:53 --> Language Class Initialized
INFO - 2021-11-20 03:58:53 --> Language Class Initialized
INFO - 2021-11-20 03:58:53 --> Config Class Initialized
INFO - 2021-11-20 03:58:53 --> Loader Class Initialized
INFO - 2021-11-20 03:58:53 --> Helper loaded: url_helper
INFO - 2021-11-20 03:58:53 --> Helper loaded: file_helper
INFO - 2021-11-20 03:58:53 --> Helper loaded: form_helper
INFO - 2021-11-20 03:58:53 --> Helper loaded: my_helper
INFO - 2021-11-20 03:58:53 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:58:53 --> Controller Class Initialized
DEBUG - 2021-11-20 03:58:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-20 03:58:53 --> Final output sent to browser
DEBUG - 2021-11-20 03:58:53 --> Total execution time: 0.0853
INFO - 2021-11-20 03:59:39 --> Config Class Initialized
INFO - 2021-11-20 03:59:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:59:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:59:39 --> Utf8 Class Initialized
INFO - 2021-11-20 03:59:39 --> URI Class Initialized
INFO - 2021-11-20 03:59:39 --> Router Class Initialized
INFO - 2021-11-20 03:59:39 --> Output Class Initialized
INFO - 2021-11-20 03:59:39 --> Security Class Initialized
DEBUG - 2021-11-20 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:59:39 --> Input Class Initialized
INFO - 2021-11-20 03:59:39 --> Language Class Initialized
INFO - 2021-11-20 03:59:39 --> Language Class Initialized
INFO - 2021-11-20 03:59:39 --> Config Class Initialized
INFO - 2021-11-20 03:59:39 --> Loader Class Initialized
INFO - 2021-11-20 03:59:39 --> Helper loaded: url_helper
INFO - 2021-11-20 03:59:39 --> Helper loaded: file_helper
INFO - 2021-11-20 03:59:39 --> Helper loaded: form_helper
INFO - 2021-11-20 03:59:39 --> Helper loaded: my_helper
INFO - 2021-11-20 03:59:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:59:39 --> Controller Class Initialized
INFO - 2021-11-20 03:59:39 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:59:39 --> Config Class Initialized
INFO - 2021-11-20 03:59:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:59:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:59:39 --> Utf8 Class Initialized
INFO - 2021-11-20 03:59:39 --> URI Class Initialized
INFO - 2021-11-20 03:59:39 --> Router Class Initialized
INFO - 2021-11-20 03:59:39 --> Output Class Initialized
INFO - 2021-11-20 03:59:39 --> Security Class Initialized
DEBUG - 2021-11-20 03:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:59:39 --> Input Class Initialized
INFO - 2021-11-20 03:59:39 --> Language Class Initialized
INFO - 2021-11-20 03:59:39 --> Language Class Initialized
INFO - 2021-11-20 03:59:39 --> Config Class Initialized
INFO - 2021-11-20 03:59:39 --> Loader Class Initialized
INFO - 2021-11-20 03:59:39 --> Helper loaded: url_helper
INFO - 2021-11-20 03:59:39 --> Helper loaded: file_helper
INFO - 2021-11-20 03:59:39 --> Helper loaded: form_helper
INFO - 2021-11-20 03:59:39 --> Helper loaded: my_helper
INFO - 2021-11-20 03:59:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:59:39 --> Controller Class Initialized
DEBUG - 2021-11-20 03:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 03:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:59:39 --> Final output sent to browser
DEBUG - 2021-11-20 03:59:39 --> Total execution time: 0.0678
INFO - 2021-11-20 03:59:45 --> Config Class Initialized
INFO - 2021-11-20 03:59:45 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:59:45 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:59:45 --> Utf8 Class Initialized
INFO - 2021-11-20 03:59:45 --> URI Class Initialized
INFO - 2021-11-20 03:59:45 --> Router Class Initialized
INFO - 2021-11-20 03:59:45 --> Output Class Initialized
INFO - 2021-11-20 03:59:45 --> Security Class Initialized
DEBUG - 2021-11-20 03:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:59:45 --> Input Class Initialized
INFO - 2021-11-20 03:59:45 --> Language Class Initialized
INFO - 2021-11-20 03:59:45 --> Language Class Initialized
INFO - 2021-11-20 03:59:45 --> Config Class Initialized
INFO - 2021-11-20 03:59:45 --> Loader Class Initialized
INFO - 2021-11-20 03:59:45 --> Helper loaded: url_helper
INFO - 2021-11-20 03:59:45 --> Helper loaded: file_helper
INFO - 2021-11-20 03:59:45 --> Helper loaded: form_helper
INFO - 2021-11-20 03:59:45 --> Helper loaded: my_helper
INFO - 2021-11-20 03:59:45 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:59:45 --> Controller Class Initialized
INFO - 2021-11-20 03:59:45 --> Helper loaded: cookie_helper
INFO - 2021-11-20 03:59:45 --> Final output sent to browser
DEBUG - 2021-11-20 03:59:45 --> Total execution time: 0.0996
INFO - 2021-11-20 03:59:45 --> Config Class Initialized
INFO - 2021-11-20 03:59:45 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:59:45 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:59:45 --> Utf8 Class Initialized
INFO - 2021-11-20 03:59:45 --> URI Class Initialized
INFO - 2021-11-20 03:59:45 --> Router Class Initialized
INFO - 2021-11-20 03:59:45 --> Output Class Initialized
INFO - 2021-11-20 03:59:45 --> Security Class Initialized
DEBUG - 2021-11-20 03:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:59:45 --> Input Class Initialized
INFO - 2021-11-20 03:59:45 --> Language Class Initialized
INFO - 2021-11-20 03:59:45 --> Language Class Initialized
INFO - 2021-11-20 03:59:45 --> Config Class Initialized
INFO - 2021-11-20 03:59:45 --> Loader Class Initialized
INFO - 2021-11-20 03:59:45 --> Helper loaded: url_helper
INFO - 2021-11-20 03:59:45 --> Helper loaded: file_helper
INFO - 2021-11-20 03:59:45 --> Helper loaded: form_helper
INFO - 2021-11-20 03:59:45 --> Helper loaded: my_helper
INFO - 2021-11-20 03:59:45 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:59:45 --> Controller Class Initialized
DEBUG - 2021-11-20 03:59:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 03:59:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:59:46 --> Final output sent to browser
DEBUG - 2021-11-20 03:59:46 --> Total execution time: 0.2572
INFO - 2021-11-20 03:59:56 --> Config Class Initialized
INFO - 2021-11-20 03:59:56 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:59:56 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:59:56 --> Utf8 Class Initialized
INFO - 2021-11-20 03:59:56 --> URI Class Initialized
INFO - 2021-11-20 03:59:56 --> Router Class Initialized
INFO - 2021-11-20 03:59:56 --> Output Class Initialized
INFO - 2021-11-20 03:59:56 --> Security Class Initialized
DEBUG - 2021-11-20 03:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:59:56 --> Input Class Initialized
INFO - 2021-11-20 03:59:56 --> Language Class Initialized
INFO - 2021-11-20 03:59:56 --> Language Class Initialized
INFO - 2021-11-20 03:59:56 --> Config Class Initialized
INFO - 2021-11-20 03:59:56 --> Loader Class Initialized
INFO - 2021-11-20 03:59:56 --> Helper loaded: url_helper
INFO - 2021-11-20 03:59:56 --> Helper loaded: file_helper
INFO - 2021-11-20 03:59:56 --> Helper loaded: form_helper
INFO - 2021-11-20 03:59:56 --> Helper loaded: my_helper
INFO - 2021-11-20 03:59:56 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:59:56 --> Controller Class Initialized
DEBUG - 2021-11-20 03:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 03:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 03:59:56 --> Final output sent to browser
DEBUG - 2021-11-20 03:59:56 --> Total execution time: 0.0874
INFO - 2021-11-20 03:59:58 --> Config Class Initialized
INFO - 2021-11-20 03:59:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 03:59:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 03:59:58 --> Utf8 Class Initialized
INFO - 2021-11-20 03:59:58 --> URI Class Initialized
INFO - 2021-11-20 03:59:58 --> Router Class Initialized
INFO - 2021-11-20 03:59:58 --> Output Class Initialized
INFO - 2021-11-20 03:59:58 --> Security Class Initialized
DEBUG - 2021-11-20 03:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 03:59:58 --> Input Class Initialized
INFO - 2021-11-20 03:59:58 --> Language Class Initialized
INFO - 2021-11-20 03:59:58 --> Language Class Initialized
INFO - 2021-11-20 03:59:58 --> Config Class Initialized
INFO - 2021-11-20 03:59:58 --> Loader Class Initialized
INFO - 2021-11-20 03:59:58 --> Helper loaded: url_helper
INFO - 2021-11-20 03:59:58 --> Helper loaded: file_helper
INFO - 2021-11-20 03:59:58 --> Helper loaded: form_helper
INFO - 2021-11-20 03:59:58 --> Helper loaded: my_helper
INFO - 2021-11-20 03:59:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 03:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 03:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 03:59:58 --> Controller Class Initialized
DEBUG - 2021-11-20 03:59:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-20 03:59:58 --> Final output sent to browser
DEBUG - 2021-11-20 03:59:58 --> Total execution time: 0.1384
INFO - 2021-11-20 04:00:03 --> Config Class Initialized
INFO - 2021-11-20 04:00:03 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:03 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:03 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:03 --> URI Class Initialized
INFO - 2021-11-20 04:00:03 --> Router Class Initialized
INFO - 2021-11-20 04:00:03 --> Output Class Initialized
INFO - 2021-11-20 04:00:03 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:03 --> Input Class Initialized
INFO - 2021-11-20 04:00:03 --> Language Class Initialized
INFO - 2021-11-20 04:00:03 --> Language Class Initialized
INFO - 2021-11-20 04:00:03 --> Config Class Initialized
INFO - 2021-11-20 04:00:03 --> Loader Class Initialized
INFO - 2021-11-20 04:00:03 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:03 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:03 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:03 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:03 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:03 --> Controller Class Initialized
DEBUG - 2021-11-20 04:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:00:03 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:03 --> Total execution time: 0.0895
INFO - 2021-11-20 04:00:08 --> Config Class Initialized
INFO - 2021-11-20 04:00:08 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:08 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:08 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:08 --> URI Class Initialized
INFO - 2021-11-20 04:00:08 --> Router Class Initialized
INFO - 2021-11-20 04:00:08 --> Output Class Initialized
INFO - 2021-11-20 04:00:08 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:08 --> Input Class Initialized
INFO - 2021-11-20 04:00:08 --> Language Class Initialized
INFO - 2021-11-20 04:00:08 --> Language Class Initialized
INFO - 2021-11-20 04:00:08 --> Config Class Initialized
INFO - 2021-11-20 04:00:08 --> Loader Class Initialized
INFO - 2021-11-20 04:00:08 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:08 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:08 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:08 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:08 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:08 --> Controller Class Initialized
INFO - 2021-11-20 04:00:08 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:08 --> Total execution time: 0.1546
INFO - 2021-11-20 04:00:09 --> Config Class Initialized
INFO - 2021-11-20 04:00:09 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:09 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:09 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:09 --> URI Class Initialized
INFO - 2021-11-20 04:00:09 --> Router Class Initialized
INFO - 2021-11-20 04:00:09 --> Output Class Initialized
INFO - 2021-11-20 04:00:09 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:09 --> Input Class Initialized
INFO - 2021-11-20 04:00:09 --> Language Class Initialized
INFO - 2021-11-20 04:00:09 --> Language Class Initialized
INFO - 2021-11-20 04:00:09 --> Config Class Initialized
INFO - 2021-11-20 04:00:09 --> Loader Class Initialized
INFO - 2021-11-20 04:00:09 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:09 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:09 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:09 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:09 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:09 --> Controller Class Initialized
DEBUG - 2021-11-20 04:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 04:00:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:00:09 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:09 --> Total execution time: 0.1137
INFO - 2021-11-20 04:00:19 --> Config Class Initialized
INFO - 2021-11-20 04:00:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:19 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:19 --> URI Class Initialized
INFO - 2021-11-20 04:00:19 --> Router Class Initialized
INFO - 2021-11-20 04:00:19 --> Output Class Initialized
INFO - 2021-11-20 04:00:19 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:19 --> Input Class Initialized
INFO - 2021-11-20 04:00:19 --> Language Class Initialized
INFO - 2021-11-20 04:00:19 --> Language Class Initialized
INFO - 2021-11-20 04:00:19 --> Config Class Initialized
INFO - 2021-11-20 04:00:19 --> Loader Class Initialized
INFO - 2021-11-20 04:00:19 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:19 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:19 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:19 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:19 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:19 --> Controller Class Initialized
INFO - 2021-11-20 04:00:19 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:19 --> Total execution time: 0.1476
INFO - 2021-11-20 04:00:22 --> Config Class Initialized
INFO - 2021-11-20 04:00:22 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:22 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:22 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:22 --> URI Class Initialized
INFO - 2021-11-20 04:00:22 --> Router Class Initialized
INFO - 2021-11-20 04:00:22 --> Output Class Initialized
INFO - 2021-11-20 04:00:22 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:22 --> Input Class Initialized
INFO - 2021-11-20 04:00:22 --> Language Class Initialized
INFO - 2021-11-20 04:00:22 --> Language Class Initialized
INFO - 2021-11-20 04:00:22 --> Config Class Initialized
INFO - 2021-11-20 04:00:22 --> Loader Class Initialized
INFO - 2021-11-20 04:00:22 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:22 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:22 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:22 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:22 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:22 --> Controller Class Initialized
DEBUG - 2021-11-20 04:00:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-20 04:00:22 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:22 --> Total execution time: 0.0680
INFO - 2021-11-20 04:00:45 --> Config Class Initialized
INFO - 2021-11-20 04:00:45 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:45 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:45 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:45 --> URI Class Initialized
INFO - 2021-11-20 04:00:45 --> Router Class Initialized
INFO - 2021-11-20 04:00:45 --> Output Class Initialized
INFO - 2021-11-20 04:00:45 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:45 --> Input Class Initialized
INFO - 2021-11-20 04:00:45 --> Language Class Initialized
INFO - 2021-11-20 04:00:45 --> Language Class Initialized
INFO - 2021-11-20 04:00:45 --> Config Class Initialized
INFO - 2021-11-20 04:00:45 --> Loader Class Initialized
INFO - 2021-11-20 04:00:45 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:45 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:45 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:45 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:45 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:45 --> Controller Class Initialized
DEBUG - 2021-11-20 04:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-20 04:00:45 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:45 --> Total execution time: 0.0962
INFO - 2021-11-20 04:00:56 --> Config Class Initialized
INFO - 2021-11-20 04:00:56 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:00:56 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:00:56 --> Utf8 Class Initialized
INFO - 2021-11-20 04:00:56 --> URI Class Initialized
INFO - 2021-11-20 04:00:56 --> Router Class Initialized
INFO - 2021-11-20 04:00:56 --> Output Class Initialized
INFO - 2021-11-20 04:00:56 --> Security Class Initialized
DEBUG - 2021-11-20 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:00:56 --> Input Class Initialized
INFO - 2021-11-20 04:00:56 --> Language Class Initialized
INFO - 2021-11-20 04:00:57 --> Language Class Initialized
INFO - 2021-11-20 04:00:57 --> Config Class Initialized
INFO - 2021-11-20 04:00:57 --> Loader Class Initialized
INFO - 2021-11-20 04:00:57 --> Helper loaded: url_helper
INFO - 2021-11-20 04:00:57 --> Helper loaded: file_helper
INFO - 2021-11-20 04:00:57 --> Helper loaded: form_helper
INFO - 2021-11-20 04:00:57 --> Helper loaded: my_helper
INFO - 2021-11-20 04:00:57 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:00:57 --> Controller Class Initialized
DEBUG - 2021-11-20 04:00:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-20 04:00:57 --> Final output sent to browser
DEBUG - 2021-11-20 04:00:57 --> Total execution time: 0.0748
INFO - 2021-11-20 04:01:06 --> Config Class Initialized
INFO - 2021-11-20 04:01:06 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:06 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:06 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:06 --> URI Class Initialized
INFO - 2021-11-20 04:01:06 --> Router Class Initialized
INFO - 2021-11-20 04:01:06 --> Output Class Initialized
INFO - 2021-11-20 04:01:06 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:06 --> Input Class Initialized
INFO - 2021-11-20 04:01:06 --> Language Class Initialized
INFO - 2021-11-20 04:01:06 --> Language Class Initialized
INFO - 2021-11-20 04:01:06 --> Config Class Initialized
INFO - 2021-11-20 04:01:06 --> Loader Class Initialized
INFO - 2021-11-20 04:01:06 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:06 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:06 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:06 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:06 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:06 --> Controller Class Initialized
DEBUG - 2021-11-20 04:01:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-11-20 04:01:06 --> Final output sent to browser
DEBUG - 2021-11-20 04:01:06 --> Total execution time: 0.0915
INFO - 2021-11-20 04:01:25 --> Config Class Initialized
INFO - 2021-11-20 04:01:25 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:25 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:25 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:25 --> URI Class Initialized
INFO - 2021-11-20 04:01:25 --> Router Class Initialized
INFO - 2021-11-20 04:01:25 --> Output Class Initialized
INFO - 2021-11-20 04:01:25 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:25 --> Input Class Initialized
INFO - 2021-11-20 04:01:25 --> Language Class Initialized
INFO - 2021-11-20 04:01:25 --> Language Class Initialized
INFO - 2021-11-20 04:01:25 --> Config Class Initialized
INFO - 2021-11-20 04:01:25 --> Loader Class Initialized
INFO - 2021-11-20 04:01:25 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:25 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:25 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:25 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:25 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:25 --> Controller Class Initialized
INFO - 2021-11-20 04:01:25 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:01:25 --> Config Class Initialized
INFO - 2021-11-20 04:01:25 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:25 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:25 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:25 --> URI Class Initialized
INFO - 2021-11-20 04:01:25 --> Router Class Initialized
INFO - 2021-11-20 04:01:25 --> Output Class Initialized
INFO - 2021-11-20 04:01:25 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:25 --> Input Class Initialized
INFO - 2021-11-20 04:01:25 --> Language Class Initialized
INFO - 2021-11-20 04:01:25 --> Language Class Initialized
INFO - 2021-11-20 04:01:25 --> Config Class Initialized
INFO - 2021-11-20 04:01:25 --> Loader Class Initialized
INFO - 2021-11-20 04:01:25 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:25 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:25 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:25 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:25 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:25 --> Controller Class Initialized
DEBUG - 2021-11-20 04:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:01:25 --> Final output sent to browser
DEBUG - 2021-11-20 04:01:25 --> Total execution time: 0.0570
INFO - 2021-11-20 04:01:50 --> Config Class Initialized
INFO - 2021-11-20 04:01:50 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:50 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:50 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:50 --> URI Class Initialized
INFO - 2021-11-20 04:01:50 --> Router Class Initialized
INFO - 2021-11-20 04:01:50 --> Output Class Initialized
INFO - 2021-11-20 04:01:50 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:50 --> Input Class Initialized
INFO - 2021-11-20 04:01:50 --> Language Class Initialized
INFO - 2021-11-20 04:01:50 --> Language Class Initialized
INFO - 2021-11-20 04:01:50 --> Config Class Initialized
INFO - 2021-11-20 04:01:50 --> Loader Class Initialized
INFO - 2021-11-20 04:01:50 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:50 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:50 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:50 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:50 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:50 --> Controller Class Initialized
INFO - 2021-11-20 04:01:50 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:01:50 --> Final output sent to browser
DEBUG - 2021-11-20 04:01:50 --> Total execution time: 0.0665
INFO - 2021-11-20 04:01:50 --> Config Class Initialized
INFO - 2021-11-20 04:01:50 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:50 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:50 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:50 --> URI Class Initialized
INFO - 2021-11-20 04:01:50 --> Router Class Initialized
INFO - 2021-11-20 04:01:50 --> Output Class Initialized
INFO - 2021-11-20 04:01:50 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:50 --> Input Class Initialized
INFO - 2021-11-20 04:01:50 --> Language Class Initialized
INFO - 2021-11-20 04:01:50 --> Language Class Initialized
INFO - 2021-11-20 04:01:50 --> Config Class Initialized
INFO - 2021-11-20 04:01:50 --> Loader Class Initialized
INFO - 2021-11-20 04:01:50 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:50 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:50 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:50 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:50 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:50 --> Controller Class Initialized
DEBUG - 2021-11-20 04:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 04:01:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:01:50 --> Final output sent to browser
DEBUG - 2021-11-20 04:01:50 --> Total execution time: 0.2581
INFO - 2021-11-20 04:01:52 --> Config Class Initialized
INFO - 2021-11-20 04:01:52 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:52 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:52 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:52 --> URI Class Initialized
INFO - 2021-11-20 04:01:52 --> Router Class Initialized
INFO - 2021-11-20 04:01:52 --> Output Class Initialized
INFO - 2021-11-20 04:01:52 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:52 --> Input Class Initialized
INFO - 2021-11-20 04:01:52 --> Language Class Initialized
INFO - 2021-11-20 04:01:52 --> Language Class Initialized
INFO - 2021-11-20 04:01:52 --> Config Class Initialized
INFO - 2021-11-20 04:01:52 --> Loader Class Initialized
INFO - 2021-11-20 04:01:52 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:52 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:52 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:52 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:52 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:52 --> Controller Class Initialized
DEBUG - 2021-11-20 04:01:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 04:01:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:01:52 --> Final output sent to browser
DEBUG - 2021-11-20 04:01:52 --> Total execution time: 0.1075
INFO - 2021-11-20 04:01:54 --> Config Class Initialized
INFO - 2021-11-20 04:01:54 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:54 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:54 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:54 --> URI Class Initialized
INFO - 2021-11-20 04:01:54 --> Router Class Initialized
INFO - 2021-11-20 04:01:54 --> Output Class Initialized
INFO - 2021-11-20 04:01:54 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:54 --> Input Class Initialized
INFO - 2021-11-20 04:01:54 --> Language Class Initialized
INFO - 2021-11-20 04:01:54 --> Language Class Initialized
INFO - 2021-11-20 04:01:54 --> Config Class Initialized
INFO - 2021-11-20 04:01:54 --> Loader Class Initialized
INFO - 2021-11-20 04:01:54 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:54 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:54 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:54 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:54 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:01:54 --> Controller Class Initialized
DEBUG - 2021-11-20 04:01:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-20 04:01:54 --> Final output sent to browser
DEBUG - 2021-11-20 04:01:54 --> Total execution time: 0.1278
INFO - 2021-11-20 04:01:59 --> Config Class Initialized
INFO - 2021-11-20 04:01:59 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:01:59 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:01:59 --> Utf8 Class Initialized
INFO - 2021-11-20 04:01:59 --> URI Class Initialized
INFO - 2021-11-20 04:01:59 --> Router Class Initialized
INFO - 2021-11-20 04:01:59 --> Output Class Initialized
INFO - 2021-11-20 04:01:59 --> Security Class Initialized
DEBUG - 2021-11-20 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:01:59 --> Input Class Initialized
INFO - 2021-11-20 04:01:59 --> Language Class Initialized
INFO - 2021-11-20 04:01:59 --> Language Class Initialized
INFO - 2021-11-20 04:01:59 --> Config Class Initialized
INFO - 2021-11-20 04:01:59 --> Loader Class Initialized
INFO - 2021-11-20 04:01:59 --> Helper loaded: url_helper
INFO - 2021-11-20 04:01:59 --> Helper loaded: file_helper
INFO - 2021-11-20 04:01:59 --> Helper loaded: form_helper
INFO - 2021-11-20 04:01:59 --> Helper loaded: my_helper
INFO - 2021-11-20 04:01:59 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:00 --> Controller Class Initialized
DEBUG - 2021-11-20 04:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:02:00 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:00 --> Total execution time: 0.0897
INFO - 2021-11-20 04:02:07 --> Config Class Initialized
INFO - 2021-11-20 04:02:07 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:02:07 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:02:07 --> Utf8 Class Initialized
INFO - 2021-11-20 04:02:07 --> URI Class Initialized
INFO - 2021-11-20 04:02:07 --> Router Class Initialized
INFO - 2021-11-20 04:02:07 --> Output Class Initialized
INFO - 2021-11-20 04:02:07 --> Security Class Initialized
DEBUG - 2021-11-20 04:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:02:07 --> Input Class Initialized
INFO - 2021-11-20 04:02:07 --> Language Class Initialized
INFO - 2021-11-20 04:02:07 --> Language Class Initialized
INFO - 2021-11-20 04:02:07 --> Config Class Initialized
INFO - 2021-11-20 04:02:07 --> Loader Class Initialized
INFO - 2021-11-20 04:02:07 --> Helper loaded: url_helper
INFO - 2021-11-20 04:02:07 --> Helper loaded: file_helper
INFO - 2021-11-20 04:02:07 --> Helper loaded: form_helper
INFO - 2021-11-20 04:02:07 --> Helper loaded: my_helper
INFO - 2021-11-20 04:02:07 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:07 --> Controller Class Initialized
INFO - 2021-11-20 04:02:07 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:07 --> Total execution time: 0.1317
INFO - 2021-11-20 04:02:10 --> Config Class Initialized
INFO - 2021-11-20 04:02:10 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:02:10 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:02:10 --> Utf8 Class Initialized
INFO - 2021-11-20 04:02:10 --> URI Class Initialized
INFO - 2021-11-20 04:02:10 --> Router Class Initialized
INFO - 2021-11-20 04:02:10 --> Output Class Initialized
INFO - 2021-11-20 04:02:10 --> Security Class Initialized
DEBUG - 2021-11-20 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:02:10 --> Input Class Initialized
INFO - 2021-11-20 04:02:10 --> Language Class Initialized
INFO - 2021-11-20 04:02:10 --> Language Class Initialized
INFO - 2021-11-20 04:02:10 --> Config Class Initialized
INFO - 2021-11-20 04:02:10 --> Loader Class Initialized
INFO - 2021-11-20 04:02:10 --> Helper loaded: url_helper
INFO - 2021-11-20 04:02:10 --> Helper loaded: file_helper
INFO - 2021-11-20 04:02:10 --> Helper loaded: form_helper
INFO - 2021-11-20 04:02:10 --> Helper loaded: my_helper
INFO - 2021-11-20 04:02:10 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:10 --> Controller Class Initialized
DEBUG - 2021-11-20 04:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 04:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:02:10 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:10 --> Total execution time: 0.1225
INFO - 2021-11-20 04:02:21 --> Config Class Initialized
INFO - 2021-11-20 04:02:21 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:02:21 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:02:21 --> Utf8 Class Initialized
INFO - 2021-11-20 04:02:21 --> URI Class Initialized
INFO - 2021-11-20 04:02:21 --> Router Class Initialized
INFO - 2021-11-20 04:02:21 --> Output Class Initialized
INFO - 2021-11-20 04:02:21 --> Security Class Initialized
DEBUG - 2021-11-20 04:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:02:21 --> Input Class Initialized
INFO - 2021-11-20 04:02:21 --> Language Class Initialized
INFO - 2021-11-20 04:02:21 --> Language Class Initialized
INFO - 2021-11-20 04:02:21 --> Config Class Initialized
INFO - 2021-11-20 04:02:21 --> Loader Class Initialized
INFO - 2021-11-20 04:02:21 --> Helper loaded: url_helper
INFO - 2021-11-20 04:02:21 --> Helper loaded: file_helper
INFO - 2021-11-20 04:02:21 --> Helper loaded: form_helper
INFO - 2021-11-20 04:02:21 --> Helper loaded: my_helper
INFO - 2021-11-20 04:02:21 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:21 --> Controller Class Initialized
INFO - 2021-11-20 04:02:21 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:21 --> Total execution time: 0.1379
INFO - 2021-11-20 04:02:23 --> Config Class Initialized
INFO - 2021-11-20 04:02:23 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:02:23 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:02:23 --> Utf8 Class Initialized
INFO - 2021-11-20 04:02:23 --> URI Class Initialized
INFO - 2021-11-20 04:02:23 --> Router Class Initialized
INFO - 2021-11-20 04:02:23 --> Output Class Initialized
INFO - 2021-11-20 04:02:23 --> Security Class Initialized
DEBUG - 2021-11-20 04:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:02:23 --> Input Class Initialized
INFO - 2021-11-20 04:02:23 --> Language Class Initialized
INFO - 2021-11-20 04:02:23 --> Language Class Initialized
INFO - 2021-11-20 04:02:23 --> Config Class Initialized
INFO - 2021-11-20 04:02:23 --> Loader Class Initialized
INFO - 2021-11-20 04:02:23 --> Helper loaded: url_helper
INFO - 2021-11-20 04:02:23 --> Helper loaded: file_helper
INFO - 2021-11-20 04:02:23 --> Helper loaded: form_helper
INFO - 2021-11-20 04:02:23 --> Helper loaded: my_helper
INFO - 2021-11-20 04:02:23 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:23 --> Controller Class Initialized
DEBUG - 2021-11-20 04:02:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-20 04:02:23 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:23 --> Total execution time: 0.1002
INFO - 2021-11-20 04:02:45 --> Config Class Initialized
INFO - 2021-11-20 04:02:45 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:02:45 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:02:45 --> Utf8 Class Initialized
INFO - 2021-11-20 04:02:45 --> URI Class Initialized
INFO - 2021-11-20 04:02:45 --> Router Class Initialized
INFO - 2021-11-20 04:02:45 --> Output Class Initialized
INFO - 2021-11-20 04:02:45 --> Security Class Initialized
DEBUG - 2021-11-20 04:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:02:45 --> Input Class Initialized
INFO - 2021-11-20 04:02:45 --> Language Class Initialized
INFO - 2021-11-20 04:02:45 --> Language Class Initialized
INFO - 2021-11-20 04:02:45 --> Config Class Initialized
INFO - 2021-11-20 04:02:45 --> Loader Class Initialized
INFO - 2021-11-20 04:02:45 --> Helper loaded: url_helper
INFO - 2021-11-20 04:02:45 --> Helper loaded: file_helper
INFO - 2021-11-20 04:02:45 --> Helper loaded: form_helper
INFO - 2021-11-20 04:02:45 --> Helper loaded: my_helper
INFO - 2021-11-20 04:02:45 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:45 --> Controller Class Initialized
DEBUG - 2021-11-20 04:02:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-20 04:02:45 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:45 --> Total execution time: 0.0717
INFO - 2021-11-20 04:02:55 --> Config Class Initialized
INFO - 2021-11-20 04:02:55 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:02:55 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:02:55 --> Utf8 Class Initialized
INFO - 2021-11-20 04:02:55 --> URI Class Initialized
INFO - 2021-11-20 04:02:55 --> Router Class Initialized
INFO - 2021-11-20 04:02:55 --> Output Class Initialized
INFO - 2021-11-20 04:02:55 --> Security Class Initialized
DEBUG - 2021-11-20 04:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:02:55 --> Input Class Initialized
INFO - 2021-11-20 04:02:55 --> Language Class Initialized
INFO - 2021-11-20 04:02:55 --> Language Class Initialized
INFO - 2021-11-20 04:02:55 --> Config Class Initialized
INFO - 2021-11-20 04:02:55 --> Loader Class Initialized
INFO - 2021-11-20 04:02:55 --> Helper loaded: url_helper
INFO - 2021-11-20 04:02:55 --> Helper loaded: file_helper
INFO - 2021-11-20 04:02:55 --> Helper loaded: form_helper
INFO - 2021-11-20 04:02:55 --> Helper loaded: my_helper
INFO - 2021-11-20 04:02:55 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:02:55 --> Controller Class Initialized
DEBUG - 2021-11-20 04:02:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-11-20 04:02:55 --> Final output sent to browser
DEBUG - 2021-11-20 04:02:55 --> Total execution time: 0.0759
INFO - 2021-11-20 04:03:15 --> Config Class Initialized
INFO - 2021-11-20 04:03:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:03:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:03:15 --> Utf8 Class Initialized
INFO - 2021-11-20 04:03:15 --> URI Class Initialized
INFO - 2021-11-20 04:03:15 --> Router Class Initialized
INFO - 2021-11-20 04:03:15 --> Output Class Initialized
INFO - 2021-11-20 04:03:15 --> Security Class Initialized
DEBUG - 2021-11-20 04:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:03:15 --> Input Class Initialized
INFO - 2021-11-20 04:03:15 --> Language Class Initialized
INFO - 2021-11-20 04:03:15 --> Language Class Initialized
INFO - 2021-11-20 04:03:15 --> Config Class Initialized
INFO - 2021-11-20 04:03:15 --> Loader Class Initialized
INFO - 2021-11-20 04:03:15 --> Helper loaded: url_helper
INFO - 2021-11-20 04:03:15 --> Helper loaded: file_helper
INFO - 2021-11-20 04:03:15 --> Helper loaded: form_helper
INFO - 2021-11-20 04:03:15 --> Helper loaded: my_helper
INFO - 2021-11-20 04:03:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:03:15 --> Controller Class Initialized
INFO - 2021-11-20 04:03:15 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:03:15 --> Config Class Initialized
INFO - 2021-11-20 04:03:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:03:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:03:15 --> Utf8 Class Initialized
INFO - 2021-11-20 04:03:15 --> URI Class Initialized
INFO - 2021-11-20 04:03:15 --> Router Class Initialized
INFO - 2021-11-20 04:03:15 --> Output Class Initialized
INFO - 2021-11-20 04:03:15 --> Security Class Initialized
DEBUG - 2021-11-20 04:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:03:15 --> Input Class Initialized
INFO - 2021-11-20 04:03:15 --> Language Class Initialized
INFO - 2021-11-20 04:03:15 --> Language Class Initialized
INFO - 2021-11-20 04:03:15 --> Config Class Initialized
INFO - 2021-11-20 04:03:15 --> Loader Class Initialized
INFO - 2021-11-20 04:03:15 --> Helper loaded: url_helper
INFO - 2021-11-20 04:03:15 --> Helper loaded: file_helper
INFO - 2021-11-20 04:03:15 --> Helper loaded: form_helper
INFO - 2021-11-20 04:03:15 --> Helper loaded: my_helper
INFO - 2021-11-20 04:03:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:03:15 --> Controller Class Initialized
DEBUG - 2021-11-20 04:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:03:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:03:15 --> Final output sent to browser
DEBUG - 2021-11-20 04:03:15 --> Total execution time: 0.0526
INFO - 2021-11-20 04:03:57 --> Config Class Initialized
INFO - 2021-11-20 04:03:57 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:03:57 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:03:57 --> Utf8 Class Initialized
INFO - 2021-11-20 04:03:57 --> URI Class Initialized
INFO - 2021-11-20 04:03:57 --> Router Class Initialized
INFO - 2021-11-20 04:03:57 --> Output Class Initialized
INFO - 2021-11-20 04:03:57 --> Security Class Initialized
DEBUG - 2021-11-20 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:03:57 --> Input Class Initialized
INFO - 2021-11-20 04:03:57 --> Language Class Initialized
INFO - 2021-11-20 04:03:57 --> Language Class Initialized
INFO - 2021-11-20 04:03:57 --> Config Class Initialized
INFO - 2021-11-20 04:03:57 --> Loader Class Initialized
INFO - 2021-11-20 04:03:57 --> Helper loaded: url_helper
INFO - 2021-11-20 04:03:57 --> Helper loaded: file_helper
INFO - 2021-11-20 04:03:57 --> Helper loaded: form_helper
INFO - 2021-11-20 04:03:57 --> Helper loaded: my_helper
INFO - 2021-11-20 04:03:57 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:03:57 --> Controller Class Initialized
INFO - 2021-11-20 04:03:57 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:03:57 --> Final output sent to browser
DEBUG - 2021-11-20 04:03:57 --> Total execution time: 0.0698
INFO - 2021-11-20 04:03:58 --> Config Class Initialized
INFO - 2021-11-20 04:03:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:03:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:03:58 --> Utf8 Class Initialized
INFO - 2021-11-20 04:03:58 --> URI Class Initialized
INFO - 2021-11-20 04:03:58 --> Router Class Initialized
INFO - 2021-11-20 04:03:58 --> Output Class Initialized
INFO - 2021-11-20 04:03:58 --> Security Class Initialized
DEBUG - 2021-11-20 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:03:58 --> Input Class Initialized
INFO - 2021-11-20 04:03:58 --> Language Class Initialized
INFO - 2021-11-20 04:03:58 --> Language Class Initialized
INFO - 2021-11-20 04:03:58 --> Config Class Initialized
INFO - 2021-11-20 04:03:58 --> Loader Class Initialized
INFO - 2021-11-20 04:03:58 --> Helper loaded: url_helper
INFO - 2021-11-20 04:03:58 --> Helper loaded: file_helper
INFO - 2021-11-20 04:03:58 --> Helper loaded: form_helper
INFO - 2021-11-20 04:03:58 --> Helper loaded: my_helper
INFO - 2021-11-20 04:03:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:03:58 --> Controller Class Initialized
DEBUG - 2021-11-20 04:03:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 04:03:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:03:58 --> Final output sent to browser
DEBUG - 2021-11-20 04:03:58 --> Total execution time: 0.2548
INFO - 2021-11-20 04:05:39 --> Config Class Initialized
INFO - 2021-11-20 04:05:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:05:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:05:39 --> Utf8 Class Initialized
INFO - 2021-11-20 04:05:39 --> URI Class Initialized
INFO - 2021-11-20 04:05:39 --> Router Class Initialized
INFO - 2021-11-20 04:05:39 --> Output Class Initialized
INFO - 2021-11-20 04:05:39 --> Security Class Initialized
DEBUG - 2021-11-20 04:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:05:39 --> Input Class Initialized
INFO - 2021-11-20 04:05:39 --> Language Class Initialized
INFO - 2021-11-20 04:05:39 --> Language Class Initialized
INFO - 2021-11-20 04:05:39 --> Config Class Initialized
INFO - 2021-11-20 04:05:39 --> Loader Class Initialized
INFO - 2021-11-20 04:05:39 --> Helper loaded: url_helper
INFO - 2021-11-20 04:05:39 --> Helper loaded: file_helper
INFO - 2021-11-20 04:05:39 --> Helper loaded: form_helper
INFO - 2021-11-20 04:05:39 --> Helper loaded: my_helper
INFO - 2021-11-20 04:05:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:05:39 --> Controller Class Initialized
DEBUG - 2021-11-20 04:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 04:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:05:39 --> Final output sent to browser
DEBUG - 2021-11-20 04:05:39 --> Total execution time: 0.1060
INFO - 2021-11-20 04:06:05 --> Config Class Initialized
INFO - 2021-11-20 04:06:05 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:05 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:05 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:05 --> URI Class Initialized
INFO - 2021-11-20 04:06:05 --> Router Class Initialized
INFO - 2021-11-20 04:06:05 --> Output Class Initialized
INFO - 2021-11-20 04:06:05 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:05 --> Input Class Initialized
INFO - 2021-11-20 04:06:05 --> Language Class Initialized
INFO - 2021-11-20 04:06:05 --> Language Class Initialized
INFO - 2021-11-20 04:06:05 --> Config Class Initialized
INFO - 2021-11-20 04:06:05 --> Loader Class Initialized
INFO - 2021-11-20 04:06:05 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:05 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:05 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:05 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:05 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:05 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-20 04:06:05 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:05 --> Total execution time: 0.1409
INFO - 2021-11-20 04:06:10 --> Config Class Initialized
INFO - 2021-11-20 04:06:10 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:10 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:10 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:10 --> URI Class Initialized
INFO - 2021-11-20 04:06:10 --> Router Class Initialized
INFO - 2021-11-20 04:06:10 --> Output Class Initialized
INFO - 2021-11-20 04:06:10 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:10 --> Input Class Initialized
INFO - 2021-11-20 04:06:10 --> Language Class Initialized
INFO - 2021-11-20 04:06:10 --> Language Class Initialized
INFO - 2021-11-20 04:06:10 --> Config Class Initialized
INFO - 2021-11-20 04:06:10 --> Loader Class Initialized
INFO - 2021-11-20 04:06:10 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:10 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:10 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:10 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:10 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:10 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:06:10 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:10 --> Total execution time: 0.0848
INFO - 2021-11-20 04:06:15 --> Config Class Initialized
INFO - 2021-11-20 04:06:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:15 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:15 --> URI Class Initialized
INFO - 2021-11-20 04:06:15 --> Router Class Initialized
INFO - 2021-11-20 04:06:15 --> Output Class Initialized
INFO - 2021-11-20 04:06:15 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:15 --> Input Class Initialized
INFO - 2021-11-20 04:06:15 --> Language Class Initialized
INFO - 2021-11-20 04:06:15 --> Language Class Initialized
INFO - 2021-11-20 04:06:15 --> Config Class Initialized
INFO - 2021-11-20 04:06:15 --> Loader Class Initialized
INFO - 2021-11-20 04:06:15 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:15 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:15 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:15 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:15 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 04:06:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:06:15 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:15 --> Total execution time: 0.1419
INFO - 2021-11-20 04:06:23 --> Config Class Initialized
INFO - 2021-11-20 04:06:23 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:23 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:23 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:23 --> URI Class Initialized
INFO - 2021-11-20 04:06:23 --> Router Class Initialized
INFO - 2021-11-20 04:06:23 --> Output Class Initialized
INFO - 2021-11-20 04:06:23 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:23 --> Input Class Initialized
INFO - 2021-11-20 04:06:23 --> Language Class Initialized
INFO - 2021-11-20 04:06:23 --> Language Class Initialized
INFO - 2021-11-20 04:06:23 --> Config Class Initialized
INFO - 2021-11-20 04:06:23 --> Loader Class Initialized
INFO - 2021-11-20 04:06:23 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:23 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:23 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:23 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:23 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:23 --> Controller Class Initialized
INFO - 2021-11-20 04:06:23 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:23 --> Total execution time: 0.1302
INFO - 2021-11-20 04:06:25 --> Config Class Initialized
INFO - 2021-11-20 04:06:25 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:25 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:25 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:25 --> URI Class Initialized
INFO - 2021-11-20 04:06:25 --> Router Class Initialized
INFO - 2021-11-20 04:06:25 --> Output Class Initialized
INFO - 2021-11-20 04:06:25 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:25 --> Input Class Initialized
INFO - 2021-11-20 04:06:25 --> Language Class Initialized
INFO - 2021-11-20 04:06:25 --> Language Class Initialized
INFO - 2021-11-20 04:06:25 --> Config Class Initialized
INFO - 2021-11-20 04:06:25 --> Loader Class Initialized
INFO - 2021-11-20 04:06:25 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:25 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:25 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:25 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:25 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:25 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-20 04:06:25 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:25 --> Total execution time: 0.0817
INFO - 2021-11-20 04:06:30 --> Config Class Initialized
INFO - 2021-11-20 04:06:30 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:30 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:30 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:30 --> URI Class Initialized
INFO - 2021-11-20 04:06:30 --> Router Class Initialized
INFO - 2021-11-20 04:06:30 --> Output Class Initialized
INFO - 2021-11-20 04:06:30 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:30 --> Input Class Initialized
INFO - 2021-11-20 04:06:30 --> Language Class Initialized
INFO - 2021-11-20 04:06:30 --> Language Class Initialized
INFO - 2021-11-20 04:06:30 --> Config Class Initialized
INFO - 2021-11-20 04:06:30 --> Loader Class Initialized
INFO - 2021-11-20 04:06:30 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:30 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:30 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:30 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:30 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:30 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:06:30 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:30 --> Total execution time: 0.0839
INFO - 2021-11-20 04:06:33 --> Config Class Initialized
INFO - 2021-11-20 04:06:33 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:33 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:33 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:33 --> URI Class Initialized
INFO - 2021-11-20 04:06:33 --> Router Class Initialized
INFO - 2021-11-20 04:06:33 --> Output Class Initialized
INFO - 2021-11-20 04:06:33 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:33 --> Input Class Initialized
INFO - 2021-11-20 04:06:33 --> Language Class Initialized
INFO - 2021-11-20 04:06:33 --> Language Class Initialized
INFO - 2021-11-20 04:06:33 --> Config Class Initialized
INFO - 2021-11-20 04:06:33 --> Loader Class Initialized
INFO - 2021-11-20 04:06:33 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:33 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:33 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:33 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:33 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:33 --> Controller Class Initialized
INFO - 2021-11-20 04:06:33 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:33 --> Total execution time: 0.1256
INFO - 2021-11-20 04:06:35 --> Config Class Initialized
INFO - 2021-11-20 04:06:35 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:35 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:35 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:35 --> URI Class Initialized
INFO - 2021-11-20 04:06:35 --> Router Class Initialized
INFO - 2021-11-20 04:06:35 --> Output Class Initialized
INFO - 2021-11-20 04:06:35 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:35 --> Input Class Initialized
INFO - 2021-11-20 04:06:35 --> Language Class Initialized
INFO - 2021-11-20 04:06:35 --> Language Class Initialized
INFO - 2021-11-20 04:06:35 --> Config Class Initialized
INFO - 2021-11-20 04:06:35 --> Loader Class Initialized
INFO - 2021-11-20 04:06:35 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:35 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:35 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:35 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:35 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:35 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-20 04:06:35 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:35 --> Total execution time: 0.0955
INFO - 2021-11-20 04:06:57 --> Config Class Initialized
INFO - 2021-11-20 04:06:57 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:06:57 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:06:57 --> Utf8 Class Initialized
INFO - 2021-11-20 04:06:57 --> URI Class Initialized
INFO - 2021-11-20 04:06:57 --> Router Class Initialized
INFO - 2021-11-20 04:06:57 --> Output Class Initialized
INFO - 2021-11-20 04:06:57 --> Security Class Initialized
DEBUG - 2021-11-20 04:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:06:57 --> Input Class Initialized
INFO - 2021-11-20 04:06:57 --> Language Class Initialized
INFO - 2021-11-20 04:06:57 --> Language Class Initialized
INFO - 2021-11-20 04:06:57 --> Config Class Initialized
INFO - 2021-11-20 04:06:57 --> Loader Class Initialized
INFO - 2021-11-20 04:06:57 --> Helper loaded: url_helper
INFO - 2021-11-20 04:06:57 --> Helper loaded: file_helper
INFO - 2021-11-20 04:06:57 --> Helper loaded: form_helper
INFO - 2021-11-20 04:06:57 --> Helper loaded: my_helper
INFO - 2021-11-20 04:06:57 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:06:57 --> Controller Class Initialized
DEBUG - 2021-11-20 04:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-20 04:06:57 --> Final output sent to browser
DEBUG - 2021-11-20 04:06:57 --> Total execution time: 0.0739
INFO - 2021-11-20 04:07:07 --> Config Class Initialized
INFO - 2021-11-20 04:07:07 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:07:07 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:07:07 --> Utf8 Class Initialized
INFO - 2021-11-20 04:07:07 --> URI Class Initialized
INFO - 2021-11-20 04:07:07 --> Router Class Initialized
INFO - 2021-11-20 04:07:07 --> Output Class Initialized
INFO - 2021-11-20 04:07:07 --> Security Class Initialized
DEBUG - 2021-11-20 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:07:07 --> Input Class Initialized
INFO - 2021-11-20 04:07:07 --> Language Class Initialized
INFO - 2021-11-20 04:07:07 --> Language Class Initialized
INFO - 2021-11-20 04:07:07 --> Config Class Initialized
INFO - 2021-11-20 04:07:07 --> Loader Class Initialized
INFO - 2021-11-20 04:07:07 --> Helper loaded: url_helper
INFO - 2021-11-20 04:07:07 --> Helper loaded: file_helper
INFO - 2021-11-20 04:07:07 --> Helper loaded: form_helper
INFO - 2021-11-20 04:07:07 --> Helper loaded: my_helper
INFO - 2021-11-20 04:07:07 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:07:07 --> Controller Class Initialized
DEBUG - 2021-11-20 04:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-20 04:07:08 --> Final output sent to browser
DEBUG - 2021-11-20 04:07:08 --> Total execution time: 0.0933
INFO - 2021-11-20 04:07:20 --> Config Class Initialized
INFO - 2021-11-20 04:07:20 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:07:20 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:07:20 --> Utf8 Class Initialized
INFO - 2021-11-20 04:07:20 --> URI Class Initialized
INFO - 2021-11-20 04:07:20 --> Router Class Initialized
INFO - 2021-11-20 04:07:20 --> Output Class Initialized
INFO - 2021-11-20 04:07:20 --> Security Class Initialized
DEBUG - 2021-11-20 04:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:07:20 --> Input Class Initialized
INFO - 2021-11-20 04:07:20 --> Language Class Initialized
INFO - 2021-11-20 04:07:20 --> Language Class Initialized
INFO - 2021-11-20 04:07:20 --> Config Class Initialized
INFO - 2021-11-20 04:07:20 --> Loader Class Initialized
INFO - 2021-11-20 04:07:20 --> Helper loaded: url_helper
INFO - 2021-11-20 04:07:20 --> Helper loaded: file_helper
INFO - 2021-11-20 04:07:20 --> Helper loaded: form_helper
INFO - 2021-11-20 04:07:20 --> Helper loaded: my_helper
INFO - 2021-11-20 04:07:20 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:07:20 --> Controller Class Initialized
DEBUG - 2021-11-20 04:07:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-11-20 04:07:20 --> Final output sent to browser
DEBUG - 2021-11-20 04:07:20 --> Total execution time: 0.0847
INFO - 2021-11-20 04:07:39 --> Config Class Initialized
INFO - 2021-11-20 04:07:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:07:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:07:39 --> Utf8 Class Initialized
INFO - 2021-11-20 04:07:39 --> URI Class Initialized
INFO - 2021-11-20 04:07:39 --> Router Class Initialized
INFO - 2021-11-20 04:07:39 --> Output Class Initialized
INFO - 2021-11-20 04:07:39 --> Security Class Initialized
DEBUG - 2021-11-20 04:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:07:39 --> Input Class Initialized
INFO - 2021-11-20 04:07:39 --> Language Class Initialized
INFO - 2021-11-20 04:07:39 --> Language Class Initialized
INFO - 2021-11-20 04:07:39 --> Config Class Initialized
INFO - 2021-11-20 04:07:39 --> Loader Class Initialized
INFO - 2021-11-20 04:07:39 --> Helper loaded: url_helper
INFO - 2021-11-20 04:07:39 --> Helper loaded: file_helper
INFO - 2021-11-20 04:07:39 --> Helper loaded: form_helper
INFO - 2021-11-20 04:07:39 --> Helper loaded: my_helper
INFO - 2021-11-20 04:07:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:07:39 --> Controller Class Initialized
INFO - 2021-11-20 04:07:39 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:07:39 --> Config Class Initialized
INFO - 2021-11-20 04:07:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:07:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:07:39 --> Utf8 Class Initialized
INFO - 2021-11-20 04:07:39 --> URI Class Initialized
INFO - 2021-11-20 04:07:39 --> Router Class Initialized
INFO - 2021-11-20 04:07:39 --> Output Class Initialized
INFO - 2021-11-20 04:07:39 --> Security Class Initialized
DEBUG - 2021-11-20 04:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:07:39 --> Input Class Initialized
INFO - 2021-11-20 04:07:39 --> Language Class Initialized
INFO - 2021-11-20 04:07:39 --> Language Class Initialized
INFO - 2021-11-20 04:07:39 --> Config Class Initialized
INFO - 2021-11-20 04:07:39 --> Loader Class Initialized
INFO - 2021-11-20 04:07:39 --> Helper loaded: url_helper
INFO - 2021-11-20 04:07:39 --> Helper loaded: file_helper
INFO - 2021-11-20 04:07:39 --> Helper loaded: form_helper
INFO - 2021-11-20 04:07:39 --> Helper loaded: my_helper
INFO - 2021-11-20 04:07:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:07:39 --> Controller Class Initialized
DEBUG - 2021-11-20 04:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:07:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:07:39 --> Final output sent to browser
DEBUG - 2021-11-20 04:07:39 --> Total execution time: 0.0683
INFO - 2021-11-20 04:07:57 --> Config Class Initialized
INFO - 2021-11-20 04:07:57 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:07:57 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:07:57 --> Utf8 Class Initialized
INFO - 2021-11-20 04:07:57 --> URI Class Initialized
INFO - 2021-11-20 04:07:57 --> Router Class Initialized
INFO - 2021-11-20 04:07:57 --> Output Class Initialized
INFO - 2021-11-20 04:07:57 --> Security Class Initialized
DEBUG - 2021-11-20 04:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:07:57 --> Input Class Initialized
INFO - 2021-11-20 04:07:57 --> Language Class Initialized
INFO - 2021-11-20 04:07:57 --> Language Class Initialized
INFO - 2021-11-20 04:07:57 --> Config Class Initialized
INFO - 2021-11-20 04:07:57 --> Loader Class Initialized
INFO - 2021-11-20 04:07:57 --> Helper loaded: url_helper
INFO - 2021-11-20 04:07:57 --> Helper loaded: file_helper
INFO - 2021-11-20 04:07:57 --> Helper loaded: form_helper
INFO - 2021-11-20 04:07:57 --> Helper loaded: my_helper
INFO - 2021-11-20 04:07:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:07:58 --> Controller Class Initialized
INFO - 2021-11-20 04:07:58 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:07:58 --> Final output sent to browser
DEBUG - 2021-11-20 04:07:58 --> Total execution time: 0.0670
INFO - 2021-11-20 04:07:58 --> Config Class Initialized
INFO - 2021-11-20 04:07:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:07:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:07:58 --> Utf8 Class Initialized
INFO - 2021-11-20 04:07:58 --> URI Class Initialized
INFO - 2021-11-20 04:07:58 --> Router Class Initialized
INFO - 2021-11-20 04:07:58 --> Output Class Initialized
INFO - 2021-11-20 04:07:58 --> Security Class Initialized
DEBUG - 2021-11-20 04:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:07:58 --> Input Class Initialized
INFO - 2021-11-20 04:07:58 --> Language Class Initialized
INFO - 2021-11-20 04:07:58 --> Language Class Initialized
INFO - 2021-11-20 04:07:58 --> Config Class Initialized
INFO - 2021-11-20 04:07:58 --> Loader Class Initialized
INFO - 2021-11-20 04:07:58 --> Helper loaded: url_helper
INFO - 2021-11-20 04:07:58 --> Helper loaded: file_helper
INFO - 2021-11-20 04:07:58 --> Helper loaded: form_helper
INFO - 2021-11-20 04:07:58 --> Helper loaded: my_helper
INFO - 2021-11-20 04:07:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:07:58 --> Controller Class Initialized
DEBUG - 2021-11-20 04:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 04:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:07:58 --> Final output sent to browser
DEBUG - 2021-11-20 04:07:58 --> Total execution time: 0.2582
INFO - 2021-11-20 04:08:01 --> Config Class Initialized
INFO - 2021-11-20 04:08:01 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:01 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:01 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:01 --> URI Class Initialized
INFO - 2021-11-20 04:08:01 --> Router Class Initialized
INFO - 2021-11-20 04:08:01 --> Output Class Initialized
INFO - 2021-11-20 04:08:01 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:01 --> Input Class Initialized
INFO - 2021-11-20 04:08:01 --> Language Class Initialized
INFO - 2021-11-20 04:08:01 --> Language Class Initialized
INFO - 2021-11-20 04:08:01 --> Config Class Initialized
INFO - 2021-11-20 04:08:01 --> Loader Class Initialized
INFO - 2021-11-20 04:08:01 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:01 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:01 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:01 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:01 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:01 --> Controller Class Initialized
DEBUG - 2021-11-20 04:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 04:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:08:01 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:01 --> Total execution time: 0.0961
INFO - 2021-11-20 04:08:05 --> Config Class Initialized
INFO - 2021-11-20 04:08:05 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:05 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:05 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:05 --> URI Class Initialized
INFO - 2021-11-20 04:08:05 --> Router Class Initialized
INFO - 2021-11-20 04:08:05 --> Output Class Initialized
INFO - 2021-11-20 04:08:05 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:05 --> Input Class Initialized
INFO - 2021-11-20 04:08:05 --> Language Class Initialized
INFO - 2021-11-20 04:08:05 --> Language Class Initialized
INFO - 2021-11-20 04:08:05 --> Config Class Initialized
INFO - 2021-11-20 04:08:05 --> Loader Class Initialized
INFO - 2021-11-20 04:08:05 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:05 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:05 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:05 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:05 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:05 --> Controller Class Initialized
DEBUG - 2021-11-20 04:08:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-20 04:08:05 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:05 --> Total execution time: 0.1936
INFO - 2021-11-20 04:08:07 --> Config Class Initialized
INFO - 2021-11-20 04:08:07 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:07 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:07 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:07 --> URI Class Initialized
INFO - 2021-11-20 04:08:07 --> Router Class Initialized
INFO - 2021-11-20 04:08:07 --> Output Class Initialized
INFO - 2021-11-20 04:08:07 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:07 --> Input Class Initialized
INFO - 2021-11-20 04:08:07 --> Language Class Initialized
INFO - 2021-11-20 04:08:07 --> Language Class Initialized
INFO - 2021-11-20 04:08:07 --> Config Class Initialized
INFO - 2021-11-20 04:08:07 --> Loader Class Initialized
INFO - 2021-11-20 04:08:07 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:07 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:07 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:07 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:07 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:07 --> Controller Class Initialized
DEBUG - 2021-11-20 04:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:08:07 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:07 --> Total execution time: 0.1176
INFO - 2021-11-20 04:08:11 --> Config Class Initialized
INFO - 2021-11-20 04:08:11 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:11 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:11 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:11 --> URI Class Initialized
INFO - 2021-11-20 04:08:11 --> Router Class Initialized
INFO - 2021-11-20 04:08:11 --> Output Class Initialized
INFO - 2021-11-20 04:08:11 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:11 --> Input Class Initialized
INFO - 2021-11-20 04:08:11 --> Language Class Initialized
INFO - 2021-11-20 04:08:11 --> Language Class Initialized
INFO - 2021-11-20 04:08:11 --> Config Class Initialized
INFO - 2021-11-20 04:08:11 --> Loader Class Initialized
INFO - 2021-11-20 04:08:11 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:11 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:11 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:11 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:11 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:11 --> Controller Class Initialized
INFO - 2021-11-20 04:08:11 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:11 --> Total execution time: 0.1460
INFO - 2021-11-20 04:08:15 --> Config Class Initialized
INFO - 2021-11-20 04:08:15 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:15 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:15 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:15 --> URI Class Initialized
INFO - 2021-11-20 04:08:15 --> Router Class Initialized
INFO - 2021-11-20 04:08:15 --> Output Class Initialized
INFO - 2021-11-20 04:08:15 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:15 --> Input Class Initialized
INFO - 2021-11-20 04:08:15 --> Language Class Initialized
INFO - 2021-11-20 04:08:15 --> Language Class Initialized
INFO - 2021-11-20 04:08:15 --> Config Class Initialized
INFO - 2021-11-20 04:08:15 --> Loader Class Initialized
INFO - 2021-11-20 04:08:15 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:15 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:15 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:15 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:15 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:15 --> Controller Class Initialized
DEBUG - 2021-11-20 04:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 04:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:08:15 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:15 --> Total execution time: 0.1354
INFO - 2021-11-20 04:08:24 --> Config Class Initialized
INFO - 2021-11-20 04:08:24 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:24 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:24 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:24 --> URI Class Initialized
INFO - 2021-11-20 04:08:24 --> Router Class Initialized
INFO - 2021-11-20 04:08:24 --> Output Class Initialized
INFO - 2021-11-20 04:08:24 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:24 --> Input Class Initialized
INFO - 2021-11-20 04:08:24 --> Language Class Initialized
INFO - 2021-11-20 04:08:24 --> Language Class Initialized
INFO - 2021-11-20 04:08:24 --> Config Class Initialized
INFO - 2021-11-20 04:08:24 --> Loader Class Initialized
INFO - 2021-11-20 04:08:24 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:24 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:24 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:24 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:24 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:24 --> Controller Class Initialized
INFO - 2021-11-20 04:08:24 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:24 --> Total execution time: 0.1495
INFO - 2021-11-20 04:08:27 --> Config Class Initialized
INFO - 2021-11-20 04:08:27 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:27 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:27 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:27 --> URI Class Initialized
INFO - 2021-11-20 04:08:27 --> Router Class Initialized
INFO - 2021-11-20 04:08:27 --> Output Class Initialized
INFO - 2021-11-20 04:08:27 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:27 --> Input Class Initialized
INFO - 2021-11-20 04:08:27 --> Language Class Initialized
INFO - 2021-11-20 04:08:27 --> Language Class Initialized
INFO - 2021-11-20 04:08:27 --> Config Class Initialized
INFO - 2021-11-20 04:08:27 --> Loader Class Initialized
INFO - 2021-11-20 04:08:27 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:27 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:27 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:27 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:27 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:27 --> Controller Class Initialized
DEBUG - 2021-11-20 04:08:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-20 04:08:27 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:27 --> Total execution time: 0.0992
INFO - 2021-11-20 04:08:55 --> Config Class Initialized
INFO - 2021-11-20 04:08:55 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:08:55 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:08:55 --> Utf8 Class Initialized
INFO - 2021-11-20 04:08:55 --> URI Class Initialized
INFO - 2021-11-20 04:08:55 --> Router Class Initialized
INFO - 2021-11-20 04:08:55 --> Output Class Initialized
INFO - 2021-11-20 04:08:55 --> Security Class Initialized
DEBUG - 2021-11-20 04:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:08:55 --> Input Class Initialized
INFO - 2021-11-20 04:08:55 --> Language Class Initialized
INFO - 2021-11-20 04:08:55 --> Language Class Initialized
INFO - 2021-11-20 04:08:55 --> Config Class Initialized
INFO - 2021-11-20 04:08:55 --> Loader Class Initialized
INFO - 2021-11-20 04:08:55 --> Helper loaded: url_helper
INFO - 2021-11-20 04:08:55 --> Helper loaded: file_helper
INFO - 2021-11-20 04:08:55 --> Helper loaded: form_helper
INFO - 2021-11-20 04:08:55 --> Helper loaded: my_helper
INFO - 2021-11-20 04:08:55 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:08:55 --> Controller Class Initialized
DEBUG - 2021-11-20 04:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-20 04:08:55 --> Final output sent to browser
DEBUG - 2021-11-20 04:08:55 --> Total execution time: 0.0973
INFO - 2021-11-20 04:09:04 --> Config Class Initialized
INFO - 2021-11-20 04:09:04 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:09:04 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:09:04 --> Utf8 Class Initialized
INFO - 2021-11-20 04:09:04 --> URI Class Initialized
INFO - 2021-11-20 04:09:04 --> Router Class Initialized
INFO - 2021-11-20 04:09:04 --> Output Class Initialized
INFO - 2021-11-20 04:09:04 --> Security Class Initialized
DEBUG - 2021-11-20 04:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:09:04 --> Input Class Initialized
INFO - 2021-11-20 04:09:04 --> Language Class Initialized
INFO - 2021-11-20 04:09:04 --> Language Class Initialized
INFO - 2021-11-20 04:09:04 --> Config Class Initialized
INFO - 2021-11-20 04:09:04 --> Loader Class Initialized
INFO - 2021-11-20 04:09:04 --> Helper loaded: url_helper
INFO - 2021-11-20 04:09:04 --> Helper loaded: file_helper
INFO - 2021-11-20 04:09:04 --> Helper loaded: form_helper
INFO - 2021-11-20 04:09:04 --> Helper loaded: my_helper
INFO - 2021-11-20 04:09:04 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:09:04 --> Controller Class Initialized
DEBUG - 2021-11-20 04:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-20 04:09:04 --> Final output sent to browser
DEBUG - 2021-11-20 04:09:04 --> Total execution time: 0.0888
INFO - 2021-11-20 04:09:14 --> Config Class Initialized
INFO - 2021-11-20 04:09:14 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:09:14 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:09:14 --> Utf8 Class Initialized
INFO - 2021-11-20 04:09:14 --> URI Class Initialized
INFO - 2021-11-20 04:09:14 --> Router Class Initialized
INFO - 2021-11-20 04:09:14 --> Output Class Initialized
INFO - 2021-11-20 04:09:14 --> Security Class Initialized
DEBUG - 2021-11-20 04:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:09:14 --> Input Class Initialized
INFO - 2021-11-20 04:09:14 --> Language Class Initialized
INFO - 2021-11-20 04:09:14 --> Language Class Initialized
INFO - 2021-11-20 04:09:14 --> Config Class Initialized
INFO - 2021-11-20 04:09:14 --> Loader Class Initialized
INFO - 2021-11-20 04:09:14 --> Helper loaded: url_helper
INFO - 2021-11-20 04:09:14 --> Helper loaded: file_helper
INFO - 2021-11-20 04:09:14 --> Helper loaded: form_helper
INFO - 2021-11-20 04:09:14 --> Helper loaded: my_helper
INFO - 2021-11-20 04:09:14 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:09:14 --> Controller Class Initialized
DEBUG - 2021-11-20 04:09:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-11-20 04:09:14 --> Final output sent to browser
DEBUG - 2021-11-20 04:09:14 --> Total execution time: 0.1022
INFO - 2021-11-20 04:09:29 --> Config Class Initialized
INFO - 2021-11-20 04:09:29 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:09:29 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:09:29 --> Utf8 Class Initialized
INFO - 2021-11-20 04:09:29 --> URI Class Initialized
INFO - 2021-11-20 04:09:29 --> Router Class Initialized
INFO - 2021-11-20 04:09:29 --> Output Class Initialized
INFO - 2021-11-20 04:09:29 --> Security Class Initialized
DEBUG - 2021-11-20 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:09:29 --> Input Class Initialized
INFO - 2021-11-20 04:09:29 --> Language Class Initialized
INFO - 2021-11-20 04:09:29 --> Language Class Initialized
INFO - 2021-11-20 04:09:29 --> Config Class Initialized
INFO - 2021-11-20 04:09:29 --> Loader Class Initialized
INFO - 2021-11-20 04:09:29 --> Helper loaded: url_helper
INFO - 2021-11-20 04:09:29 --> Helper loaded: file_helper
INFO - 2021-11-20 04:09:29 --> Helper loaded: form_helper
INFO - 2021-11-20 04:09:29 --> Helper loaded: my_helper
INFO - 2021-11-20 04:09:29 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:09:29 --> Controller Class Initialized
INFO - 2021-11-20 04:09:29 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:09:29 --> Config Class Initialized
INFO - 2021-11-20 04:09:29 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:09:29 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:09:29 --> Utf8 Class Initialized
INFO - 2021-11-20 04:09:29 --> URI Class Initialized
INFO - 2021-11-20 04:09:29 --> Router Class Initialized
INFO - 2021-11-20 04:09:29 --> Output Class Initialized
INFO - 2021-11-20 04:09:29 --> Security Class Initialized
DEBUG - 2021-11-20 04:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:09:29 --> Input Class Initialized
INFO - 2021-11-20 04:09:29 --> Language Class Initialized
INFO - 2021-11-20 04:09:29 --> Language Class Initialized
INFO - 2021-11-20 04:09:29 --> Config Class Initialized
INFO - 2021-11-20 04:09:29 --> Loader Class Initialized
INFO - 2021-11-20 04:09:29 --> Helper loaded: url_helper
INFO - 2021-11-20 04:09:29 --> Helper loaded: file_helper
INFO - 2021-11-20 04:09:29 --> Helper loaded: form_helper
INFO - 2021-11-20 04:09:29 --> Helper loaded: my_helper
INFO - 2021-11-20 04:09:29 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:09:29 --> Controller Class Initialized
DEBUG - 2021-11-20 04:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:09:29 --> Final output sent to browser
DEBUG - 2021-11-20 04:09:29 --> Total execution time: 0.0621
INFO - 2021-11-20 04:10:19 --> Config Class Initialized
INFO - 2021-11-20 04:10:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:10:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:10:19 --> Utf8 Class Initialized
INFO - 2021-11-20 04:10:19 --> URI Class Initialized
INFO - 2021-11-20 04:10:19 --> Router Class Initialized
INFO - 2021-11-20 04:10:19 --> Output Class Initialized
INFO - 2021-11-20 04:10:19 --> Security Class Initialized
DEBUG - 2021-11-20 04:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:10:19 --> Input Class Initialized
INFO - 2021-11-20 04:10:19 --> Language Class Initialized
INFO - 2021-11-20 04:10:19 --> Language Class Initialized
INFO - 2021-11-20 04:10:19 --> Config Class Initialized
INFO - 2021-11-20 04:10:19 --> Loader Class Initialized
INFO - 2021-11-20 04:10:19 --> Helper loaded: url_helper
INFO - 2021-11-20 04:10:19 --> Helper loaded: file_helper
INFO - 2021-11-20 04:10:19 --> Helper loaded: form_helper
INFO - 2021-11-20 04:10:19 --> Helper loaded: my_helper
INFO - 2021-11-20 04:10:19 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:10:19 --> Controller Class Initialized
INFO - 2021-11-20 04:10:19 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:10:19 --> Final output sent to browser
DEBUG - 2021-11-20 04:10:19 --> Total execution time: 0.0979
INFO - 2021-11-20 04:10:19 --> Config Class Initialized
INFO - 2021-11-20 04:10:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:10:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:10:20 --> Utf8 Class Initialized
INFO - 2021-11-20 04:10:20 --> URI Class Initialized
INFO - 2021-11-20 04:10:20 --> Router Class Initialized
INFO - 2021-11-20 04:10:20 --> Output Class Initialized
INFO - 2021-11-20 04:10:20 --> Security Class Initialized
DEBUG - 2021-11-20 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:10:20 --> Input Class Initialized
INFO - 2021-11-20 04:10:20 --> Language Class Initialized
INFO - 2021-11-20 04:10:20 --> Language Class Initialized
INFO - 2021-11-20 04:10:20 --> Config Class Initialized
INFO - 2021-11-20 04:10:20 --> Loader Class Initialized
INFO - 2021-11-20 04:10:20 --> Helper loaded: url_helper
INFO - 2021-11-20 04:10:20 --> Helper loaded: file_helper
INFO - 2021-11-20 04:10:20 --> Helper loaded: form_helper
INFO - 2021-11-20 04:10:20 --> Helper loaded: my_helper
INFO - 2021-11-20 04:10:20 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:10:20 --> Controller Class Initialized
DEBUG - 2021-11-20 04:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 04:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:10:20 --> Final output sent to browser
DEBUG - 2021-11-20 04:10:20 --> Total execution time: 0.2655
INFO - 2021-11-20 04:10:46 --> Config Class Initialized
INFO - 2021-11-20 04:10:46 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:10:46 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:10:46 --> Utf8 Class Initialized
INFO - 2021-11-20 04:10:46 --> URI Class Initialized
INFO - 2021-11-20 04:10:46 --> Router Class Initialized
INFO - 2021-11-20 04:10:46 --> Output Class Initialized
INFO - 2021-11-20 04:10:46 --> Security Class Initialized
DEBUG - 2021-11-20 04:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:10:46 --> Input Class Initialized
INFO - 2021-11-20 04:10:46 --> Language Class Initialized
INFO - 2021-11-20 04:10:46 --> Language Class Initialized
INFO - 2021-11-20 04:10:46 --> Config Class Initialized
INFO - 2021-11-20 04:10:46 --> Loader Class Initialized
INFO - 2021-11-20 04:10:46 --> Helper loaded: url_helper
INFO - 2021-11-20 04:10:46 --> Helper loaded: file_helper
INFO - 2021-11-20 04:10:46 --> Helper loaded: form_helper
INFO - 2021-11-20 04:10:46 --> Helper loaded: my_helper
INFO - 2021-11-20 04:10:46 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:10:46 --> Controller Class Initialized
DEBUG - 2021-11-20 04:10:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 04:10:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:10:46 --> Final output sent to browser
DEBUG - 2021-11-20 04:10:46 --> Total execution time: 0.0910
INFO - 2021-11-20 04:10:51 --> Config Class Initialized
INFO - 2021-11-20 04:10:51 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:10:51 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:10:51 --> Utf8 Class Initialized
INFO - 2021-11-20 04:10:51 --> URI Class Initialized
INFO - 2021-11-20 04:10:51 --> Router Class Initialized
INFO - 2021-11-20 04:10:51 --> Output Class Initialized
INFO - 2021-11-20 04:10:51 --> Security Class Initialized
DEBUG - 2021-11-20 04:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:10:51 --> Input Class Initialized
INFO - 2021-11-20 04:10:51 --> Language Class Initialized
INFO - 2021-11-20 04:10:51 --> Language Class Initialized
INFO - 2021-11-20 04:10:51 --> Config Class Initialized
INFO - 2021-11-20 04:10:51 --> Loader Class Initialized
INFO - 2021-11-20 04:10:51 --> Helper loaded: url_helper
INFO - 2021-11-20 04:10:51 --> Helper loaded: file_helper
INFO - 2021-11-20 04:10:51 --> Helper loaded: form_helper
INFO - 2021-11-20 04:10:51 --> Helper loaded: my_helper
INFO - 2021-11-20 04:10:51 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:10:51 --> Controller Class Initialized
DEBUG - 2021-11-20 04:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-20 04:10:51 --> Final output sent to browser
DEBUG - 2021-11-20 04:10:51 --> Total execution time: 0.1456
INFO - 2021-11-20 04:10:55 --> Config Class Initialized
INFO - 2021-11-20 04:10:55 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:10:55 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:10:55 --> Utf8 Class Initialized
INFO - 2021-11-20 04:10:55 --> URI Class Initialized
INFO - 2021-11-20 04:10:55 --> Router Class Initialized
INFO - 2021-11-20 04:10:55 --> Output Class Initialized
INFO - 2021-11-20 04:10:55 --> Security Class Initialized
DEBUG - 2021-11-20 04:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:10:55 --> Input Class Initialized
INFO - 2021-11-20 04:10:55 --> Language Class Initialized
INFO - 2021-11-20 04:10:55 --> Language Class Initialized
INFO - 2021-11-20 04:10:55 --> Config Class Initialized
INFO - 2021-11-20 04:10:55 --> Loader Class Initialized
INFO - 2021-11-20 04:10:55 --> Helper loaded: url_helper
INFO - 2021-11-20 04:10:55 --> Helper loaded: file_helper
INFO - 2021-11-20 04:10:55 --> Helper loaded: form_helper
INFO - 2021-11-20 04:10:55 --> Helper loaded: my_helper
INFO - 2021-11-20 04:10:55 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:10:55 --> Controller Class Initialized
DEBUG - 2021-11-20 04:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:10:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:10:55 --> Final output sent to browser
DEBUG - 2021-11-20 04:10:55 --> Total execution time: 0.0902
INFO - 2021-11-20 04:10:58 --> Config Class Initialized
INFO - 2021-11-20 04:10:58 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:10:58 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:10:58 --> Utf8 Class Initialized
INFO - 2021-11-20 04:10:58 --> URI Class Initialized
INFO - 2021-11-20 04:10:58 --> Router Class Initialized
INFO - 2021-11-20 04:10:58 --> Output Class Initialized
INFO - 2021-11-20 04:10:58 --> Security Class Initialized
DEBUG - 2021-11-20 04:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:10:58 --> Input Class Initialized
INFO - 2021-11-20 04:10:58 --> Language Class Initialized
INFO - 2021-11-20 04:10:58 --> Language Class Initialized
INFO - 2021-11-20 04:10:58 --> Config Class Initialized
INFO - 2021-11-20 04:10:58 --> Loader Class Initialized
INFO - 2021-11-20 04:10:58 --> Helper loaded: url_helper
INFO - 2021-11-20 04:10:58 --> Helper loaded: file_helper
INFO - 2021-11-20 04:10:58 --> Helper loaded: form_helper
INFO - 2021-11-20 04:10:58 --> Helper loaded: my_helper
INFO - 2021-11-20 04:10:58 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:10:58 --> Controller Class Initialized
INFO - 2021-11-20 04:10:59 --> Final output sent to browser
DEBUG - 2021-11-20 04:10:59 --> Total execution time: 0.1218
INFO - 2021-11-20 04:11:00 --> Config Class Initialized
INFO - 2021-11-20 04:11:00 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:11:00 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:11:00 --> Utf8 Class Initialized
INFO - 2021-11-20 04:11:00 --> URI Class Initialized
INFO - 2021-11-20 04:11:00 --> Router Class Initialized
INFO - 2021-11-20 04:11:00 --> Output Class Initialized
INFO - 2021-11-20 04:11:00 --> Security Class Initialized
DEBUG - 2021-11-20 04:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:11:00 --> Input Class Initialized
INFO - 2021-11-20 04:11:00 --> Language Class Initialized
INFO - 2021-11-20 04:11:00 --> Language Class Initialized
INFO - 2021-11-20 04:11:00 --> Config Class Initialized
INFO - 2021-11-20 04:11:00 --> Loader Class Initialized
INFO - 2021-11-20 04:11:00 --> Helper loaded: url_helper
INFO - 2021-11-20 04:11:00 --> Helper loaded: file_helper
INFO - 2021-11-20 04:11:00 --> Helper loaded: form_helper
INFO - 2021-11-20 04:11:00 --> Helper loaded: my_helper
INFO - 2021-11-20 04:11:00 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:11:00 --> Controller Class Initialized
DEBUG - 2021-11-20 04:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 04:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:11:00 --> Final output sent to browser
DEBUG - 2021-11-20 04:11:00 --> Total execution time: 0.1114
INFO - 2021-11-20 04:11:09 --> Config Class Initialized
INFO - 2021-11-20 04:11:09 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:11:09 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:11:09 --> Utf8 Class Initialized
INFO - 2021-11-20 04:11:09 --> URI Class Initialized
INFO - 2021-11-20 04:11:09 --> Router Class Initialized
INFO - 2021-11-20 04:11:09 --> Output Class Initialized
INFO - 2021-11-20 04:11:09 --> Security Class Initialized
DEBUG - 2021-11-20 04:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:11:09 --> Input Class Initialized
INFO - 2021-11-20 04:11:09 --> Language Class Initialized
INFO - 2021-11-20 04:11:09 --> Language Class Initialized
INFO - 2021-11-20 04:11:09 --> Config Class Initialized
INFO - 2021-11-20 04:11:09 --> Loader Class Initialized
INFO - 2021-11-20 04:11:09 --> Helper loaded: url_helper
INFO - 2021-11-20 04:11:09 --> Helper loaded: file_helper
INFO - 2021-11-20 04:11:09 --> Helper loaded: form_helper
INFO - 2021-11-20 04:11:09 --> Helper loaded: my_helper
INFO - 2021-11-20 04:11:09 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:11:09 --> Controller Class Initialized
INFO - 2021-11-20 04:11:09 --> Final output sent to browser
DEBUG - 2021-11-20 04:11:09 --> Total execution time: 0.1373
INFO - 2021-11-20 04:11:11 --> Config Class Initialized
INFO - 2021-11-20 04:11:11 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:11:11 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:11:11 --> Utf8 Class Initialized
INFO - 2021-11-20 04:11:11 --> URI Class Initialized
INFO - 2021-11-20 04:11:11 --> Router Class Initialized
INFO - 2021-11-20 04:11:11 --> Output Class Initialized
INFO - 2021-11-20 04:11:11 --> Security Class Initialized
DEBUG - 2021-11-20 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:11:11 --> Input Class Initialized
INFO - 2021-11-20 04:11:11 --> Language Class Initialized
INFO - 2021-11-20 04:11:11 --> Language Class Initialized
INFO - 2021-11-20 04:11:11 --> Config Class Initialized
INFO - 2021-11-20 04:11:11 --> Loader Class Initialized
INFO - 2021-11-20 04:11:11 --> Helper loaded: url_helper
INFO - 2021-11-20 04:11:11 --> Helper loaded: file_helper
INFO - 2021-11-20 04:11:11 --> Helper loaded: form_helper
INFO - 2021-11-20 04:11:12 --> Helper loaded: my_helper
INFO - 2021-11-20 04:11:12 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:11:12 --> Controller Class Initialized
DEBUG - 2021-11-20 04:11:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-20 04:11:12 --> Final output sent to browser
DEBUG - 2021-11-20 04:11:12 --> Total execution time: 0.0705
INFO - 2021-11-20 04:11:36 --> Config Class Initialized
INFO - 2021-11-20 04:11:36 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:11:36 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:11:36 --> Utf8 Class Initialized
INFO - 2021-11-20 04:11:36 --> URI Class Initialized
INFO - 2021-11-20 04:11:36 --> Router Class Initialized
INFO - 2021-11-20 04:11:36 --> Output Class Initialized
INFO - 2021-11-20 04:11:36 --> Security Class Initialized
DEBUG - 2021-11-20 04:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:11:36 --> Input Class Initialized
INFO - 2021-11-20 04:11:36 --> Language Class Initialized
INFO - 2021-11-20 04:11:36 --> Language Class Initialized
INFO - 2021-11-20 04:11:36 --> Config Class Initialized
INFO - 2021-11-20 04:11:36 --> Loader Class Initialized
INFO - 2021-11-20 04:11:36 --> Helper loaded: url_helper
INFO - 2021-11-20 04:11:36 --> Helper loaded: file_helper
INFO - 2021-11-20 04:11:36 --> Helper loaded: form_helper
INFO - 2021-11-20 04:11:36 --> Helper loaded: my_helper
INFO - 2021-11-20 04:11:36 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:11:36 --> Controller Class Initialized
DEBUG - 2021-11-20 04:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-20 04:11:36 --> Final output sent to browser
DEBUG - 2021-11-20 04:11:36 --> Total execution time: 0.0961
INFO - 2021-11-20 04:11:47 --> Config Class Initialized
INFO - 2021-11-20 04:11:47 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:11:47 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:11:47 --> Utf8 Class Initialized
INFO - 2021-11-20 04:11:47 --> URI Class Initialized
INFO - 2021-11-20 04:11:47 --> Router Class Initialized
INFO - 2021-11-20 04:11:47 --> Output Class Initialized
INFO - 2021-11-20 04:11:47 --> Security Class Initialized
DEBUG - 2021-11-20 04:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:11:47 --> Input Class Initialized
INFO - 2021-11-20 04:11:47 --> Language Class Initialized
INFO - 2021-11-20 04:11:47 --> Language Class Initialized
INFO - 2021-11-20 04:11:47 --> Config Class Initialized
INFO - 2021-11-20 04:11:47 --> Loader Class Initialized
INFO - 2021-11-20 04:11:47 --> Helper loaded: url_helper
INFO - 2021-11-20 04:11:47 --> Helper loaded: file_helper
INFO - 2021-11-20 04:11:47 --> Helper loaded: form_helper
INFO - 2021-11-20 04:11:47 --> Helper loaded: my_helper
INFO - 2021-11-20 04:11:47 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:11:47 --> Controller Class Initialized
DEBUG - 2021-11-20 04:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-20 04:11:47 --> Final output sent to browser
DEBUG - 2021-11-20 04:11:47 --> Total execution time: 0.0751
INFO - 2021-11-20 04:11:56 --> Config Class Initialized
INFO - 2021-11-20 04:11:56 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:11:56 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:11:56 --> Utf8 Class Initialized
INFO - 2021-11-20 04:11:56 --> URI Class Initialized
INFO - 2021-11-20 04:11:56 --> Router Class Initialized
INFO - 2021-11-20 04:11:56 --> Output Class Initialized
INFO - 2021-11-20 04:11:56 --> Security Class Initialized
DEBUG - 2021-11-20 04:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:11:56 --> Input Class Initialized
INFO - 2021-11-20 04:11:56 --> Language Class Initialized
INFO - 2021-11-20 04:11:56 --> Language Class Initialized
INFO - 2021-11-20 04:11:56 --> Config Class Initialized
INFO - 2021-11-20 04:11:56 --> Loader Class Initialized
INFO - 2021-11-20 04:11:56 --> Helper loaded: url_helper
INFO - 2021-11-20 04:11:56 --> Helper loaded: file_helper
INFO - 2021-11-20 04:11:56 --> Helper loaded: form_helper
INFO - 2021-11-20 04:11:56 --> Helper loaded: my_helper
INFO - 2021-11-20 04:11:56 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:11:56 --> Controller Class Initialized
DEBUG - 2021-11-20 04:11:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-20 04:11:56 --> Final output sent to browser
DEBUG - 2021-11-20 04:11:56 --> Total execution time: 0.0708
INFO - 2021-11-20 04:12:04 --> Config Class Initialized
INFO - 2021-11-20 04:12:04 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:12:04 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:12:04 --> Utf8 Class Initialized
INFO - 2021-11-20 04:12:04 --> URI Class Initialized
INFO - 2021-11-20 04:12:04 --> Router Class Initialized
INFO - 2021-11-20 04:12:04 --> Output Class Initialized
INFO - 2021-11-20 04:12:04 --> Security Class Initialized
DEBUG - 2021-11-20 04:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:12:04 --> Input Class Initialized
INFO - 2021-11-20 04:12:04 --> Language Class Initialized
INFO - 2021-11-20 04:12:04 --> Language Class Initialized
INFO - 2021-11-20 04:12:04 --> Config Class Initialized
INFO - 2021-11-20 04:12:04 --> Loader Class Initialized
INFO - 2021-11-20 04:12:04 --> Helper loaded: url_helper
INFO - 2021-11-20 04:12:04 --> Helper loaded: file_helper
INFO - 2021-11-20 04:12:04 --> Helper loaded: form_helper
INFO - 2021-11-20 04:12:04 --> Helper loaded: my_helper
INFO - 2021-11-20 04:12:04 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:12:04 --> Controller Class Initialized
DEBUG - 2021-11-20 04:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-20 04:12:04 --> Final output sent to browser
DEBUG - 2021-11-20 04:12:04 --> Total execution time: 0.0941
INFO - 2021-11-20 04:12:22 --> Config Class Initialized
INFO - 2021-11-20 04:12:22 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:12:22 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:12:22 --> Utf8 Class Initialized
INFO - 2021-11-20 04:12:22 --> URI Class Initialized
INFO - 2021-11-20 04:12:22 --> Router Class Initialized
INFO - 2021-11-20 04:12:22 --> Output Class Initialized
INFO - 2021-11-20 04:12:22 --> Security Class Initialized
DEBUG - 2021-11-20 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:12:22 --> Input Class Initialized
INFO - 2021-11-20 04:12:22 --> Language Class Initialized
INFO - 2021-11-20 04:12:22 --> Language Class Initialized
INFO - 2021-11-20 04:12:22 --> Config Class Initialized
INFO - 2021-11-20 04:12:22 --> Loader Class Initialized
INFO - 2021-11-20 04:12:22 --> Helper loaded: url_helper
INFO - 2021-11-20 04:12:22 --> Helper loaded: file_helper
INFO - 2021-11-20 04:12:22 --> Helper loaded: form_helper
INFO - 2021-11-20 04:12:22 --> Helper loaded: my_helper
INFO - 2021-11-20 04:12:22 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:12:22 --> Controller Class Initialized
INFO - 2021-11-20 04:12:22 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:12:22 --> Config Class Initialized
INFO - 2021-11-20 04:12:22 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:12:22 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:12:22 --> Utf8 Class Initialized
INFO - 2021-11-20 04:12:22 --> URI Class Initialized
INFO - 2021-11-20 04:12:22 --> Router Class Initialized
INFO - 2021-11-20 04:12:22 --> Output Class Initialized
INFO - 2021-11-20 04:12:22 --> Security Class Initialized
DEBUG - 2021-11-20 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:12:22 --> Input Class Initialized
INFO - 2021-11-20 04:12:22 --> Language Class Initialized
INFO - 2021-11-20 04:12:22 --> Language Class Initialized
INFO - 2021-11-20 04:12:22 --> Config Class Initialized
INFO - 2021-11-20 04:12:22 --> Loader Class Initialized
INFO - 2021-11-20 04:12:22 --> Helper loaded: url_helper
INFO - 2021-11-20 04:12:22 --> Helper loaded: file_helper
INFO - 2021-11-20 04:12:22 --> Helper loaded: form_helper
INFO - 2021-11-20 04:12:22 --> Helper loaded: my_helper
INFO - 2021-11-20 04:12:22 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:12:22 --> Controller Class Initialized
DEBUG - 2021-11-20 04:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:12:22 --> Final output sent to browser
DEBUG - 2021-11-20 04:12:22 --> Total execution time: 0.0645
INFO - 2021-11-20 04:46:37 --> Config Class Initialized
INFO - 2021-11-20 04:46:37 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:46:37 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:46:37 --> Utf8 Class Initialized
INFO - 2021-11-20 04:46:37 --> URI Class Initialized
INFO - 2021-11-20 04:46:37 --> Router Class Initialized
INFO - 2021-11-20 04:46:37 --> Output Class Initialized
INFO - 2021-11-20 04:46:37 --> Security Class Initialized
DEBUG - 2021-11-20 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:46:37 --> Input Class Initialized
INFO - 2021-11-20 04:46:37 --> Language Class Initialized
INFO - 2021-11-20 04:46:37 --> Language Class Initialized
INFO - 2021-11-20 04:46:37 --> Config Class Initialized
INFO - 2021-11-20 04:46:37 --> Loader Class Initialized
INFO - 2021-11-20 04:46:37 --> Helper loaded: url_helper
INFO - 2021-11-20 04:46:37 --> Helper loaded: file_helper
INFO - 2021-11-20 04:46:37 --> Helper loaded: form_helper
INFO - 2021-11-20 04:46:37 --> Helper loaded: my_helper
INFO - 2021-11-20 04:46:37 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:46:37 --> Controller Class Initialized
INFO - 2021-11-20 04:46:37 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:46:37 --> Final output sent to browser
DEBUG - 2021-11-20 04:46:37 --> Total execution time: 0.0959
INFO - 2021-11-20 04:46:37 --> Config Class Initialized
INFO - 2021-11-20 04:46:37 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:46:37 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:46:37 --> Utf8 Class Initialized
INFO - 2021-11-20 04:46:37 --> URI Class Initialized
INFO - 2021-11-20 04:46:37 --> Router Class Initialized
INFO - 2021-11-20 04:46:37 --> Output Class Initialized
INFO - 2021-11-20 04:46:37 --> Security Class Initialized
DEBUG - 2021-11-20 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:46:37 --> Input Class Initialized
INFO - 2021-11-20 04:46:37 --> Language Class Initialized
INFO - 2021-11-20 04:46:37 --> Language Class Initialized
INFO - 2021-11-20 04:46:37 --> Config Class Initialized
INFO - 2021-11-20 04:46:37 --> Loader Class Initialized
INFO - 2021-11-20 04:46:37 --> Helper loaded: url_helper
INFO - 2021-11-20 04:46:37 --> Helper loaded: file_helper
INFO - 2021-11-20 04:46:37 --> Helper loaded: form_helper
INFO - 2021-11-20 04:46:37 --> Helper loaded: my_helper
INFO - 2021-11-20 04:46:37 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:46:37 --> Controller Class Initialized
DEBUG - 2021-11-20 04:46:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 04:46:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:46:38 --> Final output sent to browser
DEBUG - 2021-11-20 04:46:38 --> Total execution time: 0.2577
INFO - 2021-11-20 04:46:39 --> Config Class Initialized
INFO - 2021-11-20 04:46:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:46:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:46:39 --> Utf8 Class Initialized
INFO - 2021-11-20 04:46:39 --> URI Class Initialized
INFO - 2021-11-20 04:46:39 --> Router Class Initialized
INFO - 2021-11-20 04:46:39 --> Output Class Initialized
INFO - 2021-11-20 04:46:39 --> Security Class Initialized
DEBUG - 2021-11-20 04:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:46:39 --> Input Class Initialized
INFO - 2021-11-20 04:46:39 --> Language Class Initialized
INFO - 2021-11-20 04:46:39 --> Language Class Initialized
INFO - 2021-11-20 04:46:39 --> Config Class Initialized
INFO - 2021-11-20 04:46:39 --> Loader Class Initialized
INFO - 2021-11-20 04:46:39 --> Helper loaded: url_helper
INFO - 2021-11-20 04:46:39 --> Helper loaded: file_helper
INFO - 2021-11-20 04:46:39 --> Helper loaded: form_helper
INFO - 2021-11-20 04:46:39 --> Helper loaded: my_helper
INFO - 2021-11-20 04:46:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:46:39 --> Controller Class Initialized
DEBUG - 2021-11-20 04:46:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 04:46:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:46:39 --> Final output sent to browser
DEBUG - 2021-11-20 04:46:39 --> Total execution time: 0.0790
INFO - 2021-11-20 04:46:43 --> Config Class Initialized
INFO - 2021-11-20 04:46:43 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:46:43 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:46:43 --> Utf8 Class Initialized
INFO - 2021-11-20 04:46:43 --> URI Class Initialized
INFO - 2021-11-20 04:46:43 --> Router Class Initialized
INFO - 2021-11-20 04:46:43 --> Output Class Initialized
INFO - 2021-11-20 04:46:43 --> Security Class Initialized
DEBUG - 2021-11-20 04:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:46:43 --> Input Class Initialized
INFO - 2021-11-20 04:46:43 --> Language Class Initialized
INFO - 2021-11-20 04:46:43 --> Language Class Initialized
INFO - 2021-11-20 04:46:43 --> Config Class Initialized
INFO - 2021-11-20 04:46:43 --> Loader Class Initialized
INFO - 2021-11-20 04:46:43 --> Helper loaded: url_helper
INFO - 2021-11-20 04:46:43 --> Helper loaded: file_helper
INFO - 2021-11-20 04:46:43 --> Helper loaded: form_helper
INFO - 2021-11-20 04:46:43 --> Helper loaded: my_helper
INFO - 2021-11-20 04:46:43 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:46:43 --> Controller Class Initialized
DEBUG - 2021-11-20 04:46:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-20 04:46:43 --> Final output sent to browser
DEBUG - 2021-11-20 04:46:43 --> Total execution time: 0.1443
INFO - 2021-11-20 04:47:10 --> Config Class Initialized
INFO - 2021-11-20 04:47:10 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:47:10 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:47:10 --> Utf8 Class Initialized
INFO - 2021-11-20 04:47:10 --> URI Class Initialized
INFO - 2021-11-20 04:47:10 --> Router Class Initialized
INFO - 2021-11-20 04:47:10 --> Output Class Initialized
INFO - 2021-11-20 04:47:10 --> Security Class Initialized
DEBUG - 2021-11-20 04:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:47:10 --> Input Class Initialized
INFO - 2021-11-20 04:47:10 --> Language Class Initialized
INFO - 2021-11-20 04:47:10 --> Language Class Initialized
INFO - 2021-11-20 04:47:10 --> Config Class Initialized
INFO - 2021-11-20 04:47:10 --> Loader Class Initialized
INFO - 2021-11-20 04:47:10 --> Helper loaded: url_helper
INFO - 2021-11-20 04:47:10 --> Helper loaded: file_helper
INFO - 2021-11-20 04:47:10 --> Helper loaded: form_helper
INFO - 2021-11-20 04:47:10 --> Helper loaded: my_helper
INFO - 2021-11-20 04:47:10 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:47:10 --> Controller Class Initialized
DEBUG - 2021-11-20 04:47:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-20 04:47:10 --> Final output sent to browser
DEBUG - 2021-11-20 04:47:10 --> Total execution time: 0.0823
INFO - 2021-11-20 04:47:21 --> Config Class Initialized
INFO - 2021-11-20 04:47:21 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:47:21 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:47:21 --> Utf8 Class Initialized
INFO - 2021-11-20 04:47:21 --> URI Class Initialized
INFO - 2021-11-20 04:47:21 --> Router Class Initialized
INFO - 2021-11-20 04:47:21 --> Output Class Initialized
INFO - 2021-11-20 04:47:21 --> Security Class Initialized
DEBUG - 2021-11-20 04:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:47:21 --> Input Class Initialized
INFO - 2021-11-20 04:47:21 --> Language Class Initialized
INFO - 2021-11-20 04:47:21 --> Language Class Initialized
INFO - 2021-11-20 04:47:21 --> Config Class Initialized
INFO - 2021-11-20 04:47:21 --> Loader Class Initialized
INFO - 2021-11-20 04:47:21 --> Helper loaded: url_helper
INFO - 2021-11-20 04:47:21 --> Helper loaded: file_helper
INFO - 2021-11-20 04:47:21 --> Helper loaded: form_helper
INFO - 2021-11-20 04:47:21 --> Helper loaded: my_helper
INFO - 2021-11-20 04:47:21 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:47:21 --> Controller Class Initialized
DEBUG - 2021-11-20 04:47:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-20 04:47:21 --> Final output sent to browser
DEBUG - 2021-11-20 04:47:21 --> Total execution time: 0.0831
INFO - 2021-11-20 04:47:31 --> Config Class Initialized
INFO - 2021-11-20 04:47:31 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:47:31 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:47:31 --> Utf8 Class Initialized
INFO - 2021-11-20 04:47:31 --> URI Class Initialized
INFO - 2021-11-20 04:47:31 --> Router Class Initialized
INFO - 2021-11-20 04:47:31 --> Output Class Initialized
INFO - 2021-11-20 04:47:31 --> Security Class Initialized
DEBUG - 2021-11-20 04:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:47:31 --> Input Class Initialized
INFO - 2021-11-20 04:47:31 --> Language Class Initialized
INFO - 2021-11-20 04:47:31 --> Language Class Initialized
INFO - 2021-11-20 04:47:31 --> Config Class Initialized
INFO - 2021-11-20 04:47:31 --> Loader Class Initialized
INFO - 2021-11-20 04:47:31 --> Helper loaded: url_helper
INFO - 2021-11-20 04:47:31 --> Helper loaded: file_helper
INFO - 2021-11-20 04:47:31 --> Helper loaded: form_helper
INFO - 2021-11-20 04:47:31 --> Helper loaded: my_helper
INFO - 2021-11-20 04:47:31 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:47:31 --> Controller Class Initialized
DEBUG - 2021-11-20 04:47:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-20 04:47:31 --> Final output sent to browser
DEBUG - 2021-11-20 04:47:31 --> Total execution time: 0.0767
INFO - 2021-11-20 04:47:39 --> Config Class Initialized
INFO - 2021-11-20 04:47:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:47:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:47:39 --> Utf8 Class Initialized
INFO - 2021-11-20 04:47:39 --> URI Class Initialized
INFO - 2021-11-20 04:47:39 --> Router Class Initialized
INFO - 2021-11-20 04:47:39 --> Output Class Initialized
INFO - 2021-11-20 04:47:39 --> Security Class Initialized
DEBUG - 2021-11-20 04:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:47:39 --> Input Class Initialized
INFO - 2021-11-20 04:47:39 --> Language Class Initialized
INFO - 2021-11-20 04:47:39 --> Language Class Initialized
INFO - 2021-11-20 04:47:39 --> Config Class Initialized
INFO - 2021-11-20 04:47:39 --> Loader Class Initialized
INFO - 2021-11-20 04:47:39 --> Helper loaded: url_helper
INFO - 2021-11-20 04:47:39 --> Helper loaded: file_helper
INFO - 2021-11-20 04:47:39 --> Helper loaded: form_helper
INFO - 2021-11-20 04:47:39 --> Helper loaded: my_helper
INFO - 2021-11-20 04:47:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:47:39 --> Controller Class Initialized
DEBUG - 2021-11-20 04:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-11-20 04:47:39 --> Final output sent to browser
DEBUG - 2021-11-20 04:47:39 --> Total execution time: 0.0724
INFO - 2021-11-20 04:47:52 --> Config Class Initialized
INFO - 2021-11-20 04:47:52 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:47:52 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:47:52 --> Utf8 Class Initialized
INFO - 2021-11-20 04:47:52 --> URI Class Initialized
INFO - 2021-11-20 04:47:52 --> Router Class Initialized
INFO - 2021-11-20 04:47:52 --> Output Class Initialized
INFO - 2021-11-20 04:47:52 --> Security Class Initialized
DEBUG - 2021-11-20 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:47:52 --> Input Class Initialized
INFO - 2021-11-20 04:47:52 --> Language Class Initialized
INFO - 2021-11-20 04:47:52 --> Language Class Initialized
INFO - 2021-11-20 04:47:52 --> Config Class Initialized
INFO - 2021-11-20 04:47:52 --> Loader Class Initialized
INFO - 2021-11-20 04:47:52 --> Helper loaded: url_helper
INFO - 2021-11-20 04:47:52 --> Helper loaded: file_helper
INFO - 2021-11-20 04:47:52 --> Helper loaded: form_helper
INFO - 2021-11-20 04:47:52 --> Helper loaded: my_helper
INFO - 2021-11-20 04:47:52 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:47:52 --> Controller Class Initialized
INFO - 2021-11-20 04:47:52 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:47:52 --> Config Class Initialized
INFO - 2021-11-20 04:47:52 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:47:52 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:47:52 --> Utf8 Class Initialized
INFO - 2021-11-20 04:47:52 --> URI Class Initialized
INFO - 2021-11-20 04:47:52 --> Router Class Initialized
INFO - 2021-11-20 04:47:52 --> Output Class Initialized
INFO - 2021-11-20 04:47:52 --> Security Class Initialized
DEBUG - 2021-11-20 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:47:52 --> Input Class Initialized
INFO - 2021-11-20 04:47:52 --> Language Class Initialized
INFO - 2021-11-20 04:47:52 --> Language Class Initialized
INFO - 2021-11-20 04:47:52 --> Config Class Initialized
INFO - 2021-11-20 04:47:52 --> Loader Class Initialized
INFO - 2021-11-20 04:47:52 --> Helper loaded: url_helper
INFO - 2021-11-20 04:47:52 --> Helper loaded: file_helper
INFO - 2021-11-20 04:47:52 --> Helper loaded: form_helper
INFO - 2021-11-20 04:47:52 --> Helper loaded: my_helper
INFO - 2021-11-20 04:47:52 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:47:52 --> Controller Class Initialized
DEBUG - 2021-11-20 04:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:47:52 --> Final output sent to browser
DEBUG - 2021-11-20 04:47:52 --> Total execution time: 0.0684
INFO - 2021-11-20 04:48:17 --> Config Class Initialized
INFO - 2021-11-20 04:48:17 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:17 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:17 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:17 --> URI Class Initialized
INFO - 2021-11-20 04:48:17 --> Router Class Initialized
INFO - 2021-11-20 04:48:17 --> Output Class Initialized
INFO - 2021-11-20 04:48:17 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:17 --> Input Class Initialized
INFO - 2021-11-20 04:48:17 --> Language Class Initialized
INFO - 2021-11-20 04:48:17 --> Language Class Initialized
INFO - 2021-11-20 04:48:17 --> Config Class Initialized
INFO - 2021-11-20 04:48:17 --> Loader Class Initialized
INFO - 2021-11-20 04:48:17 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:17 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:17 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:17 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:17 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:17 --> Controller Class Initialized
INFO - 2021-11-20 04:48:17 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:48:17 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:17 --> Total execution time: 0.0767
INFO - 2021-11-20 04:48:17 --> Config Class Initialized
INFO - 2021-11-20 04:48:17 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:17 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:17 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:17 --> URI Class Initialized
INFO - 2021-11-20 04:48:17 --> Router Class Initialized
INFO - 2021-11-20 04:48:17 --> Output Class Initialized
INFO - 2021-11-20 04:48:17 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:17 --> Input Class Initialized
INFO - 2021-11-20 04:48:17 --> Language Class Initialized
INFO - 2021-11-20 04:48:17 --> Language Class Initialized
INFO - 2021-11-20 04:48:17 --> Config Class Initialized
INFO - 2021-11-20 04:48:17 --> Loader Class Initialized
INFO - 2021-11-20 04:48:17 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:17 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:17 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:17 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:17 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:17 --> Controller Class Initialized
DEBUG - 2021-11-20 04:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-20 04:48:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:48:17 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:17 --> Total execution time: 0.2267
INFO - 2021-11-20 04:48:19 --> Config Class Initialized
INFO - 2021-11-20 04:48:19 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:19 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:19 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:19 --> URI Class Initialized
INFO - 2021-11-20 04:48:19 --> Router Class Initialized
INFO - 2021-11-20 04:48:19 --> Output Class Initialized
INFO - 2021-11-20 04:48:19 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:19 --> Input Class Initialized
INFO - 2021-11-20 04:48:19 --> Language Class Initialized
INFO - 2021-11-20 04:48:19 --> Language Class Initialized
INFO - 2021-11-20 04:48:19 --> Config Class Initialized
INFO - 2021-11-20 04:48:19 --> Loader Class Initialized
INFO - 2021-11-20 04:48:19 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:19 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:19 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:19 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:19 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:19 --> Controller Class Initialized
DEBUG - 2021-11-20 04:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-20 04:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:48:19 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:19 --> Total execution time: 0.0924
INFO - 2021-11-20 04:48:21 --> Config Class Initialized
INFO - 2021-11-20 04:48:21 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:21 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:21 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:21 --> URI Class Initialized
INFO - 2021-11-20 04:48:21 --> Router Class Initialized
INFO - 2021-11-20 04:48:21 --> Output Class Initialized
INFO - 2021-11-20 04:48:21 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:21 --> Input Class Initialized
INFO - 2021-11-20 04:48:21 --> Language Class Initialized
INFO - 2021-11-20 04:48:21 --> Language Class Initialized
INFO - 2021-11-20 04:48:21 --> Config Class Initialized
INFO - 2021-11-20 04:48:21 --> Loader Class Initialized
INFO - 2021-11-20 04:48:21 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:21 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:21 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:21 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:21 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:21 --> Controller Class Initialized
DEBUG - 2021-11-20 04:48:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-20 04:48:21 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:21 --> Total execution time: 0.1427
INFO - 2021-11-20 04:48:24 --> Config Class Initialized
INFO - 2021-11-20 04:48:24 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:24 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:24 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:24 --> URI Class Initialized
INFO - 2021-11-20 04:48:24 --> Router Class Initialized
INFO - 2021-11-20 04:48:24 --> Output Class Initialized
INFO - 2021-11-20 04:48:24 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:24 --> Input Class Initialized
INFO - 2021-11-20 04:48:24 --> Language Class Initialized
INFO - 2021-11-20 04:48:24 --> Language Class Initialized
INFO - 2021-11-20 04:48:24 --> Config Class Initialized
INFO - 2021-11-20 04:48:24 --> Loader Class Initialized
INFO - 2021-11-20 04:48:24 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:24 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:24 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:24 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:24 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:24 --> Controller Class Initialized
DEBUG - 2021-11-20 04:48:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-11-20 04:48:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:48:24 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:24 --> Total execution time: 0.0867
INFO - 2021-11-20 04:48:27 --> Config Class Initialized
INFO - 2021-11-20 04:48:27 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:27 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:27 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:27 --> URI Class Initialized
INFO - 2021-11-20 04:48:27 --> Router Class Initialized
INFO - 2021-11-20 04:48:27 --> Output Class Initialized
INFO - 2021-11-20 04:48:27 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:27 --> Input Class Initialized
INFO - 2021-11-20 04:48:27 --> Language Class Initialized
INFO - 2021-11-20 04:48:27 --> Language Class Initialized
INFO - 2021-11-20 04:48:27 --> Config Class Initialized
INFO - 2021-11-20 04:48:27 --> Loader Class Initialized
INFO - 2021-11-20 04:48:27 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:27 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:27 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:27 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:27 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:27 --> Controller Class Initialized
INFO - 2021-11-20 04:48:27 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:27 --> Total execution time: 0.1172
INFO - 2021-11-20 04:48:29 --> Config Class Initialized
INFO - 2021-11-20 04:48:29 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:29 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:29 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:29 --> URI Class Initialized
INFO - 2021-11-20 04:48:29 --> Router Class Initialized
INFO - 2021-11-20 04:48:29 --> Output Class Initialized
INFO - 2021-11-20 04:48:29 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:29 --> Input Class Initialized
INFO - 2021-11-20 04:48:29 --> Language Class Initialized
INFO - 2021-11-20 04:48:29 --> Language Class Initialized
INFO - 2021-11-20 04:48:29 --> Config Class Initialized
INFO - 2021-11-20 04:48:29 --> Loader Class Initialized
INFO - 2021-11-20 04:48:29 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:29 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:29 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:29 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:29 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:29 --> Controller Class Initialized
DEBUG - 2021-11-20 04:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-11-20 04:48:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:48:29 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:29 --> Total execution time: 0.1032
INFO - 2021-11-20 04:48:39 --> Config Class Initialized
INFO - 2021-11-20 04:48:39 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:39 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:39 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:39 --> URI Class Initialized
INFO - 2021-11-20 04:48:39 --> Router Class Initialized
INFO - 2021-11-20 04:48:39 --> Output Class Initialized
INFO - 2021-11-20 04:48:39 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:39 --> Input Class Initialized
INFO - 2021-11-20 04:48:39 --> Language Class Initialized
INFO - 2021-11-20 04:48:39 --> Language Class Initialized
INFO - 2021-11-20 04:48:39 --> Config Class Initialized
INFO - 2021-11-20 04:48:39 --> Loader Class Initialized
INFO - 2021-11-20 04:48:39 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:39 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:39 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:39 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:39 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:39 --> Controller Class Initialized
INFO - 2021-11-20 04:48:39 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:39 --> Total execution time: 0.1144
INFO - 2021-11-20 04:48:41 --> Config Class Initialized
INFO - 2021-11-20 04:48:41 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:48:41 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:48:41 --> Utf8 Class Initialized
INFO - 2021-11-20 04:48:41 --> URI Class Initialized
INFO - 2021-11-20 04:48:41 --> Router Class Initialized
INFO - 2021-11-20 04:48:41 --> Output Class Initialized
INFO - 2021-11-20 04:48:41 --> Security Class Initialized
DEBUG - 2021-11-20 04:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:48:41 --> Input Class Initialized
INFO - 2021-11-20 04:48:41 --> Language Class Initialized
INFO - 2021-11-20 04:48:41 --> Language Class Initialized
INFO - 2021-11-20 04:48:41 --> Config Class Initialized
INFO - 2021-11-20 04:48:41 --> Loader Class Initialized
INFO - 2021-11-20 04:48:41 --> Helper loaded: url_helper
INFO - 2021-11-20 04:48:41 --> Helper loaded: file_helper
INFO - 2021-11-20 04:48:41 --> Helper loaded: form_helper
INFO - 2021-11-20 04:48:41 --> Helper loaded: my_helper
INFO - 2021-11-20 04:48:41 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:48:41 --> Controller Class Initialized
DEBUG - 2021-11-20 04:48:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-20 04:48:41 --> Final output sent to browser
DEBUG - 2021-11-20 04:48:41 --> Total execution time: 0.0874
INFO - 2021-11-20 04:49:06 --> Config Class Initialized
INFO - 2021-11-20 04:49:06 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:49:06 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:49:06 --> Utf8 Class Initialized
INFO - 2021-11-20 04:49:06 --> URI Class Initialized
INFO - 2021-11-20 04:49:06 --> Router Class Initialized
INFO - 2021-11-20 04:49:06 --> Output Class Initialized
INFO - 2021-11-20 04:49:06 --> Security Class Initialized
DEBUG - 2021-11-20 04:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:49:06 --> Input Class Initialized
INFO - 2021-11-20 04:49:06 --> Language Class Initialized
INFO - 2021-11-20 04:49:06 --> Language Class Initialized
INFO - 2021-11-20 04:49:06 --> Config Class Initialized
INFO - 2021-11-20 04:49:06 --> Loader Class Initialized
INFO - 2021-11-20 04:49:06 --> Helper loaded: url_helper
INFO - 2021-11-20 04:49:06 --> Helper loaded: file_helper
INFO - 2021-11-20 04:49:06 --> Helper loaded: form_helper
INFO - 2021-11-20 04:49:06 --> Helper loaded: my_helper
INFO - 2021-11-20 04:49:06 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:49:06 --> Controller Class Initialized
DEBUG - 2021-11-20 04:49:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-20 04:49:06 --> Final output sent to browser
DEBUG - 2021-11-20 04:49:06 --> Total execution time: 0.0956
INFO - 2021-11-20 04:49:16 --> Config Class Initialized
INFO - 2021-11-20 04:49:16 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:49:16 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:49:16 --> Utf8 Class Initialized
INFO - 2021-11-20 04:49:16 --> URI Class Initialized
INFO - 2021-11-20 04:49:16 --> Router Class Initialized
INFO - 2021-11-20 04:49:16 --> Output Class Initialized
INFO - 2021-11-20 04:49:16 --> Security Class Initialized
DEBUG - 2021-11-20 04:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:49:16 --> Input Class Initialized
INFO - 2021-11-20 04:49:16 --> Language Class Initialized
INFO - 2021-11-20 04:49:16 --> Language Class Initialized
INFO - 2021-11-20 04:49:16 --> Config Class Initialized
INFO - 2021-11-20 04:49:16 --> Loader Class Initialized
INFO - 2021-11-20 04:49:16 --> Helper loaded: url_helper
INFO - 2021-11-20 04:49:16 --> Helper loaded: file_helper
INFO - 2021-11-20 04:49:16 --> Helper loaded: form_helper
INFO - 2021-11-20 04:49:16 --> Helper loaded: my_helper
INFO - 2021-11-20 04:49:16 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:49:16 --> Controller Class Initialized
DEBUG - 2021-11-20 04:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-20 04:49:16 --> Final output sent to browser
DEBUG - 2021-11-20 04:49:16 --> Total execution time: 0.0749
INFO - 2021-11-20 04:49:25 --> Config Class Initialized
INFO - 2021-11-20 04:49:25 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:49:25 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:49:25 --> Utf8 Class Initialized
INFO - 2021-11-20 04:49:25 --> URI Class Initialized
INFO - 2021-11-20 04:49:25 --> Router Class Initialized
INFO - 2021-11-20 04:49:25 --> Output Class Initialized
INFO - 2021-11-20 04:49:25 --> Security Class Initialized
DEBUG - 2021-11-20 04:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:49:25 --> Input Class Initialized
INFO - 2021-11-20 04:49:25 --> Language Class Initialized
INFO - 2021-11-20 04:49:25 --> Language Class Initialized
INFO - 2021-11-20 04:49:25 --> Config Class Initialized
INFO - 2021-11-20 04:49:25 --> Loader Class Initialized
INFO - 2021-11-20 04:49:25 --> Helper loaded: url_helper
INFO - 2021-11-20 04:49:25 --> Helper loaded: file_helper
INFO - 2021-11-20 04:49:25 --> Helper loaded: form_helper
INFO - 2021-11-20 04:49:25 --> Helper loaded: my_helper
INFO - 2021-11-20 04:49:25 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:49:25 --> Controller Class Initialized
DEBUG - 2021-11-20 04:49:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-20 04:49:25 --> Final output sent to browser
DEBUG - 2021-11-20 04:49:25 --> Total execution time: 0.0807
INFO - 2021-11-20 04:49:32 --> Config Class Initialized
INFO - 2021-11-20 04:49:32 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:49:32 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:49:32 --> Utf8 Class Initialized
INFO - 2021-11-20 04:49:32 --> URI Class Initialized
INFO - 2021-11-20 04:49:32 --> Router Class Initialized
INFO - 2021-11-20 04:49:32 --> Output Class Initialized
INFO - 2021-11-20 04:49:32 --> Security Class Initialized
DEBUG - 2021-11-20 04:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:49:32 --> Input Class Initialized
INFO - 2021-11-20 04:49:32 --> Language Class Initialized
INFO - 2021-11-20 04:49:32 --> Language Class Initialized
INFO - 2021-11-20 04:49:32 --> Config Class Initialized
INFO - 2021-11-20 04:49:32 --> Loader Class Initialized
INFO - 2021-11-20 04:49:32 --> Helper loaded: url_helper
INFO - 2021-11-20 04:49:32 --> Helper loaded: file_helper
INFO - 2021-11-20 04:49:32 --> Helper loaded: form_helper
INFO - 2021-11-20 04:49:32 --> Helper loaded: my_helper
INFO - 2021-11-20 04:49:32 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:49:32 --> Controller Class Initialized
INFO - 2021-11-20 04:49:32 --> Helper loaded: cookie_helper
INFO - 2021-11-20 04:49:32 --> Config Class Initialized
INFO - 2021-11-20 04:49:32 --> Hooks Class Initialized
DEBUG - 2021-11-20 04:49:32 --> UTF-8 Support Enabled
INFO - 2021-11-20 04:49:32 --> Utf8 Class Initialized
INFO - 2021-11-20 04:49:32 --> URI Class Initialized
INFO - 2021-11-20 04:49:32 --> Router Class Initialized
INFO - 2021-11-20 04:49:32 --> Output Class Initialized
INFO - 2021-11-20 04:49:32 --> Security Class Initialized
DEBUG - 2021-11-20 04:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-20 04:49:32 --> Input Class Initialized
INFO - 2021-11-20 04:49:32 --> Language Class Initialized
INFO - 2021-11-20 04:49:32 --> Language Class Initialized
INFO - 2021-11-20 04:49:32 --> Config Class Initialized
INFO - 2021-11-20 04:49:32 --> Loader Class Initialized
INFO - 2021-11-20 04:49:32 --> Helper loaded: url_helper
INFO - 2021-11-20 04:49:32 --> Helper loaded: file_helper
INFO - 2021-11-20 04:49:32 --> Helper loaded: form_helper
INFO - 2021-11-20 04:49:32 --> Helper loaded: my_helper
INFO - 2021-11-20 04:49:32 --> Database Driver Class Initialized
DEBUG - 2021-11-20 04:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-20 04:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-20 04:49:32 --> Controller Class Initialized
DEBUG - 2021-11-20 04:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-20 04:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-20 04:49:32 --> Final output sent to browser
DEBUG - 2021-11-20 04:49:32 --> Total execution time: 0.0736
