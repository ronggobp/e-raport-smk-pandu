<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-12 14:48:43 --> Config Class Initialized
INFO - 2021-04-12 14:48:43 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:48:43 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:48:43 --> Utf8 Class Initialized
INFO - 2021-04-12 14:48:43 --> URI Class Initialized
DEBUG - 2021-04-12 14:48:43 --> No URI present. Default controller set.
INFO - 2021-04-12 14:48:43 --> Router Class Initialized
INFO - 2021-04-12 14:48:43 --> Output Class Initialized
INFO - 2021-04-12 14:48:43 --> Security Class Initialized
DEBUG - 2021-04-12 14:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:48:43 --> Input Class Initialized
INFO - 2021-04-12 14:48:43 --> Language Class Initialized
INFO - 2021-04-12 14:48:43 --> Language Class Initialized
INFO - 2021-04-12 14:48:43 --> Config Class Initialized
INFO - 2021-04-12 14:48:43 --> Loader Class Initialized
INFO - 2021-04-12 14:48:43 --> Helper loaded: url_helper
INFO - 2021-04-12 14:48:43 --> Helper loaded: file_helper
INFO - 2021-04-12 14:48:43 --> Helper loaded: form_helper
INFO - 2021-04-12 14:48:43 --> Helper loaded: my_helper
INFO - 2021-04-12 14:48:44 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:48:44 --> Controller Class Initialized
INFO - 2021-04-12 14:48:44 --> Config Class Initialized
INFO - 2021-04-12 14:48:44 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:48:44 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:48:44 --> Utf8 Class Initialized
INFO - 2021-04-12 14:48:44 --> URI Class Initialized
INFO - 2021-04-12 14:48:44 --> Router Class Initialized
INFO - 2021-04-12 14:48:44 --> Output Class Initialized
INFO - 2021-04-12 14:48:44 --> Security Class Initialized
DEBUG - 2021-04-12 14:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:48:44 --> Input Class Initialized
INFO - 2021-04-12 14:48:44 --> Language Class Initialized
INFO - 2021-04-12 14:48:44 --> Language Class Initialized
INFO - 2021-04-12 14:48:44 --> Config Class Initialized
INFO - 2021-04-12 14:48:44 --> Loader Class Initialized
INFO - 2021-04-12 14:48:44 --> Helper loaded: url_helper
INFO - 2021-04-12 14:48:44 --> Helper loaded: file_helper
INFO - 2021-04-12 14:48:44 --> Helper loaded: form_helper
INFO - 2021-04-12 14:48:44 --> Helper loaded: my_helper
INFO - 2021-04-12 14:48:44 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:48:44 --> Controller Class Initialized
DEBUG - 2021-04-12 14:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-12 14:48:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:48:44 --> Final output sent to browser
DEBUG - 2021-04-12 14:48:44 --> Total execution time: 0.1043
INFO - 2021-04-12 14:48:51 --> Config Class Initialized
INFO - 2021-04-12 14:48:51 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:48:51 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:48:51 --> Utf8 Class Initialized
INFO - 2021-04-12 14:48:51 --> URI Class Initialized
INFO - 2021-04-12 14:48:51 --> Router Class Initialized
INFO - 2021-04-12 14:48:51 --> Output Class Initialized
INFO - 2021-04-12 14:48:51 --> Security Class Initialized
DEBUG - 2021-04-12 14:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:48:51 --> Input Class Initialized
INFO - 2021-04-12 14:48:51 --> Language Class Initialized
INFO - 2021-04-12 14:48:51 --> Language Class Initialized
INFO - 2021-04-12 14:48:51 --> Config Class Initialized
INFO - 2021-04-12 14:48:51 --> Loader Class Initialized
INFO - 2021-04-12 14:48:51 --> Helper loaded: url_helper
INFO - 2021-04-12 14:48:51 --> Helper loaded: file_helper
INFO - 2021-04-12 14:48:51 --> Helper loaded: form_helper
INFO - 2021-04-12 14:48:51 --> Helper loaded: my_helper
INFO - 2021-04-12 14:48:51 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:48:51 --> Controller Class Initialized
INFO - 2021-04-12 14:48:51 --> Helper loaded: cookie_helper
INFO - 2021-04-12 14:48:51 --> Final output sent to browser
DEBUG - 2021-04-12 14:48:51 --> Total execution time: 0.1406
INFO - 2021-04-12 14:48:52 --> Config Class Initialized
INFO - 2021-04-12 14:48:52 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:48:52 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:48:52 --> Utf8 Class Initialized
INFO - 2021-04-12 14:48:52 --> URI Class Initialized
INFO - 2021-04-12 14:48:52 --> Router Class Initialized
INFO - 2021-04-12 14:48:52 --> Output Class Initialized
INFO - 2021-04-12 14:48:52 --> Security Class Initialized
DEBUG - 2021-04-12 14:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:48:52 --> Input Class Initialized
INFO - 2021-04-12 14:48:52 --> Language Class Initialized
INFO - 2021-04-12 14:48:52 --> Language Class Initialized
INFO - 2021-04-12 14:48:52 --> Config Class Initialized
INFO - 2021-04-12 14:48:52 --> Loader Class Initialized
INFO - 2021-04-12 14:48:52 --> Helper loaded: url_helper
INFO - 2021-04-12 14:48:52 --> Helper loaded: file_helper
INFO - 2021-04-12 14:48:52 --> Helper loaded: form_helper
INFO - 2021-04-12 14:48:52 --> Helper loaded: my_helper
INFO - 2021-04-12 14:48:52 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:48:52 --> Controller Class Initialized
DEBUG - 2021-04-12 14:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-12 14:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:48:52 --> Final output sent to browser
DEBUG - 2021-04-12 14:48:52 --> Total execution time: 0.2862
INFO - 2021-04-12 14:55:06 --> Config Class Initialized
INFO - 2021-04-12 14:55:06 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:06 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:06 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:06 --> URI Class Initialized
INFO - 2021-04-12 14:55:06 --> Router Class Initialized
INFO - 2021-04-12 14:55:06 --> Output Class Initialized
INFO - 2021-04-12 14:55:06 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:06 --> Input Class Initialized
INFO - 2021-04-12 14:55:06 --> Language Class Initialized
INFO - 2021-04-12 14:55:06 --> Language Class Initialized
INFO - 2021-04-12 14:55:06 --> Config Class Initialized
INFO - 2021-04-12 14:55:06 --> Loader Class Initialized
INFO - 2021-04-12 14:55:06 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:06 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:06 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:06 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:06 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:06 --> Controller Class Initialized
DEBUG - 2021-04-12 14:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 14:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:55:06 --> Final output sent to browser
DEBUG - 2021-04-12 14:55:06 --> Total execution time: 0.3277
INFO - 2021-04-12 14:55:24 --> Config Class Initialized
INFO - 2021-04-12 14:55:24 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:24 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:24 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:24 --> URI Class Initialized
INFO - 2021-04-12 14:55:24 --> Router Class Initialized
INFO - 2021-04-12 14:55:24 --> Output Class Initialized
INFO - 2021-04-12 14:55:24 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:24 --> Input Class Initialized
INFO - 2021-04-12 14:55:24 --> Language Class Initialized
INFO - 2021-04-12 14:55:24 --> Language Class Initialized
INFO - 2021-04-12 14:55:24 --> Config Class Initialized
INFO - 2021-04-12 14:55:24 --> Loader Class Initialized
INFO - 2021-04-12 14:55:24 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:24 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:24 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:24 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:24 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:24 --> Controller Class Initialized
DEBUG - 2021-04-12 14:55:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-12 14:55:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:55:24 --> Final output sent to browser
DEBUG - 2021-04-12 14:55:24 --> Total execution time: 0.2183
INFO - 2021-04-12 14:55:24 --> Config Class Initialized
INFO - 2021-04-12 14:55:24 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:24 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:24 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:24 --> URI Class Initialized
INFO - 2021-04-12 14:55:24 --> Router Class Initialized
INFO - 2021-04-12 14:55:24 --> Output Class Initialized
INFO - 2021-04-12 14:55:24 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:24 --> Input Class Initialized
INFO - 2021-04-12 14:55:24 --> Language Class Initialized
INFO - 2021-04-12 14:55:24 --> Language Class Initialized
INFO - 2021-04-12 14:55:24 --> Config Class Initialized
INFO - 2021-04-12 14:55:24 --> Loader Class Initialized
INFO - 2021-04-12 14:55:24 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:24 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:24 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:24 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:24 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:24 --> Controller Class Initialized
INFO - 2021-04-12 14:55:27 --> Config Class Initialized
INFO - 2021-04-12 14:55:27 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:27 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:27 --> URI Class Initialized
INFO - 2021-04-12 14:55:27 --> Router Class Initialized
INFO - 2021-04-12 14:55:27 --> Output Class Initialized
INFO - 2021-04-12 14:55:27 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:27 --> Input Class Initialized
INFO - 2021-04-12 14:55:27 --> Language Class Initialized
INFO - 2021-04-12 14:55:27 --> Language Class Initialized
INFO - 2021-04-12 14:55:27 --> Config Class Initialized
INFO - 2021-04-12 14:55:27 --> Loader Class Initialized
INFO - 2021-04-12 14:55:27 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:27 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:27 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:27 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:27 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:27 --> Controller Class Initialized
DEBUG - 2021-04-12 14:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-12 14:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:55:27 --> Final output sent to browser
DEBUG - 2021-04-12 14:55:27 --> Total execution time: 0.2832
INFO - 2021-04-12 14:55:44 --> Config Class Initialized
INFO - 2021-04-12 14:55:44 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:44 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:44 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:44 --> URI Class Initialized
INFO - 2021-04-12 14:55:44 --> Router Class Initialized
INFO - 2021-04-12 14:55:44 --> Output Class Initialized
INFO - 2021-04-12 14:55:44 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:44 --> Input Class Initialized
INFO - 2021-04-12 14:55:44 --> Language Class Initialized
INFO - 2021-04-12 14:55:44 --> Language Class Initialized
INFO - 2021-04-12 14:55:44 --> Config Class Initialized
INFO - 2021-04-12 14:55:44 --> Loader Class Initialized
INFO - 2021-04-12 14:55:44 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:44 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:44 --> Controller Class Initialized
INFO - 2021-04-12 14:55:44 --> Config Class Initialized
INFO - 2021-04-12 14:55:44 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:44 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:44 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:44 --> URI Class Initialized
INFO - 2021-04-12 14:55:44 --> Router Class Initialized
INFO - 2021-04-12 14:55:44 --> Output Class Initialized
INFO - 2021-04-12 14:55:44 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:44 --> Input Class Initialized
INFO - 2021-04-12 14:55:44 --> Language Class Initialized
INFO - 2021-04-12 14:55:44 --> Language Class Initialized
INFO - 2021-04-12 14:55:44 --> Config Class Initialized
INFO - 2021-04-12 14:55:44 --> Loader Class Initialized
INFO - 2021-04-12 14:55:44 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:44 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:44 --> Controller Class Initialized
DEBUG - 2021-04-12 14:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-12 14:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:55:44 --> Final output sent to browser
DEBUG - 2021-04-12 14:55:44 --> Total execution time: 0.1589
INFO - 2021-04-12 14:55:44 --> Config Class Initialized
INFO - 2021-04-12 14:55:44 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:44 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:44 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:44 --> URI Class Initialized
INFO - 2021-04-12 14:55:44 --> Router Class Initialized
INFO - 2021-04-12 14:55:44 --> Output Class Initialized
INFO - 2021-04-12 14:55:44 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:44 --> Input Class Initialized
INFO - 2021-04-12 14:55:44 --> Language Class Initialized
INFO - 2021-04-12 14:55:44 --> Language Class Initialized
INFO - 2021-04-12 14:55:44 --> Config Class Initialized
INFO - 2021-04-12 14:55:44 --> Loader Class Initialized
INFO - 2021-04-12 14:55:44 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:44 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:44 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:44 --> Controller Class Initialized
INFO - 2021-04-12 14:55:47 --> Config Class Initialized
INFO - 2021-04-12 14:55:47 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:47 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:47 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:47 --> URI Class Initialized
INFO - 2021-04-12 14:55:48 --> Router Class Initialized
INFO - 2021-04-12 14:55:48 --> Output Class Initialized
INFO - 2021-04-12 14:55:48 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:48 --> Input Class Initialized
INFO - 2021-04-12 14:55:48 --> Language Class Initialized
INFO - 2021-04-12 14:55:48 --> Language Class Initialized
INFO - 2021-04-12 14:55:48 --> Config Class Initialized
INFO - 2021-04-12 14:55:48 --> Loader Class Initialized
INFO - 2021-04-12 14:55:48 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:48 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:48 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:48 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:48 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:48 --> Controller Class Initialized
DEBUG - 2021-04-12 14:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-12 14:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:55:48 --> Final output sent to browser
DEBUG - 2021-04-12 14:55:48 --> Total execution time: 0.3091
INFO - 2021-04-12 14:55:48 --> Config Class Initialized
INFO - 2021-04-12 14:55:48 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:48 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:48 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:48 --> URI Class Initialized
INFO - 2021-04-12 14:55:48 --> Router Class Initialized
INFO - 2021-04-12 14:55:48 --> Output Class Initialized
INFO - 2021-04-12 14:55:48 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:48 --> Input Class Initialized
INFO - 2021-04-12 14:55:48 --> Language Class Initialized
INFO - 2021-04-12 14:55:48 --> Language Class Initialized
INFO - 2021-04-12 14:55:48 --> Config Class Initialized
INFO - 2021-04-12 14:55:48 --> Loader Class Initialized
INFO - 2021-04-12 14:55:48 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:48 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:48 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:48 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:48 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:48 --> Controller Class Initialized
INFO - 2021-04-12 14:55:50 --> Config Class Initialized
INFO - 2021-04-12 14:55:50 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:55:50 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:55:50 --> Utf8 Class Initialized
INFO - 2021-04-12 14:55:50 --> URI Class Initialized
INFO - 2021-04-12 14:55:50 --> Router Class Initialized
INFO - 2021-04-12 14:55:50 --> Output Class Initialized
INFO - 2021-04-12 14:55:50 --> Security Class Initialized
DEBUG - 2021-04-12 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:55:50 --> Input Class Initialized
INFO - 2021-04-12 14:55:50 --> Language Class Initialized
INFO - 2021-04-12 14:55:50 --> Language Class Initialized
INFO - 2021-04-12 14:55:50 --> Config Class Initialized
INFO - 2021-04-12 14:55:50 --> Loader Class Initialized
INFO - 2021-04-12 14:55:50 --> Helper loaded: url_helper
INFO - 2021-04-12 14:55:50 --> Helper loaded: file_helper
INFO - 2021-04-12 14:55:50 --> Helper loaded: form_helper
INFO - 2021-04-12 14:55:50 --> Helper loaded: my_helper
INFO - 2021-04-12 14:55:50 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:55:50 --> Controller Class Initialized
INFO - 2021-04-12 14:55:50 --> Final output sent to browser
DEBUG - 2021-04-12 14:55:50 --> Total execution time: 0.1946
INFO - 2021-04-12 14:56:00 --> Config Class Initialized
INFO - 2021-04-12 14:56:00 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:00 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:00 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:00 --> URI Class Initialized
INFO - 2021-04-12 14:56:00 --> Router Class Initialized
INFO - 2021-04-12 14:56:00 --> Output Class Initialized
INFO - 2021-04-12 14:56:00 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:00 --> Input Class Initialized
INFO - 2021-04-12 14:56:00 --> Language Class Initialized
INFO - 2021-04-12 14:56:00 --> Language Class Initialized
INFO - 2021-04-12 14:56:00 --> Config Class Initialized
INFO - 2021-04-12 14:56:00 --> Loader Class Initialized
INFO - 2021-04-12 14:56:00 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:00 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:00 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:00 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:00 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:00 --> Controller Class Initialized
INFO - 2021-04-12 14:56:00 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:00 --> Total execution time: 0.2284
INFO - 2021-04-12 14:56:00 --> Config Class Initialized
INFO - 2021-04-12 14:56:00 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:00 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:00 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:00 --> URI Class Initialized
INFO - 2021-04-12 14:56:00 --> Router Class Initialized
INFO - 2021-04-12 14:56:00 --> Output Class Initialized
INFO - 2021-04-12 14:56:00 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:00 --> Input Class Initialized
INFO - 2021-04-12 14:56:00 --> Language Class Initialized
INFO - 2021-04-12 14:56:00 --> Language Class Initialized
INFO - 2021-04-12 14:56:00 --> Config Class Initialized
INFO - 2021-04-12 14:56:00 --> Loader Class Initialized
INFO - 2021-04-12 14:56:00 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:00 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:00 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:00 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:00 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:00 --> Controller Class Initialized
INFO - 2021-04-12 14:56:04 --> Config Class Initialized
INFO - 2021-04-12 14:56:04 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:04 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:04 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:04 --> URI Class Initialized
INFO - 2021-04-12 14:56:04 --> Router Class Initialized
INFO - 2021-04-12 14:56:04 --> Output Class Initialized
INFO - 2021-04-12 14:56:04 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:04 --> Input Class Initialized
INFO - 2021-04-12 14:56:04 --> Language Class Initialized
INFO - 2021-04-12 14:56:04 --> Language Class Initialized
INFO - 2021-04-12 14:56:04 --> Config Class Initialized
INFO - 2021-04-12 14:56:04 --> Loader Class Initialized
INFO - 2021-04-12 14:56:04 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:04 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:04 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:04 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:04 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:04 --> Controller Class Initialized
DEBUG - 2021-04-12 14:56:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-12 14:56:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:56:05 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:05 --> Total execution time: 0.2884
INFO - 2021-04-12 14:56:05 --> Config Class Initialized
INFO - 2021-04-12 14:56:05 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:05 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:05 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:05 --> URI Class Initialized
INFO - 2021-04-12 14:56:05 --> Router Class Initialized
INFO - 2021-04-12 14:56:05 --> Output Class Initialized
INFO - 2021-04-12 14:56:05 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:05 --> Input Class Initialized
INFO - 2021-04-12 14:56:05 --> Language Class Initialized
INFO - 2021-04-12 14:56:05 --> Language Class Initialized
INFO - 2021-04-12 14:56:05 --> Config Class Initialized
INFO - 2021-04-12 14:56:05 --> Loader Class Initialized
INFO - 2021-04-12 14:56:05 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:05 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:05 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:05 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:05 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:05 --> Controller Class Initialized
INFO - 2021-04-12 14:56:07 --> Config Class Initialized
INFO - 2021-04-12 14:56:07 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:07 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:07 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:07 --> URI Class Initialized
INFO - 2021-04-12 14:56:07 --> Router Class Initialized
INFO - 2021-04-12 14:56:07 --> Output Class Initialized
INFO - 2021-04-12 14:56:07 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:07 --> Input Class Initialized
INFO - 2021-04-12 14:56:07 --> Language Class Initialized
INFO - 2021-04-12 14:56:07 --> Language Class Initialized
INFO - 2021-04-12 14:56:07 --> Config Class Initialized
INFO - 2021-04-12 14:56:07 --> Loader Class Initialized
INFO - 2021-04-12 14:56:07 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:07 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:07 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:07 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:07 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:07 --> Controller Class Initialized
INFO - 2021-04-12 14:56:07 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:07 --> Total execution time: 0.2025
INFO - 2021-04-12 14:56:16 --> Config Class Initialized
INFO - 2021-04-12 14:56:16 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:16 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:16 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:16 --> URI Class Initialized
INFO - 2021-04-12 14:56:16 --> Router Class Initialized
INFO - 2021-04-12 14:56:16 --> Output Class Initialized
INFO - 2021-04-12 14:56:16 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:16 --> Input Class Initialized
INFO - 2021-04-12 14:56:16 --> Language Class Initialized
INFO - 2021-04-12 14:56:16 --> Language Class Initialized
INFO - 2021-04-12 14:56:16 --> Config Class Initialized
INFO - 2021-04-12 14:56:16 --> Loader Class Initialized
INFO - 2021-04-12 14:56:16 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:16 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:16 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:16 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:16 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:16 --> Controller Class Initialized
INFO - 2021-04-12 14:56:16 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:16 --> Total execution time: 0.2254
INFO - 2021-04-12 14:56:16 --> Config Class Initialized
INFO - 2021-04-12 14:56:16 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:16 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:16 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:16 --> URI Class Initialized
INFO - 2021-04-12 14:56:16 --> Router Class Initialized
INFO - 2021-04-12 14:56:16 --> Output Class Initialized
INFO - 2021-04-12 14:56:16 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:16 --> Input Class Initialized
INFO - 2021-04-12 14:56:16 --> Language Class Initialized
INFO - 2021-04-12 14:56:16 --> Language Class Initialized
INFO - 2021-04-12 14:56:16 --> Config Class Initialized
INFO - 2021-04-12 14:56:16 --> Loader Class Initialized
INFO - 2021-04-12 14:56:16 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:16 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:16 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:16 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:16 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:16 --> Controller Class Initialized
INFO - 2021-04-12 14:56:20 --> Config Class Initialized
INFO - 2021-04-12 14:56:20 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:20 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:20 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:20 --> URI Class Initialized
INFO - 2021-04-12 14:56:20 --> Router Class Initialized
INFO - 2021-04-12 14:56:20 --> Output Class Initialized
INFO - 2021-04-12 14:56:20 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:20 --> Input Class Initialized
INFO - 2021-04-12 14:56:21 --> Language Class Initialized
INFO - 2021-04-12 14:56:21 --> Language Class Initialized
INFO - 2021-04-12 14:56:21 --> Config Class Initialized
INFO - 2021-04-12 14:56:21 --> Loader Class Initialized
INFO - 2021-04-12 14:56:21 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:21 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:21 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:21 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:21 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:21 --> Controller Class Initialized
DEBUG - 2021-04-12 14:56:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 14:56:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:56:21 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:21 --> Total execution time: 0.1912
INFO - 2021-04-12 14:56:23 --> Config Class Initialized
INFO - 2021-04-12 14:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:23 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:23 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:23 --> URI Class Initialized
INFO - 2021-04-12 14:56:23 --> Router Class Initialized
INFO - 2021-04-12 14:56:23 --> Output Class Initialized
INFO - 2021-04-12 14:56:23 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:23 --> Input Class Initialized
INFO - 2021-04-12 14:56:23 --> Language Class Initialized
INFO - 2021-04-12 14:56:23 --> Language Class Initialized
INFO - 2021-04-12 14:56:23 --> Config Class Initialized
INFO - 2021-04-12 14:56:23 --> Loader Class Initialized
INFO - 2021-04-12 14:56:23 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:23 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:23 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:23 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:23 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:23 --> Controller Class Initialized
DEBUG - 2021-04-12 14:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-12 14:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:56:23 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:23 --> Total execution time: 0.1841
INFO - 2021-04-12 14:56:23 --> Config Class Initialized
INFO - 2021-04-12 14:56:23 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:23 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:23 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:23 --> URI Class Initialized
INFO - 2021-04-12 14:56:23 --> Router Class Initialized
INFO - 2021-04-12 14:56:23 --> Output Class Initialized
INFO - 2021-04-12 14:56:23 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:23 --> Input Class Initialized
INFO - 2021-04-12 14:56:23 --> Language Class Initialized
INFO - 2021-04-12 14:56:23 --> Language Class Initialized
INFO - 2021-04-12 14:56:23 --> Config Class Initialized
INFO - 2021-04-12 14:56:23 --> Loader Class Initialized
INFO - 2021-04-12 14:56:23 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:23 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:23 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:23 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:23 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:23 --> Controller Class Initialized
INFO - 2021-04-12 14:56:25 --> Config Class Initialized
INFO - 2021-04-12 14:56:25 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:25 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:25 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:25 --> URI Class Initialized
INFO - 2021-04-12 14:56:25 --> Router Class Initialized
INFO - 2021-04-12 14:56:25 --> Output Class Initialized
INFO - 2021-04-12 14:56:25 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:25 --> Input Class Initialized
INFO - 2021-04-12 14:56:25 --> Language Class Initialized
INFO - 2021-04-12 14:56:25 --> Language Class Initialized
INFO - 2021-04-12 14:56:25 --> Config Class Initialized
INFO - 2021-04-12 14:56:25 --> Loader Class Initialized
INFO - 2021-04-12 14:56:25 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:25 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:25 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:25 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:25 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:25 --> Controller Class Initialized
DEBUG - 2021-04-12 14:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-12 14:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:56:25 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:25 --> Total execution time: 0.1656
INFO - 2021-04-12 14:56:25 --> Config Class Initialized
INFO - 2021-04-12 14:56:25 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:25 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:25 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:25 --> URI Class Initialized
INFO - 2021-04-12 14:56:25 --> Router Class Initialized
INFO - 2021-04-12 14:56:25 --> Output Class Initialized
INFO - 2021-04-12 14:56:25 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:25 --> Input Class Initialized
INFO - 2021-04-12 14:56:25 --> Language Class Initialized
INFO - 2021-04-12 14:56:25 --> Language Class Initialized
INFO - 2021-04-12 14:56:25 --> Config Class Initialized
INFO - 2021-04-12 14:56:25 --> Loader Class Initialized
INFO - 2021-04-12 14:56:25 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:25 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:25 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:25 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:25 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:25 --> Controller Class Initialized
INFO - 2021-04-12 14:56:27 --> Config Class Initialized
INFO - 2021-04-12 14:56:27 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:27 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:27 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:27 --> URI Class Initialized
INFO - 2021-04-12 14:56:27 --> Router Class Initialized
INFO - 2021-04-12 14:56:27 --> Output Class Initialized
INFO - 2021-04-12 14:56:27 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:27 --> Input Class Initialized
INFO - 2021-04-12 14:56:27 --> Language Class Initialized
INFO - 2021-04-12 14:56:27 --> Language Class Initialized
INFO - 2021-04-12 14:56:27 --> Config Class Initialized
INFO - 2021-04-12 14:56:27 --> Loader Class Initialized
INFO - 2021-04-12 14:56:27 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:27 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:27 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:27 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:27 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:27 --> Controller Class Initialized
INFO - 2021-04-12 14:56:27 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:27 --> Total execution time: 0.2067
INFO - 2021-04-12 14:56:39 --> Config Class Initialized
INFO - 2021-04-12 14:56:39 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:39 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:39 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:39 --> URI Class Initialized
INFO - 2021-04-12 14:56:39 --> Router Class Initialized
INFO - 2021-04-12 14:56:39 --> Output Class Initialized
INFO - 2021-04-12 14:56:39 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:39 --> Input Class Initialized
INFO - 2021-04-12 14:56:39 --> Language Class Initialized
INFO - 2021-04-12 14:56:39 --> Language Class Initialized
INFO - 2021-04-12 14:56:39 --> Config Class Initialized
INFO - 2021-04-12 14:56:39 --> Loader Class Initialized
INFO - 2021-04-12 14:56:39 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:39 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:39 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:39 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:39 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:39 --> Controller Class Initialized
INFO - 2021-04-12 14:56:39 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:39 --> Total execution time: 0.1646
INFO - 2021-04-12 14:56:41 --> Config Class Initialized
INFO - 2021-04-12 14:56:41 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:41 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:41 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:41 --> URI Class Initialized
INFO - 2021-04-12 14:56:41 --> Router Class Initialized
INFO - 2021-04-12 14:56:42 --> Output Class Initialized
INFO - 2021-04-12 14:56:42 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:42 --> Input Class Initialized
INFO - 2021-04-12 14:56:42 --> Language Class Initialized
INFO - 2021-04-12 14:56:42 --> Language Class Initialized
INFO - 2021-04-12 14:56:42 --> Config Class Initialized
INFO - 2021-04-12 14:56:42 --> Loader Class Initialized
INFO - 2021-04-12 14:56:42 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:42 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:42 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:42 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:42 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:42 --> Controller Class Initialized
INFO - 2021-04-12 14:56:42 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:42 --> Total execution time: 0.1889
INFO - 2021-04-12 14:56:49 --> Config Class Initialized
INFO - 2021-04-12 14:56:49 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:49 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:49 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:49 --> URI Class Initialized
INFO - 2021-04-12 14:56:49 --> Router Class Initialized
INFO - 2021-04-12 14:56:49 --> Output Class Initialized
INFO - 2021-04-12 14:56:49 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:49 --> Input Class Initialized
INFO - 2021-04-12 14:56:49 --> Language Class Initialized
INFO - 2021-04-12 14:56:49 --> Language Class Initialized
INFO - 2021-04-12 14:56:49 --> Config Class Initialized
INFO - 2021-04-12 14:56:49 --> Loader Class Initialized
INFO - 2021-04-12 14:56:49 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:49 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:49 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:49 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:49 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:49 --> Controller Class Initialized
INFO - 2021-04-12 14:56:49 --> Final output sent to browser
DEBUG - 2021-04-12 14:56:49 --> Total execution time: 0.2076
INFO - 2021-04-12 14:56:49 --> Config Class Initialized
INFO - 2021-04-12 14:56:49 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:56:49 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:56:49 --> Utf8 Class Initialized
INFO - 2021-04-12 14:56:49 --> URI Class Initialized
INFO - 2021-04-12 14:56:49 --> Router Class Initialized
INFO - 2021-04-12 14:56:49 --> Output Class Initialized
INFO - 2021-04-12 14:56:49 --> Security Class Initialized
DEBUG - 2021-04-12 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:56:49 --> Input Class Initialized
INFO - 2021-04-12 14:56:49 --> Language Class Initialized
INFO - 2021-04-12 14:56:49 --> Language Class Initialized
INFO - 2021-04-12 14:56:49 --> Config Class Initialized
INFO - 2021-04-12 14:56:49 --> Loader Class Initialized
INFO - 2021-04-12 14:56:49 --> Helper loaded: url_helper
INFO - 2021-04-12 14:56:49 --> Helper loaded: file_helper
INFO - 2021-04-12 14:56:49 --> Helper loaded: form_helper
INFO - 2021-04-12 14:56:49 --> Helper loaded: my_helper
INFO - 2021-04-12 14:56:49 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:56:49 --> Controller Class Initialized
INFO - 2021-04-12 14:57:00 --> Config Class Initialized
INFO - 2021-04-12 14:57:00 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:57:00 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:57:00 --> Utf8 Class Initialized
INFO - 2021-04-12 14:57:00 --> URI Class Initialized
INFO - 2021-04-12 14:57:00 --> Router Class Initialized
INFO - 2021-04-12 14:57:00 --> Output Class Initialized
INFO - 2021-04-12 14:57:00 --> Security Class Initialized
DEBUG - 2021-04-12 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:57:00 --> Input Class Initialized
INFO - 2021-04-12 14:57:00 --> Language Class Initialized
INFO - 2021-04-12 14:57:00 --> Language Class Initialized
INFO - 2021-04-12 14:57:00 --> Config Class Initialized
INFO - 2021-04-12 14:57:00 --> Loader Class Initialized
INFO - 2021-04-12 14:57:00 --> Helper loaded: url_helper
INFO - 2021-04-12 14:57:00 --> Helper loaded: file_helper
INFO - 2021-04-12 14:57:00 --> Helper loaded: form_helper
INFO - 2021-04-12 14:57:00 --> Helper loaded: my_helper
INFO - 2021-04-12 14:57:00 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:57:00 --> Controller Class Initialized
DEBUG - 2021-04-12 14:57:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 14:57:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:57:00 --> Final output sent to browser
DEBUG - 2021-04-12 14:57:00 --> Total execution time: 0.2079
INFO - 2021-04-12 14:57:03 --> Config Class Initialized
INFO - 2021-04-12 14:57:03 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:57:03 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:57:03 --> Utf8 Class Initialized
INFO - 2021-04-12 14:57:03 --> URI Class Initialized
INFO - 2021-04-12 14:57:03 --> Router Class Initialized
INFO - 2021-04-12 14:57:03 --> Output Class Initialized
INFO - 2021-04-12 14:57:03 --> Security Class Initialized
DEBUG - 2021-04-12 14:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:57:03 --> Input Class Initialized
INFO - 2021-04-12 14:57:03 --> Language Class Initialized
INFO - 2021-04-12 14:57:03 --> Language Class Initialized
INFO - 2021-04-12 14:57:03 --> Config Class Initialized
INFO - 2021-04-12 14:57:03 --> Loader Class Initialized
INFO - 2021-04-12 14:57:03 --> Helper loaded: url_helper
INFO - 2021-04-12 14:57:03 --> Helper loaded: file_helper
INFO - 2021-04-12 14:57:03 --> Helper loaded: form_helper
INFO - 2021-04-12 14:57:03 --> Helper loaded: my_helper
INFO - 2021-04-12 14:57:03 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:57:03 --> Controller Class Initialized
DEBUG - 2021-04-12 14:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 14:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:57:03 --> Final output sent to browser
DEBUG - 2021-04-12 14:57:03 --> Total execution time: 0.2444
INFO - 2021-04-12 14:57:12 --> Config Class Initialized
INFO - 2021-04-12 14:57:12 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:57:12 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:57:12 --> Utf8 Class Initialized
INFO - 2021-04-12 14:57:12 --> URI Class Initialized
INFO - 2021-04-12 14:57:12 --> Router Class Initialized
INFO - 2021-04-12 14:57:12 --> Output Class Initialized
INFO - 2021-04-12 14:57:12 --> Security Class Initialized
DEBUG - 2021-04-12 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:57:12 --> Input Class Initialized
INFO - 2021-04-12 14:57:12 --> Language Class Initialized
INFO - 2021-04-12 14:57:12 --> Language Class Initialized
INFO - 2021-04-12 14:57:12 --> Config Class Initialized
INFO - 2021-04-12 14:57:12 --> Loader Class Initialized
INFO - 2021-04-12 14:57:12 --> Helper loaded: url_helper
INFO - 2021-04-12 14:57:12 --> Helper loaded: file_helper
INFO - 2021-04-12 14:57:12 --> Helper loaded: form_helper
INFO - 2021-04-12 14:57:12 --> Helper loaded: my_helper
INFO - 2021-04-12 14:57:12 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:57:12 --> Controller Class Initialized
INFO - 2021-04-12 14:57:12 --> Config Class Initialized
INFO - 2021-04-12 14:57:12 --> Hooks Class Initialized
DEBUG - 2021-04-12 14:57:12 --> UTF-8 Support Enabled
INFO - 2021-04-12 14:57:12 --> Utf8 Class Initialized
INFO - 2021-04-12 14:57:12 --> URI Class Initialized
INFO - 2021-04-12 14:57:12 --> Router Class Initialized
INFO - 2021-04-12 14:57:12 --> Output Class Initialized
INFO - 2021-04-12 14:57:12 --> Security Class Initialized
DEBUG - 2021-04-12 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 14:57:12 --> Input Class Initialized
INFO - 2021-04-12 14:57:12 --> Language Class Initialized
INFO - 2021-04-12 14:57:12 --> Language Class Initialized
INFO - 2021-04-12 14:57:12 --> Config Class Initialized
INFO - 2021-04-12 14:57:12 --> Loader Class Initialized
INFO - 2021-04-12 14:57:12 --> Helper loaded: url_helper
INFO - 2021-04-12 14:57:12 --> Helper loaded: file_helper
INFO - 2021-04-12 14:57:12 --> Helper loaded: form_helper
INFO - 2021-04-12 14:57:12 --> Helper loaded: my_helper
INFO - 2021-04-12 14:57:12 --> Database Driver Class Initialized
DEBUG - 2021-04-12 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 14:57:12 --> Controller Class Initialized
DEBUG - 2021-04-12 14:57:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 14:57:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 14:57:12 --> Final output sent to browser
DEBUG - 2021-04-12 14:57:12 --> Total execution time: 0.2286
INFO - 2021-04-12 15:06:18 --> Config Class Initialized
INFO - 2021-04-12 15:06:18 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:06:18 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:06:18 --> Utf8 Class Initialized
INFO - 2021-04-12 15:06:18 --> URI Class Initialized
INFO - 2021-04-12 15:06:18 --> Router Class Initialized
INFO - 2021-04-12 15:06:18 --> Output Class Initialized
INFO - 2021-04-12 15:06:18 --> Security Class Initialized
DEBUG - 2021-04-12 15:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:06:18 --> Input Class Initialized
INFO - 2021-04-12 15:06:18 --> Language Class Initialized
INFO - 2021-04-12 15:06:18 --> Language Class Initialized
INFO - 2021-04-12 15:06:18 --> Config Class Initialized
INFO - 2021-04-12 15:06:18 --> Loader Class Initialized
INFO - 2021-04-12 15:06:18 --> Helper loaded: url_helper
INFO - 2021-04-12 15:06:18 --> Helper loaded: file_helper
INFO - 2021-04-12 15:06:18 --> Helper loaded: form_helper
INFO - 2021-04-12 15:06:18 --> Helper loaded: my_helper
INFO - 2021-04-12 15:06:18 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:06:18 --> Controller Class Initialized
DEBUG - 2021-04-12 15:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:06:18 --> Final output sent to browser
DEBUG - 2021-04-12 15:06:18 --> Total execution time: 0.1742
INFO - 2021-04-12 15:19:53 --> Config Class Initialized
INFO - 2021-04-12 15:19:53 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:19:53 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:19:53 --> Utf8 Class Initialized
INFO - 2021-04-12 15:19:53 --> URI Class Initialized
INFO - 2021-04-12 15:19:53 --> Router Class Initialized
INFO - 2021-04-12 15:19:53 --> Output Class Initialized
INFO - 2021-04-12 15:19:53 --> Security Class Initialized
DEBUG - 2021-04-12 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:19:53 --> Input Class Initialized
INFO - 2021-04-12 15:19:53 --> Language Class Initialized
INFO - 2021-04-12 15:19:53 --> Language Class Initialized
INFO - 2021-04-12 15:19:53 --> Config Class Initialized
INFO - 2021-04-12 15:19:53 --> Loader Class Initialized
INFO - 2021-04-12 15:19:53 --> Helper loaded: url_helper
INFO - 2021-04-12 15:19:53 --> Helper loaded: file_helper
INFO - 2021-04-12 15:19:53 --> Helper loaded: form_helper
INFO - 2021-04-12 15:19:53 --> Helper loaded: my_helper
INFO - 2021-04-12 15:19:53 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:19:53 --> Controller Class Initialized
DEBUG - 2021-04-12 15:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:19:53 --> Final output sent to browser
DEBUG - 2021-04-12 15:19:53 --> Total execution time: 0.1590
INFO - 2021-04-12 15:21:14 --> Config Class Initialized
INFO - 2021-04-12 15:21:14 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:21:14 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:21:14 --> Utf8 Class Initialized
INFO - 2021-04-12 15:21:14 --> URI Class Initialized
INFO - 2021-04-12 15:21:14 --> Router Class Initialized
INFO - 2021-04-12 15:21:14 --> Output Class Initialized
INFO - 2021-04-12 15:21:14 --> Security Class Initialized
DEBUG - 2021-04-12 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:21:15 --> Input Class Initialized
INFO - 2021-04-12 15:21:15 --> Language Class Initialized
INFO - 2021-04-12 15:21:15 --> Language Class Initialized
INFO - 2021-04-12 15:21:15 --> Config Class Initialized
INFO - 2021-04-12 15:21:15 --> Loader Class Initialized
INFO - 2021-04-12 15:21:15 --> Helper loaded: url_helper
INFO - 2021-04-12 15:21:15 --> Helper loaded: file_helper
INFO - 2021-04-12 15:21:15 --> Helper loaded: form_helper
INFO - 2021-04-12 15:21:15 --> Helper loaded: my_helper
INFO - 2021-04-12 15:21:15 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:21:15 --> Controller Class Initialized
INFO - 2021-04-12 15:21:15 --> Config Class Initialized
INFO - 2021-04-12 15:21:15 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:21:15 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:21:15 --> Utf8 Class Initialized
INFO - 2021-04-12 15:21:15 --> URI Class Initialized
INFO - 2021-04-12 15:21:15 --> Router Class Initialized
INFO - 2021-04-12 15:21:15 --> Output Class Initialized
INFO - 2021-04-12 15:21:15 --> Security Class Initialized
DEBUG - 2021-04-12 15:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:21:15 --> Input Class Initialized
INFO - 2021-04-12 15:21:15 --> Language Class Initialized
INFO - 2021-04-12 15:21:15 --> Language Class Initialized
INFO - 2021-04-12 15:21:15 --> Config Class Initialized
INFO - 2021-04-12 15:21:15 --> Loader Class Initialized
INFO - 2021-04-12 15:21:15 --> Helper loaded: url_helper
INFO - 2021-04-12 15:21:15 --> Helper loaded: file_helper
INFO - 2021-04-12 15:21:15 --> Helper loaded: form_helper
INFO - 2021-04-12 15:21:15 --> Helper loaded: my_helper
INFO - 2021-04-12 15:21:15 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:21:15 --> Controller Class Initialized
DEBUG - 2021-04-12 15:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:21:15 --> Final output sent to browser
DEBUG - 2021-04-12 15:21:15 --> Total execution time: 0.2207
INFO - 2021-04-12 15:21:29 --> Config Class Initialized
INFO - 2021-04-12 15:21:29 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:21:29 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:21:29 --> Utf8 Class Initialized
INFO - 2021-04-12 15:21:29 --> URI Class Initialized
INFO - 2021-04-12 15:21:29 --> Router Class Initialized
INFO - 2021-04-12 15:21:29 --> Output Class Initialized
INFO - 2021-04-12 15:21:29 --> Security Class Initialized
DEBUG - 2021-04-12 15:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:21:29 --> Input Class Initialized
INFO - 2021-04-12 15:21:29 --> Language Class Initialized
INFO - 2021-04-12 15:21:29 --> Language Class Initialized
INFO - 2021-04-12 15:21:29 --> Config Class Initialized
INFO - 2021-04-12 15:21:29 --> Loader Class Initialized
INFO - 2021-04-12 15:21:29 --> Helper loaded: url_helper
INFO - 2021-04-12 15:21:29 --> Helper loaded: file_helper
INFO - 2021-04-12 15:21:29 --> Helper loaded: form_helper
INFO - 2021-04-12 15:21:29 --> Helper loaded: my_helper
INFO - 2021-04-12 15:21:29 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:21:29 --> Controller Class Initialized
DEBUG - 2021-04-12 15:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:21:29 --> Final output sent to browser
DEBUG - 2021-04-12 15:21:29 --> Total execution time: 0.1473
INFO - 2021-04-12 15:24:23 --> Config Class Initialized
INFO - 2021-04-12 15:24:23 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:24:23 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:24:23 --> Utf8 Class Initialized
INFO - 2021-04-12 15:24:23 --> URI Class Initialized
INFO - 2021-04-12 15:24:23 --> Router Class Initialized
INFO - 2021-04-12 15:24:23 --> Output Class Initialized
INFO - 2021-04-12 15:24:23 --> Security Class Initialized
DEBUG - 2021-04-12 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:24:23 --> Input Class Initialized
INFO - 2021-04-12 15:24:23 --> Language Class Initialized
INFO - 2021-04-12 15:24:23 --> Language Class Initialized
INFO - 2021-04-12 15:24:23 --> Config Class Initialized
INFO - 2021-04-12 15:24:23 --> Loader Class Initialized
INFO - 2021-04-12 15:24:23 --> Helper loaded: url_helper
INFO - 2021-04-12 15:24:23 --> Helper loaded: file_helper
INFO - 2021-04-12 15:24:23 --> Helper loaded: form_helper
INFO - 2021-04-12 15:24:23 --> Helper loaded: my_helper
INFO - 2021-04-12 15:24:23 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:24:23 --> Controller Class Initialized
DEBUG - 2021-04-12 15:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:24:23 --> Final output sent to browser
DEBUG - 2021-04-12 15:24:23 --> Total execution time: 0.1542
INFO - 2021-04-12 15:24:26 --> Config Class Initialized
INFO - 2021-04-12 15:24:26 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:24:26 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:24:26 --> Utf8 Class Initialized
INFO - 2021-04-12 15:24:26 --> URI Class Initialized
INFO - 2021-04-12 15:24:26 --> Router Class Initialized
INFO - 2021-04-12 15:24:26 --> Output Class Initialized
INFO - 2021-04-12 15:24:26 --> Security Class Initialized
DEBUG - 2021-04-12 15:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:24:26 --> Input Class Initialized
INFO - 2021-04-12 15:24:26 --> Language Class Initialized
INFO - 2021-04-12 15:24:26 --> Language Class Initialized
INFO - 2021-04-12 15:24:26 --> Config Class Initialized
INFO - 2021-04-12 15:24:26 --> Loader Class Initialized
INFO - 2021-04-12 15:24:26 --> Helper loaded: url_helper
INFO - 2021-04-12 15:24:26 --> Helper loaded: file_helper
INFO - 2021-04-12 15:24:26 --> Helper loaded: form_helper
INFO - 2021-04-12 15:24:26 --> Helper loaded: my_helper
INFO - 2021-04-12 15:24:26 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:24:26 --> Controller Class Initialized
DEBUG - 2021-04-12 15:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:24:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:24:27 --> Final output sent to browser
DEBUG - 2021-04-12 15:24:27 --> Total execution time: 0.1437
INFO - 2021-04-12 15:24:28 --> Config Class Initialized
INFO - 2021-04-12 15:24:28 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:24:28 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:24:28 --> Utf8 Class Initialized
INFO - 2021-04-12 15:24:28 --> URI Class Initialized
INFO - 2021-04-12 15:24:28 --> Router Class Initialized
INFO - 2021-04-12 15:24:28 --> Output Class Initialized
INFO - 2021-04-12 15:24:28 --> Security Class Initialized
DEBUG - 2021-04-12 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:24:28 --> Input Class Initialized
INFO - 2021-04-12 15:24:28 --> Language Class Initialized
INFO - 2021-04-12 15:24:28 --> Language Class Initialized
INFO - 2021-04-12 15:24:28 --> Config Class Initialized
INFO - 2021-04-12 15:24:28 --> Loader Class Initialized
INFO - 2021-04-12 15:24:28 --> Helper loaded: url_helper
INFO - 2021-04-12 15:24:28 --> Helper loaded: file_helper
INFO - 2021-04-12 15:24:28 --> Helper loaded: form_helper
INFO - 2021-04-12 15:24:28 --> Helper loaded: my_helper
INFO - 2021-04-12 15:24:28 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:24:28 --> Controller Class Initialized
DEBUG - 2021-04-12 15:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:24:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:24:28 --> Final output sent to browser
DEBUG - 2021-04-12 15:24:28 --> Total execution time: 0.1305
INFO - 2021-04-12 15:27:29 --> Config Class Initialized
INFO - 2021-04-12 15:27:29 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:29 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:29 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:29 --> URI Class Initialized
INFO - 2021-04-12 15:27:29 --> Router Class Initialized
INFO - 2021-04-12 15:27:29 --> Output Class Initialized
INFO - 2021-04-12 15:27:29 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:29 --> Input Class Initialized
INFO - 2021-04-12 15:27:29 --> Language Class Initialized
INFO - 2021-04-12 15:27:29 --> Language Class Initialized
INFO - 2021-04-12 15:27:29 --> Config Class Initialized
INFO - 2021-04-12 15:27:29 --> Loader Class Initialized
INFO - 2021-04-12 15:27:29 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:29 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:29 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:29 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:29 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:29 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:29 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:29 --> Total execution time: 0.1448
INFO - 2021-04-12 15:27:30 --> Config Class Initialized
INFO - 2021-04-12 15:27:30 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:30 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:30 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:30 --> URI Class Initialized
INFO - 2021-04-12 15:27:30 --> Router Class Initialized
INFO - 2021-04-12 15:27:30 --> Output Class Initialized
INFO - 2021-04-12 15:27:30 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:30 --> Input Class Initialized
INFO - 2021-04-12 15:27:30 --> Language Class Initialized
INFO - 2021-04-12 15:27:30 --> Language Class Initialized
INFO - 2021-04-12 15:27:30 --> Config Class Initialized
INFO - 2021-04-12 15:27:30 --> Loader Class Initialized
INFO - 2021-04-12 15:27:30 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:30 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:30 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:30 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:30 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:30 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:30 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:30 --> Total execution time: 0.1373
INFO - 2021-04-12 15:27:33 --> Config Class Initialized
INFO - 2021-04-12 15:27:33 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:33 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:33 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:33 --> URI Class Initialized
INFO - 2021-04-12 15:27:33 --> Router Class Initialized
INFO - 2021-04-12 15:27:33 --> Output Class Initialized
INFO - 2021-04-12 15:27:33 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:33 --> Input Class Initialized
INFO - 2021-04-12 15:27:33 --> Language Class Initialized
INFO - 2021-04-12 15:27:33 --> Language Class Initialized
INFO - 2021-04-12 15:27:33 --> Config Class Initialized
INFO - 2021-04-12 15:27:33 --> Loader Class Initialized
INFO - 2021-04-12 15:27:33 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:33 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:33 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:33 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:33 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:33 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:33 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:33 --> Total execution time: 0.1328
INFO - 2021-04-12 15:27:37 --> Config Class Initialized
INFO - 2021-04-12 15:27:37 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:37 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:37 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:37 --> URI Class Initialized
INFO - 2021-04-12 15:27:37 --> Router Class Initialized
INFO - 2021-04-12 15:27:37 --> Output Class Initialized
INFO - 2021-04-12 15:27:37 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:37 --> Input Class Initialized
INFO - 2021-04-12 15:27:37 --> Language Class Initialized
INFO - 2021-04-12 15:27:37 --> Language Class Initialized
INFO - 2021-04-12 15:27:37 --> Config Class Initialized
INFO - 2021-04-12 15:27:37 --> Loader Class Initialized
INFO - 2021-04-12 15:27:37 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:37 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:37 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:37 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:37 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:37 --> Controller Class Initialized
INFO - 2021-04-12 15:27:37 --> Config Class Initialized
INFO - 2021-04-12 15:27:37 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:37 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:37 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:37 --> URI Class Initialized
INFO - 2021-04-12 15:27:37 --> Router Class Initialized
INFO - 2021-04-12 15:27:37 --> Output Class Initialized
INFO - 2021-04-12 15:27:37 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:37 --> Input Class Initialized
INFO - 2021-04-12 15:27:37 --> Language Class Initialized
INFO - 2021-04-12 15:27:37 --> Language Class Initialized
INFO - 2021-04-12 15:27:37 --> Config Class Initialized
INFO - 2021-04-12 15:27:37 --> Loader Class Initialized
INFO - 2021-04-12 15:27:37 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:37 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:37 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:37 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:37 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:37 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:37 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:37 --> Total execution time: 0.1307
INFO - 2021-04-12 15:27:40 --> Config Class Initialized
INFO - 2021-04-12 15:27:40 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:40 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:40 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:40 --> URI Class Initialized
INFO - 2021-04-12 15:27:40 --> Router Class Initialized
INFO - 2021-04-12 15:27:40 --> Output Class Initialized
INFO - 2021-04-12 15:27:40 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:40 --> Input Class Initialized
INFO - 2021-04-12 15:27:40 --> Language Class Initialized
INFO - 2021-04-12 15:27:40 --> Language Class Initialized
INFO - 2021-04-12 15:27:40 --> Config Class Initialized
INFO - 2021-04-12 15:27:40 --> Loader Class Initialized
INFO - 2021-04-12 15:27:40 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:40 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:40 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:40 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:40 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:40 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:40 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:40 --> Total execution time: 0.1296
INFO - 2021-04-12 15:27:42 --> Config Class Initialized
INFO - 2021-04-12 15:27:42 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:42 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:42 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:42 --> URI Class Initialized
INFO - 2021-04-12 15:27:42 --> Router Class Initialized
INFO - 2021-04-12 15:27:42 --> Output Class Initialized
INFO - 2021-04-12 15:27:42 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:42 --> Input Class Initialized
INFO - 2021-04-12 15:27:42 --> Language Class Initialized
INFO - 2021-04-12 15:27:42 --> Language Class Initialized
INFO - 2021-04-12 15:27:42 --> Config Class Initialized
INFO - 2021-04-12 15:27:42 --> Loader Class Initialized
INFO - 2021-04-12 15:27:42 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:42 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:42 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:42 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:42 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:42 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:27:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:42 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:42 --> Total execution time: 0.1532
INFO - 2021-04-12 15:27:46 --> Config Class Initialized
INFO - 2021-04-12 15:27:46 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:46 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:46 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:46 --> URI Class Initialized
INFO - 2021-04-12 15:27:46 --> Router Class Initialized
INFO - 2021-04-12 15:27:46 --> Output Class Initialized
INFO - 2021-04-12 15:27:46 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:46 --> Input Class Initialized
INFO - 2021-04-12 15:27:46 --> Language Class Initialized
INFO - 2021-04-12 15:27:46 --> Language Class Initialized
INFO - 2021-04-12 15:27:46 --> Config Class Initialized
INFO - 2021-04-12 15:27:46 --> Loader Class Initialized
INFO - 2021-04-12 15:27:46 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:46 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:46 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:46 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:46 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:46 --> Controller Class Initialized
INFO - 2021-04-12 15:27:46 --> Config Class Initialized
INFO - 2021-04-12 15:27:46 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:27:46 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:27:46 --> Utf8 Class Initialized
INFO - 2021-04-12 15:27:46 --> URI Class Initialized
INFO - 2021-04-12 15:27:46 --> Router Class Initialized
INFO - 2021-04-12 15:27:46 --> Output Class Initialized
INFO - 2021-04-12 15:27:46 --> Security Class Initialized
DEBUG - 2021-04-12 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:27:46 --> Input Class Initialized
INFO - 2021-04-12 15:27:46 --> Language Class Initialized
INFO - 2021-04-12 15:27:46 --> Language Class Initialized
INFO - 2021-04-12 15:27:46 --> Config Class Initialized
INFO - 2021-04-12 15:27:46 --> Loader Class Initialized
INFO - 2021-04-12 15:27:46 --> Helper loaded: url_helper
INFO - 2021-04-12 15:27:46 --> Helper loaded: file_helper
INFO - 2021-04-12 15:27:46 --> Helper loaded: form_helper
INFO - 2021-04-12 15:27:46 --> Helper loaded: my_helper
INFO - 2021-04-12 15:27:46 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:27:46 --> Controller Class Initialized
DEBUG - 2021-04-12 15:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:27:46 --> Final output sent to browser
DEBUG - 2021-04-12 15:27:46 --> Total execution time: 0.1540
INFO - 2021-04-12 15:28:20 --> Config Class Initialized
INFO - 2021-04-12 15:28:20 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:20 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:20 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:20 --> URI Class Initialized
INFO - 2021-04-12 15:28:20 --> Router Class Initialized
INFO - 2021-04-12 15:28:20 --> Output Class Initialized
INFO - 2021-04-12 15:28:20 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:20 --> Input Class Initialized
INFO - 2021-04-12 15:28:20 --> Language Class Initialized
INFO - 2021-04-12 15:28:20 --> Language Class Initialized
INFO - 2021-04-12 15:28:20 --> Config Class Initialized
INFO - 2021-04-12 15:28:20 --> Loader Class Initialized
INFO - 2021-04-12 15:28:20 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:20 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:20 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:20 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:20 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:20 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-04-12 15:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:20 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:20 --> Total execution time: 0.1727
INFO - 2021-04-12 15:28:20 --> Config Class Initialized
INFO - 2021-04-12 15:28:20 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:20 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:20 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:20 --> URI Class Initialized
INFO - 2021-04-12 15:28:20 --> Router Class Initialized
INFO - 2021-04-12 15:28:20 --> Output Class Initialized
INFO - 2021-04-12 15:28:20 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:20 --> Input Class Initialized
INFO - 2021-04-12 15:28:20 --> Language Class Initialized
INFO - 2021-04-12 15:28:20 --> Language Class Initialized
INFO - 2021-04-12 15:28:20 --> Config Class Initialized
INFO - 2021-04-12 15:28:20 --> Loader Class Initialized
INFO - 2021-04-12 15:28:20 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:20 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:20 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:20 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:20 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:20 --> Controller Class Initialized
INFO - 2021-04-12 15:28:21 --> Config Class Initialized
INFO - 2021-04-12 15:28:21 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:21 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:21 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:21 --> URI Class Initialized
INFO - 2021-04-12 15:28:21 --> Router Class Initialized
INFO - 2021-04-12 15:28:21 --> Output Class Initialized
INFO - 2021-04-12 15:28:21 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:21 --> Input Class Initialized
INFO - 2021-04-12 15:28:21 --> Language Class Initialized
INFO - 2021-04-12 15:28:21 --> Language Class Initialized
INFO - 2021-04-12 15:28:21 --> Config Class Initialized
INFO - 2021-04-12 15:28:21 --> Loader Class Initialized
INFO - 2021-04-12 15:28:21 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:21 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:21 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:21 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:22 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:22 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-04-12 15:28:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:22 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:22 --> Total execution time: 0.1939
INFO - 2021-04-12 15:28:22 --> Config Class Initialized
INFO - 2021-04-12 15:28:22 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:22 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:22 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:22 --> URI Class Initialized
INFO - 2021-04-12 15:28:22 --> Router Class Initialized
INFO - 2021-04-12 15:28:22 --> Output Class Initialized
INFO - 2021-04-12 15:28:22 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:22 --> Input Class Initialized
INFO - 2021-04-12 15:28:22 --> Language Class Initialized
INFO - 2021-04-12 15:28:22 --> Language Class Initialized
INFO - 2021-04-12 15:28:22 --> Config Class Initialized
INFO - 2021-04-12 15:28:22 --> Loader Class Initialized
INFO - 2021-04-12 15:28:22 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:22 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:22 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:22 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:22 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:22 --> Controller Class Initialized
INFO - 2021-04-12 15:28:25 --> Config Class Initialized
INFO - 2021-04-12 15:28:25 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:25 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:25 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:25 --> URI Class Initialized
INFO - 2021-04-12 15:28:25 --> Router Class Initialized
INFO - 2021-04-12 15:28:25 --> Output Class Initialized
INFO - 2021-04-12 15:28:25 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:25 --> Input Class Initialized
INFO - 2021-04-12 15:28:25 --> Language Class Initialized
INFO - 2021-04-12 15:28:25 --> Language Class Initialized
INFO - 2021-04-12 15:28:25 --> Config Class Initialized
INFO - 2021-04-12 15:28:25 --> Loader Class Initialized
INFO - 2021-04-12 15:28:25 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:25 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:25 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:25 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:25 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:25 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-12 15:28:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:25 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:25 --> Total execution time: 0.1652
INFO - 2021-04-12 15:28:25 --> Config Class Initialized
INFO - 2021-04-12 15:28:25 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:25 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:25 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:25 --> URI Class Initialized
INFO - 2021-04-12 15:28:25 --> Router Class Initialized
INFO - 2021-04-12 15:28:25 --> Output Class Initialized
INFO - 2021-04-12 15:28:25 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:25 --> Input Class Initialized
INFO - 2021-04-12 15:28:25 --> Language Class Initialized
INFO - 2021-04-12 15:28:25 --> Language Class Initialized
INFO - 2021-04-12 15:28:25 --> Config Class Initialized
INFO - 2021-04-12 15:28:25 --> Loader Class Initialized
INFO - 2021-04-12 15:28:25 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:25 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:25 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:25 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:25 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:25 --> Controller Class Initialized
INFO - 2021-04-12 15:28:26 --> Config Class Initialized
INFO - 2021-04-12 15:28:26 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:26 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:26 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:26 --> URI Class Initialized
INFO - 2021-04-12 15:28:26 --> Router Class Initialized
INFO - 2021-04-12 15:28:26 --> Output Class Initialized
INFO - 2021-04-12 15:28:26 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:26 --> Input Class Initialized
INFO - 2021-04-12 15:28:26 --> Language Class Initialized
INFO - 2021-04-12 15:28:26 --> Language Class Initialized
INFO - 2021-04-12 15:28:26 --> Config Class Initialized
INFO - 2021-04-12 15:28:26 --> Loader Class Initialized
INFO - 2021-04-12 15:28:26 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:26 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:26 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:26 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:26 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:26 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-12 15:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:26 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:26 --> Total execution time: 0.2080
INFO - 2021-04-12 15:28:26 --> Config Class Initialized
INFO - 2021-04-12 15:28:26 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:26 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:26 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:26 --> URI Class Initialized
INFO - 2021-04-12 15:28:26 --> Router Class Initialized
INFO - 2021-04-12 15:28:26 --> Output Class Initialized
INFO - 2021-04-12 15:28:26 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:27 --> Input Class Initialized
INFO - 2021-04-12 15:28:27 --> Language Class Initialized
INFO - 2021-04-12 15:28:27 --> Language Class Initialized
INFO - 2021-04-12 15:28:27 --> Config Class Initialized
INFO - 2021-04-12 15:28:27 --> Loader Class Initialized
INFO - 2021-04-12 15:28:27 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:27 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:27 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:27 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:27 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:27 --> Controller Class Initialized
INFO - 2021-04-12 15:28:28 --> Config Class Initialized
INFO - 2021-04-12 15:28:28 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:28 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:28 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:28 --> URI Class Initialized
INFO - 2021-04-12 15:28:28 --> Router Class Initialized
INFO - 2021-04-12 15:28:28 --> Output Class Initialized
INFO - 2021-04-12 15:28:28 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:28 --> Input Class Initialized
INFO - 2021-04-12 15:28:28 --> Language Class Initialized
INFO - 2021-04-12 15:28:28 --> Language Class Initialized
INFO - 2021-04-12 15:28:28 --> Config Class Initialized
INFO - 2021-04-12 15:28:28 --> Loader Class Initialized
INFO - 2021-04-12 15:28:28 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:28 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:28 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:28 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:28 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:28 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-04-12 15:28:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:28 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:28 --> Total execution time: 0.1859
INFO - 2021-04-12 15:28:28 --> Config Class Initialized
INFO - 2021-04-12 15:28:28 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:28 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:28 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:28 --> URI Class Initialized
INFO - 2021-04-12 15:28:28 --> Router Class Initialized
INFO - 2021-04-12 15:28:28 --> Output Class Initialized
INFO - 2021-04-12 15:28:28 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:28 --> Input Class Initialized
INFO - 2021-04-12 15:28:28 --> Language Class Initialized
INFO - 2021-04-12 15:28:28 --> Language Class Initialized
INFO - 2021-04-12 15:28:28 --> Config Class Initialized
INFO - 2021-04-12 15:28:28 --> Loader Class Initialized
INFO - 2021-04-12 15:28:28 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:28 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:28 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:28 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:28 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:28 --> Controller Class Initialized
INFO - 2021-04-12 15:28:29 --> Config Class Initialized
INFO - 2021-04-12 15:28:29 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:29 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:29 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:29 --> URI Class Initialized
INFO - 2021-04-12 15:28:29 --> Router Class Initialized
INFO - 2021-04-12 15:28:29 --> Output Class Initialized
INFO - 2021-04-12 15:28:29 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:29 --> Input Class Initialized
INFO - 2021-04-12 15:28:29 --> Language Class Initialized
INFO - 2021-04-12 15:28:29 --> Language Class Initialized
INFO - 2021-04-12 15:28:29 --> Config Class Initialized
INFO - 2021-04-12 15:28:30 --> Loader Class Initialized
INFO - 2021-04-12 15:28:30 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:30 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:30 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:30 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:30 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:30 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-04-12 15:28:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:30 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:30 --> Total execution time: 0.1432
INFO - 2021-04-12 15:28:30 --> Config Class Initialized
INFO - 2021-04-12 15:28:30 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:30 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:30 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:30 --> URI Class Initialized
INFO - 2021-04-12 15:28:30 --> Router Class Initialized
INFO - 2021-04-12 15:28:30 --> Output Class Initialized
INFO - 2021-04-12 15:28:30 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:30 --> Input Class Initialized
INFO - 2021-04-12 15:28:30 --> Language Class Initialized
INFO - 2021-04-12 15:28:30 --> Language Class Initialized
INFO - 2021-04-12 15:28:30 --> Config Class Initialized
INFO - 2021-04-12 15:28:30 --> Loader Class Initialized
INFO - 2021-04-12 15:28:30 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:30 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:30 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:30 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:30 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:30 --> Controller Class Initialized
INFO - 2021-04-12 15:28:31 --> Config Class Initialized
INFO - 2021-04-12 15:28:31 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:31 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:31 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:31 --> URI Class Initialized
INFO - 2021-04-12 15:28:31 --> Router Class Initialized
INFO - 2021-04-12 15:28:31 --> Output Class Initialized
INFO - 2021-04-12 15:28:31 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:31 --> Input Class Initialized
INFO - 2021-04-12 15:28:31 --> Language Class Initialized
INFO - 2021-04-12 15:28:31 --> Language Class Initialized
INFO - 2021-04-12 15:28:31 --> Config Class Initialized
INFO - 2021-04-12 15:28:31 --> Loader Class Initialized
INFO - 2021-04-12 15:28:31 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:31 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:31 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:31 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:31 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:31 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-12 15:28:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:31 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:31 --> Total execution time: 0.2234
INFO - 2021-04-12 15:28:31 --> Config Class Initialized
INFO - 2021-04-12 15:28:31 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:31 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:31 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:31 --> URI Class Initialized
INFO - 2021-04-12 15:28:31 --> Router Class Initialized
INFO - 2021-04-12 15:28:31 --> Output Class Initialized
INFO - 2021-04-12 15:28:31 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:31 --> Input Class Initialized
INFO - 2021-04-12 15:28:31 --> Language Class Initialized
INFO - 2021-04-12 15:28:31 --> Language Class Initialized
INFO - 2021-04-12 15:28:31 --> Config Class Initialized
INFO - 2021-04-12 15:28:32 --> Loader Class Initialized
INFO - 2021-04-12 15:28:32 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:32 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:32 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:32 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:32 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:32 --> Controller Class Initialized
INFO - 2021-04-12 15:28:33 --> Config Class Initialized
INFO - 2021-04-12 15:28:33 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:33 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:33 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:33 --> URI Class Initialized
INFO - 2021-04-12 15:28:33 --> Router Class Initialized
INFO - 2021-04-12 15:28:33 --> Output Class Initialized
INFO - 2021-04-12 15:28:33 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:33 --> Input Class Initialized
INFO - 2021-04-12 15:28:33 --> Language Class Initialized
INFO - 2021-04-12 15:28:33 --> Language Class Initialized
INFO - 2021-04-12 15:28:33 --> Config Class Initialized
INFO - 2021-04-12 15:28:33 --> Loader Class Initialized
INFO - 2021-04-12 15:28:33 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:33 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:33 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:33 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:33 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:33 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:33 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:33 --> Total execution time: 0.1200
INFO - 2021-04-12 15:28:34 --> Config Class Initialized
INFO - 2021-04-12 15:28:34 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:34 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:34 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:34 --> URI Class Initialized
INFO - 2021-04-12 15:28:34 --> Router Class Initialized
INFO - 2021-04-12 15:28:34 --> Output Class Initialized
INFO - 2021-04-12 15:28:34 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:34 --> Input Class Initialized
INFO - 2021-04-12 15:28:34 --> Language Class Initialized
INFO - 2021-04-12 15:28:35 --> Language Class Initialized
INFO - 2021-04-12 15:28:35 --> Config Class Initialized
INFO - 2021-04-12 15:28:35 --> Loader Class Initialized
INFO - 2021-04-12 15:28:35 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:35 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:35 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:35 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:35 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:35 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-12 15:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:35 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:35 --> Total execution time: 0.1420
INFO - 2021-04-12 15:28:35 --> Config Class Initialized
INFO - 2021-04-12 15:28:35 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:35 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:35 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:35 --> URI Class Initialized
INFO - 2021-04-12 15:28:35 --> Router Class Initialized
INFO - 2021-04-12 15:28:35 --> Output Class Initialized
INFO - 2021-04-12 15:28:35 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:35 --> Input Class Initialized
INFO - 2021-04-12 15:28:35 --> Language Class Initialized
INFO - 2021-04-12 15:28:35 --> Language Class Initialized
INFO - 2021-04-12 15:28:35 --> Config Class Initialized
INFO - 2021-04-12 15:28:35 --> Loader Class Initialized
INFO - 2021-04-12 15:28:35 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:35 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:35 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:35 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:35 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:35 --> Controller Class Initialized
INFO - 2021-04-12 15:28:38 --> Config Class Initialized
INFO - 2021-04-12 15:28:38 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:38 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:38 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:38 --> URI Class Initialized
INFO - 2021-04-12 15:28:38 --> Router Class Initialized
INFO - 2021-04-12 15:28:38 --> Output Class Initialized
INFO - 2021-04-12 15:28:38 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:38 --> Input Class Initialized
INFO - 2021-04-12 15:28:38 --> Language Class Initialized
INFO - 2021-04-12 15:28:38 --> Language Class Initialized
INFO - 2021-04-12 15:28:38 --> Config Class Initialized
INFO - 2021-04-12 15:28:38 --> Loader Class Initialized
INFO - 2021-04-12 15:28:38 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:38 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:38 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:38 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:38 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:38 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-12 15:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:38 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:38 --> Total execution time: 0.1220
INFO - 2021-04-12 15:28:38 --> Config Class Initialized
INFO - 2021-04-12 15:28:38 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:38 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:38 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:38 --> URI Class Initialized
INFO - 2021-04-12 15:28:38 --> Router Class Initialized
INFO - 2021-04-12 15:28:38 --> Output Class Initialized
INFO - 2021-04-12 15:28:38 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:38 --> Input Class Initialized
INFO - 2021-04-12 15:28:38 --> Language Class Initialized
INFO - 2021-04-12 15:28:38 --> Language Class Initialized
INFO - 2021-04-12 15:28:38 --> Config Class Initialized
INFO - 2021-04-12 15:28:38 --> Loader Class Initialized
INFO - 2021-04-12 15:28:38 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:38 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:38 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:38 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:38 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:38 --> Controller Class Initialized
INFO - 2021-04-12 15:28:40 --> Config Class Initialized
INFO - 2021-04-12 15:28:40 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:40 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:40 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:40 --> URI Class Initialized
INFO - 2021-04-12 15:28:40 --> Router Class Initialized
INFO - 2021-04-12 15:28:40 --> Output Class Initialized
INFO - 2021-04-12 15:28:40 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:40 --> Input Class Initialized
INFO - 2021-04-12 15:28:40 --> Language Class Initialized
INFO - 2021-04-12 15:28:40 --> Language Class Initialized
INFO - 2021-04-12 15:28:40 --> Config Class Initialized
INFO - 2021-04-12 15:28:40 --> Loader Class Initialized
INFO - 2021-04-12 15:28:40 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:40 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:40 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:40 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:40 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:40 --> Controller Class Initialized
INFO - 2021-04-12 15:28:40 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:40 --> Total execution time: 0.1160
INFO - 2021-04-12 15:28:48 --> Config Class Initialized
INFO - 2021-04-12 15:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:48 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:48 --> URI Class Initialized
INFO - 2021-04-12 15:28:48 --> Router Class Initialized
INFO - 2021-04-12 15:28:48 --> Output Class Initialized
INFO - 2021-04-12 15:28:48 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:48 --> Input Class Initialized
INFO - 2021-04-12 15:28:48 --> Language Class Initialized
INFO - 2021-04-12 15:28:48 --> Language Class Initialized
INFO - 2021-04-12 15:28:48 --> Config Class Initialized
INFO - 2021-04-12 15:28:48 --> Loader Class Initialized
INFO - 2021-04-12 15:28:48 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:48 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:48 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:48 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:48 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:48 --> Controller Class Initialized
INFO - 2021-04-12 15:28:48 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:48 --> Total execution time: 0.1335
INFO - 2021-04-12 15:28:48 --> Config Class Initialized
INFO - 2021-04-12 15:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:48 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:49 --> URI Class Initialized
INFO - 2021-04-12 15:28:49 --> Router Class Initialized
INFO - 2021-04-12 15:28:49 --> Output Class Initialized
INFO - 2021-04-12 15:28:49 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:49 --> Input Class Initialized
INFO - 2021-04-12 15:28:49 --> Language Class Initialized
INFO - 2021-04-12 15:28:49 --> Language Class Initialized
INFO - 2021-04-12 15:28:49 --> Config Class Initialized
INFO - 2021-04-12 15:28:49 --> Loader Class Initialized
INFO - 2021-04-12 15:28:49 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:49 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:49 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:49 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:49 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:49 --> Controller Class Initialized
INFO - 2021-04-12 15:28:56 --> Config Class Initialized
INFO - 2021-04-12 15:28:56 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:56 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:56 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:56 --> URI Class Initialized
INFO - 2021-04-12 15:28:56 --> Router Class Initialized
INFO - 2021-04-12 15:28:56 --> Output Class Initialized
INFO - 2021-04-12 15:28:56 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:56 --> Input Class Initialized
INFO - 2021-04-12 15:28:56 --> Language Class Initialized
INFO - 2021-04-12 15:28:56 --> Language Class Initialized
INFO - 2021-04-12 15:28:56 --> Config Class Initialized
INFO - 2021-04-12 15:28:56 --> Loader Class Initialized
INFO - 2021-04-12 15:28:56 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:56 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:56 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:56 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:56 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:56 --> Controller Class Initialized
INFO - 2021-04-12 15:28:56 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:56 --> Total execution time: 0.1695
INFO - 2021-04-12 15:28:56 --> Config Class Initialized
INFO - 2021-04-12 15:28:56 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:56 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:56 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:56 --> URI Class Initialized
INFO - 2021-04-12 15:28:56 --> Router Class Initialized
INFO - 2021-04-12 15:28:56 --> Output Class Initialized
INFO - 2021-04-12 15:28:57 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:57 --> Input Class Initialized
INFO - 2021-04-12 15:28:57 --> Language Class Initialized
INFO - 2021-04-12 15:28:57 --> Language Class Initialized
INFO - 2021-04-12 15:28:57 --> Config Class Initialized
INFO - 2021-04-12 15:28:57 --> Loader Class Initialized
INFO - 2021-04-12 15:28:57 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:57 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:57 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:57 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:57 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:57 --> Controller Class Initialized
INFO - 2021-04-12 15:28:59 --> Config Class Initialized
INFO - 2021-04-12 15:28:59 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:59 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:59 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:59 --> URI Class Initialized
INFO - 2021-04-12 15:28:59 --> Router Class Initialized
INFO - 2021-04-12 15:28:59 --> Output Class Initialized
INFO - 2021-04-12 15:28:59 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:59 --> Input Class Initialized
INFO - 2021-04-12 15:28:59 --> Language Class Initialized
INFO - 2021-04-12 15:28:59 --> Language Class Initialized
INFO - 2021-04-12 15:28:59 --> Config Class Initialized
INFO - 2021-04-12 15:28:59 --> Loader Class Initialized
INFO - 2021-04-12 15:28:59 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:59 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:59 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:59 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:59 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:59 --> Controller Class Initialized
DEBUG - 2021-04-12 15:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-12 15:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:28:59 --> Final output sent to browser
DEBUG - 2021-04-12 15:28:59 --> Total execution time: 0.1489
INFO - 2021-04-12 15:28:59 --> Config Class Initialized
INFO - 2021-04-12 15:28:59 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:28:59 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:28:59 --> Utf8 Class Initialized
INFO - 2021-04-12 15:28:59 --> URI Class Initialized
INFO - 2021-04-12 15:28:59 --> Router Class Initialized
INFO - 2021-04-12 15:28:59 --> Output Class Initialized
INFO - 2021-04-12 15:28:59 --> Security Class Initialized
DEBUG - 2021-04-12 15:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:28:59 --> Input Class Initialized
INFO - 2021-04-12 15:28:59 --> Language Class Initialized
INFO - 2021-04-12 15:28:59 --> Language Class Initialized
INFO - 2021-04-12 15:28:59 --> Config Class Initialized
INFO - 2021-04-12 15:28:59 --> Loader Class Initialized
INFO - 2021-04-12 15:28:59 --> Helper loaded: url_helper
INFO - 2021-04-12 15:28:59 --> Helper loaded: file_helper
INFO - 2021-04-12 15:28:59 --> Helper loaded: form_helper
INFO - 2021-04-12 15:28:59 --> Helper loaded: my_helper
INFO - 2021-04-12 15:28:59 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:28:59 --> Controller Class Initialized
INFO - 2021-04-12 15:29:00 --> Config Class Initialized
INFO - 2021-04-12 15:29:00 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:00 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:00 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:00 --> URI Class Initialized
INFO - 2021-04-12 15:29:00 --> Router Class Initialized
INFO - 2021-04-12 15:29:00 --> Output Class Initialized
INFO - 2021-04-12 15:29:00 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:00 --> Input Class Initialized
INFO - 2021-04-12 15:29:00 --> Language Class Initialized
INFO - 2021-04-12 15:29:00 --> Language Class Initialized
INFO - 2021-04-12 15:29:00 --> Config Class Initialized
INFO - 2021-04-12 15:29:00 --> Loader Class Initialized
INFO - 2021-04-12 15:29:01 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:01 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:01 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:01 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:01 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:01 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-04-12 15:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:01 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:01 --> Total execution time: 0.1279
INFO - 2021-04-12 15:29:11 --> Config Class Initialized
INFO - 2021-04-12 15:29:11 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:11 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:11 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:11 --> URI Class Initialized
INFO - 2021-04-12 15:29:11 --> Router Class Initialized
INFO - 2021-04-12 15:29:11 --> Output Class Initialized
INFO - 2021-04-12 15:29:11 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:11 --> Input Class Initialized
INFO - 2021-04-12 15:29:11 --> Language Class Initialized
INFO - 2021-04-12 15:29:11 --> Language Class Initialized
INFO - 2021-04-12 15:29:11 --> Config Class Initialized
INFO - 2021-04-12 15:29:11 --> Loader Class Initialized
INFO - 2021-04-12 15:29:11 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:11 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:11 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:11 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:11 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:11 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-04-12 15:29:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:11 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:11 --> Total execution time: 0.1441
INFO - 2021-04-12 15:29:11 --> Config Class Initialized
INFO - 2021-04-12 15:29:11 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:11 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:11 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:11 --> URI Class Initialized
INFO - 2021-04-12 15:29:11 --> Router Class Initialized
INFO - 2021-04-12 15:29:11 --> Output Class Initialized
INFO - 2021-04-12 15:29:11 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:11 --> Input Class Initialized
INFO - 2021-04-12 15:29:11 --> Language Class Initialized
INFO - 2021-04-12 15:29:11 --> Language Class Initialized
INFO - 2021-04-12 15:29:11 --> Config Class Initialized
INFO - 2021-04-12 15:29:11 --> Loader Class Initialized
INFO - 2021-04-12 15:29:11 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:11 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:11 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:11 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:11 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:11 --> Controller Class Initialized
INFO - 2021-04-12 15:29:16 --> Config Class Initialized
INFO - 2021-04-12 15:29:16 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:16 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:16 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:16 --> URI Class Initialized
INFO - 2021-04-12 15:29:16 --> Router Class Initialized
INFO - 2021-04-12 15:29:16 --> Output Class Initialized
INFO - 2021-04-12 15:29:16 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:16 --> Input Class Initialized
INFO - 2021-04-12 15:29:16 --> Language Class Initialized
INFO - 2021-04-12 15:29:16 --> Language Class Initialized
INFO - 2021-04-12 15:29:16 --> Config Class Initialized
INFO - 2021-04-12 15:29:16 --> Loader Class Initialized
INFO - 2021-04-12 15:29:16 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:16 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:16 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:16 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:16 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:16 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-04-12 15:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:16 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:16 --> Total execution time: 0.1336
INFO - 2021-04-12 15:29:16 --> Config Class Initialized
INFO - 2021-04-12 15:29:16 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:16 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:16 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:16 --> URI Class Initialized
INFO - 2021-04-12 15:29:16 --> Router Class Initialized
INFO - 2021-04-12 15:29:16 --> Output Class Initialized
INFO - 2021-04-12 15:29:16 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:16 --> Input Class Initialized
INFO - 2021-04-12 15:29:16 --> Language Class Initialized
INFO - 2021-04-12 15:29:16 --> Language Class Initialized
INFO - 2021-04-12 15:29:16 --> Config Class Initialized
INFO - 2021-04-12 15:29:16 --> Loader Class Initialized
INFO - 2021-04-12 15:29:16 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:16 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:16 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:16 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:16 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:16 --> Controller Class Initialized
INFO - 2021-04-12 15:29:20 --> Config Class Initialized
INFO - 2021-04-12 15:29:20 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:20 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:20 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:20 --> URI Class Initialized
INFO - 2021-04-12 15:29:20 --> Router Class Initialized
INFO - 2021-04-12 15:29:20 --> Output Class Initialized
INFO - 2021-04-12 15:29:20 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:20 --> Input Class Initialized
INFO - 2021-04-12 15:29:20 --> Language Class Initialized
INFO - 2021-04-12 15:29:20 --> Language Class Initialized
INFO - 2021-04-12 15:29:20 --> Config Class Initialized
INFO - 2021-04-12 15:29:20 --> Loader Class Initialized
INFO - 2021-04-12 15:29:20 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:20 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:20 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:20 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:20 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:20 --> Controller Class Initialized
INFO - 2021-04-12 15:29:20 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:20 --> Total execution time: 0.1283
INFO - 2021-04-12 15:29:35 --> Config Class Initialized
INFO - 2021-04-12 15:29:35 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:35 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:35 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:35 --> URI Class Initialized
INFO - 2021-04-12 15:29:35 --> Router Class Initialized
INFO - 2021-04-12 15:29:35 --> Output Class Initialized
INFO - 2021-04-12 15:29:35 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:35 --> Input Class Initialized
INFO - 2021-04-12 15:29:35 --> Language Class Initialized
INFO - 2021-04-12 15:29:35 --> Language Class Initialized
INFO - 2021-04-12 15:29:35 --> Config Class Initialized
INFO - 2021-04-12 15:29:35 --> Loader Class Initialized
INFO - 2021-04-12 15:29:35 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:35 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:35 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:35 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:35 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:35 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:35 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:35 --> Total execution time: 0.1235
INFO - 2021-04-12 15:29:36 --> Config Class Initialized
INFO - 2021-04-12 15:29:36 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:36 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:36 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:36 --> URI Class Initialized
INFO - 2021-04-12 15:29:36 --> Router Class Initialized
INFO - 2021-04-12 15:29:36 --> Output Class Initialized
INFO - 2021-04-12 15:29:36 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:36 --> Input Class Initialized
INFO - 2021-04-12 15:29:36 --> Language Class Initialized
INFO - 2021-04-12 15:29:36 --> Language Class Initialized
INFO - 2021-04-12 15:29:36 --> Config Class Initialized
INFO - 2021-04-12 15:29:36 --> Loader Class Initialized
INFO - 2021-04-12 15:29:36 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:36 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:36 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:36 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:36 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:36 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:36 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:36 --> Total execution time: 0.1276
INFO - 2021-04-12 15:29:40 --> Config Class Initialized
INFO - 2021-04-12 15:29:40 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:40 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:40 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:40 --> URI Class Initialized
INFO - 2021-04-12 15:29:40 --> Router Class Initialized
INFO - 2021-04-12 15:29:40 --> Output Class Initialized
INFO - 2021-04-12 15:29:40 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:40 --> Input Class Initialized
INFO - 2021-04-12 15:29:40 --> Language Class Initialized
INFO - 2021-04-12 15:29:40 --> Language Class Initialized
INFO - 2021-04-12 15:29:40 --> Config Class Initialized
INFO - 2021-04-12 15:29:40 --> Loader Class Initialized
INFO - 2021-04-12 15:29:40 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:40 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:40 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:40 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:40 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:40 --> Controller Class Initialized
INFO - 2021-04-12 15:29:40 --> Config Class Initialized
INFO - 2021-04-12 15:29:40 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:40 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:40 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:40 --> URI Class Initialized
INFO - 2021-04-12 15:29:40 --> Router Class Initialized
INFO - 2021-04-12 15:29:40 --> Output Class Initialized
INFO - 2021-04-12 15:29:40 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:40 --> Input Class Initialized
INFO - 2021-04-12 15:29:40 --> Language Class Initialized
INFO - 2021-04-12 15:29:40 --> Language Class Initialized
INFO - 2021-04-12 15:29:40 --> Config Class Initialized
INFO - 2021-04-12 15:29:40 --> Loader Class Initialized
INFO - 2021-04-12 15:29:40 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:40 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:40 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:40 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:40 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:40 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:40 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:40 --> Total execution time: 0.1689
INFO - 2021-04-12 15:29:41 --> Config Class Initialized
INFO - 2021-04-12 15:29:41 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:41 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:41 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:41 --> URI Class Initialized
INFO - 2021-04-12 15:29:41 --> Router Class Initialized
INFO - 2021-04-12 15:29:41 --> Output Class Initialized
INFO - 2021-04-12 15:29:41 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:41 --> Input Class Initialized
INFO - 2021-04-12 15:29:41 --> Language Class Initialized
INFO - 2021-04-12 15:29:41 --> Language Class Initialized
INFO - 2021-04-12 15:29:41 --> Config Class Initialized
INFO - 2021-04-12 15:29:41 --> Loader Class Initialized
INFO - 2021-04-12 15:29:41 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:41 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:41 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:41 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:41 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:41 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:41 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:41 --> Total execution time: 0.1433
INFO - 2021-04-12 15:29:45 --> Config Class Initialized
INFO - 2021-04-12 15:29:45 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:45 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:45 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:45 --> URI Class Initialized
INFO - 2021-04-12 15:29:45 --> Router Class Initialized
INFO - 2021-04-12 15:29:45 --> Output Class Initialized
INFO - 2021-04-12 15:29:45 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:45 --> Input Class Initialized
INFO - 2021-04-12 15:29:45 --> Language Class Initialized
INFO - 2021-04-12 15:29:45 --> Language Class Initialized
INFO - 2021-04-12 15:29:45 --> Config Class Initialized
INFO - 2021-04-12 15:29:45 --> Loader Class Initialized
INFO - 2021-04-12 15:29:45 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:45 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:45 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:45 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:45 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:45 --> Controller Class Initialized
INFO - 2021-04-12 15:29:45 --> Config Class Initialized
INFO - 2021-04-12 15:29:45 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:29:45 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:29:45 --> Utf8 Class Initialized
INFO - 2021-04-12 15:29:45 --> URI Class Initialized
INFO - 2021-04-12 15:29:45 --> Router Class Initialized
INFO - 2021-04-12 15:29:45 --> Output Class Initialized
INFO - 2021-04-12 15:29:45 --> Security Class Initialized
DEBUG - 2021-04-12 15:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:29:45 --> Input Class Initialized
INFO - 2021-04-12 15:29:45 --> Language Class Initialized
INFO - 2021-04-12 15:29:46 --> Language Class Initialized
INFO - 2021-04-12 15:29:46 --> Config Class Initialized
INFO - 2021-04-12 15:29:46 --> Loader Class Initialized
INFO - 2021-04-12 15:29:46 --> Helper loaded: url_helper
INFO - 2021-04-12 15:29:46 --> Helper loaded: file_helper
INFO - 2021-04-12 15:29:46 --> Helper loaded: form_helper
INFO - 2021-04-12 15:29:46 --> Helper loaded: my_helper
INFO - 2021-04-12 15:29:46 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:29:46 --> Controller Class Initialized
DEBUG - 2021-04-12 15:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:29:46 --> Final output sent to browser
DEBUG - 2021-04-12 15:29:46 --> Total execution time: 0.1527
INFO - 2021-04-12 15:35:27 --> Config Class Initialized
INFO - 2021-04-12 15:35:27 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:35:27 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:35:27 --> Utf8 Class Initialized
INFO - 2021-04-12 15:35:27 --> URI Class Initialized
INFO - 2021-04-12 15:35:27 --> Router Class Initialized
INFO - 2021-04-12 15:35:27 --> Output Class Initialized
INFO - 2021-04-12 15:35:27 --> Security Class Initialized
DEBUG - 2021-04-12 15:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:35:27 --> Input Class Initialized
INFO - 2021-04-12 15:35:27 --> Language Class Initialized
INFO - 2021-04-12 15:35:27 --> Language Class Initialized
INFO - 2021-04-12 15:35:27 --> Config Class Initialized
INFO - 2021-04-12 15:35:27 --> Loader Class Initialized
INFO - 2021-04-12 15:35:27 --> Helper loaded: url_helper
INFO - 2021-04-12 15:35:27 --> Helper loaded: file_helper
INFO - 2021-04-12 15:35:27 --> Helper loaded: form_helper
INFO - 2021-04-12 15:35:27 --> Helper loaded: my_helper
INFO - 2021-04-12 15:35:27 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:35:27 --> Controller Class Initialized
DEBUG - 2021-04-12 15:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:35:27 --> Final output sent to browser
DEBUG - 2021-04-12 15:35:27 --> Total execution time: 0.1967
INFO - 2021-04-12 15:35:32 --> Config Class Initialized
INFO - 2021-04-12 15:35:32 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:35:32 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:35:32 --> Utf8 Class Initialized
INFO - 2021-04-12 15:35:32 --> URI Class Initialized
INFO - 2021-04-12 15:35:32 --> Router Class Initialized
INFO - 2021-04-12 15:35:32 --> Output Class Initialized
INFO - 2021-04-12 15:35:32 --> Security Class Initialized
DEBUG - 2021-04-12 15:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:35:32 --> Input Class Initialized
INFO - 2021-04-12 15:35:32 --> Language Class Initialized
INFO - 2021-04-12 15:35:32 --> Language Class Initialized
INFO - 2021-04-12 15:35:32 --> Config Class Initialized
INFO - 2021-04-12 15:35:32 --> Loader Class Initialized
INFO - 2021-04-12 15:35:32 --> Helper loaded: url_helper
INFO - 2021-04-12 15:35:32 --> Helper loaded: file_helper
INFO - 2021-04-12 15:35:32 --> Helper loaded: form_helper
INFO - 2021-04-12 15:35:32 --> Helper loaded: my_helper
INFO - 2021-04-12 15:35:32 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:35:32 --> Controller Class Initialized
INFO - 2021-04-12 15:35:32 --> Config Class Initialized
INFO - 2021-04-12 15:35:32 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:35:32 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:35:32 --> Utf8 Class Initialized
INFO - 2021-04-12 15:35:32 --> URI Class Initialized
INFO - 2021-04-12 15:35:32 --> Router Class Initialized
INFO - 2021-04-12 15:35:32 --> Output Class Initialized
INFO - 2021-04-12 15:35:32 --> Security Class Initialized
DEBUG - 2021-04-12 15:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:35:32 --> Input Class Initialized
INFO - 2021-04-12 15:35:32 --> Language Class Initialized
INFO - 2021-04-12 15:35:32 --> Language Class Initialized
INFO - 2021-04-12 15:35:32 --> Config Class Initialized
INFO - 2021-04-12 15:35:32 --> Loader Class Initialized
INFO - 2021-04-12 15:35:32 --> Helper loaded: url_helper
INFO - 2021-04-12 15:35:32 --> Helper loaded: file_helper
INFO - 2021-04-12 15:35:32 --> Helper loaded: form_helper
INFO - 2021-04-12 15:35:32 --> Helper loaded: my_helper
INFO - 2021-04-12 15:35:32 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:35:32 --> Controller Class Initialized
DEBUG - 2021-04-12 15:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:35:32 --> Final output sent to browser
DEBUG - 2021-04-12 15:35:32 --> Total execution time: 0.1548
INFO - 2021-04-12 15:43:47 --> Config Class Initialized
INFO - 2021-04-12 15:43:47 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:43:47 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:43:47 --> Utf8 Class Initialized
INFO - 2021-04-12 15:43:47 --> URI Class Initialized
INFO - 2021-04-12 15:43:47 --> Router Class Initialized
INFO - 2021-04-12 15:43:47 --> Output Class Initialized
INFO - 2021-04-12 15:43:47 --> Security Class Initialized
DEBUG - 2021-04-12 15:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:43:47 --> Input Class Initialized
INFO - 2021-04-12 15:43:47 --> Language Class Initialized
INFO - 2021-04-12 15:43:47 --> Language Class Initialized
INFO - 2021-04-12 15:43:47 --> Config Class Initialized
INFO - 2021-04-12 15:43:47 --> Loader Class Initialized
INFO - 2021-04-12 15:43:47 --> Helper loaded: url_helper
INFO - 2021-04-12 15:43:47 --> Helper loaded: file_helper
INFO - 2021-04-12 15:43:47 --> Helper loaded: form_helper
INFO - 2021-04-12 15:43:47 --> Helper loaded: my_helper
INFO - 2021-04-12 15:43:47 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:43:47 --> Controller Class Initialized
DEBUG - 2021-04-12 15:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:43:47 --> Final output sent to browser
DEBUG - 2021-04-12 15:43:47 --> Total execution time: 0.1183
INFO - 2021-04-12 15:43:48 --> Config Class Initialized
INFO - 2021-04-12 15:43:48 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:43:48 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:43:48 --> Utf8 Class Initialized
INFO - 2021-04-12 15:43:48 --> URI Class Initialized
INFO - 2021-04-12 15:43:48 --> Router Class Initialized
INFO - 2021-04-12 15:43:48 --> Output Class Initialized
INFO - 2021-04-12 15:43:48 --> Security Class Initialized
DEBUG - 2021-04-12 15:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:43:48 --> Input Class Initialized
INFO - 2021-04-12 15:43:48 --> Language Class Initialized
INFO - 2021-04-12 15:43:48 --> Language Class Initialized
INFO - 2021-04-12 15:43:48 --> Config Class Initialized
INFO - 2021-04-12 15:43:48 --> Loader Class Initialized
INFO - 2021-04-12 15:43:48 --> Helper loaded: url_helper
INFO - 2021-04-12 15:43:48 --> Helper loaded: file_helper
INFO - 2021-04-12 15:43:48 --> Helper loaded: form_helper
INFO - 2021-04-12 15:43:48 --> Helper loaded: my_helper
INFO - 2021-04-12 15:43:48 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:43:48 --> Controller Class Initialized
DEBUG - 2021-04-12 15:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:43:48 --> Final output sent to browser
DEBUG - 2021-04-12 15:43:48 --> Total execution time: 0.1337
INFO - 2021-04-12 15:43:55 --> Config Class Initialized
INFO - 2021-04-12 15:43:55 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:43:55 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:43:55 --> Utf8 Class Initialized
INFO - 2021-04-12 15:43:55 --> URI Class Initialized
INFO - 2021-04-12 15:43:55 --> Router Class Initialized
INFO - 2021-04-12 15:43:55 --> Output Class Initialized
INFO - 2021-04-12 15:43:55 --> Security Class Initialized
DEBUG - 2021-04-12 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:43:55 --> Input Class Initialized
INFO - 2021-04-12 15:43:55 --> Language Class Initialized
INFO - 2021-04-12 15:43:55 --> Language Class Initialized
INFO - 2021-04-12 15:43:55 --> Config Class Initialized
INFO - 2021-04-12 15:43:55 --> Loader Class Initialized
INFO - 2021-04-12 15:43:55 --> Helper loaded: url_helper
INFO - 2021-04-12 15:43:55 --> Helper loaded: file_helper
INFO - 2021-04-12 15:43:55 --> Helper loaded: form_helper
INFO - 2021-04-12 15:43:55 --> Helper loaded: my_helper
INFO - 2021-04-12 15:43:55 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:43:55 --> Controller Class Initialized
INFO - 2021-04-12 15:43:55 --> Config Class Initialized
INFO - 2021-04-12 15:43:55 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:43:55 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:43:55 --> Utf8 Class Initialized
INFO - 2021-04-12 15:43:55 --> URI Class Initialized
INFO - 2021-04-12 15:43:55 --> Router Class Initialized
INFO - 2021-04-12 15:43:55 --> Output Class Initialized
INFO - 2021-04-12 15:43:55 --> Security Class Initialized
DEBUG - 2021-04-12 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:43:55 --> Input Class Initialized
INFO - 2021-04-12 15:43:55 --> Language Class Initialized
INFO - 2021-04-12 15:43:55 --> Language Class Initialized
INFO - 2021-04-12 15:43:55 --> Config Class Initialized
INFO - 2021-04-12 15:43:55 --> Loader Class Initialized
INFO - 2021-04-12 15:43:55 --> Helper loaded: url_helper
INFO - 2021-04-12 15:43:55 --> Helper loaded: file_helper
INFO - 2021-04-12 15:43:55 --> Helper loaded: form_helper
INFO - 2021-04-12 15:43:55 --> Helper loaded: my_helper
INFO - 2021-04-12 15:43:55 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:43:55 --> Controller Class Initialized
DEBUG - 2021-04-12 15:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:43:55 --> Final output sent to browser
DEBUG - 2021-04-12 15:43:55 --> Total execution time: 0.1621
INFO - 2021-04-12 15:45:14 --> Config Class Initialized
INFO - 2021-04-12 15:45:14 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:45:14 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:45:14 --> Utf8 Class Initialized
INFO - 2021-04-12 15:45:14 --> URI Class Initialized
INFO - 2021-04-12 15:45:14 --> Router Class Initialized
INFO - 2021-04-12 15:45:14 --> Output Class Initialized
INFO - 2021-04-12 15:45:14 --> Security Class Initialized
DEBUG - 2021-04-12 15:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:45:14 --> Input Class Initialized
INFO - 2021-04-12 15:45:14 --> Language Class Initialized
INFO - 2021-04-12 15:45:14 --> Language Class Initialized
INFO - 2021-04-12 15:45:14 --> Config Class Initialized
INFO - 2021-04-12 15:45:14 --> Loader Class Initialized
INFO - 2021-04-12 15:45:14 --> Helper loaded: url_helper
INFO - 2021-04-12 15:45:14 --> Helper loaded: file_helper
INFO - 2021-04-12 15:45:14 --> Helper loaded: form_helper
INFO - 2021-04-12 15:45:14 --> Helper loaded: my_helper
INFO - 2021-04-12 15:45:14 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:45:14 --> Controller Class Initialized
DEBUG - 2021-04-12 15:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:45:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:45:14 --> Final output sent to browser
DEBUG - 2021-04-12 15:45:14 --> Total execution time: 0.1185
INFO - 2021-04-12 15:45:15 --> Config Class Initialized
INFO - 2021-04-12 15:45:15 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:45:15 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:45:15 --> Utf8 Class Initialized
INFO - 2021-04-12 15:45:15 --> URI Class Initialized
INFO - 2021-04-12 15:45:15 --> Router Class Initialized
INFO - 2021-04-12 15:45:15 --> Output Class Initialized
INFO - 2021-04-12 15:45:15 --> Security Class Initialized
DEBUG - 2021-04-12 15:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:45:15 --> Input Class Initialized
INFO - 2021-04-12 15:45:15 --> Language Class Initialized
INFO - 2021-04-12 15:45:15 --> Language Class Initialized
INFO - 2021-04-12 15:45:15 --> Config Class Initialized
INFO - 2021-04-12 15:45:15 --> Loader Class Initialized
INFO - 2021-04-12 15:45:15 --> Helper loaded: url_helper
INFO - 2021-04-12 15:45:15 --> Helper loaded: file_helper
INFO - 2021-04-12 15:45:15 --> Helper loaded: form_helper
INFO - 2021-04-12 15:45:15 --> Helper loaded: my_helper
INFO - 2021-04-12 15:45:15 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:45:15 --> Controller Class Initialized
DEBUG - 2021-04-12 15:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:45:15 --> Final output sent to browser
DEBUG - 2021-04-12 15:45:15 --> Total execution time: 0.1362
INFO - 2021-04-12 15:45:20 --> Config Class Initialized
INFO - 2021-04-12 15:45:20 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:45:20 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:45:20 --> Utf8 Class Initialized
INFO - 2021-04-12 15:45:20 --> URI Class Initialized
INFO - 2021-04-12 15:45:20 --> Router Class Initialized
INFO - 2021-04-12 15:45:20 --> Output Class Initialized
INFO - 2021-04-12 15:45:20 --> Security Class Initialized
DEBUG - 2021-04-12 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:45:20 --> Input Class Initialized
INFO - 2021-04-12 15:45:20 --> Language Class Initialized
INFO - 2021-04-12 15:45:20 --> Language Class Initialized
INFO - 2021-04-12 15:45:20 --> Config Class Initialized
INFO - 2021-04-12 15:45:20 --> Loader Class Initialized
INFO - 2021-04-12 15:45:20 --> Helper loaded: url_helper
INFO - 2021-04-12 15:45:20 --> Helper loaded: file_helper
INFO - 2021-04-12 15:45:20 --> Helper loaded: form_helper
INFO - 2021-04-12 15:45:20 --> Helper loaded: my_helper
INFO - 2021-04-12 15:45:20 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:45:20 --> Controller Class Initialized
INFO - 2021-04-12 15:45:20 --> Config Class Initialized
INFO - 2021-04-12 15:45:20 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:45:20 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:45:20 --> Utf8 Class Initialized
INFO - 2021-04-12 15:45:20 --> URI Class Initialized
INFO - 2021-04-12 15:45:20 --> Router Class Initialized
INFO - 2021-04-12 15:45:20 --> Output Class Initialized
INFO - 2021-04-12 15:45:20 --> Security Class Initialized
DEBUG - 2021-04-12 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:45:20 --> Input Class Initialized
INFO - 2021-04-12 15:45:20 --> Language Class Initialized
INFO - 2021-04-12 15:45:20 --> Language Class Initialized
INFO - 2021-04-12 15:45:20 --> Config Class Initialized
INFO - 2021-04-12 15:45:20 --> Loader Class Initialized
INFO - 2021-04-12 15:45:20 --> Helper loaded: url_helper
INFO - 2021-04-12 15:45:20 --> Helper loaded: file_helper
INFO - 2021-04-12 15:45:20 --> Helper loaded: form_helper
INFO - 2021-04-12 15:45:20 --> Helper loaded: my_helper
INFO - 2021-04-12 15:45:20 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:45:20 --> Controller Class Initialized
DEBUG - 2021-04-12 15:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:45:20 --> Final output sent to browser
DEBUG - 2021-04-12 15:45:20 --> Total execution time: 0.1617
INFO - 2021-04-12 15:46:10 --> Config Class Initialized
INFO - 2021-04-12 15:46:10 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:46:10 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:46:10 --> Utf8 Class Initialized
INFO - 2021-04-12 15:46:10 --> URI Class Initialized
INFO - 2021-04-12 15:46:10 --> Router Class Initialized
INFO - 2021-04-12 15:46:10 --> Output Class Initialized
INFO - 2021-04-12 15:46:10 --> Security Class Initialized
DEBUG - 2021-04-12 15:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:46:10 --> Input Class Initialized
INFO - 2021-04-12 15:46:10 --> Language Class Initialized
INFO - 2021-04-12 15:46:10 --> Language Class Initialized
INFO - 2021-04-12 15:46:10 --> Config Class Initialized
INFO - 2021-04-12 15:46:10 --> Loader Class Initialized
INFO - 2021-04-12 15:46:10 --> Helper loaded: url_helper
INFO - 2021-04-12 15:46:10 --> Helper loaded: file_helper
INFO - 2021-04-12 15:46:10 --> Helper loaded: form_helper
INFO - 2021-04-12 15:46:10 --> Helper loaded: my_helper
INFO - 2021-04-12 15:46:10 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:46:10 --> Controller Class Initialized
DEBUG - 2021-04-12 15:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:46:10 --> Final output sent to browser
DEBUG - 2021-04-12 15:46:10 --> Total execution time: 0.1310
INFO - 2021-04-12 15:52:09 --> Config Class Initialized
INFO - 2021-04-12 15:52:09 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:52:09 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:52:09 --> Utf8 Class Initialized
INFO - 2021-04-12 15:52:09 --> URI Class Initialized
INFO - 2021-04-12 15:52:09 --> Router Class Initialized
INFO - 2021-04-12 15:52:09 --> Output Class Initialized
INFO - 2021-04-12 15:52:09 --> Security Class Initialized
DEBUG - 2021-04-12 15:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:52:09 --> Input Class Initialized
INFO - 2021-04-12 15:52:09 --> Language Class Initialized
INFO - 2021-04-12 15:52:09 --> Language Class Initialized
INFO - 2021-04-12 15:52:09 --> Config Class Initialized
INFO - 2021-04-12 15:52:09 --> Loader Class Initialized
INFO - 2021-04-12 15:52:09 --> Helper loaded: url_helper
INFO - 2021-04-12 15:52:09 --> Helper loaded: file_helper
INFO - 2021-04-12 15:52:09 --> Helper loaded: form_helper
INFO - 2021-04-12 15:52:09 --> Helper loaded: my_helper
INFO - 2021-04-12 15:52:09 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:52:09 --> Controller Class Initialized
DEBUG - 2021-04-12 15:52:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-12 15:52:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:52:09 --> Final output sent to browser
DEBUG - 2021-04-12 15:52:09 --> Total execution time: 0.1885
INFO - 2021-04-12 15:52:16 --> Config Class Initialized
INFO - 2021-04-12 15:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:52:17 --> Utf8 Class Initialized
INFO - 2021-04-12 15:52:17 --> URI Class Initialized
INFO - 2021-04-12 15:52:17 --> Router Class Initialized
INFO - 2021-04-12 15:52:17 --> Output Class Initialized
INFO - 2021-04-12 15:52:17 --> Security Class Initialized
DEBUG - 2021-04-12 15:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:52:17 --> Input Class Initialized
INFO - 2021-04-12 15:52:17 --> Language Class Initialized
INFO - 2021-04-12 15:52:17 --> Language Class Initialized
INFO - 2021-04-12 15:52:17 --> Config Class Initialized
INFO - 2021-04-12 15:52:17 --> Loader Class Initialized
INFO - 2021-04-12 15:52:17 --> Helper loaded: url_helper
INFO - 2021-04-12 15:52:17 --> Helper loaded: file_helper
INFO - 2021-04-12 15:52:17 --> Helper loaded: form_helper
INFO - 2021-04-12 15:52:17 --> Helper loaded: my_helper
INFO - 2021-04-12 15:52:17 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:52:17 --> Controller Class Initialized
INFO - 2021-04-12 15:52:17 --> Config Class Initialized
INFO - 2021-04-12 15:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-12 15:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-12 15:52:17 --> Utf8 Class Initialized
INFO - 2021-04-12 15:52:17 --> URI Class Initialized
INFO - 2021-04-12 15:52:17 --> Router Class Initialized
INFO - 2021-04-12 15:52:17 --> Output Class Initialized
INFO - 2021-04-12 15:52:17 --> Security Class Initialized
DEBUG - 2021-04-12 15:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-12 15:52:17 --> Input Class Initialized
INFO - 2021-04-12 15:52:17 --> Language Class Initialized
INFO - 2021-04-12 15:52:17 --> Language Class Initialized
INFO - 2021-04-12 15:52:17 --> Config Class Initialized
INFO - 2021-04-12 15:52:17 --> Loader Class Initialized
INFO - 2021-04-12 15:52:17 --> Helper loaded: url_helper
INFO - 2021-04-12 15:52:17 --> Helper loaded: file_helper
INFO - 2021-04-12 15:52:17 --> Helper loaded: form_helper
INFO - 2021-04-12 15:52:17 --> Helper loaded: my_helper
INFO - 2021-04-12 15:52:17 --> Database Driver Class Initialized
DEBUG - 2021-04-12 15:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-12 15:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-12 15:52:17 --> Controller Class Initialized
DEBUG - 2021-04-12 15:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-12 15:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-12 15:52:17 --> Final output sent to browser
DEBUG - 2021-04-12 15:52:17 --> Total execution time: 0.1842
