<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-03 09:36:30 --> Config Class Initialized
INFO - 2021-04-03 09:36:30 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:36:30 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:36:30 --> Utf8 Class Initialized
INFO - 2021-04-03 09:36:30 --> URI Class Initialized
DEBUG - 2021-04-03 09:36:30 --> No URI present. Default controller set.
INFO - 2021-04-03 09:36:30 --> Router Class Initialized
INFO - 2021-04-03 09:36:31 --> Output Class Initialized
INFO - 2021-04-03 09:36:31 --> Security Class Initialized
DEBUG - 2021-04-03 09:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:36:31 --> Input Class Initialized
INFO - 2021-04-03 09:36:31 --> Language Class Initialized
INFO - 2021-04-03 09:36:31 --> Language Class Initialized
INFO - 2021-04-03 09:36:31 --> Config Class Initialized
INFO - 2021-04-03 09:36:31 --> Loader Class Initialized
INFO - 2021-04-03 09:36:31 --> Helper loaded: url_helper
INFO - 2021-04-03 09:36:31 --> Helper loaded: file_helper
INFO - 2021-04-03 09:36:31 --> Helper loaded: form_helper
INFO - 2021-04-03 09:36:32 --> Helper loaded: my_helper
INFO - 2021-04-03 09:36:32 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:36:32 --> Controller Class Initialized
INFO - 2021-04-03 09:36:33 --> Config Class Initialized
INFO - 2021-04-03 09:36:33 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:36:33 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:36:33 --> Utf8 Class Initialized
INFO - 2021-04-03 09:36:33 --> URI Class Initialized
INFO - 2021-04-03 09:36:33 --> Router Class Initialized
INFO - 2021-04-03 09:36:33 --> Output Class Initialized
INFO - 2021-04-03 09:36:33 --> Security Class Initialized
DEBUG - 2021-04-03 09:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:36:33 --> Input Class Initialized
INFO - 2021-04-03 09:36:33 --> Language Class Initialized
INFO - 2021-04-03 09:36:33 --> Language Class Initialized
INFO - 2021-04-03 09:36:33 --> Config Class Initialized
INFO - 2021-04-03 09:36:33 --> Loader Class Initialized
INFO - 2021-04-03 09:36:33 --> Helper loaded: url_helper
INFO - 2021-04-03 09:36:33 --> Helper loaded: file_helper
INFO - 2021-04-03 09:36:33 --> Helper loaded: form_helper
INFO - 2021-04-03 09:36:33 --> Helper loaded: my_helper
INFO - 2021-04-03 09:36:33 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:36:33 --> Controller Class Initialized
DEBUG - 2021-04-03 09:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-04-03 09:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:36:33 --> Final output sent to browser
DEBUG - 2021-04-03 09:36:33 --> Total execution time: 0.9541
INFO - 2021-04-03 09:37:06 --> Config Class Initialized
INFO - 2021-04-03 09:37:06 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:37:06 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:37:06 --> Utf8 Class Initialized
INFO - 2021-04-03 09:37:06 --> URI Class Initialized
INFO - 2021-04-03 09:37:06 --> Router Class Initialized
INFO - 2021-04-03 09:37:06 --> Output Class Initialized
INFO - 2021-04-03 09:37:06 --> Security Class Initialized
DEBUG - 2021-04-03 09:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:37:06 --> Input Class Initialized
INFO - 2021-04-03 09:37:06 --> Language Class Initialized
INFO - 2021-04-03 09:37:07 --> Language Class Initialized
INFO - 2021-04-03 09:37:07 --> Config Class Initialized
INFO - 2021-04-03 09:37:07 --> Loader Class Initialized
INFO - 2021-04-03 09:37:07 --> Helper loaded: url_helper
INFO - 2021-04-03 09:37:07 --> Helper loaded: file_helper
INFO - 2021-04-03 09:37:07 --> Helper loaded: form_helper
INFO - 2021-04-03 09:37:07 --> Helper loaded: my_helper
INFO - 2021-04-03 09:37:07 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:37:07 --> Controller Class Initialized
INFO - 2021-04-03 09:37:07 --> Helper loaded: cookie_helper
INFO - 2021-04-03 09:37:07 --> Final output sent to browser
DEBUG - 2021-04-03 09:37:07 --> Total execution time: 0.8746
INFO - 2021-04-03 09:37:09 --> Config Class Initialized
INFO - 2021-04-03 09:37:09 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:37:09 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:37:09 --> Utf8 Class Initialized
INFO - 2021-04-03 09:37:09 --> URI Class Initialized
INFO - 2021-04-03 09:37:09 --> Router Class Initialized
INFO - 2021-04-03 09:37:09 --> Output Class Initialized
INFO - 2021-04-03 09:37:09 --> Security Class Initialized
DEBUG - 2021-04-03 09:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:37:09 --> Input Class Initialized
INFO - 2021-04-03 09:37:09 --> Language Class Initialized
INFO - 2021-04-03 09:37:09 --> Language Class Initialized
INFO - 2021-04-03 09:37:10 --> Config Class Initialized
INFO - 2021-04-03 09:37:10 --> Loader Class Initialized
INFO - 2021-04-03 09:37:10 --> Helper loaded: url_helper
INFO - 2021-04-03 09:37:10 --> Helper loaded: file_helper
INFO - 2021-04-03 09:37:10 --> Helper loaded: form_helper
INFO - 2021-04-03 09:37:10 --> Helper loaded: my_helper
INFO - 2021-04-03 09:37:10 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:37:10 --> Controller Class Initialized
DEBUG - 2021-04-03 09:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-04-03 09:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:37:11 --> Final output sent to browser
DEBUG - 2021-04-03 09:37:11 --> Total execution time: 1.4165
INFO - 2021-04-03 09:37:15 --> Config Class Initialized
INFO - 2021-04-03 09:37:15 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:37:15 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:37:15 --> Utf8 Class Initialized
INFO - 2021-04-03 09:37:15 --> URI Class Initialized
INFO - 2021-04-03 09:37:15 --> Router Class Initialized
INFO - 2021-04-03 09:37:15 --> Output Class Initialized
INFO - 2021-04-03 09:37:15 --> Security Class Initialized
DEBUG - 2021-04-03 09:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:37:15 --> Input Class Initialized
INFO - 2021-04-03 09:37:15 --> Language Class Initialized
INFO - 2021-04-03 09:37:15 --> Language Class Initialized
INFO - 2021-04-03 09:37:15 --> Config Class Initialized
INFO - 2021-04-03 09:37:15 --> Loader Class Initialized
INFO - 2021-04-03 09:37:15 --> Helper loaded: url_helper
INFO - 2021-04-03 09:37:15 --> Helper loaded: file_helper
INFO - 2021-04-03 09:37:15 --> Helper loaded: form_helper
INFO - 2021-04-03 09:37:15 --> Helper loaded: my_helper
INFO - 2021-04-03 09:37:15 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:37:15 --> Controller Class Initialized
DEBUG - 2021-04-03 09:37:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:37:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:37:16 --> Final output sent to browser
DEBUG - 2021-04-03 09:37:16 --> Total execution time: 0.7968
INFO - 2021-04-03 09:39:00 --> Config Class Initialized
INFO - 2021-04-03 09:39:00 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:00 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:00 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:00 --> URI Class Initialized
INFO - 2021-04-03 09:39:00 --> Router Class Initialized
INFO - 2021-04-03 09:39:00 --> Output Class Initialized
INFO - 2021-04-03 09:39:00 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:00 --> Input Class Initialized
INFO - 2021-04-03 09:39:00 --> Language Class Initialized
INFO - 2021-04-03 09:39:01 --> Language Class Initialized
INFO - 2021-04-03 09:39:01 --> Config Class Initialized
INFO - 2021-04-03 09:39:01 --> Loader Class Initialized
INFO - 2021-04-03 09:39:01 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:01 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:01 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:01 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:01 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:01 --> Controller Class Initialized
DEBUG - 2021-04-03 09:39:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-03 09:39:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:39:01 --> Final output sent to browser
DEBUG - 2021-04-03 09:39:01 --> Total execution time: 0.9598
INFO - 2021-04-03 09:39:01 --> Config Class Initialized
INFO - 2021-04-03 09:39:02 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:02 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:02 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:02 --> URI Class Initialized
INFO - 2021-04-03 09:39:02 --> Router Class Initialized
INFO - 2021-04-03 09:39:02 --> Output Class Initialized
INFO - 2021-04-03 09:39:02 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:02 --> Input Class Initialized
INFO - 2021-04-03 09:39:02 --> Language Class Initialized
INFO - 2021-04-03 09:39:02 --> Language Class Initialized
INFO - 2021-04-03 09:39:02 --> Config Class Initialized
INFO - 2021-04-03 09:39:02 --> Loader Class Initialized
INFO - 2021-04-03 09:39:02 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:02 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:02 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:02 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:02 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:02 --> Controller Class Initialized
INFO - 2021-04-03 09:39:06 --> Config Class Initialized
INFO - 2021-04-03 09:39:06 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:06 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:06 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:06 --> URI Class Initialized
INFO - 2021-04-03 09:39:06 --> Router Class Initialized
INFO - 2021-04-03 09:39:06 --> Output Class Initialized
INFO - 2021-04-03 09:39:06 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:07 --> Input Class Initialized
INFO - 2021-04-03 09:39:07 --> Language Class Initialized
INFO - 2021-04-03 09:39:07 --> Language Class Initialized
INFO - 2021-04-03 09:39:07 --> Config Class Initialized
INFO - 2021-04-03 09:39:07 --> Loader Class Initialized
INFO - 2021-04-03 09:39:07 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:07 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:07 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:07 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:07 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:07 --> Controller Class Initialized
ERROR - 2021-04-03 09:39:07 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-04-03 09:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-04-03 09:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:39:07 --> Final output sent to browser
DEBUG - 2021-04-03 09:39:07 --> Total execution time: 0.8433
INFO - 2021-04-03 09:39:16 --> Config Class Initialized
INFO - 2021-04-03 09:39:16 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:16 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:16 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:16 --> URI Class Initialized
INFO - 2021-04-03 09:39:16 --> Router Class Initialized
INFO - 2021-04-03 09:39:16 --> Output Class Initialized
INFO - 2021-04-03 09:39:16 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:16 --> Input Class Initialized
INFO - 2021-04-03 09:39:16 --> Language Class Initialized
INFO - 2021-04-03 09:39:16 --> Language Class Initialized
INFO - 2021-04-03 09:39:16 --> Config Class Initialized
INFO - 2021-04-03 09:39:16 --> Loader Class Initialized
INFO - 2021-04-03 09:39:16 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:16 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:16 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:16 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:16 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:16 --> Controller Class Initialized
DEBUG - 2021-04-03 09:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2021-04-03 09:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:39:17 --> Final output sent to browser
DEBUG - 2021-04-03 09:39:17 --> Total execution time: 0.6793
INFO - 2021-04-03 09:39:17 --> Config Class Initialized
INFO - 2021-04-03 09:39:17 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:17 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:17 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:17 --> URI Class Initialized
INFO - 2021-04-03 09:39:17 --> Router Class Initialized
INFO - 2021-04-03 09:39:17 --> Output Class Initialized
INFO - 2021-04-03 09:39:17 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:17 --> Input Class Initialized
INFO - 2021-04-03 09:39:17 --> Language Class Initialized
INFO - 2021-04-03 09:39:17 --> Language Class Initialized
INFO - 2021-04-03 09:39:17 --> Config Class Initialized
INFO - 2021-04-03 09:39:17 --> Loader Class Initialized
INFO - 2021-04-03 09:39:17 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:17 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:17 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:17 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:17 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:17 --> Controller Class Initialized
INFO - 2021-04-03 09:39:27 --> Config Class Initialized
INFO - 2021-04-03 09:39:27 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:27 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:27 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:27 --> URI Class Initialized
INFO - 2021-04-03 09:39:27 --> Router Class Initialized
INFO - 2021-04-03 09:39:27 --> Output Class Initialized
INFO - 2021-04-03 09:39:27 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:27 --> Input Class Initialized
INFO - 2021-04-03 09:39:28 --> Language Class Initialized
INFO - 2021-04-03 09:39:28 --> Language Class Initialized
INFO - 2021-04-03 09:39:28 --> Config Class Initialized
INFO - 2021-04-03 09:39:28 --> Loader Class Initialized
INFO - 2021-04-03 09:39:28 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:28 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:28 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:28 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:28 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:28 --> Controller Class Initialized
DEBUG - 2021-04-03 09:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:39:28 --> Final output sent to browser
DEBUG - 2021-04-03 09:39:28 --> Total execution time: 0.8830
INFO - 2021-04-03 09:39:30 --> Config Class Initialized
INFO - 2021-04-03 09:39:30 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:30 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:30 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:30 --> URI Class Initialized
INFO - 2021-04-03 09:39:30 --> Router Class Initialized
INFO - 2021-04-03 09:39:30 --> Output Class Initialized
INFO - 2021-04-03 09:39:30 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:30 --> Input Class Initialized
INFO - 2021-04-03 09:39:30 --> Language Class Initialized
INFO - 2021-04-03 09:39:30 --> Language Class Initialized
INFO - 2021-04-03 09:39:30 --> Config Class Initialized
INFO - 2021-04-03 09:39:30 --> Loader Class Initialized
INFO - 2021-04-03 09:39:30 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:30 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:31 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:31 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:31 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:31 --> Controller Class Initialized
DEBUG - 2021-04-03 09:39:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 09:39:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:39:31 --> Final output sent to browser
DEBUG - 2021-04-03 09:39:31 --> Total execution time: 0.9097
INFO - 2021-04-03 09:39:37 --> Config Class Initialized
INFO - 2021-04-03 09:39:37 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:37 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:37 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:37 --> URI Class Initialized
INFO - 2021-04-03 09:39:37 --> Router Class Initialized
INFO - 2021-04-03 09:39:37 --> Output Class Initialized
INFO - 2021-04-03 09:39:37 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:37 --> Input Class Initialized
INFO - 2021-04-03 09:39:37 --> Language Class Initialized
INFO - 2021-04-03 09:39:37 --> Language Class Initialized
INFO - 2021-04-03 09:39:37 --> Config Class Initialized
INFO - 2021-04-03 09:39:37 --> Loader Class Initialized
INFO - 2021-04-03 09:39:37 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:37 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:37 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:37 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:37 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:37 --> Controller Class Initialized
INFO - 2021-04-03 09:39:37 --> Config Class Initialized
INFO - 2021-04-03 09:39:37 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:39:37 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:39:37 --> Utf8 Class Initialized
INFO - 2021-04-03 09:39:37 --> URI Class Initialized
INFO - 2021-04-03 09:39:37 --> Router Class Initialized
INFO - 2021-04-03 09:39:38 --> Output Class Initialized
INFO - 2021-04-03 09:39:38 --> Security Class Initialized
DEBUG - 2021-04-03 09:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:39:38 --> Input Class Initialized
INFO - 2021-04-03 09:39:38 --> Language Class Initialized
INFO - 2021-04-03 09:39:38 --> Language Class Initialized
INFO - 2021-04-03 09:39:38 --> Config Class Initialized
INFO - 2021-04-03 09:39:38 --> Loader Class Initialized
INFO - 2021-04-03 09:39:38 --> Helper loaded: url_helper
INFO - 2021-04-03 09:39:38 --> Helper loaded: file_helper
INFO - 2021-04-03 09:39:38 --> Helper loaded: form_helper
INFO - 2021-04-03 09:39:38 --> Helper loaded: my_helper
INFO - 2021-04-03 09:39:38 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:39:38 --> Controller Class Initialized
DEBUG - 2021-04-03 09:39:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:39:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:39:38 --> Final output sent to browser
DEBUG - 2021-04-03 09:39:38 --> Total execution time: 0.7769
INFO - 2021-04-03 09:51:53 --> Config Class Initialized
INFO - 2021-04-03 09:51:53 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:51:53 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:51:53 --> Utf8 Class Initialized
INFO - 2021-04-03 09:51:53 --> URI Class Initialized
INFO - 2021-04-03 09:51:53 --> Router Class Initialized
INFO - 2021-04-03 09:51:53 --> Output Class Initialized
INFO - 2021-04-03 09:51:53 --> Security Class Initialized
DEBUG - 2021-04-03 09:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:51:54 --> Input Class Initialized
INFO - 2021-04-03 09:51:54 --> Language Class Initialized
INFO - 2021-04-03 09:51:54 --> Language Class Initialized
INFO - 2021-04-03 09:51:54 --> Config Class Initialized
INFO - 2021-04-03 09:51:54 --> Loader Class Initialized
INFO - 2021-04-03 09:51:54 --> Helper loaded: url_helper
INFO - 2021-04-03 09:51:54 --> Helper loaded: file_helper
INFO - 2021-04-03 09:51:54 --> Helper loaded: form_helper
INFO - 2021-04-03 09:51:54 --> Helper loaded: my_helper
INFO - 2021-04-03 09:51:54 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:51:54 --> Controller Class Initialized
DEBUG - 2021-04-03 09:51:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:51:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:51:54 --> Final output sent to browser
DEBUG - 2021-04-03 09:51:54 --> Total execution time: 0.4991
INFO - 2021-04-03 09:51:55 --> Config Class Initialized
INFO - 2021-04-03 09:51:55 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:51:55 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:51:55 --> Utf8 Class Initialized
INFO - 2021-04-03 09:51:55 --> URI Class Initialized
INFO - 2021-04-03 09:51:55 --> Router Class Initialized
INFO - 2021-04-03 09:51:55 --> Output Class Initialized
INFO - 2021-04-03 09:51:55 --> Security Class Initialized
DEBUG - 2021-04-03 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:51:55 --> Input Class Initialized
INFO - 2021-04-03 09:51:55 --> Language Class Initialized
INFO - 2021-04-03 09:51:55 --> Language Class Initialized
INFO - 2021-04-03 09:51:55 --> Config Class Initialized
INFO - 2021-04-03 09:51:55 --> Loader Class Initialized
INFO - 2021-04-03 09:51:56 --> Helper loaded: url_helper
INFO - 2021-04-03 09:51:56 --> Helper loaded: file_helper
INFO - 2021-04-03 09:51:56 --> Helper loaded: form_helper
INFO - 2021-04-03 09:51:56 --> Helper loaded: my_helper
INFO - 2021-04-03 09:51:56 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:51:56 --> Controller Class Initialized
DEBUG - 2021-04-03 09:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 09:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:51:56 --> Final output sent to browser
DEBUG - 2021-04-03 09:51:56 --> Total execution time: 0.7016
INFO - 2021-04-03 09:52:02 --> Config Class Initialized
INFO - 2021-04-03 09:52:02 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:02 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:02 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:02 --> URI Class Initialized
INFO - 2021-04-03 09:52:02 --> Router Class Initialized
INFO - 2021-04-03 09:52:02 --> Output Class Initialized
INFO - 2021-04-03 09:52:02 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:02 --> Input Class Initialized
INFO - 2021-04-03 09:52:02 --> Language Class Initialized
INFO - 2021-04-03 09:52:02 --> Language Class Initialized
INFO - 2021-04-03 09:52:02 --> Config Class Initialized
INFO - 2021-04-03 09:52:02 --> Loader Class Initialized
INFO - 2021-04-03 09:52:02 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:02 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:03 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:03 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:03 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:03 --> Controller Class Initialized
INFO - 2021-04-03 09:52:03 --> Config Class Initialized
INFO - 2021-04-03 09:52:03 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:03 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:03 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:03 --> URI Class Initialized
INFO - 2021-04-03 09:52:03 --> Router Class Initialized
INFO - 2021-04-03 09:52:03 --> Output Class Initialized
INFO - 2021-04-03 09:52:03 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:03 --> Input Class Initialized
INFO - 2021-04-03 09:52:03 --> Language Class Initialized
INFO - 2021-04-03 09:52:03 --> Language Class Initialized
INFO - 2021-04-03 09:52:03 --> Config Class Initialized
INFO - 2021-04-03 09:52:03 --> Loader Class Initialized
INFO - 2021-04-03 09:52:03 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:03 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:03 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:03 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:03 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:04 --> Controller Class Initialized
DEBUG - 2021-04-03 09:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:52:04 --> Final output sent to browser
DEBUG - 2021-04-03 09:52:04 --> Total execution time: 0.8072
INFO - 2021-04-03 09:52:05 --> Config Class Initialized
INFO - 2021-04-03 09:52:05 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:05 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:05 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:05 --> URI Class Initialized
INFO - 2021-04-03 09:52:05 --> Router Class Initialized
INFO - 2021-04-03 09:52:05 --> Output Class Initialized
INFO - 2021-04-03 09:52:05 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:06 --> Input Class Initialized
INFO - 2021-04-03 09:52:06 --> Language Class Initialized
INFO - 2021-04-03 09:52:06 --> Language Class Initialized
INFO - 2021-04-03 09:52:06 --> Config Class Initialized
INFO - 2021-04-03 09:52:06 --> Loader Class Initialized
INFO - 2021-04-03 09:52:06 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:06 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:06 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:06 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:06 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:06 --> Controller Class Initialized
DEBUG - 2021-04-03 09:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 09:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:52:06 --> Final output sent to browser
DEBUG - 2021-04-03 09:52:06 --> Total execution time: 0.7279
INFO - 2021-04-03 09:52:15 --> Config Class Initialized
INFO - 2021-04-03 09:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:15 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:15 --> URI Class Initialized
INFO - 2021-04-03 09:52:15 --> Router Class Initialized
INFO - 2021-04-03 09:52:15 --> Output Class Initialized
INFO - 2021-04-03 09:52:15 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:15 --> Input Class Initialized
INFO - 2021-04-03 09:52:15 --> Language Class Initialized
INFO - 2021-04-03 09:52:15 --> Language Class Initialized
INFO - 2021-04-03 09:52:15 --> Config Class Initialized
INFO - 2021-04-03 09:52:15 --> Loader Class Initialized
INFO - 2021-04-03 09:52:15 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:15 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:15 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:15 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:15 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:15 --> Controller Class Initialized
INFO - 2021-04-03 09:52:15 --> Config Class Initialized
INFO - 2021-04-03 09:52:15 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:15 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:15 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:15 --> URI Class Initialized
INFO - 2021-04-03 09:52:15 --> Router Class Initialized
INFO - 2021-04-03 09:52:16 --> Output Class Initialized
INFO - 2021-04-03 09:52:16 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:16 --> Input Class Initialized
INFO - 2021-04-03 09:52:16 --> Language Class Initialized
INFO - 2021-04-03 09:52:16 --> Language Class Initialized
INFO - 2021-04-03 09:52:16 --> Config Class Initialized
INFO - 2021-04-03 09:52:16 --> Loader Class Initialized
INFO - 2021-04-03 09:52:16 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:16 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:16 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:16 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:16 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:16 --> Controller Class Initialized
DEBUG - 2021-04-03 09:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:52:16 --> Final output sent to browser
DEBUG - 2021-04-03 09:52:16 --> Total execution time: 0.9016
INFO - 2021-04-03 09:52:31 --> Config Class Initialized
INFO - 2021-04-03 09:52:31 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:31 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:31 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:31 --> URI Class Initialized
INFO - 2021-04-03 09:52:31 --> Router Class Initialized
INFO - 2021-04-03 09:52:31 --> Output Class Initialized
INFO - 2021-04-03 09:52:31 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:31 --> Input Class Initialized
INFO - 2021-04-03 09:52:31 --> Language Class Initialized
INFO - 2021-04-03 09:52:31 --> Language Class Initialized
INFO - 2021-04-03 09:52:32 --> Config Class Initialized
INFO - 2021-04-03 09:52:32 --> Loader Class Initialized
INFO - 2021-04-03 09:52:32 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:32 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:32 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:32 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:32 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:32 --> Controller Class Initialized
DEBUG - 2021-04-03 09:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-03 09:52:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:52:32 --> Final output sent to browser
DEBUG - 2021-04-03 09:52:32 --> Total execution time: 0.7983
INFO - 2021-04-03 09:52:32 --> Config Class Initialized
INFO - 2021-04-03 09:52:32 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:32 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:32 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:32 --> URI Class Initialized
INFO - 2021-04-03 09:52:32 --> Router Class Initialized
INFO - 2021-04-03 09:52:32 --> Output Class Initialized
INFO - 2021-04-03 09:52:32 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:32 --> Input Class Initialized
INFO - 2021-04-03 09:52:32 --> Language Class Initialized
INFO - 2021-04-03 09:52:32 --> Language Class Initialized
INFO - 2021-04-03 09:52:32 --> Config Class Initialized
INFO - 2021-04-03 09:52:32 --> Loader Class Initialized
INFO - 2021-04-03 09:52:32 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:32 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:32 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:32 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:33 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:52:33 --> Controller Class Initialized
INFO - 2021-04-03 09:52:59 --> Config Class Initialized
INFO - 2021-04-03 09:52:59 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:52:59 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:52:59 --> Utf8 Class Initialized
INFO - 2021-04-03 09:52:59 --> URI Class Initialized
INFO - 2021-04-03 09:52:59 --> Router Class Initialized
INFO - 2021-04-03 09:52:59 --> Output Class Initialized
INFO - 2021-04-03 09:52:59 --> Security Class Initialized
DEBUG - 2021-04-03 09:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:52:59 --> Input Class Initialized
INFO - 2021-04-03 09:52:59 --> Language Class Initialized
INFO - 2021-04-03 09:52:59 --> Language Class Initialized
INFO - 2021-04-03 09:52:59 --> Config Class Initialized
INFO - 2021-04-03 09:52:59 --> Loader Class Initialized
INFO - 2021-04-03 09:52:59 --> Helper loaded: url_helper
INFO - 2021-04-03 09:52:59 --> Helper loaded: file_helper
INFO - 2021-04-03 09:52:59 --> Helper loaded: form_helper
INFO - 2021-04-03 09:52:59 --> Helper loaded: my_helper
INFO - 2021-04-03 09:52:59 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:53:00 --> Controller Class Initialized
INFO - 2021-04-03 09:53:00 --> Final output sent to browser
DEBUG - 2021-04-03 09:53:00 --> Total execution time: 0.6996
INFO - 2021-04-03 09:53:00 --> Config Class Initialized
INFO - 2021-04-03 09:53:00 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:53:00 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:53:00 --> Utf8 Class Initialized
INFO - 2021-04-03 09:53:00 --> URI Class Initialized
INFO - 2021-04-03 09:53:00 --> Router Class Initialized
INFO - 2021-04-03 09:53:00 --> Output Class Initialized
INFO - 2021-04-03 09:53:00 --> Security Class Initialized
DEBUG - 2021-04-03 09:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:53:00 --> Input Class Initialized
INFO - 2021-04-03 09:53:00 --> Language Class Initialized
INFO - 2021-04-03 09:53:00 --> Language Class Initialized
INFO - 2021-04-03 09:53:00 --> Config Class Initialized
INFO - 2021-04-03 09:53:00 --> Loader Class Initialized
INFO - 2021-04-03 09:53:00 --> Helper loaded: url_helper
INFO - 2021-04-03 09:53:00 --> Helper loaded: file_helper
INFO - 2021-04-03 09:53:00 --> Helper loaded: form_helper
INFO - 2021-04-03 09:53:01 --> Helper loaded: my_helper
INFO - 2021-04-03 09:53:01 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:53:01 --> Controller Class Initialized
INFO - 2021-04-03 09:53:13 --> Config Class Initialized
INFO - 2021-04-03 09:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:53:13 --> Utf8 Class Initialized
INFO - 2021-04-03 09:53:13 --> URI Class Initialized
INFO - 2021-04-03 09:53:13 --> Router Class Initialized
INFO - 2021-04-03 09:53:13 --> Output Class Initialized
INFO - 2021-04-03 09:53:13 --> Security Class Initialized
DEBUG - 2021-04-03 09:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:53:13 --> Input Class Initialized
INFO - 2021-04-03 09:53:13 --> Language Class Initialized
INFO - 2021-04-03 09:53:13 --> Language Class Initialized
INFO - 2021-04-03 09:53:13 --> Config Class Initialized
INFO - 2021-04-03 09:53:13 --> Loader Class Initialized
INFO - 2021-04-03 09:53:13 --> Helper loaded: url_helper
INFO - 2021-04-03 09:53:13 --> Helper loaded: file_helper
INFO - 2021-04-03 09:53:13 --> Helper loaded: form_helper
INFO - 2021-04-03 09:53:13 --> Helper loaded: my_helper
INFO - 2021-04-03 09:53:13 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:53:13 --> Controller Class Initialized
DEBUG - 2021-04-03 09:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:53:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:53:13 --> Final output sent to browser
DEBUG - 2021-04-03 09:53:14 --> Total execution time: 0.7738
INFO - 2021-04-03 09:53:14 --> Config Class Initialized
INFO - 2021-04-03 09:53:14 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:53:14 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:53:14 --> Utf8 Class Initialized
INFO - 2021-04-03 09:53:14 --> URI Class Initialized
INFO - 2021-04-03 09:53:15 --> Router Class Initialized
INFO - 2021-04-03 09:53:15 --> Output Class Initialized
INFO - 2021-04-03 09:53:15 --> Security Class Initialized
DEBUG - 2021-04-03 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:53:15 --> Input Class Initialized
INFO - 2021-04-03 09:53:15 --> Language Class Initialized
INFO - 2021-04-03 09:53:15 --> Language Class Initialized
INFO - 2021-04-03 09:53:15 --> Config Class Initialized
INFO - 2021-04-03 09:53:15 --> Loader Class Initialized
INFO - 2021-04-03 09:53:15 --> Helper loaded: url_helper
INFO - 2021-04-03 09:53:15 --> Helper loaded: file_helper
INFO - 2021-04-03 09:53:15 --> Helper loaded: form_helper
INFO - 2021-04-03 09:53:15 --> Helper loaded: my_helper
INFO - 2021-04-03 09:53:15 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:53:15 --> Controller Class Initialized
DEBUG - 2021-04-03 09:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 09:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:53:15 --> Final output sent to browser
DEBUG - 2021-04-03 09:53:15 --> Total execution time: 0.8719
INFO - 2021-04-03 09:53:20 --> Config Class Initialized
INFO - 2021-04-03 09:53:20 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:53:20 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:53:20 --> Utf8 Class Initialized
INFO - 2021-04-03 09:53:20 --> URI Class Initialized
INFO - 2021-04-03 09:53:20 --> Router Class Initialized
INFO - 2021-04-03 09:53:20 --> Output Class Initialized
INFO - 2021-04-03 09:53:20 --> Security Class Initialized
DEBUG - 2021-04-03 09:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:53:20 --> Input Class Initialized
INFO - 2021-04-03 09:53:20 --> Language Class Initialized
INFO - 2021-04-03 09:53:20 --> Language Class Initialized
INFO - 2021-04-03 09:53:20 --> Config Class Initialized
INFO - 2021-04-03 09:53:20 --> Loader Class Initialized
INFO - 2021-04-03 09:53:20 --> Helper loaded: url_helper
INFO - 2021-04-03 09:53:20 --> Helper loaded: file_helper
INFO - 2021-04-03 09:53:20 --> Helper loaded: form_helper
INFO - 2021-04-03 09:53:20 --> Helper loaded: my_helper
INFO - 2021-04-03 09:53:20 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:53:20 --> Controller Class Initialized
INFO - 2021-04-03 09:53:21 --> Config Class Initialized
INFO - 2021-04-03 09:53:21 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:53:21 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:53:21 --> Utf8 Class Initialized
INFO - 2021-04-03 09:53:21 --> URI Class Initialized
INFO - 2021-04-03 09:53:21 --> Router Class Initialized
INFO - 2021-04-03 09:53:21 --> Output Class Initialized
INFO - 2021-04-03 09:53:21 --> Security Class Initialized
DEBUG - 2021-04-03 09:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:53:21 --> Input Class Initialized
INFO - 2021-04-03 09:53:21 --> Language Class Initialized
INFO - 2021-04-03 09:53:21 --> Language Class Initialized
INFO - 2021-04-03 09:53:21 --> Config Class Initialized
INFO - 2021-04-03 09:53:21 --> Loader Class Initialized
INFO - 2021-04-03 09:53:21 --> Helper loaded: url_helper
INFO - 2021-04-03 09:53:21 --> Helper loaded: file_helper
INFO - 2021-04-03 09:53:21 --> Helper loaded: form_helper
INFO - 2021-04-03 09:53:21 --> Helper loaded: my_helper
INFO - 2021-04-03 09:53:21 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:53:21 --> Controller Class Initialized
DEBUG - 2021-04-03 09:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:53:21 --> Final output sent to browser
DEBUG - 2021-04-03 09:53:21 --> Total execution time: 0.7823
INFO - 2021-04-03 09:58:05 --> Config Class Initialized
INFO - 2021-04-03 09:58:05 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:58:05 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:58:05 --> Utf8 Class Initialized
INFO - 2021-04-03 09:58:05 --> URI Class Initialized
INFO - 2021-04-03 09:58:05 --> Router Class Initialized
INFO - 2021-04-03 09:58:05 --> Output Class Initialized
INFO - 2021-04-03 09:58:05 --> Security Class Initialized
DEBUG - 2021-04-03 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:58:05 --> Input Class Initialized
INFO - 2021-04-03 09:58:05 --> Language Class Initialized
INFO - 2021-04-03 09:58:05 --> Language Class Initialized
INFO - 2021-04-03 09:58:05 --> Config Class Initialized
INFO - 2021-04-03 09:58:05 --> Loader Class Initialized
INFO - 2021-04-03 09:58:05 --> Helper loaded: url_helper
INFO - 2021-04-03 09:58:05 --> Helper loaded: file_helper
INFO - 2021-04-03 09:58:05 --> Helper loaded: form_helper
INFO - 2021-04-03 09:58:05 --> Helper loaded: my_helper
INFO - 2021-04-03 09:58:05 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:58:05 --> Controller Class Initialized
DEBUG - 2021-04-03 09:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-03 09:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:58:05 --> Final output sent to browser
DEBUG - 2021-04-03 09:58:05 --> Total execution time: 0.6632
INFO - 2021-04-03 09:58:06 --> Config Class Initialized
INFO - 2021-04-03 09:58:06 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:58:06 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:58:06 --> Utf8 Class Initialized
INFO - 2021-04-03 09:58:06 --> URI Class Initialized
INFO - 2021-04-03 09:58:06 --> Router Class Initialized
INFO - 2021-04-03 09:58:06 --> Output Class Initialized
INFO - 2021-04-03 09:58:06 --> Security Class Initialized
DEBUG - 2021-04-03 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:58:06 --> Input Class Initialized
INFO - 2021-04-03 09:58:06 --> Language Class Initialized
INFO - 2021-04-03 09:58:06 --> Language Class Initialized
INFO - 2021-04-03 09:58:06 --> Config Class Initialized
INFO - 2021-04-03 09:58:06 --> Loader Class Initialized
INFO - 2021-04-03 09:58:06 --> Helper loaded: url_helper
INFO - 2021-04-03 09:58:06 --> Helper loaded: file_helper
INFO - 2021-04-03 09:58:06 --> Helper loaded: form_helper
INFO - 2021-04-03 09:58:06 --> Helper loaded: my_helper
INFO - 2021-04-03 09:58:06 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:58:06 --> Controller Class Initialized
INFO - 2021-04-03 09:58:50 --> Config Class Initialized
INFO - 2021-04-03 09:58:50 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:58:50 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:58:50 --> Utf8 Class Initialized
INFO - 2021-04-03 09:58:50 --> URI Class Initialized
INFO - 2021-04-03 09:58:50 --> Router Class Initialized
INFO - 2021-04-03 09:58:50 --> Output Class Initialized
INFO - 2021-04-03 09:58:50 --> Security Class Initialized
DEBUG - 2021-04-03 09:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:58:50 --> Input Class Initialized
INFO - 2021-04-03 09:58:50 --> Language Class Initialized
INFO - 2021-04-03 09:58:50 --> Language Class Initialized
INFO - 2021-04-03 09:58:50 --> Config Class Initialized
INFO - 2021-04-03 09:58:50 --> Loader Class Initialized
INFO - 2021-04-03 09:58:50 --> Helper loaded: url_helper
INFO - 2021-04-03 09:58:50 --> Helper loaded: file_helper
INFO - 2021-04-03 09:58:50 --> Helper loaded: form_helper
INFO - 2021-04-03 09:58:50 --> Helper loaded: my_helper
INFO - 2021-04-03 09:58:50 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:58:50 --> Controller Class Initialized
DEBUG - 2021-04-03 09:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 09:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:58:50 --> Final output sent to browser
DEBUG - 2021-04-03 09:58:50 --> Total execution time: 0.7258
INFO - 2021-04-03 09:58:52 --> Config Class Initialized
INFO - 2021-04-03 09:58:52 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:58:52 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:58:52 --> Utf8 Class Initialized
INFO - 2021-04-03 09:58:52 --> URI Class Initialized
INFO - 2021-04-03 09:58:52 --> Router Class Initialized
INFO - 2021-04-03 09:58:52 --> Output Class Initialized
INFO - 2021-04-03 09:58:52 --> Security Class Initialized
DEBUG - 2021-04-03 09:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:58:53 --> Input Class Initialized
INFO - 2021-04-03 09:58:53 --> Language Class Initialized
INFO - 2021-04-03 09:58:53 --> Language Class Initialized
INFO - 2021-04-03 09:58:53 --> Config Class Initialized
INFO - 2021-04-03 09:58:53 --> Loader Class Initialized
INFO - 2021-04-03 09:58:53 --> Helper loaded: url_helper
INFO - 2021-04-03 09:58:53 --> Helper loaded: file_helper
INFO - 2021-04-03 09:58:53 --> Helper loaded: form_helper
INFO - 2021-04-03 09:58:53 --> Helper loaded: my_helper
INFO - 2021-04-03 09:58:53 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:58:53 --> Controller Class Initialized
DEBUG - 2021-04-03 09:58:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-03 09:58:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:58:53 --> Final output sent to browser
DEBUG - 2021-04-03 09:58:53 --> Total execution time: 0.5606
INFO - 2021-04-03 09:58:53 --> Config Class Initialized
INFO - 2021-04-03 09:58:53 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:58:53 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:58:53 --> Utf8 Class Initialized
INFO - 2021-04-03 09:58:53 --> URI Class Initialized
INFO - 2021-04-03 09:58:53 --> Router Class Initialized
INFO - 2021-04-03 09:58:53 --> Output Class Initialized
INFO - 2021-04-03 09:58:53 --> Security Class Initialized
DEBUG - 2021-04-03 09:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:58:53 --> Input Class Initialized
INFO - 2021-04-03 09:58:53 --> Language Class Initialized
INFO - 2021-04-03 09:58:53 --> Language Class Initialized
INFO - 2021-04-03 09:58:53 --> Config Class Initialized
INFO - 2021-04-03 09:58:53 --> Loader Class Initialized
INFO - 2021-04-03 09:58:53 --> Helper loaded: url_helper
INFO - 2021-04-03 09:58:53 --> Helper loaded: file_helper
INFO - 2021-04-03 09:58:53 --> Helper loaded: form_helper
INFO - 2021-04-03 09:58:54 --> Helper loaded: my_helper
INFO - 2021-04-03 09:58:54 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:58:54 --> Controller Class Initialized
INFO - 2021-04-03 09:59:17 --> Config Class Initialized
INFO - 2021-04-03 09:59:18 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:59:18 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:59:18 --> Utf8 Class Initialized
INFO - 2021-04-03 09:59:18 --> URI Class Initialized
INFO - 2021-04-03 09:59:18 --> Router Class Initialized
INFO - 2021-04-03 09:59:18 --> Output Class Initialized
INFO - 2021-04-03 09:59:18 --> Security Class Initialized
DEBUG - 2021-04-03 09:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:59:18 --> Input Class Initialized
INFO - 2021-04-03 09:59:18 --> Language Class Initialized
INFO - 2021-04-03 09:59:18 --> Language Class Initialized
INFO - 2021-04-03 09:59:18 --> Config Class Initialized
INFO - 2021-04-03 09:59:18 --> Loader Class Initialized
INFO - 2021-04-03 09:59:18 --> Helper loaded: url_helper
INFO - 2021-04-03 09:59:18 --> Helper loaded: file_helper
INFO - 2021-04-03 09:59:18 --> Helper loaded: form_helper
INFO - 2021-04-03 09:59:18 --> Helper loaded: my_helper
INFO - 2021-04-03 09:59:18 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:59:18 --> Controller Class Initialized
INFO - 2021-04-03 09:59:18 --> Final output sent to browser
DEBUG - 2021-04-03 09:59:18 --> Total execution time: 0.6594
INFO - 2021-04-03 09:59:18 --> Config Class Initialized
INFO - 2021-04-03 09:59:18 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:59:18 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:59:18 --> Utf8 Class Initialized
INFO - 2021-04-03 09:59:18 --> URI Class Initialized
INFO - 2021-04-03 09:59:18 --> Router Class Initialized
INFO - 2021-04-03 09:59:18 --> Output Class Initialized
INFO - 2021-04-03 09:59:18 --> Security Class Initialized
DEBUG - 2021-04-03 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:59:19 --> Input Class Initialized
INFO - 2021-04-03 09:59:19 --> Language Class Initialized
INFO - 2021-04-03 09:59:19 --> Language Class Initialized
INFO - 2021-04-03 09:59:19 --> Config Class Initialized
INFO - 2021-04-03 09:59:19 --> Loader Class Initialized
INFO - 2021-04-03 09:59:19 --> Helper loaded: url_helper
INFO - 2021-04-03 09:59:19 --> Helper loaded: file_helper
INFO - 2021-04-03 09:59:19 --> Helper loaded: form_helper
INFO - 2021-04-03 09:59:19 --> Helper loaded: my_helper
INFO - 2021-04-03 09:59:19 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:59:19 --> Controller Class Initialized
INFO - 2021-04-03 09:59:42 --> Config Class Initialized
INFO - 2021-04-03 09:59:42 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:59:42 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:59:42 --> Utf8 Class Initialized
INFO - 2021-04-03 09:59:42 --> URI Class Initialized
INFO - 2021-04-03 09:59:42 --> Router Class Initialized
INFO - 2021-04-03 09:59:42 --> Output Class Initialized
INFO - 2021-04-03 09:59:42 --> Security Class Initialized
DEBUG - 2021-04-03 09:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:59:42 --> Input Class Initialized
INFO - 2021-04-03 09:59:42 --> Language Class Initialized
INFO - 2021-04-03 09:59:43 --> Language Class Initialized
INFO - 2021-04-03 09:59:43 --> Config Class Initialized
INFO - 2021-04-03 09:59:43 --> Loader Class Initialized
INFO - 2021-04-03 09:59:43 --> Helper loaded: url_helper
INFO - 2021-04-03 09:59:43 --> Helper loaded: file_helper
INFO - 2021-04-03 09:59:43 --> Helper loaded: form_helper
INFO - 2021-04-03 09:59:43 --> Helper loaded: my_helper
INFO - 2021-04-03 09:59:43 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:59:43 --> Controller Class Initialized
DEBUG - 2021-04-03 09:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-03 09:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 09:59:43 --> Final output sent to browser
DEBUG - 2021-04-03 09:59:43 --> Total execution time: 0.7160
INFO - 2021-04-03 09:59:43 --> Config Class Initialized
INFO - 2021-04-03 09:59:43 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:59:43 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:59:43 --> Utf8 Class Initialized
INFO - 2021-04-03 09:59:43 --> URI Class Initialized
INFO - 2021-04-03 09:59:43 --> Router Class Initialized
INFO - 2021-04-03 09:59:43 --> Output Class Initialized
INFO - 2021-04-03 09:59:43 --> Security Class Initialized
DEBUG - 2021-04-03 09:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:59:43 --> Input Class Initialized
INFO - 2021-04-03 09:59:43 --> Language Class Initialized
INFO - 2021-04-03 09:59:43 --> Language Class Initialized
INFO - 2021-04-03 09:59:43 --> Config Class Initialized
INFO - 2021-04-03 09:59:43 --> Loader Class Initialized
INFO - 2021-04-03 09:59:43 --> Helper loaded: url_helper
INFO - 2021-04-03 09:59:44 --> Helper loaded: file_helper
INFO - 2021-04-03 09:59:44 --> Helper loaded: form_helper
INFO - 2021-04-03 09:59:44 --> Helper loaded: my_helper
INFO - 2021-04-03 09:59:44 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:59:44 --> Controller Class Initialized
INFO - 2021-04-03 09:59:45 --> Config Class Initialized
INFO - 2021-04-03 09:59:45 --> Hooks Class Initialized
DEBUG - 2021-04-03 09:59:45 --> UTF-8 Support Enabled
INFO - 2021-04-03 09:59:45 --> Utf8 Class Initialized
INFO - 2021-04-03 09:59:45 --> URI Class Initialized
INFO - 2021-04-03 09:59:45 --> Router Class Initialized
INFO - 2021-04-03 09:59:45 --> Output Class Initialized
INFO - 2021-04-03 09:59:45 --> Security Class Initialized
DEBUG - 2021-04-03 09:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 09:59:45 --> Input Class Initialized
INFO - 2021-04-03 09:59:45 --> Language Class Initialized
INFO - 2021-04-03 09:59:45 --> Language Class Initialized
INFO - 2021-04-03 09:59:46 --> Config Class Initialized
INFO - 2021-04-03 09:59:46 --> Loader Class Initialized
INFO - 2021-04-03 09:59:46 --> Helper loaded: url_helper
INFO - 2021-04-03 09:59:46 --> Helper loaded: file_helper
INFO - 2021-04-03 09:59:46 --> Helper loaded: form_helper
INFO - 2021-04-03 09:59:46 --> Helper loaded: my_helper
INFO - 2021-04-03 09:59:46 --> Database Driver Class Initialized
DEBUG - 2021-04-03 09:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 09:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 09:59:46 --> Controller Class Initialized
INFO - 2021-04-03 09:59:46 --> Final output sent to browser
DEBUG - 2021-04-03 09:59:46 --> Total execution time: 0.5803
INFO - 2021-04-03 10:04:23 --> Config Class Initialized
INFO - 2021-04-03 10:04:23 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:23 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:24 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:24 --> URI Class Initialized
INFO - 2021-04-03 10:04:24 --> Router Class Initialized
INFO - 2021-04-03 10:04:24 --> Output Class Initialized
INFO - 2021-04-03 10:04:24 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:24 --> Input Class Initialized
INFO - 2021-04-03 10:04:24 --> Language Class Initialized
INFO - 2021-04-03 10:04:24 --> Language Class Initialized
INFO - 2021-04-03 10:04:24 --> Config Class Initialized
INFO - 2021-04-03 10:04:24 --> Loader Class Initialized
INFO - 2021-04-03 10:04:24 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:24 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:24 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:24 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:24 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:24 --> Controller Class Initialized
DEBUG - 2021-04-03 10:04:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-04-03 10:04:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:04:24 --> Final output sent to browser
DEBUG - 2021-04-03 10:04:24 --> Total execution time: 0.7096
INFO - 2021-04-03 10:04:24 --> Config Class Initialized
INFO - 2021-04-03 10:04:24 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:24 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:24 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:24 --> URI Class Initialized
INFO - 2021-04-03 10:04:24 --> Router Class Initialized
INFO - 2021-04-03 10:04:24 --> Output Class Initialized
INFO - 2021-04-03 10:04:24 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:25 --> Input Class Initialized
INFO - 2021-04-03 10:04:25 --> Language Class Initialized
INFO - 2021-04-03 10:04:25 --> Language Class Initialized
INFO - 2021-04-03 10:04:25 --> Config Class Initialized
INFO - 2021-04-03 10:04:25 --> Loader Class Initialized
INFO - 2021-04-03 10:04:25 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:25 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:25 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:25 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:25 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:25 --> Controller Class Initialized
INFO - 2021-04-03 10:04:26 --> Config Class Initialized
INFO - 2021-04-03 10:04:26 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:26 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:26 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:26 --> URI Class Initialized
INFO - 2021-04-03 10:04:26 --> Router Class Initialized
INFO - 2021-04-03 10:04:26 --> Output Class Initialized
INFO - 2021-04-03 10:04:26 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:26 --> Input Class Initialized
INFO - 2021-04-03 10:04:26 --> Language Class Initialized
INFO - 2021-04-03 10:04:26 --> Language Class Initialized
INFO - 2021-04-03 10:04:26 --> Config Class Initialized
INFO - 2021-04-03 10:04:26 --> Loader Class Initialized
INFO - 2021-04-03 10:04:26 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:26 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:26 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:26 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:26 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:26 --> Controller Class Initialized
INFO - 2021-04-03 10:04:26 --> Final output sent to browser
DEBUG - 2021-04-03 10:04:26 --> Total execution time: 0.6334
INFO - 2021-04-03 10:04:51 --> Config Class Initialized
INFO - 2021-04-03 10:04:51 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:51 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:51 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:51 --> URI Class Initialized
INFO - 2021-04-03 10:04:51 --> Router Class Initialized
INFO - 2021-04-03 10:04:51 --> Output Class Initialized
INFO - 2021-04-03 10:04:51 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:51 --> Input Class Initialized
INFO - 2021-04-03 10:04:51 --> Language Class Initialized
INFO - 2021-04-03 10:04:51 --> Language Class Initialized
INFO - 2021-04-03 10:04:51 --> Config Class Initialized
INFO - 2021-04-03 10:04:51 --> Loader Class Initialized
INFO - 2021-04-03 10:04:51 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:51 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:51 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:51 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:51 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:51 --> Controller Class Initialized
INFO - 2021-04-03 10:04:51 --> Final output sent to browser
DEBUG - 2021-04-03 10:04:51 --> Total execution time: 0.6643
INFO - 2021-04-03 10:04:52 --> Config Class Initialized
INFO - 2021-04-03 10:04:52 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:52 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:52 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:52 --> URI Class Initialized
INFO - 2021-04-03 10:04:52 --> Router Class Initialized
INFO - 2021-04-03 10:04:52 --> Output Class Initialized
INFO - 2021-04-03 10:04:52 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:52 --> Input Class Initialized
INFO - 2021-04-03 10:04:52 --> Language Class Initialized
INFO - 2021-04-03 10:04:52 --> Language Class Initialized
INFO - 2021-04-03 10:04:52 --> Config Class Initialized
INFO - 2021-04-03 10:04:52 --> Loader Class Initialized
INFO - 2021-04-03 10:04:52 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:52 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:52 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:52 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:52 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:52 --> Controller Class Initialized
INFO - 2021-04-03 10:04:55 --> Config Class Initialized
INFO - 2021-04-03 10:04:55 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:55 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:55 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:55 --> URI Class Initialized
INFO - 2021-04-03 10:04:55 --> Router Class Initialized
INFO - 2021-04-03 10:04:55 --> Output Class Initialized
INFO - 2021-04-03 10:04:55 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:55 --> Input Class Initialized
INFO - 2021-04-03 10:04:55 --> Language Class Initialized
INFO - 2021-04-03 10:04:55 --> Language Class Initialized
INFO - 2021-04-03 10:04:55 --> Config Class Initialized
INFO - 2021-04-03 10:04:55 --> Loader Class Initialized
INFO - 2021-04-03 10:04:55 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:55 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:55 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:56 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:56 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:56 --> Controller Class Initialized
INFO - 2021-04-03 10:04:56 --> Final output sent to browser
DEBUG - 2021-04-03 10:04:56 --> Total execution time: 0.8019
INFO - 2021-04-03 10:04:56 --> Config Class Initialized
INFO - 2021-04-03 10:04:56 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:56 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:56 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:56 --> URI Class Initialized
INFO - 2021-04-03 10:04:56 --> Router Class Initialized
INFO - 2021-04-03 10:04:56 --> Output Class Initialized
INFO - 2021-04-03 10:04:56 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:56 --> Input Class Initialized
INFO - 2021-04-03 10:04:56 --> Language Class Initialized
INFO - 2021-04-03 10:04:56 --> Language Class Initialized
INFO - 2021-04-03 10:04:56 --> Config Class Initialized
INFO - 2021-04-03 10:04:56 --> Loader Class Initialized
INFO - 2021-04-03 10:04:56 --> Helper loaded: url_helper
INFO - 2021-04-03 10:04:57 --> Helper loaded: file_helper
INFO - 2021-04-03 10:04:57 --> Helper loaded: form_helper
INFO - 2021-04-03 10:04:57 --> Helper loaded: my_helper
INFO - 2021-04-03 10:04:57 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:04:57 --> Controller Class Initialized
INFO - 2021-04-03 10:04:59 --> Config Class Initialized
INFO - 2021-04-03 10:04:59 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:04:59 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:04:59 --> Utf8 Class Initialized
INFO - 2021-04-03 10:04:59 --> URI Class Initialized
INFO - 2021-04-03 10:04:59 --> Router Class Initialized
INFO - 2021-04-03 10:04:59 --> Output Class Initialized
INFO - 2021-04-03 10:04:59 --> Security Class Initialized
DEBUG - 2021-04-03 10:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:04:59 --> Input Class Initialized
INFO - 2021-04-03 10:04:59 --> Language Class Initialized
INFO - 2021-04-03 10:05:00 --> Language Class Initialized
INFO - 2021-04-03 10:05:00 --> Config Class Initialized
INFO - 2021-04-03 10:05:00 --> Loader Class Initialized
INFO - 2021-04-03 10:05:00 --> Helper loaded: url_helper
INFO - 2021-04-03 10:05:00 --> Helper loaded: file_helper
INFO - 2021-04-03 10:05:00 --> Helper loaded: form_helper
INFO - 2021-04-03 10:05:00 --> Helper loaded: my_helper
INFO - 2021-04-03 10:05:00 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:05:00 --> Controller Class Initialized
DEBUG - 2021-04-03 10:05:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-04-03 10:05:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:05:00 --> Final output sent to browser
DEBUG - 2021-04-03 10:05:00 --> Total execution time: 0.9472
INFO - 2021-04-03 10:05:00 --> Config Class Initialized
INFO - 2021-04-03 10:05:01 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:05:01 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:05:01 --> Utf8 Class Initialized
INFO - 2021-04-03 10:05:01 --> URI Class Initialized
INFO - 2021-04-03 10:05:01 --> Router Class Initialized
INFO - 2021-04-03 10:05:01 --> Output Class Initialized
INFO - 2021-04-03 10:05:01 --> Security Class Initialized
DEBUG - 2021-04-03 10:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:05:01 --> Input Class Initialized
INFO - 2021-04-03 10:05:01 --> Language Class Initialized
INFO - 2021-04-03 10:05:01 --> Language Class Initialized
INFO - 2021-04-03 10:05:01 --> Config Class Initialized
INFO - 2021-04-03 10:05:01 --> Loader Class Initialized
INFO - 2021-04-03 10:05:01 --> Helper loaded: url_helper
INFO - 2021-04-03 10:05:01 --> Helper loaded: file_helper
INFO - 2021-04-03 10:05:01 --> Helper loaded: form_helper
INFO - 2021-04-03 10:05:01 --> Helper loaded: my_helper
INFO - 2021-04-03 10:05:01 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:05:01 --> Controller Class Initialized
INFO - 2021-04-03 10:05:05 --> Config Class Initialized
INFO - 2021-04-03 10:05:05 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:05:05 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:05:05 --> Utf8 Class Initialized
INFO - 2021-04-03 10:05:05 --> URI Class Initialized
INFO - 2021-04-03 10:05:05 --> Router Class Initialized
INFO - 2021-04-03 10:05:05 --> Output Class Initialized
INFO - 2021-04-03 10:05:05 --> Security Class Initialized
DEBUG - 2021-04-03 10:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:05:05 --> Input Class Initialized
INFO - 2021-04-03 10:05:05 --> Language Class Initialized
INFO - 2021-04-03 10:05:05 --> Language Class Initialized
INFO - 2021-04-03 10:05:05 --> Config Class Initialized
INFO - 2021-04-03 10:05:05 --> Loader Class Initialized
INFO - 2021-04-03 10:05:05 --> Helper loaded: url_helper
INFO - 2021-04-03 10:05:05 --> Helper loaded: file_helper
INFO - 2021-04-03 10:05:05 --> Helper loaded: form_helper
INFO - 2021-04-03 10:05:05 --> Helper loaded: my_helper
INFO - 2021-04-03 10:05:05 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:05:06 --> Controller Class Initialized
DEBUG - 2021-04-03 10:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 10:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:05:06 --> Final output sent to browser
DEBUG - 2021-04-03 10:05:06 --> Total execution time: 0.8846
INFO - 2021-04-03 10:05:07 --> Config Class Initialized
INFO - 2021-04-03 10:05:07 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:05:07 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:05:07 --> Utf8 Class Initialized
INFO - 2021-04-03 10:05:07 --> URI Class Initialized
INFO - 2021-04-03 10:05:07 --> Router Class Initialized
INFO - 2021-04-03 10:05:07 --> Output Class Initialized
INFO - 2021-04-03 10:05:07 --> Security Class Initialized
DEBUG - 2021-04-03 10:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:05:07 --> Input Class Initialized
INFO - 2021-04-03 10:05:07 --> Language Class Initialized
INFO - 2021-04-03 10:05:07 --> Language Class Initialized
INFO - 2021-04-03 10:05:07 --> Config Class Initialized
INFO - 2021-04-03 10:05:07 --> Loader Class Initialized
INFO - 2021-04-03 10:05:07 --> Helper loaded: url_helper
INFO - 2021-04-03 10:05:07 --> Helper loaded: file_helper
INFO - 2021-04-03 10:05:07 --> Helper loaded: form_helper
INFO - 2021-04-03 10:05:07 --> Helper loaded: my_helper
INFO - 2021-04-03 10:05:07 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:05:07 --> Controller Class Initialized
DEBUG - 2021-04-03 10:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 10:05:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:05:07 --> Final output sent to browser
DEBUG - 2021-04-03 10:05:07 --> Total execution time: 0.8771
INFO - 2021-04-03 10:05:12 --> Config Class Initialized
INFO - 2021-04-03 10:05:12 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:05:12 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:05:12 --> Utf8 Class Initialized
INFO - 2021-04-03 10:05:12 --> URI Class Initialized
INFO - 2021-04-03 10:05:12 --> Router Class Initialized
INFO - 2021-04-03 10:05:12 --> Output Class Initialized
INFO - 2021-04-03 10:05:12 --> Security Class Initialized
DEBUG - 2021-04-03 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:05:12 --> Input Class Initialized
INFO - 2021-04-03 10:05:12 --> Language Class Initialized
INFO - 2021-04-03 10:05:12 --> Language Class Initialized
INFO - 2021-04-03 10:05:12 --> Config Class Initialized
INFO - 2021-04-03 10:05:13 --> Loader Class Initialized
INFO - 2021-04-03 10:05:13 --> Helper loaded: url_helper
INFO - 2021-04-03 10:05:13 --> Helper loaded: file_helper
INFO - 2021-04-03 10:05:13 --> Helper loaded: form_helper
INFO - 2021-04-03 10:05:13 --> Helper loaded: my_helper
INFO - 2021-04-03 10:05:13 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:05:13 --> Controller Class Initialized
INFO - 2021-04-03 10:05:13 --> Config Class Initialized
INFO - 2021-04-03 10:05:13 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:05:13 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:05:13 --> Utf8 Class Initialized
INFO - 2021-04-03 10:05:13 --> URI Class Initialized
INFO - 2021-04-03 10:05:13 --> Router Class Initialized
INFO - 2021-04-03 10:05:13 --> Output Class Initialized
INFO - 2021-04-03 10:05:13 --> Security Class Initialized
DEBUG - 2021-04-03 10:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:05:13 --> Input Class Initialized
INFO - 2021-04-03 10:05:13 --> Language Class Initialized
INFO - 2021-04-03 10:05:13 --> Language Class Initialized
INFO - 2021-04-03 10:05:13 --> Config Class Initialized
INFO - 2021-04-03 10:05:13 --> Loader Class Initialized
INFO - 2021-04-03 10:05:13 --> Helper loaded: url_helper
INFO - 2021-04-03 10:05:13 --> Helper loaded: file_helper
INFO - 2021-04-03 10:05:14 --> Helper loaded: form_helper
INFO - 2021-04-03 10:05:14 --> Helper loaded: my_helper
INFO - 2021-04-03 10:05:14 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:05:14 --> Controller Class Initialized
DEBUG - 2021-04-03 10:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 10:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:05:14 --> Final output sent to browser
DEBUG - 2021-04-03 10:05:14 --> Total execution time: 0.8937
INFO - 2021-04-03 10:08:25 --> Config Class Initialized
INFO - 2021-04-03 10:08:25 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:08:25 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:08:25 --> Utf8 Class Initialized
INFO - 2021-04-03 10:08:25 --> URI Class Initialized
INFO - 2021-04-03 10:08:25 --> Router Class Initialized
INFO - 2021-04-03 10:08:25 --> Output Class Initialized
INFO - 2021-04-03 10:08:25 --> Security Class Initialized
DEBUG - 2021-04-03 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:08:25 --> Input Class Initialized
INFO - 2021-04-03 10:08:25 --> Language Class Initialized
INFO - 2021-04-03 10:08:26 --> Language Class Initialized
INFO - 2021-04-03 10:08:26 --> Config Class Initialized
INFO - 2021-04-03 10:08:26 --> Loader Class Initialized
INFO - 2021-04-03 10:08:26 --> Helper loaded: url_helper
INFO - 2021-04-03 10:08:26 --> Helper loaded: file_helper
INFO - 2021-04-03 10:08:26 --> Helper loaded: form_helper
INFO - 2021-04-03 10:08:26 --> Helper loaded: my_helper
INFO - 2021-04-03 10:08:26 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:08:26 --> Controller Class Initialized
DEBUG - 2021-04-03 10:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 10:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:08:26 --> Final output sent to browser
DEBUG - 2021-04-03 10:08:26 --> Total execution time: 0.8866
INFO - 2021-04-03 10:08:27 --> Config Class Initialized
INFO - 2021-04-03 10:08:27 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:08:27 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:08:27 --> Utf8 Class Initialized
INFO - 2021-04-03 10:08:27 --> URI Class Initialized
INFO - 2021-04-03 10:08:27 --> Router Class Initialized
INFO - 2021-04-03 10:08:27 --> Output Class Initialized
INFO - 2021-04-03 10:08:27 --> Security Class Initialized
DEBUG - 2021-04-03 10:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:08:27 --> Input Class Initialized
INFO - 2021-04-03 10:08:28 --> Language Class Initialized
INFO - 2021-04-03 10:08:28 --> Language Class Initialized
INFO - 2021-04-03 10:08:28 --> Config Class Initialized
INFO - 2021-04-03 10:08:28 --> Loader Class Initialized
INFO - 2021-04-03 10:08:28 --> Helper loaded: url_helper
INFO - 2021-04-03 10:08:28 --> Helper loaded: file_helper
INFO - 2021-04-03 10:08:28 --> Helper loaded: form_helper
INFO - 2021-04-03 10:08:28 --> Helper loaded: my_helper
INFO - 2021-04-03 10:08:28 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:08:28 --> Controller Class Initialized
DEBUG - 2021-04-03 10:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 10:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:08:28 --> Final output sent to browser
DEBUG - 2021-04-03 10:08:28 --> Total execution time: 0.9424
INFO - 2021-04-03 10:08:33 --> Config Class Initialized
INFO - 2021-04-03 10:08:33 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:08:33 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:08:33 --> Utf8 Class Initialized
INFO - 2021-04-03 10:08:33 --> URI Class Initialized
INFO - 2021-04-03 10:08:33 --> Router Class Initialized
INFO - 2021-04-03 10:08:33 --> Output Class Initialized
INFO - 2021-04-03 10:08:33 --> Security Class Initialized
DEBUG - 2021-04-03 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:08:34 --> Input Class Initialized
INFO - 2021-04-03 10:08:34 --> Language Class Initialized
INFO - 2021-04-03 10:08:34 --> Language Class Initialized
INFO - 2021-04-03 10:08:34 --> Config Class Initialized
INFO - 2021-04-03 10:08:34 --> Loader Class Initialized
INFO - 2021-04-03 10:08:34 --> Helper loaded: url_helper
INFO - 2021-04-03 10:08:34 --> Helper loaded: file_helper
INFO - 2021-04-03 10:08:34 --> Helper loaded: form_helper
INFO - 2021-04-03 10:08:34 --> Helper loaded: my_helper
INFO - 2021-04-03 10:08:34 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:08:34 --> Controller Class Initialized
INFO - 2021-04-03 10:08:34 --> Config Class Initialized
INFO - 2021-04-03 10:08:34 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:08:34 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:08:34 --> Utf8 Class Initialized
INFO - 2021-04-03 10:08:34 --> URI Class Initialized
INFO - 2021-04-03 10:08:34 --> Router Class Initialized
INFO - 2021-04-03 10:08:34 --> Output Class Initialized
INFO - 2021-04-03 10:08:34 --> Security Class Initialized
DEBUG - 2021-04-03 10:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:08:34 --> Input Class Initialized
INFO - 2021-04-03 10:08:35 --> Language Class Initialized
INFO - 2021-04-03 10:08:35 --> Language Class Initialized
INFO - 2021-04-03 10:08:35 --> Config Class Initialized
INFO - 2021-04-03 10:08:35 --> Loader Class Initialized
INFO - 2021-04-03 10:08:35 --> Helper loaded: url_helper
INFO - 2021-04-03 10:08:35 --> Helper loaded: file_helper
INFO - 2021-04-03 10:08:35 --> Helper loaded: form_helper
INFO - 2021-04-03 10:08:35 --> Helper loaded: my_helper
INFO - 2021-04-03 10:08:35 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:08:35 --> Controller Class Initialized
DEBUG - 2021-04-03 10:08:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 10:08:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:08:35 --> Final output sent to browser
DEBUG - 2021-04-03 10:08:35 --> Total execution time: 0.8334
INFO - 2021-04-03 10:09:01 --> Config Class Initialized
INFO - 2021-04-03 10:09:01 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:09:01 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:09:01 --> Utf8 Class Initialized
INFO - 2021-04-03 10:09:01 --> URI Class Initialized
INFO - 2021-04-03 10:09:02 --> Router Class Initialized
INFO - 2021-04-03 10:09:02 --> Output Class Initialized
INFO - 2021-04-03 10:09:02 --> Security Class Initialized
DEBUG - 2021-04-03 10:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:09:02 --> Input Class Initialized
INFO - 2021-04-03 10:09:02 --> Language Class Initialized
INFO - 2021-04-03 10:09:02 --> Language Class Initialized
INFO - 2021-04-03 10:09:02 --> Config Class Initialized
INFO - 2021-04-03 10:09:02 --> Loader Class Initialized
INFO - 2021-04-03 10:09:02 --> Helper loaded: url_helper
INFO - 2021-04-03 10:09:02 --> Helper loaded: file_helper
INFO - 2021-04-03 10:09:02 --> Helper loaded: form_helper
INFO - 2021-04-03 10:09:02 --> Helper loaded: my_helper
INFO - 2021-04-03 10:09:02 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:09:02 --> Controller Class Initialized
DEBUG - 2021-04-03 10:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-03 10:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:09:02 --> Final output sent to browser
DEBUG - 2021-04-03 10:09:02 --> Total execution time: 0.7533
INFO - 2021-04-03 10:09:02 --> Config Class Initialized
INFO - 2021-04-03 10:09:02 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:09:02 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:09:03 --> Utf8 Class Initialized
INFO - 2021-04-03 10:09:03 --> URI Class Initialized
INFO - 2021-04-03 10:09:03 --> Router Class Initialized
INFO - 2021-04-03 10:09:03 --> Output Class Initialized
INFO - 2021-04-03 10:09:03 --> Security Class Initialized
DEBUG - 2021-04-03 10:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:09:03 --> Input Class Initialized
INFO - 2021-04-03 10:09:03 --> Language Class Initialized
INFO - 2021-04-03 10:09:03 --> Language Class Initialized
INFO - 2021-04-03 10:09:03 --> Config Class Initialized
INFO - 2021-04-03 10:09:03 --> Loader Class Initialized
INFO - 2021-04-03 10:09:03 --> Helper loaded: url_helper
INFO - 2021-04-03 10:09:03 --> Helper loaded: file_helper
INFO - 2021-04-03 10:09:03 --> Helper loaded: form_helper
INFO - 2021-04-03 10:09:03 --> Helper loaded: my_helper
INFO - 2021-04-03 10:09:03 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:09:03 --> Controller Class Initialized
INFO - 2021-04-03 10:09:03 --> Config Class Initialized
INFO - 2021-04-03 10:09:03 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:09:03 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:09:03 --> Utf8 Class Initialized
INFO - 2021-04-03 10:09:03 --> URI Class Initialized
INFO - 2021-04-03 10:09:03 --> Router Class Initialized
INFO - 2021-04-03 10:09:03 --> Output Class Initialized
INFO - 2021-04-03 10:09:04 --> Security Class Initialized
DEBUG - 2021-04-03 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:09:04 --> Input Class Initialized
INFO - 2021-04-03 10:09:04 --> Language Class Initialized
INFO - 2021-04-03 10:09:04 --> Language Class Initialized
INFO - 2021-04-03 10:09:04 --> Config Class Initialized
INFO - 2021-04-03 10:09:04 --> Loader Class Initialized
INFO - 2021-04-03 10:09:04 --> Helper loaded: url_helper
INFO - 2021-04-03 10:09:04 --> Helper loaded: file_helper
INFO - 2021-04-03 10:09:04 --> Helper loaded: form_helper
INFO - 2021-04-03 10:09:04 --> Helper loaded: my_helper
INFO - 2021-04-03 10:09:04 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:09:04 --> Controller Class Initialized
ERROR - 2021-04-03 10:09:04 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2021-04-03 10:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-04-03 10:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:09:04 --> Final output sent to browser
DEBUG - 2021-04-03 10:09:04 --> Total execution time: 0.7136
INFO - 2021-04-03 10:10:37 --> Config Class Initialized
INFO - 2021-04-03 10:10:37 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:37 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:37 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:37 --> URI Class Initialized
INFO - 2021-04-03 10:10:37 --> Router Class Initialized
INFO - 2021-04-03 10:10:37 --> Output Class Initialized
INFO - 2021-04-03 10:10:37 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:37 --> Input Class Initialized
INFO - 2021-04-03 10:10:37 --> Language Class Initialized
INFO - 2021-04-03 10:10:37 --> Language Class Initialized
INFO - 2021-04-03 10:10:37 --> Config Class Initialized
INFO - 2021-04-03 10:10:37 --> Loader Class Initialized
INFO - 2021-04-03 10:10:37 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:37 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:37 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:37 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:37 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:38 --> Controller Class Initialized
INFO - 2021-04-03 10:10:44 --> Upload Class Initialized
INFO - 2021-04-03 10:10:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-04-03 10:10:44 --> The upload path does not appear to be valid.
INFO - 2021-04-03 10:10:44 --> Config Class Initialized
INFO - 2021-04-03 10:10:44 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:44 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:44 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:44 --> URI Class Initialized
INFO - 2021-04-03 10:10:44 --> Router Class Initialized
INFO - 2021-04-03 10:10:44 --> Output Class Initialized
INFO - 2021-04-03 10:10:45 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:45 --> Input Class Initialized
INFO - 2021-04-03 10:10:45 --> Language Class Initialized
INFO - 2021-04-03 10:10:45 --> Language Class Initialized
INFO - 2021-04-03 10:10:45 --> Config Class Initialized
INFO - 2021-04-03 10:10:45 --> Loader Class Initialized
INFO - 2021-04-03 10:10:45 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:45 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:45 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:45 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:45 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:45 --> Controller Class Initialized
DEBUG - 2021-04-03 10:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-04-03 10:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:10:45 --> Final output sent to browser
DEBUG - 2021-04-03 10:10:45 --> Total execution time: 0.9644
INFO - 2021-04-03 10:10:45 --> Config Class Initialized
INFO - 2021-04-03 10:10:45 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:45 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:45 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:45 --> URI Class Initialized
INFO - 2021-04-03 10:10:46 --> Router Class Initialized
INFO - 2021-04-03 10:10:46 --> Output Class Initialized
INFO - 2021-04-03 10:10:46 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:46 --> Input Class Initialized
INFO - 2021-04-03 10:10:46 --> Language Class Initialized
INFO - 2021-04-03 10:10:46 --> Language Class Initialized
INFO - 2021-04-03 10:10:46 --> Config Class Initialized
INFO - 2021-04-03 10:10:46 --> Loader Class Initialized
INFO - 2021-04-03 10:10:46 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:46 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:46 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:46 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:46 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:46 --> Controller Class Initialized
INFO - 2021-04-03 10:10:49 --> Config Class Initialized
INFO - 2021-04-03 10:10:49 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:49 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:49 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:50 --> URI Class Initialized
INFO - 2021-04-03 10:10:50 --> Router Class Initialized
INFO - 2021-04-03 10:10:50 --> Output Class Initialized
INFO - 2021-04-03 10:10:50 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:50 --> Input Class Initialized
INFO - 2021-04-03 10:10:50 --> Language Class Initialized
INFO - 2021-04-03 10:10:50 --> Language Class Initialized
INFO - 2021-04-03 10:10:50 --> Config Class Initialized
INFO - 2021-04-03 10:10:50 --> Loader Class Initialized
INFO - 2021-04-03 10:10:50 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:50 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:50 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:50 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:50 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:50 --> Controller Class Initialized
INFO - 2021-04-03 10:10:50 --> Config Class Initialized
INFO - 2021-04-03 10:10:50 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:50 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:50 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:50 --> URI Class Initialized
INFO - 2021-04-03 10:10:50 --> Router Class Initialized
INFO - 2021-04-03 10:10:50 --> Output Class Initialized
INFO - 2021-04-03 10:10:50 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:50 --> Input Class Initialized
INFO - 2021-04-03 10:10:51 --> Language Class Initialized
INFO - 2021-04-03 10:10:51 --> Language Class Initialized
INFO - 2021-04-03 10:10:51 --> Config Class Initialized
INFO - 2021-04-03 10:10:51 --> Loader Class Initialized
INFO - 2021-04-03 10:10:51 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:51 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:51 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:51 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:51 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:51 --> Controller Class Initialized
INFO - 2021-04-03 10:10:51 --> Config Class Initialized
INFO - 2021-04-03 10:10:51 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:51 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:51 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:51 --> URI Class Initialized
INFO - 2021-04-03 10:10:51 --> Router Class Initialized
INFO - 2021-04-03 10:10:51 --> Output Class Initialized
INFO - 2021-04-03 10:10:51 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:51 --> Input Class Initialized
INFO - 2021-04-03 10:10:51 --> Language Class Initialized
INFO - 2021-04-03 10:10:51 --> Language Class Initialized
INFO - 2021-04-03 10:10:51 --> Config Class Initialized
INFO - 2021-04-03 10:10:51 --> Loader Class Initialized
INFO - 2021-04-03 10:10:51 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:51 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:51 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:51 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:51 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:52 --> Controller Class Initialized
INFO - 2021-04-03 10:10:56 --> Config Class Initialized
INFO - 2021-04-03 10:10:56 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:10:56 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:10:56 --> Utf8 Class Initialized
INFO - 2021-04-03 10:10:56 --> URI Class Initialized
INFO - 2021-04-03 10:10:56 --> Router Class Initialized
INFO - 2021-04-03 10:10:56 --> Output Class Initialized
INFO - 2021-04-03 10:10:56 --> Security Class Initialized
DEBUG - 2021-04-03 10:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:10:56 --> Input Class Initialized
INFO - 2021-04-03 10:10:56 --> Language Class Initialized
INFO - 2021-04-03 10:10:56 --> Language Class Initialized
INFO - 2021-04-03 10:10:56 --> Config Class Initialized
INFO - 2021-04-03 10:10:56 --> Loader Class Initialized
INFO - 2021-04-03 10:10:56 --> Helper loaded: url_helper
INFO - 2021-04-03 10:10:56 --> Helper loaded: file_helper
INFO - 2021-04-03 10:10:56 --> Helper loaded: form_helper
INFO - 2021-04-03 10:10:56 --> Helper loaded: my_helper
INFO - 2021-04-03 10:10:56 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:10:56 --> Controller Class Initialized
INFO - 2021-04-03 10:11:04 --> Config Class Initialized
INFO - 2021-04-03 10:11:04 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:11:04 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:11:04 --> Utf8 Class Initialized
INFO - 2021-04-03 10:11:04 --> URI Class Initialized
INFO - 2021-04-03 10:11:04 --> Router Class Initialized
INFO - 2021-04-03 10:11:04 --> Output Class Initialized
INFO - 2021-04-03 10:11:04 --> Security Class Initialized
DEBUG - 2021-04-03 10:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:11:04 --> Input Class Initialized
INFO - 2021-04-03 10:11:04 --> Language Class Initialized
INFO - 2021-04-03 10:11:04 --> Language Class Initialized
INFO - 2021-04-03 10:11:04 --> Config Class Initialized
INFO - 2021-04-03 10:11:04 --> Loader Class Initialized
INFO - 2021-04-03 10:11:04 --> Helper loaded: url_helper
INFO - 2021-04-03 10:11:04 --> Helper loaded: file_helper
INFO - 2021-04-03 10:11:04 --> Helper loaded: form_helper
INFO - 2021-04-03 10:11:04 --> Helper loaded: my_helper
INFO - 2021-04-03 10:11:04 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:11:05 --> Controller Class Initialized
DEBUG - 2021-04-03 10:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 10:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:11:05 --> Final output sent to browser
DEBUG - 2021-04-03 10:11:05 --> Total execution time: 0.8967
INFO - 2021-04-03 10:11:06 --> Config Class Initialized
INFO - 2021-04-03 10:11:06 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:11:06 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:11:06 --> Utf8 Class Initialized
INFO - 2021-04-03 10:11:06 --> URI Class Initialized
INFO - 2021-04-03 10:11:06 --> Router Class Initialized
INFO - 2021-04-03 10:11:06 --> Output Class Initialized
INFO - 2021-04-03 10:11:06 --> Security Class Initialized
DEBUG - 2021-04-03 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:11:06 --> Input Class Initialized
INFO - 2021-04-03 10:11:06 --> Language Class Initialized
INFO - 2021-04-03 10:11:06 --> Language Class Initialized
INFO - 2021-04-03 10:11:06 --> Config Class Initialized
INFO - 2021-04-03 10:11:06 --> Loader Class Initialized
INFO - 2021-04-03 10:11:06 --> Helper loaded: url_helper
INFO - 2021-04-03 10:11:06 --> Helper loaded: file_helper
INFO - 2021-04-03 10:11:06 --> Helper loaded: form_helper
INFO - 2021-04-03 10:11:06 --> Helper loaded: my_helper
INFO - 2021-04-03 10:11:06 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:11:07 --> Controller Class Initialized
DEBUG - 2021-04-03 10:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-04-03 10:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:11:07 --> Final output sent to browser
DEBUG - 2021-04-03 10:11:07 --> Total execution time: 0.5863
INFO - 2021-04-03 10:11:18 --> Config Class Initialized
INFO - 2021-04-03 10:11:18 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:11:18 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:11:18 --> Utf8 Class Initialized
INFO - 2021-04-03 10:11:18 --> URI Class Initialized
INFO - 2021-04-03 10:11:18 --> Router Class Initialized
INFO - 2021-04-03 10:11:18 --> Output Class Initialized
INFO - 2021-04-03 10:11:18 --> Security Class Initialized
DEBUG - 2021-04-03 10:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:11:18 --> Input Class Initialized
INFO - 2021-04-03 10:11:18 --> Language Class Initialized
INFO - 2021-04-03 10:11:18 --> Language Class Initialized
INFO - 2021-04-03 10:11:18 --> Config Class Initialized
INFO - 2021-04-03 10:11:19 --> Loader Class Initialized
INFO - 2021-04-03 10:11:19 --> Helper loaded: url_helper
INFO - 2021-04-03 10:11:19 --> Helper loaded: file_helper
INFO - 2021-04-03 10:11:19 --> Helper loaded: form_helper
INFO - 2021-04-03 10:11:19 --> Helper loaded: my_helper
INFO - 2021-04-03 10:11:19 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:11:19 --> Controller Class Initialized
INFO - 2021-04-03 10:11:19 --> Config Class Initialized
INFO - 2021-04-03 10:11:19 --> Hooks Class Initialized
DEBUG - 2021-04-03 10:11:19 --> UTF-8 Support Enabled
INFO - 2021-04-03 10:11:19 --> Utf8 Class Initialized
INFO - 2021-04-03 10:11:19 --> URI Class Initialized
INFO - 2021-04-03 10:11:19 --> Router Class Initialized
INFO - 2021-04-03 10:11:19 --> Output Class Initialized
INFO - 2021-04-03 10:11:19 --> Security Class Initialized
DEBUG - 2021-04-03 10:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-03 10:11:19 --> Input Class Initialized
INFO - 2021-04-03 10:11:19 --> Language Class Initialized
INFO - 2021-04-03 10:11:19 --> Language Class Initialized
INFO - 2021-04-03 10:11:19 --> Config Class Initialized
INFO - 2021-04-03 10:11:19 --> Loader Class Initialized
INFO - 2021-04-03 10:11:19 --> Helper loaded: url_helper
INFO - 2021-04-03 10:11:19 --> Helper loaded: file_helper
INFO - 2021-04-03 10:11:19 --> Helper loaded: form_helper
INFO - 2021-04-03 10:11:19 --> Helper loaded: my_helper
INFO - 2021-04-03 10:11:19 --> Database Driver Class Initialized
DEBUG - 2021-04-03 10:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-03 10:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-03 10:11:20 --> Controller Class Initialized
DEBUG - 2021-04-03 10:11:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-04-03 10:11:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-04-03 10:11:20 --> Final output sent to browser
DEBUG - 2021-04-03 10:11:20 --> Total execution time: 0.8460
