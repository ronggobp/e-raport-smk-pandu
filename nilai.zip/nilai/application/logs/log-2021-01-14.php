<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-14 01:32:25 --> Config Class Initialized
INFO - 2021-01-14 01:32:25 --> Hooks Class Initialized
DEBUG - 2021-01-14 01:32:25 --> UTF-8 Support Enabled
INFO - 2021-01-14 01:32:25 --> Utf8 Class Initialized
INFO - 2021-01-14 01:32:25 --> URI Class Initialized
DEBUG - 2021-01-14 01:32:25 --> No URI present. Default controller set.
INFO - 2021-01-14 01:32:25 --> Router Class Initialized
INFO - 2021-01-14 01:32:25 --> Output Class Initialized
INFO - 2021-01-14 01:32:25 --> Security Class Initialized
DEBUG - 2021-01-14 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 01:32:25 --> Input Class Initialized
INFO - 2021-01-14 01:32:25 --> Language Class Initialized
INFO - 2021-01-14 01:32:25 --> Language Class Initialized
INFO - 2021-01-14 01:32:25 --> Config Class Initialized
INFO - 2021-01-14 01:32:25 --> Loader Class Initialized
INFO - 2021-01-14 01:32:25 --> Helper loaded: url_helper
INFO - 2021-01-14 01:32:25 --> Helper loaded: file_helper
INFO - 2021-01-14 01:32:25 --> Helper loaded: form_helper
INFO - 2021-01-14 01:32:25 --> Helper loaded: my_helper
INFO - 2021-01-14 01:32:25 --> Database Driver Class Initialized
DEBUG - 2021-01-14 01:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 01:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 01:32:25 --> Controller Class Initialized
INFO - 2021-01-14 01:32:25 --> Config Class Initialized
INFO - 2021-01-14 01:32:25 --> Hooks Class Initialized
DEBUG - 2021-01-14 01:32:25 --> UTF-8 Support Enabled
INFO - 2021-01-14 01:32:25 --> Utf8 Class Initialized
INFO - 2021-01-14 01:32:25 --> URI Class Initialized
INFO - 2021-01-14 01:32:25 --> Router Class Initialized
INFO - 2021-01-14 01:32:25 --> Output Class Initialized
INFO - 2021-01-14 01:32:25 --> Security Class Initialized
DEBUG - 2021-01-14 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 01:32:25 --> Input Class Initialized
INFO - 2021-01-14 01:32:25 --> Language Class Initialized
INFO - 2021-01-14 01:32:25 --> Language Class Initialized
INFO - 2021-01-14 01:32:25 --> Config Class Initialized
INFO - 2021-01-14 01:32:25 --> Loader Class Initialized
INFO - 2021-01-14 01:32:25 --> Helper loaded: url_helper
INFO - 2021-01-14 01:32:25 --> Helper loaded: file_helper
INFO - 2021-01-14 01:32:25 --> Helper loaded: form_helper
INFO - 2021-01-14 01:32:25 --> Helper loaded: my_helper
INFO - 2021-01-14 01:32:25 --> Database Driver Class Initialized
DEBUG - 2021-01-14 01:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 01:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 01:32:25 --> Controller Class Initialized
DEBUG - 2021-01-14 01:32:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-14 01:32:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 01:32:25 --> Final output sent to browser
DEBUG - 2021-01-14 01:32:25 --> Total execution time: 0.2927
INFO - 2021-01-14 01:50:57 --> Config Class Initialized
INFO - 2021-01-14 01:50:57 --> Hooks Class Initialized
DEBUG - 2021-01-14 01:50:57 --> UTF-8 Support Enabled
INFO - 2021-01-14 01:50:57 --> Utf8 Class Initialized
INFO - 2021-01-14 01:50:57 --> URI Class Initialized
INFO - 2021-01-14 01:50:57 --> Router Class Initialized
INFO - 2021-01-14 01:50:57 --> Output Class Initialized
INFO - 2021-01-14 01:50:57 --> Security Class Initialized
DEBUG - 2021-01-14 01:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 01:50:57 --> Input Class Initialized
INFO - 2021-01-14 01:50:57 --> Language Class Initialized
INFO - 2021-01-14 01:50:57 --> Language Class Initialized
INFO - 2021-01-14 01:50:57 --> Config Class Initialized
INFO - 2021-01-14 01:50:57 --> Loader Class Initialized
INFO - 2021-01-14 01:50:57 --> Helper loaded: url_helper
INFO - 2021-01-14 01:50:57 --> Helper loaded: file_helper
INFO - 2021-01-14 01:50:57 --> Helper loaded: form_helper
INFO - 2021-01-14 01:50:57 --> Helper loaded: my_helper
INFO - 2021-01-14 01:50:57 --> Database Driver Class Initialized
DEBUG - 2021-01-14 01:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 01:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 01:50:57 --> Controller Class Initialized
INFO - 2021-01-14 01:50:57 --> Helper loaded: cookie_helper
INFO - 2021-01-14 01:50:57 --> Final output sent to browser
DEBUG - 2021-01-14 01:50:57 --> Total execution time: 0.3105
INFO - 2021-01-14 01:50:59 --> Config Class Initialized
INFO - 2021-01-14 01:50:59 --> Hooks Class Initialized
DEBUG - 2021-01-14 01:50:59 --> UTF-8 Support Enabled
INFO - 2021-01-14 01:50:59 --> Utf8 Class Initialized
INFO - 2021-01-14 01:50:59 --> URI Class Initialized
INFO - 2021-01-14 01:50:59 --> Router Class Initialized
INFO - 2021-01-14 01:50:59 --> Output Class Initialized
INFO - 2021-01-14 01:50:59 --> Security Class Initialized
DEBUG - 2021-01-14 01:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 01:50:59 --> Input Class Initialized
INFO - 2021-01-14 01:50:59 --> Language Class Initialized
INFO - 2021-01-14 01:50:59 --> Language Class Initialized
INFO - 2021-01-14 01:50:59 --> Config Class Initialized
INFO - 2021-01-14 01:51:00 --> Loader Class Initialized
INFO - 2021-01-14 01:51:00 --> Helper loaded: url_helper
INFO - 2021-01-14 01:51:00 --> Helper loaded: file_helper
INFO - 2021-01-14 01:51:00 --> Helper loaded: form_helper
INFO - 2021-01-14 01:51:00 --> Helper loaded: my_helper
INFO - 2021-01-14 01:51:00 --> Database Driver Class Initialized
DEBUG - 2021-01-14 01:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 01:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 01:51:00 --> Controller Class Initialized
DEBUG - 2021-01-14 01:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-14 01:51:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 01:51:00 --> Final output sent to browser
DEBUG - 2021-01-14 01:51:00 --> Total execution time: 0.3643
INFO - 2021-01-14 01:57:10 --> Config Class Initialized
INFO - 2021-01-14 01:57:10 --> Hooks Class Initialized
DEBUG - 2021-01-14 01:57:10 --> UTF-8 Support Enabled
INFO - 2021-01-14 01:57:10 --> Utf8 Class Initialized
INFO - 2021-01-14 01:57:10 --> URI Class Initialized
INFO - 2021-01-14 01:57:10 --> Router Class Initialized
INFO - 2021-01-14 01:57:10 --> Output Class Initialized
INFO - 2021-01-14 01:57:10 --> Security Class Initialized
DEBUG - 2021-01-14 01:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 01:57:10 --> Input Class Initialized
INFO - 2021-01-14 01:57:10 --> Language Class Initialized
INFO - 2021-01-14 01:57:10 --> Language Class Initialized
INFO - 2021-01-14 01:57:10 --> Config Class Initialized
INFO - 2021-01-14 01:57:10 --> Loader Class Initialized
INFO - 2021-01-14 01:57:10 --> Helper loaded: url_helper
INFO - 2021-01-14 01:57:10 --> Helper loaded: file_helper
INFO - 2021-01-14 01:57:10 --> Helper loaded: form_helper
INFO - 2021-01-14 01:57:10 --> Helper loaded: my_helper
INFO - 2021-01-14 01:57:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 01:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 01:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 01:57:10 --> Controller Class Initialized
DEBUG - 2021-01-14 01:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-14 01:57:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 01:57:10 --> Final output sent to browser
DEBUG - 2021-01-14 01:57:10 --> Total execution time: 0.2886
INFO - 2021-01-14 01:57:11 --> Config Class Initialized
INFO - 2021-01-14 01:57:11 --> Hooks Class Initialized
DEBUG - 2021-01-14 01:57:11 --> UTF-8 Support Enabled
INFO - 2021-01-14 01:57:11 --> Utf8 Class Initialized
INFO - 2021-01-14 01:57:11 --> URI Class Initialized
INFO - 2021-01-14 01:57:11 --> Router Class Initialized
INFO - 2021-01-14 01:57:11 --> Output Class Initialized
INFO - 2021-01-14 01:57:11 --> Security Class Initialized
DEBUG - 2021-01-14 01:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 01:57:11 --> Input Class Initialized
INFO - 2021-01-14 01:57:11 --> Language Class Initialized
INFO - 2021-01-14 01:57:11 --> Language Class Initialized
INFO - 2021-01-14 01:57:11 --> Config Class Initialized
INFO - 2021-01-14 01:57:11 --> Loader Class Initialized
INFO - 2021-01-14 01:57:11 --> Helper loaded: url_helper
INFO - 2021-01-14 01:57:11 --> Helper loaded: file_helper
INFO - 2021-01-14 01:57:11 --> Helper loaded: form_helper
INFO - 2021-01-14 01:57:11 --> Helper loaded: my_helper
INFO - 2021-01-14 01:57:11 --> Database Driver Class Initialized
DEBUG - 2021-01-14 01:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 01:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 01:57:11 --> Controller Class Initialized
DEBUG - 2021-01-14 01:57:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 01:57:11 --> Final output sent to browser
DEBUG - 2021-01-14 01:57:11 --> Total execution time: 0.2381
INFO - 2021-01-14 02:18:14 --> Config Class Initialized
INFO - 2021-01-14 02:18:14 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:18:14 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:18:14 --> Utf8 Class Initialized
INFO - 2021-01-14 02:18:14 --> URI Class Initialized
INFO - 2021-01-14 02:18:14 --> Router Class Initialized
INFO - 2021-01-14 02:18:14 --> Output Class Initialized
INFO - 2021-01-14 02:18:14 --> Security Class Initialized
DEBUG - 2021-01-14 02:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:18:14 --> Input Class Initialized
INFO - 2021-01-14 02:18:14 --> Language Class Initialized
INFO - 2021-01-14 02:18:14 --> Language Class Initialized
INFO - 2021-01-14 02:18:14 --> Config Class Initialized
INFO - 2021-01-14 02:18:14 --> Loader Class Initialized
INFO - 2021-01-14 02:18:14 --> Helper loaded: url_helper
INFO - 2021-01-14 02:18:14 --> Helper loaded: file_helper
INFO - 2021-01-14 02:18:14 --> Helper loaded: form_helper
INFO - 2021-01-14 02:18:14 --> Helper loaded: my_helper
INFO - 2021-01-14 02:18:14 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:18:14 --> Controller Class Initialized
DEBUG - 2021-01-14 02:18:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:18:14 --> Final output sent to browser
DEBUG - 2021-01-14 02:18:14 --> Total execution time: 0.2257
INFO - 2021-01-14 02:20:48 --> Config Class Initialized
INFO - 2021-01-14 02:20:48 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:20:48 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:20:48 --> Utf8 Class Initialized
INFO - 2021-01-14 02:20:48 --> URI Class Initialized
INFO - 2021-01-14 02:20:48 --> Router Class Initialized
INFO - 2021-01-14 02:20:48 --> Output Class Initialized
INFO - 2021-01-14 02:20:48 --> Security Class Initialized
DEBUG - 2021-01-14 02:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:20:48 --> Input Class Initialized
INFO - 2021-01-14 02:20:48 --> Language Class Initialized
INFO - 2021-01-14 02:20:48 --> Language Class Initialized
INFO - 2021-01-14 02:20:48 --> Config Class Initialized
INFO - 2021-01-14 02:20:48 --> Loader Class Initialized
INFO - 2021-01-14 02:20:48 --> Helper loaded: url_helper
INFO - 2021-01-14 02:20:48 --> Helper loaded: file_helper
INFO - 2021-01-14 02:20:48 --> Helper loaded: form_helper
INFO - 2021-01-14 02:20:48 --> Helper loaded: my_helper
INFO - 2021-01-14 02:20:48 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:20:48 --> Controller Class Initialized
DEBUG - 2021-01-14 02:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:20:48 --> Final output sent to browser
DEBUG - 2021-01-14 02:20:48 --> Total execution time: 0.2507
INFO - 2021-01-14 02:20:49 --> Config Class Initialized
INFO - 2021-01-14 02:20:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:20:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:20:49 --> Utf8 Class Initialized
INFO - 2021-01-14 02:20:49 --> URI Class Initialized
INFO - 2021-01-14 02:20:49 --> Router Class Initialized
INFO - 2021-01-14 02:20:49 --> Output Class Initialized
INFO - 2021-01-14 02:20:50 --> Security Class Initialized
DEBUG - 2021-01-14 02:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:20:50 --> Input Class Initialized
INFO - 2021-01-14 02:20:50 --> Language Class Initialized
INFO - 2021-01-14 02:20:50 --> Language Class Initialized
INFO - 2021-01-14 02:20:50 --> Config Class Initialized
INFO - 2021-01-14 02:20:50 --> Loader Class Initialized
INFO - 2021-01-14 02:20:50 --> Helper loaded: url_helper
INFO - 2021-01-14 02:20:50 --> Helper loaded: file_helper
INFO - 2021-01-14 02:20:50 --> Helper loaded: form_helper
INFO - 2021-01-14 02:20:50 --> Helper loaded: my_helper
INFO - 2021-01-14 02:20:50 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:20:50 --> Controller Class Initialized
DEBUG - 2021-01-14 02:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:20:50 --> Final output sent to browser
DEBUG - 2021-01-14 02:20:50 --> Total execution time: 0.2532
INFO - 2021-01-14 02:23:41 --> Config Class Initialized
INFO - 2021-01-14 02:23:41 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:23:41 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:23:41 --> Utf8 Class Initialized
INFO - 2021-01-14 02:23:41 --> URI Class Initialized
INFO - 2021-01-14 02:23:41 --> Router Class Initialized
INFO - 2021-01-14 02:23:41 --> Output Class Initialized
INFO - 2021-01-14 02:23:41 --> Security Class Initialized
DEBUG - 2021-01-14 02:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:23:41 --> Input Class Initialized
INFO - 2021-01-14 02:23:41 --> Language Class Initialized
INFO - 2021-01-14 02:23:41 --> Language Class Initialized
INFO - 2021-01-14 02:23:41 --> Config Class Initialized
INFO - 2021-01-14 02:23:41 --> Loader Class Initialized
INFO - 2021-01-14 02:23:41 --> Helper loaded: url_helper
INFO - 2021-01-14 02:23:41 --> Helper loaded: file_helper
INFO - 2021-01-14 02:23:41 --> Helper loaded: form_helper
INFO - 2021-01-14 02:23:41 --> Helper loaded: my_helper
INFO - 2021-01-14 02:23:41 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:23:41 --> Controller Class Initialized
DEBUG - 2021-01-14 02:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:23:41 --> Final output sent to browser
DEBUG - 2021-01-14 02:23:41 --> Total execution time: 0.2441
INFO - 2021-01-14 02:23:50 --> Config Class Initialized
INFO - 2021-01-14 02:23:50 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:23:50 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:23:50 --> Utf8 Class Initialized
INFO - 2021-01-14 02:23:50 --> URI Class Initialized
INFO - 2021-01-14 02:23:50 --> Router Class Initialized
INFO - 2021-01-14 02:23:50 --> Output Class Initialized
INFO - 2021-01-14 02:23:50 --> Security Class Initialized
DEBUG - 2021-01-14 02:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:23:50 --> Input Class Initialized
INFO - 2021-01-14 02:23:50 --> Language Class Initialized
INFO - 2021-01-14 02:23:50 --> Language Class Initialized
INFO - 2021-01-14 02:23:50 --> Config Class Initialized
INFO - 2021-01-14 02:23:50 --> Loader Class Initialized
INFO - 2021-01-14 02:23:50 --> Helper loaded: url_helper
INFO - 2021-01-14 02:23:50 --> Helper loaded: file_helper
INFO - 2021-01-14 02:23:50 --> Helper loaded: form_helper
INFO - 2021-01-14 02:23:50 --> Helper loaded: my_helper
INFO - 2021-01-14 02:23:50 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:23:50 --> Controller Class Initialized
DEBUG - 2021-01-14 02:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-14 02:23:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 02:23:50 --> Final output sent to browser
DEBUG - 2021-01-14 02:23:50 --> Total execution time: 0.3157
INFO - 2021-01-14 02:23:54 --> Config Class Initialized
INFO - 2021-01-14 02:23:54 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:23:54 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:23:54 --> Utf8 Class Initialized
INFO - 2021-01-14 02:23:54 --> URI Class Initialized
INFO - 2021-01-14 02:23:54 --> Router Class Initialized
INFO - 2021-01-14 02:23:54 --> Output Class Initialized
INFO - 2021-01-14 02:23:54 --> Security Class Initialized
DEBUG - 2021-01-14 02:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:23:54 --> Input Class Initialized
INFO - 2021-01-14 02:23:54 --> Language Class Initialized
INFO - 2021-01-14 02:23:54 --> Language Class Initialized
INFO - 2021-01-14 02:23:54 --> Config Class Initialized
INFO - 2021-01-14 02:23:54 --> Loader Class Initialized
INFO - 2021-01-14 02:23:54 --> Helper loaded: url_helper
INFO - 2021-01-14 02:23:54 --> Helper loaded: file_helper
INFO - 2021-01-14 02:23:54 --> Helper loaded: form_helper
INFO - 2021-01-14 02:23:54 --> Helper loaded: my_helper
INFO - 2021-01-14 02:23:54 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:23:54 --> Controller Class Initialized
DEBUG - 2021-01-14 02:23:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-14 02:23:54 --> Final output sent to browser
DEBUG - 2021-01-14 02:23:54 --> Total execution time: 0.3604
INFO - 2021-01-14 02:24:10 --> Config Class Initialized
INFO - 2021-01-14 02:24:10 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:24:10 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:24:10 --> Utf8 Class Initialized
INFO - 2021-01-14 02:24:10 --> URI Class Initialized
INFO - 2021-01-14 02:24:10 --> Router Class Initialized
INFO - 2021-01-14 02:24:10 --> Output Class Initialized
INFO - 2021-01-14 02:24:10 --> Security Class Initialized
DEBUG - 2021-01-14 02:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:24:10 --> Input Class Initialized
INFO - 2021-01-14 02:24:10 --> Language Class Initialized
INFO - 2021-01-14 02:24:10 --> Language Class Initialized
INFO - 2021-01-14 02:24:10 --> Config Class Initialized
INFO - 2021-01-14 02:24:10 --> Loader Class Initialized
INFO - 2021-01-14 02:24:10 --> Helper loaded: url_helper
INFO - 2021-01-14 02:24:10 --> Helper loaded: file_helper
INFO - 2021-01-14 02:24:10 --> Helper loaded: form_helper
INFO - 2021-01-14 02:24:10 --> Helper loaded: my_helper
INFO - 2021-01-14 02:24:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:24:10 --> Controller Class Initialized
DEBUG - 2021-01-14 02:24:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:24:10 --> Final output sent to browser
DEBUG - 2021-01-14 02:24:10 --> Total execution time: 0.2165
INFO - 2021-01-14 02:24:33 --> Config Class Initialized
INFO - 2021-01-14 02:24:33 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:24:33 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:24:33 --> Utf8 Class Initialized
INFO - 2021-01-14 02:24:33 --> URI Class Initialized
INFO - 2021-01-14 02:24:33 --> Router Class Initialized
INFO - 2021-01-14 02:24:33 --> Output Class Initialized
INFO - 2021-01-14 02:24:33 --> Security Class Initialized
DEBUG - 2021-01-14 02:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:24:33 --> Input Class Initialized
INFO - 2021-01-14 02:24:33 --> Language Class Initialized
INFO - 2021-01-14 02:24:33 --> Language Class Initialized
INFO - 2021-01-14 02:24:33 --> Config Class Initialized
INFO - 2021-01-14 02:24:33 --> Loader Class Initialized
INFO - 2021-01-14 02:24:33 --> Helper loaded: url_helper
INFO - 2021-01-14 02:24:33 --> Helper loaded: file_helper
INFO - 2021-01-14 02:24:33 --> Helper loaded: form_helper
INFO - 2021-01-14 02:24:33 --> Helper loaded: my_helper
INFO - 2021-01-14 02:24:33 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:24:33 --> Controller Class Initialized
DEBUG - 2021-01-14 02:24:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:24:33 --> Final output sent to browser
DEBUG - 2021-01-14 02:24:33 --> Total execution time: 0.2507
INFO - 2021-01-14 02:29:22 --> Config Class Initialized
INFO - 2021-01-14 02:29:22 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:29:22 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:29:22 --> Utf8 Class Initialized
INFO - 2021-01-14 02:29:22 --> URI Class Initialized
INFO - 2021-01-14 02:29:22 --> Router Class Initialized
INFO - 2021-01-14 02:29:22 --> Output Class Initialized
INFO - 2021-01-14 02:29:22 --> Security Class Initialized
DEBUG - 2021-01-14 02:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:29:22 --> Input Class Initialized
INFO - 2021-01-14 02:29:22 --> Language Class Initialized
INFO - 2021-01-14 02:29:22 --> Language Class Initialized
INFO - 2021-01-14 02:29:22 --> Config Class Initialized
INFO - 2021-01-14 02:29:22 --> Loader Class Initialized
INFO - 2021-01-14 02:29:22 --> Helper loaded: url_helper
INFO - 2021-01-14 02:29:22 --> Helper loaded: file_helper
INFO - 2021-01-14 02:29:22 --> Helper loaded: form_helper
INFO - 2021-01-14 02:29:22 --> Helper loaded: my_helper
INFO - 2021-01-14 02:29:22 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:29:22 --> Controller Class Initialized
DEBUG - 2021-01-14 02:29:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:29:23 --> Final output sent to browser
DEBUG - 2021-01-14 02:29:23 --> Total execution time: 0.2570
INFO - 2021-01-14 02:30:13 --> Config Class Initialized
INFO - 2021-01-14 02:30:13 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:30:13 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:30:13 --> Utf8 Class Initialized
INFO - 2021-01-14 02:30:13 --> URI Class Initialized
INFO - 2021-01-14 02:30:13 --> Router Class Initialized
INFO - 2021-01-14 02:30:13 --> Output Class Initialized
INFO - 2021-01-14 02:30:13 --> Security Class Initialized
DEBUG - 2021-01-14 02:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:30:13 --> Input Class Initialized
INFO - 2021-01-14 02:30:13 --> Language Class Initialized
INFO - 2021-01-14 02:30:13 --> Language Class Initialized
INFO - 2021-01-14 02:30:13 --> Config Class Initialized
INFO - 2021-01-14 02:30:13 --> Loader Class Initialized
INFO - 2021-01-14 02:30:13 --> Helper loaded: url_helper
INFO - 2021-01-14 02:30:13 --> Helper loaded: file_helper
INFO - 2021-01-14 02:30:13 --> Helper loaded: form_helper
INFO - 2021-01-14 02:30:13 --> Helper loaded: my_helper
INFO - 2021-01-14 02:30:13 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:30:13 --> Controller Class Initialized
DEBUG - 2021-01-14 02:30:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:30:13 --> Final output sent to browser
DEBUG - 2021-01-14 02:30:13 --> Total execution time: 0.2252
INFO - 2021-01-14 02:30:40 --> Config Class Initialized
INFO - 2021-01-14 02:30:40 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:30:40 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:30:40 --> Utf8 Class Initialized
INFO - 2021-01-14 02:30:40 --> URI Class Initialized
INFO - 2021-01-14 02:30:40 --> Router Class Initialized
INFO - 2021-01-14 02:30:40 --> Output Class Initialized
INFO - 2021-01-14 02:30:40 --> Security Class Initialized
DEBUG - 2021-01-14 02:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:30:40 --> Input Class Initialized
INFO - 2021-01-14 02:30:40 --> Language Class Initialized
INFO - 2021-01-14 02:30:40 --> Language Class Initialized
INFO - 2021-01-14 02:30:40 --> Config Class Initialized
INFO - 2021-01-14 02:30:40 --> Loader Class Initialized
INFO - 2021-01-14 02:30:40 --> Helper loaded: url_helper
INFO - 2021-01-14 02:30:40 --> Helper loaded: file_helper
INFO - 2021-01-14 02:30:40 --> Helper loaded: form_helper
INFO - 2021-01-14 02:30:40 --> Helper loaded: my_helper
INFO - 2021-01-14 02:30:40 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:30:40 --> Controller Class Initialized
DEBUG - 2021-01-14 02:30:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:30:40 --> Final output sent to browser
DEBUG - 2021-01-14 02:30:40 --> Total execution time: 0.2400
INFO - 2021-01-14 02:31:12 --> Config Class Initialized
INFO - 2021-01-14 02:31:12 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:31:12 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:31:12 --> Utf8 Class Initialized
INFO - 2021-01-14 02:31:12 --> URI Class Initialized
INFO - 2021-01-14 02:31:12 --> Router Class Initialized
INFO - 2021-01-14 02:31:12 --> Output Class Initialized
INFO - 2021-01-14 02:31:12 --> Security Class Initialized
DEBUG - 2021-01-14 02:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:31:12 --> Input Class Initialized
INFO - 2021-01-14 02:31:12 --> Language Class Initialized
INFO - 2021-01-14 02:31:12 --> Language Class Initialized
INFO - 2021-01-14 02:31:12 --> Config Class Initialized
INFO - 2021-01-14 02:31:12 --> Loader Class Initialized
INFO - 2021-01-14 02:31:12 --> Helper loaded: url_helper
INFO - 2021-01-14 02:31:12 --> Helper loaded: file_helper
INFO - 2021-01-14 02:31:12 --> Helper loaded: form_helper
INFO - 2021-01-14 02:31:12 --> Helper loaded: my_helper
INFO - 2021-01-14 02:31:12 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:31:12 --> Controller Class Initialized
DEBUG - 2021-01-14 02:31:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:31:12 --> Final output sent to browser
DEBUG - 2021-01-14 02:31:13 --> Total execution time: 0.2239
INFO - 2021-01-14 02:58:39 --> Config Class Initialized
INFO - 2021-01-14 02:58:39 --> Hooks Class Initialized
DEBUG - 2021-01-14 02:58:39 --> UTF-8 Support Enabled
INFO - 2021-01-14 02:58:39 --> Utf8 Class Initialized
INFO - 2021-01-14 02:58:39 --> URI Class Initialized
INFO - 2021-01-14 02:58:39 --> Router Class Initialized
INFO - 2021-01-14 02:58:39 --> Output Class Initialized
INFO - 2021-01-14 02:58:39 --> Security Class Initialized
DEBUG - 2021-01-14 02:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 02:58:39 --> Input Class Initialized
INFO - 2021-01-14 02:58:39 --> Language Class Initialized
INFO - 2021-01-14 02:58:39 --> Language Class Initialized
INFO - 2021-01-14 02:58:39 --> Config Class Initialized
INFO - 2021-01-14 02:58:39 --> Loader Class Initialized
INFO - 2021-01-14 02:58:39 --> Helper loaded: url_helper
INFO - 2021-01-14 02:58:39 --> Helper loaded: file_helper
INFO - 2021-01-14 02:58:39 --> Helper loaded: form_helper
INFO - 2021-01-14 02:58:39 --> Helper loaded: my_helper
INFO - 2021-01-14 02:58:39 --> Database Driver Class Initialized
DEBUG - 2021-01-14 02:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 02:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 02:58:39 --> Controller Class Initialized
DEBUG - 2021-01-14 02:58:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 02:58:39 --> Final output sent to browser
DEBUG - 2021-01-14 02:58:39 --> Total execution time: 0.2464
INFO - 2021-01-14 03:11:27 --> Config Class Initialized
INFO - 2021-01-14 03:11:27 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:11:27 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:11:27 --> Utf8 Class Initialized
INFO - 2021-01-14 03:11:27 --> URI Class Initialized
INFO - 2021-01-14 03:11:27 --> Router Class Initialized
INFO - 2021-01-14 03:11:27 --> Output Class Initialized
INFO - 2021-01-14 03:11:27 --> Security Class Initialized
DEBUG - 2021-01-14 03:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:11:27 --> Input Class Initialized
INFO - 2021-01-14 03:11:27 --> Language Class Initialized
INFO - 2021-01-14 03:11:27 --> Language Class Initialized
INFO - 2021-01-14 03:11:27 --> Config Class Initialized
INFO - 2021-01-14 03:11:27 --> Loader Class Initialized
INFO - 2021-01-14 03:11:27 --> Helper loaded: url_helper
INFO - 2021-01-14 03:11:27 --> Helper loaded: file_helper
INFO - 2021-01-14 03:11:27 --> Helper loaded: form_helper
INFO - 2021-01-14 03:11:27 --> Helper loaded: my_helper
INFO - 2021-01-14 03:11:27 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:11:27 --> Controller Class Initialized
ERROR - 2021-01-14 03:11:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'' at line 1 - Invalid query: select a.id, a.kd_singkat from m_mapel a order by a.id asc WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'
INFO - 2021-01-14 03:11:27 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:11:49 --> Config Class Initialized
INFO - 2021-01-14 03:11:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:11:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:11:49 --> Utf8 Class Initialized
INFO - 2021-01-14 03:11:49 --> URI Class Initialized
INFO - 2021-01-14 03:11:49 --> Router Class Initialized
INFO - 2021-01-14 03:11:49 --> Output Class Initialized
INFO - 2021-01-14 03:11:49 --> Security Class Initialized
DEBUG - 2021-01-14 03:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:11:49 --> Input Class Initialized
INFO - 2021-01-14 03:11:49 --> Language Class Initialized
INFO - 2021-01-14 03:11:49 --> Language Class Initialized
INFO - 2021-01-14 03:11:49 --> Config Class Initialized
INFO - 2021-01-14 03:11:49 --> Loader Class Initialized
INFO - 2021-01-14 03:11:49 --> Helper loaded: url_helper
INFO - 2021-01-14 03:11:49 --> Helper loaded: file_helper
INFO - 2021-01-14 03:11:49 --> Helper loaded: form_helper
INFO - 2021-01-14 03:11:49 --> Helper loaded: my_helper
INFO - 2021-01-14 03:11:49 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:11:49 --> Controller Class Initialized
ERROR - 2021-01-14 03:11:49 --> Query error: Unknown column 'a.id' in 'field list' - Invalid query: select a.id, a.kd_singkat from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'
INFO - 2021-01-14 03:11:49 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:12:02 --> Config Class Initialized
INFO - 2021-01-14 03:12:02 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:12:02 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:12:02 --> Utf8 Class Initialized
INFO - 2021-01-14 03:12:02 --> URI Class Initialized
INFO - 2021-01-14 03:12:02 --> Router Class Initialized
INFO - 2021-01-14 03:12:02 --> Output Class Initialized
INFO - 2021-01-14 03:12:02 --> Security Class Initialized
DEBUG - 2021-01-14 03:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:12:02 --> Input Class Initialized
INFO - 2021-01-14 03:12:02 --> Language Class Initialized
INFO - 2021-01-14 03:12:02 --> Language Class Initialized
INFO - 2021-01-14 03:12:02 --> Config Class Initialized
INFO - 2021-01-14 03:12:03 --> Loader Class Initialized
INFO - 2021-01-14 03:12:03 --> Helper loaded: url_helper
INFO - 2021-01-14 03:12:03 --> Helper loaded: file_helper
INFO - 2021-01-14 03:12:03 --> Helper loaded: form_helper
INFO - 2021-01-14 03:12:03 --> Helper loaded: my_helper
INFO - 2021-01-14 03:12:03 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:12:03 --> Controller Class Initialized
DEBUG - 2021-01-14 03:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:12:03 --> Final output sent to browser
DEBUG - 2021-01-14 03:12:03 --> Total execution time: 0.2920
INFO - 2021-01-14 03:12:31 --> Config Class Initialized
INFO - 2021-01-14 03:12:31 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:12:31 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:12:31 --> Utf8 Class Initialized
INFO - 2021-01-14 03:12:31 --> URI Class Initialized
INFO - 2021-01-14 03:12:32 --> Router Class Initialized
INFO - 2021-01-14 03:12:32 --> Output Class Initialized
INFO - 2021-01-14 03:12:32 --> Security Class Initialized
DEBUG - 2021-01-14 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:12:32 --> Input Class Initialized
INFO - 2021-01-14 03:12:32 --> Language Class Initialized
INFO - 2021-01-14 03:12:32 --> Language Class Initialized
INFO - 2021-01-14 03:12:32 --> Config Class Initialized
INFO - 2021-01-14 03:12:32 --> Loader Class Initialized
INFO - 2021-01-14 03:12:32 --> Helper loaded: url_helper
INFO - 2021-01-14 03:12:32 --> Helper loaded: file_helper
INFO - 2021-01-14 03:12:32 --> Helper loaded: form_helper
INFO - 2021-01-14 03:12:32 --> Helper loaded: my_helper
INFO - 2021-01-14 03:12:32 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:12:32 --> Controller Class Initialized
ERROR - 2021-01-14 03:12:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'' at line 1 - Invalid query: select a.id, a.kd_singkat from m_mapel a order WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'
INFO - 2021-01-14 03:12:32 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:12:46 --> Config Class Initialized
INFO - 2021-01-14 03:12:46 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:12:46 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:12:46 --> Utf8 Class Initialized
INFO - 2021-01-14 03:12:46 --> URI Class Initialized
INFO - 2021-01-14 03:12:46 --> Router Class Initialized
INFO - 2021-01-14 03:12:46 --> Output Class Initialized
INFO - 2021-01-14 03:12:46 --> Security Class Initialized
DEBUG - 2021-01-14 03:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:12:46 --> Input Class Initialized
INFO - 2021-01-14 03:12:46 --> Language Class Initialized
INFO - 2021-01-14 03:12:46 --> Language Class Initialized
INFO - 2021-01-14 03:12:46 --> Config Class Initialized
INFO - 2021-01-14 03:12:46 --> Loader Class Initialized
INFO - 2021-01-14 03:12:46 --> Helper loaded: url_helper
INFO - 2021-01-14 03:12:46 --> Helper loaded: file_helper
INFO - 2021-01-14 03:12:46 --> Helper loaded: form_helper
INFO - 2021-01-14 03:12:46 --> Helper loaded: my_helper
INFO - 2021-01-14 03:12:46 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:12:46 --> Controller Class Initialized
ERROR - 2021-01-14 03:12:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'' at line 1 - Invalid query: select a.id, a.kd_singkat from m_mapel an order WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'
INFO - 2021-01-14 03:12:46 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:14:07 --> Config Class Initialized
INFO - 2021-01-14 03:14:07 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:14:07 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:14:07 --> Utf8 Class Initialized
INFO - 2021-01-14 03:14:08 --> URI Class Initialized
INFO - 2021-01-14 03:14:08 --> Router Class Initialized
INFO - 2021-01-14 03:14:08 --> Output Class Initialized
INFO - 2021-01-14 03:14:08 --> Security Class Initialized
DEBUG - 2021-01-14 03:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:14:08 --> Input Class Initialized
INFO - 2021-01-14 03:14:08 --> Language Class Initialized
INFO - 2021-01-14 03:14:08 --> Language Class Initialized
INFO - 2021-01-14 03:14:08 --> Config Class Initialized
INFO - 2021-01-14 03:14:08 --> Loader Class Initialized
INFO - 2021-01-14 03:14:08 --> Helper loaded: url_helper
INFO - 2021-01-14 03:14:08 --> Helper loaded: file_helper
INFO - 2021-01-14 03:14:08 --> Helper loaded: form_helper
INFO - 2021-01-14 03:14:08 --> Helper loaded: my_helper
INFO - 2021-01-14 03:14:08 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:14:08 --> Controller Class Initialized
DEBUG - 2021-01-14 03:14:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:14:08 --> Final output sent to browser
DEBUG - 2021-01-14 03:14:08 --> Total execution time: 0.2642
INFO - 2021-01-14 03:15:47 --> Config Class Initialized
INFO - 2021-01-14 03:15:47 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:15:47 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:15:47 --> Utf8 Class Initialized
INFO - 2021-01-14 03:15:47 --> URI Class Initialized
INFO - 2021-01-14 03:15:47 --> Router Class Initialized
INFO - 2021-01-14 03:15:47 --> Output Class Initialized
INFO - 2021-01-14 03:15:47 --> Security Class Initialized
DEBUG - 2021-01-14 03:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:15:47 --> Input Class Initialized
INFO - 2021-01-14 03:15:47 --> Language Class Initialized
INFO - 2021-01-14 03:15:47 --> Language Class Initialized
INFO - 2021-01-14 03:15:47 --> Config Class Initialized
INFO - 2021-01-14 03:15:47 --> Loader Class Initialized
INFO - 2021-01-14 03:15:47 --> Helper loaded: url_helper
INFO - 2021-01-14 03:15:47 --> Helper loaded: file_helper
INFO - 2021-01-14 03:15:47 --> Helper loaded: form_helper
INFO - 2021-01-14 03:15:47 --> Helper loaded: my_helper
INFO - 2021-01-14 03:15:47 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:15:47 --> Controller Class Initialized
ERROR - 2021-01-14 03:15:47 --> Query error: Unknown column 'a.id' in 'field list' - Invalid query: select a.id, a.kd_singkat from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'
INFO - 2021-01-14 03:15:47 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:16:04 --> Config Class Initialized
INFO - 2021-01-14 03:16:04 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:16:04 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:16:04 --> Utf8 Class Initialized
INFO - 2021-01-14 03:16:04 --> URI Class Initialized
INFO - 2021-01-14 03:16:04 --> Router Class Initialized
INFO - 2021-01-14 03:16:04 --> Output Class Initialized
INFO - 2021-01-14 03:16:04 --> Security Class Initialized
DEBUG - 2021-01-14 03:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:16:04 --> Input Class Initialized
INFO - 2021-01-14 03:16:04 --> Language Class Initialized
INFO - 2021-01-14 03:16:04 --> Language Class Initialized
INFO - 2021-01-14 03:16:04 --> Config Class Initialized
INFO - 2021-01-14 03:16:04 --> Loader Class Initialized
INFO - 2021-01-14 03:16:04 --> Helper loaded: url_helper
INFO - 2021-01-14 03:16:04 --> Helper loaded: file_helper
INFO - 2021-01-14 03:16:04 --> Helper loaded: form_helper
INFO - 2021-01-14 03:16:04 --> Helper loaded: my_helper
INFO - 2021-01-14 03:16:04 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:16:04 --> Controller Class Initialized
ERROR - 2021-01-14 03:16:04 --> Query error: Unknown column 'a.kd_singkat' in 'field list' - Invalid query: select a.kd_singkat from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'
INFO - 2021-01-14 03:16:04 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:16:36 --> Config Class Initialized
INFO - 2021-01-14 03:16:36 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:16:36 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:16:36 --> Utf8 Class Initialized
INFO - 2021-01-14 03:16:36 --> URI Class Initialized
INFO - 2021-01-14 03:16:36 --> Router Class Initialized
INFO - 2021-01-14 03:16:36 --> Output Class Initialized
INFO - 2021-01-14 03:16:36 --> Security Class Initialized
DEBUG - 2021-01-14 03:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:16:36 --> Input Class Initialized
INFO - 2021-01-14 03:16:36 --> Language Class Initialized
INFO - 2021-01-14 03:16:36 --> Language Class Initialized
INFO - 2021-01-14 03:16:36 --> Config Class Initialized
INFO - 2021-01-14 03:16:36 --> Loader Class Initialized
INFO - 2021-01-14 03:16:36 --> Helper loaded: url_helper
INFO - 2021-01-14 03:16:36 --> Helper loaded: file_helper
INFO - 2021-01-14 03:16:36 --> Helper loaded: form_helper
INFO - 2021-01-14 03:16:37 --> Helper loaded: my_helper
INFO - 2021-01-14 03:16:37 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:16:37 --> Controller Class Initialized
DEBUG - 2021-01-14 03:16:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:16:37 --> Final output sent to browser
DEBUG - 2021-01-14 03:16:37 --> Total execution time: 0.2240
INFO - 2021-01-14 03:19:15 --> Config Class Initialized
INFO - 2021-01-14 03:19:15 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:19:15 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:19:15 --> Utf8 Class Initialized
INFO - 2021-01-14 03:19:15 --> URI Class Initialized
INFO - 2021-01-14 03:19:15 --> Router Class Initialized
INFO - 2021-01-14 03:19:15 --> Output Class Initialized
INFO - 2021-01-14 03:19:15 --> Security Class Initialized
DEBUG - 2021-01-14 03:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:19:15 --> Input Class Initialized
INFO - 2021-01-14 03:19:15 --> Language Class Initialized
INFO - 2021-01-14 03:19:15 --> Language Class Initialized
INFO - 2021-01-14 03:19:15 --> Config Class Initialized
INFO - 2021-01-14 03:19:15 --> Loader Class Initialized
INFO - 2021-01-14 03:19:15 --> Helper loaded: url_helper
INFO - 2021-01-14 03:19:15 --> Helper loaded: file_helper
INFO - 2021-01-14 03:19:15 --> Helper loaded: form_helper
INFO - 2021-01-14 03:19:15 --> Helper loaded: my_helper
INFO - 2021-01-14 03:19:15 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:19:15 --> Controller Class Initialized
ERROR - 2021-01-14 03:19:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''Q','G' AND tambahan_sub = 'NASIONAL',KOMPETENSI'' at line 1 - Invalid query: select * from m_mapel WHERE kelompok = 'A','Q','G' AND tambahan_sub = 'NASIONAL',KOMPETENSI'
INFO - 2021-01-14 03:19:15 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:20:08 --> Config Class Initialized
INFO - 2021-01-14 03:20:08 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:20:08 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:20:08 --> Utf8 Class Initialized
INFO - 2021-01-14 03:20:08 --> URI Class Initialized
INFO - 2021-01-14 03:20:08 --> Router Class Initialized
INFO - 2021-01-14 03:20:08 --> Output Class Initialized
INFO - 2021-01-14 03:20:08 --> Security Class Initialized
DEBUG - 2021-01-14 03:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:20:08 --> Input Class Initialized
INFO - 2021-01-14 03:20:08 --> Language Class Initialized
INFO - 2021-01-14 03:20:08 --> Language Class Initialized
INFO - 2021-01-14 03:20:08 --> Config Class Initialized
INFO - 2021-01-14 03:20:08 --> Loader Class Initialized
INFO - 2021-01-14 03:20:08 --> Helper loaded: url_helper
INFO - 2021-01-14 03:20:08 --> Helper loaded: file_helper
INFO - 2021-01-14 03:20:08 --> Helper loaded: form_helper
INFO - 2021-01-14 03:20:08 --> Helper loaded: my_helper
INFO - 2021-01-14 03:20:08 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:20:08 --> Controller Class Initialized
ERROR - 2021-01-14 03:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Q','G' AND tambahan_sub = 'NASIONAL','KOMPETENSI'' at line 1 - Invalid query: select * from m_mapel WHERE kelompok = 'A',Q','G' AND tambahan_sub = 'NASIONAL','KOMPETENSI'
INFO - 2021-01-14 03:20:08 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:20:29 --> Config Class Initialized
INFO - 2021-01-14 03:20:29 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:20:29 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:20:29 --> Utf8 Class Initialized
INFO - 2021-01-14 03:20:29 --> URI Class Initialized
INFO - 2021-01-14 03:20:29 --> Router Class Initialized
INFO - 2021-01-14 03:20:29 --> Output Class Initialized
INFO - 2021-01-14 03:20:29 --> Security Class Initialized
DEBUG - 2021-01-14 03:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:20:29 --> Input Class Initialized
INFO - 2021-01-14 03:20:29 --> Language Class Initialized
INFO - 2021-01-14 03:20:29 --> Language Class Initialized
INFO - 2021-01-14 03:20:29 --> Config Class Initialized
INFO - 2021-01-14 03:20:29 --> Loader Class Initialized
INFO - 2021-01-14 03:20:29 --> Helper loaded: url_helper
INFO - 2021-01-14 03:20:29 --> Helper loaded: file_helper
INFO - 2021-01-14 03:20:29 --> Helper loaded: form_helper
INFO - 2021-01-14 03:20:29 --> Helper loaded: my_helper
INFO - 2021-01-14 03:20:29 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:20:29 --> Controller Class Initialized
ERROR - 2021-01-14 03:20:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''Q','G' AND tambahan_sub = 'NASIONAL','KOMPETENSI'' at line 1 - Invalid query: select * from m_mapel WHERE kelompok = 'A','Q','G' AND tambahan_sub = 'NASIONAL','KOMPETENSI'
INFO - 2021-01-14 03:20:29 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 03:20:49 --> Config Class Initialized
INFO - 2021-01-14 03:20:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:20:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:20:49 --> Utf8 Class Initialized
INFO - 2021-01-14 03:20:49 --> URI Class Initialized
INFO - 2021-01-14 03:20:49 --> Router Class Initialized
INFO - 2021-01-14 03:20:49 --> Output Class Initialized
INFO - 2021-01-14 03:20:49 --> Security Class Initialized
DEBUG - 2021-01-14 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:20:49 --> Input Class Initialized
INFO - 2021-01-14 03:20:49 --> Language Class Initialized
INFO - 2021-01-14 03:20:49 --> Language Class Initialized
INFO - 2021-01-14 03:20:49 --> Config Class Initialized
INFO - 2021-01-14 03:20:49 --> Loader Class Initialized
INFO - 2021-01-14 03:20:49 --> Helper loaded: url_helper
INFO - 2021-01-14 03:20:49 --> Helper loaded: file_helper
INFO - 2021-01-14 03:20:49 --> Helper loaded: form_helper
INFO - 2021-01-14 03:20:49 --> Helper loaded: my_helper
INFO - 2021-01-14 03:20:49 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:20:49 --> Controller Class Initialized
DEBUG - 2021-01-14 03:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:20:49 --> Final output sent to browser
DEBUG - 2021-01-14 03:20:49 --> Total execution time: 0.2654
INFO - 2021-01-14 03:21:07 --> Config Class Initialized
INFO - 2021-01-14 03:21:07 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:21:07 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:21:07 --> Utf8 Class Initialized
INFO - 2021-01-14 03:21:07 --> URI Class Initialized
INFO - 2021-01-14 03:21:07 --> Router Class Initialized
INFO - 2021-01-14 03:21:07 --> Output Class Initialized
INFO - 2021-01-14 03:21:07 --> Security Class Initialized
DEBUG - 2021-01-14 03:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:21:07 --> Input Class Initialized
INFO - 2021-01-14 03:21:07 --> Language Class Initialized
INFO - 2021-01-14 03:21:07 --> Language Class Initialized
INFO - 2021-01-14 03:21:07 --> Config Class Initialized
INFO - 2021-01-14 03:21:07 --> Loader Class Initialized
INFO - 2021-01-14 03:21:07 --> Helper loaded: url_helper
INFO - 2021-01-14 03:21:07 --> Helper loaded: file_helper
INFO - 2021-01-14 03:21:07 --> Helper loaded: form_helper
INFO - 2021-01-14 03:21:07 --> Helper loaded: my_helper
INFO - 2021-01-14 03:21:07 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:21:07 --> Controller Class Initialized
DEBUG - 2021-01-14 03:21:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:21:07 --> Final output sent to browser
DEBUG - 2021-01-14 03:21:07 --> Total execution time: 0.2447
INFO - 2021-01-14 03:25:19 --> Config Class Initialized
INFO - 2021-01-14 03:25:19 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:25:19 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:25:19 --> Utf8 Class Initialized
INFO - 2021-01-14 03:25:19 --> URI Class Initialized
INFO - 2021-01-14 03:25:19 --> Router Class Initialized
INFO - 2021-01-14 03:25:19 --> Output Class Initialized
INFO - 2021-01-14 03:25:19 --> Security Class Initialized
DEBUG - 2021-01-14 03:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:25:19 --> Input Class Initialized
INFO - 2021-01-14 03:25:19 --> Language Class Initialized
INFO - 2021-01-14 03:25:19 --> Language Class Initialized
INFO - 2021-01-14 03:25:19 --> Config Class Initialized
INFO - 2021-01-14 03:25:19 --> Loader Class Initialized
INFO - 2021-01-14 03:25:19 --> Helper loaded: url_helper
INFO - 2021-01-14 03:25:19 --> Helper loaded: file_helper
INFO - 2021-01-14 03:25:19 --> Helper loaded: form_helper
INFO - 2021-01-14 03:25:19 --> Helper loaded: my_helper
INFO - 2021-01-14 03:25:19 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:25:19 --> Controller Class Initialized
DEBUG - 2021-01-14 03:25:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:25:19 --> Final output sent to browser
DEBUG - 2021-01-14 03:25:19 --> Total execution time: 0.2559
INFO - 2021-01-14 03:26:28 --> Config Class Initialized
INFO - 2021-01-14 03:26:28 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:26:28 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:26:28 --> Utf8 Class Initialized
INFO - 2021-01-14 03:26:28 --> URI Class Initialized
INFO - 2021-01-14 03:26:28 --> Router Class Initialized
INFO - 2021-01-14 03:26:28 --> Output Class Initialized
INFO - 2021-01-14 03:26:28 --> Security Class Initialized
DEBUG - 2021-01-14 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:26:28 --> Input Class Initialized
INFO - 2021-01-14 03:26:28 --> Language Class Initialized
INFO - 2021-01-14 03:26:28 --> Language Class Initialized
INFO - 2021-01-14 03:26:28 --> Config Class Initialized
INFO - 2021-01-14 03:26:28 --> Loader Class Initialized
INFO - 2021-01-14 03:26:28 --> Helper loaded: url_helper
INFO - 2021-01-14 03:26:28 --> Helper loaded: file_helper
INFO - 2021-01-14 03:26:28 --> Helper loaded: form_helper
INFO - 2021-01-14 03:26:28 --> Helper loaded: my_helper
INFO - 2021-01-14 03:26:28 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:26:29 --> Controller Class Initialized
DEBUG - 2021-01-14 03:26:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:26:29 --> Final output sent to browser
DEBUG - 2021-01-14 03:26:29 --> Total execution time: 0.2405
INFO - 2021-01-14 03:27:02 --> Config Class Initialized
INFO - 2021-01-14 03:27:02 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:27:02 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:27:02 --> Utf8 Class Initialized
INFO - 2021-01-14 03:27:02 --> URI Class Initialized
INFO - 2021-01-14 03:27:02 --> Router Class Initialized
INFO - 2021-01-14 03:27:02 --> Output Class Initialized
INFO - 2021-01-14 03:27:02 --> Security Class Initialized
DEBUG - 2021-01-14 03:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:27:02 --> Input Class Initialized
INFO - 2021-01-14 03:27:02 --> Language Class Initialized
INFO - 2021-01-14 03:27:02 --> Language Class Initialized
INFO - 2021-01-14 03:27:02 --> Config Class Initialized
INFO - 2021-01-14 03:27:02 --> Loader Class Initialized
INFO - 2021-01-14 03:27:02 --> Helper loaded: url_helper
INFO - 2021-01-14 03:27:02 --> Helper loaded: file_helper
INFO - 2021-01-14 03:27:02 --> Helper loaded: form_helper
INFO - 2021-01-14 03:27:02 --> Helper loaded: my_helper
INFO - 2021-01-14 03:27:02 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:27:03 --> Controller Class Initialized
DEBUG - 2021-01-14 03:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:27:03 --> Final output sent to browser
DEBUG - 2021-01-14 03:27:03 --> Total execution time: 0.2358
INFO - 2021-01-14 03:28:11 --> Config Class Initialized
INFO - 2021-01-14 03:28:11 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:28:11 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:28:11 --> Utf8 Class Initialized
INFO - 2021-01-14 03:28:11 --> URI Class Initialized
INFO - 2021-01-14 03:28:11 --> Router Class Initialized
INFO - 2021-01-14 03:28:11 --> Output Class Initialized
INFO - 2021-01-14 03:28:11 --> Security Class Initialized
DEBUG - 2021-01-14 03:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:28:12 --> Input Class Initialized
INFO - 2021-01-14 03:28:12 --> Language Class Initialized
INFO - 2021-01-14 03:28:12 --> Language Class Initialized
INFO - 2021-01-14 03:28:12 --> Config Class Initialized
INFO - 2021-01-14 03:28:12 --> Loader Class Initialized
INFO - 2021-01-14 03:28:12 --> Helper loaded: url_helper
INFO - 2021-01-14 03:28:12 --> Helper loaded: file_helper
INFO - 2021-01-14 03:28:12 --> Helper loaded: form_helper
INFO - 2021-01-14 03:28:12 --> Helper loaded: my_helper
INFO - 2021-01-14 03:28:12 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:28:12 --> Controller Class Initialized
DEBUG - 2021-01-14 03:28:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:28:12 --> Final output sent to browser
DEBUG - 2021-01-14 03:28:12 --> Total execution time: 0.2442
INFO - 2021-01-14 03:29:53 --> Config Class Initialized
INFO - 2021-01-14 03:29:53 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:29:53 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:29:53 --> Utf8 Class Initialized
INFO - 2021-01-14 03:29:53 --> URI Class Initialized
INFO - 2021-01-14 03:29:53 --> Router Class Initialized
INFO - 2021-01-14 03:29:53 --> Output Class Initialized
INFO - 2021-01-14 03:29:53 --> Security Class Initialized
DEBUG - 2021-01-14 03:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:29:53 --> Input Class Initialized
INFO - 2021-01-14 03:29:53 --> Language Class Initialized
ERROR - 2021-01-14 03:29:53 --> Severity: Parsing Error --> syntax error, unexpected 'foreach' (T_FOREACH), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 178
INFO - 2021-01-14 03:30:13 --> Config Class Initialized
INFO - 2021-01-14 03:30:13 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:30:13 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:30:13 --> Utf8 Class Initialized
INFO - 2021-01-14 03:30:13 --> URI Class Initialized
INFO - 2021-01-14 03:30:13 --> Router Class Initialized
INFO - 2021-01-14 03:30:13 --> Output Class Initialized
INFO - 2021-01-14 03:30:13 --> Security Class Initialized
DEBUG - 2021-01-14 03:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:30:13 --> Input Class Initialized
INFO - 2021-01-14 03:30:13 --> Language Class Initialized
ERROR - 2021-01-14 03:30:13 --> Severity: Parsing Error --> syntax error, unexpected '$html' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
INFO - 2021-01-14 03:31:07 --> Config Class Initialized
INFO - 2021-01-14 03:31:07 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:31:07 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:31:07 --> Utf8 Class Initialized
INFO - 2021-01-14 03:31:07 --> URI Class Initialized
INFO - 2021-01-14 03:31:07 --> Router Class Initialized
INFO - 2021-01-14 03:31:07 --> Output Class Initialized
INFO - 2021-01-14 03:31:07 --> Security Class Initialized
DEBUG - 2021-01-14 03:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:31:07 --> Input Class Initialized
INFO - 2021-01-14 03:31:07 --> Language Class Initialized
INFO - 2021-01-14 03:31:07 --> Language Class Initialized
INFO - 2021-01-14 03:31:07 --> Config Class Initialized
INFO - 2021-01-14 03:31:07 --> Loader Class Initialized
INFO - 2021-01-14 03:31:07 --> Helper loaded: url_helper
INFO - 2021-01-14 03:31:07 --> Helper loaded: file_helper
INFO - 2021-01-14 03:31:07 --> Helper loaded: form_helper
INFO - 2021-01-14 03:31:07 --> Helper loaded: my_helper
INFO - 2021-01-14 03:31:07 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:31:07 --> Controller Class Initialized
DEBUG - 2021-01-14 03:31:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:31:07 --> Final output sent to browser
DEBUG - 2021-01-14 03:31:07 --> Total execution time: 0.2730
INFO - 2021-01-14 03:31:27 --> Config Class Initialized
INFO - 2021-01-14 03:31:27 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:31:27 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:31:27 --> Utf8 Class Initialized
INFO - 2021-01-14 03:31:27 --> URI Class Initialized
INFO - 2021-01-14 03:31:27 --> Router Class Initialized
INFO - 2021-01-14 03:31:27 --> Output Class Initialized
INFO - 2021-01-14 03:31:27 --> Security Class Initialized
DEBUG - 2021-01-14 03:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:31:27 --> Input Class Initialized
INFO - 2021-01-14 03:31:27 --> Language Class Initialized
INFO - 2021-01-14 03:31:27 --> Language Class Initialized
INFO - 2021-01-14 03:31:27 --> Config Class Initialized
INFO - 2021-01-14 03:31:27 --> Loader Class Initialized
INFO - 2021-01-14 03:31:27 --> Helper loaded: url_helper
INFO - 2021-01-14 03:31:27 --> Helper loaded: file_helper
INFO - 2021-01-14 03:31:27 --> Helper loaded: form_helper
INFO - 2021-01-14 03:31:27 --> Helper loaded: my_helper
INFO - 2021-01-14 03:31:27 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:31:27 --> Controller Class Initialized
DEBUG - 2021-01-14 03:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:31:27 --> Final output sent to browser
DEBUG - 2021-01-14 03:31:27 --> Total execution time: 0.2478
INFO - 2021-01-14 03:31:41 --> Config Class Initialized
INFO - 2021-01-14 03:31:41 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:31:41 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:31:41 --> Utf8 Class Initialized
INFO - 2021-01-14 03:31:41 --> URI Class Initialized
INFO - 2021-01-14 03:31:41 --> Router Class Initialized
INFO - 2021-01-14 03:31:41 --> Output Class Initialized
INFO - 2021-01-14 03:31:41 --> Security Class Initialized
DEBUG - 2021-01-14 03:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:31:41 --> Input Class Initialized
INFO - 2021-01-14 03:31:41 --> Language Class Initialized
INFO - 2021-01-14 03:31:41 --> Language Class Initialized
INFO - 2021-01-14 03:31:41 --> Config Class Initialized
INFO - 2021-01-14 03:31:41 --> Loader Class Initialized
INFO - 2021-01-14 03:31:41 --> Helper loaded: url_helper
INFO - 2021-01-14 03:31:41 --> Helper loaded: file_helper
INFO - 2021-01-14 03:31:41 --> Helper loaded: form_helper
INFO - 2021-01-14 03:31:41 --> Helper loaded: my_helper
INFO - 2021-01-14 03:31:41 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:31:41 --> Controller Class Initialized
DEBUG - 2021-01-14 03:31:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:31:41 --> Final output sent to browser
DEBUG - 2021-01-14 03:31:41 --> Total execution time: 0.2917
INFO - 2021-01-14 03:31:53 --> Config Class Initialized
INFO - 2021-01-14 03:31:53 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:31:53 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:31:53 --> Utf8 Class Initialized
INFO - 2021-01-14 03:31:53 --> URI Class Initialized
INFO - 2021-01-14 03:31:53 --> Router Class Initialized
INFO - 2021-01-14 03:31:53 --> Output Class Initialized
INFO - 2021-01-14 03:31:53 --> Security Class Initialized
DEBUG - 2021-01-14 03:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:31:53 --> Input Class Initialized
INFO - 2021-01-14 03:31:53 --> Language Class Initialized
INFO - 2021-01-14 03:31:53 --> Language Class Initialized
INFO - 2021-01-14 03:31:53 --> Config Class Initialized
INFO - 2021-01-14 03:31:53 --> Loader Class Initialized
INFO - 2021-01-14 03:31:53 --> Helper loaded: url_helper
INFO - 2021-01-14 03:31:53 --> Helper loaded: file_helper
INFO - 2021-01-14 03:31:53 --> Helper loaded: form_helper
INFO - 2021-01-14 03:31:53 --> Helper loaded: my_helper
INFO - 2021-01-14 03:31:53 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:31:53 --> Controller Class Initialized
DEBUG - 2021-01-14 03:31:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:31:53 --> Final output sent to browser
DEBUG - 2021-01-14 03:31:53 --> Total execution time: 0.2434
INFO - 2021-01-14 03:32:42 --> Config Class Initialized
INFO - 2021-01-14 03:32:42 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:32:42 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:32:42 --> Utf8 Class Initialized
INFO - 2021-01-14 03:32:42 --> URI Class Initialized
INFO - 2021-01-14 03:32:42 --> Router Class Initialized
INFO - 2021-01-14 03:32:42 --> Output Class Initialized
INFO - 2021-01-14 03:32:42 --> Security Class Initialized
DEBUG - 2021-01-14 03:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:32:42 --> Input Class Initialized
INFO - 2021-01-14 03:32:42 --> Language Class Initialized
INFO - 2021-01-14 03:32:42 --> Language Class Initialized
INFO - 2021-01-14 03:32:42 --> Config Class Initialized
INFO - 2021-01-14 03:32:42 --> Loader Class Initialized
INFO - 2021-01-14 03:32:42 --> Helper loaded: url_helper
INFO - 2021-01-14 03:32:42 --> Helper loaded: file_helper
INFO - 2021-01-14 03:32:43 --> Helper loaded: form_helper
INFO - 2021-01-14 03:32:43 --> Helper loaded: my_helper
INFO - 2021-01-14 03:32:43 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:32:43 --> Controller Class Initialized
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
ERROR - 2021-01-14 03:32:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 174
DEBUG - 2021-01-14 03:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:32:43 --> Final output sent to browser
DEBUG - 2021-01-14 03:32:43 --> Total execution time: 0.6590
INFO - 2021-01-14 03:33:25 --> Config Class Initialized
INFO - 2021-01-14 03:33:25 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:33:25 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:33:25 --> Utf8 Class Initialized
INFO - 2021-01-14 03:33:25 --> URI Class Initialized
INFO - 2021-01-14 03:33:25 --> Router Class Initialized
INFO - 2021-01-14 03:33:25 --> Output Class Initialized
INFO - 2021-01-14 03:33:25 --> Security Class Initialized
DEBUG - 2021-01-14 03:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:33:25 --> Input Class Initialized
INFO - 2021-01-14 03:33:25 --> Language Class Initialized
INFO - 2021-01-14 03:33:25 --> Language Class Initialized
INFO - 2021-01-14 03:33:25 --> Config Class Initialized
INFO - 2021-01-14 03:33:25 --> Loader Class Initialized
INFO - 2021-01-14 03:33:25 --> Helper loaded: url_helper
INFO - 2021-01-14 03:33:25 --> Helper loaded: file_helper
INFO - 2021-01-14 03:33:25 --> Helper loaded: form_helper
INFO - 2021-01-14 03:33:25 --> Helper loaded: my_helper
INFO - 2021-01-14 03:33:25 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:33:25 --> Controller Class Initialized
DEBUG - 2021-01-14 03:33:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 03:33:25 --> Final output sent to browser
DEBUG - 2021-01-14 03:33:25 --> Total execution time: 0.2566
INFO - 2021-01-14 03:44:33 --> Config Class Initialized
INFO - 2021-01-14 03:44:33 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:44:33 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:44:33 --> Utf8 Class Initialized
INFO - 2021-01-14 03:44:33 --> URI Class Initialized
INFO - 2021-01-14 03:44:33 --> Router Class Initialized
INFO - 2021-01-14 03:44:33 --> Output Class Initialized
INFO - 2021-01-14 03:44:33 --> Security Class Initialized
DEBUG - 2021-01-14 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:44:33 --> Input Class Initialized
INFO - 2021-01-14 03:44:33 --> Language Class Initialized
INFO - 2021-01-14 03:44:33 --> Language Class Initialized
INFO - 2021-01-14 03:44:33 --> Config Class Initialized
INFO - 2021-01-14 03:44:33 --> Loader Class Initialized
INFO - 2021-01-14 03:44:33 --> Helper loaded: url_helper
INFO - 2021-01-14 03:44:33 --> Helper loaded: file_helper
INFO - 2021-01-14 03:44:33 --> Helper loaded: form_helper
INFO - 2021-01-14 03:44:33 --> Helper loaded: my_helper
INFO - 2021-01-14 03:44:33 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:44:33 --> Controller Class Initialized
DEBUG - 2021-01-14 03:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-14 03:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:44:33 --> Final output sent to browser
DEBUG - 2021-01-14 03:44:33 --> Total execution time: 0.3240
INFO - 2021-01-14 03:44:41 --> Config Class Initialized
INFO - 2021-01-14 03:44:41 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:44:41 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:44:41 --> Utf8 Class Initialized
INFO - 2021-01-14 03:44:41 --> URI Class Initialized
INFO - 2021-01-14 03:44:42 --> Router Class Initialized
INFO - 2021-01-14 03:44:42 --> Output Class Initialized
INFO - 2021-01-14 03:44:42 --> Security Class Initialized
DEBUG - 2021-01-14 03:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:44:42 --> Input Class Initialized
INFO - 2021-01-14 03:44:42 --> Language Class Initialized
INFO - 2021-01-14 03:44:42 --> Language Class Initialized
INFO - 2021-01-14 03:44:42 --> Config Class Initialized
INFO - 2021-01-14 03:44:42 --> Loader Class Initialized
INFO - 2021-01-14 03:44:42 --> Helper loaded: url_helper
INFO - 2021-01-14 03:44:42 --> Helper loaded: file_helper
INFO - 2021-01-14 03:44:42 --> Helper loaded: form_helper
INFO - 2021-01-14 03:44:42 --> Helper loaded: my_helper
INFO - 2021-01-14 03:44:42 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:44:42 --> Controller Class Initialized
DEBUG - 2021-01-14 03:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-14 03:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:44:42 --> Final output sent to browser
DEBUG - 2021-01-14 03:44:42 --> Total execution time: 0.2840
INFO - 2021-01-14 03:44:43 --> Config Class Initialized
INFO - 2021-01-14 03:44:43 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:44:43 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:44:43 --> Utf8 Class Initialized
INFO - 2021-01-14 03:44:43 --> URI Class Initialized
INFO - 2021-01-14 03:44:43 --> Router Class Initialized
INFO - 2021-01-14 03:44:43 --> Output Class Initialized
INFO - 2021-01-14 03:44:43 --> Security Class Initialized
DEBUG - 2021-01-14 03:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:44:43 --> Input Class Initialized
INFO - 2021-01-14 03:44:43 --> Language Class Initialized
INFO - 2021-01-14 03:44:43 --> Language Class Initialized
INFO - 2021-01-14 03:44:43 --> Config Class Initialized
INFO - 2021-01-14 03:44:43 --> Loader Class Initialized
INFO - 2021-01-14 03:44:43 --> Helper loaded: url_helper
INFO - 2021-01-14 03:44:43 --> Helper loaded: file_helper
INFO - 2021-01-14 03:44:43 --> Helper loaded: form_helper
INFO - 2021-01-14 03:44:43 --> Helper loaded: my_helper
INFO - 2021-01-14 03:44:43 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:44:43 --> Controller Class Initialized
DEBUG - 2021-01-14 03:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-14 03:44:43 --> Final output sent to browser
DEBUG - 2021-01-14 03:44:43 --> Total execution time: 0.3294
INFO - 2021-01-14 03:50:42 --> Config Class Initialized
INFO - 2021-01-14 03:50:42 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:50:42 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:50:42 --> Utf8 Class Initialized
INFO - 2021-01-14 03:50:42 --> URI Class Initialized
INFO - 2021-01-14 03:50:42 --> Router Class Initialized
INFO - 2021-01-14 03:50:42 --> Output Class Initialized
INFO - 2021-01-14 03:50:42 --> Security Class Initialized
DEBUG - 2021-01-14 03:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:50:42 --> Input Class Initialized
INFO - 2021-01-14 03:50:42 --> Language Class Initialized
INFO - 2021-01-14 03:50:42 --> Language Class Initialized
INFO - 2021-01-14 03:50:42 --> Config Class Initialized
INFO - 2021-01-14 03:50:42 --> Loader Class Initialized
INFO - 2021-01-14 03:50:42 --> Helper loaded: url_helper
INFO - 2021-01-14 03:50:42 --> Helper loaded: file_helper
INFO - 2021-01-14 03:50:42 --> Helper loaded: form_helper
INFO - 2021-01-14 03:50:42 --> Helper loaded: my_helper
INFO - 2021-01-14 03:50:42 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:50:42 --> Controller Class Initialized
INFO - 2021-01-14 03:50:42 --> Helper loaded: cookie_helper
INFO - 2021-01-14 03:50:42 --> Config Class Initialized
INFO - 2021-01-14 03:50:42 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:50:42 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:50:42 --> Utf8 Class Initialized
INFO - 2021-01-14 03:50:42 --> URI Class Initialized
INFO - 2021-01-14 03:50:43 --> Router Class Initialized
INFO - 2021-01-14 03:50:43 --> Output Class Initialized
INFO - 2021-01-14 03:50:43 --> Security Class Initialized
DEBUG - 2021-01-14 03:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:50:43 --> Input Class Initialized
INFO - 2021-01-14 03:50:43 --> Language Class Initialized
INFO - 2021-01-14 03:50:43 --> Language Class Initialized
INFO - 2021-01-14 03:50:43 --> Config Class Initialized
INFO - 2021-01-14 03:50:43 --> Loader Class Initialized
INFO - 2021-01-14 03:50:43 --> Helper loaded: url_helper
INFO - 2021-01-14 03:50:43 --> Helper loaded: file_helper
INFO - 2021-01-14 03:50:43 --> Helper loaded: form_helper
INFO - 2021-01-14 03:50:43 --> Helper loaded: my_helper
INFO - 2021-01-14 03:50:43 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:50:43 --> Controller Class Initialized
DEBUG - 2021-01-14 03:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-14 03:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:50:43 --> Final output sent to browser
DEBUG - 2021-01-14 03:50:43 --> Total execution time: 0.2790
INFO - 2021-01-14 03:50:47 --> Config Class Initialized
INFO - 2021-01-14 03:50:47 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:50:47 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:50:47 --> Utf8 Class Initialized
INFO - 2021-01-14 03:50:47 --> URI Class Initialized
INFO - 2021-01-14 03:50:47 --> Router Class Initialized
INFO - 2021-01-14 03:50:47 --> Output Class Initialized
INFO - 2021-01-14 03:50:47 --> Security Class Initialized
DEBUG - 2021-01-14 03:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:50:47 --> Input Class Initialized
INFO - 2021-01-14 03:50:48 --> Language Class Initialized
INFO - 2021-01-14 03:50:48 --> Language Class Initialized
INFO - 2021-01-14 03:50:48 --> Config Class Initialized
INFO - 2021-01-14 03:50:48 --> Loader Class Initialized
INFO - 2021-01-14 03:50:48 --> Helper loaded: url_helper
INFO - 2021-01-14 03:50:48 --> Helper loaded: file_helper
INFO - 2021-01-14 03:50:48 --> Helper loaded: form_helper
INFO - 2021-01-14 03:50:48 --> Helper loaded: my_helper
INFO - 2021-01-14 03:50:48 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:50:48 --> Controller Class Initialized
INFO - 2021-01-14 03:50:48 --> Helper loaded: cookie_helper
INFO - 2021-01-14 03:50:48 --> Final output sent to browser
DEBUG - 2021-01-14 03:50:48 --> Total execution time: 0.3485
INFO - 2021-01-14 03:50:48 --> Config Class Initialized
INFO - 2021-01-14 03:50:48 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:50:48 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:50:48 --> Utf8 Class Initialized
INFO - 2021-01-14 03:50:48 --> URI Class Initialized
INFO - 2021-01-14 03:50:48 --> Router Class Initialized
INFO - 2021-01-14 03:50:48 --> Output Class Initialized
INFO - 2021-01-14 03:50:48 --> Security Class Initialized
DEBUG - 2021-01-14 03:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:50:48 --> Input Class Initialized
INFO - 2021-01-14 03:50:48 --> Language Class Initialized
INFO - 2021-01-14 03:50:48 --> Language Class Initialized
INFO - 2021-01-14 03:50:48 --> Config Class Initialized
INFO - 2021-01-14 03:50:48 --> Loader Class Initialized
INFO - 2021-01-14 03:50:48 --> Helper loaded: url_helper
INFO - 2021-01-14 03:50:48 --> Helper loaded: file_helper
INFO - 2021-01-14 03:50:48 --> Helper loaded: form_helper
INFO - 2021-01-14 03:50:48 --> Helper loaded: my_helper
INFO - 2021-01-14 03:50:48 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:50:48 --> Controller Class Initialized
DEBUG - 2021-01-14 03:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-14 03:50:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:50:48 --> Final output sent to browser
DEBUG - 2021-01-14 03:50:48 --> Total execution time: 0.4190
INFO - 2021-01-14 03:50:50 --> Config Class Initialized
INFO - 2021-01-14 03:50:50 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:50:50 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:50:50 --> Utf8 Class Initialized
INFO - 2021-01-14 03:50:50 --> URI Class Initialized
INFO - 2021-01-14 03:50:50 --> Router Class Initialized
INFO - 2021-01-14 03:50:50 --> Output Class Initialized
INFO - 2021-01-14 03:50:50 --> Security Class Initialized
DEBUG - 2021-01-14 03:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:50:50 --> Input Class Initialized
INFO - 2021-01-14 03:50:50 --> Language Class Initialized
INFO - 2021-01-14 03:50:51 --> Language Class Initialized
INFO - 2021-01-14 03:50:51 --> Config Class Initialized
INFO - 2021-01-14 03:50:51 --> Loader Class Initialized
INFO - 2021-01-14 03:50:51 --> Helper loaded: url_helper
INFO - 2021-01-14 03:50:51 --> Helper loaded: file_helper
INFO - 2021-01-14 03:50:51 --> Helper loaded: form_helper
INFO - 2021-01-14 03:50:51 --> Helper loaded: my_helper
INFO - 2021-01-14 03:50:51 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:50:51 --> Controller Class Initialized
DEBUG - 2021-01-14 03:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-01-14 03:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:50:51 --> Final output sent to browser
DEBUG - 2021-01-14 03:50:51 --> Total execution time: 0.2910
INFO - 2021-01-14 03:50:52 --> Config Class Initialized
INFO - 2021-01-14 03:50:52 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:50:52 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:50:52 --> Utf8 Class Initialized
INFO - 2021-01-14 03:50:52 --> URI Class Initialized
INFO - 2021-01-14 03:50:52 --> Router Class Initialized
INFO - 2021-01-14 03:50:52 --> Output Class Initialized
INFO - 2021-01-14 03:50:52 --> Security Class Initialized
DEBUG - 2021-01-14 03:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:50:52 --> Input Class Initialized
INFO - 2021-01-14 03:50:52 --> Language Class Initialized
INFO - 2021-01-14 03:50:52 --> Language Class Initialized
INFO - 2021-01-14 03:50:52 --> Config Class Initialized
INFO - 2021-01-14 03:50:52 --> Loader Class Initialized
INFO - 2021-01-14 03:50:52 --> Helper loaded: url_helper
INFO - 2021-01-14 03:50:52 --> Helper loaded: file_helper
INFO - 2021-01-14 03:50:52 --> Helper loaded: form_helper
INFO - 2021-01-14 03:50:52 --> Helper loaded: my_helper
INFO - 2021-01-14 03:50:52 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:50:52 --> Controller Class Initialized
DEBUG - 2021-01-14 03:50:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-01-14 03:50:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:50:52 --> Final output sent to browser
DEBUG - 2021-01-14 03:50:52 --> Total execution time: 0.3079
INFO - 2021-01-14 03:51:07 --> Config Class Initialized
INFO - 2021-01-14 03:51:07 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:51:07 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:51:07 --> Utf8 Class Initialized
INFO - 2021-01-14 03:51:07 --> URI Class Initialized
INFO - 2021-01-14 03:51:07 --> Router Class Initialized
INFO - 2021-01-14 03:51:07 --> Output Class Initialized
INFO - 2021-01-14 03:51:07 --> Security Class Initialized
DEBUG - 2021-01-14 03:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:51:07 --> Input Class Initialized
INFO - 2021-01-14 03:51:07 --> Language Class Initialized
INFO - 2021-01-14 03:51:07 --> Language Class Initialized
INFO - 2021-01-14 03:51:07 --> Config Class Initialized
INFO - 2021-01-14 03:51:07 --> Loader Class Initialized
INFO - 2021-01-14 03:51:07 --> Helper loaded: url_helper
INFO - 2021-01-14 03:51:07 --> Helper loaded: file_helper
INFO - 2021-01-14 03:51:07 --> Helper loaded: form_helper
INFO - 2021-01-14 03:51:07 --> Helper loaded: my_helper
INFO - 2021-01-14 03:51:07 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:51:07 --> Controller Class Initialized
DEBUG - 2021-01-14 03:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-01-14 03:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 03:51:07 --> Final output sent to browser
DEBUG - 2021-01-14 03:51:07 --> Total execution time: 0.2856
INFO - 2021-01-14 03:51:08 --> Config Class Initialized
INFO - 2021-01-14 03:51:08 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:51:08 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:51:08 --> Utf8 Class Initialized
INFO - 2021-01-14 03:51:08 --> URI Class Initialized
INFO - 2021-01-14 03:51:08 --> Router Class Initialized
INFO - 2021-01-14 03:51:08 --> Output Class Initialized
INFO - 2021-01-14 03:51:08 --> Security Class Initialized
DEBUG - 2021-01-14 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:51:08 --> Input Class Initialized
INFO - 2021-01-14 03:51:08 --> Language Class Initialized
INFO - 2021-01-14 03:51:08 --> Language Class Initialized
INFO - 2021-01-14 03:51:08 --> Config Class Initialized
INFO - 2021-01-14 03:51:08 --> Loader Class Initialized
INFO - 2021-01-14 03:51:08 --> Helper loaded: url_helper
INFO - 2021-01-14 03:51:08 --> Helper loaded: file_helper
INFO - 2021-01-14 03:51:08 --> Helper loaded: form_helper
INFO - 2021-01-14 03:51:08 --> Helper loaded: my_helper
INFO - 2021-01-14 03:51:08 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:51:08 --> Controller Class Initialized
INFO - 2021-01-14 03:51:09 --> Config Class Initialized
INFO - 2021-01-14 03:51:09 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:51:09 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:51:09 --> Utf8 Class Initialized
INFO - 2021-01-14 03:51:09 --> URI Class Initialized
INFO - 2021-01-14 03:51:09 --> Router Class Initialized
INFO - 2021-01-14 03:51:09 --> Output Class Initialized
INFO - 2021-01-14 03:51:09 --> Security Class Initialized
DEBUG - 2021-01-14 03:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:51:09 --> Input Class Initialized
INFO - 2021-01-14 03:51:09 --> Language Class Initialized
INFO - 2021-01-14 03:51:09 --> Language Class Initialized
INFO - 2021-01-14 03:51:09 --> Config Class Initialized
INFO - 2021-01-14 03:51:09 --> Loader Class Initialized
INFO - 2021-01-14 03:51:09 --> Helper loaded: url_helper
INFO - 2021-01-14 03:51:09 --> Helper loaded: file_helper
INFO - 2021-01-14 03:51:09 --> Helper loaded: form_helper
INFO - 2021-01-14 03:51:09 --> Helper loaded: my_helper
INFO - 2021-01-14 03:51:09 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:51:09 --> Controller Class Initialized
INFO - 2021-01-14 03:51:09 --> Final output sent to browser
DEBUG - 2021-01-14 03:51:09 --> Total execution time: 0.2916
INFO - 2021-01-14 03:59:23 --> Config Class Initialized
INFO - 2021-01-14 03:59:23 --> Hooks Class Initialized
DEBUG - 2021-01-14 03:59:23 --> UTF-8 Support Enabled
INFO - 2021-01-14 03:59:23 --> Utf8 Class Initialized
INFO - 2021-01-14 03:59:23 --> URI Class Initialized
INFO - 2021-01-14 03:59:23 --> Router Class Initialized
INFO - 2021-01-14 03:59:23 --> Output Class Initialized
INFO - 2021-01-14 03:59:23 --> Security Class Initialized
DEBUG - 2021-01-14 03:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 03:59:23 --> Input Class Initialized
INFO - 2021-01-14 03:59:23 --> Language Class Initialized
INFO - 2021-01-14 03:59:23 --> Language Class Initialized
INFO - 2021-01-14 03:59:23 --> Config Class Initialized
INFO - 2021-01-14 03:59:23 --> Loader Class Initialized
INFO - 2021-01-14 03:59:23 --> Helper loaded: url_helper
INFO - 2021-01-14 03:59:23 --> Helper loaded: file_helper
INFO - 2021-01-14 03:59:23 --> Helper loaded: form_helper
INFO - 2021-01-14 03:59:23 --> Helper loaded: my_helper
INFO - 2021-01-14 03:59:23 --> Database Driver Class Initialized
DEBUG - 2021-01-14 03:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 03:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 03:59:23 --> Controller Class Initialized
ERROR - 2021-01-14 03:59:23 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 37
ERROR - 2021-01-14 03:59:23 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: select
            a.nis, a.nisn, a.nama, a.jk
            from m_siswa a
            inner join t_kelas_siswa b ON a.id = b.id_siswa
            inner join m_kelas c ON b.id_kelas = c.id
            where a.id = '' and a.ta = '2020'
INFO - 2021-01-14 03:59:23 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 04:26:26 --> Config Class Initialized
INFO - 2021-01-14 04:26:26 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:26:26 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:26:26 --> Utf8 Class Initialized
INFO - 2021-01-14 04:26:26 --> URI Class Initialized
INFO - 2021-01-14 04:26:26 --> Router Class Initialized
INFO - 2021-01-14 04:26:26 --> Output Class Initialized
INFO - 2021-01-14 04:26:26 --> Security Class Initialized
DEBUG - 2021-01-14 04:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:26:26 --> Input Class Initialized
INFO - 2021-01-14 04:26:26 --> Language Class Initialized
INFO - 2021-01-14 04:26:26 --> Language Class Initialized
INFO - 2021-01-14 04:26:26 --> Config Class Initialized
INFO - 2021-01-14 04:26:26 --> Loader Class Initialized
INFO - 2021-01-14 04:26:26 --> Helper loaded: url_helper
INFO - 2021-01-14 04:26:26 --> Helper loaded: file_helper
INFO - 2021-01-14 04:26:26 --> Helper loaded: form_helper
INFO - 2021-01-14 04:26:26 --> Helper loaded: my_helper
INFO - 2021-01-14 04:26:26 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:26:26 --> Controller Class Initialized
ERROR - 2021-01-14 04:26:26 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 43
DEBUG - 2021-01-14 04:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:26:26 --> Final output sent to browser
DEBUG - 2021-01-14 04:26:26 --> Total execution time: 0.2586
INFO - 2021-01-14 04:26:40 --> Config Class Initialized
INFO - 2021-01-14 04:26:40 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:26:40 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:26:40 --> Utf8 Class Initialized
INFO - 2021-01-14 04:26:40 --> URI Class Initialized
INFO - 2021-01-14 04:26:40 --> Router Class Initialized
INFO - 2021-01-14 04:26:40 --> Output Class Initialized
INFO - 2021-01-14 04:26:40 --> Security Class Initialized
DEBUG - 2021-01-14 04:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:26:40 --> Input Class Initialized
INFO - 2021-01-14 04:26:40 --> Language Class Initialized
INFO - 2021-01-14 04:26:40 --> Language Class Initialized
INFO - 2021-01-14 04:26:40 --> Config Class Initialized
INFO - 2021-01-14 04:26:40 --> Loader Class Initialized
INFO - 2021-01-14 04:26:40 --> Helper loaded: url_helper
INFO - 2021-01-14 04:26:40 --> Helper loaded: file_helper
INFO - 2021-01-14 04:26:40 --> Helper loaded: form_helper
INFO - 2021-01-14 04:26:40 --> Helper loaded: my_helper
INFO - 2021-01-14 04:26:40 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:26:40 --> Controller Class Initialized
DEBUG - 2021-01-14 04:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:26:40 --> Final output sent to browser
DEBUG - 2021-01-14 04:26:40 --> Total execution time: 0.2531
INFO - 2021-01-14 04:26:59 --> Config Class Initialized
INFO - 2021-01-14 04:26:59 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:26:59 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:26:59 --> Utf8 Class Initialized
INFO - 2021-01-14 04:26:59 --> URI Class Initialized
INFO - 2021-01-14 04:26:59 --> Router Class Initialized
INFO - 2021-01-14 04:26:59 --> Output Class Initialized
INFO - 2021-01-14 04:26:59 --> Security Class Initialized
DEBUG - 2021-01-14 04:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:26:59 --> Input Class Initialized
INFO - 2021-01-14 04:26:59 --> Language Class Initialized
INFO - 2021-01-14 04:26:59 --> Language Class Initialized
INFO - 2021-01-14 04:26:59 --> Config Class Initialized
INFO - 2021-01-14 04:26:59 --> Loader Class Initialized
INFO - 2021-01-14 04:26:59 --> Helper loaded: url_helper
INFO - 2021-01-14 04:26:59 --> Helper loaded: file_helper
INFO - 2021-01-14 04:26:59 --> Helper loaded: form_helper
INFO - 2021-01-14 04:26:59 --> Helper loaded: my_helper
INFO - 2021-01-14 04:26:59 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:26:59 --> Controller Class Initialized
DEBUG - 2021-01-14 04:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:26:59 --> Final output sent to browser
DEBUG - 2021-01-14 04:26:59 --> Total execution time: 0.2361
INFO - 2021-01-14 04:27:05 --> Config Class Initialized
INFO - 2021-01-14 04:27:05 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:27:05 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:27:05 --> Utf8 Class Initialized
INFO - 2021-01-14 04:27:05 --> URI Class Initialized
INFO - 2021-01-14 04:27:05 --> Router Class Initialized
INFO - 2021-01-14 04:27:05 --> Output Class Initialized
INFO - 2021-01-14 04:27:05 --> Security Class Initialized
DEBUG - 2021-01-14 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:27:05 --> Input Class Initialized
INFO - 2021-01-14 04:27:05 --> Language Class Initialized
INFO - 2021-01-14 04:27:05 --> Language Class Initialized
INFO - 2021-01-14 04:27:05 --> Config Class Initialized
INFO - 2021-01-14 04:27:05 --> Loader Class Initialized
INFO - 2021-01-14 04:27:05 --> Helper loaded: url_helper
INFO - 2021-01-14 04:27:05 --> Helper loaded: file_helper
INFO - 2021-01-14 04:27:05 --> Helper loaded: form_helper
INFO - 2021-01-14 04:27:05 --> Helper loaded: my_helper
INFO - 2021-01-14 04:27:05 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:27:05 --> Controller Class Initialized
INFO - 2021-01-14 04:27:05 --> Helper loaded: cookie_helper
INFO - 2021-01-14 04:27:05 --> Config Class Initialized
INFO - 2021-01-14 04:27:05 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:27:05 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:27:05 --> Utf8 Class Initialized
INFO - 2021-01-14 04:27:05 --> URI Class Initialized
INFO - 2021-01-14 04:27:05 --> Router Class Initialized
INFO - 2021-01-14 04:27:05 --> Output Class Initialized
INFO - 2021-01-14 04:27:05 --> Security Class Initialized
DEBUG - 2021-01-14 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:27:05 --> Input Class Initialized
INFO - 2021-01-14 04:27:05 --> Language Class Initialized
INFO - 2021-01-14 04:27:05 --> Language Class Initialized
INFO - 2021-01-14 04:27:05 --> Config Class Initialized
INFO - 2021-01-14 04:27:05 --> Loader Class Initialized
INFO - 2021-01-14 04:27:05 --> Helper loaded: url_helper
INFO - 2021-01-14 04:27:05 --> Helper loaded: file_helper
INFO - 2021-01-14 04:27:05 --> Helper loaded: form_helper
INFO - 2021-01-14 04:27:05 --> Helper loaded: my_helper
INFO - 2021-01-14 04:27:05 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:27:05 --> Controller Class Initialized
DEBUG - 2021-01-14 04:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-14 04:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 04:27:05 --> Final output sent to browser
DEBUG - 2021-01-14 04:27:05 --> Total execution time: 0.2782
INFO - 2021-01-14 04:27:10 --> Config Class Initialized
INFO - 2021-01-14 04:27:10 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:27:10 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:27:10 --> Utf8 Class Initialized
INFO - 2021-01-14 04:27:10 --> URI Class Initialized
INFO - 2021-01-14 04:27:10 --> Router Class Initialized
INFO - 2021-01-14 04:27:10 --> Output Class Initialized
INFO - 2021-01-14 04:27:10 --> Security Class Initialized
DEBUG - 2021-01-14 04:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:27:10 --> Input Class Initialized
INFO - 2021-01-14 04:27:10 --> Language Class Initialized
INFO - 2021-01-14 04:27:10 --> Language Class Initialized
INFO - 2021-01-14 04:27:10 --> Config Class Initialized
INFO - 2021-01-14 04:27:10 --> Loader Class Initialized
INFO - 2021-01-14 04:27:10 --> Helper loaded: url_helper
INFO - 2021-01-14 04:27:10 --> Helper loaded: file_helper
INFO - 2021-01-14 04:27:10 --> Helper loaded: form_helper
INFO - 2021-01-14 04:27:10 --> Helper loaded: my_helper
INFO - 2021-01-14 04:27:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:27:10 --> Controller Class Initialized
INFO - 2021-01-14 04:27:10 --> Helper loaded: cookie_helper
INFO - 2021-01-14 04:27:10 --> Final output sent to browser
DEBUG - 2021-01-14 04:27:10 --> Total execution time: 0.3134
INFO - 2021-01-14 04:27:11 --> Config Class Initialized
INFO - 2021-01-14 04:27:11 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:27:11 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:27:11 --> Utf8 Class Initialized
INFO - 2021-01-14 04:27:11 --> URI Class Initialized
INFO - 2021-01-14 04:27:11 --> Router Class Initialized
INFO - 2021-01-14 04:27:11 --> Output Class Initialized
INFO - 2021-01-14 04:27:11 --> Security Class Initialized
DEBUG - 2021-01-14 04:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:27:11 --> Input Class Initialized
INFO - 2021-01-14 04:27:11 --> Language Class Initialized
INFO - 2021-01-14 04:27:11 --> Language Class Initialized
INFO - 2021-01-14 04:27:11 --> Config Class Initialized
INFO - 2021-01-14 04:27:11 --> Loader Class Initialized
INFO - 2021-01-14 04:27:11 --> Helper loaded: url_helper
INFO - 2021-01-14 04:27:11 --> Helper loaded: file_helper
INFO - 2021-01-14 04:27:11 --> Helper loaded: form_helper
INFO - 2021-01-14 04:27:11 --> Helper loaded: my_helper
INFO - 2021-01-14 04:27:11 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:27:11 --> Controller Class Initialized
DEBUG - 2021-01-14 04:27:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-14 04:27:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 04:27:11 --> Final output sent to browser
DEBUG - 2021-01-14 04:27:11 --> Total execution time: 0.4297
INFO - 2021-01-14 04:27:12 --> Config Class Initialized
INFO - 2021-01-14 04:27:12 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:27:12 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:27:12 --> Utf8 Class Initialized
INFO - 2021-01-14 04:27:12 --> URI Class Initialized
INFO - 2021-01-14 04:27:12 --> Router Class Initialized
INFO - 2021-01-14 04:27:12 --> Output Class Initialized
INFO - 2021-01-14 04:27:12 --> Security Class Initialized
DEBUG - 2021-01-14 04:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:27:12 --> Input Class Initialized
INFO - 2021-01-14 04:27:12 --> Language Class Initialized
INFO - 2021-01-14 04:27:12 --> Language Class Initialized
INFO - 2021-01-14 04:27:12 --> Config Class Initialized
INFO - 2021-01-14 04:27:12 --> Loader Class Initialized
INFO - 2021-01-14 04:27:12 --> Helper loaded: url_helper
INFO - 2021-01-14 04:27:12 --> Helper loaded: file_helper
INFO - 2021-01-14 04:27:12 --> Helper loaded: form_helper
INFO - 2021-01-14 04:27:12 --> Helper loaded: my_helper
INFO - 2021-01-14 04:27:12 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:27:12 --> Controller Class Initialized
DEBUG - 2021-01-14 04:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-14 04:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 04:27:12 --> Final output sent to browser
DEBUG - 2021-01-14 04:27:12 --> Total execution time: 0.3246
INFO - 2021-01-14 04:27:13 --> Config Class Initialized
INFO - 2021-01-14 04:27:13 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:27:13 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:27:13 --> Utf8 Class Initialized
INFO - 2021-01-14 04:27:13 --> URI Class Initialized
INFO - 2021-01-14 04:27:13 --> Router Class Initialized
INFO - 2021-01-14 04:27:13 --> Output Class Initialized
INFO - 2021-01-14 04:27:13 --> Security Class Initialized
DEBUG - 2021-01-14 04:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:27:13 --> Input Class Initialized
INFO - 2021-01-14 04:27:13 --> Language Class Initialized
INFO - 2021-01-14 04:27:13 --> Language Class Initialized
INFO - 2021-01-14 04:27:13 --> Config Class Initialized
INFO - 2021-01-14 04:27:13 --> Loader Class Initialized
INFO - 2021-01-14 04:27:13 --> Helper loaded: url_helper
INFO - 2021-01-14 04:27:13 --> Helper loaded: file_helper
INFO - 2021-01-14 04:27:13 --> Helper loaded: form_helper
INFO - 2021-01-14 04:27:13 --> Helper loaded: my_helper
INFO - 2021-01-14 04:27:13 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:27:13 --> Controller Class Initialized
DEBUG - 2021-01-14 04:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:27:13 --> Final output sent to browser
DEBUG - 2021-01-14 04:27:13 --> Total execution time: 0.2777
INFO - 2021-01-14 04:29:26 --> Config Class Initialized
INFO - 2021-01-14 04:29:26 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:29:26 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:29:26 --> Utf8 Class Initialized
INFO - 2021-01-14 04:29:26 --> URI Class Initialized
INFO - 2021-01-14 04:29:26 --> Router Class Initialized
INFO - 2021-01-14 04:29:26 --> Output Class Initialized
INFO - 2021-01-14 04:29:26 --> Security Class Initialized
DEBUG - 2021-01-14 04:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:29:26 --> Input Class Initialized
INFO - 2021-01-14 04:29:26 --> Language Class Initialized
INFO - 2021-01-14 04:29:26 --> Language Class Initialized
INFO - 2021-01-14 04:29:26 --> Config Class Initialized
INFO - 2021-01-14 04:29:26 --> Loader Class Initialized
INFO - 2021-01-14 04:29:26 --> Helper loaded: url_helper
INFO - 2021-01-14 04:29:26 --> Helper loaded: file_helper
INFO - 2021-01-14 04:29:26 --> Helper loaded: form_helper
INFO - 2021-01-14 04:29:26 --> Helper loaded: my_helper
INFO - 2021-01-14 04:29:26 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:29:26 --> Controller Class Initialized
DEBUG - 2021-01-14 04:29:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:29:26 --> Final output sent to browser
DEBUG - 2021-01-14 04:29:26 --> Total execution time: 0.2483
INFO - 2021-01-14 04:30:29 --> Config Class Initialized
INFO - 2021-01-14 04:30:29 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:30:29 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:30:29 --> Utf8 Class Initialized
INFO - 2021-01-14 04:30:29 --> URI Class Initialized
INFO - 2021-01-14 04:30:29 --> Router Class Initialized
INFO - 2021-01-14 04:30:29 --> Output Class Initialized
INFO - 2021-01-14 04:30:29 --> Security Class Initialized
DEBUG - 2021-01-14 04:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:30:29 --> Input Class Initialized
INFO - 2021-01-14 04:30:29 --> Language Class Initialized
INFO - 2021-01-14 04:30:29 --> Language Class Initialized
INFO - 2021-01-14 04:30:29 --> Config Class Initialized
INFO - 2021-01-14 04:30:29 --> Loader Class Initialized
INFO - 2021-01-14 04:30:29 --> Helper loaded: url_helper
INFO - 2021-01-14 04:30:29 --> Helper loaded: file_helper
INFO - 2021-01-14 04:30:29 --> Helper loaded: form_helper
INFO - 2021-01-14 04:30:29 --> Helper loaded: my_helper
INFO - 2021-01-14 04:30:29 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:30:29 --> Controller Class Initialized
DEBUG - 2021-01-14 04:30:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:30:29 --> Final output sent to browser
DEBUG - 2021-01-14 04:30:29 --> Total execution time: 0.2341
INFO - 2021-01-14 04:31:11 --> Config Class Initialized
INFO - 2021-01-14 04:31:11 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:31:11 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:31:11 --> Utf8 Class Initialized
INFO - 2021-01-14 04:31:11 --> URI Class Initialized
INFO - 2021-01-14 04:31:11 --> Router Class Initialized
INFO - 2021-01-14 04:31:11 --> Output Class Initialized
INFO - 2021-01-14 04:31:11 --> Security Class Initialized
DEBUG - 2021-01-14 04:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:31:11 --> Input Class Initialized
INFO - 2021-01-14 04:31:11 --> Language Class Initialized
INFO - 2021-01-14 04:31:11 --> Language Class Initialized
INFO - 2021-01-14 04:31:11 --> Config Class Initialized
INFO - 2021-01-14 04:31:11 --> Loader Class Initialized
INFO - 2021-01-14 04:31:11 --> Helper loaded: url_helper
INFO - 2021-01-14 04:31:11 --> Helper loaded: file_helper
INFO - 2021-01-14 04:31:11 --> Helper loaded: form_helper
INFO - 2021-01-14 04:31:11 --> Helper loaded: my_helper
INFO - 2021-01-14 04:31:11 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:31:11 --> Controller Class Initialized
DEBUG - 2021-01-14 04:31:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:31:11 --> Final output sent to browser
DEBUG - 2021-01-14 04:31:11 --> Total execution time: 0.2376
INFO - 2021-01-14 04:33:46 --> Config Class Initialized
INFO - 2021-01-14 04:33:46 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:33:46 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:33:46 --> Utf8 Class Initialized
INFO - 2021-01-14 04:33:46 --> URI Class Initialized
INFO - 2021-01-14 04:33:46 --> Router Class Initialized
INFO - 2021-01-14 04:33:46 --> Output Class Initialized
INFO - 2021-01-14 04:33:46 --> Security Class Initialized
DEBUG - 2021-01-14 04:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:33:46 --> Input Class Initialized
INFO - 2021-01-14 04:33:46 --> Language Class Initialized
INFO - 2021-01-14 04:33:46 --> Language Class Initialized
INFO - 2021-01-14 04:33:46 --> Config Class Initialized
INFO - 2021-01-14 04:33:46 --> Loader Class Initialized
INFO - 2021-01-14 04:33:46 --> Helper loaded: url_helper
INFO - 2021-01-14 04:33:46 --> Helper loaded: file_helper
INFO - 2021-01-14 04:33:46 --> Helper loaded: form_helper
INFO - 2021-01-14 04:33:46 --> Helper loaded: my_helper
INFO - 2021-01-14 04:33:46 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:33:47 --> Controller Class Initialized
DEBUG - 2021-01-14 04:33:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-14 04:33:47 --> Final output sent to browser
DEBUG - 2021-01-14 04:33:47 --> Total execution time: 0.2390
INFO - 2021-01-14 04:33:49 --> Config Class Initialized
INFO - 2021-01-14 04:33:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:33:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:33:49 --> Utf8 Class Initialized
INFO - 2021-01-14 04:33:49 --> URI Class Initialized
INFO - 2021-01-14 04:33:49 --> Router Class Initialized
INFO - 2021-01-14 04:33:49 --> Output Class Initialized
INFO - 2021-01-14 04:33:49 --> Security Class Initialized
DEBUG - 2021-01-14 04:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:33:49 --> Input Class Initialized
INFO - 2021-01-14 04:33:49 --> Language Class Initialized
INFO - 2021-01-14 04:33:49 --> Language Class Initialized
INFO - 2021-01-14 04:33:49 --> Config Class Initialized
INFO - 2021-01-14 04:33:49 --> Loader Class Initialized
INFO - 2021-01-14 04:33:49 --> Helper loaded: url_helper
INFO - 2021-01-14 04:33:49 --> Helper loaded: file_helper
INFO - 2021-01-14 04:33:49 --> Helper loaded: form_helper
INFO - 2021-01-14 04:33:49 --> Helper loaded: my_helper
INFO - 2021-01-14 04:33:49 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:33:49 --> Controller Class Initialized
DEBUG - 2021-01-14 04:33:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:33:49 --> Final output sent to browser
DEBUG - 2021-01-14 04:33:49 --> Total execution time: 0.2455
INFO - 2021-01-14 04:33:52 --> Config Class Initialized
INFO - 2021-01-14 04:33:52 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:33:52 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:33:52 --> Utf8 Class Initialized
INFO - 2021-01-14 04:33:52 --> URI Class Initialized
INFO - 2021-01-14 04:33:52 --> Router Class Initialized
INFO - 2021-01-14 04:33:52 --> Output Class Initialized
INFO - 2021-01-14 04:33:52 --> Security Class Initialized
DEBUG - 2021-01-14 04:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:33:52 --> Input Class Initialized
INFO - 2021-01-14 04:33:52 --> Language Class Initialized
INFO - 2021-01-14 04:33:52 --> Language Class Initialized
INFO - 2021-01-14 04:33:52 --> Config Class Initialized
INFO - 2021-01-14 04:33:52 --> Loader Class Initialized
INFO - 2021-01-14 04:33:52 --> Helper loaded: url_helper
INFO - 2021-01-14 04:33:52 --> Helper loaded: file_helper
INFO - 2021-01-14 04:33:52 --> Helper loaded: form_helper
INFO - 2021-01-14 04:33:52 --> Helper loaded: my_helper
INFO - 2021-01-14 04:33:52 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:33:52 --> Controller Class Initialized
DEBUG - 2021-01-14 04:33:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:33:52 --> Final output sent to browser
DEBUG - 2021-01-14 04:33:52 --> Total execution time: 0.2495
INFO - 2021-01-14 04:34:34 --> Config Class Initialized
INFO - 2021-01-14 04:34:34 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:34:34 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:34:34 --> Utf8 Class Initialized
INFO - 2021-01-14 04:34:34 --> URI Class Initialized
INFO - 2021-01-14 04:34:34 --> Router Class Initialized
INFO - 2021-01-14 04:34:34 --> Output Class Initialized
INFO - 2021-01-14 04:34:34 --> Security Class Initialized
DEBUG - 2021-01-14 04:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:34:34 --> Input Class Initialized
INFO - 2021-01-14 04:34:34 --> Language Class Initialized
INFO - 2021-01-14 04:34:34 --> Language Class Initialized
INFO - 2021-01-14 04:34:34 --> Config Class Initialized
INFO - 2021-01-14 04:34:34 --> Loader Class Initialized
INFO - 2021-01-14 04:34:34 --> Helper loaded: url_helper
INFO - 2021-01-14 04:34:34 --> Helper loaded: file_helper
INFO - 2021-01-14 04:34:34 --> Helper loaded: form_helper
INFO - 2021-01-14 04:34:34 --> Helper loaded: my_helper
INFO - 2021-01-14 04:34:34 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:34:34 --> Controller Class Initialized
DEBUG - 2021-01-14 04:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:34:35 --> Final output sent to browser
DEBUG - 2021-01-14 04:34:35 --> Total execution time: 0.2421
INFO - 2021-01-14 04:35:22 --> Config Class Initialized
INFO - 2021-01-14 04:35:22 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:35:22 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:35:22 --> Utf8 Class Initialized
INFO - 2021-01-14 04:35:22 --> URI Class Initialized
INFO - 2021-01-14 04:35:22 --> Router Class Initialized
INFO - 2021-01-14 04:35:22 --> Output Class Initialized
INFO - 2021-01-14 04:35:22 --> Security Class Initialized
DEBUG - 2021-01-14 04:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:35:22 --> Input Class Initialized
INFO - 2021-01-14 04:35:22 --> Language Class Initialized
INFO - 2021-01-14 04:35:22 --> Language Class Initialized
INFO - 2021-01-14 04:35:22 --> Config Class Initialized
INFO - 2021-01-14 04:35:22 --> Loader Class Initialized
INFO - 2021-01-14 04:35:22 --> Helper loaded: url_helper
INFO - 2021-01-14 04:35:22 --> Helper loaded: file_helper
INFO - 2021-01-14 04:35:22 --> Helper loaded: form_helper
INFO - 2021-01-14 04:35:22 --> Helper loaded: my_helper
INFO - 2021-01-14 04:35:22 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:35:22 --> Controller Class Initialized
DEBUG - 2021-01-14 04:35:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:35:22 --> Final output sent to browser
DEBUG - 2021-01-14 04:35:23 --> Total execution time: 0.2355
INFO - 2021-01-14 04:36:15 --> Config Class Initialized
INFO - 2021-01-14 04:36:15 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:36:15 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:36:15 --> Utf8 Class Initialized
INFO - 2021-01-14 04:36:15 --> URI Class Initialized
INFO - 2021-01-14 04:36:15 --> Router Class Initialized
INFO - 2021-01-14 04:36:15 --> Output Class Initialized
INFO - 2021-01-14 04:36:15 --> Security Class Initialized
DEBUG - 2021-01-14 04:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:36:15 --> Input Class Initialized
INFO - 2021-01-14 04:36:15 --> Language Class Initialized
INFO - 2021-01-14 04:36:15 --> Language Class Initialized
INFO - 2021-01-14 04:36:15 --> Config Class Initialized
INFO - 2021-01-14 04:36:15 --> Loader Class Initialized
INFO - 2021-01-14 04:36:15 --> Helper loaded: url_helper
INFO - 2021-01-14 04:36:15 --> Helper loaded: file_helper
INFO - 2021-01-14 04:36:15 --> Helper loaded: form_helper
INFO - 2021-01-14 04:36:15 --> Helper loaded: my_helper
INFO - 2021-01-14 04:36:15 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:36:15 --> Controller Class Initialized
DEBUG - 2021-01-14 04:36:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:36:15 --> Final output sent to browser
DEBUG - 2021-01-14 04:36:15 --> Total execution time: 0.2346
INFO - 2021-01-14 04:37:10 --> Config Class Initialized
INFO - 2021-01-14 04:37:10 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:37:10 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:37:10 --> Utf8 Class Initialized
INFO - 2021-01-14 04:37:10 --> URI Class Initialized
INFO - 2021-01-14 04:37:10 --> Router Class Initialized
INFO - 2021-01-14 04:37:10 --> Output Class Initialized
INFO - 2021-01-14 04:37:10 --> Security Class Initialized
DEBUG - 2021-01-14 04:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:37:10 --> Input Class Initialized
INFO - 2021-01-14 04:37:10 --> Language Class Initialized
INFO - 2021-01-14 04:37:10 --> Language Class Initialized
INFO - 2021-01-14 04:37:10 --> Config Class Initialized
INFO - 2021-01-14 04:37:10 --> Loader Class Initialized
INFO - 2021-01-14 04:37:10 --> Helper loaded: url_helper
INFO - 2021-01-14 04:37:10 --> Helper loaded: file_helper
INFO - 2021-01-14 04:37:10 --> Helper loaded: form_helper
INFO - 2021-01-14 04:37:10 --> Helper loaded: my_helper
INFO - 2021-01-14 04:37:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:37:10 --> Controller Class Initialized
DEBUG - 2021-01-14 04:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:37:10 --> Final output sent to browser
DEBUG - 2021-01-14 04:37:10 --> Total execution time: 0.2447
INFO - 2021-01-14 04:40:59 --> Config Class Initialized
INFO - 2021-01-14 04:40:59 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:40:59 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:40:59 --> Utf8 Class Initialized
INFO - 2021-01-14 04:40:59 --> URI Class Initialized
INFO - 2021-01-14 04:40:59 --> Router Class Initialized
INFO - 2021-01-14 04:40:59 --> Output Class Initialized
INFO - 2021-01-14 04:40:59 --> Security Class Initialized
DEBUG - 2021-01-14 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:40:59 --> Input Class Initialized
INFO - 2021-01-14 04:40:59 --> Language Class Initialized
INFO - 2021-01-14 04:40:59 --> Language Class Initialized
INFO - 2021-01-14 04:40:59 --> Config Class Initialized
INFO - 2021-01-14 04:40:59 --> Loader Class Initialized
INFO - 2021-01-14 04:40:59 --> Helper loaded: url_helper
INFO - 2021-01-14 04:40:59 --> Helper loaded: file_helper
INFO - 2021-01-14 04:40:59 --> Helper loaded: form_helper
INFO - 2021-01-14 04:40:59 --> Helper loaded: my_helper
INFO - 2021-01-14 04:40:59 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:40:59 --> Controller Class Initialized
DEBUG - 2021-01-14 04:40:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:40:59 --> Final output sent to browser
DEBUG - 2021-01-14 04:40:59 --> Total execution time: 0.2514
INFO - 2021-01-14 04:41:54 --> Config Class Initialized
INFO - 2021-01-14 04:41:54 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:41:54 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:41:54 --> Utf8 Class Initialized
INFO - 2021-01-14 04:41:54 --> URI Class Initialized
INFO - 2021-01-14 04:41:54 --> Router Class Initialized
INFO - 2021-01-14 04:41:54 --> Output Class Initialized
INFO - 2021-01-14 04:41:54 --> Security Class Initialized
DEBUG - 2021-01-14 04:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:41:54 --> Input Class Initialized
INFO - 2021-01-14 04:41:54 --> Language Class Initialized
INFO - 2021-01-14 04:41:54 --> Language Class Initialized
INFO - 2021-01-14 04:41:54 --> Config Class Initialized
INFO - 2021-01-14 04:41:54 --> Loader Class Initialized
INFO - 2021-01-14 04:41:55 --> Helper loaded: url_helper
INFO - 2021-01-14 04:41:55 --> Helper loaded: file_helper
INFO - 2021-01-14 04:41:55 --> Helper loaded: form_helper
INFO - 2021-01-14 04:41:55 --> Helper loaded: my_helper
INFO - 2021-01-14 04:41:55 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:41:55 --> Controller Class Initialized
DEBUG - 2021-01-14 04:41:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:41:55 --> Final output sent to browser
DEBUG - 2021-01-14 04:41:55 --> Total execution time: 0.2544
INFO - 2021-01-14 04:42:16 --> Config Class Initialized
INFO - 2021-01-14 04:42:16 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:42:16 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:42:16 --> Utf8 Class Initialized
INFO - 2021-01-14 04:42:16 --> URI Class Initialized
INFO - 2021-01-14 04:42:16 --> Router Class Initialized
INFO - 2021-01-14 04:42:16 --> Output Class Initialized
INFO - 2021-01-14 04:42:16 --> Security Class Initialized
DEBUG - 2021-01-14 04:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:42:16 --> Input Class Initialized
INFO - 2021-01-14 04:42:16 --> Language Class Initialized
INFO - 2021-01-14 04:42:16 --> Language Class Initialized
INFO - 2021-01-14 04:42:16 --> Config Class Initialized
INFO - 2021-01-14 04:42:16 --> Loader Class Initialized
INFO - 2021-01-14 04:42:16 --> Helper loaded: url_helper
INFO - 2021-01-14 04:42:16 --> Helper loaded: file_helper
INFO - 2021-01-14 04:42:16 --> Helper loaded: form_helper
INFO - 2021-01-14 04:42:16 --> Helper loaded: my_helper
INFO - 2021-01-14 04:42:16 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:42:16 --> Controller Class Initialized
DEBUG - 2021-01-14 04:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:42:16 --> Final output sent to browser
DEBUG - 2021-01-14 04:42:16 --> Total execution time: 0.2490
INFO - 2021-01-14 04:42:22 --> Config Class Initialized
INFO - 2021-01-14 04:42:22 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:42:22 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:42:22 --> Utf8 Class Initialized
INFO - 2021-01-14 04:42:22 --> URI Class Initialized
INFO - 2021-01-14 04:42:22 --> Router Class Initialized
INFO - 2021-01-14 04:42:22 --> Output Class Initialized
INFO - 2021-01-14 04:42:22 --> Security Class Initialized
DEBUG - 2021-01-14 04:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:42:22 --> Input Class Initialized
INFO - 2021-01-14 04:42:22 --> Language Class Initialized
INFO - 2021-01-14 04:42:22 --> Language Class Initialized
INFO - 2021-01-14 04:42:22 --> Config Class Initialized
INFO - 2021-01-14 04:42:22 --> Loader Class Initialized
INFO - 2021-01-14 04:42:22 --> Helper loaded: url_helper
INFO - 2021-01-14 04:42:23 --> Helper loaded: file_helper
INFO - 2021-01-14 04:42:23 --> Helper loaded: form_helper
INFO - 2021-01-14 04:42:23 --> Helper loaded: my_helper
INFO - 2021-01-14 04:42:23 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:42:23 --> Controller Class Initialized
DEBUG - 2021-01-14 04:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:42:23 --> Final output sent to browser
DEBUG - 2021-01-14 04:42:23 --> Total execution time: 0.2560
INFO - 2021-01-14 04:42:45 --> Config Class Initialized
INFO - 2021-01-14 04:42:45 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:42:45 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:42:45 --> Utf8 Class Initialized
INFO - 2021-01-14 04:42:45 --> URI Class Initialized
INFO - 2021-01-14 04:42:45 --> Router Class Initialized
INFO - 2021-01-14 04:42:45 --> Output Class Initialized
INFO - 2021-01-14 04:42:45 --> Security Class Initialized
DEBUG - 2021-01-14 04:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:42:45 --> Input Class Initialized
INFO - 2021-01-14 04:42:45 --> Language Class Initialized
INFO - 2021-01-14 04:42:45 --> Language Class Initialized
INFO - 2021-01-14 04:42:45 --> Config Class Initialized
INFO - 2021-01-14 04:42:45 --> Loader Class Initialized
INFO - 2021-01-14 04:42:45 --> Helper loaded: url_helper
INFO - 2021-01-14 04:42:45 --> Helper loaded: file_helper
INFO - 2021-01-14 04:42:45 --> Helper loaded: form_helper
INFO - 2021-01-14 04:42:45 --> Helper loaded: my_helper
INFO - 2021-01-14 04:42:45 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:42:45 --> Controller Class Initialized
DEBUG - 2021-01-14 04:42:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:42:45 --> Final output sent to browser
DEBUG - 2021-01-14 04:42:45 --> Total execution time: 0.2983
INFO - 2021-01-14 04:43:14 --> Config Class Initialized
INFO - 2021-01-14 04:43:14 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:43:14 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:43:14 --> Utf8 Class Initialized
INFO - 2021-01-14 04:43:14 --> URI Class Initialized
INFO - 2021-01-14 04:43:14 --> Router Class Initialized
INFO - 2021-01-14 04:43:14 --> Output Class Initialized
INFO - 2021-01-14 04:43:14 --> Security Class Initialized
DEBUG - 2021-01-14 04:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:43:14 --> Input Class Initialized
INFO - 2021-01-14 04:43:14 --> Language Class Initialized
INFO - 2021-01-14 04:43:14 --> Language Class Initialized
INFO - 2021-01-14 04:43:14 --> Config Class Initialized
INFO - 2021-01-14 04:43:14 --> Loader Class Initialized
INFO - 2021-01-14 04:43:14 --> Helper loaded: url_helper
INFO - 2021-01-14 04:43:14 --> Helper loaded: file_helper
INFO - 2021-01-14 04:43:15 --> Helper loaded: form_helper
INFO - 2021-01-14 04:43:15 --> Helper loaded: my_helper
INFO - 2021-01-14 04:43:15 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:43:15 --> Controller Class Initialized
DEBUG - 2021-01-14 04:43:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:43:15 --> Final output sent to browser
DEBUG - 2021-01-14 04:43:15 --> Total execution time: 0.2605
INFO - 2021-01-14 04:52:58 --> Config Class Initialized
INFO - 2021-01-14 04:52:58 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:52:58 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:52:58 --> Utf8 Class Initialized
INFO - 2021-01-14 04:52:58 --> URI Class Initialized
INFO - 2021-01-14 04:52:58 --> Router Class Initialized
INFO - 2021-01-14 04:52:58 --> Output Class Initialized
INFO - 2021-01-14 04:52:58 --> Security Class Initialized
DEBUG - 2021-01-14 04:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:52:58 --> Input Class Initialized
INFO - 2021-01-14 04:52:58 --> Language Class Initialized
INFO - 2021-01-14 04:52:58 --> Language Class Initialized
INFO - 2021-01-14 04:52:58 --> Config Class Initialized
INFO - 2021-01-14 04:52:58 --> Loader Class Initialized
INFO - 2021-01-14 04:52:58 --> Helper loaded: url_helper
INFO - 2021-01-14 04:52:58 --> Helper loaded: file_helper
INFO - 2021-01-14 04:52:58 --> Helper loaded: form_helper
INFO - 2021-01-14 04:52:58 --> Helper loaded: my_helper
INFO - 2021-01-14 04:52:58 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:52:58 --> Controller Class Initialized
ERROR - 2021-01-14 04:52:58 --> Severity: Notice --> Undefined index: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 43
DEBUG - 2021-01-14 04:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:52:58 --> Final output sent to browser
DEBUG - 2021-01-14 04:52:58 --> Total execution time: 0.2795
INFO - 2021-01-14 04:55:55 --> Config Class Initialized
INFO - 2021-01-14 04:55:55 --> Hooks Class Initialized
DEBUG - 2021-01-14 04:55:55 --> UTF-8 Support Enabled
INFO - 2021-01-14 04:55:55 --> Utf8 Class Initialized
INFO - 2021-01-14 04:55:55 --> URI Class Initialized
INFO - 2021-01-14 04:55:55 --> Router Class Initialized
INFO - 2021-01-14 04:55:55 --> Output Class Initialized
INFO - 2021-01-14 04:55:55 --> Security Class Initialized
DEBUG - 2021-01-14 04:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 04:55:55 --> Input Class Initialized
INFO - 2021-01-14 04:55:55 --> Language Class Initialized
INFO - 2021-01-14 04:55:55 --> Language Class Initialized
INFO - 2021-01-14 04:55:55 --> Config Class Initialized
INFO - 2021-01-14 04:55:55 --> Loader Class Initialized
INFO - 2021-01-14 04:55:55 --> Helper loaded: url_helper
INFO - 2021-01-14 04:55:55 --> Helper loaded: file_helper
INFO - 2021-01-14 04:55:55 --> Helper loaded: form_helper
INFO - 2021-01-14 04:55:55 --> Helper loaded: my_helper
INFO - 2021-01-14 04:55:55 --> Database Driver Class Initialized
DEBUG - 2021-01-14 04:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 04:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 04:55:55 --> Controller Class Initialized
ERROR - 2021-01-14 04:55:55 --> Severity: Notice --> Undefined index: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 43
DEBUG - 2021-01-14 04:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 04:55:55 --> Final output sent to browser
DEBUG - 2021-01-14 04:55:55 --> Total execution time: 0.2681
INFO - 2021-01-14 07:46:17 --> Config Class Initialized
INFO - 2021-01-14 07:46:17 --> Hooks Class Initialized
DEBUG - 2021-01-14 07:46:17 --> UTF-8 Support Enabled
INFO - 2021-01-14 07:46:17 --> Utf8 Class Initialized
INFO - 2021-01-14 07:46:17 --> URI Class Initialized
INFO - 2021-01-14 07:46:17 --> Router Class Initialized
INFO - 2021-01-14 07:46:17 --> Output Class Initialized
INFO - 2021-01-14 07:46:17 --> Security Class Initialized
DEBUG - 2021-01-14 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 07:46:17 --> Input Class Initialized
INFO - 2021-01-14 07:46:17 --> Language Class Initialized
INFO - 2021-01-14 07:46:17 --> Language Class Initialized
INFO - 2021-01-14 07:46:17 --> Config Class Initialized
INFO - 2021-01-14 07:46:17 --> Loader Class Initialized
INFO - 2021-01-14 07:46:17 --> Helper loaded: url_helper
INFO - 2021-01-14 07:46:17 --> Helper loaded: file_helper
INFO - 2021-01-14 07:46:17 --> Helper loaded: form_helper
INFO - 2021-01-14 07:46:17 --> Helper loaded: my_helper
INFO - 2021-01-14 07:46:17 --> Database Driver Class Initialized
DEBUG - 2021-01-14 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 07:46:17 --> Controller Class Initialized
ERROR - 2021-01-14 07:46:17 --> Severity: Notice --> Undefined index: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 43
DEBUG - 2021-01-14 07:46:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 07:46:17 --> Final output sent to browser
DEBUG - 2021-01-14 07:46:17 --> Total execution time: 0.3093
INFO - 2021-01-14 07:48:22 --> Config Class Initialized
INFO - 2021-01-14 07:48:22 --> Hooks Class Initialized
DEBUG - 2021-01-14 07:48:22 --> UTF-8 Support Enabled
INFO - 2021-01-14 07:48:22 --> Utf8 Class Initialized
INFO - 2021-01-14 07:48:22 --> URI Class Initialized
INFO - 2021-01-14 07:48:22 --> Router Class Initialized
INFO - 2021-01-14 07:48:22 --> Output Class Initialized
INFO - 2021-01-14 07:48:22 --> Security Class Initialized
DEBUG - 2021-01-14 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 07:48:22 --> Input Class Initialized
INFO - 2021-01-14 07:48:22 --> Language Class Initialized
INFO - 2021-01-14 07:48:22 --> Language Class Initialized
INFO - 2021-01-14 07:48:22 --> Config Class Initialized
INFO - 2021-01-14 07:48:22 --> Loader Class Initialized
INFO - 2021-01-14 07:48:22 --> Helper loaded: url_helper
INFO - 2021-01-14 07:48:22 --> Helper loaded: file_helper
INFO - 2021-01-14 07:48:22 --> Helper loaded: form_helper
INFO - 2021-01-14 07:48:22 --> Helper loaded: my_helper
INFO - 2021-01-14 07:48:22 --> Database Driver Class Initialized
DEBUG - 2021-01-14 07:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 07:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 07:48:22 --> Controller Class Initialized
ERROR - 2021-01-14 07:48:22 --> Severity: Notice --> Undefined index: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 43
DEBUG - 2021-01-14 07:48:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 07:48:22 --> Final output sent to browser
DEBUG - 2021-01-14 07:48:22 --> Total execution time: 0.2877
INFO - 2021-01-14 07:51:39 --> Config Class Initialized
INFO - 2021-01-14 07:51:39 --> Hooks Class Initialized
DEBUG - 2021-01-14 07:51:39 --> UTF-8 Support Enabled
INFO - 2021-01-14 07:51:39 --> Utf8 Class Initialized
INFO - 2021-01-14 07:51:39 --> URI Class Initialized
INFO - 2021-01-14 07:51:39 --> Router Class Initialized
INFO - 2021-01-14 07:51:39 --> Output Class Initialized
INFO - 2021-01-14 07:51:39 --> Security Class Initialized
DEBUG - 2021-01-14 07:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 07:51:39 --> Input Class Initialized
INFO - 2021-01-14 07:51:39 --> Language Class Initialized
INFO - 2021-01-14 07:51:39 --> Language Class Initialized
INFO - 2021-01-14 07:51:39 --> Config Class Initialized
INFO - 2021-01-14 07:51:39 --> Loader Class Initialized
INFO - 2021-01-14 07:51:39 --> Helper loaded: url_helper
INFO - 2021-01-14 07:51:39 --> Helper loaded: file_helper
INFO - 2021-01-14 07:51:39 --> Helper loaded: form_helper
INFO - 2021-01-14 07:51:39 --> Helper loaded: my_helper
INFO - 2021-01-14 07:51:39 --> Database Driver Class Initialized
DEBUG - 2021-01-14 07:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 07:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 07:51:39 --> Controller Class Initialized
DEBUG - 2021-01-14 07:51:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-14 07:51:39 --> Final output sent to browser
DEBUG - 2021-01-14 07:51:39 --> Total execution time: 0.3116
INFO - 2021-01-14 08:10:28 --> Config Class Initialized
INFO - 2021-01-14 08:10:28 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:10:28 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:10:28 --> Utf8 Class Initialized
INFO - 2021-01-14 08:10:28 --> URI Class Initialized
INFO - 2021-01-14 08:10:28 --> Router Class Initialized
INFO - 2021-01-14 08:10:28 --> Output Class Initialized
INFO - 2021-01-14 08:10:28 --> Security Class Initialized
DEBUG - 2021-01-14 08:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:10:28 --> Input Class Initialized
INFO - 2021-01-14 08:10:28 --> Language Class Initialized
INFO - 2021-01-14 08:10:28 --> Language Class Initialized
INFO - 2021-01-14 08:10:28 --> Config Class Initialized
INFO - 2021-01-14 08:10:28 --> Loader Class Initialized
INFO - 2021-01-14 08:10:28 --> Helper loaded: url_helper
INFO - 2021-01-14 08:10:28 --> Helper loaded: file_helper
INFO - 2021-01-14 08:10:28 --> Helper loaded: form_helper
INFO - 2021-01-14 08:10:28 --> Helper loaded: my_helper
INFO - 2021-01-14 08:10:28 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:10:28 --> Controller Class Initialized
ERROR - 2021-01-14 08:10:28 --> Severity: Notice --> Undefined variable: s_siswa1 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 71
ERROR - 2021-01-14 08:10:28 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\nilai\system\database\drivers\mysqli\mysqli_driver.php 306
ERROR - 2021-01-14 08:10:28 --> Query error:  - Invalid query: 
INFO - 2021-01-14 08:10:28 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-14 08:10:47 --> Config Class Initialized
INFO - 2021-01-14 08:10:47 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:10:47 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:10:47 --> Utf8 Class Initialized
INFO - 2021-01-14 08:10:47 --> URI Class Initialized
INFO - 2021-01-14 08:10:47 --> Router Class Initialized
INFO - 2021-01-14 08:10:47 --> Output Class Initialized
INFO - 2021-01-14 08:10:47 --> Security Class Initialized
DEBUG - 2021-01-14 08:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:10:47 --> Input Class Initialized
INFO - 2021-01-14 08:10:47 --> Language Class Initialized
INFO - 2021-01-14 08:10:47 --> Language Class Initialized
INFO - 2021-01-14 08:10:47 --> Config Class Initialized
INFO - 2021-01-14 08:10:47 --> Loader Class Initialized
INFO - 2021-01-14 08:10:47 --> Helper loaded: url_helper
INFO - 2021-01-14 08:10:47 --> Helper loaded: file_helper
INFO - 2021-01-14 08:10:47 --> Helper loaded: form_helper
INFO - 2021-01-14 08:10:47 --> Helper loaded: my_helper
INFO - 2021-01-14 08:10:47 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:10:48 --> Controller Class Initialized
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:10:48 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
DEBUG - 2021-01-14 08:10:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:10:48 --> Final output sent to browser
DEBUG - 2021-01-14 08:10:48 --> Total execution time: 0.8734
INFO - 2021-01-14 08:12:29 --> Config Class Initialized
INFO - 2021-01-14 08:12:29 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:12:29 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:12:29 --> Utf8 Class Initialized
INFO - 2021-01-14 08:12:29 --> URI Class Initialized
INFO - 2021-01-14 08:12:29 --> Router Class Initialized
INFO - 2021-01-14 08:12:29 --> Output Class Initialized
INFO - 2021-01-14 08:12:29 --> Security Class Initialized
DEBUG - 2021-01-14 08:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:12:29 --> Input Class Initialized
INFO - 2021-01-14 08:12:29 --> Language Class Initialized
INFO - 2021-01-14 08:12:29 --> Language Class Initialized
INFO - 2021-01-14 08:12:29 --> Config Class Initialized
INFO - 2021-01-14 08:12:29 --> Loader Class Initialized
INFO - 2021-01-14 08:12:29 --> Helper loaded: url_helper
INFO - 2021-01-14 08:12:29 --> Helper loaded: file_helper
INFO - 2021-01-14 08:12:29 --> Helper loaded: form_helper
INFO - 2021-01-14 08:12:29 --> Helper loaded: my_helper
INFO - 2021-01-14 08:12:29 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:12:29 --> Controller Class Initialized
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:29 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:12:30 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
DEBUG - 2021-01-14 08:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:12:30 --> Final output sent to browser
DEBUG - 2021-01-14 08:12:30 --> Total execution time: 0.8409
INFO - 2021-01-14 08:13:07 --> Config Class Initialized
INFO - 2021-01-14 08:13:07 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:13:07 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:13:07 --> Utf8 Class Initialized
INFO - 2021-01-14 08:13:07 --> URI Class Initialized
INFO - 2021-01-14 08:13:07 --> Router Class Initialized
INFO - 2021-01-14 08:13:07 --> Output Class Initialized
INFO - 2021-01-14 08:13:07 --> Security Class Initialized
DEBUG - 2021-01-14 08:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:13:07 --> Input Class Initialized
INFO - 2021-01-14 08:13:07 --> Language Class Initialized
INFO - 2021-01-14 08:13:07 --> Language Class Initialized
INFO - 2021-01-14 08:13:07 --> Config Class Initialized
INFO - 2021-01-14 08:13:07 --> Loader Class Initialized
INFO - 2021-01-14 08:13:07 --> Helper loaded: url_helper
INFO - 2021-01-14 08:13:07 --> Helper loaded: file_helper
INFO - 2021-01-14 08:13:07 --> Helper loaded: form_helper
INFO - 2021-01-14 08:13:07 --> Helper loaded: my_helper
INFO - 2021-01-14 08:13:07 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:13:07 --> Controller Class Initialized
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 226
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
ERROR - 2021-01-14 08:13:07 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
DEBUG - 2021-01-14 08:13:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:13:08 --> Final output sent to browser
DEBUG - 2021-01-14 08:13:08 --> Total execution time: 0.9407
INFO - 2021-01-14 08:15:49 --> Config Class Initialized
INFO - 2021-01-14 08:15:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:15:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:15:49 --> Utf8 Class Initialized
INFO - 2021-01-14 08:15:49 --> URI Class Initialized
INFO - 2021-01-14 08:15:49 --> Router Class Initialized
INFO - 2021-01-14 08:15:49 --> Output Class Initialized
INFO - 2021-01-14 08:15:49 --> Security Class Initialized
DEBUG - 2021-01-14 08:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:15:49 --> Input Class Initialized
INFO - 2021-01-14 08:15:49 --> Language Class Initialized
INFO - 2021-01-14 08:15:49 --> Language Class Initialized
INFO - 2021-01-14 08:15:49 --> Config Class Initialized
INFO - 2021-01-14 08:15:49 --> Loader Class Initialized
INFO - 2021-01-14 08:15:49 --> Helper loaded: url_helper
INFO - 2021-01-14 08:15:49 --> Helper loaded: file_helper
INFO - 2021-01-14 08:15:49 --> Helper loaded: form_helper
INFO - 2021-01-14 08:15:49 --> Helper loaded: my_helper
INFO - 2021-01-14 08:15:49 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:15:49 --> Controller Class Initialized
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:49 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 228
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 229
ERROR - 2021-01-14 08:15:50 --> Severity: Notice --> Undefined variable: id_siswa C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 230
DEBUG - 2021-01-14 08:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:15:50 --> Final output sent to browser
DEBUG - 2021-01-14 08:15:50 --> Total execution time: 0.9731
INFO - 2021-01-14 08:18:11 --> Config Class Initialized
INFO - 2021-01-14 08:18:11 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:18:11 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:18:11 --> Utf8 Class Initialized
INFO - 2021-01-14 08:18:11 --> URI Class Initialized
INFO - 2021-01-14 08:18:11 --> Router Class Initialized
INFO - 2021-01-14 08:18:11 --> Output Class Initialized
INFO - 2021-01-14 08:18:11 --> Security Class Initialized
DEBUG - 2021-01-14 08:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:18:11 --> Input Class Initialized
INFO - 2021-01-14 08:18:11 --> Language Class Initialized
INFO - 2021-01-14 08:18:11 --> Language Class Initialized
INFO - 2021-01-14 08:18:11 --> Config Class Initialized
INFO - 2021-01-14 08:18:11 --> Loader Class Initialized
INFO - 2021-01-14 08:18:11 --> Helper loaded: url_helper
INFO - 2021-01-14 08:18:11 --> Helper loaded: file_helper
INFO - 2021-01-14 08:18:11 --> Helper loaded: form_helper
INFO - 2021-01-14 08:18:11 --> Helper loaded: my_helper
INFO - 2021-01-14 08:18:11 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:18:11 --> Controller Class Initialized
DEBUG - 2021-01-14 08:18:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:18:11 --> Final output sent to browser
DEBUG - 2021-01-14 08:18:11 --> Total execution time: 0.2786
INFO - 2021-01-14 08:54:42 --> Config Class Initialized
INFO - 2021-01-14 08:54:42 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:54:42 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:54:42 --> Utf8 Class Initialized
INFO - 2021-01-14 08:54:42 --> URI Class Initialized
INFO - 2021-01-14 08:54:42 --> Router Class Initialized
INFO - 2021-01-14 08:54:42 --> Output Class Initialized
INFO - 2021-01-14 08:54:42 --> Security Class Initialized
DEBUG - 2021-01-14 08:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:54:42 --> Input Class Initialized
INFO - 2021-01-14 08:54:42 --> Language Class Initialized
INFO - 2021-01-14 08:54:42 --> Language Class Initialized
INFO - 2021-01-14 08:54:42 --> Config Class Initialized
INFO - 2021-01-14 08:54:42 --> Loader Class Initialized
INFO - 2021-01-14 08:54:42 --> Helper loaded: url_helper
INFO - 2021-01-14 08:54:42 --> Helper loaded: file_helper
INFO - 2021-01-14 08:54:42 --> Helper loaded: form_helper
INFO - 2021-01-14 08:54:42 --> Helper loaded: my_helper
INFO - 2021-01-14 08:54:42 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:54:43 --> Controller Class Initialized
DEBUG - 2021-01-14 08:54:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:54:43 --> Final output sent to browser
DEBUG - 2021-01-14 08:54:43 --> Total execution time: 0.2877
INFO - 2021-01-14 08:55:39 --> Config Class Initialized
INFO - 2021-01-14 08:55:39 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:55:39 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:55:39 --> Utf8 Class Initialized
INFO - 2021-01-14 08:55:39 --> URI Class Initialized
INFO - 2021-01-14 08:55:39 --> Router Class Initialized
INFO - 2021-01-14 08:55:39 --> Output Class Initialized
INFO - 2021-01-14 08:55:39 --> Security Class Initialized
DEBUG - 2021-01-14 08:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:55:39 --> Input Class Initialized
INFO - 2021-01-14 08:55:39 --> Language Class Initialized
INFO - 2021-01-14 08:55:39 --> Language Class Initialized
INFO - 2021-01-14 08:55:39 --> Config Class Initialized
INFO - 2021-01-14 08:55:39 --> Loader Class Initialized
INFO - 2021-01-14 08:55:39 --> Helper loaded: url_helper
INFO - 2021-01-14 08:55:39 --> Helper loaded: file_helper
INFO - 2021-01-14 08:55:39 --> Helper loaded: form_helper
INFO - 2021-01-14 08:55:39 --> Helper loaded: my_helper
INFO - 2021-01-14 08:55:39 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:55:39 --> Controller Class Initialized
DEBUG - 2021-01-14 08:55:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:55:39 --> Final output sent to browser
DEBUG - 2021-01-14 08:55:39 --> Total execution time: 0.2881
INFO - 2021-01-14 08:56:55 --> Config Class Initialized
INFO - 2021-01-14 08:56:55 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:56:55 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:56:56 --> Utf8 Class Initialized
INFO - 2021-01-14 08:56:56 --> URI Class Initialized
INFO - 2021-01-14 08:56:56 --> Router Class Initialized
INFO - 2021-01-14 08:56:56 --> Output Class Initialized
INFO - 2021-01-14 08:56:56 --> Security Class Initialized
DEBUG - 2021-01-14 08:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:56:56 --> Input Class Initialized
INFO - 2021-01-14 08:56:56 --> Language Class Initialized
INFO - 2021-01-14 08:56:56 --> Language Class Initialized
INFO - 2021-01-14 08:56:56 --> Config Class Initialized
INFO - 2021-01-14 08:56:56 --> Loader Class Initialized
INFO - 2021-01-14 08:56:56 --> Helper loaded: url_helper
INFO - 2021-01-14 08:56:56 --> Helper loaded: file_helper
INFO - 2021-01-14 08:56:56 --> Helper loaded: form_helper
INFO - 2021-01-14 08:56:56 --> Helper loaded: my_helper
INFO - 2021-01-14 08:56:56 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:56:56 --> Controller Class Initialized
DEBUG - 2021-01-14 08:56:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:56:56 --> Final output sent to browser
DEBUG - 2021-01-14 08:56:56 --> Total execution time: 0.2729
INFO - 2021-01-14 08:57:13 --> Config Class Initialized
INFO - 2021-01-14 08:57:13 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:57:13 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:57:13 --> Utf8 Class Initialized
INFO - 2021-01-14 08:57:13 --> URI Class Initialized
INFO - 2021-01-14 08:57:13 --> Router Class Initialized
INFO - 2021-01-14 08:57:13 --> Output Class Initialized
INFO - 2021-01-14 08:57:13 --> Security Class Initialized
DEBUG - 2021-01-14 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:57:13 --> Input Class Initialized
INFO - 2021-01-14 08:57:13 --> Language Class Initialized
INFO - 2021-01-14 08:57:13 --> Language Class Initialized
INFO - 2021-01-14 08:57:13 --> Config Class Initialized
INFO - 2021-01-14 08:57:13 --> Loader Class Initialized
INFO - 2021-01-14 08:57:13 --> Helper loaded: url_helper
INFO - 2021-01-14 08:57:13 --> Helper loaded: file_helper
INFO - 2021-01-14 08:57:13 --> Helper loaded: form_helper
INFO - 2021-01-14 08:57:13 --> Helper loaded: my_helper
INFO - 2021-01-14 08:57:13 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:57:13 --> Controller Class Initialized
DEBUG - 2021-01-14 08:57:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:57:13 --> Final output sent to browser
DEBUG - 2021-01-14 08:57:13 --> Total execution time: 0.2771
INFO - 2021-01-14 08:57:30 --> Config Class Initialized
INFO - 2021-01-14 08:57:30 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:57:30 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:57:30 --> Utf8 Class Initialized
INFO - 2021-01-14 08:57:30 --> URI Class Initialized
INFO - 2021-01-14 08:57:30 --> Router Class Initialized
INFO - 2021-01-14 08:57:30 --> Output Class Initialized
INFO - 2021-01-14 08:57:30 --> Security Class Initialized
DEBUG - 2021-01-14 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:57:30 --> Input Class Initialized
INFO - 2021-01-14 08:57:30 --> Language Class Initialized
INFO - 2021-01-14 08:57:30 --> Language Class Initialized
INFO - 2021-01-14 08:57:30 --> Config Class Initialized
INFO - 2021-01-14 08:57:30 --> Loader Class Initialized
INFO - 2021-01-14 08:57:30 --> Helper loaded: url_helper
INFO - 2021-01-14 08:57:30 --> Helper loaded: file_helper
INFO - 2021-01-14 08:57:30 --> Helper loaded: form_helper
INFO - 2021-01-14 08:57:30 --> Helper loaded: my_helper
INFO - 2021-01-14 08:57:30 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:57:30 --> Controller Class Initialized
DEBUG - 2021-01-14 08:57:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:57:30 --> Final output sent to browser
DEBUG - 2021-01-14 08:57:30 --> Total execution time: 0.2827
INFO - 2021-01-14 08:58:10 --> Config Class Initialized
INFO - 2021-01-14 08:58:10 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:58:10 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:58:10 --> Utf8 Class Initialized
INFO - 2021-01-14 08:58:10 --> URI Class Initialized
INFO - 2021-01-14 08:58:10 --> Router Class Initialized
INFO - 2021-01-14 08:58:10 --> Output Class Initialized
INFO - 2021-01-14 08:58:10 --> Security Class Initialized
DEBUG - 2021-01-14 08:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:58:10 --> Input Class Initialized
INFO - 2021-01-14 08:58:10 --> Language Class Initialized
INFO - 2021-01-14 08:58:10 --> Language Class Initialized
INFO - 2021-01-14 08:58:10 --> Config Class Initialized
INFO - 2021-01-14 08:58:10 --> Loader Class Initialized
INFO - 2021-01-14 08:58:10 --> Helper loaded: url_helper
INFO - 2021-01-14 08:58:10 --> Helper loaded: file_helper
INFO - 2021-01-14 08:58:10 --> Helper loaded: form_helper
INFO - 2021-01-14 08:58:10 --> Helper loaded: my_helper
INFO - 2021-01-14 08:58:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:58:10 --> Controller Class Initialized
DEBUG - 2021-01-14 08:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:58:10 --> Final output sent to browser
DEBUG - 2021-01-14 08:58:10 --> Total execution time: 0.2781
INFO - 2021-01-14 08:58:41 --> Config Class Initialized
INFO - 2021-01-14 08:58:42 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:58:42 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:58:42 --> Utf8 Class Initialized
INFO - 2021-01-14 08:58:42 --> URI Class Initialized
INFO - 2021-01-14 08:58:42 --> Router Class Initialized
INFO - 2021-01-14 08:58:42 --> Output Class Initialized
INFO - 2021-01-14 08:58:42 --> Security Class Initialized
DEBUG - 2021-01-14 08:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:58:42 --> Input Class Initialized
INFO - 2021-01-14 08:58:42 --> Language Class Initialized
INFO - 2021-01-14 08:58:42 --> Language Class Initialized
INFO - 2021-01-14 08:58:42 --> Config Class Initialized
INFO - 2021-01-14 08:58:42 --> Loader Class Initialized
INFO - 2021-01-14 08:58:42 --> Helper loaded: url_helper
INFO - 2021-01-14 08:58:42 --> Helper loaded: file_helper
INFO - 2021-01-14 08:58:42 --> Helper loaded: form_helper
INFO - 2021-01-14 08:58:42 --> Helper loaded: my_helper
INFO - 2021-01-14 08:58:42 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:58:42 --> Controller Class Initialized
DEBUG - 2021-01-14 08:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:58:42 --> Final output sent to browser
DEBUG - 2021-01-14 08:58:42 --> Total execution time: 0.2899
INFO - 2021-01-14 08:58:51 --> Config Class Initialized
INFO - 2021-01-14 08:58:51 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:58:51 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:58:51 --> Utf8 Class Initialized
INFO - 2021-01-14 08:58:51 --> URI Class Initialized
INFO - 2021-01-14 08:58:51 --> Router Class Initialized
INFO - 2021-01-14 08:58:51 --> Output Class Initialized
INFO - 2021-01-14 08:58:51 --> Security Class Initialized
DEBUG - 2021-01-14 08:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:58:51 --> Input Class Initialized
INFO - 2021-01-14 08:58:51 --> Language Class Initialized
INFO - 2021-01-14 08:58:51 --> Language Class Initialized
INFO - 2021-01-14 08:58:51 --> Config Class Initialized
INFO - 2021-01-14 08:58:51 --> Loader Class Initialized
INFO - 2021-01-14 08:58:51 --> Helper loaded: url_helper
INFO - 2021-01-14 08:58:51 --> Helper loaded: file_helper
INFO - 2021-01-14 08:58:51 --> Helper loaded: form_helper
INFO - 2021-01-14 08:58:51 --> Helper loaded: my_helper
INFO - 2021-01-14 08:58:51 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:58:51 --> Controller Class Initialized
DEBUG - 2021-01-14 08:58:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:58:51 --> Final output sent to browser
DEBUG - 2021-01-14 08:58:51 --> Total execution time: 0.2781
INFO - 2021-01-14 08:59:01 --> Config Class Initialized
INFO - 2021-01-14 08:59:01 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:59:01 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:59:01 --> Utf8 Class Initialized
INFO - 2021-01-14 08:59:01 --> URI Class Initialized
INFO - 2021-01-14 08:59:01 --> Router Class Initialized
INFO - 2021-01-14 08:59:01 --> Output Class Initialized
INFO - 2021-01-14 08:59:01 --> Security Class Initialized
DEBUG - 2021-01-14 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:59:01 --> Input Class Initialized
INFO - 2021-01-14 08:59:01 --> Language Class Initialized
INFO - 2021-01-14 08:59:01 --> Language Class Initialized
INFO - 2021-01-14 08:59:01 --> Config Class Initialized
INFO - 2021-01-14 08:59:01 --> Loader Class Initialized
INFO - 2021-01-14 08:59:01 --> Helper loaded: url_helper
INFO - 2021-01-14 08:59:01 --> Helper loaded: file_helper
INFO - 2021-01-14 08:59:01 --> Helper loaded: form_helper
INFO - 2021-01-14 08:59:01 --> Helper loaded: my_helper
INFO - 2021-01-14 08:59:01 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:59:01 --> Controller Class Initialized
DEBUG - 2021-01-14 08:59:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:59:01 --> Final output sent to browser
DEBUG - 2021-01-14 08:59:01 --> Total execution time: 0.2890
INFO - 2021-01-14 08:59:16 --> Config Class Initialized
INFO - 2021-01-14 08:59:16 --> Hooks Class Initialized
DEBUG - 2021-01-14 08:59:16 --> UTF-8 Support Enabled
INFO - 2021-01-14 08:59:16 --> Utf8 Class Initialized
INFO - 2021-01-14 08:59:16 --> URI Class Initialized
INFO - 2021-01-14 08:59:16 --> Router Class Initialized
INFO - 2021-01-14 08:59:16 --> Output Class Initialized
INFO - 2021-01-14 08:59:16 --> Security Class Initialized
DEBUG - 2021-01-14 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 08:59:16 --> Input Class Initialized
INFO - 2021-01-14 08:59:16 --> Language Class Initialized
INFO - 2021-01-14 08:59:16 --> Language Class Initialized
INFO - 2021-01-14 08:59:16 --> Config Class Initialized
INFO - 2021-01-14 08:59:16 --> Loader Class Initialized
INFO - 2021-01-14 08:59:16 --> Helper loaded: url_helper
INFO - 2021-01-14 08:59:16 --> Helper loaded: file_helper
INFO - 2021-01-14 08:59:16 --> Helper loaded: form_helper
INFO - 2021-01-14 08:59:16 --> Helper loaded: my_helper
INFO - 2021-01-14 08:59:16 --> Database Driver Class Initialized
DEBUG - 2021-01-14 08:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 08:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 08:59:16 --> Controller Class Initialized
DEBUG - 2021-01-14 08:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 08:59:16 --> Final output sent to browser
DEBUG - 2021-01-14 08:59:16 --> Total execution time: 0.2911
INFO - 2021-01-14 09:15:08 --> Config Class Initialized
INFO - 2021-01-14 09:15:08 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:15:08 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:15:08 --> Utf8 Class Initialized
INFO - 2021-01-14 09:15:08 --> URI Class Initialized
INFO - 2021-01-14 09:15:08 --> Router Class Initialized
INFO - 2021-01-14 09:15:08 --> Output Class Initialized
INFO - 2021-01-14 09:15:08 --> Security Class Initialized
DEBUG - 2021-01-14 09:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:15:08 --> Input Class Initialized
INFO - 2021-01-14 09:15:08 --> Language Class Initialized
INFO - 2021-01-14 09:15:09 --> Language Class Initialized
INFO - 2021-01-14 09:15:09 --> Config Class Initialized
INFO - 2021-01-14 09:15:09 --> Loader Class Initialized
INFO - 2021-01-14 09:15:09 --> Helper loaded: url_helper
INFO - 2021-01-14 09:15:09 --> Helper loaded: file_helper
INFO - 2021-01-14 09:15:09 --> Helper loaded: form_helper
INFO - 2021-01-14 09:15:09 --> Helper loaded: my_helper
INFO - 2021-01-14 09:15:09 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:15:09 --> Controller Class Initialized
DEBUG - 2021-01-14 09:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:15:09 --> Final output sent to browser
DEBUG - 2021-01-14 09:15:09 --> Total execution time: 0.2764
INFO - 2021-01-14 09:17:34 --> Config Class Initialized
INFO - 2021-01-14 09:17:34 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:17:34 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:17:34 --> Utf8 Class Initialized
INFO - 2021-01-14 09:17:34 --> URI Class Initialized
INFO - 2021-01-14 09:17:34 --> Router Class Initialized
INFO - 2021-01-14 09:17:34 --> Output Class Initialized
INFO - 2021-01-14 09:17:34 --> Security Class Initialized
DEBUG - 2021-01-14 09:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:17:34 --> Input Class Initialized
INFO - 2021-01-14 09:17:34 --> Language Class Initialized
INFO - 2021-01-14 09:17:34 --> Language Class Initialized
INFO - 2021-01-14 09:17:34 --> Config Class Initialized
INFO - 2021-01-14 09:17:34 --> Loader Class Initialized
INFO - 2021-01-14 09:17:34 --> Helper loaded: url_helper
INFO - 2021-01-14 09:17:34 --> Helper loaded: file_helper
INFO - 2021-01-14 09:17:34 --> Helper loaded: form_helper
INFO - 2021-01-14 09:17:34 --> Helper loaded: my_helper
INFO - 2021-01-14 09:17:34 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:17:34 --> Controller Class Initialized
DEBUG - 2021-01-14 09:17:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:17:34 --> Final output sent to browser
DEBUG - 2021-01-14 09:17:34 --> Total execution time: 0.2601
INFO - 2021-01-14 09:18:43 --> Config Class Initialized
INFO - 2021-01-14 09:18:43 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:18:43 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:18:43 --> Utf8 Class Initialized
INFO - 2021-01-14 09:18:44 --> URI Class Initialized
INFO - 2021-01-14 09:18:44 --> Router Class Initialized
INFO - 2021-01-14 09:18:44 --> Output Class Initialized
INFO - 2021-01-14 09:18:44 --> Security Class Initialized
DEBUG - 2021-01-14 09:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:18:44 --> Input Class Initialized
INFO - 2021-01-14 09:18:44 --> Language Class Initialized
INFO - 2021-01-14 09:18:44 --> Language Class Initialized
INFO - 2021-01-14 09:18:44 --> Config Class Initialized
INFO - 2021-01-14 09:18:44 --> Loader Class Initialized
INFO - 2021-01-14 09:18:44 --> Helper loaded: url_helper
INFO - 2021-01-14 09:18:44 --> Helper loaded: file_helper
INFO - 2021-01-14 09:18:44 --> Helper loaded: form_helper
INFO - 2021-01-14 09:18:44 --> Helper loaded: my_helper
INFO - 2021-01-14 09:18:44 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:18:44 --> Controller Class Initialized
DEBUG - 2021-01-14 09:18:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:18:44 --> Final output sent to browser
DEBUG - 2021-01-14 09:18:44 --> Total execution time: 0.2559
INFO - 2021-01-14 09:18:49 --> Config Class Initialized
INFO - 2021-01-14 09:18:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:18:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:18:49 --> Utf8 Class Initialized
INFO - 2021-01-14 09:18:49 --> URI Class Initialized
INFO - 2021-01-14 09:18:49 --> Router Class Initialized
INFO - 2021-01-14 09:18:49 --> Output Class Initialized
INFO - 2021-01-14 09:18:49 --> Security Class Initialized
DEBUG - 2021-01-14 09:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:18:49 --> Input Class Initialized
INFO - 2021-01-14 09:18:49 --> Language Class Initialized
INFO - 2021-01-14 09:18:49 --> Language Class Initialized
INFO - 2021-01-14 09:18:49 --> Config Class Initialized
INFO - 2021-01-14 09:18:49 --> Loader Class Initialized
INFO - 2021-01-14 09:18:49 --> Helper loaded: url_helper
INFO - 2021-01-14 09:18:49 --> Helper loaded: file_helper
INFO - 2021-01-14 09:18:49 --> Helper loaded: form_helper
INFO - 2021-01-14 09:18:49 --> Helper loaded: my_helper
INFO - 2021-01-14 09:18:49 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:18:49 --> Controller Class Initialized
DEBUG - 2021-01-14 09:18:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:18:49 --> Final output sent to browser
DEBUG - 2021-01-14 09:18:49 --> Total execution time: 0.2561
INFO - 2021-01-14 09:19:02 --> Config Class Initialized
INFO - 2021-01-14 09:19:02 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:19:02 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:19:02 --> Utf8 Class Initialized
INFO - 2021-01-14 09:19:02 --> URI Class Initialized
INFO - 2021-01-14 09:19:02 --> Router Class Initialized
INFO - 2021-01-14 09:19:02 --> Output Class Initialized
INFO - 2021-01-14 09:19:02 --> Security Class Initialized
DEBUG - 2021-01-14 09:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:19:02 --> Input Class Initialized
INFO - 2021-01-14 09:19:02 --> Language Class Initialized
INFO - 2021-01-14 09:19:02 --> Language Class Initialized
INFO - 2021-01-14 09:19:02 --> Config Class Initialized
INFO - 2021-01-14 09:19:02 --> Loader Class Initialized
INFO - 2021-01-14 09:19:02 --> Helper loaded: url_helper
INFO - 2021-01-14 09:19:02 --> Helper loaded: file_helper
INFO - 2021-01-14 09:19:02 --> Helper loaded: form_helper
INFO - 2021-01-14 09:19:02 --> Helper loaded: my_helper
INFO - 2021-01-14 09:19:02 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:19:02 --> Controller Class Initialized
DEBUG - 2021-01-14 09:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:19:02 --> Final output sent to browser
DEBUG - 2021-01-14 09:19:02 --> Total execution time: 0.2727
INFO - 2021-01-14 09:19:28 --> Config Class Initialized
INFO - 2021-01-14 09:19:28 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:19:28 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:19:28 --> Utf8 Class Initialized
INFO - 2021-01-14 09:19:28 --> URI Class Initialized
INFO - 2021-01-14 09:19:28 --> Router Class Initialized
INFO - 2021-01-14 09:19:28 --> Output Class Initialized
INFO - 2021-01-14 09:19:28 --> Security Class Initialized
DEBUG - 2021-01-14 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:19:28 --> Input Class Initialized
INFO - 2021-01-14 09:19:29 --> Language Class Initialized
INFO - 2021-01-14 09:19:29 --> Language Class Initialized
INFO - 2021-01-14 09:19:29 --> Config Class Initialized
INFO - 2021-01-14 09:19:29 --> Loader Class Initialized
INFO - 2021-01-14 09:19:29 --> Helper loaded: url_helper
INFO - 2021-01-14 09:19:29 --> Helper loaded: file_helper
INFO - 2021-01-14 09:19:29 --> Helper loaded: form_helper
INFO - 2021-01-14 09:19:29 --> Helper loaded: my_helper
INFO - 2021-01-14 09:19:29 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:19:29 --> Controller Class Initialized
DEBUG - 2021-01-14 09:19:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:19:29 --> Final output sent to browser
DEBUG - 2021-01-14 09:19:29 --> Total execution time: 0.2984
INFO - 2021-01-14 09:19:57 --> Config Class Initialized
INFO - 2021-01-14 09:19:57 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:19:57 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:19:57 --> Utf8 Class Initialized
INFO - 2021-01-14 09:19:57 --> URI Class Initialized
INFO - 2021-01-14 09:19:57 --> Router Class Initialized
INFO - 2021-01-14 09:19:57 --> Output Class Initialized
INFO - 2021-01-14 09:19:57 --> Security Class Initialized
DEBUG - 2021-01-14 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:19:57 --> Input Class Initialized
INFO - 2021-01-14 09:19:57 --> Language Class Initialized
INFO - 2021-01-14 09:19:57 --> Language Class Initialized
INFO - 2021-01-14 09:19:57 --> Config Class Initialized
INFO - 2021-01-14 09:19:57 --> Loader Class Initialized
INFO - 2021-01-14 09:19:57 --> Helper loaded: url_helper
INFO - 2021-01-14 09:19:57 --> Helper loaded: file_helper
INFO - 2021-01-14 09:19:57 --> Helper loaded: form_helper
INFO - 2021-01-14 09:19:57 --> Helper loaded: my_helper
INFO - 2021-01-14 09:19:57 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:19:57 --> Controller Class Initialized
DEBUG - 2021-01-14 09:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:19:57 --> Final output sent to browser
DEBUG - 2021-01-14 09:19:57 --> Total execution time: 0.2669
INFO - 2021-01-14 09:20:28 --> Config Class Initialized
INFO - 2021-01-14 09:20:28 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:20:28 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:20:28 --> Utf8 Class Initialized
INFO - 2021-01-14 09:20:28 --> URI Class Initialized
INFO - 2021-01-14 09:20:28 --> Router Class Initialized
INFO - 2021-01-14 09:20:28 --> Output Class Initialized
INFO - 2021-01-14 09:20:28 --> Security Class Initialized
DEBUG - 2021-01-14 09:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:20:28 --> Input Class Initialized
INFO - 2021-01-14 09:20:28 --> Language Class Initialized
INFO - 2021-01-14 09:20:28 --> Language Class Initialized
INFO - 2021-01-14 09:20:28 --> Config Class Initialized
INFO - 2021-01-14 09:20:28 --> Loader Class Initialized
INFO - 2021-01-14 09:20:28 --> Helper loaded: url_helper
INFO - 2021-01-14 09:20:28 --> Helper loaded: file_helper
INFO - 2021-01-14 09:20:28 --> Helper loaded: form_helper
INFO - 2021-01-14 09:20:28 --> Helper loaded: my_helper
INFO - 2021-01-14 09:20:28 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:20:28 --> Controller Class Initialized
DEBUG - 2021-01-14 09:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:20:28 --> Final output sent to browser
DEBUG - 2021-01-14 09:20:28 --> Total execution time: 0.2578
INFO - 2021-01-14 09:20:57 --> Config Class Initialized
INFO - 2021-01-14 09:20:57 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:20:57 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:20:57 --> Utf8 Class Initialized
INFO - 2021-01-14 09:20:57 --> URI Class Initialized
INFO - 2021-01-14 09:20:57 --> Router Class Initialized
INFO - 2021-01-14 09:20:57 --> Output Class Initialized
INFO - 2021-01-14 09:20:57 --> Security Class Initialized
DEBUG - 2021-01-14 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:20:57 --> Input Class Initialized
INFO - 2021-01-14 09:20:57 --> Language Class Initialized
INFO - 2021-01-14 09:20:57 --> Language Class Initialized
INFO - 2021-01-14 09:20:57 --> Config Class Initialized
INFO - 2021-01-14 09:20:57 --> Loader Class Initialized
INFO - 2021-01-14 09:20:57 --> Helper loaded: url_helper
INFO - 2021-01-14 09:20:57 --> Helper loaded: file_helper
INFO - 2021-01-14 09:20:57 --> Helper loaded: form_helper
INFO - 2021-01-14 09:20:57 --> Helper loaded: my_helper
INFO - 2021-01-14 09:20:57 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:20:57 --> Controller Class Initialized
DEBUG - 2021-01-14 09:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:20:57 --> Final output sent to browser
DEBUG - 2021-01-14 09:20:57 --> Total execution time: 0.2890
INFO - 2021-01-14 09:21:19 --> Config Class Initialized
INFO - 2021-01-14 09:21:19 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:21:19 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:21:19 --> Utf8 Class Initialized
INFO - 2021-01-14 09:21:19 --> URI Class Initialized
INFO - 2021-01-14 09:21:19 --> Router Class Initialized
INFO - 2021-01-14 09:21:19 --> Output Class Initialized
INFO - 2021-01-14 09:21:19 --> Security Class Initialized
DEBUG - 2021-01-14 09:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:21:19 --> Input Class Initialized
INFO - 2021-01-14 09:21:19 --> Language Class Initialized
INFO - 2021-01-14 09:21:19 --> Language Class Initialized
INFO - 2021-01-14 09:21:19 --> Config Class Initialized
INFO - 2021-01-14 09:21:19 --> Loader Class Initialized
INFO - 2021-01-14 09:21:19 --> Helper loaded: url_helper
INFO - 2021-01-14 09:21:19 --> Helper loaded: file_helper
INFO - 2021-01-14 09:21:19 --> Helper loaded: form_helper
INFO - 2021-01-14 09:21:19 --> Helper loaded: my_helper
INFO - 2021-01-14 09:21:19 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:21:19 --> Controller Class Initialized
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 232
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 233
ERROR - 2021-01-14 09:21:20 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 234
DEBUG - 2021-01-14 09:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:21:20 --> Final output sent to browser
DEBUG - 2021-01-14 09:21:20 --> Total execution time: 0.8113
INFO - 2021-01-14 09:21:31 --> Config Class Initialized
INFO - 2021-01-14 09:21:31 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:21:31 --> Utf8 Class Initialized
INFO - 2021-01-14 09:21:31 --> URI Class Initialized
INFO - 2021-01-14 09:21:31 --> Router Class Initialized
INFO - 2021-01-14 09:21:31 --> Output Class Initialized
INFO - 2021-01-14 09:21:31 --> Security Class Initialized
DEBUG - 2021-01-14 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:21:31 --> Input Class Initialized
INFO - 2021-01-14 09:21:31 --> Language Class Initialized
INFO - 2021-01-14 09:21:31 --> Language Class Initialized
INFO - 2021-01-14 09:21:31 --> Config Class Initialized
INFO - 2021-01-14 09:21:31 --> Loader Class Initialized
INFO - 2021-01-14 09:21:31 --> Helper loaded: url_helper
INFO - 2021-01-14 09:21:31 --> Helper loaded: file_helper
INFO - 2021-01-14 09:21:31 --> Helper loaded: form_helper
INFO - 2021-01-14 09:21:31 --> Helper loaded: my_helper
INFO - 2021-01-14 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:21:31 --> Controller Class Initialized
DEBUG - 2021-01-14 09:21:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:21:31 --> Final output sent to browser
DEBUG - 2021-01-14 09:21:31 --> Total execution time: 0.2794
INFO - 2021-01-14 09:22:49 --> Config Class Initialized
INFO - 2021-01-14 09:22:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:22:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:22:49 --> Utf8 Class Initialized
INFO - 2021-01-14 09:22:49 --> URI Class Initialized
INFO - 2021-01-14 09:22:49 --> Router Class Initialized
INFO - 2021-01-14 09:22:49 --> Output Class Initialized
INFO - 2021-01-14 09:22:49 --> Security Class Initialized
DEBUG - 2021-01-14 09:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:22:49 --> Input Class Initialized
INFO - 2021-01-14 09:22:49 --> Language Class Initialized
INFO - 2021-01-14 09:22:49 --> Language Class Initialized
INFO - 2021-01-14 09:22:49 --> Config Class Initialized
INFO - 2021-01-14 09:22:49 --> Loader Class Initialized
INFO - 2021-01-14 09:22:49 --> Helper loaded: url_helper
INFO - 2021-01-14 09:22:49 --> Helper loaded: file_helper
INFO - 2021-01-14 09:22:50 --> Helper loaded: form_helper
INFO - 2021-01-14 09:22:50 --> Helper loaded: my_helper
INFO - 2021-01-14 09:22:50 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:22:50 --> Controller Class Initialized
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:50 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 148
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 179
ERROR - 2021-01-14 09:22:51 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 210
DEBUG - 2021-01-14 09:22:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:22:51 --> Final output sent to browser
DEBUG - 2021-01-14 09:22:51 --> Total execution time: 1.9348
INFO - 2021-01-14 09:23:34 --> Config Class Initialized
INFO - 2021-01-14 09:23:34 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:23:34 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:23:34 --> Utf8 Class Initialized
INFO - 2021-01-14 09:23:34 --> URI Class Initialized
INFO - 2021-01-14 09:23:34 --> Router Class Initialized
INFO - 2021-01-14 09:23:34 --> Output Class Initialized
INFO - 2021-01-14 09:23:34 --> Security Class Initialized
DEBUG - 2021-01-14 09:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:23:34 --> Input Class Initialized
INFO - 2021-01-14 09:23:34 --> Language Class Initialized
INFO - 2021-01-14 09:23:34 --> Language Class Initialized
INFO - 2021-01-14 09:23:34 --> Config Class Initialized
INFO - 2021-01-14 09:23:34 --> Loader Class Initialized
INFO - 2021-01-14 09:23:34 --> Helper loaded: url_helper
INFO - 2021-01-14 09:23:34 --> Helper loaded: file_helper
INFO - 2021-01-14 09:23:34 --> Helper loaded: form_helper
INFO - 2021-01-14 09:23:34 --> Helper loaded: my_helper
INFO - 2021-01-14 09:23:34 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:23:34 --> Controller Class Initialized
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:34 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:35 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 146
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 177
ERROR - 2021-01-14 09:23:36 --> Severity: Warning --> Illegal string offset 'id_siswa' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 208
DEBUG - 2021-01-14 09:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:23:36 --> Final output sent to browser
DEBUG - 2021-01-14 09:23:36 --> Total execution time: 1.9838
INFO - 2021-01-14 09:23:54 --> Config Class Initialized
INFO - 2021-01-14 09:23:54 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:23:54 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:23:54 --> Utf8 Class Initialized
INFO - 2021-01-14 09:23:54 --> URI Class Initialized
INFO - 2021-01-14 09:23:54 --> Router Class Initialized
INFO - 2021-01-14 09:23:54 --> Output Class Initialized
INFO - 2021-01-14 09:23:54 --> Security Class Initialized
DEBUG - 2021-01-14 09:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:23:54 --> Input Class Initialized
INFO - 2021-01-14 09:23:54 --> Language Class Initialized
INFO - 2021-01-14 09:23:54 --> Language Class Initialized
INFO - 2021-01-14 09:23:54 --> Config Class Initialized
INFO - 2021-01-14 09:23:54 --> Loader Class Initialized
INFO - 2021-01-14 09:23:54 --> Helper loaded: url_helper
INFO - 2021-01-14 09:23:54 --> Helper loaded: file_helper
INFO - 2021-01-14 09:23:54 --> Helper loaded: form_helper
INFO - 2021-01-14 09:23:54 --> Helper loaded: my_helper
INFO - 2021-01-14 09:23:54 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:23:54 --> Controller Class Initialized
DEBUG - 2021-01-14 09:23:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:23:54 --> Final output sent to browser
DEBUG - 2021-01-14 09:23:54 --> Total execution time: 0.2775
INFO - 2021-01-14 09:24:10 --> Config Class Initialized
INFO - 2021-01-14 09:24:10 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:24:10 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:24:10 --> Utf8 Class Initialized
INFO - 2021-01-14 09:24:10 --> URI Class Initialized
INFO - 2021-01-14 09:24:10 --> Router Class Initialized
INFO - 2021-01-14 09:24:10 --> Output Class Initialized
INFO - 2021-01-14 09:24:10 --> Security Class Initialized
DEBUG - 2021-01-14 09:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:24:10 --> Input Class Initialized
INFO - 2021-01-14 09:24:10 --> Language Class Initialized
INFO - 2021-01-14 09:24:10 --> Language Class Initialized
INFO - 2021-01-14 09:24:10 --> Config Class Initialized
INFO - 2021-01-14 09:24:10 --> Loader Class Initialized
INFO - 2021-01-14 09:24:10 --> Helper loaded: url_helper
INFO - 2021-01-14 09:24:10 --> Helper loaded: file_helper
INFO - 2021-01-14 09:24:10 --> Helper loaded: form_helper
INFO - 2021-01-14 09:24:10 --> Helper loaded: my_helper
INFO - 2021-01-14 09:24:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:24:10 --> Controller Class Initialized
DEBUG - 2021-01-14 09:24:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:24:10 --> Final output sent to browser
DEBUG - 2021-01-14 09:24:11 --> Total execution time: 0.2767
INFO - 2021-01-14 09:26:45 --> Config Class Initialized
INFO - 2021-01-14 09:26:45 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:26:45 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:26:45 --> Utf8 Class Initialized
INFO - 2021-01-14 09:26:45 --> URI Class Initialized
INFO - 2021-01-14 09:26:45 --> Router Class Initialized
INFO - 2021-01-14 09:26:45 --> Output Class Initialized
INFO - 2021-01-14 09:26:45 --> Security Class Initialized
DEBUG - 2021-01-14 09:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:26:45 --> Input Class Initialized
INFO - 2021-01-14 09:26:45 --> Language Class Initialized
INFO - 2021-01-14 09:26:45 --> Language Class Initialized
INFO - 2021-01-14 09:26:45 --> Config Class Initialized
INFO - 2021-01-14 09:26:45 --> Loader Class Initialized
INFO - 2021-01-14 09:26:45 --> Helper loaded: url_helper
INFO - 2021-01-14 09:26:45 --> Helper loaded: file_helper
INFO - 2021-01-14 09:26:45 --> Helper loaded: form_helper
INFO - 2021-01-14 09:26:45 --> Helper loaded: my_helper
INFO - 2021-01-14 09:26:45 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:26:45 --> Controller Class Initialized
DEBUG - 2021-01-14 09:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:26:45 --> Final output sent to browser
DEBUG - 2021-01-14 09:26:45 --> Total execution time: 0.3238
INFO - 2021-01-14 09:26:52 --> Config Class Initialized
INFO - 2021-01-14 09:26:52 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:26:52 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:26:52 --> Utf8 Class Initialized
INFO - 2021-01-14 09:26:52 --> URI Class Initialized
INFO - 2021-01-14 09:26:52 --> Router Class Initialized
INFO - 2021-01-14 09:26:52 --> Output Class Initialized
INFO - 2021-01-14 09:26:52 --> Security Class Initialized
DEBUG - 2021-01-14 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:26:52 --> Input Class Initialized
INFO - 2021-01-14 09:26:52 --> Language Class Initialized
INFO - 2021-01-14 09:26:52 --> Language Class Initialized
INFO - 2021-01-14 09:26:52 --> Config Class Initialized
INFO - 2021-01-14 09:26:52 --> Loader Class Initialized
INFO - 2021-01-14 09:26:52 --> Helper loaded: url_helper
INFO - 2021-01-14 09:26:52 --> Helper loaded: file_helper
INFO - 2021-01-14 09:26:52 --> Helper loaded: form_helper
INFO - 2021-01-14 09:26:52 --> Helper loaded: my_helper
INFO - 2021-01-14 09:26:52 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:26:52 --> Controller Class Initialized
DEBUG - 2021-01-14 09:26:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:26:52 --> Final output sent to browser
DEBUG - 2021-01-14 09:26:52 --> Total execution time: 0.3456
INFO - 2021-01-14 09:26:54 --> Config Class Initialized
INFO - 2021-01-14 09:26:54 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:26:54 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:26:54 --> Utf8 Class Initialized
INFO - 2021-01-14 09:26:54 --> URI Class Initialized
INFO - 2021-01-14 09:26:54 --> Router Class Initialized
INFO - 2021-01-14 09:26:54 --> Output Class Initialized
INFO - 2021-01-14 09:26:54 --> Security Class Initialized
DEBUG - 2021-01-14 09:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:26:54 --> Input Class Initialized
INFO - 2021-01-14 09:26:54 --> Language Class Initialized
INFO - 2021-01-14 09:26:54 --> Language Class Initialized
INFO - 2021-01-14 09:26:54 --> Config Class Initialized
INFO - 2021-01-14 09:26:54 --> Loader Class Initialized
INFO - 2021-01-14 09:26:54 --> Helper loaded: url_helper
INFO - 2021-01-14 09:26:54 --> Helper loaded: file_helper
INFO - 2021-01-14 09:26:54 --> Helper loaded: form_helper
INFO - 2021-01-14 09:26:54 --> Helper loaded: my_helper
INFO - 2021-01-14 09:26:54 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:26:54 --> Controller Class Initialized
DEBUG - 2021-01-14 09:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:26:54 --> Final output sent to browser
DEBUG - 2021-01-14 09:26:54 --> Total execution time: 0.3436
INFO - 2021-01-14 09:27:33 --> Config Class Initialized
INFO - 2021-01-14 09:27:33 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:27:33 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:27:33 --> Utf8 Class Initialized
INFO - 2021-01-14 09:27:33 --> URI Class Initialized
INFO - 2021-01-14 09:27:33 --> Router Class Initialized
INFO - 2021-01-14 09:27:33 --> Output Class Initialized
INFO - 2021-01-14 09:27:33 --> Security Class Initialized
DEBUG - 2021-01-14 09:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:27:33 --> Input Class Initialized
INFO - 2021-01-14 09:27:33 --> Language Class Initialized
ERROR - 2021-01-14 09:27:33 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 239
INFO - 2021-01-14 09:28:23 --> Config Class Initialized
INFO - 2021-01-14 09:28:23 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:28:23 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:28:23 --> Utf8 Class Initialized
INFO - 2021-01-14 09:28:23 --> URI Class Initialized
INFO - 2021-01-14 09:28:23 --> Router Class Initialized
INFO - 2021-01-14 09:28:23 --> Output Class Initialized
INFO - 2021-01-14 09:28:23 --> Security Class Initialized
DEBUG - 2021-01-14 09:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:28:23 --> Input Class Initialized
INFO - 2021-01-14 09:28:23 --> Language Class Initialized
ERROR - 2021-01-14 09:28:23 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 237
INFO - 2021-01-14 09:28:32 --> Config Class Initialized
INFO - 2021-01-14 09:28:32 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:28:32 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:28:32 --> Utf8 Class Initialized
INFO - 2021-01-14 09:28:32 --> URI Class Initialized
INFO - 2021-01-14 09:28:32 --> Router Class Initialized
INFO - 2021-01-14 09:28:32 --> Output Class Initialized
INFO - 2021-01-14 09:28:32 --> Security Class Initialized
DEBUG - 2021-01-14 09:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:28:32 --> Input Class Initialized
INFO - 2021-01-14 09:28:32 --> Language Class Initialized
INFO - 2021-01-14 09:28:32 --> Language Class Initialized
INFO - 2021-01-14 09:28:32 --> Config Class Initialized
INFO - 2021-01-14 09:28:32 --> Loader Class Initialized
INFO - 2021-01-14 09:28:32 --> Helper loaded: url_helper
INFO - 2021-01-14 09:28:32 --> Helper loaded: file_helper
INFO - 2021-01-14 09:28:32 --> Helper loaded: form_helper
INFO - 2021-01-14 09:28:33 --> Helper loaded: my_helper
INFO - 2021-01-14 09:28:33 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:28:33 --> Controller Class Initialized
DEBUG - 2021-01-14 09:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:28:33 --> Final output sent to browser
DEBUG - 2021-01-14 09:28:33 --> Total execution time: 0.3017
INFO - 2021-01-14 09:28:41 --> Config Class Initialized
INFO - 2021-01-14 09:28:41 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:28:41 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:28:41 --> Utf8 Class Initialized
INFO - 2021-01-14 09:28:41 --> URI Class Initialized
INFO - 2021-01-14 09:28:41 --> Router Class Initialized
INFO - 2021-01-14 09:28:41 --> Output Class Initialized
INFO - 2021-01-14 09:28:41 --> Security Class Initialized
DEBUG - 2021-01-14 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:28:41 --> Input Class Initialized
INFO - 2021-01-14 09:28:41 --> Language Class Initialized
INFO - 2021-01-14 09:28:41 --> Language Class Initialized
INFO - 2021-01-14 09:28:41 --> Config Class Initialized
INFO - 2021-01-14 09:28:41 --> Loader Class Initialized
INFO - 2021-01-14 09:28:41 --> Helper loaded: url_helper
INFO - 2021-01-14 09:28:41 --> Helper loaded: file_helper
INFO - 2021-01-14 09:28:41 --> Helper loaded: form_helper
INFO - 2021-01-14 09:28:41 --> Helper loaded: my_helper
INFO - 2021-01-14 09:28:41 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:28:42 --> Controller Class Initialized
DEBUG - 2021-01-14 09:28:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:28:42 --> Final output sent to browser
DEBUG - 2021-01-14 09:28:42 --> Total execution time: 0.3402
INFO - 2021-01-14 09:28:42 --> Config Class Initialized
INFO - 2021-01-14 09:28:42 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:28:42 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:28:42 --> Utf8 Class Initialized
INFO - 2021-01-14 09:28:42 --> URI Class Initialized
INFO - 2021-01-14 09:28:42 --> Router Class Initialized
INFO - 2021-01-14 09:28:42 --> Output Class Initialized
INFO - 2021-01-14 09:28:42 --> Security Class Initialized
DEBUG - 2021-01-14 09:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:28:42 --> Input Class Initialized
INFO - 2021-01-14 09:28:42 --> Language Class Initialized
INFO - 2021-01-14 09:28:42 --> Language Class Initialized
INFO - 2021-01-14 09:28:42 --> Config Class Initialized
INFO - 2021-01-14 09:28:42 --> Loader Class Initialized
INFO - 2021-01-14 09:28:42 --> Helper loaded: url_helper
INFO - 2021-01-14 09:28:42 --> Helper loaded: file_helper
INFO - 2021-01-14 09:28:42 --> Helper loaded: form_helper
INFO - 2021-01-14 09:28:42 --> Helper loaded: my_helper
INFO - 2021-01-14 09:28:42 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:28:43 --> Controller Class Initialized
DEBUG - 2021-01-14 09:28:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:28:43 --> Final output sent to browser
DEBUG - 2021-01-14 09:28:43 --> Total execution time: 0.3089
INFO - 2021-01-14 09:28:59 --> Config Class Initialized
INFO - 2021-01-14 09:28:59 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:28:59 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:28:59 --> Utf8 Class Initialized
INFO - 2021-01-14 09:28:59 --> URI Class Initialized
INFO - 2021-01-14 09:28:59 --> Router Class Initialized
INFO - 2021-01-14 09:28:59 --> Output Class Initialized
INFO - 2021-01-14 09:28:59 --> Security Class Initialized
DEBUG - 2021-01-14 09:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:28:59 --> Input Class Initialized
INFO - 2021-01-14 09:28:59 --> Language Class Initialized
INFO - 2021-01-14 09:28:59 --> Language Class Initialized
INFO - 2021-01-14 09:28:59 --> Config Class Initialized
INFO - 2021-01-14 09:28:59 --> Loader Class Initialized
INFO - 2021-01-14 09:28:59 --> Helper loaded: url_helper
INFO - 2021-01-14 09:28:59 --> Helper loaded: file_helper
INFO - 2021-01-14 09:28:59 --> Helper loaded: form_helper
INFO - 2021-01-14 09:28:59 --> Helper loaded: my_helper
INFO - 2021-01-14 09:28:59 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:28:59 --> Controller Class Initialized
DEBUG - 2021-01-14 09:28:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:28:59 --> Final output sent to browser
DEBUG - 2021-01-14 09:28:59 --> Total execution time: 0.2984
INFO - 2021-01-14 09:29:01 --> Config Class Initialized
INFO - 2021-01-14 09:29:02 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:29:02 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:29:02 --> Utf8 Class Initialized
INFO - 2021-01-14 09:29:02 --> URI Class Initialized
INFO - 2021-01-14 09:29:02 --> Router Class Initialized
INFO - 2021-01-14 09:29:02 --> Output Class Initialized
INFO - 2021-01-14 09:29:02 --> Security Class Initialized
DEBUG - 2021-01-14 09:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:29:02 --> Input Class Initialized
INFO - 2021-01-14 09:29:02 --> Language Class Initialized
INFO - 2021-01-14 09:29:02 --> Language Class Initialized
INFO - 2021-01-14 09:29:02 --> Config Class Initialized
INFO - 2021-01-14 09:29:02 --> Loader Class Initialized
INFO - 2021-01-14 09:29:02 --> Helper loaded: url_helper
INFO - 2021-01-14 09:29:02 --> Helper loaded: file_helper
INFO - 2021-01-14 09:29:02 --> Helper loaded: form_helper
INFO - 2021-01-14 09:29:02 --> Helper loaded: my_helper
INFO - 2021-01-14 09:29:02 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:29:02 --> Controller Class Initialized
DEBUG - 2021-01-14 09:29:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:29:02 --> Final output sent to browser
DEBUG - 2021-01-14 09:29:02 --> Total execution time: 0.3391
INFO - 2021-01-14 09:29:09 --> Config Class Initialized
INFO - 2021-01-14 09:29:09 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:29:09 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:29:09 --> Utf8 Class Initialized
INFO - 2021-01-14 09:29:09 --> URI Class Initialized
INFO - 2021-01-14 09:29:09 --> Router Class Initialized
INFO - 2021-01-14 09:29:09 --> Output Class Initialized
INFO - 2021-01-14 09:29:09 --> Security Class Initialized
DEBUG - 2021-01-14 09:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:29:09 --> Input Class Initialized
INFO - 2021-01-14 09:29:09 --> Language Class Initialized
INFO - 2021-01-14 09:29:10 --> Language Class Initialized
INFO - 2021-01-14 09:29:10 --> Config Class Initialized
INFO - 2021-01-14 09:29:10 --> Loader Class Initialized
INFO - 2021-01-14 09:29:10 --> Helper loaded: url_helper
INFO - 2021-01-14 09:29:10 --> Helper loaded: file_helper
INFO - 2021-01-14 09:29:10 --> Helper loaded: form_helper
INFO - 2021-01-14 09:29:10 --> Helper loaded: my_helper
INFO - 2021-01-14 09:29:10 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:29:10 --> Controller Class Initialized
DEBUG - 2021-01-14 09:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:29:10 --> Final output sent to browser
DEBUG - 2021-01-14 09:29:10 --> Total execution time: 0.2936
INFO - 2021-01-14 09:29:11 --> Config Class Initialized
INFO - 2021-01-14 09:29:11 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:29:11 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:29:11 --> Utf8 Class Initialized
INFO - 2021-01-14 09:29:11 --> URI Class Initialized
INFO - 2021-01-14 09:29:11 --> Router Class Initialized
INFO - 2021-01-14 09:29:11 --> Output Class Initialized
INFO - 2021-01-14 09:29:11 --> Security Class Initialized
DEBUG - 2021-01-14 09:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:29:11 --> Input Class Initialized
INFO - 2021-01-14 09:29:11 --> Language Class Initialized
INFO - 2021-01-14 09:29:11 --> Language Class Initialized
INFO - 2021-01-14 09:29:11 --> Config Class Initialized
INFO - 2021-01-14 09:29:11 --> Loader Class Initialized
INFO - 2021-01-14 09:29:11 --> Helper loaded: url_helper
INFO - 2021-01-14 09:29:11 --> Helper loaded: file_helper
INFO - 2021-01-14 09:29:11 --> Helper loaded: form_helper
INFO - 2021-01-14 09:29:11 --> Helper loaded: my_helper
INFO - 2021-01-14 09:29:11 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:29:11 --> Controller Class Initialized
DEBUG - 2021-01-14 09:29:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:29:11 --> Final output sent to browser
DEBUG - 2021-01-14 09:29:11 --> Total execution time: 0.3006
INFO - 2021-01-14 09:29:30 --> Config Class Initialized
INFO - 2021-01-14 09:29:30 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:29:30 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:29:30 --> Utf8 Class Initialized
INFO - 2021-01-14 09:29:30 --> URI Class Initialized
INFO - 2021-01-14 09:29:30 --> Router Class Initialized
INFO - 2021-01-14 09:29:30 --> Output Class Initialized
INFO - 2021-01-14 09:29:30 --> Security Class Initialized
DEBUG - 2021-01-14 09:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:29:30 --> Input Class Initialized
INFO - 2021-01-14 09:29:30 --> Language Class Initialized
INFO - 2021-01-14 09:29:30 --> Language Class Initialized
INFO - 2021-01-14 09:29:30 --> Config Class Initialized
INFO - 2021-01-14 09:29:30 --> Loader Class Initialized
INFO - 2021-01-14 09:29:30 --> Helper loaded: url_helper
INFO - 2021-01-14 09:29:30 --> Helper loaded: file_helper
INFO - 2021-01-14 09:29:30 --> Helper loaded: form_helper
INFO - 2021-01-14 09:29:30 --> Helper loaded: my_helper
INFO - 2021-01-14 09:29:30 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:29:30 --> Controller Class Initialized
DEBUG - 2021-01-14 09:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:29:30 --> Final output sent to browser
DEBUG - 2021-01-14 09:29:30 --> Total execution time: 0.3063
INFO - 2021-01-14 09:29:45 --> Config Class Initialized
INFO - 2021-01-14 09:29:45 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:29:45 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:29:45 --> Utf8 Class Initialized
INFO - 2021-01-14 09:29:45 --> URI Class Initialized
INFO - 2021-01-14 09:29:45 --> Router Class Initialized
INFO - 2021-01-14 09:29:45 --> Output Class Initialized
INFO - 2021-01-14 09:29:45 --> Security Class Initialized
DEBUG - 2021-01-14 09:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:29:45 --> Input Class Initialized
INFO - 2021-01-14 09:29:45 --> Language Class Initialized
INFO - 2021-01-14 09:29:45 --> Language Class Initialized
INFO - 2021-01-14 09:29:45 --> Config Class Initialized
INFO - 2021-01-14 09:29:45 --> Loader Class Initialized
INFO - 2021-01-14 09:29:45 --> Helper loaded: url_helper
INFO - 2021-01-14 09:29:45 --> Helper loaded: file_helper
INFO - 2021-01-14 09:29:45 --> Helper loaded: form_helper
INFO - 2021-01-14 09:29:45 --> Helper loaded: my_helper
INFO - 2021-01-14 09:29:45 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:29:45 --> Controller Class Initialized
DEBUG - 2021-01-14 09:29:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:29:45 --> Final output sent to browser
DEBUG - 2021-01-14 09:29:45 --> Total execution time: 0.2887
INFO - 2021-01-14 09:29:50 --> Config Class Initialized
INFO - 2021-01-14 09:29:50 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:29:50 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:29:50 --> Utf8 Class Initialized
INFO - 2021-01-14 09:29:50 --> URI Class Initialized
INFO - 2021-01-14 09:29:50 --> Router Class Initialized
INFO - 2021-01-14 09:29:50 --> Output Class Initialized
INFO - 2021-01-14 09:29:50 --> Security Class Initialized
DEBUG - 2021-01-14 09:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:29:50 --> Input Class Initialized
INFO - 2021-01-14 09:29:51 --> Language Class Initialized
INFO - 2021-01-14 09:29:51 --> Language Class Initialized
INFO - 2021-01-14 09:29:51 --> Config Class Initialized
INFO - 2021-01-14 09:29:51 --> Loader Class Initialized
INFO - 2021-01-14 09:29:51 --> Helper loaded: url_helper
INFO - 2021-01-14 09:29:51 --> Helper loaded: file_helper
INFO - 2021-01-14 09:29:51 --> Helper loaded: form_helper
INFO - 2021-01-14 09:29:51 --> Helper loaded: my_helper
INFO - 2021-01-14 09:29:51 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:29:51 --> Controller Class Initialized
DEBUG - 2021-01-14 09:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:29:51 --> Final output sent to browser
DEBUG - 2021-01-14 09:29:51 --> Total execution time: 0.2910
INFO - 2021-01-14 09:30:01 --> Config Class Initialized
INFO - 2021-01-14 09:30:01 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:30:01 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:30:01 --> Utf8 Class Initialized
INFO - 2021-01-14 09:30:01 --> URI Class Initialized
INFO - 2021-01-14 09:30:01 --> Router Class Initialized
INFO - 2021-01-14 09:30:01 --> Output Class Initialized
INFO - 2021-01-14 09:30:01 --> Security Class Initialized
DEBUG - 2021-01-14 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:30:01 --> Input Class Initialized
INFO - 2021-01-14 09:30:01 --> Language Class Initialized
INFO - 2021-01-14 09:30:01 --> Language Class Initialized
INFO - 2021-01-14 09:30:01 --> Config Class Initialized
INFO - 2021-01-14 09:30:01 --> Loader Class Initialized
INFO - 2021-01-14 09:30:01 --> Helper loaded: url_helper
INFO - 2021-01-14 09:30:01 --> Helper loaded: file_helper
INFO - 2021-01-14 09:30:01 --> Helper loaded: form_helper
INFO - 2021-01-14 09:30:01 --> Helper loaded: my_helper
INFO - 2021-01-14 09:30:01 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:30:01 --> Controller Class Initialized
DEBUG - 2021-01-14 09:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:30:01 --> Final output sent to browser
DEBUG - 2021-01-14 09:30:01 --> Total execution time: 0.2833
INFO - 2021-01-14 09:30:35 --> Config Class Initialized
INFO - 2021-01-14 09:30:35 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:30:35 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:30:35 --> Utf8 Class Initialized
INFO - 2021-01-14 09:30:35 --> URI Class Initialized
INFO - 2021-01-14 09:30:35 --> Router Class Initialized
INFO - 2021-01-14 09:30:35 --> Output Class Initialized
INFO - 2021-01-14 09:30:35 --> Security Class Initialized
DEBUG - 2021-01-14 09:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:30:35 --> Input Class Initialized
INFO - 2021-01-14 09:30:35 --> Language Class Initialized
INFO - 2021-01-14 09:30:35 --> Language Class Initialized
INFO - 2021-01-14 09:30:35 --> Config Class Initialized
INFO - 2021-01-14 09:30:35 --> Loader Class Initialized
INFO - 2021-01-14 09:30:35 --> Helper loaded: url_helper
INFO - 2021-01-14 09:30:35 --> Helper loaded: file_helper
INFO - 2021-01-14 09:30:35 --> Helper loaded: form_helper
INFO - 2021-01-14 09:30:35 --> Helper loaded: my_helper
INFO - 2021-01-14 09:30:35 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:30:35 --> Controller Class Initialized
DEBUG - 2021-01-14 09:30:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:30:35 --> Final output sent to browser
DEBUG - 2021-01-14 09:30:35 --> Total execution time: 0.2968
INFO - 2021-01-14 09:32:19 --> Config Class Initialized
INFO - 2021-01-14 09:32:19 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:32:19 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:32:19 --> Utf8 Class Initialized
INFO - 2021-01-14 09:32:19 --> URI Class Initialized
INFO - 2021-01-14 09:32:19 --> Router Class Initialized
INFO - 2021-01-14 09:32:19 --> Output Class Initialized
INFO - 2021-01-14 09:32:19 --> Security Class Initialized
DEBUG - 2021-01-14 09:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:32:19 --> Input Class Initialized
INFO - 2021-01-14 09:32:19 --> Language Class Initialized
INFO - 2021-01-14 09:32:19 --> Language Class Initialized
INFO - 2021-01-14 09:32:19 --> Config Class Initialized
INFO - 2021-01-14 09:32:19 --> Loader Class Initialized
INFO - 2021-01-14 09:32:19 --> Helper loaded: url_helper
INFO - 2021-01-14 09:32:19 --> Helper loaded: file_helper
INFO - 2021-01-14 09:32:19 --> Helper loaded: form_helper
INFO - 2021-01-14 09:32:19 --> Helper loaded: my_helper
INFO - 2021-01-14 09:32:19 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:32:19 --> Controller Class Initialized
DEBUG - 2021-01-14 09:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:32:19 --> Final output sent to browser
DEBUG - 2021-01-14 09:32:19 --> Total execution time: 0.3459
INFO - 2021-01-14 09:32:39 --> Config Class Initialized
INFO - 2021-01-14 09:32:39 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:32:40 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:32:40 --> Utf8 Class Initialized
INFO - 2021-01-14 09:32:40 --> URI Class Initialized
INFO - 2021-01-14 09:32:40 --> Router Class Initialized
INFO - 2021-01-14 09:32:40 --> Output Class Initialized
INFO - 2021-01-14 09:32:40 --> Security Class Initialized
DEBUG - 2021-01-14 09:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:32:40 --> Input Class Initialized
INFO - 2021-01-14 09:32:40 --> Language Class Initialized
INFO - 2021-01-14 09:32:40 --> Language Class Initialized
INFO - 2021-01-14 09:32:40 --> Config Class Initialized
INFO - 2021-01-14 09:32:40 --> Loader Class Initialized
INFO - 2021-01-14 09:32:40 --> Helper loaded: url_helper
INFO - 2021-01-14 09:32:40 --> Helper loaded: file_helper
INFO - 2021-01-14 09:32:40 --> Helper loaded: form_helper
INFO - 2021-01-14 09:32:40 --> Helper loaded: my_helper
INFO - 2021-01-14 09:32:40 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:32:40 --> Controller Class Initialized
DEBUG - 2021-01-14 09:32:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:32:40 --> Final output sent to browser
DEBUG - 2021-01-14 09:32:40 --> Total execution time: 0.3243
INFO - 2021-01-14 09:32:49 --> Config Class Initialized
INFO - 2021-01-14 09:32:49 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:32:49 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:32:49 --> Utf8 Class Initialized
INFO - 2021-01-14 09:32:49 --> URI Class Initialized
INFO - 2021-01-14 09:32:49 --> Router Class Initialized
INFO - 2021-01-14 09:32:49 --> Output Class Initialized
INFO - 2021-01-14 09:32:49 --> Security Class Initialized
DEBUG - 2021-01-14 09:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:32:49 --> Input Class Initialized
INFO - 2021-01-14 09:32:49 --> Language Class Initialized
INFO - 2021-01-14 09:32:49 --> Language Class Initialized
INFO - 2021-01-14 09:32:49 --> Config Class Initialized
INFO - 2021-01-14 09:32:49 --> Loader Class Initialized
INFO - 2021-01-14 09:32:49 --> Helper loaded: url_helper
INFO - 2021-01-14 09:32:49 --> Helper loaded: file_helper
INFO - 2021-01-14 09:32:49 --> Helper loaded: form_helper
INFO - 2021-01-14 09:32:49 --> Helper loaded: my_helper
INFO - 2021-01-14 09:32:49 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:32:49 --> Controller Class Initialized
DEBUG - 2021-01-14 09:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-14 09:32:49 --> Final output sent to browser
DEBUG - 2021-01-14 09:32:49 --> Total execution time: 0.2987
INFO - 2021-01-14 09:33:06 --> Config Class Initialized
INFO - 2021-01-14 09:33:06 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:33:06 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:33:06 --> Utf8 Class Initialized
INFO - 2021-01-14 09:33:06 --> URI Class Initialized
INFO - 2021-01-14 09:33:06 --> Router Class Initialized
INFO - 2021-01-14 09:33:06 --> Output Class Initialized
INFO - 2021-01-14 09:33:06 --> Security Class Initialized
DEBUG - 2021-01-14 09:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:33:06 --> Input Class Initialized
INFO - 2021-01-14 09:33:06 --> Language Class Initialized
INFO - 2021-01-14 09:33:06 --> Language Class Initialized
INFO - 2021-01-14 09:33:06 --> Config Class Initialized
INFO - 2021-01-14 09:33:06 --> Loader Class Initialized
INFO - 2021-01-14 09:33:06 --> Helper loaded: url_helper
INFO - 2021-01-14 09:33:06 --> Helper loaded: file_helper
INFO - 2021-01-14 09:33:06 --> Helper loaded: form_helper
INFO - 2021-01-14 09:33:06 --> Helper loaded: my_helper
INFO - 2021-01-14 09:33:06 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:33:06 --> Controller Class Initialized
DEBUG - 2021-01-14 09:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-01-14 09:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 09:33:06 --> Final output sent to browser
DEBUG - 2021-01-14 09:33:06 --> Total execution time: 0.3380
INFO - 2021-01-14 09:33:08 --> Config Class Initialized
INFO - 2021-01-14 09:33:08 --> Hooks Class Initialized
DEBUG - 2021-01-14 09:33:08 --> UTF-8 Support Enabled
INFO - 2021-01-14 09:33:08 --> Utf8 Class Initialized
INFO - 2021-01-14 09:33:08 --> URI Class Initialized
INFO - 2021-01-14 09:33:08 --> Router Class Initialized
INFO - 2021-01-14 09:33:08 --> Output Class Initialized
INFO - 2021-01-14 09:33:08 --> Security Class Initialized
DEBUG - 2021-01-14 09:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-14 09:33:08 --> Input Class Initialized
INFO - 2021-01-14 09:33:08 --> Language Class Initialized
INFO - 2021-01-14 09:33:08 --> Language Class Initialized
INFO - 2021-01-14 09:33:08 --> Config Class Initialized
INFO - 2021-01-14 09:33:08 --> Loader Class Initialized
INFO - 2021-01-14 09:33:08 --> Helper loaded: url_helper
INFO - 2021-01-14 09:33:08 --> Helper loaded: file_helper
INFO - 2021-01-14 09:33:08 --> Helper loaded: form_helper
INFO - 2021-01-14 09:33:08 --> Helper loaded: my_helper
INFO - 2021-01-14 09:33:08 --> Database Driver Class Initialized
DEBUG - 2021-01-14 09:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-14 09:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-14 09:33:09 --> Controller Class Initialized
DEBUG - 2021-01-14 09:33:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-14 09:33:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-14 09:33:09 --> Final output sent to browser
DEBUG - 2021-01-14 09:33:09 --> Total execution time: 0.3041
