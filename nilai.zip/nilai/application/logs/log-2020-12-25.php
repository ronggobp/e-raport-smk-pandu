<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-25 01:02:09 --> Config Class Initialized
INFO - 2020-12-25 01:02:09 --> Hooks Class Initialized
DEBUG - 2020-12-25 01:02:09 --> UTF-8 Support Enabled
INFO - 2020-12-25 01:02:09 --> Utf8 Class Initialized
INFO - 2020-12-25 01:02:09 --> URI Class Initialized
DEBUG - 2020-12-25 01:02:10 --> No URI present. Default controller set.
INFO - 2020-12-25 01:02:10 --> Router Class Initialized
INFO - 2020-12-25 01:02:10 --> Output Class Initialized
INFO - 2020-12-25 01:02:10 --> Security Class Initialized
DEBUG - 2020-12-25 01:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 01:02:10 --> Input Class Initialized
INFO - 2020-12-25 01:02:10 --> Language Class Initialized
INFO - 2020-12-25 01:02:10 --> Language Class Initialized
INFO - 2020-12-25 01:02:10 --> Config Class Initialized
INFO - 2020-12-25 01:02:10 --> Loader Class Initialized
INFO - 2020-12-25 01:02:10 --> Helper loaded: url_helper
INFO - 2020-12-25 01:02:10 --> Helper loaded: file_helper
INFO - 2020-12-25 01:02:10 --> Helper loaded: form_helper
INFO - 2020-12-25 01:02:10 --> Helper loaded: my_helper
INFO - 2020-12-25 01:02:10 --> Database Driver Class Initialized
DEBUG - 2020-12-25 01:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 01:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 01:02:10 --> Controller Class Initialized
INFO - 2020-12-25 01:02:10 --> Config Class Initialized
INFO - 2020-12-25 01:02:10 --> Hooks Class Initialized
DEBUG - 2020-12-25 01:02:10 --> UTF-8 Support Enabled
INFO - 2020-12-25 01:02:10 --> Utf8 Class Initialized
INFO - 2020-12-25 01:02:10 --> URI Class Initialized
INFO - 2020-12-25 01:02:10 --> Router Class Initialized
INFO - 2020-12-25 01:02:10 --> Output Class Initialized
INFO - 2020-12-25 01:02:10 --> Security Class Initialized
DEBUG - 2020-12-25 01:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 01:02:10 --> Input Class Initialized
INFO - 2020-12-25 01:02:10 --> Language Class Initialized
INFO - 2020-12-25 01:02:10 --> Language Class Initialized
INFO - 2020-12-25 01:02:10 --> Config Class Initialized
INFO - 2020-12-25 01:02:10 --> Loader Class Initialized
INFO - 2020-12-25 01:02:10 --> Helper loaded: url_helper
INFO - 2020-12-25 01:02:10 --> Helper loaded: file_helper
INFO - 2020-12-25 01:02:10 --> Helper loaded: form_helper
INFO - 2020-12-25 01:02:10 --> Helper loaded: my_helper
INFO - 2020-12-25 01:02:10 --> Database Driver Class Initialized
DEBUG - 2020-12-25 01:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 01:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 01:02:10 --> Controller Class Initialized
DEBUG - 2020-12-25 01:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-25 01:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 01:02:10 --> Final output sent to browser
DEBUG - 2020-12-25 01:02:10 --> Total execution time: 0.2447
INFO - 2020-12-25 12:46:55 --> Config Class Initialized
INFO - 2020-12-25 12:46:55 --> Hooks Class Initialized
DEBUG - 2020-12-25 12:46:55 --> UTF-8 Support Enabled
INFO - 2020-12-25 12:46:55 --> Utf8 Class Initialized
INFO - 2020-12-25 12:46:55 --> URI Class Initialized
DEBUG - 2020-12-25 12:46:55 --> No URI present. Default controller set.
INFO - 2020-12-25 12:46:55 --> Router Class Initialized
INFO - 2020-12-25 12:46:55 --> Output Class Initialized
INFO - 2020-12-25 12:46:55 --> Security Class Initialized
DEBUG - 2020-12-25 12:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 12:46:55 --> Input Class Initialized
INFO - 2020-12-25 12:46:55 --> Language Class Initialized
INFO - 2020-12-25 12:46:55 --> Language Class Initialized
INFO - 2020-12-25 12:46:55 --> Config Class Initialized
INFO - 2020-12-25 12:46:55 --> Loader Class Initialized
INFO - 2020-12-25 12:46:55 --> Helper loaded: url_helper
INFO - 2020-12-25 12:46:55 --> Helper loaded: file_helper
INFO - 2020-12-25 12:46:55 --> Helper loaded: form_helper
INFO - 2020-12-25 12:46:56 --> Helper loaded: my_helper
INFO - 2020-12-25 12:46:56 --> Database Driver Class Initialized
DEBUG - 2020-12-25 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 12:46:56 --> Controller Class Initialized
INFO - 2020-12-25 12:46:56 --> Config Class Initialized
INFO - 2020-12-25 12:46:56 --> Hooks Class Initialized
DEBUG - 2020-12-25 12:46:56 --> UTF-8 Support Enabled
INFO - 2020-12-25 12:46:56 --> Utf8 Class Initialized
INFO - 2020-12-25 12:46:56 --> URI Class Initialized
INFO - 2020-12-25 12:46:56 --> Router Class Initialized
INFO - 2020-12-25 12:46:56 --> Output Class Initialized
INFO - 2020-12-25 12:46:56 --> Security Class Initialized
DEBUG - 2020-12-25 12:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 12:46:56 --> Input Class Initialized
INFO - 2020-12-25 12:46:56 --> Language Class Initialized
INFO - 2020-12-25 12:46:56 --> Language Class Initialized
INFO - 2020-12-25 12:46:56 --> Config Class Initialized
INFO - 2020-12-25 12:46:56 --> Loader Class Initialized
INFO - 2020-12-25 12:46:56 --> Helper loaded: url_helper
INFO - 2020-12-25 12:46:56 --> Helper loaded: file_helper
INFO - 2020-12-25 12:46:56 --> Helper loaded: form_helper
INFO - 2020-12-25 12:46:56 --> Helper loaded: my_helper
INFO - 2020-12-25 12:46:56 --> Database Driver Class Initialized
DEBUG - 2020-12-25 12:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 12:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 12:46:56 --> Controller Class Initialized
DEBUG - 2020-12-25 12:46:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-25 12:46:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 12:46:57 --> Final output sent to browser
DEBUG - 2020-12-25 12:46:57 --> Total execution time: 0.7684
INFO - 2020-12-25 12:47:04 --> Config Class Initialized
INFO - 2020-12-25 12:47:04 --> Hooks Class Initialized
DEBUG - 2020-12-25 12:47:04 --> UTF-8 Support Enabled
INFO - 2020-12-25 12:47:04 --> Utf8 Class Initialized
INFO - 2020-12-25 12:47:04 --> URI Class Initialized
INFO - 2020-12-25 12:47:04 --> Router Class Initialized
INFO - 2020-12-25 12:47:04 --> Output Class Initialized
INFO - 2020-12-25 12:47:04 --> Security Class Initialized
DEBUG - 2020-12-25 12:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 12:47:04 --> Input Class Initialized
INFO - 2020-12-25 12:47:04 --> Language Class Initialized
INFO - 2020-12-25 12:47:04 --> Language Class Initialized
INFO - 2020-12-25 12:47:04 --> Config Class Initialized
INFO - 2020-12-25 12:47:04 --> Loader Class Initialized
INFO - 2020-12-25 12:47:04 --> Helper loaded: url_helper
INFO - 2020-12-25 12:47:04 --> Helper loaded: file_helper
INFO - 2020-12-25 12:47:04 --> Helper loaded: form_helper
INFO - 2020-12-25 12:47:04 --> Helper loaded: my_helper
INFO - 2020-12-25 12:47:04 --> Database Driver Class Initialized
DEBUG - 2020-12-25 12:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 12:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 12:47:04 --> Controller Class Initialized
INFO - 2020-12-25 12:47:04 --> Helper loaded: cookie_helper
INFO - 2020-12-25 12:47:04 --> Final output sent to browser
DEBUG - 2020-12-25 12:47:04 --> Total execution time: 0.5685
INFO - 2020-12-25 12:47:05 --> Config Class Initialized
INFO - 2020-12-25 12:47:05 --> Hooks Class Initialized
DEBUG - 2020-12-25 12:47:05 --> UTF-8 Support Enabled
INFO - 2020-12-25 12:47:05 --> Utf8 Class Initialized
INFO - 2020-12-25 12:47:05 --> URI Class Initialized
INFO - 2020-12-25 12:47:05 --> Router Class Initialized
INFO - 2020-12-25 12:47:05 --> Output Class Initialized
INFO - 2020-12-25 12:47:05 --> Security Class Initialized
DEBUG - 2020-12-25 12:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 12:47:05 --> Input Class Initialized
INFO - 2020-12-25 12:47:05 --> Language Class Initialized
INFO - 2020-12-25 12:47:05 --> Language Class Initialized
INFO - 2020-12-25 12:47:05 --> Config Class Initialized
INFO - 2020-12-25 12:47:05 --> Loader Class Initialized
INFO - 2020-12-25 12:47:05 --> Helper loaded: url_helper
INFO - 2020-12-25 12:47:05 --> Helper loaded: file_helper
INFO - 2020-12-25 12:47:05 --> Helper loaded: form_helper
INFO - 2020-12-25 12:47:05 --> Helper loaded: my_helper
INFO - 2020-12-25 12:47:05 --> Database Driver Class Initialized
DEBUG - 2020-12-25 12:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 12:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 12:47:06 --> Controller Class Initialized
DEBUG - 2020-12-25 12:47:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-25 12:47:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 12:47:06 --> Final output sent to browser
DEBUG - 2020-12-25 12:47:06 --> Total execution time: 0.9667
INFO - 2020-12-25 12:47:19 --> Config Class Initialized
INFO - 2020-12-25 12:47:19 --> Hooks Class Initialized
DEBUG - 2020-12-25 12:47:19 --> UTF-8 Support Enabled
INFO - 2020-12-25 12:47:19 --> Utf8 Class Initialized
INFO - 2020-12-25 12:47:19 --> URI Class Initialized
INFO - 2020-12-25 12:47:19 --> Router Class Initialized
INFO - 2020-12-25 12:47:19 --> Output Class Initialized
INFO - 2020-12-25 12:47:19 --> Security Class Initialized
DEBUG - 2020-12-25 12:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 12:47:19 --> Input Class Initialized
INFO - 2020-12-25 12:47:19 --> Language Class Initialized
INFO - 2020-12-25 12:47:19 --> Language Class Initialized
INFO - 2020-12-25 12:47:19 --> Config Class Initialized
INFO - 2020-12-25 12:47:19 --> Loader Class Initialized
INFO - 2020-12-25 12:47:20 --> Helper loaded: url_helper
INFO - 2020-12-25 12:47:20 --> Helper loaded: file_helper
INFO - 2020-12-25 12:47:20 --> Helper loaded: form_helper
INFO - 2020-12-25 12:47:20 --> Helper loaded: my_helper
INFO - 2020-12-25 12:47:20 --> Database Driver Class Initialized
DEBUG - 2020-12-25 12:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 12:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 12:47:20 --> Controller Class Initialized
DEBUG - 2020-12-25 12:47:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-25 12:47:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 12:47:20 --> Final output sent to browser
DEBUG - 2020-12-25 12:47:20 --> Total execution time: 0.7559
INFO - 2020-12-25 12:58:20 --> Config Class Initialized
INFO - 2020-12-25 12:58:20 --> Hooks Class Initialized
DEBUG - 2020-12-25 12:58:20 --> UTF-8 Support Enabled
INFO - 2020-12-25 12:58:20 --> Utf8 Class Initialized
INFO - 2020-12-25 12:58:20 --> URI Class Initialized
INFO - 2020-12-25 12:58:20 --> Router Class Initialized
INFO - 2020-12-25 12:58:20 --> Output Class Initialized
INFO - 2020-12-25 12:58:20 --> Security Class Initialized
DEBUG - 2020-12-25 12:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 12:58:20 --> Input Class Initialized
INFO - 2020-12-25 12:58:20 --> Language Class Initialized
INFO - 2020-12-25 12:58:20 --> Language Class Initialized
INFO - 2020-12-25 12:58:20 --> Config Class Initialized
INFO - 2020-12-25 12:58:20 --> Loader Class Initialized
INFO - 2020-12-25 12:58:20 --> Helper loaded: url_helper
INFO - 2020-12-25 12:58:20 --> Helper loaded: file_helper
INFO - 2020-12-25 12:58:20 --> Helper loaded: form_helper
INFO - 2020-12-25 12:58:20 --> Helper loaded: my_helper
INFO - 2020-12-25 12:58:21 --> Database Driver Class Initialized
DEBUG - 2020-12-25 12:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 12:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 12:58:21 --> Controller Class Initialized
DEBUG - 2020-12-25 12:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 12:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 12:58:21 --> Final output sent to browser
DEBUG - 2020-12-25 12:58:21 --> Total execution time: 0.7970
INFO - 2020-12-25 13:32:53 --> Config Class Initialized
INFO - 2020-12-25 13:32:53 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:32:53 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:32:53 --> Utf8 Class Initialized
INFO - 2020-12-25 13:32:53 --> URI Class Initialized
INFO - 2020-12-25 13:32:53 --> Router Class Initialized
INFO - 2020-12-25 13:32:53 --> Output Class Initialized
INFO - 2020-12-25 13:32:53 --> Security Class Initialized
DEBUG - 2020-12-25 13:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:32:53 --> Input Class Initialized
INFO - 2020-12-25 13:32:53 --> Language Class Initialized
INFO - 2020-12-25 13:32:53 --> Language Class Initialized
INFO - 2020-12-25 13:32:53 --> Config Class Initialized
INFO - 2020-12-25 13:32:53 --> Loader Class Initialized
INFO - 2020-12-25 13:32:53 --> Helper loaded: url_helper
INFO - 2020-12-25 13:32:53 --> Helper loaded: file_helper
INFO - 2020-12-25 13:32:53 --> Helper loaded: form_helper
INFO - 2020-12-25 13:32:53 --> Helper loaded: my_helper
INFO - 2020-12-25 13:32:53 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:32:53 --> Controller Class Initialized
INFO - 2020-12-25 13:32:53 --> Final output sent to browser
DEBUG - 2020-12-25 13:32:53 --> Total execution time: 0.1865
INFO - 2020-12-25 13:33:24 --> Config Class Initialized
INFO - 2020-12-25 13:33:24 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:33:24 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:33:24 --> Utf8 Class Initialized
INFO - 2020-12-25 13:33:24 --> URI Class Initialized
INFO - 2020-12-25 13:33:24 --> Router Class Initialized
INFO - 2020-12-25 13:33:24 --> Output Class Initialized
INFO - 2020-12-25 13:33:24 --> Security Class Initialized
DEBUG - 2020-12-25 13:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:33:24 --> Input Class Initialized
INFO - 2020-12-25 13:33:24 --> Language Class Initialized
INFO - 2020-12-25 13:33:24 --> Language Class Initialized
INFO - 2020-12-25 13:33:24 --> Config Class Initialized
INFO - 2020-12-25 13:33:24 --> Loader Class Initialized
INFO - 2020-12-25 13:33:24 --> Helper loaded: url_helper
INFO - 2020-12-25 13:33:24 --> Helper loaded: file_helper
INFO - 2020-12-25 13:33:24 --> Helper loaded: form_helper
INFO - 2020-12-25 13:33:24 --> Helper loaded: my_helper
INFO - 2020-12-25 13:33:24 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:33:24 --> Controller Class Initialized
DEBUG - 2020-12-25 13:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:33:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:33:24 --> Final output sent to browser
DEBUG - 2020-12-25 13:33:24 --> Total execution time: 0.1996
INFO - 2020-12-25 13:33:26 --> Config Class Initialized
INFO - 2020-12-25 13:33:26 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:33:26 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:33:26 --> Utf8 Class Initialized
INFO - 2020-12-25 13:33:26 --> URI Class Initialized
INFO - 2020-12-25 13:33:26 --> Router Class Initialized
INFO - 2020-12-25 13:33:26 --> Output Class Initialized
INFO - 2020-12-25 13:33:26 --> Security Class Initialized
DEBUG - 2020-12-25 13:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:33:26 --> Input Class Initialized
INFO - 2020-12-25 13:33:26 --> Language Class Initialized
INFO - 2020-12-25 13:33:26 --> Language Class Initialized
INFO - 2020-12-25 13:33:27 --> Config Class Initialized
INFO - 2020-12-25 13:33:27 --> Loader Class Initialized
INFO - 2020-12-25 13:33:27 --> Helper loaded: url_helper
INFO - 2020-12-25 13:33:27 --> Helper loaded: file_helper
INFO - 2020-12-25 13:33:27 --> Helper loaded: form_helper
INFO - 2020-12-25 13:33:27 --> Helper loaded: my_helper
INFO - 2020-12-25 13:33:27 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:33:27 --> Controller Class Initialized
INFO - 2020-12-25 13:33:27 --> Final output sent to browser
DEBUG - 2020-12-25 13:33:27 --> Total execution time: 0.1803
INFO - 2020-12-25 13:33:48 --> Config Class Initialized
INFO - 2020-12-25 13:33:48 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:33:48 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:33:48 --> Utf8 Class Initialized
INFO - 2020-12-25 13:33:48 --> URI Class Initialized
INFO - 2020-12-25 13:33:48 --> Router Class Initialized
INFO - 2020-12-25 13:33:48 --> Output Class Initialized
INFO - 2020-12-25 13:33:48 --> Security Class Initialized
DEBUG - 2020-12-25 13:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:33:48 --> Input Class Initialized
INFO - 2020-12-25 13:33:48 --> Language Class Initialized
INFO - 2020-12-25 13:33:48 --> Language Class Initialized
INFO - 2020-12-25 13:33:48 --> Config Class Initialized
INFO - 2020-12-25 13:33:48 --> Loader Class Initialized
INFO - 2020-12-25 13:33:48 --> Helper loaded: url_helper
INFO - 2020-12-25 13:33:48 --> Helper loaded: file_helper
INFO - 2020-12-25 13:33:48 --> Helper loaded: form_helper
INFO - 2020-12-25 13:33:48 --> Helper loaded: my_helper
INFO - 2020-12-25 13:33:48 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:33:48 --> Controller Class Initialized
DEBUG - 2020-12-25 13:33:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:33:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:33:48 --> Final output sent to browser
DEBUG - 2020-12-25 13:33:48 --> Total execution time: 0.2129
INFO - 2020-12-25 13:33:50 --> Config Class Initialized
INFO - 2020-12-25 13:33:50 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:33:50 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:33:50 --> Utf8 Class Initialized
INFO - 2020-12-25 13:33:50 --> URI Class Initialized
INFO - 2020-12-25 13:33:50 --> Router Class Initialized
INFO - 2020-12-25 13:33:50 --> Output Class Initialized
INFO - 2020-12-25 13:33:50 --> Security Class Initialized
DEBUG - 2020-12-25 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:33:50 --> Input Class Initialized
INFO - 2020-12-25 13:33:50 --> Language Class Initialized
INFO - 2020-12-25 13:33:50 --> Language Class Initialized
INFO - 2020-12-25 13:33:50 --> Config Class Initialized
INFO - 2020-12-25 13:33:50 --> Loader Class Initialized
INFO - 2020-12-25 13:33:50 --> Helper loaded: url_helper
INFO - 2020-12-25 13:33:50 --> Helper loaded: file_helper
INFO - 2020-12-25 13:33:50 --> Helper loaded: form_helper
INFO - 2020-12-25 13:33:50 --> Helper loaded: my_helper
INFO - 2020-12-25 13:33:50 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:33:50 --> Controller Class Initialized
INFO - 2020-12-25 13:33:50 --> Final output sent to browser
DEBUG - 2020-12-25 13:33:50 --> Total execution time: 0.2029
INFO - 2020-12-25 13:34:53 --> Config Class Initialized
INFO - 2020-12-25 13:34:53 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:34:53 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:34:53 --> Utf8 Class Initialized
INFO - 2020-12-25 13:34:53 --> URI Class Initialized
INFO - 2020-12-25 13:34:53 --> Router Class Initialized
INFO - 2020-12-25 13:34:53 --> Output Class Initialized
INFO - 2020-12-25 13:34:53 --> Security Class Initialized
DEBUG - 2020-12-25 13:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:34:53 --> Input Class Initialized
INFO - 2020-12-25 13:34:53 --> Language Class Initialized
INFO - 2020-12-25 13:34:53 --> Language Class Initialized
INFO - 2020-12-25 13:34:53 --> Config Class Initialized
INFO - 2020-12-25 13:34:53 --> Loader Class Initialized
INFO - 2020-12-25 13:34:53 --> Helper loaded: url_helper
INFO - 2020-12-25 13:34:53 --> Helper loaded: file_helper
INFO - 2020-12-25 13:34:53 --> Helper loaded: form_helper
INFO - 2020-12-25 13:34:53 --> Helper loaded: my_helper
INFO - 2020-12-25 13:34:53 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:34:53 --> Controller Class Initialized
DEBUG - 2020-12-25 13:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:34:53 --> Final output sent to browser
DEBUG - 2020-12-25 13:34:53 --> Total execution time: 0.2132
INFO - 2020-12-25 13:35:17 --> Config Class Initialized
INFO - 2020-12-25 13:35:17 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:35:17 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:35:17 --> Utf8 Class Initialized
INFO - 2020-12-25 13:35:17 --> URI Class Initialized
INFO - 2020-12-25 13:35:17 --> Router Class Initialized
INFO - 2020-12-25 13:35:17 --> Output Class Initialized
INFO - 2020-12-25 13:35:17 --> Security Class Initialized
DEBUG - 2020-12-25 13:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:35:17 --> Input Class Initialized
INFO - 2020-12-25 13:35:17 --> Language Class Initialized
INFO - 2020-12-25 13:35:17 --> Language Class Initialized
INFO - 2020-12-25 13:35:17 --> Config Class Initialized
INFO - 2020-12-25 13:35:17 --> Loader Class Initialized
INFO - 2020-12-25 13:35:17 --> Helper loaded: url_helper
INFO - 2020-12-25 13:35:17 --> Helper loaded: file_helper
INFO - 2020-12-25 13:35:17 --> Helper loaded: form_helper
INFO - 2020-12-25 13:35:17 --> Helper loaded: my_helper
INFO - 2020-12-25 13:35:17 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:35:17 --> Controller Class Initialized
DEBUG - 2020-12-25 13:35:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:35:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:35:17 --> Final output sent to browser
DEBUG - 2020-12-25 13:35:17 --> Total execution time: 0.2177
INFO - 2020-12-25 13:35:19 --> Config Class Initialized
INFO - 2020-12-25 13:35:19 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:35:19 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:35:19 --> Utf8 Class Initialized
INFO - 2020-12-25 13:35:19 --> URI Class Initialized
INFO - 2020-12-25 13:35:19 --> Router Class Initialized
INFO - 2020-12-25 13:35:19 --> Output Class Initialized
INFO - 2020-12-25 13:35:19 --> Security Class Initialized
DEBUG - 2020-12-25 13:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:35:19 --> Input Class Initialized
INFO - 2020-12-25 13:35:19 --> Language Class Initialized
INFO - 2020-12-25 13:35:19 --> Language Class Initialized
INFO - 2020-12-25 13:35:19 --> Config Class Initialized
INFO - 2020-12-25 13:35:19 --> Loader Class Initialized
INFO - 2020-12-25 13:35:19 --> Helper loaded: url_helper
INFO - 2020-12-25 13:35:19 --> Helper loaded: file_helper
INFO - 2020-12-25 13:35:19 --> Helper loaded: form_helper
INFO - 2020-12-25 13:35:19 --> Helper loaded: my_helper
INFO - 2020-12-25 13:35:19 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:35:19 --> Controller Class Initialized
DEBUG - 2020-12-25 13:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:35:19 --> Final output sent to browser
DEBUG - 2020-12-25 13:35:19 --> Total execution time: 0.2938
INFO - 2020-12-25 13:35:20 --> Config Class Initialized
INFO - 2020-12-25 13:35:20 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:35:20 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:35:20 --> Utf8 Class Initialized
INFO - 2020-12-25 13:35:20 --> URI Class Initialized
INFO - 2020-12-25 13:35:20 --> Router Class Initialized
INFO - 2020-12-25 13:35:20 --> Output Class Initialized
INFO - 2020-12-25 13:35:20 --> Security Class Initialized
DEBUG - 2020-12-25 13:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:35:20 --> Input Class Initialized
INFO - 2020-12-25 13:35:20 --> Language Class Initialized
INFO - 2020-12-25 13:35:20 --> Language Class Initialized
INFO - 2020-12-25 13:35:20 --> Config Class Initialized
INFO - 2020-12-25 13:35:20 --> Loader Class Initialized
INFO - 2020-12-25 13:35:20 --> Helper loaded: url_helper
INFO - 2020-12-25 13:35:20 --> Helper loaded: file_helper
INFO - 2020-12-25 13:35:20 --> Helper loaded: form_helper
INFO - 2020-12-25 13:35:20 --> Helper loaded: my_helper
INFO - 2020-12-25 13:35:20 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:35:20 --> Controller Class Initialized
INFO - 2020-12-25 13:35:20 --> Final output sent to browser
DEBUG - 2020-12-25 13:35:20 --> Total execution time: 0.1812
INFO - 2020-12-25 13:35:30 --> Config Class Initialized
INFO - 2020-12-25 13:35:30 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:35:30 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:35:30 --> Utf8 Class Initialized
INFO - 2020-12-25 13:35:30 --> URI Class Initialized
INFO - 2020-12-25 13:35:30 --> Router Class Initialized
INFO - 2020-12-25 13:35:30 --> Output Class Initialized
INFO - 2020-12-25 13:35:30 --> Security Class Initialized
DEBUG - 2020-12-25 13:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:35:30 --> Input Class Initialized
INFO - 2020-12-25 13:35:30 --> Language Class Initialized
INFO - 2020-12-25 13:35:30 --> Language Class Initialized
INFO - 2020-12-25 13:35:30 --> Config Class Initialized
INFO - 2020-12-25 13:35:30 --> Loader Class Initialized
INFO - 2020-12-25 13:35:30 --> Helper loaded: url_helper
INFO - 2020-12-25 13:35:30 --> Helper loaded: file_helper
INFO - 2020-12-25 13:35:30 --> Helper loaded: form_helper
INFO - 2020-12-25 13:35:30 --> Helper loaded: my_helper
INFO - 2020-12-25 13:35:30 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:35:31 --> Controller Class Initialized
DEBUG - 2020-12-25 13:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:35:31 --> Final output sent to browser
DEBUG - 2020-12-25 13:35:31 --> Total execution time: 0.2350
INFO - 2020-12-25 13:35:32 --> Config Class Initialized
INFO - 2020-12-25 13:35:32 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:35:32 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:35:32 --> Utf8 Class Initialized
INFO - 2020-12-25 13:35:32 --> URI Class Initialized
INFO - 2020-12-25 13:35:32 --> Router Class Initialized
INFO - 2020-12-25 13:35:32 --> Output Class Initialized
INFO - 2020-12-25 13:35:32 --> Security Class Initialized
DEBUG - 2020-12-25 13:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:35:32 --> Input Class Initialized
INFO - 2020-12-25 13:35:32 --> Language Class Initialized
INFO - 2020-12-25 13:35:32 --> Language Class Initialized
INFO - 2020-12-25 13:35:32 --> Config Class Initialized
INFO - 2020-12-25 13:35:32 --> Loader Class Initialized
INFO - 2020-12-25 13:35:32 --> Helper loaded: url_helper
INFO - 2020-12-25 13:35:32 --> Helper loaded: file_helper
INFO - 2020-12-25 13:35:32 --> Helper loaded: form_helper
INFO - 2020-12-25 13:35:32 --> Helper loaded: my_helper
INFO - 2020-12-25 13:35:32 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:35:32 --> Controller Class Initialized
INFO - 2020-12-25 13:35:32 --> Final output sent to browser
DEBUG - 2020-12-25 13:35:32 --> Total execution time: 0.1952
INFO - 2020-12-25 13:37:42 --> Config Class Initialized
INFO - 2020-12-25 13:37:42 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:37:42 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:37:42 --> Utf8 Class Initialized
INFO - 2020-12-25 13:37:42 --> URI Class Initialized
INFO - 2020-12-25 13:37:42 --> Router Class Initialized
INFO - 2020-12-25 13:37:42 --> Output Class Initialized
INFO - 2020-12-25 13:37:42 --> Security Class Initialized
DEBUG - 2020-12-25 13:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:37:42 --> Input Class Initialized
INFO - 2020-12-25 13:37:42 --> Language Class Initialized
INFO - 2020-12-25 13:37:42 --> Language Class Initialized
INFO - 2020-12-25 13:37:42 --> Config Class Initialized
INFO - 2020-12-25 13:37:42 --> Loader Class Initialized
INFO - 2020-12-25 13:37:42 --> Helper loaded: url_helper
INFO - 2020-12-25 13:37:42 --> Helper loaded: file_helper
INFO - 2020-12-25 13:37:42 --> Helper loaded: form_helper
INFO - 2020-12-25 13:37:42 --> Helper loaded: my_helper
INFO - 2020-12-25 13:37:42 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:37:42 --> Controller Class Initialized
DEBUG - 2020-12-25 13:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:37:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:37:42 --> Final output sent to browser
DEBUG - 2020-12-25 13:37:42 --> Total execution time: 0.2011
INFO - 2020-12-25 13:37:45 --> Config Class Initialized
INFO - 2020-12-25 13:37:45 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:37:45 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:37:45 --> Utf8 Class Initialized
INFO - 2020-12-25 13:37:45 --> URI Class Initialized
INFO - 2020-12-25 13:37:45 --> Router Class Initialized
INFO - 2020-12-25 13:37:45 --> Output Class Initialized
INFO - 2020-12-25 13:37:45 --> Security Class Initialized
DEBUG - 2020-12-25 13:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:37:45 --> Input Class Initialized
INFO - 2020-12-25 13:37:45 --> Language Class Initialized
INFO - 2020-12-25 13:37:45 --> Language Class Initialized
INFO - 2020-12-25 13:37:45 --> Config Class Initialized
INFO - 2020-12-25 13:37:45 --> Loader Class Initialized
INFO - 2020-12-25 13:37:45 --> Helper loaded: url_helper
INFO - 2020-12-25 13:37:45 --> Helper loaded: file_helper
INFO - 2020-12-25 13:37:45 --> Helper loaded: form_helper
INFO - 2020-12-25 13:37:45 --> Helper loaded: my_helper
INFO - 2020-12-25 13:37:45 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:37:45 --> Controller Class Initialized
INFO - 2020-12-25 13:37:45 --> Final output sent to browser
DEBUG - 2020-12-25 13:37:45 --> Total execution time: 0.2098
INFO - 2020-12-25 13:37:55 --> Config Class Initialized
INFO - 2020-12-25 13:37:55 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:37:55 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:37:55 --> Utf8 Class Initialized
INFO - 2020-12-25 13:37:55 --> URI Class Initialized
INFO - 2020-12-25 13:37:55 --> Router Class Initialized
INFO - 2020-12-25 13:37:55 --> Output Class Initialized
INFO - 2020-12-25 13:37:55 --> Security Class Initialized
DEBUG - 2020-12-25 13:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:37:55 --> Input Class Initialized
INFO - 2020-12-25 13:37:55 --> Language Class Initialized
INFO - 2020-12-25 13:37:55 --> Language Class Initialized
INFO - 2020-12-25 13:37:55 --> Config Class Initialized
INFO - 2020-12-25 13:37:55 --> Loader Class Initialized
INFO - 2020-12-25 13:37:55 --> Helper loaded: url_helper
INFO - 2020-12-25 13:37:55 --> Helper loaded: file_helper
INFO - 2020-12-25 13:37:55 --> Helper loaded: form_helper
INFO - 2020-12-25 13:37:55 --> Helper loaded: my_helper
INFO - 2020-12-25 13:37:55 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:37:55 --> Controller Class Initialized
DEBUG - 2020-12-25 13:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 13:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:37:55 --> Final output sent to browser
DEBUG - 2020-12-25 13:37:55 --> Total execution time: 0.2762
INFO - 2020-12-25 13:42:23 --> Config Class Initialized
INFO - 2020-12-25 13:42:23 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:42:23 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:42:23 --> Utf8 Class Initialized
INFO - 2020-12-25 13:42:23 --> URI Class Initialized
INFO - 2020-12-25 13:42:23 --> Router Class Initialized
INFO - 2020-12-25 13:42:23 --> Output Class Initialized
INFO - 2020-12-25 13:42:23 --> Security Class Initialized
DEBUG - 2020-12-25 13:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:42:23 --> Input Class Initialized
INFO - 2020-12-25 13:42:23 --> Language Class Initialized
INFO - 2020-12-25 13:42:23 --> Language Class Initialized
INFO - 2020-12-25 13:42:23 --> Config Class Initialized
INFO - 2020-12-25 13:42:23 --> Loader Class Initialized
INFO - 2020-12-25 13:42:23 --> Helper loaded: url_helper
INFO - 2020-12-25 13:42:24 --> Helper loaded: file_helper
INFO - 2020-12-25 13:42:24 --> Helper loaded: form_helper
INFO - 2020-12-25 13:42:24 --> Helper loaded: my_helper
INFO - 2020-12-25 13:42:24 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:42:24 --> Controller Class Initialized
DEBUG - 2020-12-25 13:42:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 13:42:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 13:42:24 --> Final output sent to browser
DEBUG - 2020-12-25 13:42:24 --> Total execution time: 0.2215
INFO - 2020-12-25 13:46:49 --> Config Class Initialized
INFO - 2020-12-25 13:46:49 --> Hooks Class Initialized
DEBUG - 2020-12-25 13:46:49 --> UTF-8 Support Enabled
INFO - 2020-12-25 13:46:49 --> Utf8 Class Initialized
INFO - 2020-12-25 13:46:49 --> URI Class Initialized
INFO - 2020-12-25 13:46:49 --> Router Class Initialized
INFO - 2020-12-25 13:46:49 --> Output Class Initialized
INFO - 2020-12-25 13:46:49 --> Security Class Initialized
DEBUG - 2020-12-25 13:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 13:46:49 --> Input Class Initialized
INFO - 2020-12-25 13:46:49 --> Language Class Initialized
INFO - 2020-12-25 13:46:49 --> Language Class Initialized
INFO - 2020-12-25 13:46:49 --> Config Class Initialized
INFO - 2020-12-25 13:46:49 --> Loader Class Initialized
INFO - 2020-12-25 13:46:49 --> Helper loaded: url_helper
INFO - 2020-12-25 13:46:49 --> Helper loaded: file_helper
INFO - 2020-12-25 13:46:49 --> Helper loaded: form_helper
INFO - 2020-12-25 13:46:49 --> Helper loaded: my_helper
INFO - 2020-12-25 13:46:49 --> Database Driver Class Initialized
DEBUG - 2020-12-25 13:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 13:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 13:46:49 --> Controller Class Initialized
INFO - 2020-12-25 13:46:49 --> Final output sent to browser
DEBUG - 2020-12-25 13:46:49 --> Total execution time: 0.3208
INFO - 2020-12-25 14:02:11 --> Config Class Initialized
INFO - 2020-12-25 14:02:11 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:02:11 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:02:11 --> Utf8 Class Initialized
INFO - 2020-12-25 14:02:11 --> URI Class Initialized
INFO - 2020-12-25 14:02:12 --> Router Class Initialized
INFO - 2020-12-25 14:02:12 --> Output Class Initialized
INFO - 2020-12-25 14:02:12 --> Security Class Initialized
DEBUG - 2020-12-25 14:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:02:12 --> Input Class Initialized
INFO - 2020-12-25 14:02:12 --> Language Class Initialized
ERROR - 2020-12-25 14:02:12 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\controllers\N_karakter.php 84
INFO - 2020-12-25 14:02:48 --> Config Class Initialized
INFO - 2020-12-25 14:02:48 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:02:48 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:02:48 --> Utf8 Class Initialized
INFO - 2020-12-25 14:02:48 --> URI Class Initialized
INFO - 2020-12-25 14:02:48 --> Router Class Initialized
INFO - 2020-12-25 14:02:48 --> Output Class Initialized
INFO - 2020-12-25 14:02:48 --> Security Class Initialized
DEBUG - 2020-12-25 14:02:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:02:48 --> Input Class Initialized
INFO - 2020-12-25 14:02:48 --> Language Class Initialized
INFO - 2020-12-25 14:02:48 --> Language Class Initialized
INFO - 2020-12-25 14:02:48 --> Config Class Initialized
INFO - 2020-12-25 14:02:48 --> Loader Class Initialized
INFO - 2020-12-25 14:02:48 --> Helper loaded: url_helper
INFO - 2020-12-25 14:02:48 --> Helper loaded: file_helper
INFO - 2020-12-25 14:02:48 --> Helper loaded: form_helper
INFO - 2020-12-25 14:02:48 --> Helper loaded: my_helper
INFO - 2020-12-25 14:02:48 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:02:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:02:48 --> Controller Class Initialized
DEBUG - 2020-12-25 14:02:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:02:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:02:48 --> Final output sent to browser
DEBUG - 2020-12-25 14:02:48 --> Total execution time: 0.2231
INFO - 2020-12-25 14:03:19 --> Config Class Initialized
INFO - 2020-12-25 14:03:19 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:03:19 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:03:19 --> Utf8 Class Initialized
INFO - 2020-12-25 14:03:19 --> URI Class Initialized
INFO - 2020-12-25 14:03:20 --> Router Class Initialized
INFO - 2020-12-25 14:03:20 --> Output Class Initialized
INFO - 2020-12-25 14:03:20 --> Security Class Initialized
DEBUG - 2020-12-25 14:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:03:20 --> Input Class Initialized
INFO - 2020-12-25 14:03:20 --> Language Class Initialized
INFO - 2020-12-25 14:03:20 --> Language Class Initialized
INFO - 2020-12-25 14:03:20 --> Config Class Initialized
INFO - 2020-12-25 14:03:20 --> Loader Class Initialized
INFO - 2020-12-25 14:03:20 --> Helper loaded: url_helper
INFO - 2020-12-25 14:03:20 --> Helper loaded: file_helper
INFO - 2020-12-25 14:03:20 --> Helper loaded: form_helper
INFO - 2020-12-25 14:03:20 --> Helper loaded: my_helper
INFO - 2020-12-25 14:03:20 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:03:20 --> Controller Class Initialized
DEBUG - 2020-12-25 14:03:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:03:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:03:20 --> Final output sent to browser
DEBUG - 2020-12-25 14:03:20 --> Total execution time: 0.2263
INFO - 2020-12-25 14:04:46 --> Config Class Initialized
INFO - 2020-12-25 14:04:46 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:04:46 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:04:46 --> Utf8 Class Initialized
INFO - 2020-12-25 14:04:46 --> URI Class Initialized
INFO - 2020-12-25 14:04:46 --> Router Class Initialized
INFO - 2020-12-25 14:04:46 --> Output Class Initialized
INFO - 2020-12-25 14:04:46 --> Security Class Initialized
DEBUG - 2020-12-25 14:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:04:46 --> Input Class Initialized
INFO - 2020-12-25 14:04:46 --> Language Class Initialized
INFO - 2020-12-25 14:04:46 --> Language Class Initialized
INFO - 2020-12-25 14:04:46 --> Config Class Initialized
INFO - 2020-12-25 14:04:46 --> Loader Class Initialized
INFO - 2020-12-25 14:04:46 --> Helper loaded: url_helper
INFO - 2020-12-25 14:04:46 --> Helper loaded: file_helper
INFO - 2020-12-25 14:04:46 --> Helper loaded: form_helper
INFO - 2020-12-25 14:04:46 --> Helper loaded: my_helper
INFO - 2020-12-25 14:04:46 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:04:46 --> Controller Class Initialized
DEBUG - 2020-12-25 14:04:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:04:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:04:46 --> Final output sent to browser
DEBUG - 2020-12-25 14:04:46 --> Total execution time: 0.2271
INFO - 2020-12-25 14:05:16 --> Config Class Initialized
INFO - 2020-12-25 14:05:16 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:05:16 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:05:16 --> Utf8 Class Initialized
INFO - 2020-12-25 14:05:16 --> URI Class Initialized
INFO - 2020-12-25 14:05:16 --> Router Class Initialized
INFO - 2020-12-25 14:05:16 --> Output Class Initialized
INFO - 2020-12-25 14:05:16 --> Security Class Initialized
DEBUG - 2020-12-25 14:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:05:16 --> Input Class Initialized
INFO - 2020-12-25 14:05:16 --> Language Class Initialized
INFO - 2020-12-25 14:05:17 --> Language Class Initialized
INFO - 2020-12-25 14:05:17 --> Config Class Initialized
INFO - 2020-12-25 14:05:17 --> Loader Class Initialized
INFO - 2020-12-25 14:05:17 --> Helper loaded: url_helper
INFO - 2020-12-25 14:05:17 --> Helper loaded: file_helper
INFO - 2020-12-25 14:05:17 --> Helper loaded: form_helper
INFO - 2020-12-25 14:05:17 --> Helper loaded: my_helper
INFO - 2020-12-25 14:05:17 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:05:17 --> Controller Class Initialized
DEBUG - 2020-12-25 14:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-12-25 14:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:05:17 --> Final output sent to browser
DEBUG - 2020-12-25 14:05:17 --> Total execution time: 0.3826
INFO - 2020-12-25 14:05:25 --> Config Class Initialized
INFO - 2020-12-25 14:05:25 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:05:25 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:05:25 --> Utf8 Class Initialized
INFO - 2020-12-25 14:05:25 --> URI Class Initialized
INFO - 2020-12-25 14:05:25 --> Router Class Initialized
INFO - 2020-12-25 14:05:25 --> Output Class Initialized
INFO - 2020-12-25 14:05:25 --> Security Class Initialized
DEBUG - 2020-12-25 14:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:05:26 --> Input Class Initialized
INFO - 2020-12-25 14:05:26 --> Language Class Initialized
INFO - 2020-12-25 14:05:26 --> Language Class Initialized
INFO - 2020-12-25 14:05:26 --> Config Class Initialized
INFO - 2020-12-25 14:05:26 --> Loader Class Initialized
INFO - 2020-12-25 14:05:26 --> Helper loaded: url_helper
INFO - 2020-12-25 14:05:26 --> Helper loaded: file_helper
INFO - 2020-12-25 14:05:26 --> Helper loaded: form_helper
INFO - 2020-12-25 14:05:26 --> Helper loaded: my_helper
INFO - 2020-12-25 14:05:26 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:05:26 --> Controller Class Initialized
DEBUG - 2020-12-25 14:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-25 14:05:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:05:26 --> Final output sent to browser
DEBUG - 2020-12-25 14:05:26 --> Total execution time: 0.3157
INFO - 2020-12-25 14:05:39 --> Config Class Initialized
INFO - 2020-12-25 14:05:39 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:05:39 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:05:39 --> Utf8 Class Initialized
INFO - 2020-12-25 14:05:39 --> URI Class Initialized
INFO - 2020-12-25 14:05:39 --> Router Class Initialized
INFO - 2020-12-25 14:05:39 --> Output Class Initialized
INFO - 2020-12-25 14:05:39 --> Security Class Initialized
DEBUG - 2020-12-25 14:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:05:39 --> Input Class Initialized
INFO - 2020-12-25 14:05:39 --> Language Class Initialized
INFO - 2020-12-25 14:05:39 --> Language Class Initialized
INFO - 2020-12-25 14:05:39 --> Config Class Initialized
INFO - 2020-12-25 14:05:39 --> Loader Class Initialized
INFO - 2020-12-25 14:05:39 --> Helper loaded: url_helper
INFO - 2020-12-25 14:05:39 --> Helper loaded: file_helper
INFO - 2020-12-25 14:05:39 --> Helper loaded: form_helper
INFO - 2020-12-25 14:05:39 --> Helper loaded: my_helper
INFO - 2020-12-25 14:05:39 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:05:39 --> Controller Class Initialized
DEBUG - 2020-12-25 14:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:05:39 --> Final output sent to browser
DEBUG - 2020-12-25 14:05:39 --> Total execution time: 0.3444
INFO - 2020-12-25 14:06:03 --> Config Class Initialized
INFO - 2020-12-25 14:06:03 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:03 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:03 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:03 --> URI Class Initialized
INFO - 2020-12-25 14:06:03 --> Router Class Initialized
INFO - 2020-12-25 14:06:03 --> Output Class Initialized
INFO - 2020-12-25 14:06:03 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:03 --> Input Class Initialized
INFO - 2020-12-25 14:06:03 --> Language Class Initialized
INFO - 2020-12-25 14:06:03 --> Language Class Initialized
INFO - 2020-12-25 14:06:03 --> Config Class Initialized
INFO - 2020-12-25 14:06:03 --> Loader Class Initialized
INFO - 2020-12-25 14:06:03 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:03 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:03 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:03 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:03 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:03 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-12-25 14:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:03 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:03 --> Total execution time: 0.3105
INFO - 2020-12-25 14:06:04 --> Config Class Initialized
INFO - 2020-12-25 14:06:04 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:04 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:04 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:04 --> URI Class Initialized
INFO - 2020-12-25 14:06:04 --> Router Class Initialized
INFO - 2020-12-25 14:06:04 --> Output Class Initialized
INFO - 2020-12-25 14:06:04 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:04 --> Input Class Initialized
INFO - 2020-12-25 14:06:04 --> Language Class Initialized
INFO - 2020-12-25 14:06:04 --> Language Class Initialized
INFO - 2020-12-25 14:06:04 --> Config Class Initialized
INFO - 2020-12-25 14:06:04 --> Loader Class Initialized
INFO - 2020-12-25 14:06:04 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:04 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:04 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:04 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:04 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:04 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-25 14:06:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:04 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:04 --> Total execution time: 0.2423
INFO - 2020-12-25 14:06:06 --> Config Class Initialized
INFO - 2020-12-25 14:06:06 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:06 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:06 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:06 --> URI Class Initialized
INFO - 2020-12-25 14:06:06 --> Router Class Initialized
INFO - 2020-12-25 14:06:06 --> Output Class Initialized
INFO - 2020-12-25 14:06:06 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:07 --> Input Class Initialized
INFO - 2020-12-25 14:06:07 --> Language Class Initialized
INFO - 2020-12-25 14:06:07 --> Language Class Initialized
INFO - 2020-12-25 14:06:07 --> Config Class Initialized
INFO - 2020-12-25 14:06:07 --> Loader Class Initialized
INFO - 2020-12-25 14:06:07 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:07 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:07 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:07 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:07 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:07 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-12-25 14:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:07 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:07 --> Total execution time: 0.2739
INFO - 2020-12-25 14:06:07 --> Config Class Initialized
INFO - 2020-12-25 14:06:07 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:07 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:07 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:07 --> URI Class Initialized
INFO - 2020-12-25 14:06:07 --> Router Class Initialized
INFO - 2020-12-25 14:06:07 --> Output Class Initialized
INFO - 2020-12-25 14:06:07 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:07 --> Input Class Initialized
INFO - 2020-12-25 14:06:07 --> Language Class Initialized
INFO - 2020-12-25 14:06:07 --> Language Class Initialized
INFO - 2020-12-25 14:06:07 --> Config Class Initialized
INFO - 2020-12-25 14:06:07 --> Loader Class Initialized
INFO - 2020-12-25 14:06:07 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:07 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:07 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:07 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:07 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:08 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-25 14:06:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:08 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:08 --> Total execution time: 0.2269
INFO - 2020-12-25 14:06:09 --> Config Class Initialized
INFO - 2020-12-25 14:06:09 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:09 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:09 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:09 --> URI Class Initialized
INFO - 2020-12-25 14:06:09 --> Router Class Initialized
INFO - 2020-12-25 14:06:09 --> Output Class Initialized
INFO - 2020-12-25 14:06:09 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:09 --> Input Class Initialized
INFO - 2020-12-25 14:06:09 --> Language Class Initialized
INFO - 2020-12-25 14:06:09 --> Language Class Initialized
INFO - 2020-12-25 14:06:09 --> Config Class Initialized
INFO - 2020-12-25 14:06:09 --> Loader Class Initialized
INFO - 2020-12-25 14:06:09 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:09 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:09 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:09 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:09 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:09 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-12-25 14:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:09 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:09 --> Total execution time: 0.2996
INFO - 2020-12-25 14:06:22 --> Config Class Initialized
INFO - 2020-12-25 14:06:22 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:22 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:22 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:22 --> URI Class Initialized
INFO - 2020-12-25 14:06:22 --> Router Class Initialized
INFO - 2020-12-25 14:06:22 --> Output Class Initialized
INFO - 2020-12-25 14:06:22 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:22 --> Input Class Initialized
INFO - 2020-12-25 14:06:22 --> Language Class Initialized
INFO - 2020-12-25 14:06:22 --> Language Class Initialized
INFO - 2020-12-25 14:06:22 --> Config Class Initialized
INFO - 2020-12-25 14:06:22 --> Loader Class Initialized
INFO - 2020-12-25 14:06:22 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:22 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:22 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:22 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:22 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:22 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-25 14:06:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:22 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:22 --> Total execution time: 0.3336
INFO - 2020-12-25 14:06:24 --> Config Class Initialized
INFO - 2020-12-25 14:06:24 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:24 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:24 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:25 --> URI Class Initialized
INFO - 2020-12-25 14:06:25 --> Router Class Initialized
INFO - 2020-12-25 14:06:25 --> Output Class Initialized
INFO - 2020-12-25 14:06:25 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:25 --> Input Class Initialized
INFO - 2020-12-25 14:06:25 --> Language Class Initialized
INFO - 2020-12-25 14:06:25 --> Language Class Initialized
INFO - 2020-12-25 14:06:25 --> Config Class Initialized
INFO - 2020-12-25 14:06:25 --> Loader Class Initialized
INFO - 2020-12-25 14:06:25 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:25 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:25 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:25 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:25 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:25 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-12-25 14:06:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:25 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:25 --> Total execution time: 0.2892
INFO - 2020-12-25 14:06:26 --> Config Class Initialized
INFO - 2020-12-25 14:06:26 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:26 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:26 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:27 --> URI Class Initialized
INFO - 2020-12-25 14:06:27 --> Router Class Initialized
INFO - 2020-12-25 14:06:27 --> Output Class Initialized
INFO - 2020-12-25 14:06:27 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:27 --> Input Class Initialized
INFO - 2020-12-25 14:06:27 --> Language Class Initialized
INFO - 2020-12-25 14:06:27 --> Language Class Initialized
INFO - 2020-12-25 14:06:27 --> Config Class Initialized
INFO - 2020-12-25 14:06:27 --> Loader Class Initialized
INFO - 2020-12-25 14:06:27 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:27 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:27 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:27 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:27 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:27 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-12-25 14:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:27 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:27 --> Total execution time: 0.2968
INFO - 2020-12-25 14:06:28 --> Config Class Initialized
INFO - 2020-12-25 14:06:28 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:06:28 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:06:28 --> Utf8 Class Initialized
INFO - 2020-12-25 14:06:28 --> URI Class Initialized
INFO - 2020-12-25 14:06:28 --> Router Class Initialized
INFO - 2020-12-25 14:06:28 --> Output Class Initialized
INFO - 2020-12-25 14:06:28 --> Security Class Initialized
DEBUG - 2020-12-25 14:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:06:28 --> Input Class Initialized
INFO - 2020-12-25 14:06:28 --> Language Class Initialized
INFO - 2020-12-25 14:06:28 --> Language Class Initialized
INFO - 2020-12-25 14:06:28 --> Config Class Initialized
INFO - 2020-12-25 14:06:28 --> Loader Class Initialized
INFO - 2020-12-25 14:06:28 --> Helper loaded: url_helper
INFO - 2020-12-25 14:06:28 --> Helper loaded: file_helper
INFO - 2020-12-25 14:06:28 --> Helper loaded: form_helper
INFO - 2020-12-25 14:06:28 --> Helper loaded: my_helper
INFO - 2020-12-25 14:06:28 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:06:28 --> Controller Class Initialized
DEBUG - 2020-12-25 14:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-12-25 14:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:06:28 --> Final output sent to browser
DEBUG - 2020-12-25 14:06:28 --> Total execution time: 0.2538
INFO - 2020-12-25 14:42:59 --> Config Class Initialized
INFO - 2020-12-25 14:42:59 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:42:59 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:42:59 --> Utf8 Class Initialized
INFO - 2020-12-25 14:42:59 --> URI Class Initialized
INFO - 2020-12-25 14:42:59 --> Router Class Initialized
INFO - 2020-12-25 14:42:59 --> Output Class Initialized
INFO - 2020-12-25 14:42:59 --> Security Class Initialized
DEBUG - 2020-12-25 14:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:42:59 --> Input Class Initialized
INFO - 2020-12-25 14:42:59 --> Language Class Initialized
INFO - 2020-12-25 14:42:59 --> Language Class Initialized
INFO - 2020-12-25 14:42:59 --> Config Class Initialized
INFO - 2020-12-25 14:42:59 --> Loader Class Initialized
INFO - 2020-12-25 14:42:59 --> Helper loaded: url_helper
INFO - 2020-12-25 14:42:59 --> Helper loaded: file_helper
INFO - 2020-12-25 14:42:59 --> Helper loaded: form_helper
INFO - 2020-12-25 14:42:59 --> Helper loaded: my_helper
INFO - 2020-12-25 14:42:59 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:42:59 --> Controller Class Initialized
DEBUG - 2020-12-25 14:42:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:42:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:42:59 --> Final output sent to browser
DEBUG - 2020-12-25 14:42:59 --> Total execution time: 0.2510
INFO - 2020-12-25 14:47:01 --> Config Class Initialized
INFO - 2020-12-25 14:47:01 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:47:01 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:47:01 --> Utf8 Class Initialized
INFO - 2020-12-25 14:47:01 --> URI Class Initialized
INFO - 2020-12-25 14:47:01 --> Router Class Initialized
INFO - 2020-12-25 14:47:01 --> Output Class Initialized
INFO - 2020-12-25 14:47:01 --> Security Class Initialized
DEBUG - 2020-12-25 14:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:47:01 --> Input Class Initialized
INFO - 2020-12-25 14:47:01 --> Language Class Initialized
INFO - 2020-12-25 14:47:01 --> Language Class Initialized
INFO - 2020-12-25 14:47:01 --> Config Class Initialized
INFO - 2020-12-25 14:47:01 --> Loader Class Initialized
INFO - 2020-12-25 14:47:01 --> Helper loaded: url_helper
INFO - 2020-12-25 14:47:01 --> Helper loaded: file_helper
INFO - 2020-12-25 14:47:01 --> Helper loaded: form_helper
INFO - 2020-12-25 14:47:01 --> Helper loaded: my_helper
INFO - 2020-12-25 14:47:01 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:47:01 --> Controller Class Initialized
DEBUG - 2020-12-25 14:47:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:47:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:47:01 --> Final output sent to browser
DEBUG - 2020-12-25 14:47:01 --> Total execution time: 0.2198
INFO - 2020-12-25 14:47:43 --> Config Class Initialized
INFO - 2020-12-25 14:47:43 --> Hooks Class Initialized
DEBUG - 2020-12-25 14:47:43 --> UTF-8 Support Enabled
INFO - 2020-12-25 14:47:43 --> Utf8 Class Initialized
INFO - 2020-12-25 14:47:43 --> URI Class Initialized
INFO - 2020-12-25 14:47:43 --> Router Class Initialized
INFO - 2020-12-25 14:47:43 --> Output Class Initialized
INFO - 2020-12-25 14:47:43 --> Security Class Initialized
DEBUG - 2020-12-25 14:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 14:47:43 --> Input Class Initialized
INFO - 2020-12-25 14:47:43 --> Language Class Initialized
INFO - 2020-12-25 14:47:43 --> Language Class Initialized
INFO - 2020-12-25 14:47:43 --> Config Class Initialized
INFO - 2020-12-25 14:47:43 --> Loader Class Initialized
INFO - 2020-12-25 14:47:43 --> Helper loaded: url_helper
INFO - 2020-12-25 14:47:43 --> Helper loaded: file_helper
INFO - 2020-12-25 14:47:43 --> Helper loaded: form_helper
INFO - 2020-12-25 14:47:43 --> Helper loaded: my_helper
INFO - 2020-12-25 14:47:43 --> Database Driver Class Initialized
DEBUG - 2020-12-25 14:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 14:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 14:47:43 --> Controller Class Initialized
DEBUG - 2020-12-25 14:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 14:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 14:47:43 --> Final output sent to browser
DEBUG - 2020-12-25 14:47:43 --> Total execution time: 0.2387
INFO - 2020-12-25 15:20:37 --> Config Class Initialized
INFO - 2020-12-25 15:20:37 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:20:37 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:20:37 --> Utf8 Class Initialized
INFO - 2020-12-25 15:20:37 --> URI Class Initialized
INFO - 2020-12-25 15:20:37 --> Router Class Initialized
INFO - 2020-12-25 15:20:37 --> Output Class Initialized
INFO - 2020-12-25 15:20:37 --> Security Class Initialized
DEBUG - 2020-12-25 15:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:20:37 --> Input Class Initialized
INFO - 2020-12-25 15:20:37 --> Language Class Initialized
INFO - 2020-12-25 15:20:37 --> Language Class Initialized
INFO - 2020-12-25 15:20:38 --> Config Class Initialized
INFO - 2020-12-25 15:20:38 --> Loader Class Initialized
INFO - 2020-12-25 15:20:38 --> Helper loaded: url_helper
INFO - 2020-12-25 15:20:38 --> Helper loaded: file_helper
INFO - 2020-12-25 15:20:38 --> Helper loaded: form_helper
INFO - 2020-12-25 15:20:38 --> Helper loaded: my_helper
INFO - 2020-12-25 15:20:38 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:20:38 --> Controller Class Initialized
DEBUG - 2020-12-25 15:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:20:38 --> Final output sent to browser
DEBUG - 2020-12-25 15:20:38 --> Total execution time: 0.8268
INFO - 2020-12-25 15:22:16 --> Config Class Initialized
INFO - 2020-12-25 15:22:16 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:22:16 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:22:16 --> Utf8 Class Initialized
INFO - 2020-12-25 15:22:16 --> URI Class Initialized
INFO - 2020-12-25 15:22:16 --> Router Class Initialized
INFO - 2020-12-25 15:22:16 --> Output Class Initialized
INFO - 2020-12-25 15:22:16 --> Security Class Initialized
DEBUG - 2020-12-25 15:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:22:16 --> Input Class Initialized
INFO - 2020-12-25 15:22:16 --> Language Class Initialized
INFO - 2020-12-25 15:22:16 --> Language Class Initialized
INFO - 2020-12-25 15:22:16 --> Config Class Initialized
INFO - 2020-12-25 15:22:16 --> Loader Class Initialized
INFO - 2020-12-25 15:22:16 --> Helper loaded: url_helper
INFO - 2020-12-25 15:22:16 --> Helper loaded: file_helper
INFO - 2020-12-25 15:22:16 --> Helper loaded: form_helper
INFO - 2020-12-25 15:22:16 --> Helper loaded: my_helper
INFO - 2020-12-25 15:22:16 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:22:17 --> Controller Class Initialized
DEBUG - 2020-12-25 15:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:22:17 --> Final output sent to browser
DEBUG - 2020-12-25 15:22:17 --> Total execution time: 0.7673
INFO - 2020-12-25 15:22:30 --> Config Class Initialized
INFO - 2020-12-25 15:22:30 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:22:30 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:22:30 --> Utf8 Class Initialized
INFO - 2020-12-25 15:22:30 --> URI Class Initialized
INFO - 2020-12-25 15:22:30 --> Router Class Initialized
INFO - 2020-12-25 15:22:30 --> Output Class Initialized
INFO - 2020-12-25 15:22:30 --> Security Class Initialized
DEBUG - 2020-12-25 15:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:22:30 --> Input Class Initialized
INFO - 2020-12-25 15:22:30 --> Language Class Initialized
INFO - 2020-12-25 15:22:30 --> Language Class Initialized
INFO - 2020-12-25 15:22:30 --> Config Class Initialized
INFO - 2020-12-25 15:22:30 --> Loader Class Initialized
INFO - 2020-12-25 15:22:31 --> Helper loaded: url_helper
INFO - 2020-12-25 15:22:31 --> Helper loaded: file_helper
INFO - 2020-12-25 15:22:31 --> Helper loaded: form_helper
INFO - 2020-12-25 15:22:31 --> Helper loaded: my_helper
INFO - 2020-12-25 15:22:31 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:22:31 --> Controller Class Initialized
DEBUG - 2020-12-25 15:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:22:31 --> Final output sent to browser
DEBUG - 2020-12-25 15:22:31 --> Total execution time: 0.7419
INFO - 2020-12-25 15:22:39 --> Config Class Initialized
INFO - 2020-12-25 15:22:39 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:22:39 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:22:39 --> Utf8 Class Initialized
INFO - 2020-12-25 15:22:39 --> URI Class Initialized
INFO - 2020-12-25 15:22:39 --> Router Class Initialized
INFO - 2020-12-25 15:22:39 --> Output Class Initialized
INFO - 2020-12-25 15:22:39 --> Security Class Initialized
DEBUG - 2020-12-25 15:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:22:39 --> Input Class Initialized
INFO - 2020-12-25 15:22:39 --> Language Class Initialized
INFO - 2020-12-25 15:22:39 --> Language Class Initialized
INFO - 2020-12-25 15:22:39 --> Config Class Initialized
INFO - 2020-12-25 15:22:39 --> Loader Class Initialized
INFO - 2020-12-25 15:22:39 --> Helper loaded: url_helper
INFO - 2020-12-25 15:22:39 --> Helper loaded: file_helper
INFO - 2020-12-25 15:22:39 --> Helper loaded: form_helper
INFO - 2020-12-25 15:22:39 --> Helper loaded: my_helper
INFO - 2020-12-25 15:22:39 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:22:40 --> Controller Class Initialized
DEBUG - 2020-12-25 15:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-12-25 15:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:22:40 --> Final output sent to browser
DEBUG - 2020-12-25 15:22:40 --> Total execution time: 0.8450
INFO - 2020-12-25 15:22:41 --> Config Class Initialized
INFO - 2020-12-25 15:22:41 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:22:41 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:22:41 --> Utf8 Class Initialized
INFO - 2020-12-25 15:22:41 --> URI Class Initialized
INFO - 2020-12-25 15:22:41 --> Router Class Initialized
INFO - 2020-12-25 15:22:41 --> Output Class Initialized
INFO - 2020-12-25 15:22:41 --> Security Class Initialized
DEBUG - 2020-12-25 15:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:22:41 --> Input Class Initialized
INFO - 2020-12-25 15:22:41 --> Language Class Initialized
INFO - 2020-12-25 15:22:41 --> Language Class Initialized
INFO - 2020-12-25 15:22:41 --> Config Class Initialized
INFO - 2020-12-25 15:22:42 --> Loader Class Initialized
INFO - 2020-12-25 15:22:42 --> Helper loaded: url_helper
INFO - 2020-12-25 15:22:42 --> Helper loaded: file_helper
INFO - 2020-12-25 15:22:42 --> Helper loaded: form_helper
INFO - 2020-12-25 15:22:42 --> Helper loaded: my_helper
INFO - 2020-12-25 15:22:42 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:22:42 --> Controller Class Initialized
DEBUG - 2020-12-25 15:22:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:22:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:22:42 --> Final output sent to browser
DEBUG - 2020-12-25 15:22:42 --> Total execution time: 0.7563
INFO - 2020-12-25 15:22:54 --> Config Class Initialized
INFO - 2020-12-25 15:22:54 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:22:54 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:22:54 --> Utf8 Class Initialized
INFO - 2020-12-25 15:22:54 --> URI Class Initialized
INFO - 2020-12-25 15:22:54 --> Router Class Initialized
INFO - 2020-12-25 15:22:54 --> Output Class Initialized
INFO - 2020-12-25 15:22:55 --> Security Class Initialized
DEBUG - 2020-12-25 15:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:22:55 --> Input Class Initialized
INFO - 2020-12-25 15:22:55 --> Language Class Initialized
INFO - 2020-12-25 15:22:55 --> Language Class Initialized
INFO - 2020-12-25 15:22:55 --> Config Class Initialized
INFO - 2020-12-25 15:22:55 --> Loader Class Initialized
INFO - 2020-12-25 15:22:55 --> Helper loaded: url_helper
INFO - 2020-12-25 15:22:55 --> Helper loaded: file_helper
INFO - 2020-12-25 15:22:55 --> Helper loaded: form_helper
INFO - 2020-12-25 15:22:55 --> Helper loaded: my_helper
INFO - 2020-12-25 15:22:55 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:22:55 --> Controller Class Initialized
DEBUG - 2020-12-25 15:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:22:55 --> Final output sent to browser
DEBUG - 2020-12-25 15:22:55 --> Total execution time: 0.7930
INFO - 2020-12-25 15:23:05 --> Config Class Initialized
INFO - 2020-12-25 15:23:05 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:23:05 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:23:05 --> Utf8 Class Initialized
INFO - 2020-12-25 15:23:05 --> URI Class Initialized
INFO - 2020-12-25 15:23:05 --> Router Class Initialized
INFO - 2020-12-25 15:23:05 --> Output Class Initialized
INFO - 2020-12-25 15:23:06 --> Security Class Initialized
DEBUG - 2020-12-25 15:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:23:06 --> Input Class Initialized
INFO - 2020-12-25 15:23:06 --> Language Class Initialized
INFO - 2020-12-25 15:23:06 --> Language Class Initialized
INFO - 2020-12-25 15:23:06 --> Config Class Initialized
INFO - 2020-12-25 15:23:06 --> Loader Class Initialized
INFO - 2020-12-25 15:23:06 --> Helper loaded: url_helper
INFO - 2020-12-25 15:23:06 --> Helper loaded: file_helper
INFO - 2020-12-25 15:23:06 --> Helper loaded: form_helper
INFO - 2020-12-25 15:23:06 --> Helper loaded: my_helper
INFO - 2020-12-25 15:23:06 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:23:06 --> Controller Class Initialized
DEBUG - 2020-12-25 15:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:23:06 --> Final output sent to browser
DEBUG - 2020-12-25 15:23:06 --> Total execution time: 0.7765
INFO - 2020-12-25 15:24:23 --> Config Class Initialized
INFO - 2020-12-25 15:24:23 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:24:23 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:24:23 --> Utf8 Class Initialized
INFO - 2020-12-25 15:24:23 --> URI Class Initialized
INFO - 2020-12-25 15:24:23 --> Router Class Initialized
INFO - 2020-12-25 15:24:23 --> Output Class Initialized
INFO - 2020-12-25 15:24:23 --> Security Class Initialized
DEBUG - 2020-12-25 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:24:23 --> Input Class Initialized
INFO - 2020-12-25 15:24:23 --> Language Class Initialized
INFO - 2020-12-25 15:24:23 --> Language Class Initialized
INFO - 2020-12-25 15:24:23 --> Config Class Initialized
INFO - 2020-12-25 15:24:23 --> Loader Class Initialized
INFO - 2020-12-25 15:24:23 --> Helper loaded: url_helper
INFO - 2020-12-25 15:24:23 --> Helper loaded: file_helper
INFO - 2020-12-25 15:24:23 --> Helper loaded: form_helper
INFO - 2020-12-25 15:24:23 --> Helper loaded: my_helper
INFO - 2020-12-25 15:24:23 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:24:23 --> Controller Class Initialized
ERROR - 2020-12-25 15:24:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:25 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:26 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:27 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:28 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:29 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:30 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:31 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:32 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:33 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:34 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:35 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:36 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:37 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:38 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:24:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:24:40 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
DEBUG - 2020-12-25 15:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:24:40 --> Final output sent to browser
DEBUG - 2020-12-25 15:24:40 --> Total execution time: 17.2362
INFO - 2020-12-25 15:29:01 --> Config Class Initialized
INFO - 2020-12-25 15:29:01 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:29:01 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:29:01 --> Utf8 Class Initialized
INFO - 2020-12-25 15:29:02 --> URI Class Initialized
INFO - 2020-12-25 15:29:02 --> Router Class Initialized
INFO - 2020-12-25 15:29:02 --> Output Class Initialized
INFO - 2020-12-25 15:29:02 --> Security Class Initialized
DEBUG - 2020-12-25 15:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:29:02 --> Input Class Initialized
INFO - 2020-12-25 15:29:02 --> Language Class Initialized
INFO - 2020-12-25 15:29:02 --> Language Class Initialized
INFO - 2020-12-25 15:29:02 --> Config Class Initialized
INFO - 2020-12-25 15:29:02 --> Loader Class Initialized
INFO - 2020-12-25 15:29:02 --> Helper loaded: url_helper
INFO - 2020-12-25 15:29:02 --> Helper loaded: file_helper
INFO - 2020-12-25 15:29:02 --> Helper loaded: form_helper
INFO - 2020-12-25 15:29:02 --> Helper loaded: my_helper
INFO - 2020-12-25 15:29:02 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:29:02 --> Controller Class Initialized
DEBUG - 2020-12-25 15:29:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:29:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:29:02 --> Final output sent to browser
DEBUG - 2020-12-25 15:29:02 --> Total execution time: 0.9404
INFO - 2020-12-25 15:30:18 --> Config Class Initialized
INFO - 2020-12-25 15:30:18 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:30:18 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:30:18 --> Utf8 Class Initialized
INFO - 2020-12-25 15:30:18 --> URI Class Initialized
INFO - 2020-12-25 15:30:18 --> Router Class Initialized
INFO - 2020-12-25 15:30:18 --> Output Class Initialized
INFO - 2020-12-25 15:30:18 --> Security Class Initialized
DEBUG - 2020-12-25 15:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:30:18 --> Input Class Initialized
INFO - 2020-12-25 15:30:18 --> Language Class Initialized
INFO - 2020-12-25 15:30:18 --> Language Class Initialized
INFO - 2020-12-25 15:30:18 --> Config Class Initialized
INFO - 2020-12-25 15:30:18 --> Loader Class Initialized
INFO - 2020-12-25 15:30:18 --> Helper loaded: url_helper
INFO - 2020-12-25 15:30:18 --> Helper loaded: file_helper
INFO - 2020-12-25 15:30:18 --> Helper loaded: form_helper
INFO - 2020-12-25 15:30:18 --> Helper loaded: my_helper
INFO - 2020-12-25 15:30:18 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:30:19 --> Controller Class Initialized
DEBUG - 2020-12-25 15:30:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:30:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:30:19 --> Final output sent to browser
DEBUG - 2020-12-25 15:30:19 --> Total execution time: 0.9340
INFO - 2020-12-25 15:39:30 --> Config Class Initialized
INFO - 2020-12-25 15:39:30 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:39:30 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:39:30 --> Utf8 Class Initialized
INFO - 2020-12-25 15:39:30 --> URI Class Initialized
INFO - 2020-12-25 15:39:30 --> Router Class Initialized
INFO - 2020-12-25 15:39:30 --> Output Class Initialized
INFO - 2020-12-25 15:39:30 --> Security Class Initialized
DEBUG - 2020-12-25 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:39:31 --> Input Class Initialized
INFO - 2020-12-25 15:39:31 --> Language Class Initialized
INFO - 2020-12-25 15:39:31 --> Language Class Initialized
INFO - 2020-12-25 15:39:31 --> Config Class Initialized
INFO - 2020-12-25 15:39:31 --> Loader Class Initialized
INFO - 2020-12-25 15:39:31 --> Helper loaded: url_helper
INFO - 2020-12-25 15:39:31 --> Helper loaded: file_helper
INFO - 2020-12-25 15:39:31 --> Helper loaded: form_helper
INFO - 2020-12-25 15:39:31 --> Helper loaded: my_helper
INFO - 2020-12-25 15:39:31 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:39:31 --> Controller Class Initialized
ERROR - 2020-12-25 15:39:31 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-25 15:40:28 --> Config Class Initialized
INFO - 2020-12-25 15:40:28 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:40:28 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:40:28 --> Utf8 Class Initialized
INFO - 2020-12-25 15:40:28 --> URI Class Initialized
INFO - 2020-12-25 15:40:28 --> Router Class Initialized
INFO - 2020-12-25 15:40:28 --> Output Class Initialized
INFO - 2020-12-25 15:40:28 --> Security Class Initialized
DEBUG - 2020-12-25 15:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:40:28 --> Input Class Initialized
INFO - 2020-12-25 15:40:28 --> Language Class Initialized
INFO - 2020-12-25 15:40:28 --> Language Class Initialized
INFO - 2020-12-25 15:40:28 --> Config Class Initialized
INFO - 2020-12-25 15:40:28 --> Loader Class Initialized
INFO - 2020-12-25 15:40:28 --> Helper loaded: url_helper
INFO - 2020-12-25 15:40:28 --> Helper loaded: file_helper
INFO - 2020-12-25 15:40:28 --> Helper loaded: form_helper
INFO - 2020-12-25 15:40:28 --> Helper loaded: my_helper
INFO - 2020-12-25 15:40:28 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:40:29 --> Controller Class Initialized
ERROR - 2020-12-25 15:40:29 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 15:40:40 --> Config Class Initialized
INFO - 2020-12-25 15:40:40 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:40:40 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:40:40 --> Utf8 Class Initialized
INFO - 2020-12-25 15:40:40 --> URI Class Initialized
INFO - 2020-12-25 15:40:40 --> Router Class Initialized
INFO - 2020-12-25 15:40:40 --> Output Class Initialized
INFO - 2020-12-25 15:40:40 --> Security Class Initialized
DEBUG - 2020-12-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:40:40 --> Input Class Initialized
INFO - 2020-12-25 15:40:40 --> Language Class Initialized
INFO - 2020-12-25 15:40:40 --> Language Class Initialized
INFO - 2020-12-25 15:40:40 --> Config Class Initialized
INFO - 2020-12-25 15:40:40 --> Loader Class Initialized
INFO - 2020-12-25 15:40:40 --> Helper loaded: url_helper
INFO - 2020-12-25 15:40:40 --> Helper loaded: file_helper
INFO - 2020-12-25 15:40:40 --> Helper loaded: form_helper
INFO - 2020-12-25 15:40:40 --> Helper loaded: my_helper
INFO - 2020-12-25 15:40:40 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:40:40 --> Controller Class Initialized
ERROR - 2020-12-25 15:40:40 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
INFO - 2020-12-25 15:41:26 --> Config Class Initialized
INFO - 2020-12-25 15:41:26 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:41:26 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:41:26 --> Utf8 Class Initialized
INFO - 2020-12-25 15:41:26 --> URI Class Initialized
INFO - 2020-12-25 15:41:26 --> Router Class Initialized
INFO - 2020-12-25 15:41:26 --> Output Class Initialized
INFO - 2020-12-25 15:41:26 --> Security Class Initialized
DEBUG - 2020-12-25 15:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:41:26 --> Input Class Initialized
INFO - 2020-12-25 15:41:26 --> Language Class Initialized
INFO - 2020-12-25 15:41:26 --> Language Class Initialized
INFO - 2020-12-25 15:41:26 --> Config Class Initialized
INFO - 2020-12-25 15:41:26 --> Loader Class Initialized
INFO - 2020-12-25 15:41:26 --> Helper loaded: url_helper
INFO - 2020-12-25 15:41:26 --> Helper loaded: file_helper
INFO - 2020-12-25 15:41:26 --> Helper loaded: form_helper
INFO - 2020-12-25 15:41:26 --> Helper loaded: my_helper
INFO - 2020-12-25 15:41:26 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:41:26 --> Controller Class Initialized
DEBUG - 2020-12-25 15:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:41:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:41:26 --> Final output sent to browser
DEBUG - 2020-12-25 15:41:27 --> Total execution time: 0.7929
INFO - 2020-12-25 15:41:48 --> Config Class Initialized
INFO - 2020-12-25 15:41:48 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:41:48 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:41:48 --> Utf8 Class Initialized
INFO - 2020-12-25 15:41:48 --> URI Class Initialized
INFO - 2020-12-25 15:41:48 --> Router Class Initialized
INFO - 2020-12-25 15:41:48 --> Output Class Initialized
INFO - 2020-12-25 15:41:48 --> Security Class Initialized
DEBUG - 2020-12-25 15:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:41:49 --> Input Class Initialized
INFO - 2020-12-25 15:41:49 --> Language Class Initialized
INFO - 2020-12-25 15:41:49 --> Language Class Initialized
INFO - 2020-12-25 15:41:49 --> Config Class Initialized
INFO - 2020-12-25 15:41:49 --> Loader Class Initialized
INFO - 2020-12-25 15:41:49 --> Helper loaded: url_helper
INFO - 2020-12-25 15:41:49 --> Helper loaded: file_helper
INFO - 2020-12-25 15:41:49 --> Helper loaded: form_helper
INFO - 2020-12-25 15:41:49 --> Helper loaded: my_helper
INFO - 2020-12-25 15:41:49 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:41:49 --> Controller Class Initialized
ERROR - 2020-12-25 15:41:49 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 100
INFO - 2020-12-25 15:42:04 --> Config Class Initialized
INFO - 2020-12-25 15:42:04 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:42:04 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:42:04 --> Utf8 Class Initialized
INFO - 2020-12-25 15:42:04 --> URI Class Initialized
INFO - 2020-12-25 15:42:04 --> Router Class Initialized
INFO - 2020-12-25 15:42:04 --> Output Class Initialized
INFO - 2020-12-25 15:42:04 --> Security Class Initialized
DEBUG - 2020-12-25 15:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:42:04 --> Input Class Initialized
INFO - 2020-12-25 15:42:04 --> Language Class Initialized
INFO - 2020-12-25 15:42:05 --> Language Class Initialized
INFO - 2020-12-25 15:42:05 --> Config Class Initialized
INFO - 2020-12-25 15:42:05 --> Loader Class Initialized
INFO - 2020-12-25 15:42:05 --> Helper loaded: url_helper
INFO - 2020-12-25 15:42:05 --> Helper loaded: file_helper
INFO - 2020-12-25 15:42:05 --> Helper loaded: form_helper
INFO - 2020-12-25 15:42:05 --> Helper loaded: my_helper
INFO - 2020-12-25 15:42:05 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:42:05 --> Controller Class Initialized
DEBUG - 2020-12-25 15:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:42:05 --> Final output sent to browser
DEBUG - 2020-12-25 15:42:05 --> Total execution time: 0.7520
INFO - 2020-12-25 15:45:07 --> Config Class Initialized
INFO - 2020-12-25 15:45:07 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:45:07 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:45:07 --> Utf8 Class Initialized
INFO - 2020-12-25 15:45:07 --> URI Class Initialized
INFO - 2020-12-25 15:45:07 --> Router Class Initialized
INFO - 2020-12-25 15:45:07 --> Output Class Initialized
INFO - 2020-12-25 15:45:07 --> Security Class Initialized
DEBUG - 2020-12-25 15:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:45:07 --> Input Class Initialized
INFO - 2020-12-25 15:45:07 --> Language Class Initialized
INFO - 2020-12-25 15:45:07 --> Language Class Initialized
INFO - 2020-12-25 15:45:07 --> Config Class Initialized
INFO - 2020-12-25 15:45:07 --> Loader Class Initialized
INFO - 2020-12-25 15:45:07 --> Helper loaded: url_helper
INFO - 2020-12-25 15:45:07 --> Helper loaded: file_helper
INFO - 2020-12-25 15:45:07 --> Helper loaded: form_helper
INFO - 2020-12-25 15:45:07 --> Helper loaded: my_helper
INFO - 2020-12-25 15:45:07 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:45:08 --> Controller Class Initialized
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:08 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:09 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:10 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:11 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:12 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:13 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:14 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:15 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:16 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:17 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:18 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:19 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:20 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:21 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:22 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:23 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 15:45:24 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
DEBUG - 2020-12-25 15:45:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:45:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:45:25 --> Final output sent to browser
DEBUG - 2020-12-25 15:45:25 --> Total execution time: 17.8612
INFO - 2020-12-25 15:46:10 --> Config Class Initialized
INFO - 2020-12-25 15:46:10 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:46:10 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:46:10 --> Utf8 Class Initialized
INFO - 2020-12-25 15:46:10 --> URI Class Initialized
INFO - 2020-12-25 15:46:10 --> Router Class Initialized
INFO - 2020-12-25 15:46:10 --> Output Class Initialized
INFO - 2020-12-25 15:46:10 --> Security Class Initialized
DEBUG - 2020-12-25 15:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:46:10 --> Input Class Initialized
INFO - 2020-12-25 15:46:10 --> Language Class Initialized
INFO - 2020-12-25 15:46:10 --> Language Class Initialized
INFO - 2020-12-25 15:46:10 --> Config Class Initialized
INFO - 2020-12-25 15:46:10 --> Loader Class Initialized
INFO - 2020-12-25 15:46:10 --> Helper loaded: url_helper
INFO - 2020-12-25 15:46:10 --> Helper loaded: file_helper
INFO - 2020-12-25 15:46:10 --> Helper loaded: form_helper
INFO - 2020-12-25 15:46:10 --> Helper loaded: my_helper
INFO - 2020-12-25 15:46:10 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:46:10 --> Controller Class Initialized
DEBUG - 2020-12-25 15:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:46:11 --> Final output sent to browser
DEBUG - 2020-12-25 15:46:11 --> Total execution time: 1.0464
INFO - 2020-12-25 15:46:46 --> Config Class Initialized
INFO - 2020-12-25 15:46:46 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:46:46 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:46:46 --> Utf8 Class Initialized
INFO - 2020-12-25 15:46:46 --> URI Class Initialized
INFO - 2020-12-25 15:46:46 --> Router Class Initialized
INFO - 2020-12-25 15:46:46 --> Output Class Initialized
INFO - 2020-12-25 15:46:46 --> Security Class Initialized
DEBUG - 2020-12-25 15:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:46:46 --> Input Class Initialized
INFO - 2020-12-25 15:46:46 --> Language Class Initialized
INFO - 2020-12-25 15:46:46 --> Language Class Initialized
INFO - 2020-12-25 15:46:46 --> Config Class Initialized
INFO - 2020-12-25 15:46:46 --> Loader Class Initialized
INFO - 2020-12-25 15:46:46 --> Helper loaded: url_helper
INFO - 2020-12-25 15:46:46 --> Helper loaded: file_helper
INFO - 2020-12-25 15:46:46 --> Helper loaded: form_helper
INFO - 2020-12-25 15:46:46 --> Helper loaded: my_helper
INFO - 2020-12-25 15:46:46 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:46:46 --> Controller Class Initialized
DEBUG - 2020-12-25 15:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 15:46:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 15:46:47 --> Final output sent to browser
DEBUG - 2020-12-25 15:46:47 --> Total execution time: 0.9495
INFO - 2020-12-25 15:59:46 --> Config Class Initialized
INFO - 2020-12-25 15:59:46 --> Hooks Class Initialized
DEBUG - 2020-12-25 15:59:46 --> UTF-8 Support Enabled
INFO - 2020-12-25 15:59:46 --> Utf8 Class Initialized
INFO - 2020-12-25 15:59:46 --> URI Class Initialized
INFO - 2020-12-25 15:59:46 --> Router Class Initialized
INFO - 2020-12-25 15:59:46 --> Output Class Initialized
INFO - 2020-12-25 15:59:46 --> Security Class Initialized
DEBUG - 2020-12-25 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 15:59:47 --> Input Class Initialized
INFO - 2020-12-25 15:59:47 --> Language Class Initialized
INFO - 2020-12-25 15:59:47 --> Language Class Initialized
INFO - 2020-12-25 15:59:47 --> Config Class Initialized
INFO - 2020-12-25 15:59:47 --> Loader Class Initialized
INFO - 2020-12-25 15:59:47 --> Helper loaded: url_helper
INFO - 2020-12-25 15:59:47 --> Helper loaded: file_helper
INFO - 2020-12-25 15:59:47 --> Helper loaded: form_helper
INFO - 2020-12-25 15:59:47 --> Helper loaded: my_helper
INFO - 2020-12-25 15:59:47 --> Database Driver Class Initialized
DEBUG - 2020-12-25 15:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 15:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 15:59:47 --> Controller Class Initialized
ERROR - 2020-12-25 15:59:47 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 95
INFO - 2020-12-25 16:00:09 --> Config Class Initialized
INFO - 2020-12-25 16:00:09 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:00:09 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:00:09 --> Utf8 Class Initialized
INFO - 2020-12-25 16:00:09 --> URI Class Initialized
INFO - 2020-12-25 16:00:09 --> Router Class Initialized
INFO - 2020-12-25 16:00:09 --> Output Class Initialized
INFO - 2020-12-25 16:00:09 --> Security Class Initialized
DEBUG - 2020-12-25 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:00:09 --> Input Class Initialized
INFO - 2020-12-25 16:00:09 --> Language Class Initialized
INFO - 2020-12-25 16:00:09 --> Language Class Initialized
INFO - 2020-12-25 16:00:09 --> Config Class Initialized
INFO - 2020-12-25 16:00:09 --> Loader Class Initialized
INFO - 2020-12-25 16:00:09 --> Helper loaded: url_helper
INFO - 2020-12-25 16:00:09 --> Helper loaded: file_helper
INFO - 2020-12-25 16:00:09 --> Helper loaded: form_helper
INFO - 2020-12-25 16:00:09 --> Helper loaded: my_helper
INFO - 2020-12-25 16:00:09 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:00:10 --> Controller Class Initialized
ERROR - 2020-12-25 16:00:10 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 97
INFO - 2020-12-25 16:00:54 --> Config Class Initialized
INFO - 2020-12-25 16:00:54 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:00:54 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:00:54 --> Utf8 Class Initialized
INFO - 2020-12-25 16:00:54 --> URI Class Initialized
INFO - 2020-12-25 16:00:54 --> Router Class Initialized
INFO - 2020-12-25 16:00:54 --> Output Class Initialized
INFO - 2020-12-25 16:00:54 --> Security Class Initialized
DEBUG - 2020-12-25 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:00:54 --> Input Class Initialized
INFO - 2020-12-25 16:00:54 --> Language Class Initialized
INFO - 2020-12-25 16:00:54 --> Language Class Initialized
INFO - 2020-12-25 16:00:54 --> Config Class Initialized
INFO - 2020-12-25 16:00:54 --> Loader Class Initialized
INFO - 2020-12-25 16:00:54 --> Helper loaded: url_helper
INFO - 2020-12-25 16:00:54 --> Helper loaded: file_helper
INFO - 2020-12-25 16:00:54 --> Helper loaded: form_helper
INFO - 2020-12-25 16:00:54 --> Helper loaded: my_helper
INFO - 2020-12-25 16:00:54 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:00:54 --> Controller Class Initialized
ERROR - 2020-12-25 16:00:54 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:54 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:54 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:55 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:56 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:57 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:58 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:00:59 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:00 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:01 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:02 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:03 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:04 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:05 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:06 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:07 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:08 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:09 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:10 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:11 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:12 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:13 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 72
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_religius - assumed 'p_religius' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 74
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 76
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 78
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_nasionalis - assumed 'p_nasionalis' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 80
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_mandiri - assumed 'p_mandiri' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 86
ERROR - 2020-12-25 16:01:14 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
ERROR - 2020-12-25 16:01:15 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 90
ERROR - 2020-12-25 16:01:15 --> Severity: Notice --> Use of undefined constant p_gotong - assumed 'p_gotong' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
DEBUG - 2020-12-25 16:01:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:01:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:01:15 --> Final output sent to browser
DEBUG - 2020-12-25 16:01:15 --> Total execution time: 21.0775
INFO - 2020-12-25 16:06:02 --> Config Class Initialized
INFO - 2020-12-25 16:06:02 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:06:02 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:06:02 --> Utf8 Class Initialized
INFO - 2020-12-25 16:06:02 --> URI Class Initialized
INFO - 2020-12-25 16:06:02 --> Router Class Initialized
INFO - 2020-12-25 16:06:02 --> Output Class Initialized
INFO - 2020-12-25 16:06:02 --> Security Class Initialized
DEBUG - 2020-12-25 16:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:06:02 --> Input Class Initialized
INFO - 2020-12-25 16:06:02 --> Language Class Initialized
INFO - 2020-12-25 16:06:02 --> Language Class Initialized
INFO - 2020-12-25 16:06:02 --> Config Class Initialized
INFO - 2020-12-25 16:06:02 --> Loader Class Initialized
INFO - 2020-12-25 16:06:02 --> Helper loaded: url_helper
INFO - 2020-12-25 16:06:02 --> Helper loaded: file_helper
INFO - 2020-12-25 16:06:02 --> Helper loaded: form_helper
INFO - 2020-12-25 16:06:02 --> Helper loaded: my_helper
INFO - 2020-12-25 16:06:02 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:06:02 --> Controller Class Initialized
DEBUG - 2020-12-25 16:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:06:03 --> Final output sent to browser
DEBUG - 2020-12-25 16:06:03 --> Total execution time: 1.0585
INFO - 2020-12-25 16:09:26 --> Config Class Initialized
INFO - 2020-12-25 16:09:26 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:09:26 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:09:26 --> Utf8 Class Initialized
INFO - 2020-12-25 16:09:26 --> URI Class Initialized
INFO - 2020-12-25 16:09:26 --> Router Class Initialized
INFO - 2020-12-25 16:09:26 --> Output Class Initialized
INFO - 2020-12-25 16:09:26 --> Security Class Initialized
DEBUG - 2020-12-25 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:09:26 --> Input Class Initialized
INFO - 2020-12-25 16:09:26 --> Language Class Initialized
INFO - 2020-12-25 16:09:26 --> Language Class Initialized
INFO - 2020-12-25 16:09:26 --> Config Class Initialized
INFO - 2020-12-25 16:09:26 --> Loader Class Initialized
INFO - 2020-12-25 16:09:26 --> Helper loaded: url_helper
INFO - 2020-12-25 16:09:26 --> Helper loaded: file_helper
INFO - 2020-12-25 16:09:26 --> Helper loaded: form_helper
INFO - 2020-12-25 16:09:27 --> Helper loaded: my_helper
INFO - 2020-12-25 16:09:27 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:09:27 --> Controller Class Initialized
DEBUG - 2020-12-25 16:09:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:09:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:09:27 --> Final output sent to browser
DEBUG - 2020-12-25 16:09:27 --> Total execution time: 1.0590
INFO - 2020-12-25 16:12:20 --> Config Class Initialized
INFO - 2020-12-25 16:12:20 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:12:20 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:12:20 --> Utf8 Class Initialized
INFO - 2020-12-25 16:12:20 --> URI Class Initialized
INFO - 2020-12-25 16:12:20 --> Router Class Initialized
INFO - 2020-12-25 16:12:20 --> Output Class Initialized
INFO - 2020-12-25 16:12:20 --> Security Class Initialized
DEBUG - 2020-12-25 16:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:12:21 --> Input Class Initialized
INFO - 2020-12-25 16:12:21 --> Language Class Initialized
INFO - 2020-12-25 16:12:21 --> Language Class Initialized
INFO - 2020-12-25 16:12:21 --> Config Class Initialized
INFO - 2020-12-25 16:12:21 --> Loader Class Initialized
INFO - 2020-12-25 16:12:21 --> Helper loaded: url_helper
INFO - 2020-12-25 16:12:21 --> Helper loaded: file_helper
INFO - 2020-12-25 16:12:21 --> Helper loaded: form_helper
INFO - 2020-12-25 16:12:21 --> Helper loaded: my_helper
INFO - 2020-12-25 16:12:21 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:12:21 --> Controller Class Initialized
DEBUG - 2020-12-25 16:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:12:21 --> Final output sent to browser
DEBUG - 2020-12-25 16:12:21 --> Total execution time: 0.9826
INFO - 2020-12-25 16:12:51 --> Config Class Initialized
INFO - 2020-12-25 16:12:51 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:12:51 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:12:51 --> Utf8 Class Initialized
INFO - 2020-12-25 16:12:51 --> URI Class Initialized
INFO - 2020-12-25 16:12:51 --> Router Class Initialized
INFO - 2020-12-25 16:12:51 --> Output Class Initialized
INFO - 2020-12-25 16:12:51 --> Security Class Initialized
DEBUG - 2020-12-25 16:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:12:51 --> Input Class Initialized
INFO - 2020-12-25 16:12:51 --> Language Class Initialized
INFO - 2020-12-25 16:12:51 --> Language Class Initialized
INFO - 2020-12-25 16:12:51 --> Config Class Initialized
INFO - 2020-12-25 16:12:51 --> Loader Class Initialized
INFO - 2020-12-25 16:12:51 --> Helper loaded: url_helper
INFO - 2020-12-25 16:12:51 --> Helper loaded: file_helper
INFO - 2020-12-25 16:12:51 --> Helper loaded: form_helper
INFO - 2020-12-25 16:12:51 --> Helper loaded: my_helper
INFO - 2020-12-25 16:12:51 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:12:52 --> Controller Class Initialized
DEBUG - 2020-12-25 16:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:12:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:12:52 --> Final output sent to browser
DEBUG - 2020-12-25 16:12:52 --> Total execution time: 0.9317
INFO - 2020-12-25 16:13:34 --> Config Class Initialized
INFO - 2020-12-25 16:13:34 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:13:34 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:13:34 --> Utf8 Class Initialized
INFO - 2020-12-25 16:13:34 --> URI Class Initialized
INFO - 2020-12-25 16:13:34 --> Router Class Initialized
INFO - 2020-12-25 16:13:34 --> Output Class Initialized
INFO - 2020-12-25 16:13:34 --> Security Class Initialized
DEBUG - 2020-12-25 16:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:13:34 --> Input Class Initialized
INFO - 2020-12-25 16:13:34 --> Language Class Initialized
INFO - 2020-12-25 16:13:34 --> Language Class Initialized
INFO - 2020-12-25 16:13:34 --> Config Class Initialized
INFO - 2020-12-25 16:13:34 --> Loader Class Initialized
INFO - 2020-12-25 16:13:35 --> Helper loaded: url_helper
INFO - 2020-12-25 16:13:35 --> Helper loaded: file_helper
INFO - 2020-12-25 16:13:35 --> Helper loaded: form_helper
INFO - 2020-12-25 16:13:35 --> Helper loaded: my_helper
INFO - 2020-12-25 16:13:35 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:13:35 --> Controller Class Initialized
DEBUG - 2020-12-25 16:13:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:13:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:13:35 --> Final output sent to browser
DEBUG - 2020-12-25 16:13:35 --> Total execution time: 1.1997
INFO - 2020-12-25 16:15:38 --> Config Class Initialized
INFO - 2020-12-25 16:15:38 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:15:38 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:15:38 --> Utf8 Class Initialized
INFO - 2020-12-25 16:15:38 --> URI Class Initialized
INFO - 2020-12-25 16:15:38 --> Router Class Initialized
INFO - 2020-12-25 16:15:38 --> Output Class Initialized
INFO - 2020-12-25 16:15:38 --> Security Class Initialized
DEBUG - 2020-12-25 16:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:15:38 --> Input Class Initialized
INFO - 2020-12-25 16:15:38 --> Language Class Initialized
INFO - 2020-12-25 16:15:38 --> Language Class Initialized
INFO - 2020-12-25 16:15:38 --> Config Class Initialized
INFO - 2020-12-25 16:15:38 --> Loader Class Initialized
INFO - 2020-12-25 16:15:38 --> Helper loaded: url_helper
INFO - 2020-12-25 16:15:38 --> Helper loaded: file_helper
INFO - 2020-12-25 16:15:38 --> Helper loaded: form_helper
INFO - 2020-12-25 16:15:38 --> Helper loaded: my_helper
INFO - 2020-12-25 16:15:38 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:15:39 --> Controller Class Initialized
DEBUG - 2020-12-25 16:15:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:15:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:15:39 --> Final output sent to browser
DEBUG - 2020-12-25 16:15:39 --> Total execution time: 1.1960
INFO - 2020-12-25 16:24:24 --> Config Class Initialized
INFO - 2020-12-25 16:24:24 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:24:24 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:24:24 --> Utf8 Class Initialized
INFO - 2020-12-25 16:24:24 --> URI Class Initialized
INFO - 2020-12-25 16:24:24 --> Router Class Initialized
INFO - 2020-12-25 16:24:24 --> Output Class Initialized
INFO - 2020-12-25 16:24:24 --> Security Class Initialized
DEBUG - 2020-12-25 16:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:24:24 --> Input Class Initialized
INFO - 2020-12-25 16:24:24 --> Language Class Initialized
INFO - 2020-12-25 16:24:24 --> Language Class Initialized
INFO - 2020-12-25 16:24:24 --> Config Class Initialized
INFO - 2020-12-25 16:24:24 --> Loader Class Initialized
INFO - 2020-12-25 16:24:24 --> Helper loaded: url_helper
INFO - 2020-12-25 16:24:24 --> Helper loaded: file_helper
INFO - 2020-12-25 16:24:24 --> Helper loaded: form_helper
INFO - 2020-12-25 16:24:24 --> Helper loaded: my_helper
INFO - 2020-12-25 16:24:24 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:24:25 --> Controller Class Initialized
ERROR - 2020-12-25 16:24:25 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 82
INFO - 2020-12-25 16:25:08 --> Config Class Initialized
INFO - 2020-12-25 16:25:08 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:25:08 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:25:08 --> Utf8 Class Initialized
INFO - 2020-12-25 16:25:08 --> URI Class Initialized
INFO - 2020-12-25 16:25:08 --> Router Class Initialized
INFO - 2020-12-25 16:25:08 --> Output Class Initialized
INFO - 2020-12-25 16:25:08 --> Security Class Initialized
DEBUG - 2020-12-25 16:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:25:09 --> Input Class Initialized
INFO - 2020-12-25 16:25:09 --> Language Class Initialized
INFO - 2020-12-25 16:25:09 --> Language Class Initialized
INFO - 2020-12-25 16:25:09 --> Config Class Initialized
INFO - 2020-12-25 16:25:09 --> Loader Class Initialized
INFO - 2020-12-25 16:25:09 --> Helper loaded: url_helper
INFO - 2020-12-25 16:25:09 --> Helper loaded: file_helper
INFO - 2020-12-25 16:25:09 --> Helper loaded: form_helper
INFO - 2020-12-25 16:25:09 --> Helper loaded: my_helper
INFO - 2020-12-25 16:25:09 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:25:09 --> Controller Class Initialized
ERROR - 2020-12-25 16:25:09 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 88
INFO - 2020-12-25 16:25:37 --> Config Class Initialized
INFO - 2020-12-25 16:25:37 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:25:37 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:25:37 --> Utf8 Class Initialized
INFO - 2020-12-25 16:25:37 --> URI Class Initialized
INFO - 2020-12-25 16:25:37 --> Router Class Initialized
INFO - 2020-12-25 16:25:37 --> Output Class Initialized
INFO - 2020-12-25 16:25:37 --> Security Class Initialized
DEBUG - 2020-12-25 16:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:25:37 --> Input Class Initialized
INFO - 2020-12-25 16:25:37 --> Language Class Initialized
INFO - 2020-12-25 16:25:37 --> Language Class Initialized
INFO - 2020-12-25 16:25:37 --> Config Class Initialized
INFO - 2020-12-25 16:25:37 --> Loader Class Initialized
INFO - 2020-12-25 16:25:37 --> Helper loaded: url_helper
INFO - 2020-12-25 16:25:37 --> Helper loaded: file_helper
INFO - 2020-12-25 16:25:38 --> Helper loaded: form_helper
INFO - 2020-12-25 16:25:38 --> Helper loaded: my_helper
INFO - 2020-12-25 16:25:38 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:25:38 --> Controller Class Initialized
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:38 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:39 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:40 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:41 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:42 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:43 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:44 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:45 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:45 --> Severity: Notice --> Undefined variable: catatani C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:45 --> Severity: Notice --> Undefined variable: catatanr C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:45 --> Severity: Notice --> Undefined variable: catatann C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:45 --> Severity: Notice --> Undefined variable: catatanm C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
ERROR - 2020-12-25 16:25:45 --> Severity: Notice --> Undefined variable: catatang C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 93
DEBUG - 2020-12-25 16:25:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:25:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:25:45 --> Final output sent to browser
DEBUG - 2020-12-25 16:25:45 --> Total execution time: 7.9408
INFO - 2020-12-25 16:27:24 --> Config Class Initialized
INFO - 2020-12-25 16:27:24 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:27:24 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:27:24 --> Utf8 Class Initialized
INFO - 2020-12-25 16:27:24 --> URI Class Initialized
INFO - 2020-12-25 16:27:24 --> Router Class Initialized
INFO - 2020-12-25 16:27:24 --> Output Class Initialized
INFO - 2020-12-25 16:27:24 --> Security Class Initialized
DEBUG - 2020-12-25 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:27:24 --> Input Class Initialized
INFO - 2020-12-25 16:27:24 --> Language Class Initialized
INFO - 2020-12-25 16:27:24 --> Language Class Initialized
INFO - 2020-12-25 16:27:24 --> Config Class Initialized
INFO - 2020-12-25 16:27:24 --> Loader Class Initialized
INFO - 2020-12-25 16:27:25 --> Helper loaded: url_helper
INFO - 2020-12-25 16:27:25 --> Helper loaded: file_helper
INFO - 2020-12-25 16:27:25 --> Helper loaded: form_helper
INFO - 2020-12-25 16:27:25 --> Helper loaded: my_helper
INFO - 2020-12-25 16:27:25 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:27:25 --> Controller Class Initialized
DEBUG - 2020-12-25 16:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:27:25 --> Final output sent to browser
DEBUG - 2020-12-25 16:27:25 --> Total execution time: 1.0682
INFO - 2020-12-25 16:31:37 --> Config Class Initialized
INFO - 2020-12-25 16:31:37 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:31:37 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:31:37 --> Utf8 Class Initialized
INFO - 2020-12-25 16:31:37 --> URI Class Initialized
INFO - 2020-12-25 16:31:37 --> Router Class Initialized
INFO - 2020-12-25 16:31:37 --> Output Class Initialized
INFO - 2020-12-25 16:31:38 --> Security Class Initialized
DEBUG - 2020-12-25 16:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:31:38 --> Input Class Initialized
INFO - 2020-12-25 16:31:38 --> Language Class Initialized
INFO - 2020-12-25 16:31:38 --> Language Class Initialized
INFO - 2020-12-25 16:31:38 --> Config Class Initialized
INFO - 2020-12-25 16:31:38 --> Loader Class Initialized
INFO - 2020-12-25 16:31:38 --> Helper loaded: url_helper
INFO - 2020-12-25 16:31:38 --> Helper loaded: file_helper
INFO - 2020-12-25 16:31:38 --> Helper loaded: form_helper
INFO - 2020-12-25 16:31:38 --> Helper loaded: my_helper
INFO - 2020-12-25 16:31:38 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:31:38 --> Controller Class Initialized
DEBUG - 2020-12-25 16:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:31:38 --> Final output sent to browser
DEBUG - 2020-12-25 16:31:38 --> Total execution time: 1.1181
INFO - 2020-12-25 16:32:39 --> Config Class Initialized
INFO - 2020-12-25 16:32:39 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:32:39 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:32:39 --> Utf8 Class Initialized
INFO - 2020-12-25 16:32:39 --> URI Class Initialized
INFO - 2020-12-25 16:32:39 --> Router Class Initialized
INFO - 2020-12-25 16:32:39 --> Output Class Initialized
INFO - 2020-12-25 16:32:39 --> Security Class Initialized
DEBUG - 2020-12-25 16:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:32:40 --> Input Class Initialized
INFO - 2020-12-25 16:32:40 --> Language Class Initialized
INFO - 2020-12-25 16:32:40 --> Language Class Initialized
INFO - 2020-12-25 16:32:40 --> Config Class Initialized
INFO - 2020-12-25 16:32:40 --> Loader Class Initialized
INFO - 2020-12-25 16:32:40 --> Helper loaded: url_helper
INFO - 2020-12-25 16:32:40 --> Helper loaded: file_helper
INFO - 2020-12-25 16:32:40 --> Helper loaded: form_helper
INFO - 2020-12-25 16:32:40 --> Helper loaded: my_helper
INFO - 2020-12-25 16:32:40 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:32:40 --> Controller Class Initialized
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:40 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:41 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:42 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-25 16:32:43 --> Severity: Notice --> Use of undefined constant p_integritas - assumed 'p_integritas' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
DEBUG - 2020-12-25 16:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:32:43 --> Final output sent to browser
DEBUG - 2020-12-25 16:32:43 --> Total execution time: 4.2927
INFO - 2020-12-25 16:33:11 --> Config Class Initialized
INFO - 2020-12-25 16:33:11 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:33:11 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:33:11 --> Utf8 Class Initialized
INFO - 2020-12-25 16:33:11 --> URI Class Initialized
INFO - 2020-12-25 16:33:11 --> Router Class Initialized
INFO - 2020-12-25 16:33:11 --> Output Class Initialized
INFO - 2020-12-25 16:33:11 --> Security Class Initialized
DEBUG - 2020-12-25 16:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:33:11 --> Input Class Initialized
INFO - 2020-12-25 16:33:11 --> Language Class Initialized
INFO - 2020-12-25 16:33:11 --> Language Class Initialized
INFO - 2020-12-25 16:33:11 --> Config Class Initialized
INFO - 2020-12-25 16:33:11 --> Loader Class Initialized
INFO - 2020-12-25 16:33:11 --> Helper loaded: url_helper
INFO - 2020-12-25 16:33:11 --> Helper loaded: file_helper
INFO - 2020-12-25 16:33:12 --> Helper loaded: form_helper
INFO - 2020-12-25 16:33:12 --> Helper loaded: my_helper
INFO - 2020-12-25 16:33:12 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:33:12 --> Controller Class Initialized
DEBUG - 2020-12-25 16:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:33:12 --> Final output sent to browser
DEBUG - 2020-12-25 16:33:12 --> Total execution time: 0.9477
INFO - 2020-12-25 16:33:35 --> Config Class Initialized
INFO - 2020-12-25 16:33:35 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:33:35 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:33:35 --> Utf8 Class Initialized
INFO - 2020-12-25 16:33:35 --> URI Class Initialized
INFO - 2020-12-25 16:33:35 --> Router Class Initialized
INFO - 2020-12-25 16:33:35 --> Output Class Initialized
INFO - 2020-12-25 16:33:35 --> Security Class Initialized
DEBUG - 2020-12-25 16:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:33:35 --> Input Class Initialized
INFO - 2020-12-25 16:33:35 --> Language Class Initialized
INFO - 2020-12-25 16:33:35 --> Language Class Initialized
INFO - 2020-12-25 16:33:35 --> Config Class Initialized
INFO - 2020-12-25 16:33:35 --> Loader Class Initialized
INFO - 2020-12-25 16:33:35 --> Helper loaded: url_helper
INFO - 2020-12-25 16:33:36 --> Helper loaded: file_helper
INFO - 2020-12-25 16:33:36 --> Helper loaded: form_helper
INFO - 2020-12-25 16:33:36 --> Helper loaded: my_helper
INFO - 2020-12-25 16:33:36 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:33:36 --> Controller Class Initialized
DEBUG - 2020-12-25 16:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:33:36 --> Final output sent to browser
DEBUG - 2020-12-25 16:33:36 --> Total execution time: 1.2548
INFO - 2020-12-25 16:34:38 --> Config Class Initialized
INFO - 2020-12-25 16:34:38 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:34:38 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:34:38 --> Utf8 Class Initialized
INFO - 2020-12-25 16:34:38 --> URI Class Initialized
INFO - 2020-12-25 16:34:38 --> Router Class Initialized
INFO - 2020-12-25 16:34:38 --> Output Class Initialized
INFO - 2020-12-25 16:34:38 --> Security Class Initialized
DEBUG - 2020-12-25 16:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:34:38 --> Input Class Initialized
INFO - 2020-12-25 16:34:38 --> Language Class Initialized
INFO - 2020-12-25 16:34:38 --> Language Class Initialized
INFO - 2020-12-25 16:34:38 --> Config Class Initialized
INFO - 2020-12-25 16:34:38 --> Loader Class Initialized
INFO - 2020-12-25 16:34:39 --> Helper loaded: url_helper
INFO - 2020-12-25 16:34:39 --> Helper loaded: file_helper
INFO - 2020-12-25 16:34:39 --> Helper loaded: form_helper
INFO - 2020-12-25 16:34:39 --> Helper loaded: my_helper
INFO - 2020-12-25 16:34:39 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:34:39 --> Controller Class Initialized
ERROR - 2020-12-25 16:34:39 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ':' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-25 16:34:59 --> Config Class Initialized
INFO - 2020-12-25 16:34:59 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:34:59 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:34:59 --> Utf8 Class Initialized
INFO - 2020-12-25 16:34:59 --> URI Class Initialized
INFO - 2020-12-25 16:34:59 --> Router Class Initialized
INFO - 2020-12-25 16:34:59 --> Output Class Initialized
INFO - 2020-12-25 16:34:59 --> Security Class Initialized
DEBUG - 2020-12-25 16:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:34:59 --> Input Class Initialized
INFO - 2020-12-25 16:34:59 --> Language Class Initialized
INFO - 2020-12-25 16:34:59 --> Language Class Initialized
INFO - 2020-12-25 16:34:59 --> Config Class Initialized
INFO - 2020-12-25 16:34:59 --> Loader Class Initialized
INFO - 2020-12-25 16:34:59 --> Helper loaded: url_helper
INFO - 2020-12-25 16:34:59 --> Helper loaded: file_helper
INFO - 2020-12-25 16:34:59 --> Helper loaded: form_helper
INFO - 2020-12-25 16:34:59 --> Helper loaded: my_helper
INFO - 2020-12-25 16:35:00 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:35:00 --> Controller Class Initialized
DEBUG - 2020-12-25 16:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:35:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:35:00 --> Final output sent to browser
DEBUG - 2020-12-25 16:35:00 --> Total execution time: 1.1190
INFO - 2020-12-25 16:35:26 --> Config Class Initialized
INFO - 2020-12-25 16:35:26 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:35:26 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:35:26 --> Utf8 Class Initialized
INFO - 2020-12-25 16:35:26 --> URI Class Initialized
INFO - 2020-12-25 16:35:26 --> Router Class Initialized
INFO - 2020-12-25 16:35:26 --> Output Class Initialized
INFO - 2020-12-25 16:35:26 --> Security Class Initialized
DEBUG - 2020-12-25 16:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:35:26 --> Input Class Initialized
INFO - 2020-12-25 16:35:26 --> Language Class Initialized
INFO - 2020-12-25 16:35:26 --> Language Class Initialized
INFO - 2020-12-25 16:35:26 --> Config Class Initialized
INFO - 2020-12-25 16:35:26 --> Loader Class Initialized
INFO - 2020-12-25 16:35:26 --> Helper loaded: url_helper
INFO - 2020-12-25 16:35:26 --> Helper loaded: file_helper
INFO - 2020-12-25 16:35:27 --> Helper loaded: form_helper
INFO - 2020-12-25 16:35:27 --> Helper loaded: my_helper
INFO - 2020-12-25 16:35:27 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:35:27 --> Controller Class Initialized
DEBUG - 2020-12-25 16:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:35:27 --> Final output sent to browser
DEBUG - 2020-12-25 16:35:27 --> Total execution time: 0.9723
INFO - 2020-12-25 16:35:48 --> Config Class Initialized
INFO - 2020-12-25 16:35:48 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:35:48 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:35:48 --> Utf8 Class Initialized
INFO - 2020-12-25 16:35:48 --> URI Class Initialized
INFO - 2020-12-25 16:35:48 --> Router Class Initialized
INFO - 2020-12-25 16:35:48 --> Output Class Initialized
INFO - 2020-12-25 16:35:48 --> Security Class Initialized
DEBUG - 2020-12-25 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:35:48 --> Input Class Initialized
INFO - 2020-12-25 16:35:48 --> Language Class Initialized
INFO - 2020-12-25 16:35:48 --> Language Class Initialized
INFO - 2020-12-25 16:35:48 --> Config Class Initialized
INFO - 2020-12-25 16:35:48 --> Loader Class Initialized
INFO - 2020-12-25 16:35:48 --> Helper loaded: url_helper
INFO - 2020-12-25 16:35:48 --> Helper loaded: file_helper
INFO - 2020-12-25 16:35:48 --> Helper loaded: form_helper
INFO - 2020-12-25 16:35:48 --> Helper loaded: my_helper
INFO - 2020-12-25 16:35:48 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:35:48 --> Controller Class Initialized
DEBUG - 2020-12-25 16:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:35:49 --> Final output sent to browser
DEBUG - 2020-12-25 16:35:49 --> Total execution time: 0.9713
INFO - 2020-12-25 16:36:22 --> Config Class Initialized
INFO - 2020-12-25 16:36:22 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:36:22 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:36:22 --> Utf8 Class Initialized
INFO - 2020-12-25 16:36:22 --> URI Class Initialized
INFO - 2020-12-25 16:36:22 --> Router Class Initialized
INFO - 2020-12-25 16:36:22 --> Output Class Initialized
INFO - 2020-12-25 16:36:22 --> Security Class Initialized
DEBUG - 2020-12-25 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:36:22 --> Input Class Initialized
INFO - 2020-12-25 16:36:22 --> Language Class Initialized
INFO - 2020-12-25 16:36:22 --> Language Class Initialized
INFO - 2020-12-25 16:36:22 --> Config Class Initialized
INFO - 2020-12-25 16:36:22 --> Loader Class Initialized
INFO - 2020-12-25 16:36:22 --> Helper loaded: url_helper
INFO - 2020-12-25 16:36:22 --> Helper loaded: file_helper
INFO - 2020-12-25 16:36:22 --> Helper loaded: form_helper
INFO - 2020-12-25 16:36:22 --> Helper loaded: my_helper
INFO - 2020-12-25 16:36:22 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:36:22 --> Controller Class Initialized
DEBUG - 2020-12-25 16:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:36:23 --> Final output sent to browser
DEBUG - 2020-12-25 16:36:23 --> Total execution time: 0.9735
INFO - 2020-12-25 16:36:40 --> Config Class Initialized
INFO - 2020-12-25 16:36:40 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:36:40 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:36:40 --> Utf8 Class Initialized
INFO - 2020-12-25 16:36:40 --> URI Class Initialized
INFO - 2020-12-25 16:36:40 --> Router Class Initialized
INFO - 2020-12-25 16:36:40 --> Output Class Initialized
INFO - 2020-12-25 16:36:40 --> Security Class Initialized
DEBUG - 2020-12-25 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:36:40 --> Input Class Initialized
INFO - 2020-12-25 16:36:40 --> Language Class Initialized
INFO - 2020-12-25 16:36:40 --> Language Class Initialized
INFO - 2020-12-25 16:36:40 --> Config Class Initialized
INFO - 2020-12-25 16:36:40 --> Loader Class Initialized
INFO - 2020-12-25 16:36:40 --> Helper loaded: url_helper
INFO - 2020-12-25 16:36:40 --> Helper loaded: file_helper
INFO - 2020-12-25 16:36:40 --> Helper loaded: form_helper
INFO - 2020-12-25 16:36:40 --> Helper loaded: my_helper
INFO - 2020-12-25 16:36:41 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:36:41 --> Controller Class Initialized
DEBUG - 2020-12-25 16:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:36:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:36:41 --> Final output sent to browser
DEBUG - 2020-12-25 16:36:41 --> Total execution time: 1.0526
INFO - 2020-12-25 16:36:59 --> Config Class Initialized
INFO - 2020-12-25 16:36:59 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:36:59 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:36:59 --> Utf8 Class Initialized
INFO - 2020-12-25 16:36:59 --> URI Class Initialized
INFO - 2020-12-25 16:36:59 --> Router Class Initialized
INFO - 2020-12-25 16:36:59 --> Output Class Initialized
INFO - 2020-12-25 16:36:59 --> Security Class Initialized
DEBUG - 2020-12-25 16:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:36:59 --> Input Class Initialized
INFO - 2020-12-25 16:36:59 --> Language Class Initialized
INFO - 2020-12-25 16:36:59 --> Language Class Initialized
INFO - 2020-12-25 16:36:59 --> Config Class Initialized
INFO - 2020-12-25 16:36:59 --> Loader Class Initialized
INFO - 2020-12-25 16:36:59 --> Helper loaded: url_helper
INFO - 2020-12-25 16:37:00 --> Helper loaded: file_helper
INFO - 2020-12-25 16:37:00 --> Helper loaded: form_helper
INFO - 2020-12-25 16:37:00 --> Helper loaded: my_helper
INFO - 2020-12-25 16:37:00 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:37:00 --> Controller Class Initialized
ERROR - 2020-12-25 16:37:00 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
INFO - 2020-12-25 16:37:21 --> Config Class Initialized
INFO - 2020-12-25 16:37:21 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:37:21 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:37:21 --> Utf8 Class Initialized
INFO - 2020-12-25 16:37:21 --> URI Class Initialized
INFO - 2020-12-25 16:37:21 --> Router Class Initialized
INFO - 2020-12-25 16:37:21 --> Output Class Initialized
INFO - 2020-12-25 16:37:22 --> Security Class Initialized
DEBUG - 2020-12-25 16:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:37:22 --> Input Class Initialized
INFO - 2020-12-25 16:37:22 --> Language Class Initialized
INFO - 2020-12-25 16:37:22 --> Language Class Initialized
INFO - 2020-12-25 16:37:22 --> Config Class Initialized
INFO - 2020-12-25 16:37:22 --> Loader Class Initialized
INFO - 2020-12-25 16:37:22 --> Helper loaded: url_helper
INFO - 2020-12-25 16:37:22 --> Helper loaded: file_helper
INFO - 2020-12-25 16:37:22 --> Helper loaded: form_helper
INFO - 2020-12-25 16:37:22 --> Helper loaded: my_helper
INFO - 2020-12-25 16:37:22 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:37:22 --> Controller Class Initialized
ERROR - 2020-12-25 16:37:22 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
INFO - 2020-12-25 16:37:24 --> Config Class Initialized
INFO - 2020-12-25 16:37:24 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:37:24 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:37:24 --> Utf8 Class Initialized
INFO - 2020-12-25 16:37:24 --> URI Class Initialized
INFO - 2020-12-25 16:37:24 --> Router Class Initialized
INFO - 2020-12-25 16:37:24 --> Output Class Initialized
INFO - 2020-12-25 16:37:24 --> Security Class Initialized
DEBUG - 2020-12-25 16:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:37:24 --> Input Class Initialized
INFO - 2020-12-25 16:37:24 --> Language Class Initialized
INFO - 2020-12-25 16:37:25 --> Language Class Initialized
INFO - 2020-12-25 16:37:25 --> Config Class Initialized
INFO - 2020-12-25 16:37:25 --> Loader Class Initialized
INFO - 2020-12-25 16:37:25 --> Helper loaded: url_helper
INFO - 2020-12-25 16:37:25 --> Helper loaded: file_helper
INFO - 2020-12-25 16:37:25 --> Helper loaded: form_helper
INFO - 2020-12-25 16:37:25 --> Helper loaded: my_helper
INFO - 2020-12-25 16:37:25 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:37:25 --> Controller Class Initialized
ERROR - 2020-12-25 16:37:25 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
INFO - 2020-12-25 16:37:42 --> Config Class Initialized
INFO - 2020-12-25 16:37:42 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:37:42 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:37:43 --> Utf8 Class Initialized
INFO - 2020-12-25 16:37:43 --> URI Class Initialized
INFO - 2020-12-25 16:37:43 --> Router Class Initialized
INFO - 2020-12-25 16:37:43 --> Output Class Initialized
INFO - 2020-12-25 16:37:43 --> Security Class Initialized
DEBUG - 2020-12-25 16:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:37:43 --> Input Class Initialized
INFO - 2020-12-25 16:37:43 --> Language Class Initialized
INFO - 2020-12-25 16:37:43 --> Language Class Initialized
INFO - 2020-12-25 16:37:43 --> Config Class Initialized
INFO - 2020-12-25 16:37:43 --> Loader Class Initialized
INFO - 2020-12-25 16:37:43 --> Helper loaded: url_helper
INFO - 2020-12-25 16:37:43 --> Helper loaded: file_helper
INFO - 2020-12-25 16:37:43 --> Helper loaded: form_helper
INFO - 2020-12-25 16:37:43 --> Helper loaded: my_helper
INFO - 2020-12-25 16:37:43 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:37:43 --> Controller Class Initialized
DEBUG - 2020-12-25 16:37:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:37:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:37:43 --> Final output sent to browser
DEBUG - 2020-12-25 16:37:43 --> Total execution time: 0.8469
INFO - 2020-12-25 16:38:58 --> Config Class Initialized
INFO - 2020-12-25 16:38:58 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:38:58 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:38:58 --> Utf8 Class Initialized
INFO - 2020-12-25 16:38:58 --> URI Class Initialized
INFO - 2020-12-25 16:38:58 --> Router Class Initialized
INFO - 2020-12-25 16:38:58 --> Output Class Initialized
INFO - 2020-12-25 16:38:59 --> Security Class Initialized
DEBUG - 2020-12-25 16:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:38:59 --> Input Class Initialized
INFO - 2020-12-25 16:38:59 --> Language Class Initialized
INFO - 2020-12-25 16:38:59 --> Language Class Initialized
INFO - 2020-12-25 16:38:59 --> Config Class Initialized
INFO - 2020-12-25 16:38:59 --> Loader Class Initialized
INFO - 2020-12-25 16:38:59 --> Helper loaded: url_helper
INFO - 2020-12-25 16:38:59 --> Helper loaded: file_helper
INFO - 2020-12-25 16:38:59 --> Helper loaded: form_helper
INFO - 2020-12-25 16:38:59 --> Helper loaded: my_helper
INFO - 2020-12-25 16:38:59 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:38:59 --> Controller Class Initialized
ERROR - 2020-12-25 16:38:59 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-25 16:39:18 --> Config Class Initialized
INFO - 2020-12-25 16:39:18 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:39:18 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:39:18 --> Utf8 Class Initialized
INFO - 2020-12-25 16:39:19 --> URI Class Initialized
INFO - 2020-12-25 16:39:19 --> Router Class Initialized
INFO - 2020-12-25 16:39:19 --> Output Class Initialized
INFO - 2020-12-25 16:39:19 --> Security Class Initialized
DEBUG - 2020-12-25 16:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:39:19 --> Input Class Initialized
INFO - 2020-12-25 16:39:19 --> Language Class Initialized
INFO - 2020-12-25 16:39:19 --> Language Class Initialized
INFO - 2020-12-25 16:39:19 --> Config Class Initialized
INFO - 2020-12-25 16:39:19 --> Loader Class Initialized
INFO - 2020-12-25 16:39:19 --> Helper loaded: url_helper
INFO - 2020-12-25 16:39:19 --> Helper loaded: file_helper
INFO - 2020-12-25 16:39:19 --> Helper loaded: form_helper
INFO - 2020-12-25 16:39:19 --> Helper loaded: my_helper
INFO - 2020-12-25 16:39:19 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:39:19 --> Controller Class Initialized
ERROR - 2020-12-25 16:39:19 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 68
INFO - 2020-12-25 16:39:29 --> Config Class Initialized
INFO - 2020-12-25 16:39:29 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:39:29 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:39:29 --> Utf8 Class Initialized
INFO - 2020-12-25 16:39:29 --> URI Class Initialized
INFO - 2020-12-25 16:39:29 --> Router Class Initialized
INFO - 2020-12-25 16:39:29 --> Output Class Initialized
INFO - 2020-12-25 16:39:29 --> Security Class Initialized
DEBUG - 2020-12-25 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:39:29 --> Input Class Initialized
INFO - 2020-12-25 16:39:29 --> Language Class Initialized
INFO - 2020-12-25 16:39:29 --> Language Class Initialized
INFO - 2020-12-25 16:39:29 --> Config Class Initialized
INFO - 2020-12-25 16:39:29 --> Loader Class Initialized
INFO - 2020-12-25 16:39:29 --> Helper loaded: url_helper
INFO - 2020-12-25 16:39:30 --> Helper loaded: file_helper
INFO - 2020-12-25 16:39:30 --> Helper loaded: form_helper
INFO - 2020-12-25 16:39:30 --> Helper loaded: my_helper
INFO - 2020-12-25 16:39:30 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:39:30 --> Controller Class Initialized
DEBUG - 2020-12-25 16:39:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:39:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:39:30 --> Final output sent to browser
DEBUG - 2020-12-25 16:39:30 --> Total execution time: 1.3659
INFO - 2020-12-25 16:40:13 --> Config Class Initialized
INFO - 2020-12-25 16:40:13 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:40:13 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:40:13 --> Utf8 Class Initialized
INFO - 2020-12-25 16:40:13 --> URI Class Initialized
INFO - 2020-12-25 16:40:13 --> Router Class Initialized
INFO - 2020-12-25 16:40:13 --> Output Class Initialized
INFO - 2020-12-25 16:40:13 --> Security Class Initialized
DEBUG - 2020-12-25 16:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:40:13 --> Input Class Initialized
INFO - 2020-12-25 16:40:13 --> Language Class Initialized
INFO - 2020-12-25 16:40:13 --> Language Class Initialized
INFO - 2020-12-25 16:40:13 --> Config Class Initialized
INFO - 2020-12-25 16:40:13 --> Loader Class Initialized
INFO - 2020-12-25 16:40:13 --> Helper loaded: url_helper
INFO - 2020-12-25 16:40:13 --> Helper loaded: file_helper
INFO - 2020-12-25 16:40:13 --> Helper loaded: form_helper
INFO - 2020-12-25 16:40:14 --> Helper loaded: my_helper
INFO - 2020-12-25 16:40:14 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:40:14 --> Controller Class Initialized
DEBUG - 2020-12-25 16:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:40:14 --> Final output sent to browser
DEBUG - 2020-12-25 16:40:14 --> Total execution time: 1.1361
INFO - 2020-12-25 16:40:56 --> Config Class Initialized
INFO - 2020-12-25 16:40:56 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:40:56 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:40:57 --> Utf8 Class Initialized
INFO - 2020-12-25 16:40:57 --> URI Class Initialized
INFO - 2020-12-25 16:40:57 --> Router Class Initialized
INFO - 2020-12-25 16:40:57 --> Output Class Initialized
INFO - 2020-12-25 16:40:57 --> Security Class Initialized
DEBUG - 2020-12-25 16:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:40:57 --> Input Class Initialized
INFO - 2020-12-25 16:40:57 --> Language Class Initialized
INFO - 2020-12-25 16:40:57 --> Language Class Initialized
INFO - 2020-12-25 16:40:57 --> Config Class Initialized
INFO - 2020-12-25 16:40:57 --> Loader Class Initialized
INFO - 2020-12-25 16:40:57 --> Helper loaded: url_helper
INFO - 2020-12-25 16:40:57 --> Helper loaded: file_helper
INFO - 2020-12-25 16:40:57 --> Helper loaded: form_helper
INFO - 2020-12-25 16:40:57 --> Helper loaded: my_helper
INFO - 2020-12-25 16:40:57 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:40:57 --> Controller Class Initialized
DEBUG - 2020-12-25 16:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:40:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:40:58 --> Final output sent to browser
DEBUG - 2020-12-25 16:40:58 --> Total execution time: 1.1801
INFO - 2020-12-25 16:41:33 --> Config Class Initialized
INFO - 2020-12-25 16:41:33 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:41:33 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:41:33 --> Utf8 Class Initialized
INFO - 2020-12-25 16:41:33 --> URI Class Initialized
INFO - 2020-12-25 16:41:33 --> Router Class Initialized
INFO - 2020-12-25 16:41:33 --> Output Class Initialized
INFO - 2020-12-25 16:41:33 --> Security Class Initialized
DEBUG - 2020-12-25 16:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:41:33 --> Input Class Initialized
INFO - 2020-12-25 16:41:33 --> Language Class Initialized
INFO - 2020-12-25 16:41:33 --> Language Class Initialized
INFO - 2020-12-25 16:41:33 --> Config Class Initialized
INFO - 2020-12-25 16:41:33 --> Loader Class Initialized
INFO - 2020-12-25 16:41:34 --> Helper loaded: url_helper
INFO - 2020-12-25 16:41:34 --> Helper loaded: file_helper
INFO - 2020-12-25 16:41:34 --> Helper loaded: form_helper
INFO - 2020-12-25 16:41:34 --> Helper loaded: my_helper
INFO - 2020-12-25 16:41:34 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:41:34 --> Controller Class Initialized
DEBUG - 2020-12-25 16:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:41:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:41:34 --> Final output sent to browser
DEBUG - 2020-12-25 16:41:34 --> Total execution time: 1.1936
INFO - 2020-12-25 16:42:16 --> Config Class Initialized
INFO - 2020-12-25 16:42:16 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:42:16 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:42:16 --> Utf8 Class Initialized
INFO - 2020-12-25 16:42:16 --> URI Class Initialized
INFO - 2020-12-25 16:42:16 --> Router Class Initialized
INFO - 2020-12-25 16:42:17 --> Output Class Initialized
INFO - 2020-12-25 16:42:17 --> Security Class Initialized
DEBUG - 2020-12-25 16:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:42:17 --> Input Class Initialized
INFO - 2020-12-25 16:42:17 --> Language Class Initialized
INFO - 2020-12-25 16:42:17 --> Language Class Initialized
INFO - 2020-12-25 16:42:17 --> Config Class Initialized
INFO - 2020-12-25 16:42:17 --> Loader Class Initialized
INFO - 2020-12-25 16:42:17 --> Helper loaded: url_helper
INFO - 2020-12-25 16:42:17 --> Helper loaded: file_helper
INFO - 2020-12-25 16:42:17 --> Helper loaded: form_helper
INFO - 2020-12-25 16:42:17 --> Helper loaded: my_helper
INFO - 2020-12-25 16:42:17 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:42:17 --> Controller Class Initialized
DEBUG - 2020-12-25 16:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:42:17 --> Final output sent to browser
DEBUG - 2020-12-25 16:42:17 --> Total execution time: 1.0580
INFO - 2020-12-25 16:44:29 --> Config Class Initialized
INFO - 2020-12-25 16:44:29 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:44:30 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:44:30 --> Utf8 Class Initialized
INFO - 2020-12-25 16:44:30 --> URI Class Initialized
INFO - 2020-12-25 16:44:30 --> Router Class Initialized
INFO - 2020-12-25 16:44:30 --> Output Class Initialized
INFO - 2020-12-25 16:44:30 --> Security Class Initialized
DEBUG - 2020-12-25 16:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:44:30 --> Input Class Initialized
INFO - 2020-12-25 16:44:30 --> Language Class Initialized
INFO - 2020-12-25 16:44:30 --> Language Class Initialized
INFO - 2020-12-25 16:44:30 --> Config Class Initialized
INFO - 2020-12-25 16:44:30 --> Loader Class Initialized
INFO - 2020-12-25 16:44:30 --> Helper loaded: url_helper
INFO - 2020-12-25 16:44:30 --> Helper loaded: file_helper
INFO - 2020-12-25 16:44:30 --> Helper loaded: form_helper
INFO - 2020-12-25 16:44:30 --> Helper loaded: my_helper
INFO - 2020-12-25 16:44:30 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:44:30 --> Controller Class Initialized
DEBUG - 2020-12-25 16:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:44:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:44:30 --> Final output sent to browser
DEBUG - 2020-12-25 16:44:30 --> Total execution time: 0.9416
INFO - 2020-12-25 16:44:40 --> Config Class Initialized
INFO - 2020-12-25 16:44:40 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:44:40 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:44:40 --> Utf8 Class Initialized
INFO - 2020-12-25 16:44:40 --> URI Class Initialized
INFO - 2020-12-25 16:44:40 --> Router Class Initialized
INFO - 2020-12-25 16:44:40 --> Output Class Initialized
INFO - 2020-12-25 16:44:40 --> Security Class Initialized
DEBUG - 2020-12-25 16:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:44:41 --> Input Class Initialized
INFO - 2020-12-25 16:44:41 --> Language Class Initialized
INFO - 2020-12-25 16:44:41 --> Language Class Initialized
INFO - 2020-12-25 16:44:41 --> Config Class Initialized
INFO - 2020-12-25 16:44:41 --> Loader Class Initialized
INFO - 2020-12-25 16:44:41 --> Helper loaded: url_helper
INFO - 2020-12-25 16:44:41 --> Helper loaded: file_helper
INFO - 2020-12-25 16:44:41 --> Helper loaded: form_helper
INFO - 2020-12-25 16:44:41 --> Helper loaded: my_helper
INFO - 2020-12-25 16:44:41 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:44:41 --> Controller Class Initialized
DEBUG - 2020-12-25 16:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:44:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:44:41 --> Final output sent to browser
DEBUG - 2020-12-25 16:44:41 --> Total execution time: 0.9751
INFO - 2020-12-25 16:46:54 --> Config Class Initialized
INFO - 2020-12-25 16:46:54 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:46:54 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:46:54 --> Utf8 Class Initialized
INFO - 2020-12-25 16:46:54 --> URI Class Initialized
INFO - 2020-12-25 16:46:54 --> Router Class Initialized
INFO - 2020-12-25 16:46:54 --> Output Class Initialized
INFO - 2020-12-25 16:46:54 --> Security Class Initialized
DEBUG - 2020-12-25 16:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:46:54 --> Input Class Initialized
INFO - 2020-12-25 16:46:54 --> Language Class Initialized
INFO - 2020-12-25 16:46:54 --> Language Class Initialized
INFO - 2020-12-25 16:46:54 --> Config Class Initialized
INFO - 2020-12-25 16:46:54 --> Loader Class Initialized
INFO - 2020-12-25 16:46:54 --> Helper loaded: url_helper
INFO - 2020-12-25 16:46:54 --> Helper loaded: file_helper
INFO - 2020-12-25 16:46:54 --> Helper loaded: form_helper
INFO - 2020-12-25 16:46:54 --> Helper loaded: my_helper
INFO - 2020-12-25 16:46:54 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:46:54 --> Controller Class Initialized
ERROR - 2020-12-25 16:46:55 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 16:49:12 --> Config Class Initialized
INFO - 2020-12-25 16:49:12 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:49:12 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:49:12 --> Utf8 Class Initialized
INFO - 2020-12-25 16:49:12 --> URI Class Initialized
INFO - 2020-12-25 16:49:12 --> Router Class Initialized
INFO - 2020-12-25 16:49:12 --> Output Class Initialized
INFO - 2020-12-25 16:49:12 --> Security Class Initialized
DEBUG - 2020-12-25 16:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:49:12 --> Input Class Initialized
INFO - 2020-12-25 16:49:12 --> Language Class Initialized
INFO - 2020-12-25 16:49:12 --> Language Class Initialized
INFO - 2020-12-25 16:49:12 --> Config Class Initialized
INFO - 2020-12-25 16:49:12 --> Loader Class Initialized
INFO - 2020-12-25 16:49:12 --> Helper loaded: url_helper
INFO - 2020-12-25 16:49:12 --> Helper loaded: file_helper
INFO - 2020-12-25 16:49:12 --> Helper loaded: form_helper
INFO - 2020-12-25 16:49:12 --> Helper loaded: my_helper
INFO - 2020-12-25 16:49:12 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:49:12 --> Controller Class Initialized
DEBUG - 2020-12-25 16:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:49:12 --> Final output sent to browser
DEBUG - 2020-12-25 16:49:13 --> Total execution time: 0.9731
INFO - 2020-12-25 16:49:58 --> Config Class Initialized
INFO - 2020-12-25 16:49:58 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:49:58 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:49:58 --> Utf8 Class Initialized
INFO - 2020-12-25 16:49:58 --> URI Class Initialized
INFO - 2020-12-25 16:49:58 --> Router Class Initialized
INFO - 2020-12-25 16:49:58 --> Output Class Initialized
INFO - 2020-12-25 16:49:58 --> Security Class Initialized
DEBUG - 2020-12-25 16:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:49:58 --> Input Class Initialized
INFO - 2020-12-25 16:49:59 --> Language Class Initialized
INFO - 2020-12-25 16:49:59 --> Language Class Initialized
INFO - 2020-12-25 16:49:59 --> Config Class Initialized
INFO - 2020-12-25 16:49:59 --> Loader Class Initialized
INFO - 2020-12-25 16:49:59 --> Helper loaded: url_helper
INFO - 2020-12-25 16:49:59 --> Helper loaded: file_helper
INFO - 2020-12-25 16:49:59 --> Helper loaded: form_helper
INFO - 2020-12-25 16:49:59 --> Helper loaded: my_helper
INFO - 2020-12-25 16:49:59 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:49:59 --> Controller Class Initialized
DEBUG - 2020-12-25 16:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:49:59 --> Final output sent to browser
DEBUG - 2020-12-25 16:49:59 --> Total execution time: 0.8467
INFO - 2020-12-25 16:50:22 --> Config Class Initialized
INFO - 2020-12-25 16:50:22 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:50:22 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:50:22 --> Utf8 Class Initialized
INFO - 2020-12-25 16:50:22 --> URI Class Initialized
INFO - 2020-12-25 16:50:22 --> Router Class Initialized
INFO - 2020-12-25 16:50:22 --> Output Class Initialized
INFO - 2020-12-25 16:50:22 --> Security Class Initialized
DEBUG - 2020-12-25 16:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:50:22 --> Input Class Initialized
INFO - 2020-12-25 16:50:22 --> Language Class Initialized
INFO - 2020-12-25 16:50:22 --> Language Class Initialized
INFO - 2020-12-25 16:50:22 --> Config Class Initialized
INFO - 2020-12-25 16:50:22 --> Loader Class Initialized
INFO - 2020-12-25 16:50:22 --> Helper loaded: url_helper
INFO - 2020-12-25 16:50:22 --> Helper loaded: file_helper
INFO - 2020-12-25 16:50:23 --> Helper loaded: form_helper
INFO - 2020-12-25 16:50:23 --> Helper loaded: my_helper
INFO - 2020-12-25 16:50:23 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:50:23 --> Controller Class Initialized
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:23 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:24 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:25 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:26 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:26 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
ERROR - 2020-12-25 16:50:26 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
ERROR - 2020-12-25 16:50:26 --> Severity: Notice --> Use of undefined constant integritas_ - assumed 'integritas_' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
DEBUG - 2020-12-25 16:50:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:50:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:50:26 --> Final output sent to browser
DEBUG - 2020-12-25 16:50:26 --> Total execution time: 3.9422
INFO - 2020-12-25 16:50:41 --> Config Class Initialized
INFO - 2020-12-25 16:50:41 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:50:41 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:50:41 --> Utf8 Class Initialized
INFO - 2020-12-25 16:50:41 --> URI Class Initialized
INFO - 2020-12-25 16:50:42 --> Router Class Initialized
INFO - 2020-12-25 16:50:42 --> Output Class Initialized
INFO - 2020-12-25 16:50:42 --> Security Class Initialized
DEBUG - 2020-12-25 16:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:50:42 --> Input Class Initialized
INFO - 2020-12-25 16:50:42 --> Language Class Initialized
INFO - 2020-12-25 16:50:42 --> Language Class Initialized
INFO - 2020-12-25 16:50:42 --> Config Class Initialized
INFO - 2020-12-25 16:50:42 --> Loader Class Initialized
INFO - 2020-12-25 16:50:42 --> Helper loaded: url_helper
INFO - 2020-12-25 16:50:42 --> Helper loaded: file_helper
INFO - 2020-12-25 16:50:42 --> Helper loaded: form_helper
INFO - 2020-12-25 16:50:42 --> Helper loaded: my_helper
INFO - 2020-12-25 16:50:42 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:50:42 --> Controller Class Initialized
DEBUG - 2020-12-25 16:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:50:42 --> Final output sent to browser
DEBUG - 2020-12-25 16:50:42 --> Total execution time: 1.0334
INFO - 2020-12-25 16:50:56 --> Config Class Initialized
INFO - 2020-12-25 16:50:56 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:50:56 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:50:56 --> Utf8 Class Initialized
INFO - 2020-12-25 16:50:56 --> URI Class Initialized
INFO - 2020-12-25 16:50:56 --> Router Class Initialized
INFO - 2020-12-25 16:50:56 --> Output Class Initialized
INFO - 2020-12-25 16:50:56 --> Security Class Initialized
DEBUG - 2020-12-25 16:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:50:56 --> Input Class Initialized
INFO - 2020-12-25 16:50:56 --> Language Class Initialized
INFO - 2020-12-25 16:50:56 --> Language Class Initialized
INFO - 2020-12-25 16:50:56 --> Config Class Initialized
INFO - 2020-12-25 16:50:57 --> Loader Class Initialized
INFO - 2020-12-25 16:50:57 --> Helper loaded: url_helper
INFO - 2020-12-25 16:50:57 --> Helper loaded: file_helper
INFO - 2020-12-25 16:50:57 --> Helper loaded: form_helper
INFO - 2020-12-25 16:50:57 --> Helper loaded: my_helper
INFO - 2020-12-25 16:50:57 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:50:57 --> Controller Class Initialized
DEBUG - 2020-12-25 16:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:50:57 --> Final output sent to browser
DEBUG - 2020-12-25 16:50:57 --> Total execution time: 1.2479
INFO - 2020-12-25 16:51:12 --> Config Class Initialized
INFO - 2020-12-25 16:51:12 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:51:12 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:51:12 --> Utf8 Class Initialized
INFO - 2020-12-25 16:51:12 --> URI Class Initialized
INFO - 2020-12-25 16:51:12 --> Router Class Initialized
INFO - 2020-12-25 16:51:13 --> Output Class Initialized
INFO - 2020-12-25 16:51:13 --> Security Class Initialized
DEBUG - 2020-12-25 16:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:51:13 --> Input Class Initialized
INFO - 2020-12-25 16:51:13 --> Language Class Initialized
INFO - 2020-12-25 16:51:13 --> Language Class Initialized
INFO - 2020-12-25 16:51:13 --> Config Class Initialized
INFO - 2020-12-25 16:51:13 --> Loader Class Initialized
INFO - 2020-12-25 16:51:13 --> Helper loaded: url_helper
INFO - 2020-12-25 16:51:13 --> Helper loaded: file_helper
INFO - 2020-12-25 16:51:13 --> Helper loaded: form_helper
INFO - 2020-12-25 16:51:13 --> Helper loaded: my_helper
INFO - 2020-12-25 16:51:13 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:51:13 --> Controller Class Initialized
DEBUG - 2020-12-25 16:51:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:51:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:51:13 --> Final output sent to browser
DEBUG - 2020-12-25 16:51:13 --> Total execution time: 1.0932
INFO - 2020-12-25 16:53:35 --> Config Class Initialized
INFO - 2020-12-25 16:53:35 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:53:35 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:53:35 --> Utf8 Class Initialized
INFO - 2020-12-25 16:53:35 --> URI Class Initialized
INFO - 2020-12-25 16:53:35 --> Router Class Initialized
INFO - 2020-12-25 16:53:35 --> Output Class Initialized
INFO - 2020-12-25 16:53:35 --> Security Class Initialized
DEBUG - 2020-12-25 16:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:53:35 --> Input Class Initialized
INFO - 2020-12-25 16:53:35 --> Language Class Initialized
INFO - 2020-12-25 16:53:35 --> Language Class Initialized
INFO - 2020-12-25 16:53:35 --> Config Class Initialized
INFO - 2020-12-25 16:53:35 --> Loader Class Initialized
INFO - 2020-12-25 16:53:35 --> Helper loaded: url_helper
INFO - 2020-12-25 16:53:35 --> Helper loaded: file_helper
INFO - 2020-12-25 16:53:35 --> Helper loaded: form_helper
INFO - 2020-12-25 16:53:35 --> Helper loaded: my_helper
INFO - 2020-12-25 16:53:35 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:53:35 --> Controller Class Initialized
ERROR - 2020-12-25 16:53:35 --> Severity: Parsing Error --> syntax error, unexpected '$p_integritas' (T_VARIABLE), expecting '(' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 16:54:06 --> Config Class Initialized
INFO - 2020-12-25 16:54:06 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:54:06 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:54:06 --> Utf8 Class Initialized
INFO - 2020-12-25 16:54:06 --> URI Class Initialized
INFO - 2020-12-25 16:54:06 --> Router Class Initialized
INFO - 2020-12-25 16:54:06 --> Output Class Initialized
INFO - 2020-12-25 16:54:06 --> Security Class Initialized
DEBUG - 2020-12-25 16:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:54:06 --> Input Class Initialized
INFO - 2020-12-25 16:54:06 --> Language Class Initialized
INFO - 2020-12-25 16:54:06 --> Language Class Initialized
INFO - 2020-12-25 16:54:06 --> Config Class Initialized
INFO - 2020-12-25 16:54:06 --> Loader Class Initialized
INFO - 2020-12-25 16:54:07 --> Helper loaded: url_helper
INFO - 2020-12-25 16:54:07 --> Helper loaded: file_helper
INFO - 2020-12-25 16:54:07 --> Helper loaded: form_helper
INFO - 2020-12-25 16:54:07 --> Helper loaded: my_helper
INFO - 2020-12-25 16:54:07 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:54:07 --> Controller Class Initialized
ERROR - 2020-12-25 16:54:07 --> Severity: Parsing Error --> syntax error, unexpected '===' (T_IS_IDENTICAL) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 16:54:33 --> Config Class Initialized
INFO - 2020-12-25 16:54:33 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:54:34 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:54:34 --> Utf8 Class Initialized
INFO - 2020-12-25 16:54:34 --> URI Class Initialized
INFO - 2020-12-25 16:54:34 --> Router Class Initialized
INFO - 2020-12-25 16:54:34 --> Output Class Initialized
INFO - 2020-12-25 16:54:34 --> Security Class Initialized
DEBUG - 2020-12-25 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:54:34 --> Input Class Initialized
INFO - 2020-12-25 16:54:34 --> Language Class Initialized
INFO - 2020-12-25 16:54:34 --> Language Class Initialized
INFO - 2020-12-25 16:54:34 --> Config Class Initialized
INFO - 2020-12-25 16:54:34 --> Loader Class Initialized
INFO - 2020-12-25 16:54:34 --> Helper loaded: url_helper
INFO - 2020-12-25 16:54:34 --> Helper loaded: file_helper
INFO - 2020-12-25 16:54:34 --> Helper loaded: form_helper
INFO - 2020-12-25 16:54:34 --> Helper loaded: my_helper
INFO - 2020-12-25 16:54:34 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:54:34 --> Controller Class Initialized
ERROR - 2020-12-25 16:54:34 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 16:55:09 --> Config Class Initialized
INFO - 2020-12-25 16:55:09 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:55:09 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:55:09 --> Utf8 Class Initialized
INFO - 2020-12-25 16:55:10 --> URI Class Initialized
INFO - 2020-12-25 16:55:10 --> Router Class Initialized
INFO - 2020-12-25 16:55:10 --> Output Class Initialized
INFO - 2020-12-25 16:55:10 --> Security Class Initialized
DEBUG - 2020-12-25 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:55:10 --> Input Class Initialized
INFO - 2020-12-25 16:55:10 --> Language Class Initialized
INFO - 2020-12-25 16:55:10 --> Language Class Initialized
INFO - 2020-12-25 16:55:10 --> Config Class Initialized
INFO - 2020-12-25 16:55:10 --> Loader Class Initialized
INFO - 2020-12-25 16:55:10 --> Helper loaded: url_helper
INFO - 2020-12-25 16:55:10 --> Helper loaded: file_helper
INFO - 2020-12-25 16:55:10 --> Helper loaded: form_helper
INFO - 2020-12-25 16:55:10 --> Helper loaded: my_helper
INFO - 2020-12-25 16:55:10 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:55:10 --> Controller Class Initialized
ERROR - 2020-12-25 16:55:10 --> Severity: Parsing Error --> syntax error, unexpected '?' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 16:55:18 --> Config Class Initialized
INFO - 2020-12-25 16:55:18 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:55:18 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:55:18 --> Utf8 Class Initialized
INFO - 2020-12-25 16:55:18 --> URI Class Initialized
INFO - 2020-12-25 16:55:18 --> Router Class Initialized
INFO - 2020-12-25 16:55:18 --> Output Class Initialized
INFO - 2020-12-25 16:55:18 --> Security Class Initialized
DEBUG - 2020-12-25 16:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:55:18 --> Input Class Initialized
INFO - 2020-12-25 16:55:18 --> Language Class Initialized
INFO - 2020-12-25 16:55:18 --> Language Class Initialized
INFO - 2020-12-25 16:55:19 --> Config Class Initialized
INFO - 2020-12-25 16:55:19 --> Loader Class Initialized
INFO - 2020-12-25 16:55:19 --> Helper loaded: url_helper
INFO - 2020-12-25 16:55:19 --> Helper loaded: file_helper
INFO - 2020-12-25 16:55:19 --> Helper loaded: form_helper
INFO - 2020-12-25 16:55:19 --> Helper loaded: my_helper
INFO - 2020-12-25 16:55:19 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:55:19 --> Controller Class Initialized
ERROR - 2020-12-25 16:55:19 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-25 16:55:39 --> Config Class Initialized
INFO - 2020-12-25 16:55:39 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:55:39 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:55:39 --> Utf8 Class Initialized
INFO - 2020-12-25 16:55:39 --> URI Class Initialized
INFO - 2020-12-25 16:55:40 --> Router Class Initialized
INFO - 2020-12-25 16:55:40 --> Output Class Initialized
INFO - 2020-12-25 16:55:40 --> Security Class Initialized
DEBUG - 2020-12-25 16:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:55:40 --> Input Class Initialized
INFO - 2020-12-25 16:55:40 --> Language Class Initialized
INFO - 2020-12-25 16:55:40 --> Language Class Initialized
INFO - 2020-12-25 16:55:40 --> Config Class Initialized
INFO - 2020-12-25 16:55:40 --> Loader Class Initialized
INFO - 2020-12-25 16:55:40 --> Helper loaded: url_helper
INFO - 2020-12-25 16:55:40 --> Helper loaded: file_helper
INFO - 2020-12-25 16:55:40 --> Helper loaded: form_helper
INFO - 2020-12-25 16:55:40 --> Helper loaded: my_helper
INFO - 2020-12-25 16:55:40 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:55:40 --> Controller Class Initialized
ERROR - 2020-12-25 16:55:40 --> Severity: Parsing Error --> syntax error, unexpected ''Ananda memiliki integritas ya' (T_CONSTANT_ENCAPSED_STRING) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 66
INFO - 2020-12-25 16:56:41 --> Config Class Initialized
INFO - 2020-12-25 16:56:41 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:56:41 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:56:41 --> Utf8 Class Initialized
INFO - 2020-12-25 16:56:41 --> URI Class Initialized
INFO - 2020-12-25 16:56:41 --> Router Class Initialized
INFO - 2020-12-25 16:56:41 --> Output Class Initialized
INFO - 2020-12-25 16:56:41 --> Security Class Initialized
DEBUG - 2020-12-25 16:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:56:41 --> Input Class Initialized
INFO - 2020-12-25 16:56:41 --> Language Class Initialized
INFO - 2020-12-25 16:56:41 --> Language Class Initialized
INFO - 2020-12-25 16:56:41 --> Config Class Initialized
INFO - 2020-12-25 16:56:41 --> Loader Class Initialized
INFO - 2020-12-25 16:56:41 --> Helper loaded: url_helper
INFO - 2020-12-25 16:56:41 --> Helper loaded: file_helper
INFO - 2020-12-25 16:56:41 --> Helper loaded: form_helper
INFO - 2020-12-25 16:56:41 --> Helper loaded: my_helper
INFO - 2020-12-25 16:56:41 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:56:42 --> Controller Class Initialized
DEBUG - 2020-12-25 16:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:56:42 --> Final output sent to browser
DEBUG - 2020-12-25 16:56:42 --> Total execution time: 0.8179
INFO - 2020-12-25 16:57:18 --> Config Class Initialized
INFO - 2020-12-25 16:57:18 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:57:18 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:57:18 --> Utf8 Class Initialized
INFO - 2020-12-25 16:57:18 --> URI Class Initialized
INFO - 2020-12-25 16:57:18 --> Router Class Initialized
INFO - 2020-12-25 16:57:18 --> Output Class Initialized
INFO - 2020-12-25 16:57:18 --> Security Class Initialized
DEBUG - 2020-12-25 16:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:57:18 --> Input Class Initialized
INFO - 2020-12-25 16:57:18 --> Language Class Initialized
INFO - 2020-12-25 16:57:18 --> Language Class Initialized
INFO - 2020-12-25 16:57:18 --> Config Class Initialized
INFO - 2020-12-25 16:57:18 --> Loader Class Initialized
INFO - 2020-12-25 16:57:18 --> Helper loaded: url_helper
INFO - 2020-12-25 16:57:19 --> Helper loaded: file_helper
INFO - 2020-12-25 16:57:19 --> Helper loaded: form_helper
INFO - 2020-12-25 16:57:19 --> Helper loaded: my_helper
INFO - 2020-12-25 16:57:19 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:57:19 --> Controller Class Initialized
DEBUG - 2020-12-25 16:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:57:19 --> Final output sent to browser
DEBUG - 2020-12-25 16:57:19 --> Total execution time: 1.2147
INFO - 2020-12-25 16:57:32 --> Config Class Initialized
INFO - 2020-12-25 16:57:32 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:57:32 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:57:32 --> Utf8 Class Initialized
INFO - 2020-12-25 16:57:32 --> URI Class Initialized
INFO - 2020-12-25 16:57:32 --> Router Class Initialized
INFO - 2020-12-25 16:57:32 --> Output Class Initialized
INFO - 2020-12-25 16:57:32 --> Security Class Initialized
DEBUG - 2020-12-25 16:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:57:32 --> Input Class Initialized
INFO - 2020-12-25 16:57:33 --> Language Class Initialized
INFO - 2020-12-25 16:57:33 --> Language Class Initialized
INFO - 2020-12-25 16:57:33 --> Config Class Initialized
INFO - 2020-12-25 16:57:33 --> Loader Class Initialized
INFO - 2020-12-25 16:57:33 --> Helper loaded: url_helper
INFO - 2020-12-25 16:57:33 --> Helper loaded: file_helper
INFO - 2020-12-25 16:57:33 --> Helper loaded: form_helper
INFO - 2020-12-25 16:57:33 --> Helper loaded: my_helper
INFO - 2020-12-25 16:57:33 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:57:33 --> Controller Class Initialized
DEBUG - 2020-12-25 16:57:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:57:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:57:33 --> Final output sent to browser
DEBUG - 2020-12-25 16:57:33 --> Total execution time: 0.9708
INFO - 2020-12-25 16:57:53 --> Config Class Initialized
INFO - 2020-12-25 16:57:53 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:57:53 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:57:53 --> Utf8 Class Initialized
INFO - 2020-12-25 16:57:53 --> URI Class Initialized
INFO - 2020-12-25 16:57:53 --> Router Class Initialized
INFO - 2020-12-25 16:57:53 --> Output Class Initialized
INFO - 2020-12-25 16:57:54 --> Security Class Initialized
DEBUG - 2020-12-25 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:57:54 --> Input Class Initialized
INFO - 2020-12-25 16:57:54 --> Language Class Initialized
INFO - 2020-12-25 16:57:54 --> Language Class Initialized
INFO - 2020-12-25 16:57:54 --> Config Class Initialized
INFO - 2020-12-25 16:57:54 --> Loader Class Initialized
INFO - 2020-12-25 16:57:54 --> Helper loaded: url_helper
INFO - 2020-12-25 16:57:54 --> Helper loaded: file_helper
INFO - 2020-12-25 16:57:54 --> Helper loaded: form_helper
INFO - 2020-12-25 16:57:54 --> Helper loaded: my_helper
INFO - 2020-12-25 16:57:54 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:57:54 --> Controller Class Initialized
DEBUG - 2020-12-25 16:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:57:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:57:54 --> Final output sent to browser
DEBUG - 2020-12-25 16:57:54 --> Total execution time: 0.9688
INFO - 2020-12-25 16:58:08 --> Config Class Initialized
INFO - 2020-12-25 16:58:08 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:58:08 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:58:08 --> Utf8 Class Initialized
INFO - 2020-12-25 16:58:09 --> URI Class Initialized
INFO - 2020-12-25 16:58:09 --> Router Class Initialized
INFO - 2020-12-25 16:58:09 --> Output Class Initialized
INFO - 2020-12-25 16:58:09 --> Security Class Initialized
DEBUG - 2020-12-25 16:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:58:09 --> Input Class Initialized
INFO - 2020-12-25 16:58:09 --> Language Class Initialized
INFO - 2020-12-25 16:58:09 --> Language Class Initialized
INFO - 2020-12-25 16:58:09 --> Config Class Initialized
INFO - 2020-12-25 16:58:09 --> Loader Class Initialized
INFO - 2020-12-25 16:58:09 --> Helper loaded: url_helper
INFO - 2020-12-25 16:58:09 --> Helper loaded: file_helper
INFO - 2020-12-25 16:58:09 --> Helper loaded: form_helper
INFO - 2020-12-25 16:58:09 --> Helper loaded: my_helper
INFO - 2020-12-25 16:58:09 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:58:09 --> Controller Class Initialized
DEBUG - 2020-12-25 16:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:58:09 --> Final output sent to browser
DEBUG - 2020-12-25 16:58:09 --> Total execution time: 1.0481
INFO - 2020-12-25 16:58:30 --> Config Class Initialized
INFO - 2020-12-25 16:58:30 --> Hooks Class Initialized
DEBUG - 2020-12-25 16:58:30 --> UTF-8 Support Enabled
INFO - 2020-12-25 16:58:30 --> Utf8 Class Initialized
INFO - 2020-12-25 16:58:30 --> URI Class Initialized
INFO - 2020-12-25 16:58:30 --> Router Class Initialized
INFO - 2020-12-25 16:58:30 --> Output Class Initialized
INFO - 2020-12-25 16:58:30 --> Security Class Initialized
DEBUG - 2020-12-25 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 16:58:30 --> Input Class Initialized
INFO - 2020-12-25 16:58:30 --> Language Class Initialized
INFO - 2020-12-25 16:58:30 --> Language Class Initialized
INFO - 2020-12-25 16:58:30 --> Config Class Initialized
INFO - 2020-12-25 16:58:30 --> Loader Class Initialized
INFO - 2020-12-25 16:58:30 --> Helper loaded: url_helper
INFO - 2020-12-25 16:58:31 --> Helper loaded: file_helper
INFO - 2020-12-25 16:58:31 --> Helper loaded: form_helper
INFO - 2020-12-25 16:58:31 --> Helper loaded: my_helper
INFO - 2020-12-25 16:58:31 --> Database Driver Class Initialized
DEBUG - 2020-12-25 16:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 16:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 16:58:31 --> Controller Class Initialized
DEBUG - 2020-12-25 16:58:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 16:58:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 16:58:31 --> Final output sent to browser
DEBUG - 2020-12-25 16:58:31 --> Total execution time: 0.8260
INFO - 2020-12-25 17:00:15 --> Config Class Initialized
INFO - 2020-12-25 17:00:15 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:00:15 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:00:15 --> Utf8 Class Initialized
INFO - 2020-12-25 17:00:15 --> URI Class Initialized
INFO - 2020-12-25 17:00:15 --> Router Class Initialized
INFO - 2020-12-25 17:00:15 --> Output Class Initialized
INFO - 2020-12-25 17:00:15 --> Security Class Initialized
DEBUG - 2020-12-25 17:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:00:15 --> Input Class Initialized
INFO - 2020-12-25 17:00:15 --> Language Class Initialized
INFO - 2020-12-25 17:00:15 --> Language Class Initialized
INFO - 2020-12-25 17:00:15 --> Config Class Initialized
INFO - 2020-12-25 17:00:15 --> Loader Class Initialized
INFO - 2020-12-25 17:00:15 --> Helper loaded: url_helper
INFO - 2020-12-25 17:00:15 --> Helper loaded: file_helper
INFO - 2020-12-25 17:00:15 --> Helper loaded: form_helper
INFO - 2020-12-25 17:00:15 --> Helper loaded: my_helper
INFO - 2020-12-25 17:00:16 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:00:16 --> Controller Class Initialized
ERROR - 2020-12-25 17:00:16 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 71
INFO - 2020-12-25 17:00:33 --> Config Class Initialized
INFO - 2020-12-25 17:00:33 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:00:33 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:00:33 --> Utf8 Class Initialized
INFO - 2020-12-25 17:00:33 --> URI Class Initialized
INFO - 2020-12-25 17:00:33 --> Router Class Initialized
INFO - 2020-12-25 17:00:33 --> Output Class Initialized
INFO - 2020-12-25 17:00:33 --> Security Class Initialized
DEBUG - 2020-12-25 17:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:00:34 --> Input Class Initialized
INFO - 2020-12-25 17:00:34 --> Language Class Initialized
INFO - 2020-12-25 17:00:34 --> Language Class Initialized
INFO - 2020-12-25 17:00:34 --> Config Class Initialized
INFO - 2020-12-25 17:00:34 --> Loader Class Initialized
INFO - 2020-12-25 17:00:34 --> Helper loaded: url_helper
INFO - 2020-12-25 17:00:34 --> Helper loaded: file_helper
INFO - 2020-12-25 17:00:34 --> Helper loaded: form_helper
INFO - 2020-12-25 17:00:34 --> Helper loaded: my_helper
INFO - 2020-12-25 17:00:34 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:00:34 --> Controller Class Initialized
DEBUG - 2020-12-25 17:00:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:00:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:00:34 --> Final output sent to browser
DEBUG - 2020-12-25 17:00:34 --> Total execution time: 1.0701
INFO - 2020-12-25 17:03:39 --> Config Class Initialized
INFO - 2020-12-25 17:03:39 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:03:39 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:03:39 --> Utf8 Class Initialized
INFO - 2020-12-25 17:03:39 --> URI Class Initialized
INFO - 2020-12-25 17:03:39 --> Router Class Initialized
INFO - 2020-12-25 17:03:39 --> Output Class Initialized
INFO - 2020-12-25 17:03:39 --> Security Class Initialized
DEBUG - 2020-12-25 17:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:03:39 --> Input Class Initialized
INFO - 2020-12-25 17:03:40 --> Language Class Initialized
INFO - 2020-12-25 17:03:40 --> Language Class Initialized
INFO - 2020-12-25 17:03:40 --> Config Class Initialized
INFO - 2020-12-25 17:03:40 --> Loader Class Initialized
INFO - 2020-12-25 17:03:40 --> Helper loaded: url_helper
INFO - 2020-12-25 17:03:40 --> Helper loaded: file_helper
INFO - 2020-12-25 17:03:40 --> Helper loaded: form_helper
INFO - 2020-12-25 17:03:40 --> Helper loaded: my_helper
INFO - 2020-12-25 17:03:40 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:03:40 --> Controller Class Initialized
DEBUG - 2020-12-25 17:03:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:03:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:03:40 --> Final output sent to browser
DEBUG - 2020-12-25 17:03:40 --> Total execution time: 0.9428
INFO - 2020-12-25 17:04:13 --> Config Class Initialized
INFO - 2020-12-25 17:04:13 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:04:13 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:04:13 --> Utf8 Class Initialized
INFO - 2020-12-25 17:04:13 --> URI Class Initialized
INFO - 2020-12-25 17:04:13 --> Router Class Initialized
INFO - 2020-12-25 17:04:13 --> Output Class Initialized
INFO - 2020-12-25 17:04:13 --> Security Class Initialized
DEBUG - 2020-12-25 17:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:04:14 --> Input Class Initialized
INFO - 2020-12-25 17:04:14 --> Language Class Initialized
INFO - 2020-12-25 17:04:14 --> Language Class Initialized
INFO - 2020-12-25 17:04:14 --> Config Class Initialized
INFO - 2020-12-25 17:04:14 --> Loader Class Initialized
INFO - 2020-12-25 17:04:14 --> Helper loaded: url_helper
INFO - 2020-12-25 17:04:14 --> Helper loaded: file_helper
INFO - 2020-12-25 17:04:14 --> Helper loaded: form_helper
INFO - 2020-12-25 17:04:14 --> Helper loaded: my_helper
INFO - 2020-12-25 17:04:14 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:04:14 --> Controller Class Initialized
ERROR - 2020-12-25 17:04:14 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
INFO - 2020-12-25 17:04:30 --> Config Class Initialized
INFO - 2020-12-25 17:04:30 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:04:30 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:04:30 --> Utf8 Class Initialized
INFO - 2020-12-25 17:04:30 --> URI Class Initialized
INFO - 2020-12-25 17:04:30 --> Router Class Initialized
INFO - 2020-12-25 17:04:30 --> Output Class Initialized
INFO - 2020-12-25 17:04:30 --> Security Class Initialized
DEBUG - 2020-12-25 17:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:04:30 --> Input Class Initialized
INFO - 2020-12-25 17:04:30 --> Language Class Initialized
INFO - 2020-12-25 17:04:30 --> Language Class Initialized
INFO - 2020-12-25 17:04:30 --> Config Class Initialized
INFO - 2020-12-25 17:04:30 --> Loader Class Initialized
INFO - 2020-12-25 17:04:30 --> Helper loaded: url_helper
INFO - 2020-12-25 17:04:30 --> Helper loaded: file_helper
INFO - 2020-12-25 17:04:30 --> Helper loaded: form_helper
INFO - 2020-12-25 17:04:30 --> Helper loaded: my_helper
INFO - 2020-12-25 17:04:30 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:04:31 --> Controller Class Initialized
ERROR - 2020-12-25 17:04:31 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 67
INFO - 2020-12-25 17:05:12 --> Config Class Initialized
INFO - 2020-12-25 17:05:12 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:05:12 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:05:12 --> Utf8 Class Initialized
INFO - 2020-12-25 17:05:12 --> URI Class Initialized
INFO - 2020-12-25 17:05:12 --> Router Class Initialized
INFO - 2020-12-25 17:05:12 --> Output Class Initialized
INFO - 2020-12-25 17:05:12 --> Security Class Initialized
DEBUG - 2020-12-25 17:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:05:12 --> Input Class Initialized
INFO - 2020-12-25 17:05:12 --> Language Class Initialized
INFO - 2020-12-25 17:05:12 --> Language Class Initialized
INFO - 2020-12-25 17:05:13 --> Config Class Initialized
INFO - 2020-12-25 17:05:13 --> Loader Class Initialized
INFO - 2020-12-25 17:05:13 --> Helper loaded: url_helper
INFO - 2020-12-25 17:05:13 --> Helper loaded: file_helper
INFO - 2020-12-25 17:05:13 --> Helper loaded: form_helper
INFO - 2020-12-25 17:05:13 --> Helper loaded: my_helper
INFO - 2020-12-25 17:05:13 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:05:13 --> Controller Class Initialized
ERROR - 2020-12-25 17:05:13 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
INFO - 2020-12-25 17:05:41 --> Config Class Initialized
INFO - 2020-12-25 17:05:41 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:05:41 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:05:41 --> Utf8 Class Initialized
INFO - 2020-12-25 17:05:41 --> URI Class Initialized
INFO - 2020-12-25 17:05:41 --> Router Class Initialized
INFO - 2020-12-25 17:05:42 --> Output Class Initialized
INFO - 2020-12-25 17:05:42 --> Security Class Initialized
DEBUG - 2020-12-25 17:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:05:42 --> Input Class Initialized
INFO - 2020-12-25 17:05:42 --> Language Class Initialized
INFO - 2020-12-25 17:05:42 --> Language Class Initialized
INFO - 2020-12-25 17:05:42 --> Config Class Initialized
INFO - 2020-12-25 17:05:42 --> Loader Class Initialized
INFO - 2020-12-25 17:05:42 --> Helper loaded: url_helper
INFO - 2020-12-25 17:05:42 --> Helper loaded: file_helper
INFO - 2020-12-25 17:05:42 --> Helper loaded: form_helper
INFO - 2020-12-25 17:05:42 --> Helper loaded: my_helper
INFO - 2020-12-25 17:05:42 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:05:42 --> Controller Class Initialized
ERROR - 2020-12-25 17:05:42 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 109
INFO - 2020-12-25 17:06:06 --> Config Class Initialized
INFO - 2020-12-25 17:06:06 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:06:06 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:06:06 --> Utf8 Class Initialized
INFO - 2020-12-25 17:06:06 --> URI Class Initialized
INFO - 2020-12-25 17:06:06 --> Router Class Initialized
INFO - 2020-12-25 17:06:06 --> Output Class Initialized
INFO - 2020-12-25 17:06:06 --> Security Class Initialized
DEBUG - 2020-12-25 17:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:06:06 --> Input Class Initialized
INFO - 2020-12-25 17:06:06 --> Language Class Initialized
INFO - 2020-12-25 17:06:06 --> Language Class Initialized
INFO - 2020-12-25 17:06:06 --> Config Class Initialized
INFO - 2020-12-25 17:06:06 --> Loader Class Initialized
INFO - 2020-12-25 17:06:06 --> Helper loaded: url_helper
INFO - 2020-12-25 17:06:06 --> Helper loaded: file_helper
INFO - 2020-12-25 17:06:06 --> Helper loaded: form_helper
INFO - 2020-12-25 17:06:07 --> Helper loaded: my_helper
INFO - 2020-12-25 17:06:07 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:06:07 --> Controller Class Initialized
DEBUG - 2020-12-25 17:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:06:07 --> Final output sent to browser
DEBUG - 2020-12-25 17:06:07 --> Total execution time: 1.3027
INFO - 2020-12-25 17:06:46 --> Config Class Initialized
INFO - 2020-12-25 17:06:46 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:06:46 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:06:46 --> Utf8 Class Initialized
INFO - 2020-12-25 17:06:46 --> URI Class Initialized
INFO - 2020-12-25 17:06:46 --> Router Class Initialized
INFO - 2020-12-25 17:06:46 --> Output Class Initialized
INFO - 2020-12-25 17:06:46 --> Security Class Initialized
DEBUG - 2020-12-25 17:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:06:46 --> Input Class Initialized
INFO - 2020-12-25 17:06:46 --> Language Class Initialized
INFO - 2020-12-25 17:06:46 --> Language Class Initialized
INFO - 2020-12-25 17:06:46 --> Config Class Initialized
INFO - 2020-12-25 17:06:46 --> Loader Class Initialized
INFO - 2020-12-25 17:06:46 --> Helper loaded: url_helper
INFO - 2020-12-25 17:06:46 --> Helper loaded: file_helper
INFO - 2020-12-25 17:06:46 --> Helper loaded: form_helper
INFO - 2020-12-25 17:06:46 --> Helper loaded: my_helper
INFO - 2020-12-25 17:06:46 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:06:47 --> Controller Class Initialized
ERROR - 2020-12-25 17:06:47 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 71
INFO - 2020-12-25 17:07:07 --> Config Class Initialized
INFO - 2020-12-25 17:07:07 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:07:07 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:07:07 --> Utf8 Class Initialized
INFO - 2020-12-25 17:07:07 --> URI Class Initialized
INFO - 2020-12-25 17:07:07 --> Router Class Initialized
INFO - 2020-12-25 17:07:07 --> Output Class Initialized
INFO - 2020-12-25 17:07:07 --> Security Class Initialized
DEBUG - 2020-12-25 17:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:07:07 --> Input Class Initialized
INFO - 2020-12-25 17:07:07 --> Language Class Initialized
INFO - 2020-12-25 17:07:07 --> Language Class Initialized
INFO - 2020-12-25 17:07:07 --> Config Class Initialized
INFO - 2020-12-25 17:07:07 --> Loader Class Initialized
INFO - 2020-12-25 17:07:07 --> Helper loaded: url_helper
INFO - 2020-12-25 17:07:07 --> Helper loaded: file_helper
INFO - 2020-12-25 17:07:07 --> Helper loaded: form_helper
INFO - 2020-12-25 17:07:07 --> Helper loaded: my_helper
INFO - 2020-12-25 17:07:07 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:07:08 --> Controller Class Initialized
ERROR - 2020-12-25 17:07:08 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting ':' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 70
INFO - 2020-12-25 17:08:10 --> Config Class Initialized
INFO - 2020-12-25 17:08:10 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:08:10 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:08:10 --> Utf8 Class Initialized
INFO - 2020-12-25 17:08:10 --> URI Class Initialized
INFO - 2020-12-25 17:08:10 --> Router Class Initialized
INFO - 2020-12-25 17:08:10 --> Output Class Initialized
INFO - 2020-12-25 17:08:10 --> Security Class Initialized
DEBUG - 2020-12-25 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:08:10 --> Input Class Initialized
INFO - 2020-12-25 17:08:10 --> Language Class Initialized
INFO - 2020-12-25 17:08:10 --> Language Class Initialized
INFO - 2020-12-25 17:08:11 --> Config Class Initialized
INFO - 2020-12-25 17:08:11 --> Loader Class Initialized
INFO - 2020-12-25 17:08:11 --> Helper loaded: url_helper
INFO - 2020-12-25 17:08:11 --> Helper loaded: file_helper
INFO - 2020-12-25 17:08:11 --> Helper loaded: form_helper
INFO - 2020-12-25 17:08:11 --> Helper loaded: my_helper
INFO - 2020-12-25 17:08:11 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:08:11 --> Controller Class Initialized
ERROR - 2020-12-25 17:08:11 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ',' or ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 71
INFO - 2020-12-25 17:08:25 --> Config Class Initialized
INFO - 2020-12-25 17:08:25 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:08:25 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:08:25 --> Utf8 Class Initialized
INFO - 2020-12-25 17:08:25 --> URI Class Initialized
INFO - 2020-12-25 17:08:25 --> Router Class Initialized
INFO - 2020-12-25 17:08:25 --> Output Class Initialized
INFO - 2020-12-25 17:08:25 --> Security Class Initialized
DEBUG - 2020-12-25 17:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:08:25 --> Input Class Initialized
INFO - 2020-12-25 17:08:25 --> Language Class Initialized
INFO - 2020-12-25 17:08:25 --> Language Class Initialized
INFO - 2020-12-25 17:08:25 --> Config Class Initialized
INFO - 2020-12-25 17:08:25 --> Loader Class Initialized
INFO - 2020-12-25 17:08:25 --> Helper loaded: url_helper
INFO - 2020-12-25 17:08:25 --> Helper loaded: file_helper
INFO - 2020-12-25 17:08:25 --> Helper loaded: form_helper
INFO - 2020-12-25 17:08:25 --> Helper loaded: my_helper
INFO - 2020-12-25 17:08:26 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:08:26 --> Controller Class Initialized
DEBUG - 2020-12-25 17:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:08:26 --> Final output sent to browser
DEBUG - 2020-12-25 17:08:26 --> Total execution time: 1.2683
INFO - 2020-12-25 17:09:02 --> Config Class Initialized
INFO - 2020-12-25 17:09:02 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:09:02 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:09:02 --> Utf8 Class Initialized
INFO - 2020-12-25 17:09:02 --> URI Class Initialized
INFO - 2020-12-25 17:09:02 --> Router Class Initialized
INFO - 2020-12-25 17:09:02 --> Output Class Initialized
INFO - 2020-12-25 17:09:02 --> Security Class Initialized
DEBUG - 2020-12-25 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:09:02 --> Input Class Initialized
INFO - 2020-12-25 17:09:02 --> Language Class Initialized
INFO - 2020-12-25 17:09:02 --> Language Class Initialized
INFO - 2020-12-25 17:09:02 --> Config Class Initialized
INFO - 2020-12-25 17:09:02 --> Loader Class Initialized
INFO - 2020-12-25 17:09:02 --> Helper loaded: url_helper
INFO - 2020-12-25 17:09:02 --> Helper loaded: file_helper
INFO - 2020-12-25 17:09:02 --> Helper loaded: form_helper
INFO - 2020-12-25 17:09:02 --> Helper loaded: my_helper
INFO - 2020-12-25 17:09:03 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:09:03 --> Controller Class Initialized
DEBUG - 2020-12-25 17:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:09:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:09:03 --> Final output sent to browser
DEBUG - 2020-12-25 17:09:03 --> Total execution time: 1.3404
INFO - 2020-12-25 17:09:18 --> Config Class Initialized
INFO - 2020-12-25 17:09:18 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:09:18 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:09:18 --> Utf8 Class Initialized
INFO - 2020-12-25 17:09:18 --> URI Class Initialized
INFO - 2020-12-25 17:09:18 --> Router Class Initialized
INFO - 2020-12-25 17:09:18 --> Output Class Initialized
INFO - 2020-12-25 17:09:18 --> Security Class Initialized
DEBUG - 2020-12-25 17:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:09:18 --> Input Class Initialized
INFO - 2020-12-25 17:09:18 --> Language Class Initialized
INFO - 2020-12-25 17:09:18 --> Language Class Initialized
INFO - 2020-12-25 17:09:18 --> Config Class Initialized
INFO - 2020-12-25 17:09:18 --> Loader Class Initialized
INFO - 2020-12-25 17:09:18 --> Helper loaded: url_helper
INFO - 2020-12-25 17:09:19 --> Helper loaded: file_helper
INFO - 2020-12-25 17:09:19 --> Helper loaded: form_helper
INFO - 2020-12-25 17:09:19 --> Helper loaded: my_helper
INFO - 2020-12-25 17:09:19 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:09:19 --> Controller Class Initialized
DEBUG - 2020-12-25 17:09:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:09:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:09:19 --> Final output sent to browser
DEBUG - 2020-12-25 17:09:19 --> Total execution time: 1.2919
INFO - 2020-12-25 17:09:42 --> Config Class Initialized
INFO - 2020-12-25 17:09:42 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:09:42 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:09:42 --> Utf8 Class Initialized
INFO - 2020-12-25 17:09:42 --> URI Class Initialized
INFO - 2020-12-25 17:09:42 --> Router Class Initialized
INFO - 2020-12-25 17:09:42 --> Output Class Initialized
INFO - 2020-12-25 17:09:42 --> Security Class Initialized
DEBUG - 2020-12-25 17:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:09:42 --> Input Class Initialized
INFO - 2020-12-25 17:09:42 --> Language Class Initialized
INFO - 2020-12-25 17:09:42 --> Language Class Initialized
INFO - 2020-12-25 17:09:42 --> Config Class Initialized
INFO - 2020-12-25 17:09:42 --> Loader Class Initialized
INFO - 2020-12-25 17:09:42 --> Helper loaded: url_helper
INFO - 2020-12-25 17:09:42 --> Helper loaded: file_helper
INFO - 2020-12-25 17:09:42 --> Helper loaded: form_helper
INFO - 2020-12-25 17:09:42 --> Helper loaded: my_helper
INFO - 2020-12-25 17:09:42 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:09:43 --> Controller Class Initialized
DEBUG - 2020-12-25 17:09:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:09:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:09:43 --> Final output sent to browser
DEBUG - 2020-12-25 17:09:43 --> Total execution time: 0.9974
INFO - 2020-12-25 17:10:50 --> Config Class Initialized
INFO - 2020-12-25 17:10:50 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:10:50 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:10:50 --> Utf8 Class Initialized
INFO - 2020-12-25 17:10:50 --> URI Class Initialized
INFO - 2020-12-25 17:10:50 --> Router Class Initialized
INFO - 2020-12-25 17:10:50 --> Output Class Initialized
INFO - 2020-12-25 17:10:50 --> Security Class Initialized
DEBUG - 2020-12-25 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:10:50 --> Input Class Initialized
INFO - 2020-12-25 17:10:50 --> Language Class Initialized
INFO - 2020-12-25 17:10:50 --> Language Class Initialized
INFO - 2020-12-25 17:10:50 --> Config Class Initialized
INFO - 2020-12-25 17:10:50 --> Loader Class Initialized
INFO - 2020-12-25 17:10:50 --> Helper loaded: url_helper
INFO - 2020-12-25 17:10:51 --> Helper loaded: file_helper
INFO - 2020-12-25 17:10:51 --> Helper loaded: form_helper
INFO - 2020-12-25 17:10:51 --> Helper loaded: my_helper
INFO - 2020-12-25 17:10:51 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:10:51 --> Controller Class Initialized
DEBUG - 2020-12-25 17:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:10:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:10:51 --> Final output sent to browser
DEBUG - 2020-12-25 17:10:51 --> Total execution time: 1.1480
INFO - 2020-12-25 17:12:25 --> Config Class Initialized
INFO - 2020-12-25 17:12:25 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:12:25 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:12:25 --> Utf8 Class Initialized
INFO - 2020-12-25 17:12:25 --> URI Class Initialized
INFO - 2020-12-25 17:12:25 --> Router Class Initialized
INFO - 2020-12-25 17:12:25 --> Output Class Initialized
INFO - 2020-12-25 17:12:25 --> Security Class Initialized
DEBUG - 2020-12-25 17:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:12:25 --> Input Class Initialized
INFO - 2020-12-25 17:12:25 --> Language Class Initialized
INFO - 2020-12-25 17:12:25 --> Language Class Initialized
INFO - 2020-12-25 17:12:25 --> Config Class Initialized
INFO - 2020-12-25 17:12:25 --> Loader Class Initialized
INFO - 2020-12-25 17:12:25 --> Helper loaded: url_helper
INFO - 2020-12-25 17:12:25 --> Helper loaded: file_helper
INFO - 2020-12-25 17:12:25 --> Helper loaded: form_helper
INFO - 2020-12-25 17:12:25 --> Helper loaded: my_helper
INFO - 2020-12-25 17:12:26 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:12:26 --> Controller Class Initialized
DEBUG - 2020-12-25 17:12:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-25 17:12:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-25 17:12:26 --> Final output sent to browser
DEBUG - 2020-12-25 17:12:26 --> Total execution time: 1.0318
INFO - 2020-12-25 17:12:53 --> Config Class Initialized
INFO - 2020-12-25 17:12:53 --> Hooks Class Initialized
DEBUG - 2020-12-25 17:12:53 --> UTF-8 Support Enabled
INFO - 2020-12-25 17:12:53 --> Utf8 Class Initialized
INFO - 2020-12-25 17:12:53 --> URI Class Initialized
INFO - 2020-12-25 17:12:53 --> Router Class Initialized
INFO - 2020-12-25 17:12:53 --> Output Class Initialized
INFO - 2020-12-25 17:12:53 --> Security Class Initialized
DEBUG - 2020-12-25 17:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-25 17:12:53 --> Input Class Initialized
INFO - 2020-12-25 17:12:53 --> Language Class Initialized
INFO - 2020-12-25 17:12:53 --> Language Class Initialized
INFO - 2020-12-25 17:12:53 --> Config Class Initialized
INFO - 2020-12-25 17:12:53 --> Loader Class Initialized
INFO - 2020-12-25 17:12:53 --> Helper loaded: url_helper
INFO - 2020-12-25 17:12:53 --> Helper loaded: file_helper
INFO - 2020-12-25 17:12:53 --> Helper loaded: form_helper
INFO - 2020-12-25 17:12:53 --> Helper loaded: my_helper
INFO - 2020-12-25 17:12:53 --> Database Driver Class Initialized
DEBUG - 2020-12-25 17:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-25 17:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-25 17:12:53 --> Controller Class Initialized
ERROR - 2020-12-25 17:12:54 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 65
