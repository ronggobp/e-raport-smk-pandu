<!DOCTYPE html>
<html>
<head>
	<title>Cetak Raport</title>
	<style type="text/css">
		body {font-family: arial; font-size: 10.3pt; width: 8.5in}
		.table {border-collapse: collapse; border: solid 1px #999; width:100%}
		.table tr td, .table tr th {border:  solid 1px #000; padding: 6px;}
		.table tr th {font-weight: bold; text-align: center}
		.rgt {text-align: right;}
		.ctr {text-align: center;}
		.tbl {font-weight: bold}

		table tr td {vertical-align: top}
		.font_kecil {font-size: 12px}
	</style>
    <script type="text/javascript">
        function PrintWindow() {                    
           window.print();            
           CheckWindowState();
        }
    
        function CheckWindowState()    {           
            if(document.readyState=="complete") {
                window.close(); 
            } else {           
                setTimeout("CheckWindowState()", 1000)
            }
        }
        //PrintWindow();
    </script> 
</head>
<body>
	<table>
		<thead><!-- biar bisa ganti lembar otomatis --></thead>

		<tbody>
		
			<div align="center"><h3>PENCAPAIAN HASIL BELAJAR PESERTA DIDIK</h3></div>
		<strong>
		<tr>
			<table width="100%">
					<td width="17%"><strong>Nama Sekolah</strong></td>
					<td width="1%"><strong>:</strong></td><td width="33%"><strong><?php echo $this->config->item('nama_sekolah'); ?></strong></td>
					<td width="19%"><strong>Kelas / Semester </strong></td>
					<td width="1%"><strong>:</strong></td>
					<td width="29%"><strong><?php echo strtoupper($wali_kelas['nmkelas']); ?> / <?php echo $semester; ?></strong></td>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<td width="17%">Alamat</td>
					<td width="1%">:</td><td width="33%"><?php echo $this->config->item('alamat_sekolah'); ?></td>
					<td width="19%">Tahun Pelajaran</td>
					<td width="1%">:</td><td width="29%"><?php echo $ta; ?></td>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<td width="17%">Nama Peserta Didik</td>
					<td width="1%">:</td><td width="33%"><?php echo $det_siswa['nama']; ?></td>
					<td width="19%">Program Keahlian </td>
					<td width="1%">:</td><td width="29%"><?php echo $det_siswa['prog_keahlian']; ?></td>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<td width="17%">NIS / NISN</td>
					<td width="1%">:</td><td width="33%"><?php echo $det_siswa['nis']; ?> / <?php echo $det_siswa['nisn']; ?></td>
					<td width="19%">Kompetensi Keahlian </td>
					<td width="1%">:</td><td width="29%"><?php echo $det_siswa['komp_keahlian']; ?></td>
				</table>
			</td>
		</tr></strong>
		<tr><td colspan="6"><br></td></tr>
		<tr>
		  <td colspan="6"><b>A. Nilai Akademik </b></td>
		</tr>
		
		<tr><td colspan="6">
			<table class="table">
				<thead>
				<tr>
					<th colspan="1" rowspan="2" width="2%">No</th>
					<th colspan="1" rowspan="2" width="46%">Mata Pelajaran</th>
					<th colspan="1" rowspan="2" width="13%">Pengetahuan</th>
					<th colspan="1" rowspan="2" width="13%">Keterampilan</th>
					<th colspan="3">Nilai Akhir</th>
				</tr>
				<tr>
					<th width="13%">Angka</th>
					<th width="13%">Predikat</th>
				</tr>
				
				</thead>
				<tbody>
				<?php echo $nilai_utama; ?>
				</tbody>
			</table> <br>
			<tr><td colspan="6"><b>B. Catatan Akademik</b></td></tr>
		<tr><td colspan="6">
			<table width="100%">
				<tr>
					<td width="40%">
						<table class="table" width="100%">
							<tr><td width="100%"><?php echo $catatan['catatan_akademik']; ?></td></tr>
						</table>
					</td>
				</tr>
			</table>
		</td></tr>
		<tr><td colspan="6"><br></td></tr>
		<tr><td colspan="6"><b>C. Praktik Kerja Lapangan </b></td></tr>
		<tr><td colspan="6">
			<table class="table">
				<thead>
					<tr>
						<th width="5%">No</th>
						<th width="30%">Mitra DU/DI</th>
						<th width="25%">Lokasi</th>
						<th width="10%">Lamanya(bulan)</th>
						<th width="10%">Keterangan</th>
					</tr>
				</thead>
				<tbody>
						<tr>
							<?php $no = 1; ?>
							<td class="ctr"><?php echo $no; ?></td>
							<td><div align="center"><?php echo $pkl['mitra']; ?></div></td>
							<td><div align="center"><?php echo $pkl['lokasi']; ?></div></td>
							<td><div align="center"><?php echo $pkl['lama']; ?></div></td>
							<td><div align="center"><?php echo $pkl['keterangan']; ?></div></td>
						</tr>
				</tbody>
			</table><br>
		</td></tr>
		<tr><td colspan="6"><b>D. Ekstrakurikuler</b></td></tr>
		<tr><td colspan="6">
			<table class="table">
				<thead>
					<tr>
						<th width="5%">No</th>
						<th width="40%">Kegiatan Ekstrakurikuler</th>
						<th width="55%">Keterangan</th>
					</tr>
				</thead>
				<tbody>
					<?php 
					if (!empty($nilai_ekstra)) {
						$no = 1;
						foreach ($nilai_ekstra as $ne) {
							$desk = "";
							if ($ne['nilai'] == "A") {
								$desk = "Melaksanakan kegiatan ".$ne['nama']." dengan sangat Baik";
							} else if ($ne['nilai'] == "B") {
								$desk = "Melaksanakan kegiatan ".$ne['nama']." dengan Baik";
							} else if ($ne['nilai'] == "C") {
								$desk = "Melaksanakan kegiatan ".$ne['nama']." dengan cukup Baik";
							} else {
								$desk = "-";
							}
					?>
						<tr>
							<td class="ctr"><?php echo $no; ?></td>
							<td><div align="center"><?php echo $ne['nama']; ?></div></td>
							<td><div align="center"><?php echo $desk; ?></div></td>
						</tr>
					<?php 
							$no++;
						}
					} else {
						echo '<tr><td colspan="4">-</td></tr>';
					}
					?>
				</tbody>
			</table><br>
		</td></tr>
		<tr><td colspan="6"><b>E. Ketidakhadiran</b></td></tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<tr>
						<td width="80%">
							<table class="table" width="100%">
								<tr><td width="60%">Sakit</td><td width="40%" class="ctr"><?php echo $nilai_absensi['s']; ?> &nbsp; hari</td></tr>
								<tr><td>Izin</td><td class="ctr"><?php echo $nilai_absensi['i']; ?> &nbsp; hari</td></tr>
								<tr><td>Tanpa Keterangan</td><td class="ctr"><?php echo $nilai_absensi['a']; ?> &nbsp; hari</td></tr>
							</table>
						</td>
						<td width="60%">
						</td>
					</tr>
				</table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			</td>
		</tr>
		<center>Page 1 of 2</center>
		<tr>
		<strong>
		<tr>
			<table width="100%">
					<td width="17%"><strong>Nama Sekolah</strong></td>
					<td width="1%"><strong>:</strong></td><td width="33%"><strong><?php echo $this->config->item('nama_sekolah'); ?></strong></td>
					<td width="19%"><strong>Kelas / Semester </strong></td>
					<td width="1%"><strong>:</strong></td>
					<td width="29%"><strong><?php echo strtoupper($wali_kelas['nmkelas']); ?> / <?php echo $semester; ?></strong></td>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<td width="17%">Alamat</td>
					<td width="1%">:</td><td width="33%"><?php echo $this->config->item('alamat_sekolah'); ?></td>
					<td width="19%">Tahun Pelajaran</td>
					<td width="1%">:</td><td width="29%"><?php echo $ta; ?></td>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<td width="17%">Nama Peserta Didik</td>
					<td width="1%">:</td><td width="33%"><?php echo $det_siswa['nama']; ?></td>
					<td width="19%">Program Keahlian </td>
					<td width="1%">:</td><td width="29%"><?php echo $det_siswa['prog_keahlian']; ?></td>
				</table>
			</td>
		</tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<td width="17%">NIS / NISN</td>
					<td width="1%">:</td><td width="33%"><?php echo $det_siswa['nis']; ?> / <?php echo $det_siswa['nisn']; ?></td>
					<td width="19%">Kompetensi Keahlian </td>
					<td width="1%">:</td><td width="29%"><?php echo $det_siswa['komp_keahlian']; ?></td>
				</table><br>
			</td>
		</tr></strong>
		<tr><td colspan="6"><b>F. Deskripsi Perkembangan Karakter</b></td></tr>
		<tr>
			<td colspan="6">
				<table width="100%">
					<tr>
						<td width="100%">
							<table class="table">
								<thead>
									<tr>
										<th width="15%">Karakter yang dibangun</th>
										<th width="85%">Deskripsi</th>
									</tr>
								</thead>

								<tr><td><div style="margin-top: 5px; margin-bottom: 5px">Integritas</div></td><td><div style="margin-top: 5px; margin-bottom: 5px"><?php echo $karakter['integritas']; ?></div></td>
								</tr>
								<tr><td><div style="margin-top: 5px; margin-bottom: 5px">Religius</div></td><td><div style="margin-top: 5px; margin-bottom: 5px"><?php echo $karakter['religius']; ?></div></td>
								</tr>
								<tr><td><div style="margin-top: 5px; margin-bottom: 5px">Nasionalis</div></td><td><div style="margin-top: 5px; margin-bottom: 5px"><?php echo $karakter['nasionalis']; ?></div></td>
								</tr>
								<tr><td><div style="margin-top: 5px; margin-bottom: 5px">Mandiri</div></td><td><div style="margin-top: 5px; margin-bottom: 5px"><?php echo $karakter['mandiri']; ?></div></td>
								</tr>
								<tr><td><div style="margin-top: 5px; margin-bottom: 5px">Gotong-royong</div></td><td><div style="margin-top: 5px; margin-bottom: 5px"><?php echo $karakter['gotong']; ?></div></td>
								</tr>
							</table>
						</td>
						<td width="60%">
						</td>
					</tr>
				</table><br>
			</td>
		</tr>
		<tr><td colspan="6"><b>G. Catatan Perkembangan Karakter </b></td></tr>
		<tr><td colspan="6">
			<table width="100%">
				<tr>
					<td width="40%">
						<table class="table" width="100%">
							<tr><td width="100%"><?php echo $karakter['catatan']; ?></td></tr>
						</table>
					</td>
				</tr>
			</table>
		<br></td></tr>
		
		<?php 
		if ($semester == 2) {
		?>
		<tr>
		    <td colspan="6">
		        <?php 
		        $naik_kelas = $det_siswa['tingkat']+1;
		        $kelas_now = $det_siswa['tingkat'];
		        
			    if ($kelas_now != 12) {
		        ?>
		        
		        <div style="border: solid 1px; padding: 10px">
            		<b>Keputusan : </b>
            	    <p>Berdasarkan hasil yang dicapai pada semester 1 dan 2, peserta didik ditetapkan *) :<br>
            	    <div style="display: block">
                	    <div style="diplay: inline; float: left; width: 200px">naik ke kelas </div>
                	    <div style="diplay: inline; float: left; font-weight: bold"><?php echo $naik_kelas." (".terbilang($naik_kelas).")"; ?></div>
            	    </div><br>
            	    <div style="display: block">
                	    <div style="diplay: inline; float: left; width: 200px">tinggal di kelas</div>
                	    <div style="diplay: inline; float: left; font-weight: bold"><?php echo $kelas_now." (".terbilang($kelas_now).")"; ?></div>
                    </div> 
                    <br><br>
            	    *) Coret yang tidak perlu
        	    </div>
        	    
        	    <?php } else { ?>
        	    <div style="border: solid 1px; padding: 10px; margin-top: 10px">
            		<b>Keputusan : </b>
            	    <p>Berdasarkan pencapaian kompetensi pada kelas 10, 11 dan 12, maka, peserta didik dinyatakan : *) :<br>
            	    <div style="display: block; font-weight: bold">
                	    LULUS / TIDAK LULUS
            	    </div><br>
            	    *) Coret yang tidak perlu
        	    </div>
        	    <?php } ?>
		    <br></td>
		</tr>
		<?php } ?>				 			 
		<td colspan="6">
			<table width="100%">
			<td width="17%">Diberikan di </td>
			<td width="1%">:</td><td><?php echo $this->config->item('kota_sekolah'); ?></td>
			</table>
		</td>
		</tr>
		<tr>
		<td colspan="6">
			<table width="100%">
			<td width="17%">Tanggal </td>
			<td width="1%">:</td><td><?php 
						    if ($wali_kelas['tingkat'] != 12) {
						    ?>
							<?php echo tjs($det_raport['tgl_raport'],"l"); ?><br>
							<?php } else { ?>
							<?php echo tjs($det_raport['tgl_raport_kelas3'],"l"); ?><br>
							<?php } ?></td>
			</table>
		</td>
		</tr>
		<tr>
			<td colspan="6">
				<br><br>
				<table width="100%">
					<tr>
						<td width="50%">
							<div align="left">Mengetahui : <br>
							Orang Tua/Wali, <br>
							<br>
							<br>
							<br>
							<br>
							<br>
							<br>
							<br>
						_______________________						    </div>
						</td>
							<td width="23%"></td>
						<td width="50%">
							<br>
							Wali Kelas, <br>
							<br><br><br><br><br><br><br>
							<b><?php echo $wali_kelas['nmguru']; ?></b><br>						
						</td>
					</tr>
				</table>

			</td>
		</tr>
		<tr>
			<td colspan="6">
				<br><br>
				<table width="100%">
					<tr>
						<td width="19%"></td>
						<td width="29%">
							Mengetahui: <br>
							Kepala <?php echo $this->config->item('nama_sekolah'); ?>, <br>
							<br><br><br><br><br><br><br>
							<b><?php echo $det_raport['nama_kepsek']; ?></b><br>						
						</td>
					</tr>
				</table><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
			</td>
		</tr>
		<center>Page 2 of 2</center>
		</tbody>
	</table>
</body>
</html>