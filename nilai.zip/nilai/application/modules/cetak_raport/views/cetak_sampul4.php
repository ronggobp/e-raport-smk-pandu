<!DOCTYPE html>
<html>
<head>
	<title>Cetak Raport</title>
	<style type="text/css">
		body {font-family: arial; font-size: 11pt}
		.table {border-collapse: collapse; border: solid 1px #999; width:100%}
		.table tr td, .table tr th {border:  solid 1px #999; padding: 3px; font-size: 12px}
		.rgt {text-align: right;}
		.ctr {text-align: center;}
		.footer { position: fixed; left: 0; bottom: 0; width: 100%; text-align: center;}
	</style>
</head>
<body>
	<center>
		<span style="font-size: 14pt"><b style="font-size: 14pt">IDENTITAS PESERTA DIDIK</b></span><br><br>
		<tr><td colspan="2">
			<table style="margin-left:1%; width: 90%">
				<tr><td width="3%">1.</td><td width="45%">Nama Peserta Didik (Lengkap)</td><td width="2%">:</td><td width="50%"><?php echo $ds['nama']; ?></td></tr>
				<tr><td>2.</td><td>Nomor Induk</td><td>:</td><td><?php echo $ds['nis']; ?></td></tr>
				<tr><td>3.</td><td>Tempat dan Tanggal Lahir</td><td>:</td><td><?php echo $ds['tmp_lahir'].", ".tjs($ds['tgl_lahir'],"l"); ?></td></tr>
				<tr><td>4.</td><td>Jenis Kelamin</td><td>:</td><td><?php echo jk($ds['jk']); ?></td></tr>
				<tr><td>5.</td><td>Agama</td><td>:</td><td><?php echo $ds['agama']; ?></td></tr>
				<tr><td>6.</td><td>Anak Ke</td><td>:</td><td><?php echo $ds['anakke']; ?></td></tr>
				<tr><td>7.</td><td>Status dalam Keluarga</td><td>:</td><td><?php echo status_anak($ds['status']); ?></td></tr>
				<tr><td>8.</td><td>Alamat Peserta Didik</td><td>:</td><td><?php echo $ds['alamat']; ?></td></tr>
				<tr><td></td><td>Nomor telepon Rumah/HP</td><td>:</td><td><?php echo $ds['notelp']; ?></td></tr>
				<tr><td></td><td>Alamat email</td><td>:</td><td><?php echo $ds['email']; ?></td></tr>
				<tr><td>9.</td><td>Diterima di Sekolah ini</td><td></td><td></td></tr>
				<tr><td></td><td>a. Di Kelas</td><td>:</td><td><?php echo $ds['diterima_kelas']; ?></td></tr>
				<tr><td></td><td>b. Pada Tanggal</td><td>:</td><td><?php echo tjs($ds['diterima_tgl'],"l"); ?></td></tr>
				<tr><td></td><td>c. Semester</td><td>:</td><td><?php echo $ds['diterima_smt']; ?></td></tr>
				<tr><td>10.</td><td>Sekolah Asal</td><td:</td><td></td></tr>
				<tr><td></td><td>a. Nama Sekolah</td><td>:</td><td><?php echo $ds['sek_asal']; ?></td></tr>
				<tr><td></td><td>b. Alamat</td><td>:</td><td><?php echo $ds['sek_asal_alamat']; ?></td></tr>
				<tr><td>11.</td><td>Ijazah SMP/MTs/Paket B</td><td></td><td></td></tr>
				<tr><td></td><td>a. Tahun</td><td>:</td><td><?php echo $ds['ijazah_thn']; ?></td></tr>
				<tr><td></td><td>b. Nomor</td><td>:</td><td><?php echo $ds['ijazah_no']; ?></td></tr>
				<tr><td>12.</td><td colspan="3">Surat Keterangan Hasil Ujian Nasional (SKHUN) SMP/MTs/Paket B</td></tr>
				<tr><td></td><td>a. Tahun</td><td>:</td><td><?php echo $ds['skhun_thn']; ?></td></tr>
				<tr><td></td><td>b. Nomor</td><td>:</td><td><?php echo $ds['skhun_no']; ?></td></tr>
				<tr><td>13.</td><td>Orang Tua</td><td></td><td></td></tr>
				<tr><td></td><td>a. Ayah</td><td>:</td><td><?php echo $ds['ortu_ayah']; ?></td></tr>
				<tr><td></td><td>b. Ibu</td><td>:</td><td><?php echo $ds['ortu_ibu']; ?></td></tr>
				<tr><td>14.</td><td>Alamat Orang Tua</td><td>:</td><td><?php echo $ds['ortu_alamat']; ?></td></tr>
				<tr><td></td><td>Nomor telepon Rumah/HP</td><td>:</td><td><?php echo $ds['ortu_notelp']; ?></td></tr>
				<tr><td></td><td>Alamat email</td><td>:</td><td><?php echo $ds['ortu_email']; ?></td></tr>
				<tr><td>15.</td><td>Pekerjaan Orang Tua</td><td></td><td></td></tr>
				<tr><td></td><td>a. Ayah</td><td>:</td><td><?php echo $ds['ortu_ayah_pkj']; ?></td></tr>
				<tr><td></td><td>b. Ibu</td><td>:</td><td><?php echo $ds['ortu_ibu_pkj']; ?></td></tr>
				<tr><td>16.</td><td>Nama Wali</td><td>:</td><td><?php echo $ds['wali']; ?></td></tr>
				<tr><td>17.</td><td>Alamat Wali</td><td>:</td><td><?php echo $ds['wali_alamat']; ?></td></tr>
				<tr><td></td><td>Nomor telepon</td><td>:</td><td><?php echo $ds['notelp_rumah']; ?></td></tr>
				<tr><td></td><td>Alamat email</td><td>:</td><td><?php echo $ds['wali_email']; ?></td></tr>
				<tr><td>18.</td><td>Pekerjaan Wali</td><td>:</td><td><?php echo $ds['wali_pkj']; ?></td></tr>
			</table>
		</td>
		</tr>		
	</table>
	<br><br>
	<div style="margin-left: 25%; display: inline; float: left; width: 3cm; height: 3.7cm; border: solid 1px #000">
	<td></td><br>
	<td></td><br>
	<td>Pas Foto</td><br>
	<td>3 x 4</td><br>
	<td>Hitam Putih/</td><br>
	<td>Berwarna</td></div>
	</center>
	<div style="margin-left: 90px; display: inline; float: left;">
		Bogor, <?php echo tjs($ds['diterima_tgl'],"l"); ?><br>
		Kepala Sekolah SMK<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<?php echo $det_raport['nama_kepsek']; ?><br>
		NIP. -
	</div>
</body>
<div class="footer">
  <p>Page 2 of 2</p>
</div>
</html>