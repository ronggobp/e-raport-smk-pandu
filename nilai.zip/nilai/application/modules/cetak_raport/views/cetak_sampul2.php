<!DOCTYPE html>
<html>
<head>
	<title>Cetak Raport</title>
	<style type="text/css">
		body {font-family: arial; font-size: 10.5pt}
		.table {border-collapse: collapse; border: solid 1px #999; width:100%}
		.table tr td, .table tr th {border:  solid 1px #999; padding: 2.5px; font-size: 12px}
		.rgt {text-align: right;}
		.ctr {text-align: center;}
		.footer { position: fixed; left: 0; bottom: 0; width: 100%; text-align: center;}
	</style>
</head>
<body>
	<div align="justify"><b>Skor Ketuntasan Minimal (SKM)</b><br><br>
		Skor Ketuntasan Minimal (SKM) yang secara pengukuran disebut dengan <i>cut off score</i> merupakan bagian dari 
		<i>standard setting</i> yang secara operasional ditetapkan dalam <b>bentuk angka</b>. SKM digunakan sebagai acuan 
		penentuan Peserta Didik yang wajib mengikuti pembelajaran remedial hingga memenuhi Kriteria Pencapaian 
		Kompetensi (KPK) dan sebagai salah satu acuan Kriteria Kenaikan Kelas. Nilai Ketuntasan belajar kompetensi 
		pada mata pelajaran wajib A, B, dan C1 adalah minimal <b>60</b>, sedangkan untuk mata pelajaran C2 dan C3 nilai 
		ketuntasan belajar adalah minimal 65 dengan menyesuaikan karakteristik kompetensi/paket keahlian
    </div><br>
		<center>
			<b>Tabel Predikat Kategori</b><br><br>
		</center>
			<table class="table">
				<thead>
				<tr>
					<th colspan="1" rowspan="2" width="10%">Kategori</th>
					<th colspan="1" rowspan="2" width="38%">Rentang</th>
					<th colspan="1" rowspan="2" width="37%">Keterangan</th>
					<th colspan="1" rowspan="2" width="15%">Keterangan Penguasaan Kompetensi</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<th colspan="1">A+</th>
					<th colspan="1"><div align="left">N &ge; 95*</div></th>
					<th colspan="1" rowspan="3" width="37%"><div align="justify">Peserta didik secara konsisten menunjukkan pemahaman yang mendalam pada semua materi</div></th>
					<th colspan="1" rowspan="3" width="15%"><div align="left">Sangat kompeten</div></th>
				</tr>
				<tr>
					<th colspan="1">A</th>
					<th colspan="1"><div align="left">95 &ge; N &ge; 90*</div></th>
				</tr>
				<tr>
					<th colspan="1">A-</th>
					<th colspan="1"><div align="left">90 &ge; N &ge; 85*</div></th>
				</tr>
				</tbody>
				<tbody>
				<tr>
					<th colspan="1">B+</th>
					<th colspan="1"><div align="left">85 &ge; N &ge; 80*</div></th>
					<th colspan="1" rowspan="3" width="37%"><div align="justify">Peserta didik secara konsisten menunjukkan pemahaman yang mendalam pada sebagian besar materi</div></th>
					<th colspan="1" rowspan="3" width="15%"><div align="left">Kompeten</div></th>
				</tr>
				<tr>
					<th colspan="1">B</th>
					<th colspan="1"><div align="left">85 &ge; N &ge; 75*</div></th>
				</tr>
				<tr>
					<th colspan="1">B-</th>
					<th colspan="1"><div align="left">75 &ge; N &ge; 70*</div></th>
				</tr>
				</tbody>
				<tbody>
				<tr>
					<th>C</th>
					<th><div align="left">&bull; Mata pelajaran muatan Adaptif dan Normatif (A, B, C1) 70 > N &ge; 60<br>
					&bull; Mata pelajaran muatan Produktif <br>(C1, C2, C3) 70 > N &ge; 65</div></th>
					<th><div align="justify">Peserta didik menunjukkan pemahaman yang cukup pada semua materi</div></th>
					<th><div align="left">Cukup Kompeten</div></th>
				</tr>
				</tbody>
				<tbody>
				<tr>
					<th>D</th>
					<th><div align="left">&bull; Mata pelajaran muatan Adaptif dan Normatif (A, B, C1) N < 60<br>
					&bull; Mata pelajaran muatan Produktif <br>(C1, C2, C3) N < 65</div></th>
					<th><div align="justify">Peserta didik belum menunjukkan pemahaman yang cukup pada sebagian besar materi</div></th>
					<th><div align="left">Belum Kompeten</div></th>
				</tr>
				</tbody>
			</table>
			*untuk seluruh mata pelajaran<br><br>
			
			<table class="table">
				<thead>
				<tr>
					<th colspan="1" rowspan="2" width="33%">Predikat/Kategori</th>
					<th colspan="1" rowspan="2" width="33%">Mapel Adaptif dan Normatif</th>
					<th colspan="1" rowspan="2" width="33%">Mapel Produktif</th>
				</tr>
				</thead>
				<tbody>
				<tr>
					<th>A+</th>
					<th>&ge; 95</th>
					<th>&ge; 95</th>
				</tr>
				<tr>
					<th>A</th>
					<th>90 - 94</th>
					<th>90 - 94</th>
				</tr>
				<tr>
					<th>A-</th>
					<th>85 - 89</th>
					<th>85 - 89</th>
				</tr>
				<tr>
					<th>B+</th>
					<th>80 - 84</th>
					<th>80 - 84</th>
				</tr>
				<tr>
					<th>B</th>
					<th>75 - 79</th>
					<th>75 - 79</th>
				</tr>
				<tr>
					<th>B-</th>
					<th>70 - 74</th>
					<th>70 - 74</th>
				</tr>
				<tr>
					<th>C</th>
					<th>60 - 69</th>
					<th>65 - 69</th>
				</tr>
				<tr>
					<th>D</th>
					<th>&lt;60</th>
					<th>&lt;65</th>
				</tr>
				</tbody>
			</table><br>
			
		<b>Pembobotan Nilai Akhir Raport</b>
			<table class="table">
				<thead>
				<tr>
					<th colspan="1" rowspan="2" width="10%">Nomor</th>
					<th colspan="1" rowspan="2" width="50%">Mapel/Kelompok Mapel</th>
					<th colspan="1" rowspan="2" width="20%">Bobot Nilai Pengetahuan (%)</th>
					<th colspan="1" rowspan="2" width="20%">Bobot Nilai Keterampilan (%)</th>
				</tr>
				</thead>
				<tbody>
				<tr><div align="left">
					<th>1.</th>
					<th><div align="left">Pendidikan Akhlak dan Budi Pekerti (PAI)</div></th>
					<th>30</th>
					<th>70</th></div>
				</tr>
				<tr>
					<th>2.</th>
					<th><div align="left">PPKn</div></th>
					<th>70</th>
					<th>30</th>
				</tr>
				<tr>
					<th>3.</th>
					<th><div align="left">Matematika</div></th>
					<th>50</th>
					<th>50</th>
				</tr>
				<tr>
					<th>4.</th>
					<th><div align="left">Bahasa Indonesia</div></th>
					<th>50</th>
					<th>50</th>
				</tr>
				<tr>
					<th>5.</th>
					<th><div align="left">Sejarah Indonesia</div></th>
					<th>70</th>
					<th>30</th>
				</tr>
				<tr>
					<th>6.</th>
					<th><div align="left">Bahasa Inggris</div></th>
					<th>50</th>
					<th>50</th>
				</tr>
				<tr>
					<th>7.</th>
					<th><div align="left">Seni Budaya dan Keterampilan</div></th>
					<th>30</th>
					<th>70</th>
				</tr>
				<tr>
					<th>8.</th>
					<th><div align="left">Pendidikan Jasmani, Olahraga dan Kesehatan</div></th>
					<th>30</th>
					<th>70</th>
				</tr>
				<tr>
					<th>9.</th>
					<th><div align="left">Simulasi dan Komunikasi Digital</div></th>
					<th>30</th>
					<th>70</th>
				</tr>
				<tr>
					<th>10.</th>
					<th><div align="left">Fisika</div></th>
					<th>70</th>
					<th>30</th>
				</tr>
				<tr>
					<th>11.</th>
					<th><div align="left">Kimia</div></th>
					<th>70</th>
					<th>30</th>
				</tr>
				<tr>
					<th>12.</th>
					<th><div align="left">Kelompok Mata pelajaran Dasar Program Keahlian</div></th>
					<th>30</th>
					<th>70</th>
				</tr>
				<tr>
					<th>13.</th>
					<th><div align="left">Kelompok Mata pelajaran Dasar Kompetensi Keahlian</div></th>
					<th>30</th>
					<th>70</th>
				</tr>
				</tbody>
			</table>
</body>
<div class="footer">
  <p>Page 1 of 2</p>
</div>
</html>