<!DOCTYPE html>
<html>
<head>
	<title>Cetak Raport</title>
	<style type="text/css">
		body {font-family: arial; font-size: 15pt}
		.table {border-collapse: collapse; border: solid 1px #999; width:100%}
		.table tr td, .table tr th {border:  solid 1px #999; padding: 2px; font-size: 12px}
		.rgt {text-align: right;}
		.ctr {text-align: center;}
	</style>
</head>
<body>
	<center>
		<img src="<?php echo base_url(); ?>aset/img/logo_garuda.jpg"><br><br>
		<span style="font-size: 14pt"><b style="font-size: 18pt">LAPORAN</b><br>
		<b style="font-size: 18pt">PENCAPAIAN KOMPETENSI PESERTA DIDIK</b><br><br>
		<b style="font-size: 18pt">SEKOLAH MENENGAH KEJURUAN</b><br>
		<b style="font-size: 18pt">(SMK)</b><br>
		</span>
		<br>
		<br>
		<br>
		<br>
		<br>
		<table style="margin-left:10%; width: 83%">
			<tr>
				<td width="20%">Nama Sekolah</td>
				<td width="2%">:</td>
				<td width="50%"><u>SMK Pandu Bogor</u></td>
			</tr>
			<tr>
				<td>NIS/NSS/NDS</td>
				<td>:</td>
				<td><u>320040 / 402020216075 / 4202050012</u></td>
			</tr>
			<tr>
				<td>Alamat Sekolah</td>
				<td>:</td>
				<td><u>Komplek SMK PANDU, </u></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><u>Jl. Raya Cibungbulang Km. 15</u></td>
			</tr><tr>
				<td></td>
				<td></td>
				<td><u>Kode Pos 16630 Telp (0251) 8421550</u></td>
			</tr>
			<tr>
				<td>Kelurahan</td>
				<td>:</td>
				<td><u>Girimulya</u></td>
			</tr>
			<tr>
				<td>Kecamatan</td>
				<td>:</td>
				<td><u>Cibungbulang</u></td>
			</tr>
			<tr>
				<td>Kabupaten</td>
				<td>:</td>
				<td><u>Bogor</u></td>
			</tr>
			<tr>
				<td>Provinsi</td>
				<td>:</td>
				<td><u>Jawa Barat</u></td>
			</tr>
			<tr>
				<td>Website</td>
				<td>:</td>
				<td><u>smkpandu.sch.id</u></td>
			</tr>
			<tr>
				<td>E-mail</td>
				<td>:</td>
				<td><u>smkpandu@yahoo.com</u></td>
			</tr>
		</table>
		<br>
		<br>
		<br>
		Nama Peserta Didik<br><br><br>
		<span style="font-size: 14pt"><b style="font-size: 18pt"><u><?php echo $ds['nama']; ?></u></b></span>
		<br>
		<br>
		<br>
		<br>
		<span style="font-size: 14pt">
		<b style="font-size: 18pt">PEMERINTAH PROVINSI JAWA BARAT</b><br>
		<b style="font-size: 18pt">DINAS PENDIDIKAN</b><br>
		</span>
	</center>
</body>
</html>