<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cetak_raport extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->sespre = $this->config->item('session_name_prefix');

        $this->d['admlevel'] = $this->session->userdata($this->sespre.'level');
        $this->d['admkonid'] = $this->session->userdata($this->sespre.'konid');
        $this->d['url'] = "cetak_raport";

        $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport FROM tahun WHERE aktif = 'Y'")->row_array();
        $this->d['tasm'] = $get_tasm['tahun'];
        $this->d['ta'] = substr($get_tasm['tahun'],0,4);

        $this->d['wk'] = $this->session->userdata('app_rapot_walikelas');   
    }
	
	public function sampul1($id_siswa) {
        $d['ds'] = $this->db->query("SELECT nama, nis, nisn FROM m_siswa WHERE id = '$id_siswa'")->row_array();
		
        $this->load->view('cetak_sampul1', $d);

    }

    public function sampul2($id_siswa) {
        $d = null;

        $this->load->view('cetak_sampul2', $d);
    }

    public function sampul4($id_siswa) {
		$d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE aktif = 'Y'")->row_array();
        $d['ds'] = $get_tasm = $this->db->query("SELECT * FROM m_siswa WHERE id = '$id_siswa'")->row_array();

        $this->load->view('cetak_sampul4', $d);

    }


    public function cetak_to($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }

            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'B' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }

            //Kewilayahan 1
            $d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'C' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Kewilayahan 2
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Bidang Keahlian
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C1. Dasar Bidang Keahlian</div></b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'E' AND tambahan_sub = 'BIDANG'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr"><div align="center">'.$no++.'</div></td>
                                        <td><div align="left">'.$m['nama'].'</div></td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'E1' AND tambahan_sub = 'BIDANG'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr"><div align="center">'.$no++.'</div></td>
                                        <td><div align="left">'.$m['nama'].'</div></td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Program TO
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C2. Dasar Program Keahlian</div></b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'F' AND tambahan_sub = 'PROGRAM'")->result_array();

			foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr"><div align="center">'.$no++.'</div></td>
                                        <td><div align="left">'.$m['nama'].'</div></td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
			}

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_to', $d);
    }
	

		public function cetak_tkro_xi($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kewilayahan 2
			$d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi TKRO
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'H' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <div align="center"><td class="ctr">'.$no++.'</td></div>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tkro_xi', $d);
    }
	
	
		public function cetak_tkro_xii($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kompetensi TKRO
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'H' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tkro_xii', $d);
    }
	
	
	public function cetak_tbsm_xi($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kewilayahan 2
			$d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi TBSM XI
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'I' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tbsm_xi', $d);
    }
	
	
	public function cetak_tbsm_xii($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';
		
        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kompetensi TBSM XI
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'I' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi TBSM XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'J' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tbsm_xii', $d);
    }
	
	
	public function cetak_otr_xi($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kewilayahan 2
			$d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    	<tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi OTR XI
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'K' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    	<tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    	<tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_otr_xi', $d);
    }
	
	
	public function cetak_otr_xii($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kompetensi OTR XII
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'L' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_otr_xii', $d);
    }
	
	
	public function cetak_tki($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';
		
        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }

            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'B' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }

            //Kewilayahan 1
            $d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'C' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Kewilayahan 2
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Bidang Keahlian
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C1. Dasar Bidang Keahlian</div></b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'E' AND tambahan_sub = 'BIDANG'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'E1' AND tambahan_sub = 'BIDANG'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
				$nap = nilai_huruf_umum($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Program TKI
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C2. Dasar Program Keahlian</div></b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'M' AND tambahan_sub = 'PROGRAM'")->result_array();
			
			foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr">'.$no++.'</td>
                                        <td>'.$m['nama'].'</td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
			}

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tki', $d);
    }
	
	
	public function cetak_tkj_xi($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kewilayahan 2
			$d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi TKJ XI
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'N' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi TKJ XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'O' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tkj_xi', $d);
    }
	
	
	public function cetak_tkj_xii($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        $kelompok = array("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q");
		


        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kompetensi TKJ XII
			$d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'O' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_tkj_xii', $d);
    }
	
	
	public function cetak_mm_xi($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np); 
            $nilai_pengetahuan[$k]['predikat'] = nilai_huruf($_np); 
            $nilai_pengetahuan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['predikat'] = nilai_huruf($_nilai_keterampilan); 
            $nilai_keterampilan[$k]['desk'] = implode("; ", $txt_desk); 
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;

        //j($nilai_keterampilan);
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kewilayahan 2
			$d['nilai_utama'] .= '<tr><td><div align="center">B</div></td><td colspan="8"><b>Muatan Kewilayahan</b></td></tr>';
            $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_umum($naa);


                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi MM XI
            $d['nilai_utama'] .= '<tr><td colspan="8"><b><div align="left">C3. Dasar Kompetensi Keahlian</div></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'P' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];

				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_mm_xi', $d);
    }
	
	
	public function cetak_mm_xii($id_siswa,$tasm) {
        $d = array();
        
        
        $d['semester'] = substr($tasm, 4, 1);
        $d['ta'] = (substr($tasm, 0, 4))."/".(substr($tasm, 0, 4)+1);
        
        $siswa = $this->db->query("SELECT 
                                    a.nama, a.nis, a.nisn, a.prog_keahlian, a.komp_keahlian, c.tingkat, c.id idkelas
                                    FROM m_siswa a
                                    LEFT JOIN t_kelas_siswa b ON a.id = b.id_siswa
                                    LEFT JOIN m_kelas c ON b.id_kelas = c.id
                                    WHERE a.id = $id_siswa AND b.ta = '".$d['ta']."'")->row_array();
        
        $d['det_siswa'] = $siswa;
        
        $d['wali_kelas'] = $this->db->query("SELECT 
                                a.*, b.nama nmguru, b.nip, 
                                c.tingkat, c.nama nmkelas
                                FROM t_walikelas a 
                                INNER JOIN m_guru b ON a.id_guru = b.id 
                                INNER JOIN m_kelas c ON a.id_kelas = c.id
                                WHERE a.id_kelas = '".$d['det_siswa']['idkelas']."' AND a.tasm = '".$this->d['ta']."'")->row_array();
    
        // Start NILAI PENGETAHUAN //
        $ambil_np = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//'),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        $ambil_np_submp = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();

        $array1 = array();

        foreach ($ambil_np_submp as $a1) {
            $array1[$a1['id_mapel']] = array();   
        }

        foreach ($ambil_np as $a2) {
            $idx = $a2['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            if ($a2['jenis'] == "h") {
                $array1[$idx]['h'][] = $a2['nilai'];
            } else if ($a2['jenis'] == "t") {
                $array1[$idx]['t'] = $a2['nilai'];
            } else if ($a2['jenis'] == "a") {
                $array1[$idx]['a'] = $a2['nilai'];
            }
        }

        //echo var_dump($array1);

        $bobot_h = $this->config->item('pnp_h');
        $bobot_t = $this->config->item('pnp_t');
        $bobot_a = $this->config->item('pnp_a');

        $jml_bobot = $bobot_h+$bobot_t+$bobot_a;

        //MULAI HITUNG..
        $nilai_pengetahuan = array();
        foreach ($array1 as $k => $v) {
            
            $jumlah_h = !empty($array1[$k]['h']) ? sizeof($array1[$k]['h']) : 0;
            $jumlah_n_h = 0;

            $desk = array();

            if (!empty($array1[$k]['h'])) {
                foreach ($array1[$k]['h'] as $j) {
                    $pc_nilai_h = explode("//", $j);
                    $jumlah_n_h += $pc_nilai_h[0];

                    $_desk = nilai_pre($pc_nilai_h[0]);
                    $desk[$_desk][] = $pc_nilai_h[1];
                }
            } else {
                //biar ndak division by zero
                $jumlah_n_h = 1;
                $jumlah_h = 1;
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $__tengah = empty($array1[$k]['t']) ? 0 : $array1[$k]['t'];
            $__akhir = empty($array1[$k]['a']) ? 0 : $array1[$k]['a'];

            $_np = round(((($bobot_h/$jml_bobot)*($jumlah_n_h/$jumlah_h)) + 
                                (($bobot_t/$jml_bobot) * $__tengah) + 
                                (($bobot_a/$jml_bobot) * $__akhir)),0);
            

            $nilai_pengetahuan[$k]['nilai'] = number_format($_np);  
        }

        //echo j($nilai_pengetahuan);
        $d['nilai_pengetahuan'] = $nilai_pengetahuan;
        // END Nilai PENGETAHUAN

        // Start NILAI KETRAMPILAN //
        //ambil nilai untuk siswa ybs
        $ambil_nk = $this->db->query("SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//') nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa
                                    AND a.tasm = '".$tasm."'")->result_array();

        //echo var_dump($ambil_nk);
        //ambil id mapel, kode singkat
        $ambil_nk_submk = $this->db->query("SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = $id_siswa AND a.tasm = '".$tasm."'
                                    GROUP BY b.id_mapel")->result_array();
        //echo j($ambil_nk_submk);

        $array2 = array();

        foreach ($ambil_nk_submk as $a11) {
            $array2[$a11['id_mapel']] = array();   
        }

        //echo j($ambil_nk);

        foreach ($ambil_nk as $a22) {
            $idx = $a22['idmapel'];

            //$pc_nilai = explode("//", $a2['nilai']);

            $array2[$idx][] = $a22['nilai'];
        }

        //echo j($array2);

        //MULAI HITUNG..

        $nilai_keterampilan = array();
        foreach ($array2 as $k => $v) {
            
            $jumlah_array_nilai = sizeof($array2[$k]);
            $jumlah_nilai = 0;

            $desk = array();

            foreach ($array2[$k] as $j) {
                $pc_nilai = explode("//", $j);
                $jumlah_nilai += $pc_nilai[0];

                $_desk = nilai_pre($pc_nilai[0]);
                $desk[$_desk][] = $pc_nilai[1];
            }

            $txt_desk = array();
            foreach ($desk as $r => $s) {
                $txt_desk[] = $r." pada: ".implode(", ", $s);
            }

            $_nilai_keterampilan = round(($jumlah_nilai / $jumlah_array_nilai),0);
            

            $nilai_keterampilan[$k]['nilai'] = number_format($_nilai_keterampilan);  
        }

        //echo j($nilai_keterampilan);
        $d['nilai_keterampilan'] = $nilai_keterampilan;
        //exit;
        // END Nilai PENGETAHUAN
		
        
		//===========================================================================
        //              START Catatan Akademik
        //===========================================================================
        $q_catatan = $this->db->query("SELECT 
                                    a.*
                                    FROM t_c_akademik a 
                                    WHERE a.id_siswa = $id_siswa AND a.ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['catatan'] = $q_catatan;
		
		//===========================================================================
        //              START Praktik Kerja Lapangan
        //===========================================================================
        $q_pkl = $this->db->query("SELECT 
                                    mitra, lokasi, lama, keterangan
                                    FROM t_pkl
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['pkl'] = $q_pkl;

	    //===========================================================================
        //              START NIlai Ekstrakurikuler
        //===========================================================================
        $q_nilai_ekstra = $this->db->query("SELECT 
                                            b.nama, a.nilai, a.desk
                                            FROM t_nilai_ekstra a
                                            INNER JOIN m_ekstra b ON a.id_ekstra = b.id
                                            WHERE a.id_siswa = $id_siswa AND a.nilai != '0' AND a.tasm = '".$tasm."'")->result_array();
        //echo $this->db->last_query();

        $d['nilai_ekstra'] = $q_nilai_ekstra;
		

        //===========================================================================
        //              START NIlai Absensi
        //===========================================================================
        $q_nilai_absensi = $this->db->query("SELECT 
                                            s, i, a
                                            FROM t_nilai_absensi
                                            WHERE id_siswa = $id_siswa AND tasm = '".$tasm."'")->row_array();

        $d['nilai_absensi'] = $q_nilai_absensi;
		
		//===========================================================================
        //              START Nilai Karakter
        //===========================================================================
        $q_karakter = $this->db->query("SELECT 
                                    integritas, religius, nasionalis, mandiri, gotong, catatan
                                    FROM t_karakter
                                    WHERE id_siswa = $id_siswa AND ta = '$tasm'")->row_array();
                                    
       //echo $this->db->last_query();
	                                
        $d['karakter'] = $q_karakter;

        $d['nilai_utama'] = '';

        //foreach ($kelompok as $k) {
            //$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = '$k' AND nama_kelas = '$nk'")->result_array();
        

            $d['nilai_utama'] .= '<tr><td><div align="center">A</div></td><td colspan="8"><b>Muatan Nasional</b></td></tr>';
            $no = 1;


            //foreach ($q_mapel as $m) {
            //Nasional 1
            if ($this->config->item('is_pandu') == TRUE) {    
                $d['nilai_utama'] .= '';
                $q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
            }
			
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 70) + ($nka * 30)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
				
				$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'")->result_array();

                foreach ($q_mapel as $i=>$m) {
                    $idx = $m['id'];
                    $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                    $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
					$naa = number_format((($npa * 50) + ($nka * 50)) / 100);
					$nap = nilai_huruf_umum($naa);

                    $d['nilai_utama'] .= '
                                        <tr>
                                            <td class="ctr">'.$no++.'</td>
                                            <td>'.$m['nama'].'</td>
                                            <td class="ctr">'.$npa.'</td>
                                            <td class="ctr">'.$nka.'</td>
											<td class="ctr">'.$naa.'</td>
                                            <td class="ctr">'.$nap.'</td>
                                        </tr>';
                }
			
			//Kompetensi MM XII
            $d['nilai_utama'] .= '<tr><td colspan="8"><br><b><div align="left">C3. Dasar Kompetensi Keahlian</div><br></b></td></tr>';
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'Q' AND tambahan_sub = 'KOMPETENSI'")->result_array();

            foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr"><div align="center">'.$no++.'</div></td>
                                        <td><div align="left">'.$m['nama'].'</div></td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }
			
			//Kompetensi XI & XII
			$q_mapel = $this->db->query("SELECT * FROM m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'")->result_array();

           foreach ($q_mapel as $i=>$m) {
                $idx = $m['id'];
                $npa = empty($nilai_pengetahuan[$idx]['nilai']) ? "-" : $nilai_pengetahuan[$idx]['nilai'];
                $nka = empty($nilai_keterampilan[$idx]['nilai']) ? "-" : $nilai_keterampilan[$idx]['nilai'];
				$naa = number_format((($npa * 30) + ($nka * 70)) / 100);
				$nap = nilai_huruf_produktif($naa);

                $d['nilai_utama'] .= '
                                    <tr>
                                        <td class="ctr"><div align="center">'.$no++.'</div></td>
                                        <td><div align="left">'.$m['nama'].'</div></td>
                                        <td class="ctr">'.$npa.'</td>
                                        <td class="ctr">'.$nka.'</td>
										<td class="ctr">'.$naa.'</td>
                                        <td class="ctr">'.$nap.'</td>
                                    </tr>';
            }

				//}
            //}
        //}
        $d['det_raport'] = $get_tasm = $this->db->query("SELECT tahun, nama_kepsek, nip_kepsek, tgl_raport, tgl_raport_kelas3 FROM tahun WHERE tahun = '$tasm'")->row_array();
        
        
        $this->load->view('cetak_mm_xii', $d);
    }
	

    public function index() {

        $wali = $this->session->userdata($this->sespre."walikelas");

        $this->d['siswa_kelas'] = $this->db->query("SELECT 
                                                a.id_siswa, b.nama
                                                FROM t_kelas_siswa a
                                                INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                WHERE a.id_kelas = '".$wali['id_walikelas']."' AND a.ta = '".$this->d['ta']."' ORDER BY b.nama ASC")->result_array();

    	$this->d['p'] = "list";
        $this->load->view("template_utama", $this->d);
    }

}