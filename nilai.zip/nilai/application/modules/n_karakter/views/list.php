<style type="text/css">
    .ctr {text-align: center}
    .nso {}
</style>
<div class="card">
    <div class="header">
        <h4 class="title">Nilai Karakter</h4>
    </div>
    <div class="content">  

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="25%">Nama</th>
                    <th width="10%"><div align="center">Integritas</div></th>
					<th width="10%"><div align="center">Religius</div></th>
					<th width="10%"><div align="center">Nasionalis</div></th>
					<th width="10%"><div align="center">Mandiri</div></th>
					<th width="10%"><div align="center">Gotong Royong</div></th>
					<th width="20%"><div align="center">Catatan</th>
                </tr>
            </thead>

            <tbody>
                <form method="post" id="<?php echo $url; ?>">
				<form method="get" id="<?php echo $url; ?>">
                <input type="hidden" name="mode_form" value="<?php echo $mode_form; ?>">

                <?php 

                $no = 1;
                if (!empty($siswa_kelas)) {
                    foreach ($siswa_kelas as $sk) {
                        echo '<input type="hidden" name="id_siswa_'.$no.'" value="'.$sk['id_siswa'].'">';
                ?>
                    <tr>
                        <td><?php echo $no; ?></td>
                        <td><?php echo $sk['nama']; ?></td>
                        <td>
                            <?php 
                            echo form_dropdown("integritas_".$no,$p_integritas,$sk['integritas'],'class="form-control input-sm" required id="integritas_'.$no.'"');
                            ?>
                        <td>
                            <?php 
                            echo form_dropdown("religius_".$no,$p_religius,$sk['religius'],'class="form-control input-sm" required id="religius_'.$no.'"');
                            ?>
                        </td>
						<td>
                            <?php 
                            echo form_dropdown("nasionalis_".$no,$p_nasionalis,$sk['nasionalis'],'class="form-control input-sm" required id="nasionalis_'.$no.'"');
                            ?>
                        </td>
						<td>
                            <?php 
                            echo form_dropdown("mandiri_".$no,$p_mandiri,$sk['mandiri'],'class="form-control input-sm" required id="mandiri_'.$no.'"');
                            ?>
                        </td>
						<td>
                            <?php 
                            echo form_dropdown("gotong_".$no,$p_gotong,$sk['gotong'],'class="form-control input-sm" required id="gotong_'.$no.'"');
                            ?>
                        </td>
						<td>
                            <?php 
                            echo form_dropdown("catatan_".$no,$p_catatan,$sk['catatan'],'class="form-control input-sm" required id="catatan_'.$no.'"');
                            ?>
                        </td>
                    </tr>
                <?php 
                        $no++;
                    }
                } else {
                    echo '<tr><td colspan="4">Belum ada data siswa</td></tr>';
                }
                ?>

                
                
            </tbody>
            
        </table>

        <input type="hidden" name="jumlah" value="<?php echo $no; ?>">
        <button type="submit" class="btn btn-success" id="tbsimpan"><i class="fa fa-check"></i> Simpan</button>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).on("ready", function() {
        
        $("#<?php echo $url; ?>").on("submit", function() {
                
            var data    = $(this).serialize();


            $.ajax({
                type: "POST",
                data: data,
                url: base_url+"<?php echo $url; ?>/simpan",
                beforeSend: function(){
                    $("#tbsimpan").attr("disabled", true);
                },
                success: function(r) {
                    $("#tbsimpan").attr("disabled", false);
                    if (r.status == "ok") {
                        noti("success", r.data);
                    } else {
                        noti("danger", r.data);
                    }
                }
            });

            return false;
        });
    });
</script>
