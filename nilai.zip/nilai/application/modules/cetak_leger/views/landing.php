<div class="row">
    <div class="col-md-12">
        <p>
            <!--<a href="<?php echo base_url()."/".$url; ?>/cetak/<?php echo $this->uri->segment(3); ?>" class="btn btn-warning" target="_blank">Cetak</a>-->
        </p>
    </div>
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Cetak Leger </h4>
            </div>
            <div class="content">  
                <a href="<?php echo base_url().$url; ?>/cetak_to" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> X TO</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tki" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> X TKI</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tkro_xi" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XI TKRO</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tkro_xii" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XII TKRO</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tbsm_xi" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XI TBSM</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tbsm_xii" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XII TBSM</a><br>
				<a href="<?php echo base_url().$url; ?>/cetak_otr_xi" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XI OTR</a>
				<a href="<?php echo base_url().$url; ?>/cetak_otr_xii" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XII OTR</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tkj_xi" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XI TKJ</a>
				<a href="<?php echo base_url().$url; ?>/cetak_tkj_xii" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XII TKJ</a>
				<a href="<?php echo base_url().$url; ?>/cetak_mm_xi" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XI MM</a>
				<a href="<?php echo base_url().$url; ?>/cetak_mm_xii" target="_blank" class="btn btn-danger"><i class="fa fa-print"></i> XII MM</a><br>
            </div>
        </div>
    </div>
</div>