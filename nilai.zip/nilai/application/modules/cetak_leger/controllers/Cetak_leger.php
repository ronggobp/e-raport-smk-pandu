<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Cetak_leger extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->sespre = $this->config->item('session_name_prefix');
        $this->d['admlevel'] = $this->session->userdata($this->sespre.'level');
        $this->d['admkonid'] = $this->session->userdata($this->sespre.'konid');
        $this->d['url'] = "cetak_leger";
        $get_tasm = $this->db->query("SELECT tahun FROM tahun WHERE aktif = 'Y'")->row_array();
        $this->d['tasm'] = $get_tasm['tahun'];
        $this->d['ta'] = substr($this->d['tasm'], 0, 4);
        $this->d['sm'] = substr($this->d['tasm'], 4, 1);
        $this->d['wk'] = $this->session->userdata('app_rapot_walikelas');
        $wali = $this->session->userdata($this->sespre."walikelas");
        $this->d['id_kelas'] = $wali['id_walikelas'];
        $this->d['nama_kelas'] = $wali['nama_walikelas'];

        $this->d['dw'] = $this->db->query("select 
                b.nama nmkelas, c.nama nmguru
                from t_walikelas a 
                inner join m_kelas b on a.id_kelas = b.id
                inner join m_guru c on a.id_guru = c.id
                where left(a.tasm,4) = '".$this->d['ta']."' and a.id_kelas = '".$this->d['id_kelas']."'")->row_array();
        
    }
    public function index() {
        $this->d['p'] = "landing";
        $this->load->view("template_utama", $this->d);
    }
	public function cetak_to() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."' ORDER BY b.nama ASC";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'B' AND tambahan_sub = 'NASIONAL'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'C' AND tambahan_sub = 'WILAYAH'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel7 = "select * from m_mapel WHERE kelompok = 'E' AND tambahan_sub = 'BIDANG'";
		$s_mapel8 = "select * from m_mapel WHERE kelompok = 'E1' AND tambahan_sub = 'BIDANG'";
		$s_mapel9 = "select * from m_mapel WHERE kelompok = 'F' AND tambahan_sub = 'PROGRAM'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_mapel7 = $this->db->query($s_mapel7)->result_array();
		$queri_mapel8 = $this->db->query($s_mapel8)->result_array();
		$queri_mapel9 = $this->db->query($s_mapel9)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel7 as $m7) {
            $html .= '<td colspan="4"><div align="center">'.$m7['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel8 as $m8) {
            $html .= '<td colspan="4"><div align="center">'.$m8['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel9 as $m9) {
            $html .= '<td colspan="4"><div align="center">'.$m9['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel7 as $m7) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel8 as $m8) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel9 as $m9) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel7 as $m7) {
                // Nilai Pengetahuan
                $idx1 = $m7['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel8 as $m8) {
                // Nilai Pengetahuan
                $idx1 = $m8['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel9 as $m9) {
                // Nilai Pengetahuan
                $idx1 = $m9['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.nama ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_to', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_to', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_to', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_to', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tki() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'B' AND tambahan_sub = 'NASIONAL'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'C' AND tambahan_sub = 'WILAYAH'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel7 = "select * from m_mapel WHERE kelompok = 'E' AND tambahan_sub = 'BIDANG'";
		$s_mapel8 = "select * from m_mapel WHERE kelompok = 'E1' AND tambahan_sub = 'BIDANG'";
		$s_mapel9 = "select * from m_mapel WHERE kelompok = 'M' AND tambahan_sub = 'PROGRAM'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_mapel7 = $this->db->query($s_mapel7)->result_array();
		$queri_mapel8 = $this->db->query($s_mapel8)->result_array();
		$queri_mapel9 = $this->db->query($s_mapel9)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel7 as $m7) {
            $html .= '<td colspan="4"><div align="center">'.$m7['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel8 as $m8) {
            $html .= '<td colspan="4"><div align="center">'.$m8['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel9 as $m9) {
            $html .= '<td colspan="4"><div align="center">'.$m9['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel7 as $m7) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel8 as $m8) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel9 as $m9) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel7 as $m7) {
                // Nilai Pengetahuan
                $idx1 = $m7['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel8 as $m8) {
                // Nilai Pengetahuan
                $idx1 = $m8['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel9 as $m9) {
                // Nilai Pengetahuan
                $idx1 = $m9['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.nama ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tki', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tki', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tki', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tki', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tkro_xi() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'H' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tkro_xi', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tkro_xi', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tkro_xi', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tkro_xi', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tkro_xii() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'H' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tkro_xii', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tkro_xii', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tkro_xii', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tkro_xii', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tbsm_xi() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'I' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tbsm_xi', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tbsm_xi', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tbsm_xi', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tbsm_xi', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tbsm_xii() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'I' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'J' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tbsm_xii', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tbsm_xii', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tbsm_xii', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tbsm_xii', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_otr_xi() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'K' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_otr_xi', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_otr_xi', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_otr_xi', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_otr_xi', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_otr_xii() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'L' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_otr_xii', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_otr_xii', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_otr_xii', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_otr_xii', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tkj_xi() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'N' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'O' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel7 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_mapel7 = $this->db->query($s_mapel7)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel7 as $m7) {
            $html .= '<td colspan="4"><div align="center">'.$m7['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel7 as $m7) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel7 as $m7) {
                // Nilai Pengetahuan
                $idx1 = $m7['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tkj_xi', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tkj_xi', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tkj_xi', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tkj_xi', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_tkj_xii() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'O' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_tkj_xii', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_tkj_xii', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_tkj_xii', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_tkj_xii', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
	public function cetak_mm_xi() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'D' AND tambahan_sub = 'WILAYAH'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'P' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel6 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_mapel6 = $this->db->query($s_mapel6)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td colspan="4"><div align="center">'.$m6['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="3"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
		foreach ($queri_mapel6 as $m6) {
            $html .= '<td class="ctr">P</td><td class="ctr">K</td><td class="ctr">A</td><td class="ctr">P</td>';
        }
            $html .= '<td class="ctr">S</td><td class="ctr">I</td><td class="ctr">A</td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel6 as $m6) {
                // Nilai Pengetahuan
                $idx1 = $m6['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_mm_xi', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_mm_xi', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_mm_xi', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_mm_xi', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
    public function cetak_mm_xii() {
        $s_siswa = "select 
            a.id_siswa, b.nama
            from t_kelas_siswa a 
            inner join m_siswa b on a.id_siswa = b.id
            where a.id_kelas = '".$this->d['id_kelas']."' and a.ta = '".$this->d['ta']."'";

        $s_mapel = "select * from m_mapel WHERE kelompok = 'A1' AND tambahan_sub = 'NASIONAL'";
		$s_mapel1 = "select * from m_mapel WHERE kelompok = 'A' AND tambahan_sub = 'NASIONAL'";
		$s_mapel2 = "select * from m_mapel WHERE kelompok = 'A2' AND tambahan_sub = 'NASIONAL'";
		$s_mapel3 = "select * from m_mapel WHERE kelompok = 'A3' AND tambahan_sub = 'NASIONAL'";
		$s_mapel4 = "select * from m_mapel WHERE kelompok = 'Q' AND tambahan_sub = 'KOMPETENSI'";
		$s_mapel5 = "select * from m_mapel WHERE kelompok = 'G' AND tambahan_sub = 'KOMPETENSI'";

        $strq_np = "select 
                c.id_mapel, a.id_siswa, a.jenis, avg(a.nilai) nilai
                from t_nilai a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                inner join t_guru_mapel c on a.id_guru_mapel = c.id
                where b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."'
                group by c.id_mapel, a.id_siswa, a.jenis";
        $strq_nk = "select 
                 c.id_mapel, a.id_siswa, avg(a.nilai) nilai
                 from t_nilai_ket a 
                 inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                 inner join t_guru_mapel c on a.id_guru_mapel = c.id
                 where b.id_kelas = '".$this->d['id_kelas']."' 
                 and a.tasm = '".$this->d['tasm']."'
                 group by c.id_mapel, a.id_siswa";
		$strq_n_absen = "select 
                a.id_siswa, a.s, a.i, a.a
                from t_nilai_absensi a 
                inner join t_kelas_siswa b on a.id_siswa = b.id_siswa
                where 
                b.id_kelas = '".$this->d['id_kelas']."' 
                and a.tasm = '".$this->d['tasm']."' 
                and b.ta = '".$this->d['ta']."'";

		$queri_np = $this->db->query($strq_np)->result_array();
        $queri_nk = $this->db->query($strq_nk)->result_array();
        $queri_siswa = $this->db->query($s_siswa)->result_array();
        $queri_mapel = $this->db->query($s_mapel)->result_array();
		$queri_mapel1 = $this->db->query($s_mapel1)->result_array();
		$queri_mapel2 = $this->db->query($s_mapel2)->result_array();
		$queri_mapel3 = $this->db->query($s_mapel3)->result_array();
		$queri_mapel4 = $this->db->query($s_mapel4)->result_array();
		$queri_mapel5 = $this->db->query($s_mapel5)->result_array();
		$queri_na = $this->db->query($strq_n_absen)->result_array();
		
		$data_np = array();
        foreach ($queri_np as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $idx3 = $a['jenis'];
            $data_np[$idx1][$idx2][$idx3] = $a['nilai'];
        }

        $data_nk = array();
        foreach ($queri_nk as $a) {
            $idx1 = $a['id_mapel'];
            $idx2 = $a['id_siswa'];
            $data_nk[$idx1][$idx2] = $a['nilai'];
        }
		
		$data_na = array();
        foreach ($queri_na as $a) {
            $idx1 = $a['id_siswa'];
            $data_na[$idx1]['s'] = $a['s'];
            $data_na[$idx1]['i'] = $a['i'];
            $data_na[$idx1]['a'] = $a['a'];
        }

        $html = '<p align="left"><b>LEGER NILAI PENGETAHUAN & KETERAMPILAN</b>
                <br>
                Kelas : '.$this->d['dw']['nmkelas'].', Nama Wali : '.$this->d['dw']['nmguru'].', Tahun Pelajaran '.$this->d['tasm'].'<hr style="border: solid 1px #000; margin-top: -10px"></p>';
		$html .= '<table class="table"><tr><td rowspan="2"><div align="center">No</div></td>';
		$html .= '<td rowspan="2">Nama</td>';
        foreach ($queri_mapel as $m) {
            $html .= '<td colspan="4"><div align="center">'.$m['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td colspan="4"><div align="center">'.$m1['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td colspan="4"><div align="center">'.$m2['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td colspan="4"><div align="center">'.$m3['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td colspan="4"><div align="center">'.$m4['kd_singkat'].'</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td colspan="4"><div align="center">'.$m5['kd_singkat'].'</div></td>';
        }
        $html .= '<td rowspan="2"><div align="center">Jumlah</div></td>';
        $html .= '<td rowspan="2"><div align="center">Ranking</div></td>';
		$html .= '<td colspan="4"><div align="center">Absensi</div></td></tr>';
        foreach ($queri_mapel as $m) {
            $html .= '<td><div align="center">P</div></td><td><div align="center">K</div></td><td><div align="center">A</div></td><td><div align="center">P</div></td>';
        }
		foreach ($queri_mapel1 as $m1) {
            $html .= '<td><div align="center">P</div></td><td><div align="center">K</div></td><td><div align="center">A</div></td><td><div align="center">P</div></td>';
        }
		foreach ($queri_mapel2 as $m2) {
            $html .= '<td><div align="center">P</div></td><td><div align="center">K</div></td><td><div align="center">A</div></td><td><div align="center">P</div></td>';
        }
		foreach ($queri_mapel3 as $m3) {
            $html .= '<td><div align="center">P</div></td><td><div align="center">K</div></td><td><div align="center">A</div></td><td><div align="center">P</div></td>';
        }
		foreach ($queri_mapel4 as $m4) {
            $html .= '<td><div align="center">P</div></td><td><div align="center">K</div></td><td><div align="center">A</div></td><td><div align="center">P</div></td>';
        }
		foreach ($queri_mapel5 as $m5) {
            $html .= '<td><div align="center">P</div></td><td><div align="center">K</div></td><td><div align="center">A</div></td><td><div align="center">P</div></td>';
        }
            $html .= '<td><div align="center">S</div></td><td><div align="center">I</div></td><td><div align="center">A</div></td>';
		$no = 1;

        foreach ($queri_siswa as $s) {
			$html .= '<tr><td><div align="center">'.$no++.'</div></td><td>'.$s['nama'].'</td>';
            $jml_np = 0;
            $jml_nk = 0;
			$jml_na = 0;
			$id_siswa = $s['id_siswa'];
            foreach ($queri_mapel as $m) {
                // Nilai Pengetahuan
                $idx1 = $m['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel1 as $m1) {
                // Nilai Pengetahuan
                $idx1 = $m1['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 70) + ($nk * 30)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel2 as $m2) {
                // Nilai Pengetahuan
                $idx1 = $m2['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel3 as $m3) {
                // Nilai Pengetahuan
                $idx1 = $m3['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 50) + ($nk * 50)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_umum($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel4 as $m4) {
                // Nilai Pengetahuan
                $idx1 = $m4['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
			foreach ($queri_mapel5 as $m5) {
                // Nilai Pengetahuan
                $idx1 = $m5['id'];
                $idx2 = $s['id_siswa'];
                $np_h = !empty($data_np[$idx1][$idx2]['h']) ? $data_np[$idx1][$idx2]['h'] : 0;
                $np_t = !empty($data_np[$idx1][$idx2]['t']) ? $data_np[$idx1][$idx2]['t'] : 0;
                $np_a = !empty($data_np[$idx1][$idx2]['a']) ? $data_np[$idx1][$idx2]['a'] : 0;
                $p_h = $this->config->item('pnp_h');
                $p_t = $this->config->item('pnp_t');
                $p_a = $this->config->item('pnp_a');
                $jml = $p_h+$p_t+$p_a;

                $p_h = ($p_h / $jml) * 100; 
                $p_t = ($p_t / $jml) * 100; 
                $p_a = ($p_a / $jml) * 100; 
                
                $np = number_format((($np_h * $p_h) + ($np_t * $p_t) + ($np_a * $p_a)) / 100);
                $jml_np = $jml_np + $np;

                // Nilai Ketrampilan
                $nk = !empty($data_nk[$idx1][$idx2]) ? number_format($data_nk[$idx1][$idx2]) : 0;
                $jml_nk = $jml_nk + $nk;
				
				// Nilai Akhir
				$na = number_format((($np * 30) + ($nk * 70)) / 100);
				$jml_na = $jml_na + $na;
				
				// Predikat Nilai Akhir
				$nap = nilai_huruf_produktif($na);

                $html .= '<td class="ctr">'.($np).'</td><td class="ctr">'.($nk).'</td><td class="ctr">'.($na).'</td><td class="ctr">'.($nap).'</td>';
            }
            $html .= '<td class="ctr">'.($jml_na).'</td><td></td>';
			
			$s = !empty($data_na[$id_siswa]['s']) ? $data_na[$id_siswa]['s'] : '-';
            $i = !empty($data_na[$id_siswa]['i']) ? $data_na[$id_siswa]['i'] : '-';
            $a = !empty($data_na[$id_siswa]['a']) ? $data_na[$id_siswa]['a'] : '-';

            $html .= '
            <td class="ctr">'.$s.'</td>
            <td class="ctr">'.$i.'</td>
            <td class="ctr">'.$a.'</td>
            </tr>';
        }

        $html .= '</table>';

        /*
        echo $html;
        exit;


        $uri3 = $this->uri->segment(3);
        
        $_tasm = '';
        if (empty($uri3)) {
            $_tasm = $this->d['tasm'];
        } else {
            $_tasm = $uri3;
        }
        
        $_ta = substr($_tasm,0,4);
        $_sm = substr($_tasm,4,1);
        
        
        $d = array();
        $id_kelas = $this->d['wk']['id_walikelas'];
        $siswa = $this->db->query("SELECT a.id_siswa, b.nama FROM t_kelas_siswa a INNER JOIN m_siswa b ON a.id_siswa = b.id WHERE a.id_kelas = $id_kelas AND a.ta = '".$_ta."' ORDER BY b.id ASC")->result_array();
        
        $mapel = $this->db->query("SELECT id, kd_singkat FROM m_mapel ORDER BY id ASC")->result_array();
        //echo $this->db->last_query();
        if (!empty($siswa)) {
            foreach ($siswa as $s) {
                $id_siswa = $s['id_siswa'];
                $n_pengetahuan = $this->db->query("select 
                                                c.id, group_concat(if(a.jenis='h',concat(a.jenis,'-',a.nilai),concat(a.jenis,'-',0))) gabung,
                                                round((((sum(if(a.jenis='h',a.nilai,0))/(count(if(a.jenis='h',1,0))-2)*2) + 
                                                (sum(if(a.jenis='t',a.nilai,0))) + 
                                                (sum(if(a.jenis='a',a.nilai,0)))) / 4),0) na
                                                from t_nilai a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel
                                                order by c.kd_singkat asc")->result_array();

                //echo $this->db->last_query();
                //exit;

                $n_keterampilan = $this->db->query("select 
                                                c.id,
                                                c.kd_singkat, 
                                                round(avg(a.nilai),0) na
                                                from t_nilai_ket a
                                                left join t_guru_mapel b on a.id_guru_mapel = b.id
                                                left join m_mapel c on b.id_mapel = c.id
                                                where a.id_siswa = $id_siswa and a.tasm = '".$_tasm."'
                                                group by b.id_mapel")->result_array();
                $jml = 0;
                if (!empty($n_pengetahuan)) {
                    foreach ($n_pengetahuan as $np) {
                        $idx = $np['id'];
                        $val = $np['na'];
                        
                        $jml += $val;
                        $d['np'][$id_siswa][$idx] = $val;
                    }
                }
                if (!empty($n_keterampilan)) {
                    foreach ($n_keterampilan as $nk) {
                        $idx = $nk['id'];
                        $val = $nk['na'];
                        
                        $jml += $val;
                        $d['nk'][$id_siswa][$idx] = $val;
                    }
                }
                $d['peringkat'][$id_siswa] = $jml;
                // echo var_dump($d[$id_siswa]);
            }
        } 
        //urutkan jumlah untuk mendapatkan peringkat
        rsort($d['peringkat']);
        //j($d['peringkat']);
        
        ///GENERATE HTML
        $html = '<table class="table"><thead><tr><th rowspan="2">No</th><th rowspan="2">Nama Siswa</th>';
        
        $baris_kedua = '';
        if (!empty($mapel)) {
            foreach ($mapel as $m) {
                $html .= '<th colspan="4">'.$m['kd_singkat'].'</th>';
                $baris_kedua .= '<th>P</th><th>K</th><th>A</th><th>P</th>';
            }
        }
        
        $html .= '<th colspan="3">Jumlah</th><th rowspan="2">Peringkat</th></tr><tr>'.$baris_kedua.'<th>P</th><th>K</th><th>Jml</th></tr></thead><tbody>';
        if (!empty($siswa)) {
            $no = 1;
            foreach ($siswa as $s) {
                $html .= '<tr><td class="ctr">'.$no++.'</td><td>'.$s['nama'].'</td>';
                if (!empty($mapel)) {
                    $jml = 0;
                    $jml_p = 0;
                    $jml_k = 0;
                    foreach ($mapel as $m) {
                        $idx_siswa = $s['id_siswa'];
                        $idx_mapel = $m['id'];
                        $isi_p = empty($d['np'][$idx_siswa][$idx_mapel]) ? "-" : $d['np'][$idx_siswa][$idx_mapel];
                        $isi_k = empty($d['nk'][$idx_siswa][$idx_mapel]) ? "-" : $d['nk'][$idx_siswa][$idx_mapel];
                        
                        $jml_p += $isi_p;
                        $jml_k += $isi_k;
                        $jml += ($isi_p+$isi_k);
                        
                        $html .= '<td class="ctr">'.$isi_p.'</td><td class="ctr">'.$isi_k.'</td>';
                    }
                }
                $peringkat = array_search($jml, $d['peringkat']) + 1;
                $html .= '<td class="ctr"><b>'.$jml_p.'</td><td class="ctr"><b>'.$jml_k.'</b></td><td class="ctr"><b>'.$jml.'</b></td><td class="ctr">'.$peringkat.'</td></tr>';
            }
        }
        $html .= '</tbody></table>';
        */

        $d['html'] = $html;
        $d['teks_tasm'] = "Tahun Ajaran ".$this->d['ta']."/".($this->d['ta']+1).", Semester ".$this->d['sm'];
        //j($d);
        //$this->load->view('cetak_mm_xii', $d);

        $mauke = $this->uri->segment(3);

        if (empty($mauke)) {
            $this->load->view('cetak_mm_xii', $d);
        } else if ($mauke == "print") {
            $this->load->view('cetak_mm_xii', $d);
        } else if ($mauke == "excel") {
            $this->load->view('cetak_mm_xii', $d);
            $filename = "leger_" . date('YmdHis') . ".xls";
            header("Content-Disposition: attachment; filename=\"$filename\"");
            header("Content-Type: application/vnd.ms-excel");
        }
    }
}