<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">No Akses</h4>

            </div>
            <div class="content">

                <div class="alert alert-danger">
                Maaf, Anda tidak mempunyai akses ke halaman ini..! :(
                </div>
            </div>
        </div>
    </div>
</div>
