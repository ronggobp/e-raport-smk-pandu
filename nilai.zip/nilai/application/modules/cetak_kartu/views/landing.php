<div class="">
    <div class="col-md-12">
        <p>
            <!--<a href="<?php echo base_url()."/".$url; ?>/cetak/<?php echo $this->uri->segment(3); ?>" class="btn btn-warning" target="_blank">Cetak</a>-->
        </p>
    </div>

    <div class="col-md-12">
        <div class="card">
            <div class="header">
                <h4 class="title">Cetak Leger </h4>
            </div>
            <div class="content">  
                <a href="<?php echo base_url().$url; ?>/cetak" target="_blank" class="btn btn-success"><i class="fa fa-print"></i> Cetak Leger Nilai Pengetahuan dan Nilai Keterampilan</a> 
				<a href="<?php echo base_url().$url; ?>/cetak_ekstra" target="_blank" class="btn btn-success"><i class="fa fa-print"></i> Cetak Leger Nilai Ekstrakuriler dan Absensi</a><br>
            </div>
        </div>
    </div>

</div>