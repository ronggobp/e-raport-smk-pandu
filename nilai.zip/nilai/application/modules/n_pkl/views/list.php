<style type="text/css">
    .ctr {text-align: center}
    .nso {}
</style>
<div class="card">
    <div class="header">
        <h4 class="title">Praktik Kerja Lapangan</h4>
    </div>
    <div class="content">  

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th width="3%">No</th>
                    <th width="22%">Nama</th>
                    <th width="15%">Mitra DU/DI</th>
					<th width="20%">Lokasi</th>
					<th width="15%">Lamanya (bulan)</th>
					<th width="15%">Keterangan</th>
                </tr>
            </thead>

            <tbody>
                <form method="post" id="<?php echo $url; ?>">
                <input type="hidden" name="mode_form" value="<?php echo $mode_form; ?>">

                <?php 

                $no = 1;
                if (!empty($siswa_kelas)) {
                    foreach ($siswa_kelas as $sk) {
                        echo '<input type="hidden" name="id_siswa_'.$no.'" value="'.$sk['id_siswa'].'">';
                ?>
                    <tr>
                        <td><?php echo $no; ?></td>
                        <td><?php echo $sk['nama']; ?></td>
                        <td>
                            <input type="text" name="mitra_<?php echo $no; ?>" value="<?php echo $sk['mitra']; ?>" class="form-control input-sm" id="mitra_<?php echo $no; ?>">
                        </td>
						<td>
                            <input type="text" name="lokasi_<?php echo $no; ?>" value="<?php echo $sk['lokasi']; ?>" class="form-control input-sm" id="lokasi_<?php echo $no; ?>">
                        </td>
						<td>
                            <?php 
                            echo form_dropdown("lama_".$no,$p_lama,$sk['lama'],'class="form-control input-sm" required id="lama_'.$no.'"');
                            ?>
                        </td>
						<td>
                            <?php 
                            echo form_dropdown("keterangan_".$no,$p_keterangan,$sk['keterangan'],'class="form-control input-sm" required id="keterangan_'.$no.'"');
                            ?>
                        </td>
                    </tr>
                <?php 
                        $no++;
                    }
                } else {
                    echo '<tr><td colspan="4">Belum ada data siswa</td></tr>';
                }
                ?>

                
                
            </tbody>
            
        </table>

        <input type="hidden" name="jumlah" value="<?php echo $no; ?>">
        <button type="submit" class="btn btn-success" id="tbsimpan"><i class="fa fa-check"></i> Simpan</button>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).on("ready", function() {
        
        $("#<?php echo $url; ?>").on("submit", function() {
                
            var data    = $(this).serialize();


            $.ajax({
                type: "POST",
                data: data,
                url: base_url+"<?php echo $url; ?>/simpan",
                success: function(r) {
                    if (r.status == "ok") {
                        noti("success", r.data);
                    } else {
                        noti("danger", r.data);
                    }
                }
            });

            return false;
        });
    });

</script>